//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class ModelHandler.
// !\description Header file for class ModelHandler.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef MODELHANDLER_H
#define MODELHANDLER_H


/*===========================================================================*\
    CLASS       :   ModelHandler

    The Model class needs to send several signals. But since that class is not
    a QObject subclass, it doesn't understand SIGNALS. Therefore this signalhandler
    class is used, which is a QObject subclass and therefore does understand
    SIGNALS.
\*===========================================================================*/


#include <QObject>

#include "WidgetControllerInfo.h"

class ModelHandler : public QObject
{
    Q_OBJECT
public:
    explicit ModelHandler(QObject *parent = NULL);

    void sendDisablePaste(bool setDisabled)                    { emit disablePasteAction(setDisabled); }     // ->SLOT onDisablePasteAction
    void sendDisableShowProperties(const QString &funcname)    { emit disableShowProperties(funcname); }     // ->SLOT onDisableShowProperties
    void sendEnableShowProperties(const QString &funcname)     { emit enableShowProperties(funcname); }      // ->SLOT onEnableShowProperties
    void newWidgetSelection(WidgetController *ddwidg)          { emit sendNewWidgetSelection(ddwidg); }      // ->SLOT SetSelection
    void sendMessage(QString title, QString msg, int level)    { emit sigSendMessage(title, msg, level); }   // ->SLOT onNewLogMessage
    void newWidgetProperties(WidgetController *ddwidg)         { emit sigNewWidgetProperties(ddwidg); }      // ->SLOT loadProperties
    void sendEnableForwardBackward(bool on)                    { emit enableForwardBackward(on); }           // ->SLOT onEnableForwardbackward

public slots:
    void sendNewWidget()                                       { emit newWidget(); }                         // ->SLOT fillObjectTree

signals:
    void newWidget();
    void disablePasteAction(bool);
    void disableShowProperties(const QString &funcname);
    void enableShowProperties(const QString &funcname);
    void sigSendMessage(QString title, QString msg, int level);
    void enableForwardBackward(bool on);

    void sendNewWidgetSelection(WidgetController *);
    void sigNewWidgetProperties(WidgetController *);

public slots:
};

#endif  // MODELHANDLER_H
