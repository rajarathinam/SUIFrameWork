//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for TextArea.
// !\description Class implementation file for TextArea.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "FWQxWidgets/SUITextArea.h"

#include "FWQxCore/SUIObjectFactory.h"

SUI::TextArea::TextArea() : 
    Widget(SUI::ObjectType::TextArea)
{
}

SUI::TextArea::~TextArea()
{
}
