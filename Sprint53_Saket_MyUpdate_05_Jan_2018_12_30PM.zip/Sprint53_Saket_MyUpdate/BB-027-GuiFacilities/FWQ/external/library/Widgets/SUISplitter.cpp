//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for Splitter.
// !\description Class implementation file for Splitter.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "FWQxWidgets/SUISplitter.h"

#include "FWQxCore/SUIObjectFactory.h"

SUI::Splitter::Splitter() : 
    Widget(SUI::ObjectType::Splitter)
{
}

SUI::Splitter::~Splitter()
{
}
