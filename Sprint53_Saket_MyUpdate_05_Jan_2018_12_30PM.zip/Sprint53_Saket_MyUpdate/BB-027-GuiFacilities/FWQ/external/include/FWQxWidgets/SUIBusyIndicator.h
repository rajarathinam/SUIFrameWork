//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::BusyIndicator.
// !\description Header file for class SUI::BusyIndicator.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIBUSYINDICATOR_H
#define SUIBUSYINDICATOR_H

#include "FWQxWidgets/SUIWidget.h"
#include "FWQxCore/SUIIAnimatable.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 *
 * \brief Specific Interface for the BusyIndicator Widget
 */
class SUI_SHARED_EXPORT BusyIndicator : public Widget, public IAnimatable
{
public:
    virtual ~BusyIndicator();
    
protected:
    BusyIndicator();

};
}

#endif // SUIBUSYINDICATOR_H
