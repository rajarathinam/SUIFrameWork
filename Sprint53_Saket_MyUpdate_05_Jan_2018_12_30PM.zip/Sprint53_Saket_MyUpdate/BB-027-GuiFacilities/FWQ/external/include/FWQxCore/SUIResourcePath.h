//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ResourcePath
// !\description Header file for class SUI::ResourcePath.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUIRESOURCEPATH_H
#define SUIRESOURCEPATH_H

#include "FWQxCore/SUISharedExport.h"
#include <string>
namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief The ResourcePath class
 * This ResourcePath is used to retrieved all resouces while loading an UI File
 */
class SUI_SHARED_EXPORT ResourcePath
{
public:
    ResourcePath();
    /*!
     * \brief getInstance
     * Returns the one and only instance
     * \return
     */
    static ResourcePath *getInstance();

    /*!
     * \brief setResourcePath
     * This sets the resource path: all external resource files (for example images or XML files) that need to be
     * loaded by the framework will be resolved from this path
     * \param path - the resource path
     * \exception ArgumentException - If the supplied path is invalid an exception will be thrown
     */
    void setResourcePath(const std::string& path);

    /*!
     * \brief getResourcePath
     * Returns the current resource path
     */
    static std::string getResourcePath();

    /*!
     * \brief getResourceFile
     * This method will try to resolve the path to the specified filename. The filename can have one of these types:
     * (1) a full path (for example /home/user/<filename>)
     * (2) a resource path (for example :/<filename>)
     * (3) a relative path
     * If 'filename' is a full path or resource path, the method will return 'filename'
     * If 'filename' is a relative path, the method tries to resolve it from the resource path. If the file cannot be
     * found there, the method will try to resolve it from the path where the executable is residing. If the file
     * cannot be found there also, it returns 'filename'.
     * \param filename
     */
    static std::string getResourceFile(const std::string& filename);
};
}

#endif // SUIRESOURCEPATH_H
