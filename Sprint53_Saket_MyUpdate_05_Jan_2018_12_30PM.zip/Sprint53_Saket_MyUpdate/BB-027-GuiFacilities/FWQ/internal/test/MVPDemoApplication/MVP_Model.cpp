//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for Model.
// !\description Class implementation file for Model
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "MVP_Model.hpp"

const std::string USERNAME_USER1 = "User1";
const std::string USERNAME_USER2 = "User2";
const std::string USERNAME_USER3 = "User3";
const std::string USERNAME_USER4 = "User4";

const std::string PASSWORD_USER1 = "Password1";
const std::string PASSWORD_USER2 = "Password2";
const std::string PASSWORD_USER3 = "Password3";
const std::string PASSWORD_USER4 = "Password4";

MVP::Model::Model()
{
   usersAndPasswords.insert(std::pair<std::string, std::string>(USERNAME_USER1, PASSWORD_USER1));
   usersAndPasswords.insert(std::pair<std::string, std::string>(USERNAME_USER2, PASSWORD_USER2));
   usersAndPasswords.insert(std::pair<std::string, std::string>(USERNAME_USER3, PASSWORD_USER3));
   usersAndPasswords.insert(std::pair<std::string, std::string>(USERNAME_USER4, PASSWORD_USER4));
}

bool MVP::Model::login(const std::string &user,const  std::string &password) {
    std::map<std::string, std::string>::iterator it;
    it = usersAndPasswords.find(user);
    if(it != usersAndPasswords.end()) {
        if(it->second == password) {
            return true;
        }
    }
    return false;
}
