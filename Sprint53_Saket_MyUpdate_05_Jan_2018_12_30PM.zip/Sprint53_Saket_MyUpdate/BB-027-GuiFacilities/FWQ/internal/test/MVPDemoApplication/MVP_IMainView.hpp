//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class IMainView.
// !\description Header file for class IMainView.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef MVPIVIEW_HPP
#define MVPIVIEW_HPP

#include <string>
#include <list>
namespace MVP {

class IMainView
{
public:
    virtual void showMessage(const bool &result)=0;
};
} //namespace MVP
#endif // MVPIVIEW_HPP
