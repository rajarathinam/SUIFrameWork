//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for Application.
// !\description Class implementation file for Application
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "MVP_Application.hpp"

#include <FWQxCore/SUIResourcePath.h>
#include "MVP_MainView.hpp"

MVP::Application::Application(int argc, char *argv[], const std::string &resourcepath) :
    m_argc(argc),
    m_argv(argv),
    m_resourcepath(resourcepath)
{
    m_app = SUI::Application::createApplication(m_argc, m_argv);
    SUI::ResourcePath::getInstance()->setResourcePath(m_resourcepath);

    m_mainview = new MVP::MainView;
    m_mainview->show();
}

MVP::Application::~Application() {
    delete m_mainview;
    m_mainview = NULL;
}

int MVP::Application::exec() {
    int result = m_app->exec();
    return result;
}
