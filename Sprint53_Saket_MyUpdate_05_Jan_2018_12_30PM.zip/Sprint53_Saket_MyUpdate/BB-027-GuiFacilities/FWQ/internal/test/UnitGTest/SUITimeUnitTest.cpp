
#include <gtest.h>
#include "FWQxUtils/SUITime.h"

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class SUITimeUnitTest : public ::testing::Test
{
 public:
    SUITimeUnitTest() : TimeInstance(SUI::Time::createTime()){
    }
    ~SUITimeUnitTest(){ }

protected:
     boost::shared_ptr<SUI::Time> TimeInstance;

};

TEST_F(SUITimeUnitTest, VerifyGettersAndSetters)
{
    const int hours = 5, minutes = 30, seconds = 50, mseconds = 100;
    TimeInstance->setHMS(hours, minutes, seconds, mseconds);
    EXPECT_EQ(TimeInstance->getHour(), hours);
    EXPECT_EQ(TimeInstance->getMinute(), minutes);
    EXPECT_EQ(TimeInstance->getSecond(), seconds);
    EXPECT_EQ(TimeInstance->getMsec(), mseconds);
}

TEST_F(SUITimeUnitTest, VerifyValidTimes)
{
    TimeInstance->setHMS(0, 0, 0);
    TimeInstance->setHMS(1, 2, 3);
    TimeInstance->setHMS(0, 59, 0);
    TimeInstance->setHMS(0, 59, 59);
    TimeInstance->setHMS(23, 0, 0);
    TimeInstance->setHMS(23, 59, 0);
    TimeInstance->setHMS(23, 59, 59);

    EXPECT_EQ(TimeInstance->getHour(), 23);
    EXPECT_EQ(TimeInstance->getMinute(), 59);
    EXPECT_EQ(TimeInstance->getSecond(), 59);
}
