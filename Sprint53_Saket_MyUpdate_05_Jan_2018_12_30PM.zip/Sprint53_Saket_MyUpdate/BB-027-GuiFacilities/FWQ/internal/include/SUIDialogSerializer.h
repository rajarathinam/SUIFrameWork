//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::DialogSerializer.
// !\description Header file for class SUI::DialogSerializer.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIDIALOGSERIALIZER_H
#define SUIDIALOGSERIALIZER_H

#include "FWQxCore/SUISharedExport.h"

#include "SUIGUIDefinitionVisitor.h"

#include <QString>
#include <QXmlStreamWriter>
#include <QFile>

namespace SUI {
class DialogSerializer: public GUIDefinitionVisitor
{
public:
    typedef enum
    {
        Read,
        Write
    } rticGuiSerializerMode;

    DialogSerializer(const QString startElement, rticGuiSerializerMode mode);
    virtual ~DialogSerializer();

    void openFile(const QString &filename);
    void closeFile();
    virtual void writeWidgetProperty(SUI::ObjectPropertyTypeEnum::Type key, const QString &value);
    virtual void writeInclude(const QString &include, const QString &fileName);

    virtual GUIDefinitionVisitor &openChildWidget();
    virtual void closeChildWidget();
    void acceptVisitor(GUIDefinitionVisitor &visitor);
    void recursiveAcceptVisitor(GUIDefinitionVisitor &visitor);
    int getWidgetCount() const;

    void isEndElement(bool ready, GUIDefinitionVisitor &visitor);
    void isAttributeWidget(GUIDefinitionVisitor &visitor);
    void readerIsEndElement(GUIDefinitionVisitor &visitor, bool &ready);
private:
    QXmlStreamWriter *mXmlWriter;
    QXmlStreamReader *mXmlReader;
    QFile *mFile;
    rticGuiSerializerMode mMode;
    QString mStartElement;
    int mWidgetCount;
};
}
#endif // SUIGUISERIALIZER_H
