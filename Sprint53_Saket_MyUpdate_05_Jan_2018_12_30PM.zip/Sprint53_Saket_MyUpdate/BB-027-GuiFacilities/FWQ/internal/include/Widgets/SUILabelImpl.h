//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::LabelImpl.
// !\description Header file for class SUI::LabelImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUILABELIMPL_H
#define SUILABELIMPL_H

#include "CustomLabel.h"

#include "SUIBaseWidget.h"
#include "FWQxWidgets/SUILabel.h"

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The Label class
 */
class LabelImpl: public BaseWidget, public Label
{
    Q_OBJECT
public:
    explicit LabelImpl(QWidget *parent = NULL);

    virtual void setDefaultProperties(const ObjectContext &context);
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

    virtual CustomLabel *getWidget() const;

    virtual void setText(const std::string &value);
    virtual std::string getText() const;
    virtual void clearText();
    virtual void setBold(bool bold);
    virtual bool isBold() const;

    virtual SUI::ColorEnum::Color getColor() const;
    virtual void setColor(const SUI::ColorEnum::Color color);

    virtual SUI::ColorEnum::Color getBGColor() const;
    virtual void setBGColor(const SUI::ColorEnum::Color color);

    virtual void setAlignment(AlignmentEnum::Alignment align);
    virtual AlignmentEnum::Alignment getAlignment() const;

    virtual void setFontSize(const FontSizeEnum::FontSize &fontSize);
    virtual FontSizeEnum::FontSize getFontSize() const;

    void setPropScientific();

    virtual void setHighlightText(const std::string &searchText,const std::string &color);
    virtual std::string getHighlightText() const;

protected:
    virtual bool eventFilter(QObject *obj, QEvent *event);

private:
    QString mHighLightText;

    LabelImpl(const LabelImpl &rhs);
    LabelImpl &operator=(const LabelImpl &rhs);
};
}

#endif // SUILABELIMPL_H
