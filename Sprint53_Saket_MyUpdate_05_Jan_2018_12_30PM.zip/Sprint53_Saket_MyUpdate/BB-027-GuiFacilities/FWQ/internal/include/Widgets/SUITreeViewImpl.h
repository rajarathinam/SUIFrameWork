//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::TreeViewHeader.
// !\description Header file for class SUI::TreeViewHeader.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUITREEVIEWIMPL_H
#define SUITREEVIEWIMPL_H

#include <QStandardItemModel>
#include <QHeaderView>
#include <QPushButton>
#include <QTreeView>

#include "FWQxCore/SUIObjectFactory.h"
#include "FWQxCore/SUIObjectList.h"

#include "SUIBaseWidget.h"
#include "SUITreeViewItemImpl.h"

#include "FWQxWidgets/SUITreeView.h"

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The TreeViewHeader class
 */
class TreeViewHeader : public QHeaderView
{
    Q_OBJECT

public:
    explicit TreeViewHeader(QWidget* parent) :
        QHeaderView(Qt::Horizontal, parent)
    {
        m_collapseButton = new QPushButton("-", this);
        m_expandButton = new QPushButton("+", this);
        connect(m_collapseButton, SIGNAL(clicked()), this, SLOT(onCollapseClicked()));
        connect(m_expandButton, SIGNAL(clicked()), this, SLOT(onExpandClicked()));

        this->setStretchLastSection(true);
    }

    void setWidth(int width)
    {
        m_collapseButton->setGeometry(width - 30, 0, 20, 20);
        m_expandButton->setGeometry(width - 55, 0, 20, 20);
    }

private slots:
    void onCollapseClicked()
    {
        emit collapseClicked();
    }

    void onExpandClicked()
    {
        emit expandClicked();
    }

signals:
    void collapseClicked();
    void expandClicked();

private:
    QPushButton* m_collapseButton;
    QPushButton* m_expandButton;

};

/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 *
 * \brief The TreeView class
 */
class TreeViewImpl: public BaseWidget, public TreeView
{
    Q_OBJECT

public:
    explicit TreeViewImpl(QWidget *parent = NULL, SUI::ObjectList *widgetList = NULL);
    virtual ~TreeViewImpl();

    virtual void setDefaultProperties(const ObjectContext &context);
    virtual QTreeView *getWidget() const;

    virtual void setText(const std::string &value);
    virtual std::string getText() const;
    virtual void clearText();
    virtual void setBold(bool bold);
    virtual bool isBold() const;

    virtual void setTitle(const std::string &title);
    virtual std::string getTitle() const;

    virtual void addItems(const std::list<std::string> &itemlist);
    virtual void addTreeItem(const std::string &text, std::string &newID , const std::string &parentID);
    virtual void removeItems(const std::list<std::string> &widgetId);
    virtual bool isLeafNode(const std::string &itemID);
    virtual void sort(SortOrderEnum::SortOrder order = SortOrderEnum::Unsorted);
    virtual void clearItems();

    QString addNewTreeItem(TreeViewItemImpl *item);
    QString addNewTreeItemToItem(TreeViewItemImpl *item, QString parent);
    void appendRow(QString text, QString parentID, QString currentID);
    void renameItem(QString oldID, QString newID);
    void updateText(QString oldID, QString newID);
    void selectRow(QString widgetID);
    QStandardItem *getStandardItem(const QString &itemID);

    virtual void disableHeader(bool disableHeader);
    virtual std::list<std::string> getItems() const;
    virtual std::list<std::string> getSelectedItems() const;
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);
    virtual void selectItem(const int row, const int col = 0);
    virtual void selectItem(const std::string idstr);

public slots:
    void onCollapseClicked();
    void onExpandClicked();

private slots:
    void handleSelectionChanged();

private:
    QStandardItemModel *mStandardModel;
    QStandardItem *mCurrentItem;
    QMap<QString, QStandardItem*> mMap;

    SUI::ObjectList *mWidgetList;
    SortOrderEnum::SortOrder mSortOrder;
    TreeViewHeader *mHeader;

    TreeViewImpl(const TreeViewImpl &rhs);
    TreeViewImpl &operator=(const TreeViewImpl &rhs);

};
}

#endif // SUITREEVIEWIMPL_H
