//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::GraphicsViewImpl.
// !\description Header file for class SUI::GraphicsViewImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUIGRAPHICSVIEWIMPL_H
#define SUIGRAPHICSVIEWIMPL_H

#include "SUIBaseWidget.h"
#include "FWQxWidgets/SUIGraphicsView.h"

#include "CustomGraphicsView.h"

#include "FWQxCore/SUIImageEnum.h"

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The GraphicsViewImpl class
 */
class GraphicsViewImpl : public BaseWidget, public GraphicsView
{
    Q_OBJECT

public:
    explicit GraphicsViewImpl(QWidget *parent = NULL);
    virtual ~GraphicsViewImpl();

    virtual CustomGraphicsView *getWidget() const;

    virtual void setDefaultProperties(const ObjectContext &context);

    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);
    
    int getBorderWidth() const;

protected:
    virtual void setGeometry();

private slots:
    void onVisibilityChanged(bool isDisplayed);

private:
    GraphicsViewImpl();
    GraphicsViewImpl(const GraphicsViewImpl &rhs);
    GraphicsViewImpl &operator=(const GraphicsViewImpl &rhs);
};
}

#endif // SUIGRAPHICSVIEWIMPL_H
