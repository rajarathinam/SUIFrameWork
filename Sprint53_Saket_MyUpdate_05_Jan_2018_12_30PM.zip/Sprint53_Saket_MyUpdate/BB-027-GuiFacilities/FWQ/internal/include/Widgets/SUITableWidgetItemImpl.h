//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::TableWidgetItemImpl.
// !\description Header file for class SUI::TableWidgetItemImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUITABLEWIDGETITEMIMPL_H
#define SUITABLEWIDGETITEMIMPL_H

#include <QTableWidgetItem>

#include "SUIBaseWidget.h"
#include "FWQxWidgets/SUITableWidgetItem.h"

#include <QFrame>

namespace SUI {

/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The TableWidgetItem class
 */
class TableWidgetItemImpl : public BaseWidget, public QTableWidgetItem, public TableWidgetItem
{
    Q_OBJECT
public:
    explicit TableWidgetItemImpl(QWidget *parent);

    virtual void setDefaultProperties(const ObjectContext &context);
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

    virtual void setText(const std::string &value);
    virtual std::string getText() const;
    virtual void clearText();
    virtual void setBold(bool bold);
    virtual bool isBold() const;

    virtual void setFontSize(const FontSizeEnum::FontSize &fontSize);
    virtual FontSizeEnum::FontSize getFontSize() const;

    virtual QFrame *getWidget() const;

    virtual void setAlignment(AlignmentEnum::Alignment align);
    virtual SUI::AlignmentEnum::Alignment getAlignment() const;
    virtual SUI::ColorEnum::Color getColor() const;
    virtual void setColor(const SUI::ColorEnum::Color color);

private:
    TableWidgetItemImpl(const TableWidgetItemImpl &rhs);
    TableWidgetItemImpl &operator=(const TableWidgetItemImpl &rhs);
};
}

#endif // SUITABLEWIDGETITEMIMPL_H
