//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::LineWidgetImpl.
// !\description Header file for class SUI::LineWidgetImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUILINEWIDGETIMPL_H
#define SUILINEWIDGETIMPL_H

#include "SUIBaseWidget.h"
#include "FWQxWidgets/SUILineWidget.h"

#include <QFrame>

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The LineWidget class
 */
class LineWidgetImpl : public BaseWidget, public LineWidget
{
    Q_OBJECT

public:
    explicit LineWidgetImpl(QWidget *parent = NULL);

    virtual void setDefaultProperties(const ObjectContext &context);
    virtual QFrame *getWidget() const;

private:
    LineWidgetImpl(const LineWidgetImpl &rhs);
    LineWidgetImpl &operator=(const LineWidgetImpl &rhs);
};
}

#endif // SUILINEWIDGETIMPL_H
