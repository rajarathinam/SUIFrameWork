//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::TimerImpl.
// !\description Header file for class SUI::TimerImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUITIMERIMPL_H
#define SUITIMERIMPL_H

#include "FWQxUtils/SUITimer.h"

#include <QTimer>

namespace SUI {

class TimerImpl : public QTimer, public SUI::Timer
{

    Q_OBJECT

private:
    explicit TimerImpl(QObject *parent = 0);

    friend class Timer;

public:
    virtual bool isActive() const;

    virtual bool isSingleShot() const;
    virtual void setSingleShot(bool singleShot);

    virtual int interval() const;
    virtual void setInterval(int msec);

    virtual int getTimerId() const;

    virtual void start(int msec);
    virtual void start();
    virtual void stop();

private slots:
    void onTimeout();

};

} // namespace SUI

#endif // SUI_SUITIMERIMPL_H
