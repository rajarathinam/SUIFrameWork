//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::BaseObject.
// !\description Header file for class SUI::BaseObject.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIBASEOBJECT_H
#define SUIBASEOBJECT_H

#include "SUIObjectProperties.h"
#include "FWQxCore/SUIObjectType.h"

namespace SUI {

class BaseObject : public ObjectProperties
{
public:   
    typedef enum
    {
        EditorSelector,
        EditorForm,
        Gui
    } ObjectContext;

    BaseObject(const ObjectContext &objectContext_t, const ObjectType::Type &objectType_t, bool supportsChildren);

    virtual void setDefaultProperties(const ObjectContext &context);

    void setId(const std::string &id);
    std::string getId() const;

    virtual void setVisible(bool visible) = 0;
    virtual bool isVisible() const;

    virtual std::string getToolTip() const = 0;
    virtual void setToolTip(const std::string &toolTip) = 0;

    bool isToolTipEnabled() const;
    void setToolTipEnabled(bool enabled);

    ObjectType::Type getObjectType() const;
    
    ObjectContext getObjectContext() const;
    void setObjectContext(const ObjectContext &context);

    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

private:
    const ObjectType::Type objectType;
    
    ObjectContext objectContext;

    bool toolTipEnabled;
};

} // namespace SUI

#endif // SUI_BASEOBJECT_H
