//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class CustomScienceSpinBox.
// !\description Header file for class CustomScienceSpinBox.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef CUSTOMSCIENCESPINBOX_H
#define CUSTOMSCIENCESPINBOX_H

#include <QDoubleSpinBox>
#include <QDoubleValidator>
#include <QLineEdit>
#include <QVariant>
#include <QDebug>
#include <QString>

#include "CustomDoubleSpinBox.h"


class CustomScienceSpinBox : public CustomDoubleSpinBox
{
    Q_OBJECT
public:
    explicit CustomScienceSpinBox(QWidget *parent = 0);

    double  decimals() const;
    void    setDecimals(double value);
    virtual QString textFromValue(double value) const;
    virtual double  valueFromText(const QString &text) const;

private:
    int mDispDecimals;
    QChar mDelimiter;
    QChar mThousand;
    QDoubleValidator *mDblVal;

    void initLocalValues(QWidget *parent);
    bool isIntermediateValue(const QString &str) const;
    QVariant validateAndInterpret(QString &input, int &pos, QValidator::State &state) const;
    virtual QValidator::State validate(QString &text, int &pos) const;
    virtual void  fixup(QString &input) const;
    QString stripped(const QString &t, int *pos) const;

    static bool isIntermediateValueHelper(qint64 num, qint64 minimum, qint64 maximum, qint64 *match = 0);

    CustomScienceSpinBox();
    CustomScienceSpinBox(const CustomScienceSpinBox &rhs);
    CustomScienceSpinBox  &operator=(const CustomScienceSpinBox &rhs);
};

#endif // CUSTOMSCIENCESPINBOX_H
