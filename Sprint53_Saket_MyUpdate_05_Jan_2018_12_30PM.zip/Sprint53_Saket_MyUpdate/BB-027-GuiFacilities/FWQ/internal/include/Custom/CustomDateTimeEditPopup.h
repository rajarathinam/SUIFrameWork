//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class CustomDateTimeEditPopup.
// !\description Header file for class CustomDateTimeEditPopup.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef CUSTOMDATETIMEEDITPOPUP_H
#define CUSTOMDATETIMEEDITPOPUP_H

#include <QWidget>

class QCalendarWidget;
class QPushButton;
class QLabel;
class QDate;
class QTime;

class CustomDateTimeEditPopup : public QWidget
{
    Q_OBJECT
public:
    explicit CustomDateTimeEditPopup(QWidget *parent = NULL);
    virtual ~CustomDateTimeEditPopup();

    void setDate(const QDate &date);
    void setTime(const QTime &time);

signals:
    void newDateTimeSelected(const QDate &newDate, const QTime &newTime);

private slots:
    void okClicked();
    void cancelClicked();
    void upHourClicked();
    void upMinClicked();
    void downHourClicked();
    void downMinClicked();

private:
    QCalendarWidget *mCalendar;
    QPushButton *mUpHourButton;
    QPushButton *mUpMinButton;
    QPushButton *mDownHourButton;
    QPushButton *mDownMinButton;
    QPushButton *mOkButton;
    QPushButton *mCancelButton;
    QLabel *mHourLabel;
    QLabel *mMinLabel;
    QLabel *mColonLabel;
};

#endif // CUSTOMDATETIMEEDITPOPUP_H
