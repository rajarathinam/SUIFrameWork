//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::SpinBoxImpl.
// !\description Class implementation file for SUI::SpinBoxImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUISpinBoxImpl.h"

#include <QStyle>

SUI::SpinBoxImpl::SpinBoxImpl(QWidget *parent) :
    BaseWidget(new CustomSpinBox(parent), SUI::ObjectType::SpinBox, false)
{
    connect(getWidget(), SIGNAL(valueChanged(int)), this, SLOT(handleValueChanged()));

    exposeWidthProperty();
}

void SUI::SpinBoxImpl::handleValueChanged() {
    if (!valueChanged.empty()) valueChanged();
}

void SUI::SpinBoxImpl::setDefaultProperties(const SUI::BaseObject::ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);

    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "30");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "200");
    setPropertyValues(ObjectPropertyTypeEnum::StepSize, QString("1:%1").arg(INT_MAX));
    setPropertyValues(ObjectPropertyTypeEnum::MinValue, QString("%1:%2").arg(INT_MIN).arg(INT_MAX));
    setPropertyValues(ObjectPropertyTypeEnum::MaxValue, QString("%1:%2").arg(INT_MIN).arg(INT_MAX));
    setPropertyValue(ObjectPropertyTypeEnum::StepSize, "1");
    setPropertyValue(ObjectPropertyTypeEnum::MinValue, "0");
    setPropertyValue(ObjectPropertyTypeEnum::MaxValue, "500");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, "0");

    switch (context)
    {
    case EditorSelector:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, QString::fromStdString(SUI::ObjectType::toString(Object::getObjectType())));
        break;

    case EditorForm:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, "0");
        break;

    default:
        break;
    }
}

CustomSpinBox *SUI::SpinBoxImpl::getWidget() const {
    return dynamic_cast<CustomSpinBox *>(BaseWidget::getWidget());
}

void SUI::SpinBoxImpl::setStepSizeValueToFactor(const bool on) {
    getWidget()->setStepSizeValueToFactor(on);
}

int SUI::SpinBoxImpl::getValue() const {
    return  getWidget()->value();
}

void SUI::SpinBoxImpl::setValue(const int val) {
    getWidget()->setValue(val);
}

void SUI::SpinBoxImpl::setMinValue(const int val) {
    getWidget()->setMinimum(val);
}

int SUI::SpinBoxImpl::getMinValue() const {
    return getWidget()->minimum();
}

void SUI::SpinBoxImpl::setMaxValue(const int val) {
    getWidget()->setMaximum(val);
}

int SUI::SpinBoxImpl::getMaxValue() const {
    return getWidget()->maximum();
}

void SUI::SpinBoxImpl::setStepSize(const int val) {
    getWidget()->setSingleStep(val);
}

int SUI::SpinBoxImpl::getStepSize() const {
    return getWidget()->singleStep();
}

void SUI::SpinBoxImpl::setBold(bool bold) {
    getWidget()->setProperty("SUIFont", QVariant::fromValue<QString>(bold ? "bold" : ""));
    getWidget()->style()->polish( getWidget());
}

void SUI::SpinBoxImpl::setMode(ErrorModeEnum::ErrorMode mode) {
    mCurrentMode = mode;
    if (mode == ErrorModeEnum::Error) {
        getWidget()->setProperty("BGColorSet", "error");
    }
    else {
        getWidget()->setProperty("BGColorSet", "");
    }
    getWidget()->style()->polish(getWidget());
}

void SUI::SpinBoxImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID, propertyValue);

    switch (propertyID) {
    case SUI::ObjectPropertyTypeEnum::StepSize:
        setStepSize(propertyValue.toInt());
        break;

    case SUI::ObjectPropertyTypeEnum::MaxValue:
        setMaxValue(propertyValue.toInt());
        break;

    case SUI::ObjectPropertyTypeEnum::MinValue:
        setMinValue(propertyValue.toInt());
        break;

    case SUI::ObjectPropertyTypeEnum::Precision:
        setPrecision(propertyValue.toInt());
        break;

    case SUI::ObjectPropertyTypeEnum::StepsizeToFactor:
        getWidget()->setStepSizeValueToFactor(propertyValue.toLower() == "true");
        break;

    case SUI::ObjectPropertyTypeEnum::Alignment:
        if (propertyValue.toLower() == "right") {
            setAlignment(AlignmentEnum::Right);
        }
        else if (propertyValue.toLower() == "center") {
            setAlignment(AlignmentEnum::HCenter);
        }
        else {
            setAlignment(AlignmentEnum::Left);
        }
        break;

    case SUI::ObjectPropertyTypeEnum::Bold:
        setBold((propertyValue.compare("true", Qt::CaseInsensitive) == 0));
        break;

    case SUI::ObjectPropertyTypeEnum::Text:
    {
        bool ok = false;
        int result = propertyValue.toInt(&ok);
        if (ok) getWidget()->setValue(result);
        break;
    }
    default:
        break;
    }
}

QString SUI::SpinBoxImpl::getPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID) const {
    QString propertyValue = BaseWidget::getPropertyValue(propertyID);
    if (propertyID == SUI::ObjectPropertyTypeEnum::StepsizeToFactor) {
         getWidget()->setStepSizeValueToFactor((propertyValue.toUpper() == "TRUE") ? true : false);
    }
    return propertyValue;
}

void SUI::SpinBoxImpl::setAlignment(AlignmentEnum::Alignment align) {
    Qt::Alignment   qtAlign;
    switch (align)
    {
    case AlignmentEnum::Right:
        qtAlign = Qt::AlignRight;
        break;
    case AlignmentEnum::Left:
        qtAlign = Qt::AlignLeft;
        break;
    default:
        qtAlign = Qt::AlignCenter;
        break;
    }

    getWidget()->setAlignment(qtAlign);
}

SUI::AlignmentEnum::Alignment SUI::SpinBoxImpl::getAlignment() const {
    switch (getWidget()->alignment())
    {
    case Qt::AlignRight: return SUI::AlignmentEnum::Right;
    case Qt::AlignLeft: return SUI::AlignmentEnum::Left;
    default: return SUI::AlignmentEnum::HCenter;
    }
    return SUI::AlignmentEnum::HCenter;
}
