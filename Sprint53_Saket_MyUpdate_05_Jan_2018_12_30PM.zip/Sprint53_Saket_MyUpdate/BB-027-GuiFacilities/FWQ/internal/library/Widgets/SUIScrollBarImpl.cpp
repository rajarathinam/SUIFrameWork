//-----------------------------------------------------------------------------|
//                                                                             |
//                            C++ Source File                                  |
//                                                                             |
//-----------------------------------------------------------------------------|
//
// Ident        : SUIScrollBarImpl.cpp
// Author       :
// Description  : Class implementation file for SUI::ScrollBarImpl.
//
// ! \file        SUIScrollBarImpl.cpp
// ! \brief       Class implementation file for SUI::ScrollBarImpl.
//
//-----------------------------------------------------------------------------|
//                                                                             |
//        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
//                           All rights reserved                               |
//                                                                             |
//-----------------------------------------------------------------------------|

#include "SUIScrollBarImpl.h"

#include <QEvent>
#include <QPoint>
#include <QMouseEvent>
#include <QToolTip>
#include <QtGlobal>
#include <boost/foreach.hpp>

SUI::ScrollBarImpl::ScrollBarImpl(QWidget *parent) :
    BaseWidget(new QScrollBar(parent), SUI::ObjectType::ScrollBar, false),
    mOrientation(OrientationEnum::Horizontal),
    mCreateDefaultTooltip(true),
    mDragging(false)
{
    exposeWidthProperty();
    exposeHeightProperty();
    ScrollBarImpl::getWidget()->setMinimum(getPropertyValue(SUI::ObjectPropertyTypeEnum::MinValue).toInt());
    ScrollBarImpl::getWidget()->setMaximum(getPropertyValue(SUI::ObjectPropertyTypeEnum::MaxValue).toInt());

    connect(ScrollBarImpl::getWidget(), SIGNAL(valueChanged(int)), this, SLOT(onValueChanged()));
    connect(ScrollBarImpl::getWidget(), SIGNAL(sliderPressed()), this, SLOT(onSliderPressed()));
    connect(ScrollBarImpl::getWidget(), SIGNAL(sliderReleased()), this, SLOT(onSliderReleased()));
}

SUI::ScrollBarImpl::~ScrollBarImpl()
{
}

void SUI::ScrollBarImpl::onValueChanged()
{
    updateTooltip();
    if (!valueChanged.empty())
    {
        valueChanged();
    }
}

void SUI::ScrollBarImpl::onSliderPressed()
{
    mDragging = true;
    getWidget()->setCursor(Qt::PointingHandCursor);
}

void SUI::ScrollBarImpl::onSliderReleased()
{
    mDragging = false;
    getWidget()->setCursor(Qt::ArrowCursor);
}

void SUI::ScrollBarImpl::setDefaultProperties(const ObjectContext &context)
{
    BaseWidget::setDefaultProperties(context);
    // default values
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height,"20");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "150");

    QStringList orientationList;
    BOOST_FOREACH(auto str, SUI::OrientationEnum::getOrientationStringList()) {
        orientationList.append(QString::fromStdString(str));
    }
    setPropertyValues(SUI::ObjectPropertyTypeEnum::Orientation, orientationList.join(";"));
    setPropertyValue(ObjectPropertyTypeEnum::Orientation,QString::fromStdString(SUI::OrientationEnum::toString(SUI::OrientationEnum::Horizontal)));
    setOrientation(OrientationEnum::Horizontal);

    // set applicable INumeric values
    setPropertyValues(ObjectPropertyTypeEnum::StepSize, QString("1:%1").arg(INT_MAX));
    setPropertyValues(ObjectPropertyTypeEnum::MinValue, QString("%1:%2").arg(INT_MIN).arg(INT_MAX));
    setPropertyValues(ObjectPropertyTypeEnum::MaxValue, QString("%1:%2").arg(INT_MIN).arg(INT_MAX));

    setPropertyValue(ObjectPropertyTypeEnum::StepSize, "1");
    setPropertyValue(ObjectPropertyTypeEnum::MinValue, "0");
    setPropertyValue(ObjectPropertyTypeEnum::MaxValue, "95");
    setPageStep(5);

    switch (context)
    {
        case EditorSelector:
            break;

        case EditorForm:
            setPageStep(qMax((getMaxValue()- getMinValue()) / 20, 1));
            setValue(getMinValue() + ((getMaxValue() - getMinValue()) / 2));
            break;

        default:
            break;
    }
}

QScrollBar* SUI::ScrollBarImpl::getWidget() const
{
    return qobject_cast<QScrollBar *>(BaseWidget::getWidget());
}

SUI::OrientationEnum::Orientation SUI::ScrollBarImpl::getOrientation() const
{
    return mOrientation;
}

void SUI::ScrollBarImpl::setOrientation(OrientationEnum::Orientation orientation)
{
    mOrientation = orientation;
    switch (orientation)
    {
    case OrientationEnum::Vertical:
        getWidget()->setOrientation(Qt::Vertical);
        getWidget()->setProperty("Orientation", "Vertical");
        break;
    case OrientationEnum::Horizontal:
        getWidget()->setOrientation(Qt::Horizontal);
        getWidget()->setProperty("Orientation", "Horizontal");
        break;
    default:
        break;
    }
}

int SUI::ScrollBarImpl::getValue() const
{
    return getWidget()->value();
}

void SUI::ScrollBarImpl::setValue(const int thumbPosition)
{
    getWidget()->setValue(thumbPosition);
    updateTooltip();
}

void SUI::ScrollBarImpl::setMinValue(const int val)
{
    getWidget()->setMinimum(val);
}

int SUI::ScrollBarImpl::getMinValue() const
{
    return getWidget()->minimum();
}

void SUI::ScrollBarImpl::setMaxValue(const int val)
{
    getWidget()->setMaximum(val);
}

int SUI::ScrollBarImpl::getMaxValue() const
{
    return getWidget()->maximum();
}

void SUI::ScrollBarImpl::setStepSizeValueToFactor(const bool /*on*/)
{
    // explicitly ignored
}

void SUI::ScrollBarImpl::setStepSize(const int val)
{
    getWidget()->setSingleStep(val);
}

int SUI::ScrollBarImpl::getStepSize() const
{
    return getWidget()->singleStep();
}

void SUI::ScrollBarImpl::setPageStep(const int val)
{
    getWidget()->setPageStep(val);
    updateTooltip();
}

int SUI::ScrollBarImpl::getPageStep() const
{
    return getWidget()->pageStep();
}

void SUI::ScrollBarImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue)
{
    BaseWidget::setPropertyValue(propertyID, propertyValue);

    switch (propertyID) {

    case SUI::ObjectPropertyTypeEnum::Orientation:
        setOrientation(propertyValue == "Vertical" ? OrientationEnum::Vertical : OrientationEnum::Horizontal);
        break;

    case SUI::ObjectPropertyTypeEnum::MinValue:
        setMinValue(propertyValue.toInt());
        break;

    case SUI::ObjectPropertyTypeEnum::MaxValue:
        setMaxValue(propertyValue.toInt());
        break;

    case SUI::ObjectPropertyTypeEnum::StepSize:
        setStepSize(propertyValue.toInt());
        break;

    case SUI::ObjectPropertyTypeEnum::ToolTip:
        mCreateDefaultTooltip = propertyValue.isEmpty();
        break;

    default:
        break;
    }
}

bool SUI::ScrollBarImpl::eventFilter(QObject *obj, QEvent *event)
{
    if (mDragging && event->type() == QEvent::MouseMove && isToolTipEnabled())
    {
        QMouseEvent* mouseEvent = static_cast<QMouseEvent*>(event);
        QPoint toolTipPos = mouseEvent->globalPos() + QPoint(5, 5);
        if (getWidget()->orientation() == Qt::Vertical)
        {
            toolTipPos -= QPoint(mouseEvent->pos().x(), 0);
        }
        else
        {
            toolTipPos -= QPoint(0, mouseEvent->pos().y());
        }

        QToolTip::showText(toolTipPos, getDefaultTooltip(), getWidget());
    }
    return BaseWidget::eventFilter(obj, event);
}

void SUI::ScrollBarImpl::updateTooltip()
{
    if (isToolTipEnabled() && mCreateDefaultTooltip)
    {
        // only create a tooltip if the original design did NOT have a tooltip and has tooltips turned on
        // this tooltip will only be shown if EnableToolTips(true) has been invoked
        getWidget()->setToolTip(getWidget()->isEnabled() ? getDefaultTooltip() : "");
    }
}

QString SUI::ScrollBarImpl::getDefaultTooltip() const
{
    return QString("%1 ... %2").arg(getWidget()->value()).arg(getWidget()->value() + getWidget()->pageStep());
}

