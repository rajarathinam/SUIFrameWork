//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::ControlWidgetImpl.
// !\description Class implementation file for SUI::ControlWidgetImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUIControlWidgetImpl.h"
#include <boost/foreach.hpp>

SUI::ControlWidgetImpl::ControlWidgetImpl(QWidget *parent) :
    BaseWidget(new QLabel(parent), SUI::ObjectType::ControlWidget, false)
{
    //Fill ControlTypeList
    ControlProperties::getTypeMap().insert("ValveU", ValveU);
    ControlProperties::getTypeMap().insert("ValveR", ValveR);
    ControlProperties::getTypeMap().insert("ValveL", ValveL);

    //Fill ControlStateList
    ControlProperties::getStateMap().insert("Opened",  Opened);
    ControlProperties::getStateMap().insert("Closed", Closed);
    ControlProperties::getStateMap().insert("Faulted", Faulted);
    ControlProperties::getStateMap().insert("Unknown", Unknown);
}

QLabel *SUI::ControlWidgetImpl::getWidget() const {
    return dynamic_cast<QLabel *>(BaseWidget::getWidget());
}

void SUI::ControlWidgetImpl::setDefaultProperties(const SUI::BaseObject::ObjectContext &context) {
    setPropertyValues(SUI::ObjectPropertyTypeEnum::ControlType, getTypesString());
    setPropertyValue(SUI::ObjectPropertyTypeEnum::ControlType, "ValveU");
    mType = "ValveU";
    setPropertyValues(SUI::ObjectPropertyTypeEnum::ControlState, getStatesString());
    setPropertyValue(SUI::ObjectPropertyTypeEnum::ControlState, "Closed");
    mState = "Closed";
    setImage();
    BaseWidget::setDefaultProperties(context);
}

std::string SUI::ControlWidgetImpl::getType() const
{
    return getPropertyValue(SUI::ObjectPropertyTypeEnum::ControlType).toStdString();
}

void SUI::ControlWidgetImpl::setImage() //on property changes
{
    QImage img;
    QString file = ":/controls/Controls/" ;
    file.append(mType);
    file.append(mState);
    file.append(".png");
    img.load(file);
    QString s;
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, s.setNum(img.height()));
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, s.setNum(img.width()));

    getWidget()->setPixmap(QPixmap::fromImage(img));
}

void SUI::ControlWidgetImpl::setType(const std::string &type)
{
    QString typeStr = QString::fromStdString(type);
    if (ControlProperties::getTypeMap().contains(typeStr)) {
        if (getProperty(SUI::ObjectPropertyTypeEnum::ControlType)->getValue() != typeStr) {
            setPropertyValue(SUI::ObjectPropertyTypeEnum::ControlType, typeStr);
        }
        mType = typeStr;
        setImage();
    }
}

std::string SUI::ControlWidgetImpl::getState() const {
    return mState.toStdString();
}

void SUI::ControlWidgetImpl::setState(const std::string &state) {
    QString stateStr = QString::fromStdString(state);
    if (ControlProperties::getStateMap().contains(stateStr)) {
        if (getProperty(SUI::ObjectPropertyTypeEnum::ControlState)->getValue() != stateStr) {
            setPropertyValue(SUI::ObjectPropertyTypeEnum::ControlState, stateStr);
        }
        mState = stateStr;
        setImage();
    }
}

std::list<std::string> SUI::ControlWidgetImpl::getSupportedStates() const {
    std::list<std::string> result;
    QStringList stateList = getStatesString().split(";");
    BOOST_FOREACH (const QString &str, stateList) {
        result.push_back(str.toStdString());
    }
    return result;
}

void SUI::ControlWidgetImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    SUI::BaseWidget::setPropertyValue(propertyID,propertyValue);
    switch (propertyID) {
    case SUI::ObjectPropertyTypeEnum::ControlState:
        setState(propertyValue.toStdString());
        break;
    case SUI::ObjectPropertyTypeEnum::ControlType:
        setType(propertyValue.toStdString());
        break;
    default:
        break;
    }
}

void SUI::ControlWidgetImpl::onCustomContextMenuRequest(QPoint point) {
    QString Result = BaseWidget::getContextMenuSelectedActionString(point);
    setState(Result.toStdString());
}
