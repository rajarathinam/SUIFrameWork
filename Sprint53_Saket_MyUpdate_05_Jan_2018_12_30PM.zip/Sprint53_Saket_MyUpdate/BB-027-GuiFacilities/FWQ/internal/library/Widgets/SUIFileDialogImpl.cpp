//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::FileDialogImpl.
// !\description Class implementation file for SUI::FileDialogImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


/* issue: Implement a file browser dialog
 *
 * Actual implementation needs to catch a function call wich returns a directory, filename or
 * multiple filenames in a ';' seperated string. A hidden widget is created to handle a specific
 * function call from the FAT:
 * string showFileBrowser(string title, string message, string filters, enum Mode)
 */

#include "CustomFileDialog.h"

#include "SUIFileDialogImpl.h"
#include "SUIStyleSheet.h"

#include <QDir>
#include <QMessageBox>
#include <QApplication>
#include <QDesktopWidget>

SUI::FileDialogImpl::FileDialogImpl(QWidget *parent):
    BaseWidget(new CustomFileDialog(parent), SUI::ObjectType::FileDialog, false),
    FileDialog(),
    mMode(0)
{
    exposeWidthProperty();
    exposeHeightProperty();

    FileDialogImpl::getWidget()->setModal(true);
    FileDialogImpl::getWidget()->setFileMode(QFileDialog::ExistingFiles);
    FileDialogImpl::getWidget()->setAcceptMode(QFileDialog::AcceptOpen);
    FileDialogImpl::getWidget()->setMinimumSize(640,480);
    QRect screenRect = QApplication::desktop()->screenGeometry();
    FileDialogImpl::getWidget()->move(screenRect.center() - FileDialogImpl::getWidget()->rect().center());

    connect(FileDialogImpl::getWidget(), SIGNAL(finished(int)), this, SLOT(onClicked(int)));
    connect(FileDialogImpl::getWidget(),SIGNAL(directoryEntered(QString)),this,SLOT(onDirectoryEntered(QString)));
    initialize();
}

void SUI::FileDialogImpl::initialize() {
    centerWidget();
    mRootDir = QString("/");
    getWidget()->update();
}

void SUI::FileDialogImpl::setDefaultProperties(const ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "400");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "800");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, "0");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, "0");
}

CustomFileDialog *SUI::FileDialogImpl::getWidget() const {
    return dynamic_cast<CustomFileDialog *>(BaseWidget::getWidget());
}

void SUI::FileDialogImpl::onClicked(int result) {
    mFilenameList.clear();
    switch (result)
    {
    case Accept:
        mFilenameList = getWidget()->selectedFiles();
        if (!clicked.empty()) clicked();
        break;
    case Cancel:
    default:
        break;
    }
    getWidget()->selectedFiles().clear(); //clear selectedfiles
    getWidget()->selectFile(" "); //clean dialog
}

void SUI::FileDialogImpl::onDirectoryEntered(QString path) {
    if (QDir(path).absolutePath().contains(QDir(mRootDir).absolutePath()) == false) {
        QMessageBox::critical(getWidget(), QString("Error"), QString("Directory not within root directory"),QMessageBox::Ok);
        getWidget()->setDirectory(mRootDir);
    }
}

void SUI::FileDialogImpl::setAcceptMode(AcceptMode mode) {
    switch (mode)
    {
    default:
    case File:
        getWidget()->setFileMode(QFileDialog::ExistingFiles);
        getWidget()->setAcceptMode(QFileDialog::AcceptOpen);
        break;
    case Save:
        getWidget()->setFileMode(QFileDialog::AnyFile);
        getWidget()->setAcceptMode(QFileDialog::AcceptSave);
        break;
    case Dir:
        getWidget()->setFileMode(QFileDialog::Directory);
        getWidget()->setOptions(QFileDialog::ShowDirsOnly);
        break;
    }
}

void SUI::FileDialogImpl::setTitle(const std::string &title) {
    getWidget()->setWindowTitle(QString::fromStdString(title));
}

void SUI::FileDialogImpl::setAcceptButtonText(const std::string &message) {
    getWidget()->setLabelText(QFileDialog::Accept, QString::fromStdString(message));
}

void SUI::FileDialogImpl::setFilter(const std::list<std::string> &filter) {
    QStringList list;
    for (std::list<std::string>::const_iterator iterator = filter.begin(); iterator != filter.end(); ++iterator)
    {
        QString value = QString::fromStdString(*iterator);
        if(!value.isEmpty())
        {
            list.append(value);
        }
    }
    getWidget()->setNameFilters(list);
}

void SUI::FileDialogImpl::setDirectory(const std::string &path) {
    if (QDir(QString::fromStdString(path)).absolutePath().contains(QDir(mRootDir).absolutePath()) == true) {
        getWidget()->setDirectory(QDir(QString::fromStdString(path)));
    }
    else {
        QMessageBox::critical(getWidget(), QString("Error"), QString("Directory not within root directory"),QMessageBox::Ok);
    }
}

void SUI::FileDialogImpl::setRootDirectory(const std::string &rootpath) {
    QString rootPath = QString::fromStdString(rootpath);
    if (rootPath.isEmpty()) rootPath = "/";

    QDir dir(rootPath);
    if (dir.exists()) {
        mRootDir = dir.path();
    }
    else {
        QMessageBox::critical(getWidget(), QString("Error"), QString("Invalid directory"),QMessageBox::Ok);
    }

}

std::string SUI::FileDialogImpl::getSelectedFiles() const {
    return mFilenameList.join(";").toStdString();
}

//main interface
void SUI::FileDialogImpl::show(const std::string &title, const std::string &message, const std::list<std::string> &filters, AcceptMode mode) {
    mFilenameList.clear();
    setTitle(title);
    setAcceptButtonText(message);
    setFilter(filters);
    setAcceptMode(mode);
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "400");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "800");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, "0");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, "0");
    centerWidget();
    getWidget()->update(); //to make all changes current
    getWidget()->exec();
}

void SUI::FileDialogImpl::centerWidget() {
    if (getWidget()->isFullScreen()) return;
    QSize size = getWidget()->size();
    QRect screenGeometry = QApplication::desktop()->screenGeometry(-1);
    int mw = size.width();
    int mh = size.height();
    int cw = screenGeometry.center().x() - (mw / 2);
    int ch = screenGeometry.center().y() - (mh / 2);
    getWidget()->move(cw, ch);
}

void SUI::FileDialogImpl::setVisible(bool visible) {
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "400");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "800");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, "0");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, "0");
    centerWidget();
    getWidget()->update(); //to make all changes current

    BaseWidget::setVisible(visible);
    if (!visibilityChanged.empty()) {
        visibilityChanged(visible);
    }
}

