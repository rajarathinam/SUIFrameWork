//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::ProgressBarImpl.
// !\description Class implementation file for SUI::ProgressBarImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIProgressBarImpl.h"

#include <QStyle>
#include <QTimer>
#include <QVariant>
#include <boost/foreach.hpp>

SUI::ProgressBarImpl::ProgressBarImpl(QWidget *parent) :
    BaseWidget(new QProgressBar(parent), SUI::ObjectType::ProgressBar, false),
    mOrientation(OrientationEnum::Horizontal),
    mProgressTimer(NULL),
    mProgressValue(0),
    mMaxProgressValue(0)
{
    exposeWidthProperty();
    exposeHeightProperty();

    ProgressBarImpl::getWidget()->setMinimum(ObjectProperties::getPropertyValue(SUI::ObjectPropertyTypeEnum::MinValue).toInt());
    ProgressBarImpl::getWidget()->setMaximum(ObjectProperties::getPropertyValue(SUI::ObjectPropertyTypeEnum::MaxValue).toInt());

    connect(ProgressBarImpl::getWidget(), SIGNAL(valueChanged(int)), this, SLOT(onValueChanged()));
}

SUI::ProgressBarImpl::~ProgressBarImpl()
{
    if (mProgressTimer != NULL) {
        mProgressTimer->stop();
        mProgressTimer->deleteLater();
    }
}

void SUI::ProgressBarImpl::setText(const std::string &value) {
    if (getText() == value) return;
    getWidget()->setValue(QString::fromStdString(value).toInt());
}

std::string SUI::ProgressBarImpl::getText() const {
    return QString::number(getWidget()->value()).toStdString();
}

void SUI::ProgressBarImpl::onValueChanged() {
    if (!progressChanged.empty()) progressChanged();
}

void SUI::ProgressBarImpl::setDefaultProperties(const ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);
    // default values
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "30");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "200");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Color, "Standard");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, "35");

    QStringList orientationList;
    BOOST_FOREACH(auto str, SUI::OrientationEnum::getOrientationStringList()) {
        orientationList.append(QString::fromStdString(str));
    }
    setPropertyValues(SUI::ObjectPropertyTypeEnum::Orientation, orientationList.join(";"));
    setPropertyValue(ObjectPropertyTypeEnum::Orientation,QString::fromStdString(SUI::OrientationEnum::toString(SUI::OrientationEnum::Horizontal)));
    setOrientation(OrientationEnum::Horizontal);

    switch (context)
    {
    case EditorSelector:
        break;

    case EditorForm:
        setValue(35);
        break;

    default:
        break;
    }
}

QProgressBar *SUI::ProgressBarImpl::getWidget() const {
    return qobject_cast<QProgressBar *>(BaseWidget::getWidget());
}

SUI::OrientationEnum::Orientation SUI::ProgressBarImpl::getOrientation() const {
    return mOrientation;
}

void SUI::ProgressBarImpl::setOrientation(OrientationEnum::Orientation orientation) {
    mOrientation = orientation;
    switch (orientation)
    {
    case OrientationEnum::Vertical:
        getWidget()->setOrientation(Qt::Vertical);
        getWidget()->setTextDirection(QProgressBar::BottomToTop);
        getWidget()->setProperty("Orientation", "Vertical");
        break;
    case OrientationEnum::Horizontal:
        getWidget()->setOrientation(Qt::Horizontal);
        getWidget()->setProperty("Orientation", "Horizontal");
        break;
    default:
        break;
    }
}

int SUI::ProgressBarImpl::getValue() const {
    return getWidget()->value();
}

void SUI::ProgressBarImpl::setBold(bool bold) {
    getWidget()->setProperty("SUIFont", QVariant::fromValue<QString>(bold ? "bold" : ""));
    getWidget()->style()->polish(getWidget());
}

bool SUI::ProgressBarImpl::isBold() const {
    return getWidget()->property("SUIFont").toString() == "bold";
}

void SUI::ProgressBarImpl::clearText() {
    setText("");
}

void SUI::ProgressBarImpl::setValue(int percentage) {
    getWidget()->setValue(percentage);
}

void SUI::ProgressBarImpl::disablePercentage(bool disabled) {
    getWidget()->setTextVisible(!disabled);
}

bool SUI::ProgressBarImpl::isPercentageDisabled() const {
    return !getWidget()->isTextVisible();
}

void SUI::ProgressBarImpl::startTimedProgress(int expectedSecs) {
    if (mProgressTimer == NULL && expectedSecs > 0) {
        mProgressTimer = new QTimer(this);
        getWidget()->setMinimum(0);
        getWidget()->setMaximum(100);
        mProgressValue = 0;
        mMaxProgressValue = expectedSecs;
        connect(mProgressTimer, SIGNAL(timeout()),this, SLOT(onProgressTimer()));
        getWidget()->setValue(0);
        mProgressTimer->start(1000);
    }
}

void SUI::ProgressBarImpl::stopTimedProgress(int showReadyMSecs) {
    if (mProgressTimer != NULL) {
        getWidget()->setValue(100);
        mProgressTimer->stop();
        mProgressTimer->deleteLater();
        mProgressTimer = NULL;
        if (showReadyMSecs != 0) QTimer::singleShot(showReadyMSecs, this, SLOT(onResetProgressBarTimer()));
    }
}

void SUI::ProgressBarImpl::onProgressTimer() {
   double dividend = static_cast<double>(++mProgressValue) * 100.0;
   double divisor = static_cast<double>(mMaxProgressValue);
   int curVal = static_cast<int>(dividend / divisor);
   curVal = (curVal < 98) ? curVal : 98;
   getWidget()->setValue(curVal);
}

void SUI::ProgressBarImpl::onResetProgressBarTimer() {
    if (mProgressTimer == NULL) getWidget()->setValue(0);   // Make sure that the Timer has not started again
}

SUI::ColorEnum::Color SUI::ProgressBarImpl::getColor() const {
    return SUI::ColorEnum::fromString(getPropertyValue(SUI::ObjectPropertyTypeEnum::Color).toStdString());
}

void SUI::ProgressBarImpl::setColor(const SUI::ColorEnum::Color color) {
    if (!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color)) return;
    if (getColor() != color) {
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Color,QString::fromStdString(ColorEnum::toString(color)));
    }
    getWidget()->setProperty("ColorSet", QVariant::fromValue<QString>(QString::fromStdString(ColorEnum::toString(color)).toLower()));
    getWidget()->style()->polish(getWidget());
}

void SUI::ProgressBarImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID, propertyValue);

    switch (propertyID) {
    case SUI::ObjectPropertyTypeEnum::Bold:
        setBold((propertyValue.compare("true", Qt::CaseInsensitive) == 0));
        break;

    case SUI::ObjectPropertyTypeEnum::Text:
        setText(propertyValue.toStdString());
        break;

    case SUI::ObjectPropertyTypeEnum::Percentage:
        disablePercentage(propertyValue.toLower() == "false");
        break;

    case SUI::ObjectPropertyTypeEnum::MinValue:
        getWidget()->setMinimum(propertyValue.toInt());
        break;

    case SUI::ObjectPropertyTypeEnum::MaxValue:
        getWidget()->setMaximum(propertyValue.toInt());
        break;

    case SUI::ObjectPropertyTypeEnum::Orientation:
        setOrientation(propertyValue == "Vertical" ? OrientationEnum::Vertical : OrientationEnum::Horizontal);
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Width,QString::number(getWidget()->width()));
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Height,QString::number(getWidget()->height()));
        break;

    case SUI::ObjectPropertyTypeEnum::Color:
        setColor(SUI::ColorEnum::fromString(propertyValue.toStdString()));
        break;

    default:
        break;
    }

}

