//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::DropDownImpl.
// !\description Class implementation file for SUI::DropDownImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIDropDownImpl.h"

#include <QStyle>
#include <boost/foreach.hpp>

#include "FWQxCore/SUIArgumentException.h"

SUI::DropDownImpl::DropDownImpl(QWidget *parent) :
    BaseWidget(new QComboBox(parent), SUI::ObjectType::DropDown, false), DropDown()
{
    exposeWidthProperty();
    connect(DropDownImpl::getWidget(), SIGNAL(currentIndexChanged(QString)), this, SLOT(onCurrenIndexChanged()));
}

void SUI::DropDownImpl::setDefaultProperties(const SUI::BaseObject::ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "30");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "200");

    switch (context)
    {
    case EditorSelector:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, QString::fromStdString(SUI::ObjectType::toString(Object::getObjectType())));
        break;

    case EditorForm:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, "TBD");
        break;

    default:
        break;
    }
}

QComboBox *SUI::DropDownImpl::getWidget() const {
    return dynamic_cast<QComboBox *>(BaseWidget::getWidget());
}

void SUI::DropDownImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID,propertyValue);

    switch (propertyID) {
    case SUI::ObjectPropertyTypeEnum::Text:
    {
        clearItems();
        QStringList valueList = propertyValue.split(';');
        std::list<std::string> stdValueList;
        BOOST_FOREACH (QString value, valueList) {
            stdValueList.push_back(value.toStdString());
        }

        addItems(stdValueList);
        break;
    }
    case SUI::ObjectPropertyTypeEnum::Bold:
        setBold((propertyValue.compare("true", Qt::CaseInsensitive) == 0));
        break;

    case SUI::ObjectPropertyTypeEnum::Color:
        setColor(SUI::ColorEnum::fromString(propertyValue.toStdString()));
        break;

    case SUI::ObjectPropertyTypeEnum::BGColor:
        setBGColor(SUI::ColorEnum::fromString(propertyValue.toStdString()));
        break;

    default:
        break;
    }
}

void SUI::DropDownImpl::addItems(const std::list<std::string> &aItems) {
    QStringList itemList;
    BOOST_FOREACH (std::string item, aItems)
        itemList.append(QString::fromStdString(item));
    getWidget()->addItems(itemList);
}

void SUI::DropDownImpl::onCurrenIndexChanged() {
    if (!valueChanged.empty()) valueChanged();
    if (!currentIndexChanged.empty()) currentIndexChanged(getWidget()->currentIndex());
}

SUI::ColorEnum::Color SUI::DropDownImpl::getColor() const {
    return SUI::ColorEnum::fromString(getPropertyValue(SUI::ObjectPropertyTypeEnum::Color).toStdString());
}


void SUI::DropDownImpl::setColor(const SUI::ColorEnum::Color color) {
    if (!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color)) return;
    if (SUI::ColorEnum::fromString(getProperty(SUI::ObjectPropertyTypeEnum::Color)->getValue().toStdString()) != color) {
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Color, QString::fromStdString(ColorEnum::toString(color)));
    }
    getWidget()->setProperty("ColorSet", QString::fromStdString(SUI::ColorEnum::toString(color)));
    getWidget()->style()->polish( getWidget());
}

SUI::ColorEnum::Color SUI::DropDownImpl::getBGColor() const {
    return ColorEnum::fromString(getPropertyValue(SUI::ObjectPropertyTypeEnum::BGColor).toStdString());
}

void SUI::DropDownImpl::setBGColor(const SUI::ColorEnum::Color color) {
    if (!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color)) return;
    if (SUI::ColorEnum::fromString(getProperty(SUI::ObjectPropertyTypeEnum::BGColor)->getValue().toStdString()) != color) {
        setPropertyValue(SUI::ObjectPropertyTypeEnum::BGColor, QString::fromStdString(ColorEnum::toString(color)));
    }
    getWidget()->setProperty("BGColorSet", QString::fromStdString(SUI::ColorEnum::toString(color)));
    getWidget()->style()->polish( getWidget());
}

std::list<std::string> SUI::DropDownImpl::getItems() const {
    std::list<std::string> textItems;
    for (int i = 0; i <  getWidget()->count(); i++) {
        textItems.push_back( getWidget()->itemText(i).toStdString());
    }
    return textItems;
}

void SUI::DropDownImpl::clearItems() {
    getWidget()->clear();
}

void SUI::DropDownImpl::removeItems(const std::list<std::string> &itemlist)
{
    BOOST_FOREACH(const std::string & str, itemlist) {
        int i =  getWidget()->findText(QString::fromStdString(str));
        if (i >= 0) getWidget()->removeItem(i);
    }
}

std::list<std::string> SUI::DropDownImpl::getSelectedItems() const {
    std::list<std::string> textList;
    textList.push_back(getWidget()->currentText().toStdString());
    return textList;
}

QString SUI::DropDownImpl::getAllColumnItems(int) const {
    QStringList itemList;
    BOOST_FOREACH (std::string item, getItems()) {
        itemList.append(QString::fromStdString(item));
    }
    return itemList.join(";");
}

void SUI::DropDownImpl::setBold(bool bold) {
    getWidget()->setProperty("SUIFont", QVariant::fromValue<QString>(bold ? "bold" : ""));
    getWidget()->style()->polish( getWidget());
}

void SUI::DropDownImpl::setMode(ErrorModeEnum::ErrorMode mode) {
    mCurrentMode = mode;
    if (mode == ErrorModeEnum::Error) {
        getWidget()->setProperty("BGColorSet", "error");
    }
    else {
        getWidget()->setProperty("BGColorSet", "");
    }
    getWidget()->style()->polish(getWidget());
}

void SUI::DropDownImpl::selectItem(const int row, const int /*col*/) {
    getWidget()->setCurrentIndex(row);
}

void SUI::DropDownImpl::selectItem(const std::string) {
}

QStringList SUI::DropDownImpl::formatString(QString &aStr) {
    return (aStr.split(";", QString::SkipEmptyParts));
}

int SUI::DropDownImpl::getCurrentIndex() const {
    return getWidget()->currentIndex();
}

std::string SUI::DropDownImpl::getCurrentText() const {
    return getWidget()->currentText().toStdString();
}

void SUI::DropDownImpl::setItemText(int index, const std::string &text) {
    getWidget()->setItemText(index,QString::fromStdString(text));
}

std::string SUI::DropDownImpl::getItemText(int index) const {
    return getWidget()->itemText(index).toStdString();
}

void SUI::DropDownImpl::setCurrentIndex(int index) {
    getWidget()->setCurrentIndex(index);
}
