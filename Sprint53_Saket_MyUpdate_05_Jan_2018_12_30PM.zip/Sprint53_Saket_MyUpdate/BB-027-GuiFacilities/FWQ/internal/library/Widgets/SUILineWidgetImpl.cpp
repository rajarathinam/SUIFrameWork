//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::LineWidgetImpl.
// !\description Class implementation file for SUI::LineWidgetImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUILineWidgetImpl.h"

SUI::LineWidgetImpl::LineWidgetImpl(QWidget *parent) :
    BaseWidget(new QFrame(parent), SUI::ObjectType::LineWidget, false)
{
    exposeWidthProperty();
    LineWidgetImpl::getWidget()->setFrameShape(QFrame::HLine);
    LineWidgetImpl::getWidget()->setLineWidth(3);
    LineWidgetImpl::getWidget()->setAttribute(Qt::WA_TranslucentBackground);
}

void SUI::LineWidgetImpl::setDefaultProperties(const SUI::BaseObject::ObjectContext &context)
{
    BaseWidget::setDefaultProperties(context);

    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "200");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "4");
}


QFrame *SUI::LineWidgetImpl::getWidget() const
{
    return dynamic_cast<QFrame *>(BaseWidget::getWidget());
}
