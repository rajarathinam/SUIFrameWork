//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::GroupBoxImpl.
// !\description Class implementation file for SUI::GroupBoxImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIGroupBoxImpl.h"
#include "SUIStyleSheet.h"
#include <QStyle>
#include <QVariant>

SUI::GroupBoxImpl::GroupBoxImpl(QWidget *parent) :
    BaseWidget(new QGroupBox(parent), SUI::ObjectType::GroupBox, true)
{
    exposeHeightProperty();
    exposeWidthProperty();
}

void SUI::GroupBoxImpl::setDefaultProperties(const ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);
    setPropertyValue(ObjectPropertyTypeEnum::Bold,"true");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "50");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "200");
    setBold(true);
    const std::list<SUI::ColorEnum::Color> colors = SUI::ColorEnum::getColorEnumList(SUI::ObjectType::GroupBox);
    if (colors.size() > 0) {
        // add the colors
        setPropertyValues(SUI::ObjectPropertyTypeEnum::HoverBGColor, QString::fromStdString(ColorEnum::toString(colors,";")));

        // set the default colors
        setPropertyValue(SUI::ObjectPropertyTypeEnum::HoverBGColor, QString::fromStdString(ColorEnum::toString(colors.front())));
    }

    switch (context) {
    case EditorSelector:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, QString::fromStdString(SUI::ObjectType::toString(Object::getObjectType())));
        break;

    case EditorForm:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, "TBD");
        break;

    default:
        break;
    }
}

QGroupBox *SUI::GroupBoxImpl::getWidget() const {
    return dynamic_cast<QGroupBox *>(BaseWidget::getWidget());
}

void SUI::GroupBoxImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID,propertyValue);

    switch (propertyID) {
    case SUI::ObjectPropertyTypeEnum::Bold:
        setBold((propertyValue.compare("true", Qt::CaseInsensitive) == 0));
        break;

    case SUI::ObjectPropertyTypeEnum::Text:
        setText(propertyValue.toStdString());
        break;

    case SUI::ObjectPropertyTypeEnum::BGColor:
        setBGColor(SUI::ColorEnum::fromString(propertyValue.toStdString()));
        break;

    default:
        break;
    }
}
void SUI::GroupBoxImpl::setText(const std::string &value) {
    if (getText() == value) return;
    getWidget()->setTitle(QString::fromStdString(value));
}

std::string SUI::GroupBoxImpl::getText() const {
    return getWidget()->title().toStdString();
}

void SUI::GroupBoxImpl::clearText() {
    getWidget()->setTitle("");
}

void SUI::GroupBoxImpl::setBold(bool bold) {
    getWidget()->setProperty("SUIFont", QVariant::fromValue<QString>(bold ? "bold" : ""));
    getWidget()->style()->polish(getWidget());
}

bool SUI::GroupBoxImpl::isBold() const {
    return getWidget()->property("SUIFont").toString() == "bold";
}
bool SUI::GroupBoxImpl::eventFilter(QObject *obj, QEvent *event) {
    if (event->type() == QEvent::HoverEnter) {
        if(getPropertyValue(SUI::ObjectPropertyTypeEnum::Hover).toLower() == "true"){
            getWidget()->setCursor(Qt::PointingHandCursor);
            getWidget()->setProperty("BGColorSet", getPropertyValue(SUI::ObjectPropertyTypeEnum::HoverBGColor).toLower());
            getWidget()->style()->polish(getWidget());
        }
    }
    else if(event->type() == QEvent::HoverLeave) {
        getWidget()->setCursor(Qt::ArrowCursor);
        setBGColor(getBGColor());
    }
    return BaseWidget::eventFilter(obj, event);
}

SUI::ColorEnum::Color SUI::GroupBoxImpl::getBGColor() const {
    return ColorEnum::fromString(getPropertyValue(SUI::ObjectPropertyTypeEnum::BGColor).toStdString());
}

void SUI::GroupBoxImpl::setBGColor(const SUI::ColorEnum::Color color) {
    if (!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color)) return;
    if (SUI::ColorEnum::fromString(getPropertyValue(SUI::ObjectPropertyTypeEnum::BGColor).toStdString()) != color) {
        setPropertyValue(SUI::ObjectPropertyTypeEnum::BGColor, QString::fromStdString(ColorEnum::toString(color)));
    }
    getWidget()->setProperty("BGColorSet", QString::fromStdString(ColorEnum::toString(color)).toLower());
    getWidget()->style()->polish(getWidget());
}

void SUI::GroupBoxImpl::setHover(bool hover, SUI::ColorEnum::Color color) {
    if (!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color)) return;

    //properties set via external interface
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Hover, hover ? "true": "false");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::HoverBGColor, QString::fromStdString(ColorEnum::toString(color)));
}

