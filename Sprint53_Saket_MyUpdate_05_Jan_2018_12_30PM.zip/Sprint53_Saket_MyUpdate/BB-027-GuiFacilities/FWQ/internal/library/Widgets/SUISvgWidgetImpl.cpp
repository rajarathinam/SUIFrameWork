//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::SvgWidgetImpl.
// !\description Class implementation file for SUI::SvgWidgetImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUISvgWidgetImpl.h"
#include <QDomDocument>
#include <QHelpEvent>
#include <QToolTip>
#include <boost/foreach.hpp>

#include "FWQxCore/SUIIOException.h"
#include "FWQxCore/SUIXmlException.h"
#include "FWQxCore/SUIResourcePath.h"

SUI::SvgWidgetImpl::SvgWidgetImpl(QWidget *parent):
    BaseWidget(new QSvgWidget(parent), SUI::ObjectType::SvgWidget, false)
{
    exposeHeightProperty();
    exposeWidthProperty();
    SvgWidgetImpl::getWidget()->setMouseTracking(true);
    SvgWidgetImpl::getWidget()->installEventFilter(this);
    SvgWidgetImpl::getWidget()->setAttribute(Qt::WA_AlwaysShowToolTips);
    SvgWidgetImpl::getWidget()->load(QString::fromStdString(":/image/SvgImage.svg"));
}

SUI::SvgWidgetImpl::~SvgWidgetImpl(){
}

QSvgWidget *SUI::SvgWidgetImpl::getWidget() const {
    return dynamic_cast<QSvgWidget *>(BaseWidget::getWidget());
}

void SUI::SvgWidgetImpl::setDefaultProperties(const SUI::BaseObject::ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "60");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "60");
}

void SUI::SvgWidgetImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    switch (propertyID) {
    case SUI::ObjectPropertyTypeEnum::SvgFilename:
        if(!propertyValue.isEmpty()) getWidget()->load(propertyValue);
        break;
    default:
        break;
    }
    BaseWidget::setPropertyValue(propertyID, propertyValue);
}

std::list<std::string> SUI::SvgWidgetImpl::getElementIdList() {
    std::list<std::string>  itemList;
    BOOST_FOREACH (QString item, mDomNodeForElement.keys()) {
        itemList.push_back(item.toStdString());
    }
    return itemList;
}

void SUI::SvgWidgetImpl::setElementColor(const std::string idvalue, const SUI::ColorEnum::Color color) {
    if(!getWidget()->renderer()->elementExists(QString::fromStdString(idvalue))) return;
    if(!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color)) return;

    QDomNode node = mDomNodeForElement.value(QString::fromStdString(idvalue));
    QDomElement element = node.toElement();

    if(element.hasAttribute("fill")) {
        element.setAttribute("fill", QString::fromStdString(SUI::ColorEnum::toString(color)));
    }
    else if(element.hasAttribute("class") && element.isText()) {
        element.setAttribute("fill",QString::fromStdString(SUI::ColorEnum::toString(color)));
    }
    else if(element.hasAttribute("style")) {
        QString value = element.attribute("style");

        QStringList styleList = value.split(";");
        QStringList newStyleList;
        BOOST_FOREACH (QString style, styleList)
        {
            QStringList propertyVal = style.split(":");
            QString prop = propertyVal.first().trimmed();
            QString newVal = propertyVal.at(1).trimmed();
            if(prop == "fill")
            {
                newVal = QString::fromStdString(SUI::ColorEnum::toString(color));
            }
            newStyleList.append(prop + ":" + newVal);
        }
        element.setAttribute("style", newStyleList.join(";"));
    }
    else if(element.hasChildNodes()) {
        for(QDomNode n = element.firstChild(); !n.isNull(); n = n.nextSibling())
        {
            QDomElement childElement = n.toElement();
            if(childElement.hasAttribute("fill")) {
                childElement.setAttribute("fill", QString::fromStdString(SUI::ColorEnum::toString(color)));
            }
            else if(childElement.hasAttribute("class")) {
                childElement.setAttribute("fill", QString::fromStdString(SUI::ColorEnum::toString(color)));
            }
            else if(childElement.hasAttribute("style")) {
                QString value = childElement.attribute("style");

                QStringList styleList = value.split(";");
                QStringList newStyleList;
                BOOST_FOREACH (QString style, styleList)
                {
                    QStringList propertyVal = style.split(":");
                    QString prop = propertyVal.first().trimmed();
                    QString newVal = propertyVal.at(1).trimmed();
                    if(prop == "fill") newVal = QString::fromStdString(SUI::ColorEnum::toString(color));
                    newStyleList.append(prop + ":" + newVal);
                }
                childElement.setAttribute("style", newStyleList.join(";"));
            }
        }
    }
    getWidget()->load(mSvgDomDocument.toByteArray());
}

void SUI::SvgWidgetImpl::setElementBorderColor(const std::string idvalue, const SUI::ColorEnum::Color borderColor) {
    if(!getWidget()->renderer()->elementExists(QString::fromStdString(idvalue))) return;
    if(!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),borderColor)) return;

    QDomNode node = mDomNodeForElement.value(QString::fromStdString(idvalue));
    QDomElement element = node.toElement();
    if(element.hasAttribute("stroke")) {
        element.setAttribute("stroke", borderColor);
    }
    else if(element.hasAttribute("class")) {
        element.setAttribute("stroke", borderColor);
    }
    else if(element.hasAttribute("style")) {
        QString value = element.attribute("style");

        QStringList styleList = value.split(";");
        QStringList newStyleList;
        BOOST_FOREACH (QString style, styleList)
        {
            QStringList propertyVal = style.split(":");
            QString prop = propertyVal.first().trimmed();
            QString newVal = propertyVal.at(1).trimmed();
            if(prop == "stroke") {
                newVal = borderColor;
            }
            newStyleList.append(prop + ":" + newVal);
        }
        element.setAttribute("style", newStyleList.join(";"));
    }
    else if(element.hasChildNodes()) {
        for(QDomNode n = element.firstChild(); !n.isNull(); n = n.nextSibling())
        {
            QDomElement childElement = n.toElement();
            if(childElement.hasAttribute("stroke")) {
                childElement.setAttribute("stroke", borderColor);
            }
            else if(childElement.hasAttribute("class")) {
                childElement.setAttribute("stroke", borderColor);
            }
            else if(childElement.hasAttribute("style")) {
                QString value = childElement.attribute("style");

                QStringList styleList = value.split(";");
                QStringList newStyleList;
                BOOST_FOREACH (QString style, styleList)
                {
                    QStringList propertyVal = style.split(":");
                    QString prop = propertyVal.first().trimmed();
                    QString newVal = propertyVal.at(1).trimmed();
                    if(prop == "stroke") {
                        newVal = borderColor;
                    }
                    newStyleList.append(prop + ":" + newVal);
                }
                childElement.setAttribute("style", newStyleList.join(";"));
            }
        }
    }
}

void SUI::SvgWidgetImpl::setElementText(const std::string idvalue, const std::string text) {
    if(!getWidget()->renderer()->elementExists(QString::fromStdString(idvalue))) return;

    QDomNode node = mDomNodeForElement.value(QString::fromStdString(idvalue));
    QDomNodeList elements = node.toElement().elementsByTagName("text");
    if(elements.size() == 0) {
        QDomElement textElement = mSvgDomDocument.createElement("text");
        QDomText domtext = mSvgDomDocument.createTextNode(QString::fromStdString(text));

        node.toElement().appendChild(textElement);
        textElement.appendChild(domtext);
    }
    else {
        for (int i = 0; i < elements.item(0).childNodes().count(); i++)
        {
            if(elements.item(0).childNodes().item(i).isText()) {
                QDomText t = elements.item(0).childNodes().item(i).toText();
                t.setData(QString::fromStdString(text));

                break;
            }
        }
    }
}

void SUI::SvgWidgetImpl::setElementBorderWidth(const std::string idvalue, const int borderWidth) {
    if(!getWidget()->renderer()->elementExists(QString::fromStdString(idvalue))) return;

    QDomNode node = mDomNodeForElement.value(QString::fromStdString(idvalue));
    QDomElement element = node.toElement();
    if(element.hasAttribute(QString::fromStdString("stroke-width"))) {
        element.setAttribute("stroke-width", borderWidth);
    }
    else if(element.hasChildNodes()) {
        for(QDomNode n = element.firstChild(); !n.isNull(); n = n.nextSibling())
        {
            QDomElement childElement = n.toElement();
            if(childElement.hasAttribute("stroke-width")) {
                childElement.setAttribute("stroke-width",borderWidth );
            }
        }
    }
}

void SUI::SvgWidgetImpl::setElementTextColor(const std::string idvalue, const SUI::ColorEnum::Color color) {
    if(!getWidget()->renderer()->elementExists(QString::fromStdString(idvalue))) return;
    if(!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color)) return;

    QDomNode node = mDomNodeForElement.value(QString::fromStdString(idvalue));
    QDomNodeList elements = node.toElement().elementsByTagName("text");
    for (int i = 0; i < elements.item(0).childNodes().count(); i++)
    {
        if(elements.item(0).childNodes().item(i).isText()) {
            QDomElement element =  elements.item(0).childNodes().item(i).toElement();
            element.setAttribute("fill", color);

            break;
        }
    }
}

void SUI::SvgWidgetImpl::setElementToolTip(const std::string idvalue, const std::string tipText) {
    if(!getWidget()->renderer()->elementExists(QString::fromStdString(idvalue))) return;
    QDomNode node = mDomNodeForElement.value(QString::fromStdString(idvalue));
    QDomNodeList elements = node.toElement().elementsByTagName("title");
    if(elements.size() == 0) {
        QDomElement titleElement = mSvgDomDocument.createElement("title");
        QDomText domtext = mSvgDomDocument.createTextNode(QString::fromStdString(tipText));

        node.toElement().appendChild(titleElement);
        titleElement.appendChild(domtext);
    }
    else {
        for (int i = 0; i < elements.item(0).childNodes().count(); i++)
        {
            if(elements.item(0).childNodes().item(i).isText()) {
                QDomText t = elements.item(0).childNodes().item(i).toText();
                t.setData(QString::fromStdString(tipText));

                break;
            }
        }
    }
}

std::string SUI::SvgWidgetImpl::getElementToolTip(const std::string idvalue) {
    if(!getWidget()->renderer()->elementExists(QString::fromStdString(idvalue))) return "";
    QDomNode node = mDomNodeForElement.value(QString::fromStdString(idvalue));
    if(node.isNull()) return "";

    QDomText tooltip;
    QDomNodeList elements = node.toElement().elementsByTagName("title");
    if(elements.size() > 0) {
        for (int i = 0; i < elements.item(0).childNodes().count(); i++)
        {
            if(elements.item(0).childNodes().item(i).isText()) {
                tooltip = elements.item(0).childNodes().item(i).toText();
                break;
            }
        }
    }
    return tooltip.data().isEmpty() ? "": tooltip.data().toStdString();
}

bool SUI::SvgWidgetImpl::event(QEvent *event) {
    if (event->type() == QEvent::ToolTip) {
        QHelpEvent *helpEvent = static_cast<QHelpEvent *>(event);
//        int index = 0;
//        if (index != -1) {
            QToolTip::showText(helpEvent->globalPos(), "TESTING");
//        } else {
//            QToolTip::hideText();
//            event->ignore();
//        }
        return true;
    }
    return BaseWidget::event(event);
}

void SUI::SvgWidgetImpl::recursiveParseSvgImage(QDomNode node) {
    while(!node.isNull())
    {
        if(node.isElement()) {
            QDomElement element = node.toElement();
            if(element.hasAttribute("id")) {
                QDomNamedNodeMap attributeMap = node.attributes();
                if(getWidget()->renderer()->elementExists(attributeMap.namedItem("id").nodeValue())) {
                    mDomNodeForElement.insert(attributeMap.namedItem("id").nodeValue(), node);
                }
            }
            if(element.hasChildNodes()) recursiveParseSvgImage(node.firstChild());
        }
        node = node.nextSibling();
    }
}

void SUI::SvgWidgetImpl::parseSvgImage() {
    mDomNodeForElement.clear();
    QDomNode node = mSvgDomDocument.documentElement().firstChild();
    while(!node.isNull())
    {
        if(node.isElement()) {
            QDomElement element = node.toElement();
            if(element.hasAttribute("id")) {
                QDomNamedNodeMap attributeMap = node.attributes();
                if(getWidget()->renderer()->elementExists(attributeMap.namedItem("id").nodeValue())) {
                    mDomNodeForElement.insert(attributeMap.namedItem("id").nodeValue(), node);
                }
            }
            if(element.hasChildNodes()) recursiveParseSvgImage(node.firstChild());
        }
        node = node.nextSibling();
    }
}

void SUI::SvgWidgetImpl::setImage(const std::string &value) {
    QFile svgFile(QString::fromStdString(SUI::ResourcePath::getResourceFile(value)));
    if(!svgFile.open(QFile::ReadOnly | QFile::Text)) {
       throw new SUI::IOException(std::string("Unable to open file ").append(value).append(" for Reading."));
    }
    if(mSvgDomDocument.setContent(&svgFile, true) == false) {
       throw new SUI::XmlException(std::string("Failed to parse SVG File"));
    }
    svgFile.close();

    getWidget()->load(QString::fromStdString(value));
    parseSvgImage();
}
