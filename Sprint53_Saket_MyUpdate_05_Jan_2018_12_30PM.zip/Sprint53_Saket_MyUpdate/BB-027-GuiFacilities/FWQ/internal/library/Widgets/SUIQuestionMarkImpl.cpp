//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::QuestionMarkImpl.
// !\description Class implementation file for SUI::QuestionMarkImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIQuestionMarkImpl.h"

#include "SUIStyleSheet.h"
#include <QFileInfo>
#include <QMessageBox>
#include <QTextStream>

SUI::QuestionMarkImpl::QuestionMarkImpl(QWidget *parent) :
    BaseWidget(new CustomToolButton(parent), SUI::ObjectType::QuestionMark, false)
{
    connect(QuestionMarkImpl::getWidget(),SIGNAL(mouseReleased()),this,SLOT(onMouseRelease()));
    initialize();
}

void SUI::QuestionMarkImpl::setDefaultProperties(const ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);

    switch (context)
    {
    case EditorSelector:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, QString::fromStdString(SUI::ObjectType::toString(Object::getObjectType())));
        break;

    case EditorForm:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, "TBD");
        break;

    default:
        break;
    }
}

CustomToolButton *SUI::QuestionMarkImpl::getWidget() const {
    return dynamic_cast<CustomToolButton *>(BaseWidget::getWidget());
}

void SUI::QuestionMarkImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID,propertyValue);

    switch (propertyID) {
    case SUI::ObjectPropertyTypeEnum::Bold:
        setBold((propertyValue.compare("true", Qt::CaseInsensitive) == 0));
        break;
    case SUI::ObjectPropertyTypeEnum::Text:
        setText(propertyValue.toStdString());
        break;
    default:
        break;
    }
}

void SUI::QuestionMarkImpl::setText(const std::string &value) {
    mFile = QString::fromStdString(value);
    bool res = checkContent();
    if (getObjectContext() != SUI::BaseWidget::Gui) getWidget()->setEnabled(res);
}

std::string SUI::QuestionMarkImpl::getText() const {
    return mFile.toStdString();
}

void SUI::QuestionMarkImpl::clearText() {
    setText("");
}

void SUI::QuestionMarkImpl::setBold(bool) {
}

bool SUI::QuestionMarkImpl::isBold() const {
    return false;
}

void SUI::QuestionMarkImpl::setContent(QString content) {
    mContent = content;
}

QString SUI::QuestionMarkImpl::getContent() {
    return mContent;
}

void SUI::QuestionMarkImpl::initialize() {
    getWidget()->setIcon(QIcon(":/image/qmk.png"));
    QString s;
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, s.setNum(getWidget()->iconSize().height()));
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, s.setNum(getWidget()->iconSize().width()));
}

bool SUI::QuestionMarkImpl::checkContent() {
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Enable, "true");
    QFile f(QString::fromStdString(getText()));
    QFileInfo fi(f);
    if (!fi.exists()) setPropertyValue(SUI::ObjectPropertyTypeEnum::Enable, "false");
    else if (fi.suffix() != "txt")
    {
        QMessageBox msgBox;
        msgBox.setText("File should have extension .txt");
        msgBox.exec();
    }
    else if (!f.open(QFile::ReadOnly | QFile::Text))
    {
        QMessageBox msgBox;
        msgBox.setText("Cannot open file");
        msgBox.exec();
    }
    else
    {
        QTextStream in(&f);
        setContent(in.readAll());
        f.close();
        return true;
    }
    return false;
}

void SUI::QuestionMarkImpl::onMouseRelease() {
    QMessageBox *msgBox = new QMessageBox();
    msgBox->setStyleSheet(QString::fromStdString(SUI::StyleSheet::getInstance()->getStyleSheet()));
    if (checkContent()) {
        msgBox->setText(getContent());
        msgBox->exec();
    }
}
