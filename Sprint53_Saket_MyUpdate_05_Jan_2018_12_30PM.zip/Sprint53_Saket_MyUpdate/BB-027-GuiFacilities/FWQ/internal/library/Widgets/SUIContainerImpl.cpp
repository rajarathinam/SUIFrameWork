//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::ContainerImpl.
// !\description Class implementation file for SUI::ContainerImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIContainerImpl.h"
#include "FWQxCore/SUIResourcePath.h"
#include <QGridLayout>
#include <boost/foreach.hpp>

SUI::ContainerImpl::ContainerImpl(QWidget *parent) :
    BaseWidget(new QWidget(parent), SUI::ObjectType::Container, false)
{
    exposeHeightProperty();
    exposeWidthProperty();

    QGridLayout *gridLayout = new QGridLayout(ContainerImpl::getWidget());
    gridLayout->setSpacing(0);
    gridLayout->setContentsMargins(0, 0, 0, 0);

    mScrollArea = new QScrollArea(ContainerImpl::getWidget());
    mScrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    mScrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);

    gridLayout->addWidget(mScrollArea);
}

SUI::ContainerImpl::~ContainerImpl() {
    QWidget *ownWidget = mScrollArea->takeWidget();
    BOOST_FOREACH (SUI::Object *obj, mObjectList.getObjectList()) {
        BaseObject *object = SUI::ObjectFactory::getInstance()->toBaseObject(obj);
        SUI::Widget *widget = mObjectList.getObject<SUI::Widget>(object->getId());
        BaseWidget *baseWidget = SUI::ObjectFactory::getInstance()->toBaseWidget(widget);
        delete baseWidget;
        baseWidget = NULL;
    }
    delete ownWidget;
    ownWidget = NULL;
    delete mScrollArea;
    mScrollArea = NULL;
}

void SUI::ContainerImpl::setUiFilename(std::string filename) {
    TabOrder mTabOrder;
    QWidget *ownWidget = mScrollArea->takeWidget();
    BOOST_FOREACH (SUI::Object *obj, mObjectList.getObjectList()) {
        BaseObject *object = SUI::ObjectFactory::getInstance()->toBaseObject(obj);
        SUI::Widget *widget = mObjectList.getObject<SUI::Widget>(object->getId());
        BaseWidget *baseWidget = SUI::ObjectFactory::getInstance()->toBaseWidget(widget);
        delete baseWidget;
        baseWidget = NULL;
    }
    delete ownWidget;
    ownWidget = NULL;
    mObjectList.clear();
    QWidget* widget = QUiLoader::loadQUi(QString::fromStdString(SUI::ResourcePath::getResourceFile(filename)), mObjectList, mTabOrder);
    mScrollArea->setWidget(widget);
}

SUI::ObjectList* SUI::ContainerImpl::getObjectList() {
    return &mObjectList;
}

void SUI::ContainerImpl::setDefaultProperties(const ObjectContext &context)
{
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "200");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width,  "200");
    BaseWidget::setDefaultProperties(context);
}

QWidget *SUI::ContainerImpl::getWidget() const
{
    return dynamic_cast<QWidget *>(BaseWidget::getWidget());
}

void SUI::ContainerImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue)
{
    BaseWidget::setPropertyValue(propertyID, propertyValue);
}
