//-----------------------------------------------------------------------------|
//                                                                             |
//                            C++ Source File                                  |
//                                                                             |
//-----------------------------------------------------------------------------|
//
// Ident        : SUIWebViewImpl.cpp
// Author       : Patrick van Tongeren
// Description  : Class implementation file for SUI::WebViewImpl.
//
// ! \file        SUIWebViewImpl.cpp
// ! \brief       Class implementation file for SUI::WebViewImpl.
//
//-----------------------------------------------------------------------------|
//                                                                             |
//        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
//                           All rights reserved                               |
//                                                                             |
//-----------------------------------------------------------------------------|

#include "SUIWebViewImpl.h"
#include <QtWebKit/QWebFrame>


SUI::WebViewImpl::WebViewImpl(QWidget *parent) :
    BaseWidget(new QWebView(parent), SUI::ObjectType::WebView, false)
{
    exposeWidthProperty();
    exposeHeightProperty();

    connect(WebViewImpl::getWidget(), SIGNAL(loadFinished(bool)), this, SLOT(onLoadFinished(bool)));
}

SUI::WebViewImpl::~WebViewImpl()
{
}

void SUI::WebViewImpl::setDefaultProperties(const ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);
    // default values
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height,"75");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "175");

    setPropertyValue(SUI::ObjectPropertyTypeEnum::Url, "");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Html,
                     "<!DOCTYPE html>\n<html>\n<body>\n<div style=\"background-color:rgb(0,200,200)\">\n<fieldset>\n<legend>WebView</legend>\n\nContent\n\n</fieldset>\n</div>\n</body>\n</html>");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::ZoomFactor,"1.0");
}


void SUI::WebViewImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID, propertyValue);

    switch (propertyID) {

    case SUI::ObjectPropertyTypeEnum::Url:
        setUrl(propertyValue.toStdString());
        break;

    case SUI::ObjectPropertyTypeEnum::Html:
        setHtml(propertyValue.toStdString());
        break;

    case SUI::ObjectPropertyTypeEnum::ZoomFactor:
        setZoomFactor(propertyValue.toDouble());
        break;

    default:
        break;
    }
}

void SUI::WebViewImpl::onLoadFinished(bool success)
{
    if (!loadFinished.empty())
    {
        loadFinished(success);
    }
}

void SUI::WebViewImpl::setUrl(const std::string &url)
{
    getWidget()->setUrl(QUrl(QString::fromStdString(url)));
}

std::string SUI::WebViewImpl::getUrl() const
{
    return getWidget()->url().toString().toStdString();
}

void SUI::WebViewImpl::setHtml(const std::string &html)
{
    getWidget()->setHtml(QString::fromStdString(html));
}

void SUI::WebViewImpl::setHtml(const std::string &html, const std::string &baseUrl)
{
    getWidget()->setHtml(QString::fromStdString(html), QUrl(QString::fromStdString(baseUrl)));
}

std::string SUI::WebViewImpl::getHtml() const
{
    return getWidget()->page()->mainFrame()->toHtml().toStdString();
}

void SUI::WebViewImpl::setZoomFactor(const double factor)
{

    getWidget()->setZoomFactor(factor);
}

double SUI::WebViewImpl::getZoomFactor() const
{
    return getWidget()->zoomFactor();
}

QWebView* SUI::WebViewImpl::getWidget() const
{
    return dynamic_cast<QWebView*>(BaseWidget::getWidget());
}


