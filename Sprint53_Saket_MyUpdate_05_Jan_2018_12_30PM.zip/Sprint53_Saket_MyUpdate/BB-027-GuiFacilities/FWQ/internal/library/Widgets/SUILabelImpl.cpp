//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::LabelImpl.
// !\description Class implementation file for SUI::LabelImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUILabelImpl.h"
#include "SUIStyleSheet.h"

#include <QStyle>
#include <QEvent>
#include <QVariant>


#include "FWQxCore/SUIArgumentException.h"


SUI::LabelImpl::LabelImpl(QWidget *parent) :
    BaseWidget(new CustomLabel(parent), SUI::ObjectType::Label, false),
    mHighLightText(QString::null)
{
    exposeWidthProperty();
}

void SUI::LabelImpl::setDefaultProperties(const ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "30");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Alignment, "Left");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "200");
    setFontSize(FontSizeEnum::Normal);

    switch (context)
    {
    case EditorSelector:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, QString::fromStdString(SUI::ObjectType::toString(Object::getObjectType())));
        break;

    case EditorForm:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, "TBD");
        break;

    default:
        break;
    }
}

void SUI::LabelImpl::setText(const std::string &value) {
    QLabel *label = getWidget();
    if (label->text() == QString::fromStdString(value)) return;
    label->setText(QString::fromStdString(value));
    if (getPropertyValue(SUI::ObjectPropertyTypeEnum::PropScientific).toLower() == "true") setPropScientific();
    //clears highlighttext if set
    if(!getHighlightText().empty()) setHighlightText("", "#000000");
}

std::string SUI::LabelImpl::getText() const {
    return getWidget()->text().toStdString();
}

void SUI::LabelImpl::clearText() {
    setText("");
}


SUI::ColorEnum::Color SUI::LabelImpl::getColor() const {
    return SUI::ColorEnum::fromString(getPropertyValue(SUI::ObjectPropertyTypeEnum::Color).toStdString());
}

void SUI::LabelImpl::setColor(const SUI::ColorEnum::Color color) {
    if (!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color)) return;
    if (SUI::ColorEnum::fromString(getProperty(SUI::ObjectPropertyTypeEnum::Color)->getValue().toStdString()) != color) {
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Color, QString::fromStdString(ColorEnum::toString(color)));
    }
    getWidget()->setProperty("ColorSet", QString::fromStdString(ColorEnum::toString(color)).toLower());
    getWidget()->style()->polish(getWidget());
}

SUI::ColorEnum::Color SUI::LabelImpl::getBGColor() const {
    return ColorEnum::fromString(getPropertyValue(SUI::ObjectPropertyTypeEnum::BGColor).toStdString());
}

void SUI::LabelImpl::setBGColor(const SUI::ColorEnum::Color color) {
    if (!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color)) return;
    if (SUI::ColorEnum::fromString(getProperty(SUI::ObjectPropertyTypeEnum::BGColor)->getValue().toStdString()) != color) {
        setPropertyValue(SUI::ObjectPropertyTypeEnum::BGColor, QString::fromStdString(ColorEnum::toString(color)));
    }
    getWidget()->setProperty("BGColorSet", QString::fromStdString(ColorEnum::toString(color)).toLower());
    getWidget()->style()->polish(getWidget());
}

void SUI::LabelImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID, propertyValue);

    switch (propertyID) {
    case SUI::ObjectPropertyTypeEnum::Alignment:
        setAlignment(AlignmentEnum::fromString(propertyValue.toStdString()));
        break;

    case SUI::ObjectPropertyTypeEnum::FontSize:
        setFontSize(FontSizeEnum::fromString(propertyValue.toStdString()));
        break;

        //When the Scientific is set, the label is set to scientific
    case SUI::ObjectPropertyTypeEnum::PropScientific:
        if (propertyValue.toLower() == "true") setPropScientific();
        break;

    case SUI::ObjectPropertyTypeEnum::Bold:
        setBold((propertyValue.compare("true", Qt::CaseInsensitive) == 0));
        break;

    case SUI::ObjectPropertyTypeEnum::Text:
        setText(propertyValue.toStdString());
        break;

    case SUI::ObjectPropertyTypeEnum::Color:
        setColor(SUI::ColorEnum::fromString(propertyValue.toStdString()));
        break;

    case SUI::ObjectPropertyTypeEnum::BGColor:
        setBGColor(SUI::ColorEnum::fromString(propertyValue.toStdString()));
        break;

    default:
        break;
    }
}

CustomLabel *SUI::LabelImpl::getWidget() const {
    return qobject_cast<CustomLabel *>(BaseWidget::getWidget());
}

void SUI::LabelImpl::setAlignment(AlignmentEnum::Alignment align) {
    if (align == SUI::AlignmentEnum::Stretch) return;
    if (SUI::AlignmentEnum::fromString(getProperty(SUI::ObjectPropertyTypeEnum::Alignment)->getValue().toStdString()) != align) {
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Alignment, QString::fromStdString(AlignmentEnum::toString(align)));
    }
    Qt::Alignment   qtAlign;
    switch (align)
    {
    case AlignmentEnum::Right:
        qtAlign = Qt::AlignRight;
        break;
    case AlignmentEnum::Left:
        qtAlign = Qt::AlignLeft;
        break;
    default:
        qtAlign = Qt::AlignHCenter;
        break;
    }

    // When setting alignment, Qt::AlignVCenter has to be passed too to
    // align text correctly vertically
    getWidget()->setAlignment(qtAlign | Qt::AlignVCenter);
}

SUI::AlignmentEnum::Alignment SUI::LabelImpl::getAlignment() const {
    return SUI::AlignmentEnum::fromString(getPropertyValue(SUI::ObjectPropertyTypeEnum::Alignment).toStdString());
}

void SUI::LabelImpl::setFontSize(const FontSizeEnum::FontSize &fontSize) {
    if(fontSize == FontSizeEnum::Uninitialized) return;
    QFont font = getWidget()->font();
    switch (fontSize)
    {
    case FontSizeEnum::Big:
        font.setPointSize(SUI::FontSizeEnum::SUI_FONTPOINTSIZE_LARGE);
        break;
    case FontSizeEnum::Small:
        font.setPointSize(SUI::FontSizeEnum::SUI_FONTPOINTSIZE_SMALL);
        break;
    default:
        font.setPointSize(SUI::FontSizeEnum::SUI_FONTPOINTSIZE_NORMAL);
        break;
    }
    getWidget()->setFont(font);
}

SUI::FontSizeEnum::FontSize SUI::LabelImpl::getFontSize() const {
    if (getWidget()->font().pointSize() == SUI::FontSizeEnum::SUI_FONTPOINTSIZE_LARGE) return FontSizeEnum::Big;
    if (getWidget()->font().pointSize() == SUI::FontSizeEnum::SUI_FONTPOINTSIZE_SMALL) return FontSizeEnum::Small;
    if (getWidget()->font().pointSize() == SUI::FontSizeEnum::SUI_FONTPOINTSIZE_NORMAL) return FontSizeEnum::Normal;

    return FontSizeEnum::Uninitialized;
}


/*****************************************************************************\
 *  FUNCTION    :   setPropScientific
 *  RETURN      :   void
  \*****************************************************************************/
void SUI::LabelImpl::setPropScientific()
{
    QString valueStr = getWidget()->text();
    //check if the text contains only numbers
    bool isNumber = false;
    double dValue = valueStr.toDouble(&isNumber);
    if(isNumber)
    {
        valueStr.setNum(dValue, 'e', 2);
        valueStr.replace("e-0", "e-");
        valueStr.replace("e+", "e");
        valueStr.replace("e0", "e");
        getWidget()->setText(valueStr);
    }
}

void SUI::LabelImpl::setHighlightText(const std::string &searchText, const std::string &color) {
    mHighLightText = QString::null;
    if(!QColor ::isValidColor(QString::fromStdString(color))) return;
    if(static_cast<CustomLabel*>(BaseWidget::getWidget())->setHighlightText(QString::fromStdString(searchText), QColor(QString::fromStdString(color)))) {
        mHighLightText = QString::fromStdString(searchText);
    }
}

std::string SUI::LabelImpl::getHighlightText() const {
    return mHighLightText.toStdString();
}

void SUI::LabelImpl::setBold(bool bold) {
    getWidget()->setProperty("SUIFont", QVariant::fromValue<QString>(bold ? "bold" : ""));
    getWidget()->style()->polish(getWidget());
}

bool SUI::LabelImpl::isBold() const {
    return getWidget()->property("SUIFont").toString() == "bold";
}

bool SUI::LabelImpl::eventFilter(QObject *obj, QEvent *event) {
    if (event->type() == QEvent::MouseButtonRelease && !clicked.empty())
    {
        clicked();
    }
    return BaseWidget::eventFilter(obj, event);
}
