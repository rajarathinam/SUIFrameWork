//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::BasePageImpl.
// !\description Class implementation file for SUI::BasePageImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIBasePageImpl.h"

SUI::BasePageImpl::BasePageImpl(QWidget *widget, SUI::ObjectType::Type widgetType, bool supportsChildren) :
    SUI::BaseWidget(widget, widgetType, supportsChildren)
{
    setPropertyReadonly(SUI::ObjectPropertyTypeEnum::XPos);
    setPropertyReadonly(SUI::ObjectPropertyTypeEnum::YPos);
    setPropertyReadonly(SUI::ObjectPropertyTypeEnum::Height);
    setPropertyReadonly(SUI::ObjectPropertyTypeEnum::Width);
    setPropertyReadonly(SUI::ObjectPropertyTypeEnum::Enable);
    BasePageImpl::getWidget()->setAttribute(Qt::WA_TranslucentBackground);
}

SUI::BasePageImpl::~BasePageImpl() {
    mTablist.clear();
}

void SUI::BasePageImpl::setDefaultProperties(const SUI::BaseObject::ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable, "false");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Sizeable, "false");
}

int SUI::BasePageImpl::addTabOrder(QString position, QString widgetId) {
    int idx = -1;
    if (position != "") idx = mTablist.key(widgetId);

    if (idx < 0) {
        if (position == "") {
            if (!mTablist.isEmpty()) {
                mTablist.insert(mTablist.uniqueKeys().last() + 1, widgetId);
            }
            else {
                mTablist.insert(0, widgetId);
            }
        }
        else {
           mTablist.insert(position.toInt(), widgetId);
        }
    }
    else {
        // needed for correct reordering of the ID's
        if (mTablist.value(idx) == widgetId) {
            mTablist.remove(idx);
            lineUp();
        }

        if (mTablist.contains(position.toInt())) {
            insert(position.toInt());
        }
        mTablist.insert(position.toInt(), widgetId);
    }
    return mTablist.key(widgetId);
}

int SUI::BasePageImpl::replaceTabOrderWidget(QString oldID, QString newID) {
    int idx = mTablist.key(oldID);
    if (mTablist.contains(idx)) {
        mTablist[idx] = newID;
    }
    else {
        idx = -1;
    }
    return idx;
}

void SUI::BasePageImpl::removeTabOrder(QString widgetId) {
    mTablist.remove(mTablist.key(widgetId));
    lineUp();
}

QMap<int, QString> SUI::BasePageImpl::getTablist() const {
    return mTablist;
}

int SUI::BasePageImpl::indexof(QString widgetId) {
    return mTablist.key(widgetId);
}

void SUI::BasePageImpl::insert(int position) {
    QMapIterator<int, QString> i(mTablist);
    i.toBack();
    while (i.hasPrevious()) {
        i.previous();
        if (i.key() >= position) {
            mTablist.insert(i.key() + 1, i.value());
            mTablist.remove(i.key());
        }
    }
}

void SUI::BasePageImpl::lineUp() {
    int x = 0;
    QMapIterator<int, QString> i(mTablist);
    while (i.hasNext()) {
        i.next();
        if (i.key() != x) {
            mTablist.insert(x, i.value());
            mTablist.remove(i.key());
        }
        x++;
    }
}
