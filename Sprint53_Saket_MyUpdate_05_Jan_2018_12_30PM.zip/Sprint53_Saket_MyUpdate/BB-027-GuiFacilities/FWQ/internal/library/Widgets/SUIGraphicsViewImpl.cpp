//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::GraphicsViewImpl.
// !\description Class implementation file for SUI::GraphicsViewImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIGraphicsViewImpl.h"

#include "FWQxGraphicsItems/SUIGraphicsItem.h"
#include "SUIObjectFactoryImpl.h"
#include "FWQxGraphicsItems/SUIGraphicsScene.h"
#include "CustomGraphicsScene.h"

SUI::GraphicsViewImpl::GraphicsViewImpl(QWidget *parent) :
    BaseWidget(new CustomGraphicsView(parent), SUI::ObjectType::GraphicsView, false),
    GraphicsView()
{
    // set the graphicsscene
    GraphicsViewImpl::getWidget()->setScene(static_cast<CustomGraphicsScene*>(GraphicsView::getGraphicsScene()->implementation));
    
    // default scrollbars disabled
    GraphicsViewImpl::getWidget()->setScrollBarsEnabled(false);
    
    // strong focus policy needed for mouse actions when external scrollbars are visible
    GraphicsViewImpl::getWidget()->setFocusPolicy(Qt::StrongFocus);
    
    // default pain panel 
    GraphicsViewImpl::getWidget()->setFrameShadow(QFrame::Plain);
    GraphicsViewImpl::getWidget()->setFrameShape(QFrame::Panel);
    
    // smooth rendering
    GraphicsViewImpl::getWidget()->setRenderHints(/*QPainter::Antialiasing | */QPainter::SmoothPixmapTransform | QPainter::TextAntialiasing);

    // mousetracking needed for multiple reasons, zooming, moving items etc.
    GraphicsViewImpl::getWidget()->setMouseTracking(true);
    
    // for mouse zooming, the center point will be on the mouse
    GraphicsViewImpl::getWidget()->setTransformationAnchor(QGraphicsView::AnchorUnderMouse);
    
    // full update needed for everything to redraw correctly in every condition
   GraphicsViewImpl::getWidget()->setViewportUpdateMode(QGraphicsView::FullViewportUpdate);

    // default drag mode
    GraphicsViewImpl::getWidget()->setDragMode(QGraphicsView::ScrollHandDrag);

    // calls the visibilityChanged boost callbacks
    connect(GraphicsViewImpl::getWidget(), SIGNAL(visibilityChanged(bool)), this, SLOT(onVisibilityChanged(bool)));

    // is triggered when the scenerect changed, it happens whenever the background changed.
    connect(GraphicsViewImpl::getWidget()->scene(), SIGNAL(sceneRectChanged(QRectF)), GraphicsViewImpl::getWidget(), SLOT(onSceneRectChanged(QRectF)));

    exposeHeightProperty();
    exposeWidthProperty();
}

SUI::GraphicsViewImpl::~GraphicsViewImpl() {
    disconnect(GraphicsViewImpl::getWidget()->scene(), SIGNAL(sceneRectChanged(QRectF)), GraphicsViewImpl::getWidget(), SLOT(onSceneRectChanged(QRectF)));
    disconnect(GraphicsViewImpl::getWidget(), SIGNAL(visibilityChanged(bool)), this, SLOT(onVisibilityChanged(bool)));
}

CustomGraphicsView *SUI::GraphicsViewImpl::getWidget() const {
    return dynamic_cast<CustomGraphicsView *>(BaseWidget::getWidget());
}

void SUI::GraphicsViewImpl::setGeometry() {
    BaseWidget::setGeometry();
}

void SUI::GraphicsViewImpl::setDefaultProperties(const SUI::BaseObject::ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);

    switch (context) {
    case EditorSelector:
        setPropertyValue(ObjectPropertyTypeEnum::Height, "200");
        setPropertyValue(ObjectPropertyTypeEnum::Width, "600");
        break;
    case EditorForm:
        setPropertyValue(ObjectPropertyTypeEnum::Height, "200");
        setPropertyValue(ObjectPropertyTypeEnum::Width, "400");
        break;
    default:
        break;
    }
}

void SUI::GraphicsViewImpl::onVisibilityChanged(bool visible) {
    if (!visibilityChanged.empty()) visibilityChanged(visible);
}

int SUI::GraphicsViewImpl::getBorderWidth() const {
    return 3;
}

void SUI::GraphicsViewImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID, propertyValue);
    switch (propertyID) {
    
    case SUI::ObjectPropertyTypeEnum::ImageData:
        getGraphicsScene()->setBackgroundImage(propertyValue.toStdString());
        break;

    case SUI::ObjectPropertyTypeEnum::ScrollBars:
        setScrollBarsEnabled(propertyValue.toLower() == "true");
        break;

    case SUI::ObjectPropertyTypeEnum::AutoFitBG:
        setAspectRatioMode(AspectRatioEnum::fromString(propertyValue.toLower().toStdString()));
        break;

    case SUI::ObjectPropertyTypeEnum::ZoomStyle:
        setDragMode(DragModeEnum::fromString(propertyValue.toLower().toStdString()));
        break;

    case SUI::ObjectPropertyTypeEnum::ScrollZoom:
        setMouseWheelZoomEnabled(propertyValue.toLower() == "true");
        break;

    case SUI::ObjectPropertyTypeEnum::BorderOn:
        getWidget()->setLineWidth(propertyValue.toLower() == "true" ? getBorderWidth() : 0);
        break;

    default:
        break;
    }
}
