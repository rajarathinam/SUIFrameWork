//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::TableWidgetImpl.
// !\description Class implementation file for SUI::TableWidgetImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUITableWidgetImpl.h"

#include <QHeaderView>
#include <QHBoxLayout>
#include <QStandardItemModel>
#include <QLabel>
#include <boost/foreach.hpp>

#include "CustomTableItemModel.h"
#include "CustomSortFilterProxy.h"
#include "CustomTableItemDelegate.h"
#include "CustomTableHeaderView.h"

#include "FWQxCore/SUIObjectList.h"
#include "SUITableWidgetItemImpl.h"
#include "SUIStyleSheet.h"
#include "FWQxCore/SUIObjectFactory.h"

#include "SUIDialogSerializer.h"
#include "FWQxCore/SUIXmlException.h"
#include "FWQxCore/SUIIOException.h"
#include "FWQxCore/SUIResourcePath.h"

SUI::TableWidgetImpl::TableWidgetImpl(QWidget *parent, SUI::ObjectList *objectList) :
    BaseWidget(new QTableView(parent), SUI::ObjectType::TableWidget, true),
    TableWidget(),
    mInitDone(false),
    mObjectList(objectList),
    mPreviousUCFileName(QString::null),
    mUserCtrlDefn(NULL),
    mPrevSelectionBehavior(QAbstractItemView::SelectItems),
    mPrevSelectionMode(QAbstractItemView::SingleSelection)
{
    CustomTableItemModel *itemModel = new CustomTableItemModel(TableWidgetImpl::getWidget(),mObjectList);
    CustomSortFilterProxy *sortFilterProxy = new CustomSortFilterProxy(TableWidgetImpl::getWidget());

    TableWidgetImpl::getWidget()->setHorizontalHeader(new CustomTableHeaderView(Qt::Horizontal,TableWidgetImpl::getWidget()));
    TableWidgetImpl::getWidget()->setVerticalHeader(new CustomTableHeaderView(Qt::Vertical,TableWidgetImpl::getWidget()));

    TableWidgetImpl::getWidget()->horizontalHeader()->setModel(itemModel->getHeaderModel(Qt::Horizontal));
    TableWidgetImpl::getWidget()->verticalHeader()->setModel(itemModel->getHeaderModel(Qt::Vertical));

    sortFilterProxy->setSourceModel(itemModel);
    TableWidgetImpl::getWidget()->setModel(sortFilterProxy);

    TableWidgetImpl::getWidget()->setFrameShadow(QFrame::Plain);
    TableWidgetImpl::getWidget()->setFrameShape(QFrame::Panel);
    TableWidgetImpl::getWidget()->setItemDelegate(new CustomTableItemDelegate(TableWidgetImpl::getWidget()));

    exposeHeightProperty();
    exposeWidthProperty();

    setPropertyReadonly(ObjectPropertyTypeEnum::RowCount);
    setPropertyReadonly(ObjectPropertyTypeEnum::ColumnCount);
    setPropertyReadonly(ObjectPropertyTypeEnum::BorderWidth);
    setPropertyHidden(ObjectPropertyTypeEnum::HorizontalHeaderTags);
    setPropertyHidden(ObjectPropertyTypeEnum::VerticalHeaderTags);

    connect(TableWidgetImpl::getWidget()->selectionModel(), SIGNAL(selectionChanged(QItemSelection,QItemSelection)), this, SLOT(onSelectionChanged(QItemSelection,QItemSelection)));
    connect(TableWidgetImpl::getWidget()->horizontalHeader(), SIGNAL(clicked(QModelIndex)), this, SLOT(onHorizontalHeaderClicked(QModelIndex)));
    connect(TableWidgetImpl::getWidget()->verticalHeader(), SIGNAL(clicked(QModelIndex)), this, SLOT(onHorizontalHeaderClicked(QModelIndex)));
    connect(TableWidgetImpl::getWidget(), SIGNAL(clicked(QModelIndex)), this, SLOT(onTableViewClicked(QModelIndex)));
    connect(itemModel,SIGNAL(headerDataChanged()),this,SLOT(onHeaderDataChanged()));
    TableWidgetImpl::getWidget()->updateGeometry();
    initialize();
}

SUI::TableWidgetImpl::~TableWidgetImpl()
{
    if (TableWidgetImpl::getWidget()->model() != NULL) {
        QAbstractItemModel *m = TableWidgetImpl::getWidget()->model();
        TableWidgetImpl::getWidget()->setModel(NULL);
        m->deleteLater();
    }
}

void SUI::TableWidgetImpl::initialize() {
    bool headersOn = getPropertyValue(ObjectPropertyTypeEnum::HeadersOn).toLower() == "true";
    getWidget()->horizontalHeader()->setVisible(headersOn);
    getWidget()->verticalHeader()->setVisible(headersOn);
    getWidget()->setMouseTracking(true);
    updateTable();
}

void SUI::TableWidgetImpl::setDefaultProperties(const ObjectContext &context) {
    BaseWidget::setObjectContext(context);

    setPropertyValue(ObjectPropertyTypeEnum::BorderOn, "false");
    setPropertyValue(ObjectPropertyTypeEnum::Height, QString::number(200));
    setPropertyValue(ObjectPropertyTypeEnum::Width, QString::number(200));
    setPropertyValue(ObjectPropertyTypeEnum::ColumnCount, QString::number(1));
    setPropertyValue(ObjectPropertyTypeEnum::RowCount, QString::number(1));

    switch (context) {
    case EditorSelector:
        setPropertyValue(ObjectPropertyTypeEnum::Height, "200");
        setPropertyValue(ObjectPropertyTypeEnum::Width, "400");
        getWidget()->horizontalHeader()->setVisible(true);
        getWidget()->verticalHeader()->setVisible(true);
        break;

    case EditorForm:
        setPropertyValue(ObjectPropertyTypeEnum::Height, "200");
        setPropertyValue(ObjectPropertyTypeEnum::Width, "400");
        getWidget()->horizontalHeader()->setVisible(false);
        getWidget()->verticalHeader()->setVisible(false);
        break;

    default:
        break;
    }
    updateTable();
}

QTableView *SUI::TableWidgetImpl::getWidget() const {
    return qobject_cast<QTableView *>(BaseWidget::getWidget());
}

void SUI::TableWidgetImpl::clearItems() {
    removeHeaders();
    getWidget()->model()->removeRows(0,getWidget()->model()->rowCount());
}

std::list<std::string> SUI::TableWidgetImpl::getItems() const {
    std::list<std::string> itemList;
    for (int row = 0, rows = rowCount(); row < rows; ++row) {
        for (int column = 0, columns = columnCount(); column < columns; ++column) {
            itemList.push_back(getWidgetItem(row, column)->getId());
        }
    }
    return itemList;
}

void SUI::TableWidgetImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID, propertyValue);

    switch (propertyID) {
    case SUI::ObjectPropertyTypeEnum::ColumnWidths: {
        QStringList widthList = propertyValue.split(";", QString::SkipEmptyParts);
        for (int ind = 0; ind < widthList.size(); ind++) {
            QStringList columnWidth = widthList.at(ind).split(",");
            getWidget()->setColumnWidth(columnWidth.at(0).toInt(), columnWidth.at(1).toInt());
        }
        break;
    }
    case SUI::ObjectPropertyTypeEnum::RowHeights: {
        QStringList heightList = propertyValue.split(";", QString::SkipEmptyParts);
        for (int ind = 0; ind < heightList.size(); ind++) {
            QStringList rowHeight = heightList.at(ind).split(",");
            getWidget()->setRowHeight(rowHeight.at(0).toInt(), rowHeight.at(1).toInt());
        }
        break;
    }
    case SUI::ObjectPropertyTypeEnum::ListViewMode:
        setListViewMode(propertyValue.toLower() == "true");
        break;

    case SUI::ObjectPropertyTypeEnum::BorderWidth:
        getWidget()->setLineWidth(propertyValue.toInt());
        break;

    case SUI::ObjectPropertyTypeEnum::MultipleRowSelection:
        getWidget()->setSelectionMode(propertyValue.toLower() == "true" ? QAbstractItemView::ExtendedSelection : QAbstractItemView::SingleSelection);
        break;

    case SUI::ObjectPropertyTypeEnum::BorderOn:
        getWidget()->setLineWidth(propertyValue.toLower() == "true" ? getPropertyValue(ObjectPropertyTypeEnum::BorderWidth).toInt() : 0);
        break;

    case SUI::ObjectPropertyTypeEnum::HeadersOn:
        if (propertyValue.toLower() == "true") {
            readHeaderTags();
        }
        else {
            removeHeaders();
        }
        break;

    case SUI::ObjectPropertyTypeEnum::HorizontalHeaderTags:
        readHeaderTags();
        break;

    case SUI::ObjectPropertyTypeEnum::VerticalHeaderTags:
        readHeaderTags();
        break;

    default:
        break;
    }
}

void SUI::TableWidgetImpl::showGrid(const bool bShow) {
    getWidget()->setShowGrid(bShow);
}

void SUI::TableWidgetImpl::appendRow(const std::string &headertag) {
    int columns = columnCount();
    int rows = rowCount();
    if (headertag.empty()) {
        QString newTag = QString::fromStdString(headertag);
        newTag.prepend("<").append(">");
        setPropertyValue(SUI::ObjectPropertyTypeEnum::VerticalHeaderTags, getPropertyValue(SUI::ObjectPropertyTypeEnum::VerticalHeaderTags).append(newTag));
    }
    if (columns > 0 && rows > 0) {
        getWidget()->model()->insertRows(rows, 1);
        for (int column = 0; column < columns; ++column) {
            Widget *bwAboveWidget = static_cast<Widget*>(getWidget()->model()->data(getWidget()->model()->index(rows - 1, column),CustomTableItemModel::WidgetRole).value<void*>());
            BaseWidget *bwAbove = SUI::ObjectFactory::getInstance()->toBaseWidget(bwAboveWidget);

            if(bwAbove->getObjectType() == SUI::ObjectType::UserControl) {
                QString filename = bwAbove->getPropertyValue(SUI::ObjectPropertyTypeEnum::FileName);
                if(filename != mPreviousUCFileName) {
                    mPreviousUCFileName = filename;
                    if(mUserCtrlDefn != NULL) {
                        delete mUserCtrlDefn;
                        mUserCtrlDefn = NULL;
                    }
                    mUserCtrlDefn = new GUIViewerWidgetController();
                    SUI::DialogSerializer mySerializer("UserControl", SUI::DialogSerializer::Read);
                    try{
                        mySerializer.openFile(QString::fromStdString(SUI::ResourcePath::getResourceFile(filename.toStdString())));
                        mySerializer.acceptVisitor(*mUserCtrlDefn);
                    }
                    catch(SUI::XmlException *re){
                        std::cerr << "XmlException " << re->getExceptionMessage() << std::endl;
                        exit(1);
                    }
                    catch(SUI::IOException *re){
                        std::cerr << "IOException " << re->getExceptionMessage() << std::endl;
                        exit(1);
                    }
                }

                SUI::BaseWidget  *userCtrlBaseWidget = mUserCtrlDefn->addToWidget(this->getWidget(), *mObjectList, mTabOrder, NULL, QString::fromStdString(bwAbove->getId()));
                userCtrlBaseWidget->setVisible(false);
                userCtrlBaseWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::FileName, filename);
                Widget *userCtrlWidget = dynamic_cast<Widget*>(SUI::ObjectFactory::getInstance()->toObject(userCtrlBaseWidget));
                updateCell(rows, column, SUI::AlignmentEnum::Stretch, userCtrlWidget);
                userCtrlBaseWidget->setVisible(true);
            } else {
                BaseWidget *newWidget = SUI::ObjectFactory::getInstance()->createWidget(SUI::ObjectFactory::getInstance()->toObject(bwAbove)->getObjectType(), this->getWidget());
                newWidget->setVisible(false);
                BOOST_FOREACH (const SUI::ObjectPropertyTypeEnum::Type &propertyID, bwAbove->getPropertyTypes()) {
                    if (propertyID != SUI::ObjectPropertyTypeEnum::TabOrder) {
                        if (propertyID == SUI::ObjectPropertyTypeEnum::ID)
                        {
                            QString tableID = QString::fromStdString(Object::getId()).prepend("%1-").append(":%2-%3");
                            QString newID = tableID.arg(QString::fromStdString(SUI::ObjectType::getIdPrefix(newWidget->getObjectType()))).arg(rows + 1).arg(column + 1);
                            newWidget->setPropertyValue(propertyID, newID);
                        } else {
                            newWidget->setPropertyValue(propertyID, bwAbove->getPropertyValue(propertyID));
                        }
                    }

                }
                QString alignmentProperty = bwAbove->getPropertyValue(SUI::ObjectPropertyTypeEnum::CellAlignment);
                newWidget->addCellProperties(SUI::AlignmentEnum::fromString((alignmentProperty.size() == 0) ? "stretch" : alignmentProperty.toLower().toStdString()) , bwAbove->getPropertyValue(SUI::ObjectPropertyTypeEnum::CellName).toStdString());

                Widget *w = dynamic_cast<Widget*>(SUI::ObjectFactory::getInstance()->toObject(newWidget));
                SUI::AlignmentEnum::Alignment alignment = SUI::AlignmentEnum::fromString(SUI::ObjectFactory::getInstance()->toBaseObject(w)->getPropertyValue(SUI::ObjectPropertyTypeEnum::CellAlignment).toLower().toStdString());
                updateCell(rows,column,alignment,w);
                newWidget->setVisible(true);
            }
        }
    }
    updateTable();
}

void SUI::TableWidgetImpl::removeRow(int row) {
    int rows = getWidget()->model()->rowCount();
    if (row < rows && rows > 0 && row >= 0) {
        getWidget()->model()->removeRows(row, 1);
        updateTable();
    }
}

std::string SUI::TableWidgetImpl::getCellID(int row, int column) const {
    std::string retStr;
    if (row < rowCount() && column < columnCount() && row > -1 && column > -1) {
        retStr = getWidgetItem(row, column)->getId();
    }
    return retStr;
}

SUI::ObjectType::Type SUI::TableWidgetImpl::getCellType(int row, int column) const {
    if (row < rowCount() && column < columnCount() && row > -1 && column > -1) {
        return static_cast<ObjectType::Type>(getWidget()->model()->data(getWidget()->model()->index(row,column),CustomTableItemModel::ObjectTypeRole).toInt());
    }
    return SUI::ObjectType::None;
}

int SUI::TableWidgetImpl::rowCount() const {
    return getWidget()->model()->rowCount();
}

int SUI::TableWidgetImpl::columnCount() const {
    return getWidget()->model()->columnCount();
}

void SUI::TableWidgetImpl::setFilter(const std::string &filter, bool enabled, int col, bool caseSensitive) {
    if (col == -1) { // if column is -1, apply filter to all columns
        for (int column = 0, columns = columnCount(); column < columns; column++) {
            qobject_cast<CustomSortFilterProxy*>(getWidget()->model())->setColumnFilterFixedString(column,enabled ? QString::fromStdString(filter) : "",caseSensitive ? Qt::CaseSensitive : Qt::CaseInsensitive);
        }
    }
    else { // else, decrease column, interface is one-based
        qobject_cast<CustomSortFilterProxy*>(getWidget()->model())->setColumnFilterFixedString(col,enabled ? QString::fromStdString(filter) : "",caseSensitive ? Qt::CaseSensitive : Qt::CaseInsensitive);
    }
}

void SUI::TableWidgetImpl::setListViewMode(bool on) {
    if (on) {
        mPrevSelectionBehavior = getWidget()->selectionBehavior();
        mPrevSelectionMode = getWidget()->selectionMode();
        getWidget()->setSelectionBehavior(QAbstractItemView::SelectRows);
        getWidget()->setSelectionMode(getPropertyValue(SUI::ObjectPropertyTypeEnum::MultipleRowSelection).toLower() == "true" ?
                        QAbstractItemView::ExtendedSelection : QAbstractItemView::SingleSelection);
        qobject_cast<CustomTableItemDelegate *>(getWidget()->itemDelegate())->setHoverBehavior(CustomTableItemDelegate::HoverRows);
    }
    else {
        getWidget()->setSelectionBehavior(mPrevSelectionBehavior);
        getWidget()->setSelectionMode(mPrevSelectionMode);
        qobject_cast<CustomTableItemDelegate *>(getWidget()->itemDelegate())->setHoverBehavior(CustomTableItemDelegate::HoverItems);
    }
}

std::list<std::string> SUI::TableWidgetImpl::getSelectedItems() const {
    std::list<std::string> strList;
    QModelIndexList modelList = getWidget()->selectionModel()->selectedIndexes();
    BOOST_FOREACH (QModelIndex index, modelList) {
        if (index.isValid()) {
            strList.push_back(getWidget()->model()->data(index,CustomTableItemModel::IDRole).toString().toStdString());
        }
    }
    return strList;
}

void SUI::TableWidgetImpl::addItems(const std::list<std::string> &) { }

void SUI::TableWidgetImpl::removeItems(const std::list<std::string> &)  { }

std::list<std::string> SUI::TableWidgetImpl::getColumnItems(int column) const {
    std::list<std::string> strList;
    if (column < columnCount()) {
        for (int row = 0; row < rowCount(); row++) {
            strList.push_back(getWidget()->model()->data(getWidget()->model()->index(row, column),Qt::DisplayRole).toString().toStdString());
        }
    }
    return strList;
}

std::list<std::string> SUI::TableWidgetImpl::getRowItems(int row) const {
    std::list<std::string> strList;
    if (row < rowCount()) {
        for (int column = 0; column < columnCount(); column++) {
            strList.push_back(getWidget()->model()->data(getWidget()->model()->index(row, column),Qt::DisplayRole).toString().toStdString());
        }
    }
    return strList;
}

void SUI::TableWidgetImpl::selectItem(int row, int column) {
    getWidget()->clearSelection();
    QModelIndex index = getWidget()->model()->index(row, column);
    if (getWidget()->selectionBehavior() == QAbstractItemView::SelectRows) {
        getWidget()->selectRow(row);
    }
    else {
        getWidget()->selectionModel()->select(index, QItemSelectionModel::Select);
    }
}

void SUI::TableWidgetImpl::selectItem(const std::string idstr) {
    QString strID = QString::fromStdString(idstr);
    bool bFound = false;
    for (int row = 0; (row < rowCount()) && !bFound; row++) {
        for (int column = 0; (column < columnCount()) && !bFound; column++) {
            if (getWidget()->model()->data(getWidget()->model()->index(row,column),CustomTableItemModel::IDRole).toString() == strID) {
                bFound = true;
                selectItem(row, column);
            }
        }
    }
}

void SUI::TableWidgetImpl::addData(int row, const std::list<std::string> &data) {
    if (rowCount() == 0) insertRows(0,1);
    if (row >= rowCount()) insertRows(rowCount(),row-rowCount()+1);

    if (row >= 0 && row < rowCount()) {
        int dataSize = static_cast<int>(data.size());
        std::list<std::string>::const_iterator it = data.begin();
        for (int column = 0; (column < columnCount()) && (column < dataSize); column++) {
            bool wasSet = getWidget()->model()->setData(getWidget()->model()->index(row,column),QVariant(QString::fromStdString(*it)),Qt::DisplayRole);
            if (wasSet) ++it;
        }
    }
}

void SUI::TableWidgetImpl::onHorizontalHeaderClicked(QModelIndex index) {
    if (horizontalHeaderCellClicked.empty() == false) {
        horizontalHeaderCellClicked(index.row(),index.column(),index.data(Qt::DisplayRole).toString().toStdString());
    }
}

void SUI::TableWidgetImpl::onVerticalHeaderClicked(QModelIndex index) {
    if (verticalHeaderCellClicked.empty() == false) {
        verticalHeaderCellClicked(index.row(),index.column(),index.data(Qt::DisplayRole).toString().toStdString());
    }
}

void SUI::TableWidgetImpl::onHeaderDataChanged() {
    QStandardItemModel *horizontalHeaderModel = qobject_cast<QStandardItemModel*>(getWidget()->model()->data(QModelIndex(),CustomTableItemModel::HorizontalHeaderRole).value<QObject*>());
    QStandardItemModel *verticalHeaderModel = qobject_cast<QStandardItemModel*>(getWidget()->model()->data(QModelIndex(),CustomTableItemModel::VerticalHeaderRole).value<QObject*>());

    getWidget()->horizontalHeader()->setModel(horizontalHeaderModel);
    getWidget()->verticalHeader()->setModel(verticalHeaderModel);
}

void SUI::TableWidgetImpl::onTableViewClicked(QModelIndex) {
    //Rowclicked events
    if(rowClicked.empty() != true) rowClicked(getWidget()->currentIndex().row());
}

void SUI::TableWidgetImpl::updateTable() {
    if (getObjectContext() != SUI::BaseObject::Gui) {
        setPropertyValue(SUI::ObjectPropertyTypeEnum::RowCount, QString::number(rowCount()));
        setPropertyValue(SUI::ObjectPropertyTypeEnum::ColumnCount, QString::number(columnCount()));
        QStringList columnWidths;
        for (int column = 0; column < columnCount(); column++) {
            columnWidths.append(QString("%1,%2").arg(column).arg(getWidget()->columnWidth(column)));
        }
        setPropertyValue(SUI::ObjectPropertyTypeEnum::ColumnWidths, columnWidths.join(";"));

        QStringList rowHeights;
        for (int row = 0; row < rowCount(); row++) {
            rowHeights.append(QString("%1,%2").arg(row).arg(getWidget()->rowHeight(row)));
        }
        setPropertyValue(SUI::ObjectPropertyTypeEnum::RowHeights, rowHeights.join(";"));
    }

    QString tableID = QString::fromStdString(Object::getId()).prepend("%1-").append(":%2-%3");
    for (int row = 0, rows = rowCount(); row < rows; row++) {
        for (int column = 0, columns = columnCount(); column < columns; column++) {
            Widget *item = getWidgetItem(row,column);
            BaseObject *baseObj = SUI::ObjectFactory::getInstance()->toBaseObject(item);
            if (mObjectList != NULL) {
                if(baseObj->getPropertyTypes().contains(ObjectPropertyTypeEnum::TabOrder)) {
                    mObjectList->removeTabOrder(item->getId());
                }
                mObjectList->removeObject(item->getId());
            }
            QString newID = tableID.arg(QString::fromStdString(SUI::ObjectType::getIdPrefix(item->getObjectType()))).arg(row + 1).arg(column + 1);
            BaseObject *baseObject = SUI::ObjectFactory::getInstance()->toBaseObject(item);
            baseObject->setId(newID.toStdString());
            if (mObjectList != NULL) {
                mObjectList->addObject(newID.toStdString(), item);

                if(baseObject->getPropertyTypes().contains(ObjectPropertyTypeEnum::TabOrder)) {
                    mObjectList->addTabOrder(newID.toStdString());
                }
            }
        }
    }
    if (mObjectList != NULL) {
        mObjectList->setTabReOrder(true);
    }
    if (getObjectContext() != SUI::BaseObject::Gui) {
        readHeaderTags();
        getWidget()->update();
        getWidget()->repaint();
        getWidget()->horizontalHeader()->viewport()->update();
        getWidget()->verticalHeader()->viewport()->update();
        getWidget()->horizontalHeader()->viewport()->repaint();
        getWidget()->verticalHeader()->viewport()->repaint();
    }

}

/*****************************************************************************\
 *  FUNCTION    :   startReading
 *  PARAMETERS  :   int rowcnt
 *                      The number of rows that will be read.
 *                  int columncnt
 *                      The number of columns that will be read.
 *  RETURN      :   bool
 *                      Indicates success or failure
 *  This function has to be called before addNewTableWidgetItem() can be called.
 *  This is because the number of columns and rows has to be known in advance,
 *  for the index calculation in the addNewTableWidgetItem() function.
 *  This function starts with deleting all rows and columns. Then mDataContainer
 *  is initialized, so that it contains the proper number of items, to be
 *  assigned. Because of the mInitDone check, this function can be called
 *  multiple time during the read process. If all reading is finished,
 *  stopReading should be called.
 \****************************************************************************/
bool SUI::TableWidgetImpl::startReading(int rows, int columns) {
    if (!mInitDone) {
        getWidget()->model()->removeRows(0,getWidget()->model()->rowCount());
        getWidget()->model()->insertRows(0,rows);
        if (columns > 0) getWidget()->model()->insertColumns(1,columns-1);
        mCurReadRowInd = 0;
        mCurReadColumnInd = 0;
        mInitDone = true;
    }
    return mInitDone;
}

/*****************************************************************************\
 *  FUNCTION    :   stopReading
 *  PARAMETERS  :   void
 *  RETURN      :   bool
 *                      Indicates success or failure
 *  This function has to be called after all calls to addNewTableWidgetItem()
 *  have been done in a read process. It sets mInitDone to false, which is
 *  necessary for a new read process.
 \****************************************************************************/
bool SUI::TableWidgetImpl::stopReading() {
    mInitDone = false;
    updateTable();
    return !mInitDone;
}

/*****************************************************************************\
 *  FUNCTION    :   addNewTableWidgetItem
 *  PARAMETERS  :   TableWidgetItem *item
 *                      The TablewidgetItem to be assigned to mDataContainer.
 *  RETURN      :   void
 *
 *  Before this function is called the first time in a read process,
 *  startReading(), must have been called. mCurReadRowInd and mCurReadColumnInd
 *  are used to calculate where the new item should be assigned in
 *  mDataContainer.
 \****************************************************************************/
void SUI::TableWidgetImpl::addNewTableWidgetItem(Widget *newWidget) {
    if (mInitDone) {
        int columns = columnCount();
        int simpleIndex = mCurReadRowInd * columns + mCurReadColumnInd;
        int cellCount = rowCount() > 0 && columnCount() > 0 ? rowCount()*columnCount() : (rowCount() > 0 ? rowCount() : (columnCount() > 0 ? columnCount() : 0));
        if (simpleIndex < cellCount) {
            BaseObject *object = SUI::ObjectFactory::getInstance()->toBaseObject(newWidget);
            QString alignmentProperty = object->getPropertyValue(SUI::ObjectPropertyTypeEnum::CellAlignment);
            SUI::AlignmentEnum::Alignment alignment = SUI::AlignmentEnum::fromString((alignmentProperty.size() == 0) ? "stretch" : alignmentProperty.toLower().toStdString());
            updateCell(mCurReadRowInd,mCurReadColumnInd,alignment,newWidget);
            updateTable();
        }
        if (mCurReadColumnInd < (columns-1)) {
            ++mCurReadColumnInd;
        }
        else {
            ++mCurReadRowInd;
            mCurReadColumnInd = 0;
        }
    }
}

void SUI::TableWidgetImpl::insertRows(int pos, int count) {
    Q_ASSERT(pos >= 0);
    getWidget()->model()->insertRows(pos, count);
    updateTable();
}

void SUI::TableWidgetImpl::insertColumns(int pos, int count) {
    Q_ASSERT(pos >= 0);
    if (rowCount() == 0 && count > 1){
        getWidget()->model()->insertColumns(0, 1);
        getWidget()->model()->insertColumns(1, count-1);
    } else {
        getWidget()->model()->insertColumns(pos, count);
    }
    updateTable();
}

void SUI::TableWidgetImpl::assign(int row, int column, Widget *newWidget) {
    getWidget()->model()->setData(getWidget()->model()->index(row,column),qVariantFromValue(static_cast<void *>(newWidget)),CustomTableItemModel::WidgetRole);
}

bool SUI::TableWidgetImpl::removeRows(int pos, int count) {
    bool isRemoved = getWidget()->model()->removeRows(pos, count);
    updateTable();
    return isRemoved;
}

bool SUI::TableWidgetImpl::removeColumns(int pos, int count) {
    bool isRemoved = getWidget()->model()->removeColumns(pos, count);
    updateTable();
    return isRemoved;
}

void SUI::TableWidgetImpl::setCellWidgetType(int row, int column, Widget *newWidget) {
    if (row < rowCount() && column < columnCount() && newWidget != NULL) {
        BaseObject *object = SUI::ObjectFactory::getInstance()->toBaseObject(getWidgetItem(row,column));
        if (mObjectList != NULL) {
            if(object->getPropertyTypes().contains(ObjectPropertyTypeEnum::TabOrder)) {
                mObjectList->removeTabOrder(object->getId());
            }
            mObjectList->removeObject(object->getId());
        }
        SUI::AlignmentEnum::Alignment alignment = SUI::AlignmentEnum::fromString(object->getPropertyValue(SUI::ObjectPropertyTypeEnum::CellAlignment).toLower().toStdString());
        if(object->getPropertyValue(SUI::ObjectPropertyTypeEnum::CellAlignment).isEmpty() == true) alignment = SUI::AlignmentEnum::Stretch;
        updateCell(row, column, alignment, newWidget);
        updateTable();
    }
}

void SUI::TableWidgetImpl::setItemText(int row, int column, const std::string &text) {
    getWidget()->model()->setData(getWidget()->model()->index(row,column),QString::fromStdString(text),Qt::DisplayRole);
}

std::string SUI::TableWidgetImpl::getItemText(int row, int column) const {
    return getWidget()->model()->data(getWidget()->model()->index(row,column),Qt::DisplayRole).toString().toStdString();
}

SUI::Widget *SUI::TableWidgetImpl::getWidgetItemByName(const std::string &name) const {
    for (int row = 0, rows = rowCount(); row < rows; row++) {
        for (int column = 0, columns = columnCount();column < columns; column++) {
            BaseObject *object = SUI::ObjectFactory::getInstance()->toBaseObject(getWidgetItem(row,column));
            if(object->getPropertyValue(SUI::ObjectPropertyTypeEnum::CellName).toStdString() == name) return getWidgetItem(row,column);
        }
    }
    return NULL;
}

void SUI::TableWidgetImpl::setWidgetItemName(int row, int column, const std::string &name) {
    BaseObject *object = SUI::ObjectFactory::getInstance()->toBaseObject(getWidgetItem(row,column));
    if(object != NULL) object->setPropertyValue(SUI::ObjectPropertyTypeEnum::CellName, QString::fromStdString(name));
}

void SUI::TableWidgetImpl::onSelectionChanged(QItemSelection ,QItemSelection ) {
    // Do not fire when a header is selected:
    if (!this->getSelectedItems().empty() && !selectionChanged.empty()) selectionChanged();
}

void SUI::TableWidgetImpl::setCellBorderEnabled(int row, int column, bool borderOn) const {
    if (getWidget()->model()->data(getWidget()->model()->index(row, column),CustomTableItemModel::ObjectTypeRole) == ObjectType::TableWidgetItem) {
        getWidget()->model()->setData(getWidget()->model()->index(row,column), borderOn, CustomTableItemModel::BorderOnRole);
        getWidget()->model()->setData(getWidget()->model()->index(row,column), borderOn ? getPropertyValue(ObjectPropertyTypeEnum::BorderWidth).toInt() : 0, CustomTableItemModel::BorderWidthRole);
        getWidget()->update(getWidget()->model()->index(row,column));
    }
}

SUI::Widget *SUI::TableWidgetImpl::getWidgetItem(int row, int column) const {
    return static_cast<Widget*>(getWidget()->model()->data(getWidget()->model()->index(row,column),CustomTableItemModel::WidgetRole).value<void*>());
}

void SUI::TableWidgetImpl::readHeaderTags() {
    getWidget()->horizontalHeader()->setVisible(false);
    getWidget()->verticalHeader()->setVisible(false);

    QStandardItemModel *horizontalHeaderModel = qobject_cast<QStandardItemModel*>(getWidget()->model()->data(QModelIndex(),CustomTableItemModel::HorizontalHeaderRole).value<QObject*>());
    QStandardItemModel *verticalHeaderModel = qobject_cast<QStandardItemModel*>(getWidget()->model()->data(QModelIndex(),CustomTableItemModel::VerticalHeaderRole).value<QObject*>());
    Q_ASSERT(horizontalHeaderModel);
    Q_ASSERT(verticalHeaderModel);

    // clear them
    horizontalHeaderModel->clear();
    verticalHeaderModel->clear();

    // get new headers
    QList<QStandardItem*>horizontalHeaderItems = readHeaderTags(getPropertyValue(SUI::ObjectPropertyTypeEnum::HorizontalHeaderTags));
    QList<QStandardItem*>verticalHeaderItems = readHeaderTags(getPropertyValue(SUI::ObjectPropertyTypeEnum::VerticalHeaderTags));

    // Fill with empty headers and set vertical header invisible if empty
    while (horizontalHeaderItems.size() < columnCount()) {
        horizontalHeaderItems.append(new QStandardItem(""));
    }
    while (verticalHeaderItems.size() < rowCount()) {
        verticalHeaderItems.append(new QStandardItem(""));
    }
    
    // append the items to the model
    horizontalHeaderModel->appendRow(horizontalHeaderItems);
    verticalHeaderModel->appendRow(verticalHeaderItems);

    bool headersOn = getPropertyValue(SUI::ObjectPropertyTypeEnum::HeadersOn).toLower() == "true";
    getWidget()->horizontalHeader()->setVisible(headersOn);
    getWidget()->verticalHeader()->setVisible(getPropertyValue(SUI::ObjectPropertyTypeEnum::VerticalHeaderTags).size() ? headersOn : false);
}

void SUI::TableWidgetImpl::removeHeaders() {
    // hide the headers
    getWidget()->horizontalHeader()->setVisible(false);
    getWidget()->verticalHeader()->setVisible(false);

    // get the models and clear
    QStandardItemModel *horizontalHeaderModel = qobject_cast<QStandardItemModel*>(qvariant_cast<QObject*>(getWidget()->model()->data(QModelIndex(),CustomTableItemModel::HorizontalHeaderRole)));
    QStandardItemModel *verticalHeaderModel = qobject_cast<QStandardItemModel*>(qvariant_cast<QObject*>(getWidget()->model()->data(QModelIndex(),CustomTableItemModel::VerticalHeaderRole)));
    horizontalHeaderModel->clear();
    verticalHeaderModel->clear();
}

QStringList SUI::TableWidgetImpl::splitHeaders(const QString &headerItems) {
    QStringList items;

    int pos = 0;
    int previousPos = 0;
    int openBracketCount = 0;

    while (pos < headerItems.size()) {
        QChar currentChar = headerItems.at(pos);
        if (currentChar == '<') openBracketCount++;
        else if (currentChar == '>') {
            openBracketCount--;
            if (openBracketCount == 0) {
                QString item = headerItems.mid(previousPos,pos-previousPos).append('>');
                items.append(item);
                previousPos = pos+1;
            }
        }
        pos++;
    }
    return items;
}

QList<QStandardItem *> SUI::TableWidgetImpl::readHeaderTags(const QString &headerItems) {
    QStringList headerItemStrings = splitHeaders(headerItems);

    QList<QStandardItem*> headerItemList;

    BOOST_FOREACH (QString headerItemString, headerItemStrings) {
        if (headerItemString.count('<') == 1) {
            headerItemString.remove('<').remove('>');
            headerItemList.append(new QStandardItem(headerItemString));
        }
        else {
            QString parentItemString = headerItemString.mid(0,headerItemString.indexOf('<',1));
            parentItemString.remove('<').remove('>');
            QStandardItem *parent = new QStandardItem(parentItemString);
            headerItemList.append(parent);

            headerItemString.remove(headerItemString.size()-1,1);
            headerItemString.remove(0,headerItemString.indexOf('<',1));

            QStringList childStrings = splitHeaders(headerItemString);
            QList<QStandardItem*> childItems;
            BOOST_FOREACH (QString childString, childStrings) {
                if (childString.count('<') == 1) {
                    childString.remove('<').remove('>');
                    childItems.append(new QStandardItem(childString));
                }
                else {
                    QString childParentItemString = childString.mid(0,childString.indexOf('<',1));
                    childParentItemString.remove('<').remove('>');
                    QStandardItem *childParent = new QStandardItem(childParentItemString);
                    childItems.append(childParent);

                    childString.remove(childString.size()-1,1);
                    childString.remove(0,childString.indexOf('<',1));

                    QStringList childChildStrings = splitHeaders(childString);
                    QList<QStandardItem*> childChildItems;
                    BOOST_FOREACH (QString childChildString, childChildStrings) {
                        childChildItems.append(new QStandardItem(childChildString.remove('<').remove('>')));
                    }
                    childParent->insertRow(0,childChildItems);
                }
            }
            parent->insertRow(0,childItems);
        }
    }
    return headerItemList;
}

void SUI::TableWidgetImpl::updateCell(int row, int column, AlignmentEnum::Alignment alignment, Widget *newWidget) {
    BaseWidget *baseWidget = SUI::ObjectFactory::getInstance()->toBaseWidget(newWidget);
    baseWidget->setPropertyReadonly(SUI::ObjectPropertyTypeEnum::XPos);
    baseWidget->setPropertyReadonly(SUI::ObjectPropertyTypeEnum::YPos);
    baseWidget->setPropertyReadonly(SUI::ObjectPropertyTypeEnum::ID);
    baseWidget->addCellProperties(alignment, baseWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::CellName).toStdString());

    assign(row, column, newWidget);

    if (newWidget->getObjectType() == SUI::ObjectType::TableWidgetItem) {
        getWidget()->setIndexWidget(getWidget()->model()->index(row,column), NULL);
    }
    else {
        QModelIndex index = getWidget()->model()->index(row,column);
        if(newWidget->getObjectType() == SUI::ObjectType::UserControl){
            getWidget()->setColumnWidth(column, baseWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt());
            getWidget()->setRowHeight(row, baseWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt());
            getWidget()->setIndexWidget(index, baseWidget->getWidget());
        }
        else{
            getWidget()->setIndexWidget(index,createIndexWidget(baseWidget, getWidget()->columnWidth(column),getWidget()->rowHeight(row),alignment));
        }
    }
}

void SUI::TableWidgetImpl::setRowVisible(int row, bool visible) {
    getWidget()->setRowHidden(row, !visible);
}

bool SUI::TableWidgetImpl::isRowVisible(int row) {
    return !getWidget()->isRowHidden(row);
}

void SUI::TableWidgetImpl::setColumnVisible(int column, bool visible) {
    getWidget()->setColumnHidden(column, !visible);
}

bool SUI::TableWidgetImpl::isColumnVisible(int column) {
    return !getWidget()->isColumnHidden(column);
}


/*!
 * \brief SUI::TableWidgetImpl::getSelectedRows
 * There are 2 situations:
 * (1) the table is in listview mode:
 * You can retrieve the selected rows from selectionmodel directly
 * (2) the table is not in listview mode
 * The selectionmodel contains a list of selected cells. Select
 * the rownumbers from those items with the given columnnumber
 * \param column. By default this value is 0
 * \return
 */
std::vector<int> SUI::TableWidgetImpl::getSelectedRows(const int column) const {
    std::vector<int> selectedRows;
    QModelIndexList list;
    if(getWidget()->selectionBehavior() == QAbstractItemView::SelectRows) {
        list = getWidget()->selectionModel()->selectedRows(column);
        for (int idx = 0; idx < list.count(); idx++) {
            selectedRows.push_back(list.at(idx).row());
        }
    }
    else {
        list = getWidget()->selectionModel()->selectedIndexes();
        for (int idx = 0; idx < list.count(); idx++) {
            if(list.at(idx).column() == column) selectedRows.push_back(list.at(idx).row());
        }
    }
    return selectedRows;
}

QWidget *SUI::TableWidgetImpl::createIndexWidget(BaseWidget *baseWidget, int columnWidth, int rowHeight, SUI::AlignmentEnum::Alignment alignment) {
    baseWidget->addCellProperties(alignment, baseWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::CellName).toStdString());

    QWidget *indexWidget = new QWidget;
    indexWidget->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding);
    QHBoxLayout *layout = new QHBoxLayout;
    layout->setContentsMargins(0, 0, 0, 0);

    //StateWidget background on Tablewidget should be transparent
    if(baseWidget->getObjectType() == SUI::ObjectType::StateWidget) {
        indexWidget->setProperty("SUIWidget","stateWidget");
    }

    switch (alignment) {
    case SUI::AlignmentEnum::Left:    layout->setAlignment(Qt::AlignLeft | Qt::AlignVCenter); break;
    case SUI::AlignmentEnum::Right:   layout->setAlignment(Qt::AlignRight | Qt::AlignVCenter); break;
    case SUI::AlignmentEnum::HCenter: layout->setAlignment(Qt::AlignHCenter | Qt::AlignVCenter); break;
    default:
    {
        baseWidget->getWidget()->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding);
        baseWidget->getWidget()->resize(columnWidth, rowHeight);
        indexWidget->resize(columnWidth, rowHeight);
        break;
    }
    }

    layout->addWidget(baseWidget->getWidget());
    indexWidget->setLayout(layout);

    return indexWidget;
}

void SUI::TableWidgetImpl::sortItems(const int columnIndex, const SUI::SortOrderEnum::SortOrder order)
{
    if((columnIndex < 0) || (columnIndex > columnCount()))
    {
        return; // Invalid index.
    }

    Qt::SortOrder qOrder;
    if(SUI::SortOrderEnum::Ascending == order)
    {
        qOrder = Qt::AscendingOrder;
    }
    else if(SUI::SortOrderEnum::Descending == order)
    {
        qOrder = Qt::DescendingOrder;
    }
    else
    {
        return; // No sort do nothing.
    }
    getWidget()->model()->sort(columnIndex, qOrder);
}

void SUI::TableWidgetImpl::swapRows(int row1, int row2) {
    std::cout << row1 + row2 << std::endl;      // To prevent compiler warning on unused variables
//    if( row1 < 0 || row1 > (getWidget()->model()->rowCount() - 1) ||
//        row2 < 0 || row2 > getWidget()->model()->rowCount() - 1 ||
//        row1 == row2) {
//        // Nothing to be done
//        return;
//    }

//    // Make sure that row1 < row2
//    if(row2 < row1)
//        swapRows(row2, row1);

//    // Insert a new row below row2
//    getWidget()->model()->insertRows(row2, 1);

//    // Copy contents of row1 to new row (row2+1)
//    copyRow(row1, row2+1);

//    // Copy contents or row2 to row1
//    copyRow(row2, row1);

//    // Delete row2
//    getWidget()->model()->removeRow(row2);

//    // Refresh the label
//    updateTable();
}
