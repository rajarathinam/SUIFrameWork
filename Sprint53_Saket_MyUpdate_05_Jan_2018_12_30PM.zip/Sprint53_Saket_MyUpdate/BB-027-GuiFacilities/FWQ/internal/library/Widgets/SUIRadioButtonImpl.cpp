//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::RadioButtonImpl.
// !\description Class implementation file for SUI::RadioButtonImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIRadioButtonImpl.h"

#include <QStyle>
#include <QVariant>

SUI::RadioButtonImpl::RadioButtonImpl(QWidget *parent) :
    BaseWidget(new QRadioButton(parent), SUI::ObjectType::RadioButton, false)
{
    exposeWidthProperty();
    connect(RadioButtonImpl::getWidget(), SIGNAL(toggled(bool)), this, SLOT(handleCheckedChanged(bool)));
}

void SUI::RadioButtonImpl::setDefaultProperties(const ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "30");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "200");
    setChecked(getPropertyValue(SUI::ObjectPropertyTypeEnum::Checked).toLower() == "true");

    switch (context)
    {
    case EditorSelector:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, QString::fromStdString(SUI::ObjectType::toString(Object::getObjectType())));
        break;

    case EditorForm:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, "TBD");
        break;

    default:
        break;
    }
}

QRadioButton *SUI::RadioButtonImpl::getWidget() const {
    return dynamic_cast<QRadioButton *>(BaseWidget::getWidget());
}

void SUI::RadioButtonImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID,propertyValue);

    switch (propertyID) {
    case SUI::ObjectPropertyTypeEnum::Bold:
        setBold((propertyValue.compare("true", Qt::CaseInsensitive) == 0));
        break;

    case SUI::ObjectPropertyTypeEnum::Text:
        setText(propertyValue.toStdString());
        break;

    case SUI::ObjectPropertyTypeEnum::Checked:
        setChecked((propertyValue.compare("true", Qt::CaseInsensitive) == 0));
        getWidget()->update();
        break;

    default:
        break;
    }
}

void SUI::RadioButtonImpl::handleCheckedChanged(bool newState) {
    if (!checkStateChanged.empty()) checkStateChanged(newState);
}

/*****************************************************************************\
 *  FUNCTION    :   setChecked
 *  PARAMETERS  :   bool checked
 *  RETURN      :   void
 *
 *  This function sets the checked state of the RadioButton. In case this Radio
 *  Button is checked, you need to set the AutoExclusive property to false,
 *  otherwise the checked state of the RadioButton will not change.
\*****************************************************************************/
void SUI::RadioButtonImpl::setChecked(bool checked) {
    if (getWidget()->isChecked())
    {
        getWidget()->setAutoExclusive(false);
        getWidget()->setChecked(checked);
        getWidget()->setAutoExclusive(true);
    }
    else {
        getWidget()->setChecked(checked);
    }
}

bool SUI::RadioButtonImpl::isChecked() const {
    return getWidget()->isChecked();
}

void SUI::RadioButtonImpl::setText(const std::string &value) {
    if (getText() == value) return;
    getWidget()->setText(QString::fromStdString(value));
}

std::string SUI::RadioButtonImpl::getText() const {
    return getWidget()->text().toStdString();
}

void SUI::RadioButtonImpl::setBold(bool bold) {
    getWidget()->setProperty("SUIFont", QVariant::fromValue<QString>(bold ? "bold" : ""));
    getWidget()->style()->polish(getWidget());
}

bool SUI::RadioButtonImpl::isBold() const {
    return getWidget()->property("SUIFont").toString() == "bold";
}

void SUI::RadioButtonImpl::clearText() {
    setText("");
}
