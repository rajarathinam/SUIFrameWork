//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::MessageBoxImpl.
// !\description Class implementation file for SUI::MessageBoxImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIMessageBoxImpl.h"

#include <QAbstractButton>
#include <QPushButton>
#include <QFont>
#include <boost/foreach.hpp>

SUI::MessageBoxImpl::MessageBoxImpl(QWidget *parent) :
    BaseWidget(new QMessageBox(parent), SUI::ObjectType::MessageBox, false)
{
    connect(MessageBoxImpl::getWidget(), SIGNAL(buttonClicked(QAbstractButton *)), this, SLOT(handleClicked(QAbstractButton *)));
}

void SUI::MessageBoxImpl::setDefaultProperties(const SUI::BaseObject::ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);

    switch (context)
    {
    case EditorSelector:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, QString::fromStdString(SUI::ObjectType::toString(Object::getObjectType())));
        break;

    case EditorForm:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, "TBD");
        break;

    default:
        break;
    }
}

QMessageBox *SUI::MessageBoxImpl::getWidget() const {
    return dynamic_cast<QMessageBox *>(BaseWidget::getWidget());
}

void SUI::MessageBoxImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID,propertyValue);

    switch (propertyID) {
    case SUI::ObjectPropertyTypeEnum::Bold:
        setBold((propertyValue.compare("true", Qt::CaseInsensitive) == 0));
        break;
    case SUI::ObjectPropertyTypeEnum::Text:
        setText(propertyValue.toStdString());
        break;
    default:
        break;
    }
}

void SUI::MessageBoxImpl::setText(const std::string &value) {
    if (getText() == value) return;
    getWidget()->setText(QString::fromStdString(value));
}

void SUI::MessageBoxImpl::clearText() {
    getWidget()->setText("");
}

std::string SUI::MessageBoxImpl::getText() const {
    return  getWidget()->text().toStdString();
}

void SUI::MessageBoxImpl::setButtonText(const std::list<std::string> &text) {
    QList<QAbstractButton *> buttonList = getWidget()->findChildren<QAbstractButton *>();
    BOOST_FOREACH (QAbstractButton * pb, buttonList)
        getWidget()->removeButton(pb);

    for (std::list<std::string>::const_iterator iterator = text.begin(); iterator != text.end(); ++iterator)
    {
        QString value = QString::fromStdString(*iterator);
        if(!value.isEmpty())
        {
            getWidget()->addButton(value, QMessageBox::AcceptRole);
        }
    }
}

void SUI::MessageBoxImpl::setDefaultButton(const std::string &button) {
    QString buttonStr = QString::fromStdString(button);
    QList<QPushButton *> buttonList =
            getWidget()->findChildren<QPushButton *>();
    BOOST_FOREACH (QPushButton * pb, buttonList)
    {
        if (pb->text() == buttonStr)
        {
            getWidget()->setDefaultButton(pb);
        }
    }
}

void SUI::MessageBoxImpl::setIcon(MessageBoxIconEnum::MessageBoxIconType icon) {
    QPixmap iconPixmap;
    switch (icon)
    {
    case MessageBoxIconEnum::Information:
        iconPixmap.load(":/image/SSGUxGUI_Information_Icon.png");
        iconPixmap = iconPixmap.scaled(40, 40);
        getWidget()->setIconPixmap(iconPixmap);
        break;
    case MessageBoxIconEnum::Warning:
        iconPixmap.load(":/image/SSGUxGUI_WarningIcon.png");
        iconPixmap = iconPixmap.scaled(40, 40);
        getWidget()->setIconPixmap(iconPixmap);
        break;
    case MessageBoxIconEnum::Critical:
        iconPixmap.load(":/image/SSGUxGUI_Access_denied_Icon.png");
        iconPixmap =  iconPixmap.scaled(40, 40);
        getWidget()->setIconPixmap(iconPixmap);
        break;
    case MessageBoxIconEnum::Question:
        iconPixmap.load(":/image/SSGUxGUI_Questionmark_Icon.png");
        iconPixmap = iconPixmap.scaled(40, 40);
        dynamic_cast<QMessageBox*>(BaseWidget::getWidget())->setIconPixmap(iconPixmap);
        break;
    case MessageBoxIconEnum::None:
    default:
        getWidget()->setIcon(QMessageBox::NoIcon);
        break;
    }
}
void SUI::MessageBoxImpl::setBold(bool bold) {
    QString boldStr = bold ? "true" : "false";
    if(getPropertyValue(SUI::ObjectPropertyTypeEnum::Bold).toLower() != boldStr) {
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Bold, boldStr);
    }
    getWidget()->setStyleSheet( bold ? "QLabel {font: bold}" : "QLabel {font: normal}");
}

bool SUI::MessageBoxImpl::isBold() const {
    return getPropertyValue(SUI::ObjectPropertyTypeEnum::Bold).toLower() == "true";
}

void SUI::MessageBoxImpl::handleClicked(QAbstractButton *button) {
    if (!clicked.empty())
    {
        mButtonText = button->text();
        clicked();
    }
}
