//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for CustomTableItemModel.
// !\description Class implementation file for CustomTableItemModel.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "CustomTableItemModel.h"

#include "FWQxWidgets/SUIWidget.h"
#include "SUITableWidgetItemImpl.h"

#include <QStandardItemModel>
#include <boost/foreach.hpp>

#include "FWQxCore/SUIObjectList.h"
#include "FWQxCore/SUIObjectFactory.h"

SUI::CustomTableItemModel::CustomTableItemModel(QObject *parent, SUI::ObjectList *objectList) :
    QAbstractTableModel(parent),
    mObjectList(objectList),
    horizontalHeaderModel(new QStandardItemModel()),
    verticalHeaderModel(new QStandardItemModel())
{
}

SUI::CustomTableItemModel::CustomTableItemModel(int rows, int columns, QObject *parent) :
    QAbstractTableModel(parent),
    horizontalHeaderModel(new QStandardItemModel()),
    verticalHeaderModel(new QStandardItemModel())
{
    if (rows > 0) CustomTableItemModel::insertRows(0,rows);
    if (columns > 1) CustomTableItemModel::insertColumns(1,columns - 1);
}

SUI::CustomTableItemModel::~CustomTableItemModel() {
    if (horizontalHeaderModel != NULL) horizontalHeaderModel->deleteLater();
    if (verticalHeaderModel != NULL) verticalHeaderModel->deleteLater();
}

QVariant SUI::CustomTableItemModel::data(const QModelIndex &index, int role) const {
    QVariant returnValue;
    if (index.isValid() == true) {

        Widget *item = container[index.row()][index.column()];
        Q_ASSERT(item);

        switch (role) {
        case Qt::DisplayRole:
            if (item->getObjectType() == SUI::ObjectType::TableWidgetItem) {
                returnValue = QString::fromStdString(dynamic_cast<TableWidgetItem*>(item)->getText());
            }
            break;

        case Qt::TextAlignmentRole:
            if (item->getObjectType() == SUI::ObjectType::TableWidgetItem) {
                returnValue = dynamic_cast<TableWidgetItemImpl*>(item)->textAlignment();
            }
            break;

        case Qt::FontRole:
            if (item->getObjectType() == SUI::ObjectType::TableWidgetItem) {
                returnValue = dynamic_cast<TableWidgetItemImpl*>(item)->getWidget()->font();
            }
            break;
        case Qt::ForegroundRole:
            if (item->getObjectType() == SUI::ObjectType::TableWidgetItem) {
                returnValue = dynamic_cast<TableWidgetItemImpl*>(item)->foreground();
            }
            break;
        case Qt::BackgroundRole:
            if (item->getObjectType() == SUI::ObjectType::TableWidgetItem) {
                returnValue = dynamic_cast<TableWidgetItemImpl*>(item)->background();
            }
            break;
        case BorderOnRole:
            returnValue = SUI::ObjectFactory::getInstance()->toBaseObject(item)->getPropertyValue(SUI::ObjectPropertyTypeEnum::BorderOn).toLower() == "true";
            break;

        case BorderWidthRole:
            returnValue = SUI::ObjectFactory::getInstance()->toBaseObject(item)->getPropertyValue(SUI::ObjectPropertyTypeEnum::BorderWidth).toInt();
            break;

        case IDRole:
            returnValue = SUI::ObjectFactory::getInstance()->toBaseObject(item)->getPropertyValue(SUI::ObjectPropertyTypeEnum::ID);
            break;

        case ObjectTypeRole:
            returnValue = (int)SUI::ObjectType::fromString(SUI::ObjectFactory::getInstance()->toBaseObject(item)->getPropertyValue(SUI::ObjectPropertyTypeEnum::ObjectType).toStdString());
            break;

        case WidgetRole:
            returnValue = qVariantFromValue((void *) item);
            break;

        default: break;
        }
    }
    switch (role) {
    case HorizontalHeaderRole:
        returnValue =  QVariant::fromValue<QObject*>((QObject*)horizontalHeaderModel);
        break;

    case VerticalHeaderRole:
        returnValue =  QVariant::fromValue<QObject*>((QObject*)verticalHeaderModel);
        break;

    default: break;
    }

    return returnValue;
}

bool SUI::CustomTableItemModel::setData(const QModelIndex &index, const QVariant &value, int role) {
    if (index.isValid()) {
        bool returnValue = false;

        Widget *item = container[index.row()][index.column()];
        Q_ASSERT(item);

        switch (role) {
        case Qt::DisplayRole:
        {
            if (item->getObjectType() == ObjectType::TableWidgetItem) {
                emit layoutAboutToBeChanged();
                dynamic_cast<TableWidgetItem*>(item)->setText(value.toString().toStdString());
                SUI::ObjectFactory::getInstance()->toBaseObject(item)->setPropertyValue(ObjectPropertyTypeEnum::Text,value.toString());
                returnValue = true;
                emit dataChanged(index,index);
                emit layoutChanged();
            }
            //TODO handle other widget types
            break;
        }
        case BorderOnRole:
            SUI::ObjectFactory::getInstance()->toBaseObject(item)->setPropertyValue(ObjectPropertyTypeEnum::BorderOn, value.toBool() ? "true" : "false");
            returnValue = true;
            break;

        case BorderWidthRole:
            SUI::ObjectFactory::getInstance()->toBaseObject(item)->setPropertyValue(ObjectPropertyTypeEnum::BorderWidth, QString::number(value.toInt()));
            returnValue = true;
            break;

        case WidgetRole: {
            emit layoutAboutToBeChanged();
            Widget *widget = static_cast<Widget*>(value.value<void *>());
            Q_ASSERT(widget);
            container[index.row()][index.column()] = widget;
            returnValue = true;
            emit dataChanged(index,index);
            emit layoutChanged();
            break;
        }

        //TODO handle other roles if needed

        default:
            break;

        }
        return returnValue;
    }
    return QAbstractTableModel::setData(index,value,role);
}

int SUI::CustomTableItemModel::rowCount(const QModelIndex &) const {
    return container.size();
}

int SUI::CustomTableItemModel::columnCount(const QModelIndex &) const {
    return container.size() > 0 ? container.at(0).size() : 0;
}

bool SUI::CustomTableItemModel::insertRow(int row, const QModelIndex &parent) {
    return insertRows(row,1,parent);
}

bool SUI::CustomTableItemModel::insertRows(int pos, int count, const QModelIndex &parent) {
    if (count <= 0) return false; //FIXME enable asserts

    if (pos > rowCount() && pos > 0 && rowCount() > 0) pos = rowCount()-1;
    int rows = pos+count;
    int columns = columnCount() > 0 ? columnCount() : 1;

    beginInsertRows(parent,pos,rows-1);
    for (int row = pos; row < rows; row++) {
        QVector<Widget *> items;
        for (int column = 0; column < columns; column++) {

            TableWidgetItemImpl *tableWidgetItem = new TableWidgetItemImpl(NULL);
            tableWidgetItem->setDefaultProperties(SUI::BaseObject::Gui);
            items.append(tableWidgetItem);
            QModelIndex changedIndex = index(row,column,parent);
            emit dataChanged(changedIndex,changedIndex);
        }
        container.insert(row,items);
    }
    endInsertRows();

    return true;
}

bool SUI::CustomTableItemModel::insertColumns(int pos, int count, const QModelIndex &parent) {
    if (count <= 0) return false;
    if (pos > columnCount() && pos > 0 && columnCount() > 0) pos = columnCount()-1;
    int rows = rowCount() > 0 ? rowCount() : 1;
    int columns = pos+count;

    beginInsertColumns(parent,pos,columns-1);
    if (rowCount() == 0) { // we need at least one row in order to be able to add the col
        container.resize(1);
    }
    for (int row = 0; row < rows; row++) {
        for (int column = pos; column < columns; column++) {
            TableWidgetItemImpl *tableWidgetItem = new TableWidgetItemImpl(NULL);
            tableWidgetItem->setDefaultProperties(SUI::BaseObject::Gui);
            container[row].insert(column,tableWidgetItem);
            QModelIndex changedIndex = index(row,column,parent);
            emit dataChanged(changedIndex,changedIndex);
        }
    }
    endInsertColumns();
    return true;
}

void SUI::CustomTableItemModel::removeChildrenOfUserControl(const QObjectList &objectList) {
    BOOST_FOREACH (QObject *object, objectList ){
        if(object->children().count() > 0) {
            removeChildrenOfUserControl(object->children());
        }
        mObjectList->removeObject(object->objectName().toStdString());
        mObjectList->removeTabOrder(object->objectName().toStdString());
    }
}

bool SUI::CustomTableItemModel::removeRows(int pos, int count, const QModelIndex &parent) {
    if (count <= 0) return false;
    if ((pos+count) > rowCount()) return false;

    int rows = pos+count > rowCount() ? rowCount() : pos + count;
    beginRemoveRows(parent,pos,pos+count-1);
    for (int row = pos; row < rows; row++) {
        for (int column = 0, columns = columnCount(); column < columns; column++) {
            if (mObjectList != NULL) {
                Widget *item = container[pos][0];
                BaseWidget *baseObj = SUI::ObjectFactory::getInstance()->toBaseWidget(item);
                if(baseObj != NULL){
                    //if its a UserControl, remove all its children ObjectId's from ObjectList
                    if(baseObj->getObjectType() == SUI::ObjectType::UserControl) {
                        removeChildrenOfUserControl(baseObj->getWidget()->children());
                    }
                    mObjectList->removeObject(baseObj->getId());
                    if(baseObj->getPropertyTypes().contains(ObjectPropertyTypeEnum::TabOrder)) {
                        mObjectList->removeTabOrder(baseObj->getId());
                    }
                    delete baseObj;
                    baseObj = NULL;
                }
            }
            container[pos].remove(0);
            QModelIndex changedIndex = index(row,0,parent);
            emit dataChanged(changedIndex,changedIndex);
        }
        container.remove(pos);
    }
    endRemoveRows();
    if(rowCount() == 0){
        beginRemoveColumns(parent, 0, 0);
        container.clear();
        emit layoutAboutToBeChanged();
        QModelIndex changedIndex = index(0,0,parent);
        emit dataChanged(changedIndex,changedIndex);
        emit layoutChanged();
        endRemoveColumns();
    }
    return true;
}

bool SUI::CustomTableItemModel::insertColumn(int column, const QModelIndex &parent) {
    return insertColumns(column,1,parent);
}

bool SUI::CustomTableItemModel::removeColumns(int pos, int count, const QModelIndex &parent) {
    if (count <= 0) return false;
    if (pos >= columnCount()) return false;

    beginRemoveColumns(parent,pos,pos+count-1);
    for (int column = pos, columns = pos+count; column < columns; column++) {
        for (int row = 0, rows = rowCount(); row < rows; row++) {
            if (mObjectList != NULL) {
                Widget *item = container[row][pos];
                BaseWidget *baseObj = SUI::ObjectFactory::getInstance()->toBaseWidget(item);
                mObjectList->removeObject(baseObj->getId());
                if(baseObj->getPropertyTypes().contains(ObjectPropertyTypeEnum::TabOrder)) {
                    mObjectList->removeTabOrder(baseObj->getId());
                }
                delete baseObj;
                baseObj = NULL;
            }
            container[row].remove(pos);
            QModelIndex changedIndex = index(row,pos,parent);
            emit dataChanged(changedIndex,changedIndex);
        }
    }
    endRemoveColumns();
    if (columnCount() == 0){
        beginRemoveRows(parent, 0, 0);
        container.clear();
        emit layoutAboutToBeChanged();
        QModelIndex changedIndex = index(0,0,parent);
        emit dataChanged(changedIndex,changedIndex);
        emit layoutChanged();
        endRemoveRows();
    }
    return true;
}

bool SUI::CustomTableItemModel::indexValid(int row, int column) const {
    return row < rowCount() && column < columnCount() && row > -1 && column > -1;
}

void SUI::CustomTableItemModel::setHeaderModel(Qt::Orientation orientation, QAbstractItemModel *model) {
    switch (orientation) {
    case Qt::Horizontal:
        if (horizontalHeaderModel != NULL) horizontalHeaderModel->deleteLater();
        horizontalHeaderModel = model;
        break;
    case Qt::Vertical:
        if (verticalHeaderModel != NULL) verticalHeaderModel->deleteLater();
        verticalHeaderModel = model;
        break;
    }
    emit headerDataChanged();
}

QAbstractItemModel *SUI::CustomTableItemModel::getHeaderModel(Qt::Orientation orientation) {
    switch (orientation) {
    case Qt::Horizontal: return horizontalHeaderModel;
    case Qt::Vertical: return verticalHeaderModel;
    }
    return NULL;
}
