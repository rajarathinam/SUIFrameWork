//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for CustomGraphicsScene.
// !\description Class implementation file for CustomGraphicsScene.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "CustomGraphicsScene.h"

#include <boost/shared_ptr.hpp>

#include <QBuffer>
#include <QPainter>
#include <QGraphicsItem>
#include <QGraphicsView>
#include <QGraphicsSvgItem>
#include <QDir>
#include <QFileInfo>
#include "FWQxGraphicsItems/SUIGraphicsItem.h"
#include "FWQxCore/SUIMouseButtonEnum.h"
#include "FWQxGraphicsItems/SUIGraphicsSceneMouseEvent.h"
#include "FWQxCore/SUIResourcePath.h"
#include <QToolTip>

CustomGraphicsScene::CustomGraphicsScene(QObject *parent) :
    QGraphicsScene(parent)
{
}

void CustomGraphicsScene::mouseReleaseEvent(QGraphicsSceneMouseEvent *qEvent) {
    QGraphicsScene::mouseReleaseEvent(qEvent);
    mouseReleased(SUI::GraphicsSceneMouseEvent::create(qEvent));
}

void CustomGraphicsScene::mousePressEvent(QGraphicsSceneMouseEvent *qEvent) {
    QGraphicsScene::mousePressEvent(qEvent);
    mousePressed(SUI::GraphicsSceneMouseEvent::create(qEvent));
}

void CustomGraphicsScene::mouseMoveEvent(QGraphicsSceneMouseEvent *qEvent) {
    QGraphicsScene::mouseMoveEvent(qEvent);
    mouseMoved(SUI::GraphicsSceneMouseEvent::create(qEvent));
}

void CustomGraphicsScene::wheelEvent(QGraphicsSceneWheelEvent *qEvent) {
    QGraphicsScene::wheelEvent(qEvent);
    mouseWheelMoved(SUI::GraphicsSceneMouseEvent::create(qEvent));
}

void CustomGraphicsScene::helpEvent(QGraphicsSceneHelpEvent *event) {
    QList<QGraphicsItem *> itemsAtPos;
    QPointF scenePos = event->scenePos();
    QWidget * widget = event->widget();
    QGraphicsView * view = widget ? qobject_cast<QGraphicsView *>(widget->parentWidget()) : 0;

    if( view != NULL ) {
        const QRectF pointRect(scenePos, QSizeF(1, 1));
        if (view->isTransformed()) {
            const QTransform viewTransform = view->viewportTransform();
            itemsAtPos = items(pointRect, Qt::IntersectsItemShape, Qt::DescendingOrder, viewTransform);
        }
        else {
            itemsAtPos = items(pointRect, Qt::IntersectsItemShape, Qt::DescendingOrder);
        }
    }
    else {
        itemsAtPos = items(scenePos, Qt::IntersectsItemShape, Qt::DescendingOrder, QTransform());
    }

    QGraphicsItem *toolTipItem = 0;
    for (int i = 0; i < itemsAtPos.size(); ++i) {
        QGraphicsItem *tmp = itemsAtPos.at(i);
        if (tmp->type() == QGraphicsSvgItem::Type) {
            sendEvent(tmp, event);
        }
        if (tmp->toolTip().isEmpty() == false) {
            toolTipItem = tmp;
            break;
        }
    }
    QString text;
    QPoint point;
    if ((toolTipItem != NULL) && (toolTipItem->toolTip().isEmpty() == false)) {
        text = toolTipItem->toolTip();
        point = event->screenPos();
    }
    QToolTip::showText(point, text, event->widget());
    event->setAccepted(!text.isEmpty());
}

void CustomGraphicsScene::setBackgroundImageFile(const std::string &fileName) {
    setBackgroundImage(QPixmap(QString::fromStdString(SUI::ResourcePath::getResourceFile(fileName))));
}

void CustomGraphicsScene::setBackgroundImage(unsigned char *data , int width, int height, QImage::Format format) {
    setBackgroundImage(QPixmap::fromImage(QImage(data,width,height,format)));
}

void CustomGraphicsScene::setBackgroundImage(const std::string &data) {
    if (data != "") {
       QByteArray bytes = QByteArray::fromBase64(QString::fromStdString(data).toLocal8Bit());
       QImage image;
       image.loadFromData(bytes);
       setBackgroundImage(QPixmap::fromImage(image));
    }
}

void CustomGraphicsScene::setBackgroundImage(const QPixmap &image) {
   backgroundPixmap = image;
   setSceneRect(image.rect());
   views().first()->update();
}

void CustomGraphicsScene::drawBackground(QPainter *painter, const QRectF &rect) { 
   if (backgroundPixmap.isNull()) {
       QGraphicsScene::drawBackground(painter,rect);
   }
   else {
      qreal width = sceneRect().width()-static_cast<qreal>(backgroundPixmap.rect().width());
      qreal height = sceneRect().height()-static_cast<qreal>(backgroundPixmap.rect().height());
      painter->drawPixmap(QPointF(width/2.0f, height/2.0f), backgroundPixmap);
   }
}
