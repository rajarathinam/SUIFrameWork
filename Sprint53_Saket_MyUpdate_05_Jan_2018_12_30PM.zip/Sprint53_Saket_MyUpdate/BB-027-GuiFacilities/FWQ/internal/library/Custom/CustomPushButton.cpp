//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for CustomPushButton.
// !\description Class implementation file for CustomPushButton.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "CustomPushButton.h"

#include <QMouseEvent>

CustomPushButton::CustomPushButton(QWidget *parent) :
    QPushButton(parent)
{
}

CustomPushButton::~CustomPushButton()
{
}

void CustomPushButton::mousePressEvent(QMouseEvent *event) {
    QPushButton::mousePressEvent(event);
    emit mousePressed();
}

void CustomPushButton::mouseReleaseEvent(QMouseEvent *event) {
    QPushButton::mouseReleaseEvent(event);
    emit mouseReleased();
}
