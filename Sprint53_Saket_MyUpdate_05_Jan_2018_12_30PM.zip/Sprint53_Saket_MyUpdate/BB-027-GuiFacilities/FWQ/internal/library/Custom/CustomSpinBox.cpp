//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for CustomSpinBox.
// !\description Class implementation file for CustomSpinBox.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|



#include "CustomSpinBox.h"

CustomSpinBox::CustomSpinBox(QWidget *parent) :
    QSpinBox(parent),
    mValueIsFactor(false)
{
}

/*****************************************************************************\
 *  FUNCTION    :   stepBy
 *  PARAMETERS  :   int steps
 *  RETURN      :   void
 *
 *  This is a virtual function from QSpinBox. It is overridden because of if
 *  mValueIsFactor is set to true, the stepsize id used as a factor to multiply
 *  the current value with.
\*****************************************************************************/
void CustomSpinBox::stepBy(int steps)
{
    if (mValueIsFactor)
    {
        int dCurVal = QSpinBox::value();
        int dNewVal;
        if (steps > 0)
        {
            if (dCurVal > 0)
            {
                dNewVal = dCurVal * QSpinBox::singleStep();
            }
            else if (dCurVal < 0)
            {
                dNewVal = dCurVal / QSpinBox::singleStep();
            }
            else
            {
                dNewVal = 1;
            }
        }
        else
        {
            if (dCurVal > 0)
            {
                dNewVal = dCurVal / QSpinBox::singleStep();
            }
            else if (dCurVal < 0)
            {
                dNewVal = dCurVal * QSpinBox::singleStep();
            }
            else
            {
                dNewVal = -1;
            }
        }
        QSpinBox::setValue(dNewVal);
    }
    else
    {
        QSpinBox::stepBy(steps);
    }
}

void CustomSpinBox::setStepSizeValueToFactor(const bool on) { mValueIsFactor = on; }
