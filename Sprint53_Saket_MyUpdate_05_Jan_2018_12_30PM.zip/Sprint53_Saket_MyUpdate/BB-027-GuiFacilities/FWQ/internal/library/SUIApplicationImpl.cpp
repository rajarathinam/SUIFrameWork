//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::ApplicationImpl.
// !\description Class implementation file for SUI::ApplicationImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUIApplicationImpl.h"

#include <QLocale>
#include <QStringList>

#include <boost/foreach.hpp>
#include "FWQxCore/SUIXmlException.h"
#include "FWQxCore/SUIIOException.h"
#include "FWQxCore/SUIArgumentException.h"

#include "FWQxWidgets/SUIMessageBox.h"

SUI::ApplicationImpl::ApplicationImpl(int &argc, char *argv[]) :
    QApplication(argc,argv),
    Application()
{
}

int SUI::ApplicationImpl::exec() {
    return QApplication::exec();
}

void SUI::ApplicationImpl::setLocale(SUI::LocaleEnum::Language language, SUI::LocaleEnum::Country country) {
    QLocale::setDefault(QLocale((QLocale::Language)language,(QLocale::Country)country));
}

void SUI::ApplicationImpl::setLocale(SUI::LocaleEnum::Language language, SUI::LocaleEnum::Script script, SUI::LocaleEnum::Country country) {
    QLocale::setDefault(QLocale((QLocale::Language)language,(QLocale::Script)script,(QLocale::Country)country));
}

std::list<std::string> SUI::ApplicationImpl::getArguments() const {
    std::list<std::string> list;
    BOOST_FOREACH(const QString &arg , QApplication::arguments())
        list.push_back(arg.toStdString());
    return list;
}

bool SUI::ApplicationImpl::notify(QObject *object, QEvent *event) {
    try {
        return QApplication::notify(object,event);
    }
    catch (ArgumentException *e)
    {
        SUI::MessageBox::critical(NULL,"ArgumentException",e->getExceptionMessage());
        delete e;
        e = NULL;
    }
    catch (XmlException *e)
    {
        SUI::MessageBox::critical(NULL,"XMLException",e->getExceptionMessage());
        delete e;
        e = NULL;
    }
    catch (IOException *e)
    {
        SUI::MessageBox::critical(NULL,"IOException",e->getExceptionMessage());
        delete e;
        e = NULL;
    }
    catch (Exception *e)
    {
        SUI::MessageBox::critical(NULL,"Exception",e->getExceptionMessage());
        delete e;
        e = NULL;
    }
    catch (const std::exception &e)
    {
       SUI::MessageBox::critical(NULL,"Error",QString("An error occured:\n").append(e.what()).toStdString());
       exit(1);
    }
    
    return false;
}
