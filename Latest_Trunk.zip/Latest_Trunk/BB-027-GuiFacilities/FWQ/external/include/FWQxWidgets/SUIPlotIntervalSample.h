//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::PlotIntervalSample.
// !\description Header file for class SUI::PlotIntervalSample.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUIPLOTINTERVALSAMPLE_H
#define SUIPLOTINTERVALSAMPLE_H

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief This PlotIntervalSample type is used to describe plot intervals for plotting Histogram
 */
class PlotIntervalSample {
public:

    PlotIntervalSample(double val, double min, double max);

    /*!
     * \brief getValue
     * Returns the value of the sample
     * \return double
     */
    double getValue() const;

    /*!
     * \brief setValue
     * Sets the value of the sample.
     * \param val : value to set
     */
    void setValue(double value);

    /*!
     * \brief getMinValue
     * Returns the minimal value of the interval sample
     * \return double
     */
    double getMinValue() const;

    /*!
     * \brief setMinValue
     * Set the minimum value of the interval sample
     * \param val : minimum interval value to set
     */
    void setMinValue(double value);

    /*!
     * \brief getMaxValue
     * Returns the maximum value of the interval sample
     * \return double
     */
    double getMaxValue() const;

    /*!
     * \brief setMaxValue
     * Sets the maximum value of the interval sample
     * \param val : maximum interval value to set
     */
    void setMaxValue(double val);

private:
    double value;
    double minValue;
    double maxValue;
};
}

#endif // SUIPLOTINTERVALSAMPLE_H
