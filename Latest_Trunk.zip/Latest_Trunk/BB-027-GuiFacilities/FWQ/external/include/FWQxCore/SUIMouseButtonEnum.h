//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for SUIMouseButtonEnum
// !\description Header file for SUIMouseButtonEnum
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIMOUSEBUTTONENUM_H
#define SUIMOUSEBUTTONENUM_H

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief MouseButton
 * This enum type is used to describe mouse button (clicks).
 */
enum MouseButton
{
    NoButton = 0x00000000,
    Left     = 0x00000001,
    Right    = 0x00000002,
    Middle   = 0x00000004
};

typedef int MouseButtons;


/*!
 * \ingroup FWQxCore
 *
 * \brief WheelDirection
 * The enumeration lists the available wheel events
 */
enum WheelDirection { Up, Down };

/*!
 * \ingroup FWQxCore
 *
 * \brief CursorShape
 * The enumeration lists the various mouse cursors
 */
class CursorShapeEnum {
public:
    typedef enum {
        ArrowCursor,
        UpArrowCursor,
        CrossCursor,
        WaitCursor,
        IBeamCursor,
        SizeVerCursor,
        SizeHorCursor,
        SizeBDiagCursor,
        SizeFDiagCursor,
        SizeAllCursor,
        BlankCursor,
        SplitVCursor,
        SplitHCursor,
        PointingHandCursor,
        ForbiddenCursor,
        WhatsThisCursor,
        BusyCursor,
        OpenHandCursor,
        ClosedHandCursor,
        DragCopyCursor,
        DragMoveCursor,
        DragLinkCursor,
        LastCursor = DragLinkCursor,
        BitmapCursor = 24,
        CustomCursor = 25
    } CursorShape ;
};
}

#endif // SUIMOUSEBUTTONENUM_H
