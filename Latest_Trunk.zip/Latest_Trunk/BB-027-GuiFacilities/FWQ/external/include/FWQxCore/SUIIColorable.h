//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::IColorable.
// !\description Header file for class SUI::IColorable.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIICOLORABLE_H
#define SUIICOLORABLE_H

#include "FWQxCore/SUIColorEnum.h"

#include <list>
#include <string>

#include <boost/function.hpp>

namespace SUI {

/*!
 * \ingroup FWQxCore
 *
 * \brief Generic Interface class for interaction with the color property of a widget
 */
class IColorable
{
public:
    virtual ~IColorable() {}

    /*!
     * \brief getColor
     * Gets the current color of the widget
     * \return
     */
    virtual SUI::ColorEnum::Color getColor() const = 0;

    /*!
     * \brief setColor
     * Sets the color of the widget
     * \param color
     */
    virtual void setColor(const SUI::ColorEnum::Color color) = 0;

    /*!
     * \brief colorChanged
     * Callback function that is called when the color has changed.
     * \fn valueChanged
     */
    boost::function<void()> colorChanged;

};
}

#endif // SUIICOLORABLE_H
