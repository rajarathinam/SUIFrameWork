//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::MessageBoxIconEnum.
// !\description Header file for class SUI::MessageBoxIconEnum.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIMESSAGEBOXICONENUM_H
#define SUIMESSAGEBOXICONENUM_H

#include "FWQxCore/SUIDeprecated.h"

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief This enum type is used to describe messagebox icon types.
 * This icon helps User to identify type of message whether information,warning,critical,question
 */
class SUI_DEPRECATED MessageBoxIconEnum
{
public:
    /*!
     * \brief MessageBoxIconType
     * Enumerates message box icons
     */
    enum MessageBoxIconType
    {
        None,
        Information,//an icon indicating that the message is nothing out of the ordinary.
        Warning, //an icon indicating that the message is a warning, but can be dealt with.
        Critical, //an icon indicating that the message represents a critical problem.
        Question //an icon indicating that the message is asking a question.
    };
};
}
#endif // SUIMESSAGEBOXICON_H
