//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::BaseWidget.
// !\description Class implementation file for SUI::BaseWidget.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|



#include "SUIBaseWidget.h"

#include <QEvent>
#include <QAction>
#include <QMenu>
#include <QStyle>
#include <QFile>
#include <QFileInfo>
#include <QTextStream>
#include <boost/foreach.hpp>

#include "SUIStyleSheet.h"
#include "FWQxCore/SUIObject.h"
#include "FWQxCore/SUIObjectFactory.h"
#include "FWQxWidgets/SUIWidget.h"
#include "FWQxCore/SUIIOException.h"
#include "SUIObjectFactoryImpl.h"

SUI::BaseWidget::BaseWidget(QWidget *widget_t, const ObjectType::Type &objectType, bool childrenSupported) :
    QObject(NULL),
    BaseObject(SUI::BaseObject::Gui, objectType, childrenSupported),
    widget(widget_t),
    heightExposed(false),
    widthExposed(false)
{
    setPropertyReadonly(ObjectPropertyTypeEnum::Moveable);      //Default TRUE and readonly for all new widgets
    setPropertyReadonly(ObjectPropertyTypeEnum::Sizeable);      //Default TRUE and readonly for all new widgets
    setPropertyReadonly(ObjectPropertyTypeEnum::UserControl);   //Default empty for all new widgets

    BaseWidget::setPropertyValue(ObjectPropertyTypeEnum::XPos,"0:1024");
    BaseWidget::setPropertyValue(ObjectPropertyTypeEnum::YPos,"0:780");
    BaseWidget::setPropertyValue(ObjectPropertyTypeEnum::Width,"0:200");
    BaseWidget::setPropertyValue(ObjectPropertyTypeEnum::Height,"0:200");

    BaseWidget::getWidget()->setContextMenuPolicy(Qt::CustomContextMenu);  // Catch context menu events
    BaseWidget::getWidget()->installEventFilter(this);

    BaseWidget::getWidget()->setAttribute(Qt::WA_AlwaysShowToolTips);
}

SUI::BaseWidget::~BaseWidget()
{
    if (widget != NULL) widget->deleteLater();
}

QWidget *SUI::BaseWidget::getWidget() const {
    return widget;
}

void SUI::BaseWidget::setToolTip(const std::string &tooltip) {
    getWidget()->setToolTip(QString::fromStdString(tooltip));
}

void SUI::BaseWidget::exposeHeightProperty() {
    heightExposed = true;
}

void SUI::BaseWidget::exposeWidthProperty() {
    widthExposed = true;
}

bool SUI::BaseWidget::isWidthExposed() const {
    return widthExposed;
}

bool SUI::BaseWidget::isHeightExposed() const {
    return heightExposed;
}

void SUI::BaseWidget::setFocus() {
    if (getWidget() != NULL) getWidget()->setFocus();
}

void SUI::BaseWidget::setGeometry() {
    int x = getProperty(SUI::ObjectPropertyTypeEnum::XPos)->getValue().toInt();
    int y = getProperty(SUI::ObjectPropertyTypeEnum::YPos)->getValue().toInt();
    int height = getProperty(SUI::ObjectPropertyTypeEnum::Height)->getValue().toInt();
    int width = getProperty(SUI::ObjectPropertyTypeEnum::Width)->getValue().toInt();

    if (getObjectContext() != SUI::BaseWidget::Gui) {
        // When used in the editor, do not set x and y.
        // This is done since in the editor, the actual widgets are wrapped in a DragAndDropWidget
        x = 0;
        y = 0;
    }
    widget->setGeometry(x, y, width, height);
}

void SUI::BaseWidget::setGeometry(int x, int y, int w, int h) {
    setPropertyValue(ObjectPropertyTypeEnum::XPos, QString::number(x));
    setPropertyValue(ObjectPropertyTypeEnum::YPos, QString::number(y));
    setPropertyValue(ObjectPropertyTypeEnum::Width, QString::number(w));
    setPropertyValue(ObjectPropertyTypeEnum::Height, QString::number(h));
    widget->setGeometry(x,y,w,h);
}

SUI::Rect SUI::BaseWidget::getGeometry() const {
    return SUI::Rect(widget->geometry().x(),
                     widget->geometry().y(),
                     widget->geometry().width(),
                     widget->geometry().height());
}

void SUI::BaseWidget::setVisible(bool visible) {
    getProperty(SUI::ObjectPropertyTypeEnum::Visible)->setValue(visible ? "true" : "false");
    getWidget()->setVisible(visible);
}

void SUI::BaseWidget::setEnabled(bool enabled) {
    getProperty(SUI::ObjectPropertyTypeEnum::Enable)->setValue(enabled ? "true" : "false");
    getWidget()->setEnabled(enabled);
}

void SUI::BaseWidget::setMode(ErrorModeEnum::ErrorMode mode) {
    if (mode != ErrorModeEnum::None) {
        getWidget()->setProperty("BGColorSet", QString::fromStdString(ErrorModeEnum::toString(mode)));
    }
    else {
        getWidget()->setProperty("BGColorSet", getPropertyValue(SUI::ObjectPropertyTypeEnum::BGColor).toLower());
    }
    getWidget()->style()->polish(getWidget());
}

bool SUI::BaseWidget::isEnabled() const {
    if (!getPropertyTypes().contains(SUI::ObjectPropertyTypeEnum::Enable)) return true;
    return (getPropertyValue(SUI::ObjectPropertyTypeEnum::Enable).compare("true", Qt::CaseInsensitive) == 0);
}

bool SUI::BaseWidget::eventFilter(QObject *object, QEvent *event) {
    if (!isToolTipEnabled() && event->type() == QEvent::ToolTip) {
        return true;
    }

    // Ignore the event, otherwise some widgets will not pass the event to the parent. Like a label widget
    // QLabel for example has the mouserelease event being accepted and it will not be passed to a user control.
    event->ignore();

    return QObject::eventFilter(object, event);
}

std::string SUI::BaseWidget::getToolTip() const {
    return getWidget()->toolTip().toStdString();
}

QSet<SUI::ObjectPropertyTypeEnum::Type> SUI::BaseWidget::getPropertyTypes() const {
    QSet<SUI::ObjectPropertyTypeEnum::Type> typeSet = ObjectProperties::getPropertyTypes();

    if (typeSet.contains(SUI::ObjectPropertyTypeEnum::Height)) {
        if (!isHeightExposed() || getProperty(SUI::ObjectPropertyTypeEnum::Sizeable)->getValue().toLower() == "false") {
            typeSet.remove(SUI::ObjectPropertyTypeEnum::Height);
        }
    }
    else if (typeSet.contains(SUI::ObjectPropertyTypeEnum::Width)) {
        if (!isWidthExposed() && getProperty(SUI::ObjectPropertyTypeEnum::Sizeable)->getValue().toLower() == "false") {
            typeSet.remove(SUI::ObjectPropertyTypeEnum::Width);
        }
    }
    else if (typeSet.contains(SUI::ObjectPropertyTypeEnum::Moveable)) {
        QString id = getProperty(SUI::ObjectPropertyTypeEnum::ID)->getValue();
        if (id != "txaStatus" && id != "btnClose" && id != "btnHelp" && id != "tbw2") {
            typeSet.remove(SUI::ObjectPropertyTypeEnum::Moveable);
        }
    }
    else if (typeSet.contains(SUI::ObjectPropertyTypeEnum::Sizeable)) {
        QString id = getProperty(SUI::ObjectPropertyTypeEnum::ID)->getValue();
        if (id != "txaStatus" && id != "btnClose" && id != "btnHelp" && id != "tbw2") {
            typeSet.remove(SUI::ObjectPropertyTypeEnum::Sizeable);
        }
    }

    //FIXME this is a dirty fix
    if (getObjectType() == SUI::ObjectType::TabPage) {
        if (typeSet.contains(SUI::ObjectPropertyTypeEnum::StateList)) {
            typeSet.remove(SUI::ObjectPropertyTypeEnum::StateList);
        }
    }
    return typeSet;
}

void SUI::BaseWidget::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseObject::setPropertyValue(propertyID,propertyValue);

    switch (propertyID)
    {

    case ObjectPropertyTypeEnum::ID:
        getWidget()->setObjectName(QString::fromStdString(getId()));
        break;

    case ObjectPropertyTypeEnum::Menu:
        if (getObjectContext() == BaseWidget::Gui && getWidget() != NULL && getPropertyValue(ObjectPropertyTypeEnum::Menu) != "") {
            connect(getWidget(), SIGNAL(customContextMenuRequested(QPoint)), this, SLOT(onCustomContextMenuRequest(QPoint)) , Qt::UniqueConnection);
        }
        getProperty(ObjectPropertyTypeEnum::Menu)->setValue(propertyValue);
        break;

    case ObjectPropertyTypeEnum::Enable:
        if (getObjectContext() == BaseWidget::Gui) setEnabled((propertyValue.compare("true", Qt::CaseInsensitive) == 0));
        break;

    case ObjectPropertyTypeEnum::XPos:
        setGeometry();
        break;

    case ObjectPropertyTypeEnum::YPos:
        setGeometry();
        break;

    case ObjectPropertyTypeEnum::Height:
        setGeometry();
        break;

    case ObjectPropertyTypeEnum::Width:
        setGeometry();
        break;

    case ObjectPropertyTypeEnum::AutoScroll:
        getProperty(ObjectPropertyTypeEnum::AutoScroll)->setValue(propertyValue.toLower());
        break;

    case ObjectPropertyTypeEnum::DefaultState:
        getProperty(propertyID)->setCurrentIndex((QStringList(getProperty(propertyID)->getValues().split(";")).indexOf(propertyValue)));
        break;

    case ObjectPropertyTypeEnum::ToolTip:
        getWidget()->setToolTip(propertyValue);
        break;

    case SUI::ObjectPropertyTypeEnum::StyleSheetClass: {
        if(propertyValue.isEmpty() == false) {
            SUI::Widget *widget_t = dynamic_cast<SUI::Widget*>(SUI::ObjectFactory::getInstance()->toObject(this));
            widget_t->setStyleSheetClass(propertyValue.toStdString());
        }
        break;
    }

    default:
        break;
    }
}
QString SUI::BaseWidget::getContextMenuSelectedActionString(QPoint point) {
   
    QString selectedAction = QString::null;
    if (getWidget() != NULL) {
        QPoint globalPos = getWidget()->mapToGlobal(point);
        QString str = getPropertyValue(SUI::ObjectPropertyTypeEnum::Menu).replace(QRegExp("\\n"), ";");
        QStringList values = str.split(";", QString::SkipEmptyParts);

        BOOST_FOREACH(QString var, values) new QAction(var, this);

        QMenu widgetMenu;
        widgetMenu.setObjectName("ViewerMenu");
        QList<QAction *> actionList = findChildren<QAction *>();
        BOOST_FOREACH(QAction *pb, actionList) widgetMenu.addAction(pb);

        widgetMenu.setStyleSheet(QString::fromStdString(SUI::StyleSheet::getInstance()->getStyleSheet()));
        QAction *selectedAct = widgetMenu.exec(globalPos);

        if (actionList.contains(selectedAct) == true) {
            selectedAction = selectedAct->text();
            SUI::Widget *widget_t = dynamic_cast<SUI::Widget*>(SUI::ObjectFactory::getInstance()->toObject(this));
            if (!widget_t->contextMenuClicked.empty()) {
               widget_t->contextMenuClicked(getPropertyValue(SUI::ObjectPropertyTypeEnum::ID).toStdString(), selectedAction.toStdString());
            }
        }
        BOOST_FOREACH(QAction * pb, actionList) {
            delete pb;
            pb = NULL;
        }
    }
    return selectedAction;
}


void SUI::BaseWidget::onCustomContextMenuRequest(QPoint point) {
    getContextMenuSelectedActionString(point);
}
void SUI::BaseWidget::addCellProperties(SUI::AlignmentEnum::Alignment alignment, std::string cellname) {
    addProperty(new SUI::ObjectProperty(SUI::ObjectProperty::getDefaultObjectProperty(SUI::ObjectPropertyTypeEnum::CellAlignment)));
    addProperty(new SUI::ObjectProperty(SUI::ObjectProperty::getDefaultObjectProperty(SUI::ObjectPropertyTypeEnum::CellName)));
    setPropertyValue(SUI::ObjectPropertyTypeEnum::CellAlignment,QString::fromStdString(SUI::AlignmentEnum::toString(alignment)));
    setPropertyValue(SUI::ObjectPropertyTypeEnum::CellName,QString::fromStdString(cellname));
}

void SUI::BaseWidget::setContextMenuItems(const std::list<std::string> &items) {
    QStringList itemList;
    BOOST_FOREACH (const std::string &item, items) itemList.append(QString::fromStdString(item));
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Menu,itemList.join(";"));
}

std::list<std::string> SUI::BaseWidget::getContextMenuItems() const {
    std::list<std::string> itemList;
    QStringList items = getPropertyValue(SUI::ObjectPropertyTypeEnum::Menu).split(";");
    BOOST_FOREACH (const QString &item, items) itemList.push_back(item.toStdString());
    return itemList;
}
