//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::UILoader.
// !\description Class implementation file for SUI::UILoader.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "FWQxCore/SUIUILoader.h"

#include <QString>
#include <QFileDialog>
#include <QMessageBox>
#include <QTemporaryFile>
#include <QFileInfo>

#include "SUIDialogImpl.h"
#include "SUILegacyXMLConverter.h"
#include "SUIFileDialogImpl.h"
#include "SUIObjectFactoryImpl.h"
#include "FWQxWidgets/SUIDialog.h"
#include "FWQxCore/SUIResourcePath.h"

SUI::Dialog *SUI::UILoader::loadUI(const std::string &xmlFile, const std::string &id, SUI::Widget *parent)
{
    QWidget *qParent = NULL;
    if (parent != NULL) qParent = dynamic_cast<SUI::BaseWidget*>(SUI::ObjectFactory::getInstance()->toBaseObject(parent))->getWidget();
    QString file = QString::fromStdString(SUI::ResourcePath::getResourceFile(xmlFile));
    QFileInfo xmlFileInfo(file);
    QString tempFileTemplate = QString("%1%2%3").arg(QDir::tempPath()).arg(QDir::separator()).arg(xmlFileInfo.fileName().replace(".xml","_tmp_sui_XXXXXX.save"));
    QTemporaryFile tempFile(tempFileTemplate);

    if (!tempFile.open()) {
        std::cerr << "Could not open tempfile ..." << std::endl;
        exit(1);
    }

    if (SUI::LegacyXMLConverter::isLegacy(file)) {
        SUI::LegacyXMLConverter::convertLegacyXmlFile(file, tempFile.fileName());
        file = tempFile.fileName();
    }
    SUI::Dialog *dialog = new DialogImpl(file,QString::fromStdString(id),qParent);
    //temp file goes out of scope and is deleted
    return dialog;
}


