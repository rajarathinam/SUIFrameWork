//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::DateTimeImpl.
// !\description Class implementation file for SUI::DateTimeImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIDateTimeImpl.h"

#include "FWQxUtils/SUIDate.h"
#include "FWQxUtils/SUITime.h"

SUI::DateTimeImpl::DateTimeImpl() :
    QDateTime(QDateTime::currentDateTime()),
    DateTime()
{
}

void SUI::DateTimeImpl::addDays(int ndays) {
    QDateTime dt = QDateTime::addDays(ndays);
    QDateTime::setDate(dt.date());
}

void SUI::DateTimeImpl::addMSecs(int64_t msecs) {
    QDateTime dt = QDateTime::addMSecs(msecs);
    QDateTime::setTime(dt.time());
    QDateTime::setDate(dt.date());
}

void SUI::DateTimeImpl::addMonths(int nmonths) {
    QDateTime dt = QDateTime::addMonths(nmonths);
    QDateTime::setDate(dt.date());
}

void SUI::DateTimeImpl::addSecs(int s) {
    QDateTime dt = QDateTime::addSecs(s);
    QDateTime::setTime(dt.time());
    QDateTime::setDate(dt.date());
}

void SUI::DateTimeImpl::addYears(int nyears) {
    QDateTime dt = QDateTime::addYears(nyears);
    QDateTime::setDate(dt.date());
}

int SUI::DateTimeImpl::daysTo(const boost::shared_ptr<SUI::DateTime> &other) const {
    return QDateTime::daysTo(*boost::dynamic_pointer_cast<QDateTime>(other));
}

bool SUI::DateTimeImpl::isNull() const {
    return QDateTime::isNull();
}

bool SUI::DateTimeImpl::isValid() const {
    return QDateTime::isValid();
}

int64_t SUI::DateTimeImpl::getMsecsTo(const boost::shared_ptr<DateTime> &other) const {
    return QDateTime::msecsTo(*boost::dynamic_pointer_cast<QDateTime>(other));
}

int SUI::DateTimeImpl::getSecsTo(const boost::shared_ptr<DateTime> &other) const {
    return QDateTime::secsTo(*boost::dynamic_pointer_cast<QDateTime>(other));
}

void SUI::DateTimeImpl::setDate(const boost::shared_ptr<Date> &date) {
    QDateTime::setDate(*boost::dynamic_pointer_cast<QDate>(date));
}

void SUI::DateTimeImpl::setMSecsSinceEpoch(int64_t msecs) {
    QDateTime::setMSecsSinceEpoch(msecs);
}

void SUI::DateTimeImpl::setTime(const boost::shared_ptr<Time> &time) {
    QDateTime::setTime(*boost::dynamic_pointer_cast<QTime>(time));
}

void SUI::DateTimeImpl::setTimeSpec(DateTimeEnum::TimeSpec spec) {
    QDateTime::setTimeSpec((Qt::TimeSpec)spec);
}

void SUI::DateTimeImpl::setTime_t(uint seconds) {
    QDateTime::setTime_t(seconds);
}

boost::shared_ptr<SUI::Time> SUI::DateTimeImpl::getTime() const {
    boost::shared_ptr<Time> t(Time::createTime());
    t->setHMS(QDateTime::time().hour(),QDateTime::time().minute(),QDateTime::time().second());
    return t;
}

SUI::DateTimeEnum::TimeSpec SUI::DateTimeImpl::getTimeSpec() const {
    return (SUI::DateTimeEnum::TimeSpec) QDateTime::timeSpec();
}

int64_t SUI::DateTimeImpl::toMSecsSinceEpoch() const {
    return QDateTime::toMSecsSinceEpoch();
}

std::string SUI::DateTimeImpl::toString(const std::string &format) const {
    return QDateTime::toString(QString::fromStdString(format)).toStdString();
}

std::string SUI::DateTimeImpl::toString(DateTimeEnum::DateFormat format) const {
    return QDateTime::toString((Qt::DateFormat)format).toStdString();
}

uint SUI::DateTimeImpl::toTime_t() const {
    return QDateTime::toTime_t();
}

bool SUI::DateTimeImpl::operator!=(const boost::shared_ptr<SUI::DateTime> &d) const {
    return *dynamic_cast<const QDate*>(this) != *boost::dynamic_pointer_cast<QDate>(d);
}

bool SUI::DateTimeImpl::operator<(const boost::shared_ptr<SUI::DateTime> &d) const {
    return *dynamic_cast<const QDate*>(this) < *boost::dynamic_pointer_cast<QDate>(d);
}

bool SUI::DateTimeImpl::operator<=(const boost::shared_ptr<SUI::DateTime> &d) const {
    return *dynamic_cast<const QDate*>(this) <= *boost::dynamic_pointer_cast<QDate>(d);
}

bool SUI::DateTimeImpl::operator==(const boost::shared_ptr<SUI::DateTime> &d) const {
    return *dynamic_cast<const QDate*>(this) == *boost::dynamic_pointer_cast<QDate>(d);
}

bool SUI::DateTimeImpl::operator>(const boost::shared_ptr<SUI::DateTime> &d) const {
    return *dynamic_cast<const QDate*>(this) > *boost::dynamic_pointer_cast<QDate>(d);
}

bool SUI::DateTimeImpl::operator>=(const boost::shared_ptr<SUI::DateTime> &d) const {
    return *dynamic_cast<const QDate*>(this) >= *boost::dynamic_pointer_cast<QDate>(d);
}
