//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::TimeImpl.
// !\description Class implementation file for SUI::TimeImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|



#include "SUITimeImpl.h"

SUI::TimeImpl::TimeImpl() :
    QTime(QTime::currentTime()),
    Time()
{
}

void SUI::TimeImpl::addMSecs(int ms) {
    QTime t = QTime::addMSecs(ms);
    setHMS(t.hour(),t.minute(),t.second(),t.msec());
}

void SUI::TimeImpl::addSecs(int s) {
    QTime t = QTime::addSecs(s);
    setHMS(t.hour(),t.minute(),t.second(),t.msec());
}

int SUI::TimeImpl::getElapsed() const {
    return QTime::elapsed();
}

int SUI::TimeImpl::getHour() const {
    return QTime::hour();
}

bool SUI::TimeImpl::isNull() const {
    return QTime::isNull();
}

bool SUI::TimeImpl::isValid() const {
    return QTime::isValid();
}

int SUI::TimeImpl::getMinute() const {
    return QTime::minute();
}

int SUI::TimeImpl::getMsec() const {
    return QTime::msec();
}

int SUI::TimeImpl::restart() {
    return QTime::restart();
}

int SUI::TimeImpl::getSecond() const {
    return QTime::second();
}

bool SUI::TimeImpl::setHMS(int h, int m, int s, int ms) {
    return QTime::setHMS(h,m,s,ms);
}

void SUI::TimeImpl::start() {
    QTime::start();
}

std::string SUI::TimeImpl::toString(const std::string &format) const {
    return QTime::toString(QString::fromStdString(format)).toStdString();
}

std::string SUI::TimeImpl::toString(SUI::DateTimeEnum::DateFormat format) const {
    return QTime::toString((Qt::DateFormat)format).toStdString();
}

bool SUI::TimeImpl::operator!=(const boost::shared_ptr<SUI::Time> &d) const {
    return *dynamic_cast<const QTime*>(this) != *boost::dynamic_pointer_cast<QTime>(d);
}

bool SUI::TimeImpl::operator<(const boost::shared_ptr<SUI::Time> &d) const {
    return *dynamic_cast<const QTime*>(this) < *boost::dynamic_pointer_cast<QTime>(d);
}

bool SUI::TimeImpl::operator<=(const boost::shared_ptr<SUI::Time> &d) const {
    return *dynamic_cast<const QTime*>(this) <= *boost::dynamic_pointer_cast<QTime>(d);
}

bool SUI::TimeImpl::operator==(const boost::shared_ptr<SUI::Time> &d) const {
    return *dynamic_cast<const QTime*>(this) == *boost::dynamic_pointer_cast<QTime>(d);
}

bool SUI::TimeImpl::operator>(const boost::shared_ptr<SUI::Time> &d) const {
    return *dynamic_cast<const QTime*>(this) > *boost::dynamic_pointer_cast<QTime>(d);
}

bool SUI::TimeImpl::operator>=(const boost::shared_ptr<SUI::Time> &d) const {
    return *dynamic_cast<const QTime*>(this) >= *boost::dynamic_pointer_cast<QTime>(d);
}

