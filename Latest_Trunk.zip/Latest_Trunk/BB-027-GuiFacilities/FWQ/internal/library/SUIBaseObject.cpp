//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::BaseObject.
// !\description Class implementation file for SUI::BaseObject.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIBaseObject.h"
#include "FWQxWidgets/SUIWidget.h"

#include "FWQxCore/SUIColorEnum.h"
#include "SUIStyleSheet.h"
#include "FWQxCore/SUIObjectFactory.h"

#include <QStringList>
SUI::BaseObject::BaseObject(const ObjectContext &objectContext_t, const ObjectType::Type &objectType_t, bool supportsChildren) :
    ObjectProperties(supportsChildren),
    objectType(objectType_t),
    objectContext(objectContext_t),
    toolTipEnabled(true)
{
    // adds the properties
    ObjectProperty::setPropertyTypes(this);

}

void SUI::BaseObject::setDefaultProperties(const SUI::BaseObject::ObjectContext &context) {
    setObjectContext(context);
    const std::list<ColorEnum::Color> colors = ColorEnum::getColorEnumList(objectType);
    if (colors.size() > 0) {
        // add the colors
        setPropertyValues(SUI::ObjectPropertyTypeEnum::Color, QString::fromStdString(ColorEnum::toString(colors,";")));
        setPropertyValues(SUI::ObjectPropertyTypeEnum::BGColor, QString::fromStdString(ColorEnum::toString(colors,";")));

        // set the default colors
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Color, QString::fromStdString(ColorEnum::toString(colors.front())));
        setPropertyValue(SUI::ObjectPropertyTypeEnum::BGColor, QString::fromStdString(ColorEnum::toString(colors.front())));
    }

    const std::list<std::string> styleclass = StyleSheet::getInstance()->getStyleSheetClassByObjectType(objectType);
    QStringList styleClassList;
    for (std::list<std::string>::const_iterator it = styleclass.begin(); it != styleclass.end(); ++it) {
        styleClassList.append(QString::fromStdString(*it));
    }
    if(styleclass.size() > 0){
        setPropertyValues(SUI::ObjectPropertyTypeEnum::StyleSheetClass, styleClassList.join(";"));
    }
}

void SUI::BaseObject::setId(const std::string &id) {
    getProperty(SUI::ObjectPropertyTypeEnum::ID)->setValue(QString::fromStdString(id));
}

std::string SUI::BaseObject::getId() const {
    return getPropertyTypes().contains(SUI::ObjectPropertyTypeEnum::ID) ? getProperty(SUI::ObjectPropertyTypeEnum::ID)->getValue().toStdString() : "";
}

bool SUI::BaseObject::isVisible() const {
    if (!getPropertyTypes().contains(SUI::ObjectPropertyTypeEnum::Visible)) return true;
    return (getPropertyValue(SUI::ObjectPropertyTypeEnum::Visible).compare("true", Qt::CaseInsensitive) == 0);
}

bool SUI::BaseObject::isToolTipEnabled() const {
    return toolTipEnabled;
}

void SUI::BaseObject::setToolTipEnabled(bool enabled) {
    toolTipEnabled = enabled;
}

SUI::ObjectType::Type SUI::BaseObject::getObjectType() const {
   return objectType;
}

SUI::BaseObject::ObjectContext SUI::BaseObject::getObjectContext() const {
    return objectContext;
}

void SUI::BaseObject::setObjectContext(const SUI::BaseObject::ObjectContext &context) {
    objectContext = context;
}

void SUI::BaseObject::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    ObjectProperty *prop = getProperty(propertyID);
    if (prop == NULL) return;

    prop->setValue(propertyValue);

    switch (propertyID)
    {
    case SUI::ObjectPropertyTypeEnum::Visible:
        if (getObjectContext() == SUI::BaseObject::Gui) setVisible((propertyValue.compare("true", Qt::CaseInsensitive) == 0));
        break;

    case SUI::ObjectPropertyTypeEnum::ToolTip:
        if (propertyValue.isEmpty() && getObjectType() == SUI::ObjectType::LineEdit) { // TODO remove LineEdit stuff
            setToolTip(getPropertyValue(SUI::ObjectPropertyTypeEnum::RegExpTip).toStdString());
        }
        else {
            setToolTip(propertyValue.toStdString());
        }
        break;

    case SUI::ObjectPropertyTypeEnum::ToolTipEnable:
        getProperty(SUI::ObjectPropertyTypeEnum::ToolTipEnable)->setValue(propertyValue.toLower());
        setToolTipEnabled(propertyValue.toLower() == "true");
        break;

    default:
        break;
    }
}

