//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for CustomGraphicsEllipseItem.
// !\description Class implementation file for CustomGraphicsEllipseItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "CustomGraphicsEllipseItem.h"

#include <QPainter>

CustomGraphicsEllipseItem::CustomGraphicsEllipseItem(const QRectF &rect, QGraphicsItem *parent) :
   QGraphicsEllipseItem(rect,parent)
{   
}

void CustomGraphicsEllipseItem::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) {
   painter->save();
   painter->setRenderHints(QPainter::Antialiasing);
   QGraphicsEllipseItem::paint(painter,option,widget);
   painter->restore();
}
