//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for CustomFileDialog.
// !\description Class implementation file for CustomFileDialog.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "CustomFileDialog.h"

#include <QWidget>
#include <QMouseEvent>

#include "SUIFileDialogImpl.h"

CustomFileDialog::CustomFileDialog(QWidget *parent) :
    QFileDialog(parent)
{
}

void CustomFileDialog::changeEvent(QEvent *e) {
    QFileDialog::changeEvent(e);
}

void CustomFileDialog::mousePressEvent(QMouseEvent *e) {
    switch (e->buttons())
    {
    case Qt::LeftButton :
        //if focus is on filebrowser check directory
        QDialog::mousePressEvent(e);
        break;
    default:
        QDialog::mousePressEvent(e);
        break;
    }
}
