//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for HeaderTags.
// !\description Class implementation file for HeaderTags.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "CustomHeaderTags.h"
#include <boost/foreach.hpp>

HeaderTags::HeaderTags(const QString &tagname) :
    mTagName(tagname)
{
}

HeaderTags::HeaderTags(const QString &tagname, const QString &childtags) :
    mTagName(tagname)
{
    int startPos = 0;
    int subStartPos = 0;
    int depth = 0;

    for (int ind = 0; ind < childtags.size(); ind++) {
        if (childtags.at(ind) == '<') {
            ++depth;
            if ((depth == 2) && (subStartPos == 0)) {
                subStartPos = ind;
            }
        }
        else if (childtags.at(ind) == '>') {
            --depth;
        }
        if (depth == 0) {
            HeaderTags  *item;
            if (subStartPos == 0) {
                QString tagName = childtags.mid(startPos + 1, ind - (startPos + 1));
                item = new HeaderTags(tagName);
            }
            else {
                QString tagName = childtags.mid(startPos + 1, subStartPos - (startPos + 1));
                QString tagChildren = childtags.mid(subStartPos, ind - subStartPos + 1);
                item = new HeaderTags(tagName, tagChildren);
            }
            mChildren.append(item);
            startPos = ind + 1;
            subStartPos = 0;
        }
    }
}

HeaderTags::~HeaderTags()
{
    BOOST_FOREACH (HeaderTags *child, mChildren) {
        delete child;
        child = NULL;
    }
}

const QList<HeaderTags *> &HeaderTags::getChildren() const {
    return mChildren;
}

QString HeaderTags::getName() const {
    return mTagName;
}
