//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for CustomGraphicsView.
// !\description Class implementation file for CustomGraphicsView.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "CustomGraphicsView.h"

#include <QMouseEvent>
#include <QRubberBand>
#include <QTimer>

#include <qmath.h>

CustomGraphicsView::CustomGraphicsView(QWidget *parent) :
    QGraphicsView(parent),
    mRubberBand(new QRubberBand(QRubberBand::Rectangle,viewport())),
    mAspectRatioMode(Qt::KeepAspectRatio),
    mouseWheelZoomEnabled(false),
    mScaleFactor(1.1)
{
}

CustomGraphicsView::~CustomGraphicsView() 
{
    if (mRubberBand != NULL) {
        mRubberBand->deleteLater();
    }
}

void CustomGraphicsView::hideEvent(QHideEvent *event) {
    QGraphicsView::hideEvent(event);
    emit visibilityChanged(false);
}

void CustomGraphicsView::showEvent(QShowEvent *event) {
    QGraphicsView::showEvent(event);
    emit visibilityChanged(true);
}

void CustomGraphicsView::mousePressEvent(QMouseEvent *event) {
   QGraphicsView::mousePressEvent(event);
   if (QGraphicsView::dragMode() == QGraphicsView::RubberBandDrag) {
       mMouseOrigin = event->pos();
       mRubberBand->setGeometry(QRect(event->pos(),QSize()));
       mRubberBand->show();
   }
}

void CustomGraphicsView::mouseMoveEvent(QMouseEvent *event) {
   QGraphicsView::mouseMoveEvent(event);
   if (QGraphicsView::dragMode() == QGraphicsView::RubberBandDrag) {
       mRubberBand->setGeometry(QRect(mRubberBand->geometry().topLeft(),event->pos()).normalized());
   }
}

void CustomGraphicsView::mouseReleaseEvent(QMouseEvent *event) {
    QGraphicsView::mouseReleaseEvent(event);
    if (QGraphicsView::dragMode() == QGraphicsView::RubberBandDrag) {

        QPoint mouseend = event->pos();
        QRectF zoomRectInScene = QRectF(mapToScene(mMouseOrigin),mapToScene(mouseend));

        if (zoomRectInScene.width() > 0 && zoomRectInScene.height() > 0) {
            fitInView(zoomRectInScene,mAspectRatioMode);
        }
        else {
            fitInView(sceneRect(),mAspectRatioMode);
        }
        mRubberBand->hide();
    }    
}

void CustomGraphicsView::wheelEvent(QWheelEvent *event) {
   QGraphicsView::wheelEvent(event);
   if (mouseWheelZoomEnabled && QGraphicsView::dragMode() != QGraphicsView::RubberBandDrag) {
       double scaleValue = event->delta() > 0 ? mScaleFactor : 1.0 / mScaleFactor;
       QGraphicsView::setTransformationAnchor(QGraphicsView::AnchorUnderMouse);
       QGraphicsView::scale(scaleValue, scaleValue);
   }
}

void CustomGraphicsView::zoom(double scaleFactor, int x, int y) {
   QGraphicsView::setTransformationAnchor(QGraphicsView::AnchorViewCenter);
   QGraphicsView::resetTransform();
   qreal zoomFactor = scaleFactor < 0 ? -1.0/scaleFactor : scaleFactor;
   QGraphicsView::scale(zoomFactor, zoomFactor);
   QGraphicsView::centerOn(x, y);
}

void CustomGraphicsView::setScaleFactor(double scale) {
    mScaleFactor = scale;
}

double CustomGraphicsView::getScaleFactor() {
    return mScaleFactor;
}

double CustomGraphicsView::getScale() const {
    return qSqrt(qPow(matrix().m11(),2.0) + 2*matrix().m12());
}

void CustomGraphicsView::setScrollBarsEnabled(bool scrollBars) {
    Qt::ScrollBarPolicy policy = scrollBars ? Qt::ScrollBarAsNeeded : Qt::ScrollBarAlwaysOff;
    QGraphicsView::setHorizontalScrollBarPolicy(policy);
    QGraphicsView::setVerticalScrollBarPolicy(policy);
}

bool CustomGraphicsView::isScrollBarsEnabled() const {
    return QGraphicsView::horizontalScrollBarPolicy() == Qt::ScrollBarAsNeeded;
}

void CustomGraphicsView::fitInView() {
    QGraphicsView::fitInView(sceneRect(),mAspectRatioMode);
}

void CustomGraphicsView::setMouseWheelZoomEnabled(bool enabled) {
    mouseWheelZoomEnabled = enabled;
}

void CustomGraphicsView::fitInView(const QRectF &rect, Qt::AspectRatioMode aspectRatioMode) {
    mAspectRatioMode = aspectRatioMode;
    QGraphicsView::fitInView(rect,aspectRatioMode);
}

void CustomGraphicsView::fitInView(qreal x, qreal y, qreal w, qreal h, Qt::AspectRatioMode aspectRatioMode) {
    fitInView(QRectF(x,y,w,h),aspectRatioMode);
}

Qt::AspectRatioMode CustomGraphicsView::getAspectRatioMode() const {
    return mAspectRatioMode;
}

QRectF CustomGraphicsView::removeMarginBug(const QRectF &sceneRect, const QSize &viewerSize) {
   const double mx = sceneRect.width()/static_cast<double>(viewerSize.width());
   const double my = sceneRect.height()/static_cast<double>(viewerSize.height());
   return sceneRect.adjusted(mx,my,-mx,-my);
}


void CustomGraphicsView::onSceneRectChanged(QRectF) {
    fitInView();
    
    //FIXME this is a hack to trigger the fit, it should not be needed! The first call to fitInView should be enough.
    //FIXME There must be a "simple" solution. To be investigated!
    QTimer::singleShot(500,this,SLOT(fitInView()));
    //FIXME END
}
