//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for CustomLabel.
// !\description Class implementation file for CustomLabel.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "CustomLabel.h"
#include <QPainter>

CustomLabel::CustomLabel(QWidget *parent) :
    QLabel(parent),
    mSearchString(QString::null),
    mHighlightBeginString(QString::null),
    mDoHighlight(false)
{
}

bool CustomLabel::setHighlightText(const QString &searchText, const QColor &color) {
    mDoHighlight = false;
    int position = this->text().toUpper().indexOf(searchText.toUpper(), Qt::CaseInsensitive);
    if(-1 != position && !this->text().isEmpty()) {
        mSearchString = searchText;
        mDoHighlight = true;
        mHighlightBeginString = this->text().left(position);
        mHighlightColor = color;
    }
    this->update();
    return mDoHighlight;
}

void CustomLabel::mousePressEvent(QMouseEvent *event) {
    QLabel::mousePressEvent(event);
    emit select();
}

void CustomLabel::hideEvent(QHideEvent *event) {
    QLabel::hideEvent(event);
    emit visibilityChanged(false);
}

void CustomLabel::showEvent(QShowEvent *event) {
    QLabel::showEvent(event);
    emit visibilityChanged(true);
}

void CustomLabel::paintEvent(QPaintEvent *event) {
    QPainter painter(this);
    if(mDoHighlight) {
        int beginStringWidth = this->fontMetrics().boundingRect(this->rect(), this->alignment(), mHighlightBeginString).width();
        int searchStringWidth = this->fontMetrics().boundingRect(this->rect(), this->alignment(), mSearchString).width();

        QRect highlightRect = this->fontMetrics().boundingRect(this->rect(), this->alignment(), this->text());
        highlightRect.setRect(highlightRect.x() + beginStringWidth, highlightRect.y(), searchStringWidth, highlightRect.height());
        painter.fillRect(highlightRect, mHighlightColor);
    }
    QLabel::paintEvent(event);
}
