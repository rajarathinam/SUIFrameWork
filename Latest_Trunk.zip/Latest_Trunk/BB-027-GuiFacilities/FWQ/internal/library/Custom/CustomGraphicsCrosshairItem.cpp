//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for CustomGraphicsCrosshairItem.
// !\description Class implementation file for CustomGraphicsCrosshairItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "CustomGraphicsCrosshairItem.h"

#include <QPainter>

CustomGraphicsCrosshairItem::CustomGraphicsCrosshairItem(QGraphicsItem *parent) :
    QGraphicsEllipseItem(parent)
{
}

void CustomGraphicsCrosshairItem::paint(QPainter *painter, const QStyleOptionGraphicsItem */*option*/, QWidget */*widget*/) {
    painter->setPen(pen());
    painter->setRenderHint(QPainter::Antialiasing);

    qreal halfPenWidth = pen().width()*0.5;
    const QPointF top(rect().center().x(),rect().top()+halfPenWidth);
    const QPointF bottom(rect().center().x(),rect().bottom()-halfPenWidth);
    const QPointF left(rect().left()+halfPenWidth,rect().center().y());
    const QPointF right(rect().right()-halfPenWidth,rect().center().y());

    painter->drawLine(top,bottom);
    painter->drawLine(left,right);
}


