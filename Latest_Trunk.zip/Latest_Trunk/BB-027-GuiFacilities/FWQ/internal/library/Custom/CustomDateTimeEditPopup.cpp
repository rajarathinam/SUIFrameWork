//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for CustomDateTimeEditPopup.
// !\description Class implementation file for CustomDateTimeEditPopup.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "CustomDateTimeEditPopup.h"

#include <QDateTimeEdit>
#include <QCalendarWidget>
#include <QGridLayout>
#include <QPushButton>
#include <QLabel>
#include <QDockWidget>

CustomDateTimeEditPopup::CustomDateTimeEditPopup(QWidget *parent) :
    QWidget(parent, Qt::Popup)
{
    QGridLayout *gridLayout = new QGridLayout(this);

    mCalendar = new QCalendarWidget(this);
    mUpHourButton = new QPushButton("/\\", this);
    mUpMinButton = new QPushButton("/\\", this);
    mDownHourButton = new QPushButton("V", this);
    mDownMinButton = new QPushButton("V", this);
    mOkButton = new QPushButton(" OK ", this);
    mCancelButton = new QPushButton("Cancel", this);
    mHourLabel = new QLabel("HH", this);
    mMinLabel = new QLabel("MM", this);
    mColonLabel = new QLabel(":", this);

    gridLayout->addWidget(mCalendar, 1, 1, 6, 9, Qt::AlignBottom);
    gridLayout->addWidget(mUpHourButton, 2, 11, 1, 1);
    gridLayout->addWidget(mUpMinButton, 2, 13);
    gridLayout->addWidget(mHourLabel, 3, 11, 1, 1, Qt::AlignHCenter);
    gridLayout->addWidget(mColonLabel, 3, 12, 1, 1,Qt::AlignHCenter);
    gridLayout->addWidget(mMinLabel, 3, 13, 1, 1, Qt::AlignHCenter);
    gridLayout->addWidget(mDownHourButton, 4, 11, 1, 1);
    gridLayout->addWidget(mDownMinButton, 4, 13, 1,1);
    gridLayout->addWidget(mCancelButton, 6, 10, 1, 2);
    gridLayout->addWidget(mOkButton, 6, 12, 1, 2);

    connect(mUpHourButton, SIGNAL(clicked()), this, SLOT(upHourClicked()));
    connect(mUpMinButton, SIGNAL(clicked()), this, SLOT(upMinClicked()));
    connect(mDownHourButton, SIGNAL(clicked()), this, SLOT(downHourClicked()));
    connect(mDownMinButton, SIGNAL(clicked()), this, SLOT(downMinClicked()));
    connect(mOkButton, SIGNAL(clicked()), this, SLOT(okClicked()));
    connect(mCancelButton, SIGNAL(clicked()), this, SLOT(cancelClicked()));
}

CustomDateTimeEditPopup::~CustomDateTimeEditPopup() {
    delete mCalendar;
    delete mUpHourButton;
    delete mUpMinButton;
    delete mDownHourButton;
    delete mDownMinButton;
    delete mHourLabel;
    delete mColonLabel;
    delete mMinLabel;
    delete mOkButton;
    delete mCancelButton;
}

void CustomDateTimeEditPopup::setDate(const QDate &date) {
    mCalendar->setSelectedDate(date);
}

void CustomDateTimeEditPopup::setTime(const QTime &time) {
    mHourLabel->setText(time.toString("hh"));
    mMinLabel->setText(time.toString("mm"));
}

void CustomDateTimeEditPopup::okClicked() {
    QTime time;
    int hour= mHourLabel->text().toInt();
    int min = mMinLabel->text().toInt();
    time.setHMS(hour, min, 0, 0);
    emit newDateTimeSelected(mCalendar->selectedDate(), time);
    close();
}

void CustomDateTimeEditPopup::cancelClicked() {
    close();
}

void CustomDateTimeEditPopup::upHourClicked() {
    int hour = mHourLabel->text().toInt();
    hour = hour + 1;
    if (hour == 24) hour = 0;
    mHourLabel->setText(QString::number(hour));
}

void CustomDateTimeEditPopup::upMinClicked() {
    int min = mMinLabel->text().toInt();
    min = min +1;
    if(min == 60) min = 0;
    mMinLabel->setText(QString::number(min));
}

void CustomDateTimeEditPopup::downHourClicked() {
    int hour = mHourLabel->text().toInt();
    if(hour == 0) hour=24;
    hour = hour - 1;
    mHourLabel->setText(QString::number(hour));
}

void CustomDateTimeEditPopup::downMinClicked() {
    int min = mMinLabel->text().toInt();
    if(min == 0) min = 60;
    min = min - 1;
    mMinLabel->setText(QString::number(min));
}

