//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::ObjectProperties.
// !\description Class implementation file for SUI::ObjectProperties.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUIObjectProperties.h"

#include "SUIObjectProperty.h"

SUI::ObjectProperties::ObjectProperties(bool supportsChildren_t) :
    supportsChildren(supportsChildren_t)
{
}

SUI::ObjectProperties::~ObjectProperties()
{
    QMap<SUI::ObjectPropertyTypeEnum::Type, SUI::ObjectProperty *>::iterator it;
    for (it = properties.begin(); it != properties.end(); ++it) {
        delete it.value();
    }
    properties.clear();
}

QSet<SUI::ObjectPropertyTypeEnum::Type> SUI::ObjectProperties::getPropertyTypes() const {
    return properties.keys().toSet();
}

QMap<QString, QString> SUI::ObjectProperties::getIncludes() const {
    return includes;
}

void SUI::ObjectProperties::setInclude(const QString &include, const QString &fileName) {
    includes.insert(include,fileName);
}

bool SUI::ObjectProperties::childrenSupported() const {
    return supportsChildren;
}

void SUI::ObjectProperties::addProperty(ObjectProperty *property) {
    properties.insert(property->getObjectPropertyType(), property);
}

SUI::ObjectProperty *SUI::ObjectProperties::getProperty(SUI::ObjectPropertyTypeEnum::Type type) const {
    if (!properties.contains(type)) return NULL;
    return properties[type];
}

void SUI::ObjectProperties::setPropertyReadonly(SUI::ObjectPropertyTypeEnum::Type property, bool readOnly) {
    if (getProperty(property) != NULL) getProperty(property)->setReadOnly(readOnly);
}

bool SUI::ObjectProperties::isPropertyReadonly(SUI::ObjectPropertyTypeEnum::Type property) const {
    return getProperty(property)->isReadOnly();
}

void SUI::ObjectProperties::setPropertyHidden(SUI::ObjectPropertyTypeEnum::Type property, bool /*visible*/) {
    getProperty(property)->setHidden();
}

bool SUI::ObjectProperties::isPropertyVisible(SUI::ObjectPropertyTypeEnum::Type property) const {
    return getProperty(property)->isVisible();
}

void SUI::ObjectProperties::setPropertyValues(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    ObjectProperty *prop = getProperty(propertyID);
    if (prop != NULL) prop->setValues(propertyValue);
}

QString SUI::ObjectProperties::getPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID) const {
    ObjectProperty *prop = getProperty(propertyID);
    return prop ? prop->getValue() : "";
}

QString SUI::ObjectProperties::getPropertyValues(SUI::ObjectPropertyTypeEnum::Type propertyID) const {
    ObjectProperty *prop = getProperty(propertyID);
    return prop ? prop->getValue() : "";
}
void SUI::ObjectProperties::incrementPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, int propertyValue) {
    setPropertyValue(propertyID, QString::number(getPropertyValue(propertyID).toInt() + propertyValue));
}
