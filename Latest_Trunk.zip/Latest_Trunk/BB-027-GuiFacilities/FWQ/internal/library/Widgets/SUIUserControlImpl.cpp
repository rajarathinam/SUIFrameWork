//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::UserControlImpl.
// !\description Class implementation file for SUI::UserControlImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIUserControlImpl.h"
#include <QEvent>

SUI::UserControlImpl::UserControlImpl(QWidget *parent) :
    BaseWidget(new QWidget(parent), SUI::ObjectType::UserControl, true),
    mCurrentID(0)
{
}

bool SUI::UserControlImpl::eventFilter(QObject *obj, QEvent *event) {
    if (event->type() == QEvent::MouseButtonRelease && !clicked.empty()) {
        clicked();
    }
    else if (event->type() == QEvent::MouseButtonPress && !pressed.empty()) {
        pressed();
    }
    else if (event->type() == QEvent::Enter && !hoverEntered.empty()) {
        hoverEntered();
    }
    else if (event->type() == QEvent::Leave && !hoverLeft.empty()) {
        hoverLeft();
    }
    return BaseWidget::eventFilter(obj, event);
}

void SUI::UserControlImpl::handleClicked() {
    if (!clicked.empty()) clicked();
}



