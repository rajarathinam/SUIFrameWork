//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::BusyIndicatorImpl.
// !\description Class implementation file for SUI::BusyIndicatorImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUIBusyIndicatorImpl.h"
#include <QMovie>

SUI::BusyIndicatorImpl::BusyIndicatorImpl(QWidget *parent) :
    BaseWidget(new CustomLabel(parent), SUI::ObjectType::BusyIndicator, false),
    mMovie(new QMovie(":/image/BIRotatingWheel.gif"))
{
    mMovie->setBackgroundColor(Qt::transparent);
    mMovie->start();
    BusyIndicatorImpl::getWidget()->setMovie(mMovie);
    connect(BusyIndicatorImpl::getWidget(), SIGNAL(visibilityChanged(bool)), this, SLOT(onVisibilityChanged(bool)));
}

SUI::BusyIndicatorImpl::~BusyIndicatorImpl() {
    disconnect(getWidget(), SIGNAL(visibilityChanged(bool)), this, SLOT(onVisibilityChanged(bool)));
    if(mMovie != NULL) {
        delete mMovie;
        mMovie = NULL;
    }
}

void SUI::BusyIndicatorImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue)
{
    BaseWidget::setPropertyValue(propertyID, propertyValue);

    switch (propertyID) {
    case SUI::ObjectPropertyTypeEnum::BusyIndicatorImage:
            if (propertyValue.toLower() == "rotatingwheel") {
                if(mMovie->fileName() != QString(":/image/BIRotatingWheel.gif")){
                    mMovie->deleteLater();
                    mMovie = new QMovie(":/image/BIRotatingWheel.gif");
                    mMovie->setBackgroundColor(Qt::transparent);
                    getWidget()->setMovie(mMovie);
                    mMovie->start();
                }
            }
            else {
                if(mMovie->fileName() != QString(":/image/BIRollingDots.gif")){
                    mMovie->deleteLater();
                    mMovie = new QMovie(":/image/BIRollingDots.gif");
                    mMovie->setBackgroundColor(Qt::transparent);
                    getWidget()->setMovie(mMovie);
                    mMovie->start();
                }
            }
        break;
    default:
        break;
    }
}

void SUI::BusyIndicatorImpl::onVisibilityChanged(bool isDisplayed) {
    if (!visibilityChanged.empty()) visibilityChanged(isDisplayed);
}

void SUI::BusyIndicatorImpl::setDefaultProperties(const SUI::BaseObject::ObjectContext &context) {
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "40");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "40");
    BaseWidget::setDefaultProperties(context);
}

CustomLabel *SUI::BusyIndicatorImpl::getWidget() const {
    return dynamic_cast<CustomLabel *>(BaseWidget::getWidget());
}

void SUI::BusyIndicatorImpl::startAnimation() {
    getWidget()->show();
}

void SUI::BusyIndicatorImpl::stopAnimation() {
    getWidget()->hide();
}
