//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::WidgetPageImpl.
// !\description Class implementation file for SUI::WidgetPageImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIWidgetPageImpl.h"

SUI::WidgetPageImpl::WidgetPageImpl(QWidget *parent) :
    BasePageImpl(new QWidget(parent), SUI::ObjectType::WidgetPage, true)
{
}

