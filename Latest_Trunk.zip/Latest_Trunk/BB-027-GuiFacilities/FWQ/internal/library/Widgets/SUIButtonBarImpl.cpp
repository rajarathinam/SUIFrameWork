//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::ButtonBarImpl.
// !\description Class implementation file for SUI::ButtonBarImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIButtonBarImpl.h"

SUI::ButtonBarImpl::ButtonBarImpl(QWidget *parent) :
    BaseWidget(new QWidget(parent), SUI::ObjectType::ButtonBar, true)
{
}

void SUI::ButtonBarImpl::setDefaultProperties(const ObjectContext &context) {
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable, "false");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Sizeable, "false");
    BaseWidget::setObjectContext(context);
}
