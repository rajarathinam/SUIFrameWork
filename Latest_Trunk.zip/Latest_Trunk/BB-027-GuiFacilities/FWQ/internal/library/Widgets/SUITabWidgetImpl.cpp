//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::TabWidgetImpl.
// !\description Class implementation file for SUI::TabWidgetImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUITabWidgetImpl.h"

#include "SUITabPageImpl.h"
#include <QFont>

SUI::TabWidgetImpl::TabWidgetImpl(QWidget *parentWidget) :
    BaseWidget(new CustomTabWidget(parentWidget), SUI::ObjectType::TabWidget, true),
    previousTab(NULL)
{
    exposeHeightProperty();
    exposeWidthProperty();

    QRect tabbarRect = TabWidgetImpl::getWidget()->getTabBar()->rect();
    tabbarRect.setWidth(TabWidgetImpl::getWidget()->width());
    TabWidgetImpl::getWidget()->getTabBar()->setGeometry(tabbarRect);

    connect(TabWidgetImpl::getWidget(),SIGNAL(currentChanged(int)),this,SLOT(onCurrentIndexChanged(int)));
    TabWidgetImpl::getWidget()->setFont(QFont("Sans Serif",12,QFont::Bold));
}

SUI::TabWidgetImpl::~TabWidgetImpl() {
    disconnect(TabWidgetImpl::getWidget(), SIGNAL(currentChanged(int)), this, SLOT(onCurrentIndexChanged(int)));
    tabPages.clear();
    tabPageStatus.clear();
    previousTab = NULL;
}

void SUI::TabWidgetImpl::setDefaultProperties(const ObjectContext &context) {
    BaseWidget::setObjectContext(context);

    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "200");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "200");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, 0);
    setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, 0);

    switch (context) {
    case BaseObject::EditorSelector: {
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "600");
        while (removeTab()){};
        TabPageImpl *tabPage = new TabPageImpl(NULL);
        tabPage->setDefaultProperties(context);
        addNewTab(tabPage);
        break;
    }
    case BaseObject::EditorForm: {
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "600");
        break;
    }
    default:
        break;

    }
}

void SUI::TabWidgetImpl::addNewTab(TabPage *tabPage) {
    TabPageImpl *impl = dynamic_cast<TabPageImpl*>(tabPage);
    impl->getWidget()->setObjectName(QString::fromStdString(tabPage->getId()));
    impl->setTabWidgetParent(this);
    // set the page id
    impl->setPropertyValue(SUI::ObjectPropertyTypeEnum::ID, QString::fromStdString(tabPage->getId()));
    Q_ASSERT(impl->getWidget()->objectName().toStdString() == tabPage->getId());

    // resize the tab bar
    QRect tabbarRect = getWidget()->getTabBar()->rect();
    tabbarRect.setWidth(getWidget()->width());
    getWidget()->getTabBar()->setGeometry(tabbarRect);

    getWidget()->addTab(impl->getWidget(), QString::fromStdString(tabPage->getTabText()));
    // insert the index
    tabPages.append(tabPage);
    tabPageStatus.insert(tabPage,true);

    // set the enabled state of the page
    setTabEnabled(tabPage->getId(),tabPage->isEnabled());

    // set the current index property
    setPropertyValue(SUI::ObjectPropertyTypeEnum::CurrentTabPage, QString::number(getWidget()->currentIndex()));
    tabPage->setVisible(impl->getPropertyValue(SUI::ObjectPropertyTypeEnum::Visible).toLower() == "true" ? true : false);

    // update geometry
    getWidget()->updateGeometry();
}

bool SUI::TabWidgetImpl::removeTab() {
    // do not remove the last tab
    if (getWidget()->count() < 2) return false;
    // get the current TabPage with the name of the widget (id)
    SUI::TabPage *tabPage = getTabPage(getWidget()->currentWidget()->objectName().toStdString());
    // remove the tabpage from the widget
    int index = getWidget()->currentIndex();
    getWidget()->removeTab(index);
    // get the internal index
    int internalIndex = tabPages.indexOf(tabPage);
    // if the internalIndex is valid
    if (internalIndex != -1) {
       // remove the tabpage from the internal administration
       tabPages.remove(internalIndex);
    }
    // true if the internalIndex is valid
    return internalIndex > -1;
}

void SUI::TabWidgetImpl::setTabEnabled(const std::string &id, bool enabled) {
    TabPage *tabPage = getTabPage(id);
    int index = getTabPageIndex(tabPage);
    if (index > -1) {
       getWidget()->setTabEnabled(index,enabled);
       dynamic_cast<TabPageImpl*>(tabPage)->getWidget()->setEnabled(enabled);
    }
}

bool SUI::TabWidgetImpl::isTabEnabled(const std::string &id) const {
    TabPage *tabPage = getTabPage(id);
    return tabPage ? tabPage->isEnabled() : false;
}

SUI::TabPage *SUI::TabWidgetImpl::getCurrentTabPage() const {
    QWidget *widget = getWidget()->currentWidget();
    return widget ? getTabPage(widget->objectName().toStdString()) : NULL;
    }

int SUI::TabWidgetImpl::getCurrentIndex() const {
    return getWidget()->currentIndex();
}

SUI::TabPage *SUI::TabWidgetImpl::getTabPage(const std::string &id) const {
    TabPage *tabPage = NULL;
    for (int index = 0, t = tabPages.count(); index < t; index++) {
        tabPage = tabPages.at(index);
        if(tabPage != NULL) {
            if (tabPage->getId() != id) continue;
            tabPage = tabPages.at(index);
            break;
        }
    }
    return tabPage;
}

SUI::TabPage *SUI::TabWidgetImpl::getTabPage(int index) const {
    TabPage *tabPage = NULL; 
    QWidget *widget = getWidget()->widget(index);
    if (widget != NULL) {
        tabPage = getTabPage(widget->objectName().toStdString());                
    }
    return tabPage;
}

int SUI::TabWidgetImpl::getTabPageIndex(SUI::TabPage *tabPage) const {
    int index = -1;
    for (int i = 0, t = getWidget()->count(); i < t && (tabPage != NULL); i++) {
       QWidget *tab = getWidget()->widget(i);
       if (tab->objectName().toStdString() != tabPage->getId()) continue;
       index = i;
    }
    return index;
}

int SUI::TabWidgetImpl::getTabIndexOfWidget(const std::string &id) const {
    int index = -1;
    for (int i = 0; i < tabPages.count(); i++) {
        if (tabPages.at(i)->getId() == id || dynamic_cast<TabPageImpl*>(tabPages.at(i))->isChild(id)) {
            return i;
        }
    }
    return index;
}

int SUI::TabWidgetImpl::getTabPageMargin() const {
    return cmTabPageMargin;
}

void SUI::TabWidgetImpl::setTabText(const QString &tabWidgetID, const QString &text) {
    TabPage *tabPage = getTabPage(tabWidgetID.toStdString());
    renameTab(tabPage,text);
}

void SUI::TabWidgetImpl::setTabText(int index, const QString &text) {
    if (index > -1 && index < getWidget()->count()) {
        QWidget *qTabPage = getWidget()->widget(index);
        for (int n = 0, t = tabPages.count(); n < t; n++) {
            if (qTabPage->objectName().toStdString() != tabPages.at(n)->getId()) continue;
            renameTab(tabPages.at(n),text);
            break;
        }
    }
}

void SUI::TabWidgetImpl::renameTab(TabPage *tabPage, const QString &text) {
   if (tabPage != NULL) {
      dynamic_cast<TabPageImpl*>(tabPage)->setPropertyValue(ObjectPropertyTypeEnum::Text,text);
      int index = getTabPageIndex(tabPage);
      if (index != -1) {
          getWidget()->setTabText(index, text);
      }
}
}

void SUI::TabWidgetImpl::setCurrentTabPage(int index) {
    if (index > -1 && index < getWidget()->count()) {
        getWidget()->setCurrentIndex(index);
        setPropertyValue(SUI::ObjectPropertyTypeEnum::CurrentTabPage, QString::number(index));
    }
}

void SUI::TabWidgetImpl::setTabToFront(TabPage *tabPage) {
    int index = getTabPageIndex(tabPage);
    if (index > 0 && index < getWidget()->count()) {
        getWidget()->removeTab(index);
        getWidget()->insertTab(index,dynamic_cast<TabPageImpl*>(tabPage)->getWidget(),QString::fromStdString(tabPage->getTabText()));

        getWidget()->setCurrentIndex(index);
        setPropertyValue(SUI::ObjectPropertyTypeEnum::CurrentTabPage, QString::number(index));
    }
}

int SUI::TabWidgetImpl::moveNext() {
    int index = -1;
    int indexA = getWidget()->currentIndex();
    if (indexA > -1 && (indexA + 1) < getWidget()->count()) {
        QWidget *widgetA = getWidget()->currentWidget();
        QString tabLabel = QString::fromStdString(tabPages.at(indexA)->getTabText());
        getWidget()->removeTab(indexA);
        getWidget()->insertTab(indexA+1, widgetA, tabLabel);
        qSwap(tabPages[indexA], tabPages[indexA+1]);
        index = indexA+1;
    }
    return index;
}

int SUI::TabWidgetImpl::movePrevious() {
   int index = -1;
   int indexA = getWidget()->currentIndex();
   if (indexA > 0) {
       QWidget *widgetA = getWidget()->currentWidget();
       QString tabLabel = getWidget()->tabText(indexA);
       getWidget()->removeTab(indexA);
       getWidget()->insertTab(indexA - 1, widgetA, tabLabel);
       qSwap(tabPages[indexA-1], tabPages[indexA]);
       index = indexA - 1;
   }
   return index;
}

void SUI::TabWidgetImpl::setTabIcon(TabPage *tabpage, const QIcon &icon) {
    int index = getTabPageIndex(tabpage);
    if (index > -1 && index < getWidget()->count()) {
       getWidget()->setTabIcon(index,icon);
    }
}

void SUI::TabWidgetImpl::focusTabPage(int index) {
    if (index > -1 && index < getWidget()->count()) {
        getWidget()->widget(index)->setFocusPolicy(Qt::StrongFocus);
        getWidget()->widget(index)->setFocus();
        getWidget()->widget(index)->focusWidget();
        getWidget()->setCurrentIndex(index);
        setPropertyValue(SUI::ObjectPropertyTypeEnum::CurrentTabPage, QString::number(index));
    }
}

int SUI::TabWidgetImpl::getTabbarHeight() const {
    return getWidget()->getTabBar()->rect().height();
}

CustomTabWidget *SUI::TabWidgetImpl::getWidget() const {
    return qobject_cast<CustomTabWidget *>(BaseWidget::getWidget());
}

QString SUI::TabWidgetImpl::getTabName(int index) const {
    return index > -1 && index < getWidget()->count() ? getWidget()->tabText(index) : "";
    }

QString SUI::TabWidgetImpl::getTabName(const QString &id) const {
    TabPage *tabPage = getTabPage(id.toStdString());
    return QString::fromStdString(tabPage ? tabPage->getTabText() : "");
}

void SUI::TabWidgetImpl::setTabVisible(const std::string &id, bool visible) {
    TabPage *tabPage = getTabPage(id);
    int internalIndex = tabPages.indexOf(tabPage);

    if (visible && !tabPageStatus.value(tabPage)) {
        int index = 0;
        TabPage *tp = NULL;
        for (int n = 0, t = getWidget()->count(); n < t; n++) {
            tp = getTabPage(getWidget()->widget(index)->objectName().toStdString());
            if (internalIndex > tabPages.indexOf(tp)) index++;
            else break;
        }
        QWidget *widget = dynamic_cast<TabPageImpl*>(tabPage)->getWidget();
        getWidget()->insertTab(index,widget,QString::fromStdString(tabPage->getTabText()));
    }
    else if (!visible && tabPageStatus.value(tabPage)) {
        getWidget()->removeTab(getTabPageIndex(tabPage));
    }
    tabPageStatus[tabPage] = visible;
}

void SUI::TabWidgetImpl::onCurrentIndexChanged(int) {
    TabPage *currentTabPage = getCurrentTabPage();

    if (currentTabPage != NULL) {
        if (!currentTabPage->visibilityChanged.empty()) {
             currentTabPage->visibilityChanged(true);
        }
    }
    if (previousTab != NULL) {
        if (!previousTab->visibilityChanged.empty()) {
            previousTab->visibilityChanged(false);
        }
    }
    previousTab = currentTabPage;

    // Signal a change in the selected tab page
    if(!currentIndexChanged.empty()) {
        currentIndexChanged(tabPages.indexOf(currentTabPage));
    }
}
