//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::CheckGroupBoxImpl.
// !\description Class implementation file for SUI::CheckGroupBoxImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUICheckGroupBoxImpl.h"

#include <QStyle>
#include <QVariant>

SUI::CheckGroupBoxImpl::CheckGroupBoxImpl(QWidget *parent) :
    BaseWidget(new QGroupBox(parent), SUI::ObjectType::CheckGroupBox, true)
{
    CheckGroupBoxImpl::getWidget()->setCheckable(true);
    exposeHeightProperty();
    exposeWidthProperty();
    connect(CheckGroupBoxImpl::getWidget(), SIGNAL(toggled(bool)), this, SLOT(handleCheckedChanged(bool)));
}

void SUI::CheckGroupBoxImpl::handleCheckedChanged(bool newState) {
    if (!checkStateChanged.empty()) checkStateChanged(newState);
}

void SUI::CheckGroupBoxImpl::setDefaultProperties(const ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);

    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "50");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "200");
    setBold(true);

    setChecked(getPropertyValue(SUI::ObjectPropertyTypeEnum::Checked).toLower() == "true");

    switch (context)
    {
    case EditorSelector:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, QString::fromStdString(SUI::ObjectType::toString(Object::getObjectType())));
        break;

    case EditorForm:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, "TBD");
        break;

    default:
        break;
    }
}

QGroupBox *SUI::CheckGroupBoxImpl::getWidget() const {
    return dynamic_cast<QGroupBox *>(BaseWidget::getWidget());
}

void SUI::CheckGroupBoxImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID,propertyValue);

    switch (propertyID) {
    case SUI::ObjectPropertyTypeEnum::Bold:
        setBold((propertyValue.compare("true", Qt::CaseInsensitive) == 0));
        break;

    case SUI::ObjectPropertyTypeEnum::Text:
        setText(propertyValue.toStdString());
        break;

    case SUI::ObjectPropertyTypeEnum::Checked:
        setChecked((propertyValue.compare("true", Qt::CaseInsensitive) == 0));
        getWidget()->update();
        break;

    case SUI::ObjectPropertyTypeEnum::BGColor:
        setBGColor(SUI::ColorEnum::fromString(propertyValue.toStdString()));
        break;

    default:
        break;
    }
}
void SUI::CheckGroupBoxImpl::setText(const std::string &value) {
    QGroupBox *groupBox = getWidget();
    QString text = QString::fromStdString(value);
    if (groupBox->title() == text) return;
    groupBox->setTitle(text);
}

std::string SUI::CheckGroupBoxImpl::getText() const {
    return getWidget()->title().toStdString();
}

void SUI::CheckGroupBoxImpl::clearText() {
    setText("");
}

void SUI::CheckGroupBoxImpl::setChecked(bool checked) {
    if (getWidget()->isChecked() == checked) return;
    getWidget()->setChecked(checked);
}

bool SUI::CheckGroupBoxImpl::isChecked() const {
    return getWidget()->isChecked();
}

SUI::ColorEnum::Color SUI::CheckGroupBoxImpl::getBGColor() const {
    return ColorEnum::fromString(getPropertyValue(SUI::ObjectPropertyTypeEnum::BGColor).toStdString());
}

void SUI::CheckGroupBoxImpl::setBGColor(const SUI::ColorEnum::Color color) {
    if (!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color)) return;
    if (ColorEnum::fromString(getPropertyValue(SUI::ObjectPropertyTypeEnum::BGColor).toStdString()) != color) {
        setPropertyValue(SUI::ObjectPropertyTypeEnum::BGColor, QString::fromStdString(ColorEnum::toString(color)).toLower());
    }
    getWidget()->setProperty("BGColorSet", QString::fromStdString(ColorEnum::toString(color)).toLower());
    getWidget()->style()->polish(getWidget());
}


void SUI::CheckGroupBoxImpl::setBold(bool bold) {
    getWidget()->setProperty("SUIFont", QVariant::fromValue<QString>(bold ? "bold" : ""));
    getWidget()->style()->polish(getWidget());
}

bool SUI::CheckGroupBoxImpl::isBold() const {
    return getWidget()->property("SUIFont").toString() == "bold";
}
