//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::TextAreaImpl.
// !\description Class implementation file for SUI::TextAreaImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUITextAreaImpl.h"

#include <QScrollBar>
#include <QStyle>

SUI::TextAreaImpl::TextAreaImpl(QWidget *parent) :
    BaseWidget(new QTextEdit(parent), SUI::ObjectType::TextArea, false),
    mBold(false),
    mAlign(AlignmentEnum::Left)
{
    exposeWidthProperty();
    exposeHeightProperty();
    connect(TextAreaImpl::getWidget(), SIGNAL(textChanged()), this, SLOT(onTextChanged()));
}

void SUI::TextAreaImpl::setAutoScroll(bool scroll) {
    setPropertyValue(SUI::ObjectPropertyTypeEnum::AutoScroll, scroll ? "true" : "false");
}

bool SUI::TextAreaImpl::getAutoScroll() const {
    return (getPropertyValue(SUI::ObjectPropertyTypeEnum::AutoScroll) == "true");
}

void SUI::TextAreaImpl::setReadonly(bool readOnly) {
    getWidget()->setReadOnly(readOnly);
}

bool SUI::TextAreaImpl::getReadonly() const {
    return getWidget()->isReadOnly();
}

SUI::ColorEnum::Color SUI::TextAreaImpl::getColor() const {
    return SUI::ColorEnum::fromString(getPropertyValue(SUI::ObjectPropertyTypeEnum::Color).toStdString());
}

void SUI::TextAreaImpl::setColor(const SUI::ColorEnum::Color color) {
    if (!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color)) return;
    if (SUI::ColorEnum::fromString(getProperty(SUI::ObjectPropertyTypeEnum::Color)->getValue().toStdString()) != color) {
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Color, QString::fromStdString(ColorEnum::toString(color)));
    }
    getWidget()->setTextColor(QColor(QString::fromStdString(ColorEnum::toString(color))));
}

void SUI::TextAreaImpl::setMode(ErrorModeEnum::ErrorMode mode) {
    mCurrentMode = mode;
    if (mode == ErrorModeEnum::Error) {
        getWidget()->setProperty("BGColorSet", "error");
    }
    else {
        getWidget()->setProperty("BGColorSet", "");
    }
    getWidget()->style()->polish(getWidget());
}

void SUI::TextAreaImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID, propertyValue);

    switch (propertyID) {
    case SUI::ObjectPropertyTypeEnum::Bold:
        setBold((propertyValue.compare("true", Qt::CaseInsensitive) == 0));
        break;

    case SUI::ObjectPropertyTypeEnum::Text:
        setText(propertyValue.toStdString());
        break;

    case SUI::ObjectPropertyTypeEnum::Alignment:
        if (propertyValue.toLower() == "right") {
            setAlignment(AlignmentEnum::Right);
        }
        else if (propertyValue.toLower() == "center") {
            setAlignment(AlignmentEnum::HCenter);
        }
        else {
            setAlignment(AlignmentEnum::Left);
        }
        break;

    case SUI::ObjectPropertyTypeEnum::ReadOnly:
        setReadonly(propertyValue.toLower() == "true");
        break;

    case SUI::ObjectPropertyTypeEnum::Color:
        setColor(SUI::ColorEnum::fromString(propertyValue.toStdString()));
        break;

    default:
        break;
    }
}

void SUI::TextAreaImpl::setAlignment(AlignmentEnum::Alignment align) {
    //store alignment info
    mAlign = align;

    Qt::Alignment   qtAlign;
    switch (align)
    {
    case AlignmentEnum::Right:
        qtAlign = Qt::AlignRight;
        break;
    case AlignmentEnum::Left:
        qtAlign = Qt::AlignLeft;
        break;
    case AlignmentEnum::HCenter:
        qtAlign = Qt::AlignCenter;
        break;
    default:
        qtAlign = Qt::AlignLeft;
        break;
    }

    //set alignment in TextArea
    QTextCursor cursor =  getWidget()->textCursor();
    QTextBlockFormat textBlockFormat = cursor.blockFormat();
    textBlockFormat.setAlignment(qtAlign);
    cursor.mergeBlockFormat(textBlockFormat);
    getWidget()->setTextCursor(cursor);
}

SUI::AlignmentEnum::Alignment SUI::TextAreaImpl::getAlignment() const {
    QTextCursor cursor =  getWidget()->textCursor();
    QTextBlockFormat textBlockFormat = cursor.blockFormat();
    switch (textBlockFormat.alignment())
    {
        case Qt::AlignRight:
        {
            return SUI::AlignmentEnum::Right;
        }
        case Qt::AlignLeft:
        {
            return SUI::AlignmentEnum::Left;
        }
        case Qt::AlignCenter:
        {
            return SUI::AlignmentEnum::HCenter;
        }
        default: return SUI::AlignmentEnum::Left;
    }
    return SUI::AlignmentEnum::Left;
}

void SUI::TextAreaImpl::onTextChanged() {
    if (!IText::textChanged.empty()) IText::textChanged(getText());
}

void SUI::TextAreaImpl::setDefaultProperties(const ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "90");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "200");
    setPropertyValue(ObjectPropertyTypeEnum::Alignment,QString::fromStdString(SUI::AlignmentEnum::toString(SUI::AlignmentEnum::Left)));

    switch (context)
    {
    case EditorSelector:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, QString::fromStdString(SUI::ObjectType::toString(Object::getObjectType())));
        break;

    case EditorForm:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, "TBD");
        break;

    default:
        break;
    }
}

QTextEdit *SUI::TextAreaImpl::getWidget() const {
    return dynamic_cast<QTextEdit *>(BaseWidget::getWidget());
}

void SUI::TextAreaImpl::setText(const std::string &value) {
    QString text;
    QTextEdit *textEdit = getWidget();
    text.append(colorSelect(getPropertyValue(SUI::ObjectPropertyTypeEnum::Color)) + QString::fromStdString(value));
    if (mBold) text.append("</b>");
    text.append("</span><br>");
    textEdit->textCursor().insertHtml(text);
    if (getPropertyValue(SUI::ObjectPropertyTypeEnum::AutoScroll) == "true") {
        textEdit->verticalScrollBar()->setValue(textEdit->verticalScrollBar()->maximum());
    }
}

void SUI::TextAreaImpl::clearText() {
    getWidget()->clear();
}

std::string SUI::TextAreaImpl::getText() const {
    return getWidget()->toPlainText().toStdString();
}

void SUI::TextAreaImpl::setBold(bool bold) {
    mBold = bold;
    QTextCharFormat format =  getWidget()->currentCharFormat();
    QFont font = format.font();
    font.setBold(bold);
    format.setFont(font);
    getWidget()->setCurrentCharFormat(format);
}

bool SUI::TextAreaImpl::isBold() const {
    return getWidget()->currentCharFormat().font().bold();
}

QString SUI::TextAreaImpl::colorSelect(QString color) {
    QString mask = "<span style='color:%1;'>";
    if (mBold) mask.append("<b>");
    mask = mask.arg(color.toLower());
    //Add alignment tags for the html representation of the text
    mask.append("<div align=\"%1\" </div>");
    mask = mask.arg(QString::fromStdString(AlignmentEnum::toString(mAlign)));
    return mask;
}

int SUI::TextAreaImpl::getScrollPosition() const {
    return getWidget()->verticalScrollBar()->value();
}

void SUI::TextAreaImpl::setScrollPosition(const int value) {
    return getWidget()->verticalScrollBar()->setValue(value);
}
