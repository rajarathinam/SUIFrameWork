//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::TabPageImpl.
// !\description Class implementation file for SUI::TabPageImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUITabPageImpl.h"

#include <QBuffer>
#include <QDir>
#include <QLabel>
#include <boost/foreach.hpp>

#include "SUITabWidgetImpl.h"

SUI::TabPageImpl::TabPageImpl(QWidget *parent) :
    BasePageImpl(new QFrame(parent), SUI::ObjectType::TabPage, true),
    mParentTabWidget(NULL)
{
    TabPageImpl::getWidget()->setFocusPolicy(Qt::NoFocus);
}

SUI::TabPageImpl::~TabPageImpl() {
    mParentTabWidget = NULL;
}

QFrame *SUI::TabPageImpl::getWidget() const {
    return qobject_cast<QFrame*>(BaseWidget::getWidget());
}

void SUI::TabPageImpl::setDefaultProperties(const ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);
    setTabText(getPropertyValue(ObjectPropertyTypeEnum::Text).toStdString());

    switch (context) {
    case BaseObject::EditorSelector:
        setTabText("Tab");
        break;
    case BaseObject::EditorForm:
        setTabText("Tab");
        break;
    default:
        break;

    }
}

void SUI::TabPageImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID,propertyValue);

    switch (propertyID) {
    case SUI::ObjectPropertyTypeEnum::ImageData:
        setIconName(propertyValue.toStdString());
        break;

    default:
        break;
    }
}

void SUI::TabPageImpl::setTabText(const std::string &t) {
    setPropertyValue(ObjectPropertyTypeEnum::Text,QString::fromStdString(t));
    if (mParentTabWidget != NULL) {
        mParentTabWidget->setTabText(getPropertyValue(SUI::ObjectPropertyTypeEnum::ID),QString::fromStdString(t));
    }
}

std::string SUI::TabPageImpl::getTabText() const {
    return getPropertyValue(ObjectPropertyTypeEnum::Text).toStdString();
}

std::string SUI::TabPageImpl::getIconName() const {
    return getPropertyValue(ObjectPropertyTypeEnum::ImageData).toStdString();
}

void SUI::TabPageImpl::setIconName(const std::string &icon) {
    QString iconName = QString::fromStdString(icon);
    if (iconName.contains(QDir::separator()) == true) return;
    QImage img;
    img.load(QString("%1").arg(QDir(":/controls/Controls/").filePath(iconName)));
    QPixmap pixmap = QPixmap::fromImage(img);
    QByteArray bytes;
    QBuffer buffer(&bytes);
    buffer.open(QIODevice::ReadWrite);
    pixmap.save(&buffer, "PNG");
    QString image = bytes.toBase64();

    if (mParentTabWidget != NULL) {
        QImage img;
        QPixmap pix;
        QByteArray bytes;
        QBuffer buffer(&bytes);
        buffer.open(QIODevice::ReadOnly);
        bytes = bytes.fromBase64(QString::fromStdString(image.toStdString()).toUtf8());
        img.loadFromData(bytes);
        pix = QPixmap::fromImage(img);
        mParentTabWidget->setTabIcon(this, QIcon(pix));
    }

    if (getPropertyValue(ObjectPropertyTypeEnum::ImageData) != iconName) {
        setPropertyValue(ObjectPropertyTypeEnum::ImageData,iconName);
    }
}

void SUI::TabPageImpl::removeIcon() {
    setIconName("");
}

const std::list<std::string> SUI::TabPageImpl::getAvailableIconNames() const {
    QStringList entries = QDir(":/controls/Controls/").entryList();
    std::list<std::string> sl;
    BOOST_FOREACH (const QString &entry, entries) sl.push_back(entry.toStdString());
    return sl;
}

void SUI::TabPageImpl::setTabWidgetParent(TabWidgetImpl *tabwidget) {
    mParentTabWidget = tabwidget;
}

bool SUI::TabPageImpl::isChild(std::string widgetId) {
    return (this->getWidget()->findChild<QWidget *>( QString::fromStdString( widgetId )) != NULL);
}

void SUI::TabPageImpl::setVisible(bool visible) {
   if (mParentTabWidget != NULL) {
      mParentTabWidget->setTabVisible(SUI::Object::getId(),visible);
   }
   if (getPropertyValue(SUI::ObjectPropertyTypeEnum::Visible) != (visible ? "true" : "false")) {
      setPropertyValue(SUI::ObjectPropertyTypeEnum::Visible,visible ? "true" : "false" );
   }
   if (!visibilityChanged.empty()) {
      visibilityChanged(visible);
   }
}

void SUI::TabPageImpl::setEnabled(bool enabled) {
    if (mParentTabWidget != NULL) {
       mParentTabWidget->setTabEnabled(SUI::Object::getId(),enabled);
    }
    getWidget()->setEnabled(enabled);
}
