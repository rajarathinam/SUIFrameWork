//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::ScienceSpinBoxImpl.
// !\description Class implementation file for SUI::ScienceSpinBoxImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIScienceSpinBoxImpl.h"

#include <limits>
#include <float.h>
#include <QStyle>

SUI::ScienceSpinBoxImpl::ScienceSpinBoxImpl(QWidget *parent)    :
    BaseWidget(new CustomScienceSpinBox(parent), SUI::ObjectType::ScienceSpinBox, false)
{
    connect(ScienceSpinBoxImpl::getWidget(), SIGNAL(valueChanged(QString)), this, SLOT(handleValueChanged()));
    exposeWidthProperty();
}

void SUI::ScienceSpinBoxImpl::setDefaultProperties(const SUI::BaseObject::ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);
    setPropertyValue(ObjectPropertyTypeEnum::Text,"1e+0");
    setPropertyValues(ObjectPropertyTypeEnum::StepSize, QString("0,01:%1").arg(INT_MAX));
    setPropertyValue(ObjectPropertyTypeEnum::StepSize, "1e+1");
    setPropertyValues(ObjectPropertyTypeEnum::MinValue, QString("%1:%2").arg("1e-22").arg("1e+22"));
    setPropertyValue(ObjectPropertyTypeEnum::MinValue, "1e-22");
    setPropertyValues(ObjectPropertyTypeEnum::MaxValue, QString("%1:%2").arg("1e-22").arg("1e+22"));
    setPropertyValue(ObjectPropertyTypeEnum::MaxValue, "1e+22");
    setPropertyValues(ObjectPropertyTypeEnum::Precision,QString("0:%1").arg(DBL_MAX_10_EXP + DBL_DIG));
    setPropertyValue(ObjectPropertyTypeEnum::Precision,"1");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "30");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "200");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, "0.0e+00");

    switch (context)
    {
    case EditorSelector:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, QString::fromStdString(SUI::ObjectType::toString(Object::getObjectType())));
        break;

    case EditorForm:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, "0.0e+00");
        break;

    default:
        break;
    }
}

CustomScienceSpinBox *SUI::ScienceSpinBoxImpl::getWidget() const {
    return dynamic_cast<CustomScienceSpinBox *>(BaseWidget::getWidget());
}

void SUI::ScienceSpinBoxImpl::handleValueChanged() {
    if (!valueChanged.empty()) valueChanged();
}

double SUI::ScienceSpinBoxImpl::getValue() const {
    return getWidget()->value();
}

void SUI::ScienceSpinBoxImpl::setValue(const double val) {
    getWidget()->setValue(val);
}

void SUI::ScienceSpinBoxImpl::setMinValue(const double val) {
    getWidget()->setMinimum(val);
}

double SUI::ScienceSpinBoxImpl::getMinValue() const {
    return getWidget()->minimum();
}

void SUI::ScienceSpinBoxImpl::setMaxValue(const double val) {
    getWidget()->setMaximum(val);
}

double SUI::ScienceSpinBoxImpl::getMaxValue() const {
    return getWidget()->maximum();
}

void SUI::ScienceSpinBoxImpl::setStepSize(const double val) {
    getWidget()->setSingleStep(val);
}

double SUI::ScienceSpinBoxImpl::getStepSize() const {
    return getWidget()->singleStep();
}

void SUI::ScienceSpinBoxImpl::setPrecision(const int val) {
    getWidget()->setDecimals(val);
}

int SUI::ScienceSpinBoxImpl::getPrecision() const {
    return getWidget()->decimals();
}

void SUI::ScienceSpinBoxImpl::setStepSizeValueToFactor(const bool on) {
    getWidget()->setStepSizeValueToFactor(on);
}

void SUI::ScienceSpinBoxImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID, propertyValue);

    switch (propertyID) {

    case SUI::ObjectPropertyTypeEnum::StepSize:
        setStepSize(propertyValue.toDouble());
        break;

    case SUI::ObjectPropertyTypeEnum::MaxValue:
        setMaxValue(propertyValue.toDouble());
        break;

    case SUI::ObjectPropertyTypeEnum::MinValue:
        setMinValue(propertyValue.toDouble());
        break;

    case SUI::ObjectPropertyTypeEnum::Precision:
        setPrecision(propertyValue.toInt());
        break;

    case SUI::ObjectPropertyTypeEnum::StepsizeToFactor:
        getWidget()->setStepSizeValueToFactor((propertyValue.toUpper() == "TRUE") ? true : false);
        break;

    case SUI::ObjectPropertyTypeEnum::Alignment:
        if (propertyValue.toLower() == "right") {
            setAlignment(AlignmentEnum::Right);
        }
        else if (propertyValue.toLower() == "center") { 
            setAlignment(AlignmentEnum::HCenter);
        }
        else { 
            setAlignment(AlignmentEnum::Left);
        }
        break;

    case SUI::ObjectPropertyTypeEnum::Bold:
        setBold((propertyValue.compare("true", Qt::CaseInsensitive) == 0));
        break;

    case SUI::ObjectPropertyTypeEnum::Text:
    {
        bool ok = false;
        double result = propertyValue.toDouble(&ok);
        if (ok) {
            getWidget()->setValue(result);
        }
        break;
    }

    default:
        break;

    }

}

QString SUI::ScienceSpinBoxImpl::getPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID) const {
    QString propertyValue = BaseWidget::getPropertyValue(propertyID);
    if (propertyID == SUI::ObjectPropertyTypeEnum::StepsizeToFactor) {
        getWidget()->setStepSizeValueToFactor(propertyValue.toUpper() == "TRUE");
    }

    return propertyValue;
}

void SUI::ScienceSpinBoxImpl::setBold(bool bold) {
    getWidget()->setProperty("SUIFont", QVariant::fromValue<QString>(bold ? "bold" : ""));
    getWidget()->style()->polish(getWidget());
}

void SUI::ScienceSpinBoxImpl::setMode(ErrorModeEnum::ErrorMode mode) {
    mCurrentMode = mode;
    if (mode == ErrorModeEnum::Error) {
        getWidget()->setProperty("BGColorSet", "error");
    }
    else {
        getWidget()->setProperty("BGColorSet", "");
    }
    getWidget()->style()->polish(getWidget());
}

void SUI::ScienceSpinBoxImpl::setAlignment(AlignmentEnum::Alignment align) {
    Qt::Alignment   qtAlign;
    switch (align)
    {
    case AlignmentEnum::Right: qtAlign = Qt::AlignRight; break;
    case AlignmentEnum::Left: qtAlign = Qt::AlignLeft; break;
    default:
        qtAlign = Qt::AlignCenter;
        break;
    }
    getWidget()->setAlignment(qtAlign);
}

SUI::AlignmentEnum::Alignment SUI::ScienceSpinBoxImpl::getAlignment() const {
    switch (getWidget()->alignment())
    {
    case Qt::AlignRight: return SUI::AlignmentEnum::Right;
    case Qt::AlignLeft: return SUI::AlignmentEnum::Left;
    default: return SUI::AlignmentEnum::HCenter;
    }
    return SUI::AlignmentEnum::HCenter;
}
