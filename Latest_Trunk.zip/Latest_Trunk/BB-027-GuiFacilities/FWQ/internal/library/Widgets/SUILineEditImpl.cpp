//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::LineEditImpl.
// !\description Class implementation file for SUI::LineEditImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUILineEditImpl.h"

#include "SUIObjectProperty.h"

#include <QStyle>
#include <QDebug>
#include <QRegExpValidator>

#include <algorithm>

SUI::LineEditImpl::LineEditImpl(QWidget *parent) :
    BaseWidget(new QLineEdit(parent), SUI::ObjectType::LineEdit, false)
{
    exposeWidthProperty();
    LineEditImpl::getWidget()->setMouseTracking(true);
    LineEditImpl::getWidget()->setAutoFillBackground(true);
    connect(LineEditImpl::getWidget(), SIGNAL(editingFinished()), this, SLOT(onEditingFinished()));
    connect(LineEditImpl::getWidget(), SIGNAL(textEdited(QString)), this, SLOT(onTextEdited(QString)));
    connect(LineEditImpl::getWidget(), SIGNAL(textChanged(QString)), this, SLOT(onTextChanged(QString)));
    mBackGroundColor = getBGColor();
}

void SUI::LineEditImpl::onEditingFinished() {
    if (!LineEdit::editingFinished.empty()) LineEdit::editingFinished();
    if (!valueValidated.empty()) {
        QString text = QString::fromStdString(getText());
        int pos = 0;
        if (getWidget()->validator()->validate(text,pos) == QValidator::Acceptable) {
            mCurrentMode = ErrorModeEnum::None;
        }
        else {
           mCurrentMode = ErrorModeEnum::Error;
           valueValidated();
        }
    }
}

void SUI::LineEditImpl::onTextEdited(QString newText) {
    if (!LineEdit::textEdited.empty()) LineEdit::textEdited(newText.toStdString());
}

void SUI::LineEditImpl::onTextChanged(QString value) {
    if (!LineEdit::textChanged.empty()) LineEdit::textChanged(value.toStdString());
    if (!valueValidated.empty()) {
        QString text = QString::fromStdString(getText());
        int pos = 0;
        if (getWidget()->validator()->validate(text,pos) == QValidator::Acceptable) {
            mCurrentMode = ErrorModeEnum::None;
        }
        else {
            mCurrentMode = ErrorModeEnum::Error;
            valueValidated();
        }
    }
}

void SUI::LineEditImpl::setDefaultProperties(const ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);

    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "30");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "200");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::RegularExpression, ".*");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::PlaceHolderText,"");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Color, QString::fromStdString(ColorEnum::toString(SUI::ColorEnum::Standard)));
    setPropertyValue(SUI::ObjectPropertyTypeEnum::BGColor, QString::fromStdString(ColorEnum::toString(SUI::ColorEnum::Standard)));

    switch (context)
    {
    case EditorSelector:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, QString::fromStdString(SUI::ObjectType::toString(Object::getObjectType())));
        break;

    case EditorForm:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, "TBD");
        break;

    default:
        break;
    }
}

void SUI::LineEditImpl::setText(const std::string &value) {
    if (getText() == value) return;
    getWidget()->setText(QString::fromStdString(value));
}

std::string SUI::LineEditImpl::getText() const {
    return getWidget()->text().toStdString();
}

void SUI::LineEditImpl::clearText() {
    getWidget()->clear();
}

SUI::ColorEnum::Color SUI::LineEditImpl::getColor() const {
    return SUI::ColorEnum::fromString(getPropertyValue(SUI::ObjectPropertyTypeEnum::Color).toStdString());
}

void SUI::LineEditImpl::setColor(const SUI::ColorEnum::Color color) {
    if (!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color)) return;
    if (ColorEnum::fromString(getPropertyValue(SUI::ObjectPropertyTypeEnum::Color).toStdString()) != color) {
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Color, QString::fromStdString(ColorEnum::toString(color)).toLower());
    }
    getWidget()->setProperty("ColorSet", QString::fromStdString(ColorEnum::toString(color)).toLower());
    getWidget()->style()->polish(getWidget());
}

SUI::ColorEnum::Color SUI::LineEditImpl::getBGColor() const {
    return ColorEnum::fromString(getPropertyValue(SUI::ObjectPropertyTypeEnum::BGColor).toStdString());
}

void SUI::LineEditImpl::setBGColor(const SUI::ColorEnum::Color color) {
    if (!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color)) return;
    getWidget()->setProperty("BGColorSet", QString::fromStdString(ColorEnum::toString(color)).toLower());
    if (ColorEnum::fromString(getPropertyValue(SUI::ObjectPropertyTypeEnum::BGColor).toStdString()) != color) {
        setPropertyValue(SUI::ObjectPropertyTypeEnum::BGColor, QString::fromStdString(ColorEnum::toString(color)).toLower());
    }
    getWidget()->style()->polish(getWidget());
}

QString SUI::LineEditImpl::changeColor(QString color) {
    QString selectedColor = QString::fromStdString(SUI::ColorEnum::toString(SUI::ColorEnum::Standard));
    if (ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),ColorEnum::fromString(color.toStdString()))) {
        selectedColor = color;
    }
    return selectedColor;
}

QString SUI::LineEditImpl::changeColor(SUI::ColorEnum::Color color) {
    QString selectedColor = QString::fromStdString(SUI::ColorEnum::toString(SUI::ColorEnum::Standard));
    if (ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color)) {
        selectedColor = QString::fromStdString(SUI::ColorEnum::toString(color));
    }
    return selectedColor;
}

void SUI::LineEditImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID, propertyValue);

    switch (propertyID) {
    case SUI::ObjectPropertyTypeEnum::RegularExpression:
        getWidget()->setValidator(new QRegExpValidator(QRegExp(propertyValue.isEmpty() ? ".*" : propertyValue),getWidget()));
        break;

    case SUI::ObjectPropertyTypeEnum::RegExpTip:
        getWidget()->setToolTip(propertyValue);
        break;

    case SUI::ObjectPropertyTypeEnum::Alignment:
        setAlignment(AlignmentEnum::fromString(propertyValue.toLower().toStdString()));
        break;

    case SUI::ObjectPropertyTypeEnum::Bold:
        setBold(propertyValue.compare("true", Qt::CaseInsensitive) == 0);
        break;

    case SUI::ObjectPropertyTypeEnum::Text:
        setText(propertyValue.toStdString());
        break;

    case SUI::ObjectPropertyTypeEnum::Color:
        setColor(SUI::ColorEnum::fromString(propertyValue.toStdString()));
        break;

    case SUI::ObjectPropertyTypeEnum::BGColor:
        setBGColor(SUI::ColorEnum::fromString(propertyValue.toStdString()));
        break;
    case SUI::ObjectPropertyTypeEnum::PlaceHolderText:
        setPlaceHolderText(propertyValue.toStdString());
        break;

    default:
        break;
    }
}

QLineEdit *SUI::LineEditImpl::getWidget() const {
    return dynamic_cast<QLineEdit *>(BaseWidget::getWidget());
}

void SUI::LineEditImpl::setAlignment(AlignmentEnum::Alignment align) {
    mAlign = align;
    Qt::Alignment   qtAlign;
    switch (align)
    {
    case AlignmentEnum::Right: qtAlign = Qt::AlignRight; break;
    case AlignmentEnum::Left: qtAlign = Qt::AlignLeft; break;
    default: qtAlign = Qt::AlignCenter; break;
    }
    getWidget()->setAlignment(qtAlign);
}

SUI::AlignmentEnum::Alignment SUI::LineEditImpl::getAlignment() const {
    switch (getWidget()->alignment())
    {
    case Qt::AlignRight: return SUI::AlignmentEnum::Right;
    case Qt::AlignLeft: return SUI::AlignmentEnum::Left;
    default: return SUI::AlignmentEnum::HCenter;
    }
    return SUI::AlignmentEnum::HCenter;
}

void SUI::LineEditImpl::setBold(bool bold) {
    getWidget()->setProperty("SUIFont",bold ? "bold" : "");
    getWidget()->style()->polish(getWidget());
}

bool SUI::LineEditImpl::isBold() const {
    return getWidget()->property("SUIFont").toString() == "bold";
}

void SUI::LineEditImpl::setMode(ErrorModeEnum::ErrorMode mode) {
    mCurrentMode = mode;
    if (mode == ErrorModeEnum::Error) {
        mBackGroundColor = getBGColor();
        getWidget()->setProperty("BGColorSet", "error");
    }
    else {
        getWidget()->setProperty("BGColorSet", "");
        setBGColor(mBackGroundColor);
    }
    getWidget()->style()->polish(getWidget());
}

void SUI::LineEditImpl::setPlaceHolderText(const std::string &value)
 {
     getWidget()->setPlaceholderText(QString::fromStdString(value));
 }

std::string SUI::LineEditImpl::getPlaceHolderText() const
{
    return getWidget()->placeholderText().toStdString();
}
