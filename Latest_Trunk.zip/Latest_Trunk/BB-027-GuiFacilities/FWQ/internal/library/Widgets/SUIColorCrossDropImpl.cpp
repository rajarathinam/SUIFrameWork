//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::ColorCrossDropImpl.
// !\description Class implementation file for SUI::ColorCrossDropImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUIColorCrossDropImpl.h"


#include <QPainter>
#include <boost/foreach.hpp>

SUI::ColorCrossDropImpl::ColorCrossDropImpl(QWidget *parent) :
    BaseWidget(new QComboBox(parent), SUI::ObjectType::ColorCrossDrop, false)
{
    exposeWidthProperty();
    setValues();
    connect( ColorCrossDropImpl::getWidget(), SIGNAL(currentIndexChanged(QString)), this, SLOT(onCurrentIndexChanged()));

}

void SUI::ColorCrossDropImpl::setDefaultProperties(const SUI::BaseObject::ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "30");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "200");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Color, QString::fromStdString(ColorEnum::toString(ColorEnum::Black)));        
}

void SUI::ColorCrossDropImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    if (propertyID == SUI::ObjectPropertyTypeEnum::Color) {
        int ind =  getWidget()->findText(propertyValue);
        if (ind > -1) getWidget()->setCurrentIndex(ind);
    }
    BaseWidget::setPropertyValue(propertyID, propertyValue);
}

QComboBox *SUI::ColorCrossDropImpl::getWidget() const {
    return dynamic_cast<QComboBox *>(BaseWidget::getWidget());
}

SUI::ColorEnum::Color SUI::ColorCrossDropImpl::getColor() const {
    return SUI::ColorEnum::fromString(getPropertyValue(SUI::ObjectPropertyTypeEnum::Color).toStdString());
}

void SUI::ColorCrossDropImpl::setColor(const SUI::ColorEnum::Color color) {
    if (!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color)) return;
    if (SUI::ColorEnum::fromString(getProperty(SUI::ObjectPropertyTypeEnum::Color)->getValue().toStdString()) != color) {
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Color, QString::fromStdString(ColorEnum::toString(color)));
    }
    setProperty("Color", QString::fromStdString(SUI::ColorEnum::toString(color)));
    if (!colorChanged.empty()) colorChanged();
}

void SUI::ColorCrossDropImpl::onCurrentIndexChanged() {
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Color,  getWidget()->currentText());
    if (!currentIndexChanged.empty()) currentIndexChanged(getWidget()->currentIndex());
    if (!colorChanged.empty()) colorChanged();
}

void SUI::ColorCrossDropImpl::setValues() {
    BOOST_FOREACH (const std::string &s, ColorEnum::getColorStringList()) {
        QString v = QString::fromStdString(s);
        if (ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),ColorEnum::fromString(v.toStdString()))) {
            getWidget()->addItem(v);
            getWidget()->setItemData(getWidget()->findText(v), QPixmap::fromImage(image(v)), Qt::DecorationRole);
        }
    }
}

QImage SUI::ColorCrossDropImpl::image(QString color) {
    QImage img(16, 16, QImage::Format_RGB32);
    QPainter p(&img);

    p.fillRect(img.rect(), Qt::white);
    QColor intColor;
    switch (ColorEnum::fromString(color.toStdString()))
    {
    case SUI::ColorEnum::Black:
        intColor = Qt::black;
        break;
    case SUI::ColorEnum::Blue:
        intColor = Qt::blue;
        break;
    case SUI::ColorEnum::Green:
        intColor = Qt::green;
        break;
    case SUI::ColorEnum::Red:
        intColor = Qt::red;
        break;
    case SUI::ColorEnum::Gray:
        intColor = Qt::gray;
        break;
    case SUI::ColorEnum::Yellow:
        intColor = Qt::yellow;
        break;
    case SUI::ColorEnum::Orange:
        intColor = QColor(255,165,0);
        break;
    default:
        break;
    }

    for (int ix = 0; ix < img.width(); ix++) {
        img.setPixel(ix, img.height() / 2, QColor(intColor).rgb());
    }

    for (int iy = 0; iy < img.height(); iy++) {
        img.setPixel(img.width() / 2, iy, QColor(intColor).rgb());
    }

    return img;
}
