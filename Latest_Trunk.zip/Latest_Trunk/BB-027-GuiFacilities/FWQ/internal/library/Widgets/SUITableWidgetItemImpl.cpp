/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUITableWidgetItemImpl.cpp
| Author       :
| Description  : Class implementation file for SUI::TableWidgetItemImpl.
|
| ! \file        SUITableWidgetItemImpl.cpp
| ! \brief       Class implementation file for SUI::TableWidgetItemImpl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUITableWidgetItemImpl.h"

SUI::TableWidgetItemImpl::TableWidgetItemImpl(QWidget *parent) :
    BaseWidget(new QFrame(parent), SUI::ObjectType::TableWidgetItem, false),
    QTableWidgetItem()
{
    setPropertyReadonly(SUI::ObjectPropertyTypeEnum::ID);
    setPropertyReadonly(SUI::ObjectPropertyTypeEnum::XPos);
    setPropertyReadonly(SUI::ObjectPropertyTypeEnum::YPos);
}

void SUI::TableWidgetItemImpl::setDefaultProperties(const ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);
    setPropertyValue(ObjectPropertyTypeEnum::Alignment,"left");
    setPropertyValue(ObjectPropertyTypeEnum::BorderOn,"false");
    setAlignment(SUI::AlignmentEnum::Left);
    setFontSize(FontSizeEnum::Normal);

    switch (context)
    {
    case EditorSelector:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, QString::fromStdString(SUI::ObjectType::toString(Object::getObjectType())));
        break;

    case EditorForm:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, "TBD");
        break;

    default:
        break;
    }
}

void SUI::TableWidgetItemImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID, propertyValue);

    switch (propertyID) {
    case SUI::ObjectPropertyTypeEnum::Enable:
        if (propertyValue.toLower() == "false") {
            setFlags(flags() ^ Qt::ItemIsEditable);
        }
        else {
            setFlags(flags() | Qt::ItemIsEditable);
        }
        break;

    case SUI::ObjectPropertyTypeEnum::Alignment:
        setAlignment(SUI::AlignmentEnum::fromString( (propertyValue.size() == 0) ? "stretch" : propertyValue.toLower().toStdString()));
        break;

    case SUI::ObjectPropertyTypeEnum::FontSize:
        setFontSize(FontSizeEnum::fromString(propertyValue.toStdString()));
        break;

    case SUI::ObjectPropertyTypeEnum::Bold:
        setBold((propertyValue.compare("true", Qt::CaseInsensitive) == 0));
        break;

    case SUI::ObjectPropertyTypeEnum::Text:
        setText(propertyValue.toStdString());
        break;

    case SUI::ObjectPropertyTypeEnum::BorderWidth:
        getWidget()->setLineWidth(getPropertyValue(ObjectPropertyTypeEnum::BorderOn).toLower() == "true" ? propertyValue.toInt()  : 0);
        break;

    case SUI::ObjectPropertyTypeEnum::BorderOn:
        getWidget()->setLineWidth(propertyValue.toLower() == "true" ? getPropertyValue(ObjectPropertyTypeEnum::BorderWidth).toInt()  : 0);
        break;
    case SUI::ObjectPropertyTypeEnum::Color:
        QTableWidgetItem::setForeground(QColor(propertyValue));
        break;
    default:
        break;
    }
}

void SUI::TableWidgetItemImpl::setText(const std::string &value) {
    QTableWidgetItem::setText(QString::fromStdString(value));
    if (QString::fromStdString(value) != getPropertyValue(SUI::ObjectPropertyTypeEnum::Text)) {
       setPropertyValue(SUI::ObjectPropertyTypeEnum::Text,QString::fromStdString(value));
    }
}

std::string SUI::TableWidgetItemImpl::getText() const {
    return QTableWidgetItem::text().toStdString();
}

void SUI::TableWidgetItemImpl::clearText() {
    setText("");
}

void SUI::TableWidgetItemImpl::setBold(bool bold) {
    QFont font = getWidget()->font();
    font.setBold(bold);
    getWidget()->setFont(font);
}

bool SUI::TableWidgetItemImpl::isBold() const {
    return QTableWidgetItem::font().bold();
}

void SUI:: TableWidgetItemImpl::setFontSize(const SUI::FontSizeEnum::FontSize &fontSize) {
    QFont font = getWidget()->font();
    switch (fontSize)
    {
    case FontSizeEnum::Big:
        font.setPointSize(14);
        break;
    case FontSizeEnum::Small:
        font.setPointSize(9);
        break;
    default:
        font.setPointSize(11);
        break;
    }
    getWidget()->setFont(font);
}

SUI::FontSizeEnum::FontSize SUI::TableWidgetItemImpl::getFontSize() const {
    if (getWidget()->font().pointSize() == 14) return FontSizeEnum::Big;
    if (getWidget()->font().pointSize() == 9) return FontSizeEnum::Small;
    return FontSizeEnum::Normal;
}

QFrame *SUI::TableWidgetItemImpl::getWidget() const {
    return qobject_cast<QFrame *>(BaseWidget::getWidget());
}

void SUI::TableWidgetItemImpl::setAlignment(AlignmentEnum::Alignment align) {
    Qt::Alignment   qtAlign;
    switch (align)
    {
    case AlignmentEnum::Right:
        qtAlign = Qt::AlignRight | Qt::AlignVCenter;
        break;
    case AlignmentEnum::Left:
        qtAlign = Qt::AlignLeft | Qt::AlignVCenter;
        break;
    case AlignmentEnum::HCenter:
        qtAlign = Qt::AlignCenter | Qt::AlignVCenter;
        break;
    default:
        qtAlign = Qt::AlignLeft | Qt::AlignVCenter;
        break;
    }
    //set the text alignment
    QTableWidgetItem::setTextAlignment(qtAlign);
}

SUI::AlignmentEnum::Alignment SUI::TableWidgetItemImpl::getAlignment() const {
    switch (QTableWidgetItem::textAlignment())
    {
    case Qt::AlignRight: return SUI::AlignmentEnum::Right;
    case Qt::AlignLeft: return SUI::AlignmentEnum::Left;
    default: return SUI::AlignmentEnum::HCenter;
    }
    return SUI::AlignmentEnum::HCenter;
}

SUI::ColorEnum::Color SUI::TableWidgetItemImpl::getColor() const
{
    return SUI::ColorEnum::fromString(getPropertyValue(SUI::ObjectPropertyTypeEnum::Color).toStdString());
}

void SUI::TableWidgetItemImpl::setColor(const SUI::ColorEnum::Color color)
{
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Color, QString::fromStdString(ColorEnum::toString(color)));
}
