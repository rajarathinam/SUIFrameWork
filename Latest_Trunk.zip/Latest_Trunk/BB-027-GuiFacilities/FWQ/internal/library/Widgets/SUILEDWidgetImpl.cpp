//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::LEDWidgetImpl.
// !\description Class implementation file for SUI::LEDWidgetImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUILEDWidgetImpl.h"

SUI::LEDWidgetImpl::LEDWidgetImpl(QWidget *parent) :
    BaseWidget(new QLabel(parent), SUI::ObjectType::LEDWidget, false)
{

}

QLabel *SUI::LEDWidgetImpl::getWidget() const {
    return dynamic_cast<QLabel *>(BaseWidget::getWidget());
}

void SUI::LEDWidgetImpl::setDefaultProperties(const SUI::BaseObject::ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "30");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "30");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Color, QString::fromStdString(ColorEnum::toString(ColorEnum::Green)));
}

void SUI::LEDWidgetImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID, propertyValue);

    switch (propertyID) {
    case SUI::ObjectPropertyTypeEnum::Color:
        setColor(SUI::ColorEnum::fromString(propertyValue.toStdString()));
        break;

    default:
        break;
    }
}

SUI::ColorEnum::Color SUI::LEDWidgetImpl::getColor() const {
    return SUI::ColorEnum::fromString(getPropertyValue(SUI::ObjectPropertyTypeEnum::Color).toStdString());
}

void SUI::LEDWidgetImpl::setColor(const SUI::ColorEnum::Color color) {
    if (!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color)) return;
    if (SUI::ColorEnum::fromString(getProperty(SUI::ObjectPropertyTypeEnum::Color)->getValue().toStdString()) != color) {
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Color, QString::fromStdString(ColorEnum::toString(color)));
    }
    QImage file;
    switch (color)
    {
    case SUI::ColorEnum::Blue:
        file.load(":/image/IndicatorBlue.png");
        break;
    case SUI::ColorEnum::Green:
        file.load(":/image/IndicatorGreen.png");
        break;
    case SUI::ColorEnum::Red:
        file.load(":/image/IndicatorRed.png");
        break;
    case SUI::ColorEnum::Gray:
        file.load(":/image/IndicatorGray.png");
        break;
    case SUI::ColorEnum::White:
        file.load(":/image/IndicatorWhite.png");
        break;
    case SUI::ColorEnum::Yellow:
        file.load(":/image/IndicatorYellow.png");
        break;
    default:
        break;
    }
    getWidget()->setPixmap(QPixmap::fromImage(file));
}
