//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::ColorDropImpl.
// !\description Class implementation file for SUI::ColorDropImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUIColorDropImpl.h"

#include <QPainter>
#include <boost/foreach.hpp>

SUI::ColorDropImpl::ColorDropImpl(QWidget *parent) :
    BaseWidget(new QComboBox(parent), SUI::ObjectType::ColorDrop, false)
{
    exposeWidthProperty();
    setValues();
    connect(ColorDropImpl::getWidget(), SIGNAL(currentIndexChanged(QString)), this, SLOT(onCurrentIndexChanged()));
}

void SUI::ColorDropImpl::setDefaultProperties(const SUI::BaseObject::ObjectContext &context)
{
    BaseWidget::setDefaultProperties(context);
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "30");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width,  "200");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Color,QString::fromStdString(ColorEnum::toString(ColorEnum::Black)));
}

QComboBox *SUI::ColorDropImpl::getWidget() const
{
    return dynamic_cast<QComboBox *>(BaseWidget::getWidget());
}

void SUI::ColorDropImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue)
{
    if (propertyID == SUI::ObjectPropertyTypeEnum::Color)
    {
        int ind = getWidget()->findText(propertyValue);
        if (ind > -1)
        {
            getWidget()->setCurrentIndex(ind);
        }
    }
    BaseWidget::setPropertyValue(propertyID, propertyValue);
}

SUI::ColorEnum::Color SUI::ColorDropImpl::getColor() const {
    return SUI::ColorEnum::fromString(getPropertyValue(SUI::ObjectPropertyTypeEnum::Color).toStdString());
}

void SUI::ColorDropImpl::setColor(const SUI::ColorEnum::Color color) {
    if (SUI::ColorEnum::fromString(getProperty(SUI::ObjectPropertyTypeEnum::Color)->getValue().toStdString()) != color) {
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Color, QString::fromStdString(ColorEnum::toString(color)));
    }
}

void SUI::ColorDropImpl::onCurrentIndexChanged() {
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Color, getWidget()->currentText());
    if (!currentIndexChanged.empty()) currentIndexChanged(getWidget()->currentIndex());
    if (!colorChanged.empty()) colorChanged();
}

void SUI::ColorDropImpl::setValues() {
    BOOST_FOREACH (const std::string &s, ColorEnum::getColorStringList())  {
        QString v = QString::fromStdString(s);
        if (ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),ColorEnum::fromString(v.toStdString()))) {
            getWidget()->addItem(v);
            getWidget()->setItemData(getWidget()->findText(v), QPixmap::fromImage(image(v)), Qt::DecorationRole);
        }
    }
}

QImage SUI::ColorDropImpl::image(QString color)
{
    QImage img(16, 16, QImage::Format_ARGB32);
    img.fill(qRgba(0,0,0,0));

    QPainter p(&img);
    p.setRenderHint(QPainter::Antialiasing);

    QPainterPath path;
    path.addRoundedRect(QRectF(img.rect()), 3, 3);
    p.setPen(QPen(QBrush(Qt::black),2));

    switch (ColorEnum::fromString(color.toStdString()))
    {
    case SUI::ColorEnum::Standard:
    {
        QLinearGradient gradient(img.rect().topLeft(), img.rect().bottomRight());
        gradient.setColorAt(0, Qt::white);
        gradient.setColorAt(0.15, Qt::yellow);
        gradient.setColorAt(0.30, Qt::green);
        gradient.setColorAt(0.45, Qt::blue);
        gradient.setColorAt(0.60, Qt::gray);
        gradient.setColorAt(0.75, Qt::red);
        gradient.setColorAt(1, Qt::black);
        p.fillPath(path, gradient);
        break;
    }
    case SUI::ColorEnum::White:    p.fillPath(path, Qt::white); break;
    case SUI::ColorEnum::Black:    p.fillPath(path, Qt::black); break;
    case SUI::ColorEnum::Blue:     p.fillPath(path, Qt::blue); break;
    case SUI::ColorEnum::Green:    p.fillPath(path, Qt::green); break;
    case SUI::ColorEnum::Red:      p.fillPath(path, Qt::red); break;
    case SUI::ColorEnum::Gray:     p.fillPath(path, Qt::gray); break;
    case SUI::ColorEnum::Yellow:   p.fillPath(path, Qt::yellow); break;
    case SUI::ColorEnum::Orange:   p.fillPath(path, QBrush(QColor(255,165,0))); break;
    default:
        break;
    }
    p.drawPath(path);

    return img;
}
