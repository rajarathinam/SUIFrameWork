//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::ButtonImpl.
// !\description Class implementation file for SUI::ButtonImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIButtonImpl.h"

#include <QMessageBox>
#include <QBuffer>
#include <QIcon>
#include <QStyle>
#include <QStyleOptionButton>
#include <QStylePainter>
#include <QPainter>
#include <QMouseEvent>

#include "FWQxCore/SUIResourcePath.h"
#include <boost/bind.hpp>

SUI::ButtonImpl::ButtonImpl(QWidget *parent) :
    BaseWidget(new CustomPushButton(parent), SUI::ObjectType::Button, false)
{
    exposeWidthProperty();
    connect(ButtonImpl::getWidget(), SIGNAL(clicked()), this, SLOT(handleClicked()));
    connect(ButtonImpl::getWidget(), SIGNAL(mousePressed()), this, SLOT(loadPressedImage()));
    connect(ButtonImpl::getWidget(), SIGNAL(mouseReleased()), this, SLOT(loadDefaultImage()));
}

void SUI::ButtonImpl::loadDefaultImage() {
    QString data = getPropertyValue(SUI::ObjectPropertyTypeEnum::ImageData);
    if (!data.isEmpty()) setImage(data.toStdString());
}

void SUI::ButtonImpl::loadPressedImage() {
    QString data = getPropertyValue(SUI::ObjectPropertyTypeEnum::ImageDataPressed);
    if (!data.isEmpty()) setImage(data.toStdString());
}

CustomPushButton *SUI::ButtonImpl::getWidget() const {
    return qobject_cast<CustomPushButton *>(BaseWidget::getWidget());
}

void SUI::ButtonImpl::setText(const std::string &value) {
    QPushButton *button = getWidget();
    if (button->text() == QString::fromStdString(value)) return;
    button->setText(QString::fromStdString(value));
}

std::string SUI::ButtonImpl::getText() const {
    return getWidget()->text().toStdString();
}

void SUI::ButtonImpl::clearText() {
    getWidget()->setText("");
}

void SUI::ButtonImpl::setImage(const std::string &value) {
    QByteArray byteArray = QByteArray::fromBase64(QString::fromStdString(SUI::ResourcePath::getResourceFile(value)).toUtf8());
    QImage img = QImage::fromData(byteArray);
    QPixmap pixmap = QPixmap::fromImage(img);
    getWidget()->setIcon(QIcon(pixmap));
}

void SUI::ButtonImpl::setImage(unsigned char *, int, int, ImageEnum::Format) {
}

void SUI::ButtonImpl::setAlignment(AlignmentEnum::Alignment align) {
    if (align == SUI::AlignmentEnum::Stretch) return;
    if (SUI::AlignmentEnum::fromString(getProperty(SUI::ObjectPropertyTypeEnum::Alignment)->getValue().toStdString()) != align) {
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Alignment, QString::fromStdString(AlignmentEnum::toString(align)));
    }
    getWidget()->setProperty("SUIAlignment", QString::fromStdString(AlignmentEnum::toString(align)));
    getWidget()->style()->polish(getWidget());
}

SUI::AlignmentEnum::Alignment SUI::ButtonImpl::getAlignment() const {
    return SUI::AlignmentEnum::fromString(getPropertyValue(SUI::ObjectPropertyTypeEnum::Alignment).toStdString());
}

void SUI::ButtonImpl::setBold(bool bold) {
    getWidget()->setProperty("SUIFont", QVariant::fromValue<QString>(bold ? "bold" : ""));
    getWidget()->style()->polish(getWidget());
}

bool SUI::ButtonImpl::isBold() const {
    return getWidget()->property("SUIFont").toString() == "bold";
}

void SUI::ButtonImpl::handleClicked() {
    if (!clicked.empty()) clicked();
}

void SUI::ButtonImpl::setDefaultProperties(const ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);    
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "30");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "200");
    setPropertyValue(ObjectPropertyTypeEnum::Alignment,QString::fromStdString(SUI::AlignmentEnum::toString(SUI::AlignmentEnum::HCenter)));

    switch (context)
    {
    case EditorSelector:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, QString::fromStdString(SUI::ObjectType::toString(Object::getObjectType())));
        break;

    case EditorForm:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, "TBD");
        break;

    default:
        break;
    }
}

void SUI::ButtonImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID, propertyValue);

    switch (propertyID) {
    case SUI::ObjectPropertyTypeEnum::Bold:
        setBold((propertyValue.compare("true", Qt::CaseInsensitive) == 0));
        break;
    case SUI::ObjectPropertyTypeEnum::Text:
        setText(propertyValue.toStdString());
        break;
    case SUI::ObjectPropertyTypeEnum::Alignment:
        if (propertyValue.toLower() == "right") {
            setAlignment(AlignmentEnum::Right);
        }
        else if (propertyValue.toLower() == "left") {
            setAlignment(AlignmentEnum::Left);
        }
        else  {
            setAlignment(AlignmentEnum::HCenter);
        }
        break;
    case SUI::ObjectPropertyTypeEnum::ImageData:
        setImage(propertyValue.toStdString());
        break;
    default:
        break;

    }
}

void SUI::ButtonImpl::setGeometry() {
    BaseWidget::setGeometry();
    setImage(getPropertyValue(SUI::ObjectPropertyTypeEnum::ImageData).toStdString());
}

bool SUI::ButtonImpl::eventFilter(QObject *obj, QEvent *event) {
    if (event->type() == QEvent::HoverEnter && !hoverEntered.empty()) {
        hoverEntered();
    }
    if (event->type() == QEvent::HoverLeave && !hoverLeft.empty()) {
        hoverLeft();
    }
    return BaseWidget::eventFilter(obj, event);
}
