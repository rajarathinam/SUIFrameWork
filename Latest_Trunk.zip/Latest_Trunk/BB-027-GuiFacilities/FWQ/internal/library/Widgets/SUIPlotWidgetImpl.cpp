//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::PlotWidgetImpl.
// !\description This class is the implementation for SUIPlotWidget.
//               The getWidget() pointer, which usualy holds the address of the
//               appropriate QWidget, here holds the address of the QwtPlot instance.
//               The ScalePoints struct is used because one can set scale,
//               before it is being enabled. ScalePoints will remember scale and set properly,
//               when it is being enabled.This class uses a subclass of QwtPlotZoneItem,
//               which draws a rectangle with the given interval.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUIPlotWidgetImpl.h"
#include "SUIStyleSheet.h"
#include <QStyle>
#include <qwt_legend_label.h>
#include <qwt_plot_layout.h>

SUI::PlotWidgetImpl::PlotWidgetImpl(QWidget *parent) :
    BaseWidget(new QwtPlot(parent), SUI::ObjectType::PlotWidget, true),
    mYLeftSideUsed(false),
    mYRightSideUsed(false),
    mPlot(dynamic_cast<QwtPlot *>(this->getWidget())),
    mScalePoints({0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00 }),
    mLeftScaleType(ScaleTypeEnum::Linear),
    mRightScaleType(ScaleTypeEnum::Linear),
    mPlotGrid(new QwtPlotGrid()),
    mGridColor(SUI::ColorEnum::Gray)
{
    mpicker = new PickerPlotWidget(QwtPlot::xBottom,QwtPlot::yLeft, QwtPlotPicker::CrossRubberBand, QwtPicker::AlwaysOn, dynamic_cast<QWidget *>(mPlot->canvas())) ;
    mzoomer[0] = new ZoomPlotWidget(QwtPlot::xBottom, QwtPlot::yLeft,dynamic_cast<QWidget *>(mPlot->canvas())) ;
    mzoomer[1] = new ZoomPlotWidget(QwtPlot::xTop, QwtPlot::yRight,dynamic_cast<QWidget *>(mPlot->canvas())) ;
    exposeHeightProperty();
    exposeWidthProperty();
    initialize();
}

SUI::PlotWidgetImpl::~PlotWidgetImpl() {
    qDeleteAll(mZoneItems);
    delete mPlotGrid;
    mPlotGrid = NULL;
    qDeleteAll(mRangeRectangles);
    delete mpicker;
    mpicker = NULL;
    delete mzoomer[0];
    delete mzoomer[1];
}

void SUI::PlotWidgetImpl::initialize() {
    //initialize yRight axis to false
    mPlot->enableAxis(QwtPlot::yRight, false);
    //initialize plotzoom
    mzoomer[0]->setRubberBand( QwtPicker::RectRubberBand );
    mzoomer[0]->setRubberBandPen( QColor( Qt::green ) );
    mzoomer[0]->setTrackerMode( QwtPicker::ActiveOnly );
    mzoomer[0]->setTrackerPen( QColor( Qt::white ) );
    //initialize plotgrid
    mPlotGrid->enableX(false);
    mPlotGrid->enableY(false);
    mPlotGrid->attach(mPlot);
    mPlotGrid->setMajorPen(Qt::gray, 0.0, Qt::DashLine);
    mPlotGrid->setMinorPen(Qt::gray, 0.0, Qt::DotLine);
    //initialize plot picker
    mpicker->setAxis(mPlot->xBottom,mPlot->yLeft);

    connect(mPlot->axisWidget(QwtPlot::yLeft), SIGNAL(scaleDivChanged()), this, SLOT(onScaleChanged()));
}

void SUI::PlotWidgetImpl::setDefaultProperties(const ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);

    setPropertyValue(ObjectPropertyTypeEnum::Height, "200");
    setPropertyValue(ObjectPropertyTypeEnum::Width, "400");

    switch (context) {
    case EditorSelector:
        setPropertyValue(ObjectPropertyTypeEnum::Width, "600");
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, QString::fromStdString(SUI::ObjectType::toString(Object::getObjectType())));
        setXAutoScale(true);
        break;
    case EditorForm:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, "");
        break;
    default:
        break;
    }
}

void SUI::PlotWidgetImpl::setText(const std::string &value) {
    if (getText() == value) return;
    mPlot->setTitle(QString::fromStdString(value));
}

std::string SUI::PlotWidgetImpl::getText() const {
    return mPlot->title().text().toStdString();
}

void SUI::PlotWidgetImpl::clearText() {
    setText("");
}

void SUI::PlotWidgetImpl::setBold(bool bold) {
    QFont font = getWidget()->font();
    font.setBold(bold);
    getWidget()->setFont(font);
}

bool SUI::PlotWidgetImpl::isBold() const {
    return getWidget()->font().bold();
}
SUI::ColorEnum::Color SUI::PlotWidgetImpl::getBGColor() const {
    return ColorEnum::fromString(getPropertyValue(SUI::ObjectPropertyTypeEnum::BGColor).toStdString());
}

void SUI::PlotWidgetImpl::setBGColor(const SUI::ColorEnum::Color color) {
    if (!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color)) return;
    if (ColorEnum::fromString(getPropertyValue(SUI::ObjectPropertyTypeEnum::BGColor).toStdString()) != color) {
        setPropertyValue(SUI::ObjectPropertyTypeEnum::BGColor, QString::fromStdString(ColorEnum::toString(color)).toLower());
    }
    if(mPlot->titleLabel() != NULL) {
        dynamic_cast<QwtTextLabel *>(mPlot->titleLabel())->setProperty("BGColorSet", QString::fromStdString(ColorEnum::toString(color)).toLower());
    }
    static_cast<QwtPlot*>(mPlot)->setProperty("BGColorSet", QString::fromStdString(ColorEnum::toString(color)).toLower());
    mPlot->canvas()->setProperty("BGColorSet", QString::fromStdString(ColorEnum::toString(color)).toLower());
    mPlot->axisWidget(QwtPlot::xBottom)->setProperty("BGColorSet", QString::fromStdString(ColorEnum::toString(color)).toLower());
    mPlot->axisWidget(QwtPlot::xTop)->setProperty("BGColorSet", QString::fromStdString(ColorEnum::toString(color)).toLower());
    mPlot->axisWidget(QwtPlot::yLeft)->setProperty("BGColorSet", QString::fromStdString(ColorEnum::toString(color)).toLower());
    mPlot->axisWidget(QwtPlot::yRight)->setProperty("BGColorSet", QString::fromStdString(ColorEnum::toString(color)).toLower());
    if (mPlot->legend() != NULL) {
        dynamic_cast<QwtLegend *>(mPlot->legend())->setProperty("BGColorSet", QString::fromStdString(ColorEnum::toString(color)).toLower());
        if(dynamic_cast<QwtLegend *>(mPlot->legend())->contentsWidget() != NULL) {
            dynamic_cast<QwtLegend *>(mPlot->legend())->contentsWidget()->setProperty("BGColorSet", QString::fromStdString(ColorEnum::toString(color)).toLower());
        }
    }
    QwtPlotItemList histogramItems = mPlot->itemList(QwtPlotItem::Rtti_PlotHistogram);
    for ( int i = 0; i < histogramItems.size(); i++ )
    {
        const QVariant itemInfo = mPlot->itemToInfo( histogramItems[i] );
        if(mPlot->legend() != NULL) {
            QwtLegend *legend = qobject_cast<QwtLegend *>(mPlot->legend());
            if(legend->legendWidget(itemInfo) != NULL) {
                QwtLegendLabel *legendLabel = qobject_cast<QwtLegendLabel *>(legend->legendWidget(itemInfo));
                legendLabel->setProperty("BGColorSet", QString::fromStdString(ColorEnum::toString(color)).toLower());
                getWidget()->style()->polish(legendLabel);
            }
        }
    }
    QwtPlotItemList curveItems = mPlot->itemList(QwtPlotItem::Rtti_PlotCurve);
    for ( int i = 0; i < curveItems.size(); i++ )
    {
        const QVariant itemInfo = mPlot->itemToInfo( curveItems[i] );
        if(mPlot->legend() != NULL) {
            QwtLegend *legend = qobject_cast<QwtLegend *>(mPlot->legend());
            if(legend->legendWidget(itemInfo) != NULL) {
                QwtLegendLabel *legendLabel = qobject_cast<QwtLegendLabel *>(legend->legendWidget(itemInfo));
                legendLabel->setProperty("BGColorSet", QString::fromStdString(ColorEnum::toString(color)).toLower());
                getWidget()->style()->polish(legendLabel);
            }
        }
    }
    getWidget()->style()->polish(getWidget());
    getWidget()->style()->polish(mPlot->canvas());
    getWidget()->style()->polish(mPlot->axisWidget(QwtPlot::xBottom));
    getWidget()->style()->polish(mPlot->axisWidget(QwtPlot::xTop));
    getWidget()->style()->polish(mPlot->axisWidget(QwtPlot::yLeft));
    getWidget()->style()->polish(mPlot->axisWidget(QwtPlot::yRight));
    if (mPlot->legend() != NULL) {
        getWidget()->style()->polish(mPlot->legend());
        getWidget()->style()->polish(dynamic_cast<QwtLegend *>(mPlot->legend())->contentsWidget());
    }
    if (mPlot->titleLabel() != NULL) getWidget()->style()->polish(mPlot->titleLabel());
}

SUI::ColorEnum::Color SUI::PlotWidgetImpl::getColor() const {
    return SUI::ColorEnum::fromString(getPropertyValue(SUI::ObjectPropertyTypeEnum::Color).toStdString());
}

void SUI::PlotWidgetImpl::setColor(const SUI::ColorEnum::Color color) {
    if (!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color)) return;
    if (SUI::ColorEnum::fromString(getProperty(SUI::ObjectPropertyTypeEnum::Color)->getValue().toStdString()) != color) {
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Color, QString::fromStdString(ColorEnum::toString(color)));
    }
    mPlot->axisWidget(QwtPlot::xBottom)->setProperty("ColorSet", QString::fromStdString(ColorEnum::toString(color)).toLower());
    mPlot->axisWidget(QwtPlot::xTop)->setProperty("ColorSet", QString::fromStdString(ColorEnum::toString(color)).toLower());
    mPlot->axisWidget(QwtPlot::yLeft)->setProperty("ColorSet", QString::fromStdString(ColorEnum::toString(color)).toLower());
    mPlot->axisWidget(QwtPlot::yRight)->setProperty("ColorSet", QString::fromStdString(ColorEnum::toString(color)).toLower());
    if(mPlot->titleLabel() != NULL) {
        dynamic_cast<QwtTextLabel *>(mPlot->titleLabel())->setProperty("ColorSet", QString::fromStdString(ColorEnum::toString(color)).toLower());
    }
    if (mPlot->legend() != NULL) {
        dynamic_cast<QwtLegend *>(mPlot->legend())->setProperty("ColorSet", QString::fromStdString(ColorEnum::toString(color)).toLower());
        if(dynamic_cast<QwtLegend *>(mPlot->legend())->contentsWidget() != NULL) {
            dynamic_cast<QwtLegend *>(mPlot->legend())->contentsWidget()->setProperty("ColorSet", QString::fromStdString(ColorEnum::toString(color)).toLower());
        }
    }
    QwtPlotItemList histogramItems = mPlot->itemList(QwtPlotItem::Rtti_PlotHistogram);
    for ( int i = 0; i < histogramItems.size(); i++ )
    {
        const QVariant itemInfo = mPlot->itemToInfo( histogramItems[i] );
        if(mPlot->legend() != NULL) {
            QwtLegend *legend = qobject_cast<QwtLegend *>(mPlot->legend());
            if(legend->legendWidget(itemInfo) != NULL) {
                QwtLegendLabel *legendLabel = qobject_cast<QwtLegendLabel *>(legend->legendWidget(itemInfo));
                legendLabel->setProperty("ColorSet", QString::fromStdString(ColorEnum::toString(color)).toLower());
                getWidget()->style()->polish(legendLabel);
            }
        }
    }
    QwtPlotItemList curveItems = mPlot->itemList(QwtPlotItem::Rtti_PlotCurve);
    for ( int i = 0; i < curveItems.size(); i++ )
    {
        const QVariant itemInfo = mPlot->itemToInfo( curveItems[i] );
        if(mPlot->legend() != NULL) {
            QwtLegend *legend = qobject_cast<QwtLegend *>(mPlot->legend());
            if(legend->legendWidget(itemInfo) != NULL) {
                QwtLegendLabel *legendLabel = qobject_cast<QwtLegendLabel *>(legend->legendWidget(itemInfo));
                legendLabel->setProperty("ColorSet", QString::fromStdString(ColorEnum::toString(color)).toLower());
                getWidget()->style()->polish(legendLabel);
            }
        }
    }
    getWidget()->style()->polish(mPlot->axisWidget(QwtPlot::xBottom));
    getWidget()->style()->polish(mPlot->axisWidget(QwtPlot::xTop));
    getWidget()->style()->polish(mPlot->axisWidget(QwtPlot::yLeft));
    getWidget()->style()->polish(mPlot->axisWidget(QwtPlot::yRight));
    if (mPlot->legend() != NULL) {
        getWidget()->style()->polish(mPlot->legend());
        getWidget()->style()->polish(dynamic_cast<QwtLegend *>(mPlot->legend())->contentsWidget());
    }
    if (mPlot->titleLabel() != NULL) getWidget()->style()->polish(mPlot->titleLabel());
}

void SUI::PlotWidgetImpl::setAutoReplot(bool autoreplot) {
    mPlot->setAutoReplot(autoreplot);
}

bool SUI::PlotWidgetImpl::getAutoReplot() const {
   return mPlot->autoReplot();
}

/*****************************************************************************\
 *  FUNCTION    :   setScaleType
 *  PARAMETERS  :   PlotDataSet::Y_SIDE side
 *                      Left or Right side.
 *                  PlotDataSet::SCALE_TYPE type
 *                      The type of scale to use.
 *  RETURN      :   QString
 *                      The semicolon separated list of all DataSet names
 *
\*****************************************************************************/
void SUI::PlotWidgetImpl::setScaleType(PlotAxisEnum::PlotAxis side, ScaleTypeEnum::ScaleType type)
{
    if (side == PlotAxisEnum::yLeft)
    {
        if (type != mLeftScaleType)
        {
            QwtScaleEngine  *newScaleEng = makeNewEngine(type);
            mPlot->setAxisScaleEngine(QwtPlot::yLeft, newScaleEng);
            mLeftScaleType = type;
            setYLeftScale(mScalePoints.YLeft_min, mScalePoints.YLeft_max);
        }
    }
    else
    {
        if (type != mRightScaleType)
        {
            QwtScaleEngine  *newScaleEng = makeNewEngine(type);
            mPlot->setAxisScaleEngine(QwtPlot::yRight, newScaleEng);
            mRightScaleType = type;
            setYRightScale(mScalePoints.YRight_min, mScalePoints.YRight_max);
        }
    }
}

/*****************************************************************************\
 *  FUNCTION    :   setXGrid
 *  PARAMETERS  :   bool maxlines
 *                      Set the Max Lines on or off.
 *                  bool minlines
 *                      Set the Min Lines on or off.
 *  RETURN      :   void
 *
 *  This function enables or disables the X Grid for the Max lines and the Min
 *  lines.
\*****************************************************************************/
void SUI::PlotWidgetImpl::setXGrid(GridStyleEnum::GridStyle style)
{
    switch (style)
    {
    case GridStyleEnum::Normal:
        mPlotGrid->enableX(true);
        mPlotGrid->enableXMin(false);
        break;
    case GridStyleEnum::Detail:
        mPlotGrid->enableX(true);
        mPlotGrid->enableXMin(true);
        break;
    default:
        mPlotGrid->enableX(false);
        mPlotGrid->enableXMin(false);
        break;
    }
}

SUI::GridStyleEnum::GridStyle SUI::PlotWidgetImpl::getXGrid() {
    if(!mPlotGrid->xEnabled()) {
        return GridStyleEnum::Off;
    }
    else if(mPlotGrid->xEnabled() && mPlotGrid->xMinEnabled()) {
        return GridStyleEnum::Detail;
    }
    else {
        return GridStyleEnum::Normal;
    }
}


/*****************************************************************************\
 *  FUNCTION    :   setYGrid
 *  PARAMETERS  :   bool maxlines
 *                      Set the Max Lines on or off.
 *                  bool minlines
 *                      Set the Max Lines on or off.
 *  RETURN      :   void
 *
 *  This function enables or disables the Y Grid for the Max lines and the Min
 *  lines.
\*****************************************************************************/
void SUI::PlotWidgetImpl::setYGrid(GridStyleEnum::GridStyle style) {
    switch (style){
    case GridStyleEnum::Normal:
        mPlotGrid->enableY(true);
        mPlotGrid->enableYMin(false);
        break;
    case GridStyleEnum::Detail:
        mPlotGrid->enableY(true);
        mPlotGrid->enableYMin(true);
        break;
    default:
        mPlotGrid->enableY(false);
        mPlotGrid->enableYMin(false);
        break;
    }
}

SUI::GridStyleEnum::GridStyle SUI::PlotWidgetImpl::getYGrid() {
    if(!mPlotGrid->yEnabled()) {
        return GridStyleEnum::Off;
    }
    else if(mPlotGrid->yEnabled() && mPlotGrid->yMinEnabled()) {
        return GridStyleEnum::Detail;
    }
    else {
        return GridStyleEnum::Normal;
    }
}

void SUI::PlotWidgetImpl::setXLabel(const std::string &label) {
    mPlot->setAxisTitle(QwtPlot::xBottom, QString::fromStdString(label));
}

void SUI::PlotWidgetImpl::setYLeftLabel(const std::string &label) {
    mPlot->setAxisTitle(QwtPlot::yLeft, QString::fromStdString(label));
}

void SUI::PlotWidgetImpl::setYRightLabel(const std::string &label) {
    mPlot->setAxisTitle(QwtPlot::yRight, QString::fromStdString(label));
}

void SUI::PlotWidgetImpl::setAxisScale(SUI::PlotAxisEnum::PlotAxis axis, double min, double max, double stepsize) {
    setAxisScale(axis, min, max, true, stepsize);
}


void SUI::PlotWidgetImpl::setAxisScale(SUI::PlotAxisEnum::PlotAxis axis, double min, double max, bool replot, double stepsize) {
    if(min >= max) return;
    setScale(axis, min, max, stepsize);
    mzoomer[0]->setZoomBase(replot);
    mzoomer[1]->setZoomBase(replot);
}

void SUI::PlotWidgetImpl::setScale(SUI::PlotAxisEnum::PlotAxis axis, double min, double max, double stepsize )
{
    switch(axis) {
    case PlotAxisEnum::PlotAxis::xBottom:
    {
        mScalePoints.XBottom_min = min;
        mScalePoints.XBottom_max = max;
        break;
    }
    case PlotAxisEnum::PlotAxis::xTop:
    {
        mScalePoints.xTop_min = min;
        mScalePoints.xTop_max = max;
        break;
    }
    case PlotAxisEnum::PlotAxis::yLeft:
    {
        mScalePoints.YLeft_min = min;
        mScalePoints.YLeft_max = max;
        break;
    }
    default:
    {
        mScalePoints.YRight_min = min;
        mScalePoints.YRight_max = max;
        break;
    }
    }

    if (mPlot->axisEnabled(toQwtPlotAxis(axis))) {
        mPlot->setAxisScale(toQwtPlotAxis(axis), min, max, stepsize);
    }
}


/*!
 * \brief SUI::PlotWidgetImpl::setXScale
 * Is added for legacy support.
 */
void SUI::PlotWidgetImpl::setXScale(const double xMin, const double xMax, const double stepsize) {
    setAxisScale(PlotAxisEnum::PlotAxis::xBottom, xMin, xMax, stepsize);
}

/*!
 * \brief SUI::PlotWidgetImpl::setYLeftScale
 * Is added for legacy support.
 */
void SUI::PlotWidgetImpl::setYLeftScale(const double yMin, const double yMax, const double stepsize) {
    setAxisScale(PlotAxisEnum::PlotAxis::yLeft, yMin, yMax, stepsize);
}

/*!
 * \brief SUI::PlotWidgetImpl::setYRightScale
 * Is added for legacy support.
 */
void SUI::PlotWidgetImpl::setYRightScale(const double yMin, const double yMax, const double stepsize) {
    setAxisScale(PlotAxisEnum::PlotAxis::yRight, yMin, yMax, stepsize);
}


double SUI::PlotWidgetImpl::getAxisMinValue(PlotAxisEnum::PlotAxis axis) const {
    return mPlot->axisInterval(toQwtPlotAxis(axis)).minValue();
}

double SUI::PlotWidgetImpl::getAxisMaxValue(PlotAxisEnum::PlotAxis axis) const {
    return mPlot->axisInterval(toQwtPlotAxis(axis)).maxValue();
}

double SUI::PlotWidgetImpl::getAxisStepSize(PlotAxisEnum::PlotAxis axis) const {
    return mPlot->axisStepSize(toQwtPlotAxis(axis));
}

void SUI::PlotWidgetImpl::setTitle(const std::string &title) {
    mPlot->setTitle(QString::fromStdString(title));
}

std::string SUI::PlotWidgetImpl::getTitle() const {
    return mPlot->title().text().toStdString();
}

void SUI::PlotWidgetImpl::setMouseCursor(SUI::CursorShapeEnum::CursorShape cursor) {
    mPlot->setCursor(static_cast<Qt::CursorShape>(cursor));
    mPlot->canvas()->setCursor(static_cast<Qt::CursorShape>(cursor));
}

SUI::CursorShapeEnum::CursorShape SUI::PlotWidgetImpl::getMouseCursor() const {
    return static_cast<SUI::CursorShapeEnum::CursorShape>(mPlot->canvas()->cursor().shape());
}

void SUI::PlotWidgetImpl::setLegendEnabled(bool on, SUI::PlotLegendPositionEnum::PlotLegendPosition legend) {
    mPlot->insertLegend(on ? new QwtLegend(): NULL, toQwtPlotLegend(legend));
}

bool SUI::PlotWidgetImpl::getLegendEnabled() const {
    return mPlot->legend() != NULL ? true : false;
}

SUI::PlotLegendPositionEnum::PlotLegendPosition SUI::PlotWidgetImpl::getLegendPosition() const  {
    SUI::PlotLegendPositionEnum::PlotLegendPosition legend = SUI::PlotLegendPositionEnum::Right;
    if(getLegendEnabled()){
        if(mPlot->plotLayout() != NULL){
            switch(mPlot->plotLayout()->legendPosition()) {
            case QwtPlot::LeftLegend: legend = SUI::PlotLegendPositionEnum::Left;
                break;
            case QwtPlot::TopLegend: legend = SUI::PlotLegendPositionEnum::Top;
                break;
            case QwtPlot::BottomLegend: legend = SUI::PlotLegendPositionEnum::Bottom;
                break;
            default: legend = SUI::PlotLegendPositionEnum::Right;
                break;
            }
        }
    }
    return legend;
}

void SUI::PlotWidgetImpl::setLabelRotation(const SUI::PlotAxisEnum::PlotAxis axis, const double rotation) {
    mPlot->axisScaleDraw(toQwtPlotAxis(axis))->setLabelRotation(rotation);
}

double SUI::PlotWidgetImpl::getLabelRotation(const SUI::PlotAxisEnum::PlotAxis axis) const {
    return mPlot->axisScaleDraw(toQwtPlotAxis(axis))->labelRotation();
}

/*****************************************************************************\
 *  FUNCTION    :   replot
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This function replots the plot.
\*****************************************************************************/
void SUI::PlotWidgetImpl::replot() const {
    mPlot->replot();
}

/*****************************************************************************\
 *  FUNCTION    :   makeNewEngine
 *  PARAMETERS  :   PlotDataSet::SCALE_TYPE type
 *                      The new ScaleEngine to create.
 *  RETURN      :   void
 *
\*****************************************************************************/
QwtScaleEngine *SUI::PlotWidgetImpl::makeNewEngine(ScaleTypeEnum::ScaleType type)
{
    QwtScaleEngine  *retEngine = NULL;
    switch (type)
    {
    case ScaleTypeEnum::Linear:
        retEngine = new QwtLinearScaleEngine;
        break;
    case ScaleTypeEnum::Logarithmic:
        retEngine = new QwtLogScaleEngine;
        break;
    default:
        break;
    }
    return retEngine;
}

/*****************************************************************************\
 *  FUNCTION    :   onScaleChanged
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This is a SLOT function connected to the scaleDivChanged() SIGNAL of the
 *  yLeft Scale QwtScaleWidget.
 *  Because the Text label y position of the Rectangle's (QwtPlotZoneItem) is
 *  calculated from the Canvas, these positions have to be recalculated, when
 *  the Y Scale changes.
\*****************************************************************************/
void SUI::PlotWidgetImpl::onScaleChanged() {
    QMap<int, ZoneRectangle *> ::iterator it;
    for (it = mZoneItems.begin(); it != mZoneItems.end(); ++it)
    {
        (*it)->setLabelPosition();
    }
}

/*****************************************************************************\
 *  FUNCTION    :   SetRectangle
 *  PARAMETERS  :   const int id
 *                      The ID for the Rectangle
 *                  const double xstart
 *                      The X coordinate where the rectangle should begin.
 *                  const double xend
 *                      The X coordinate where the rectangle should end.
 *                  PlotDataSet::CurveColor color
 *                      The color of the rectangle.
 *                  bool set
 *                      Defines whether the rectangle must be turned on or off.
 *                  const QString label
 *                      The name / label of the rectangle.
 *                  const EnumPlotAxis::PLOT_AXIS axis
 *                      Indicates which axis to use.
 *  RETURN      :   void
 *
 *  This function adds a new rectangle to the PlotWidget if it doesn't already
 *  exist and set is true. If set is true and the rectangle does not exist yet,
 *  it makes a new rectangle at the given position, with the given color and
 *  the given label. If set is false and the rectangle exists, it will hide
 *  that rectangle. If the rectangle does not exist and set is false, nothing
 *  happens.
 *  If the rectangle exists and set is true, it is being redrawn with the
 *  appropriate parameters, so one can change the start, end, color and label
 *  of an existing rectangle.
\*****************************************************************************/
void SUI::PlotWidgetImpl::setRectangle(const int id, const double start, const double end, ColorEnum::Color color, bool set,
                                   const std::string &label, const PlotAxisEnum::PlotAxis axis)
{
    if (!set)
    {
        if (mZoneItems.contains(id))
        {
            mZoneItems[id]->setVisible(false);
        }
    }
    else
    {
        if (!mZoneItems.contains(id))
        {
            mZoneItems.insert(id, new ZoneRectangle(mPlot));
            mZoneItems[id]->attach(mPlot);
        }
        Qt::Orientation orient = Qt::Horizontal;
        QwtPlot::Axis   ySide = toQwtPlotAxis(axis);
        switch (axis)
        {
        case PlotAxisEnum::xBottom:
            orient = Qt::Vertical;
            break;
        case PlotAxisEnum::yLeft:
            orient = Qt::Horizontal;
            break;
        case PlotAxisEnum::yRight:
            orient = Qt::Horizontal;
            break;
        default:
            break;
        }
        QColor lColor = SUI::RangeRectangle::mapColor(color);

        mZoneItems[id]->setOrientation(orient);
        mZoneItems[id]->setColor(lColor);
        mZoneItems[id]->setVisible(true);
        mZoneItems[id]->setYAxis(ySide);
        mZoneItems[id]->setInterval(start, end);
        mZoneItems[id]->setLabel(QString::fromStdString(label));
        mZoneItems[id]->setLabelPosition();
    }
}

/*****************************************************************************\
 *  FUNCTION    :   SetROI
 *  PARAMETERS  :   int id
 *                      The name / id of the ROI
 *                  bool set
 *                      Turns the ROI on or off
 *                  const std string label
 *                      The name / label of the rectangle.
 *                  EnumCurveColor::CurveColor color
 *                      The color of the ROI
 *                  int xstart
 *                      The start point x value, relative to the X Bottom scale
 *                  int xend
 *                      The width of the ROI, relative to the X Bottom scale
 *                  int ystart
 *                      The start point y value, relative to the Left Y scale
 *                  int yend
 *                      The height of the ROI, relative to the Left Y scale
 *                  const EnumPlotAxis::PLOT_AXIS axis
 *                      Indicates which axis to use.
 *  RETURN      :   void
 *
 *  This function paints a Region Of Interest in the PlotWidget or turns it off.
\*****************************************************************************/
void SUI::PlotWidgetImpl::setROI(int id, bool set, const std::string &label, int xstart, int xend, int ystart, int yend ,
                             ColorEnum::Color color, const PlotAxisEnum::PlotAxis axis)
{
    if (!mRangeRectangles.contains(id))
    {
        mRangeRectangles.insert(id, new RangeRectangle());
    }
    if (set)
    {
        if ((xstart < INT_MAX) && (ystart < INT_MAX) && (xend < INT_MAX) && (yend < INT_MAX))
        {
            mRangeRectangles[id]->attach(mPlot);
            mRangeRectangles[id]->setRectangle(xstart, ystart, xend - xstart, yend - ystart, color, axis, label);
        }
    }
    else
    {
        mRangeRectangles[id]->detach();
    }
}

void SUI::PlotWidgetImpl::setLegend(bool on) {
    setLegendEnabled(on, SUI::PlotLegendPositionEnum::Right);
}

/*!
 * \brief SUI::PlotWidgetImpl::setXAutoScale
 * Is added for legacy support.
 */
void SUI::PlotWidgetImpl::setXAutoScale(bool set) {
    setAxisAutoScale(SUI::PlotAxisEnum::xBottom, set);
}

void SUI::PlotWidgetImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID, propertyValue);

    switch (propertyID) {
    case SUI::ObjectPropertyTypeEnum::Hover:
        mpicker->setEnabled(propertyValue.toLower() == "true");
        break;
    case SUI::ObjectPropertyTypeEnum::Zoom:
        mzoomer[0]->setEnabled(propertyValue.toLower() == "true");
        mzoomer[1]->setEnabled(mzoomer[0]->isEnabled());
        break;
    case SUI::ObjectPropertyTypeEnum::xAxisScale:
        setXAxisScaleDraw(propertyValue.toStdString());
        break;
    case SUI::ObjectPropertyTypeEnum::Bold:
        setBold((propertyValue.compare("true", Qt::CaseInsensitive) == 0));
        break;
    case SUI::ObjectPropertyTypeEnum::Text:
        setText(propertyValue.toStdString());
        break;
    case SUI::ObjectPropertyTypeEnum::BGColor:
        setBGColor(SUI::ColorEnum::fromString(propertyValue.toStdString()));
        break;
    case SUI::ObjectPropertyTypeEnum::Color:
        setColor(SUI::ColorEnum::fromString(propertyValue.toStdString()));
        break;
    default:
        break;
    }
}

QwtPlot *SUI::PlotWidgetImpl::getPlot() const {
    return mPlot;
}

void SUI::PlotWidgetImpl::setPlot(QwtPlot *plot) {
    mPlot = plot;
}

void SUI::PlotWidgetImpl::setXAxisScaleDraw(const std::string value) {
    std::string axisType = value;
    std::transform(axisType.begin(), axisType.end(), axisType.begin(), ::tolower);
    PlotAxisEnum::XAxisDateTime xAxis;
    if (axisType == "normal") {
        xAxis = PlotAxisEnum::NORMAL;
        setXScale(mScalePoints.XBottom_min, mScalePoints.XBottom_max);
    }
    else {
        if (axisType == "date") {
            xAxis = PlotAxisEnum::DATE;
        }
        else if (axisType == "time") {
            xAxis = PlotAxisEnum::TIME;
        }
        else if (axisType == "datetime") {
            xAxis = PlotAxisEnum::DATETIME;
        }
        else if (axisType == "timesmall") {
            xAxis = PlotAxisEnum::TIMESMALL;
        }
        else {
            xAxis = PlotAxisEnum::CUSTOMTIME;
        }

        DateTimeScaleDraw *scaleDraw = new DateTimeScaleDraw(Qt::UTC);
        scaleDraw->setXAxisScale(xAxis);
        mPlot->setAxisScaleDraw(QwtPlot::xBottom, scaleDraw);
    }
    mpicker->setXAxisScale(xAxis);
}

void SUI::PlotWidgetImpl::setCustomXAxisScale(const std::list<double> &items) {
    QList<double> ticks = QList<double>::fromStdList(items);
    QwtScaleDiv scaleDiv = mPlot->axisScaleDiv(QwtPlot::xBottom);
    scaleDiv.setUpperBound(ticks.last());
    scaleDiv.setLowerBound(ticks.first());
    scaleDiv.setTicks( QwtScaleDiv::MajorTick, ticks );
    mPlot->setAxisScaleDiv( QwtPlot::xBottom, scaleDiv );
    if((getPropertyValue(SUI::ObjectPropertyTypeEnum::xAxisScale)).toLower() != "customtime"){
        setPropertyValue(SUI::ObjectPropertyTypeEnum::xAxisScale, QString("customtime"));
    }
}

bool SUI::PlotWidgetImpl::eventFilter(QObject *obj, QEvent *event) {
    if ((event->type() == QEvent::MouseButtonRelease) && !clicked.empty()) clicked();
    return BaseWidget::eventFilter(obj, event);
}

void SUI::PlotWidgetImpl::setAxisVisible(SUI::PlotAxisEnum::PlotAxis axis, bool visible) {
    mPlot->enableAxis(toQwtPlotAxis(axis), visible);
}

bool SUI::PlotWidgetImpl::getAxisVisible(SUI::PlotAxisEnum::PlotAxis axis) const {
    return mPlot->axisEnabled(toQwtPlotAxis(axis));
}

void SUI::PlotWidgetImpl::setAxisMaxMajor(SUI::PlotAxisEnum::PlotAxis axis, int max) {
    mPlot->setAxisMaxMajor(toQwtPlotAxis(axis), max);
}

int SUI::PlotWidgetImpl::getAxisMaxMajor(SUI::PlotAxisEnum::PlotAxis axis) const {
    return mPlot->axisMaxMajor(toQwtPlotAxis(axis));
}

void SUI::PlotWidgetImpl::setAxisMaxMinor(SUI::PlotAxisEnum::PlotAxis axis, int max) {
    mPlot->setAxisMaxMinor(toQwtPlotAxis(axis), max);
}

int SUI::PlotWidgetImpl::getAxisMaxMinor(SUI::PlotAxisEnum::PlotAxis axis) const {
    return mPlot->axisMaxMinor(toQwtPlotAxis(axis));
}

SUI::FontSizeEnum::FontSize SUI::PlotWidgetImpl::getFontSize(SUI::PlotAxisEnum::PlotAxis axis) const {
    QwtPlot::Axis qwtAxis = toQwtPlotAxis(axis);
    return (mPlot->axisWidget(qwtAxis)->font().pointSize() == SUI::FontSizeEnum::SUI_FONTPOINTSIZE_LARGE) ?
                FontSizeEnum::Big : (mPlot->axisWidget(qwtAxis)->font().pointSize() == SUI::FontSizeEnum::SUI_FONTPOINTSIZE_SMALL) ?
                    FontSizeEnum::Small : (mPlot->axisWidget(qwtAxis)->font().pointSize() == SUI::FontSizeEnum::SUI_FONTPOINTSIZE_NORMAL) ?
                        FontSizeEnum::Normal : FontSizeEnum::Uninitialized;
}

void SUI::PlotWidgetImpl::setAxisFontSize(SUI::PlotAxisEnum::PlotAxis axis, const SUI::FontSizeEnum::FontSize &fontsize) {
    if(fontsize == SUI::FontSizeEnum::Uninitialized) return;
    QwtPlot::Axis qwtAxis = toQwtPlotAxis(axis);
    QFont font = mPlot->axisWidget(qwtAxis)->font();
    switch (fontsize) {
    case FontSizeEnum::Big:
        font.setPointSize(SUI::FontSizeEnum::SUI_FONTPOINTSIZE_LARGE);
        break;
    case FontSizeEnum::Small:
        font.setPointSize(SUI::FontSizeEnum::SUI_FONTPOINTSIZE_SMALL);
        break;
    default:
        font.setPointSize(SUI::FontSizeEnum::SUI_FONTPOINTSIZE_NORMAL);
        break;
    }
    mPlot->axisWidget(qwtAxis)->setFont(font);
}

void SUI::PlotWidgetImpl::setAxisAutoScale(SUI::PlotAxisEnum::PlotAxis axis, bool autoscale) {
    mPlot->setAxisAutoScale(toQwtPlotAxis(axis), autoscale);
}

bool SUI::PlotWidgetImpl::getAxisAutoScale(SUI::PlotAxisEnum::PlotAxis axis) const {
    return mPlot->axisAutoScale(toQwtPlotAxis(axis));
}

void SUI::PlotWidgetImpl::setGridColor(const SUI::ColorEnum::Color color) {
    if (!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color) || color == mGridColor) return;
    mGridColor = color;
    // Grid style & -size can differ for major and minor grids
    // Color is always the same
    QPen penMajor = mPlotGrid->majorPen();
    QPen penMinor = mPlotGrid->minorPen();
    penMajor.setColor(QColor(QString::fromStdString(ColorEnum::toString(mGridColor))));
    penMinor.setColor(QColor(QString::fromStdString(ColorEnum::toString(mGridColor))));
    mPlotGrid->setMajorPen(penMajor);
    mPlotGrid->setMinorPen(penMinor);
}

SUI::ColorEnum::Color SUI::PlotWidgetImpl::getGridColor() const {
    return mGridColor;
}

void SUI::PlotWidgetImpl::setGridMajorStyle(const SUI::LineStyleEnum::LineStyle linestyle) {
    if(linestyle == static_cast<SUI::LineStyleEnum::LineStyle>(mPlotGrid->majorPen().style())) return;
    QPen pen = mPlotGrid->majorPen();
    pen.setStyle(static_cast<Qt::PenStyle>(linestyle));
    mPlotGrid->setMajorPen(pen);
}

SUI::LineStyleEnum::LineStyle SUI::PlotWidgetImpl::getGridMajorStyle() const {
    return static_cast<SUI::LineStyleEnum::LineStyle>(mPlotGrid->majorPen().style());
}

void SUI::PlotWidgetImpl::setGridMinorStyle(const SUI::LineStyleEnum::LineStyle linestyle) {
    if(linestyle == static_cast<SUI::LineStyleEnum::LineStyle>(mPlotGrid->minorPen().style())) return;
    QPen pen = mPlotGrid->minorPen();
    pen.setStyle(static_cast<Qt::PenStyle>(linestyle));
    mPlotGrid->setMinorPen(pen);
}

SUI::LineStyleEnum::LineStyle SUI::PlotWidgetImpl::getGridMinorStyle() const {
    return static_cast<SUI::LineStyleEnum::LineStyle>(mPlotGrid->minorPen().style());
}

QwtPlot::Axis SUI::PlotWidgetImpl::toQwtPlotAxis(SUI::PlotAxisEnum::PlotAxis axis) const {
    QwtPlot::Axis qwtAxis = QwtPlot::xBottom;
    switch(axis) {
    case SUI::PlotAxisEnum::xTop:
        qwtAxis = QwtPlot::xTop;
        break;
    case SUI::PlotAxisEnum::yLeft:
        qwtAxis = QwtPlot::yLeft;
        break;
    case SUI::PlotAxisEnum::yRight:
        qwtAxis = QwtPlot::yRight;
        break;
    default:
        break;
    }
    return qwtAxis;
}

QwtPlot::LegendPosition SUI::PlotWidgetImpl::toQwtPlotLegend(SUI::PlotLegendPositionEnum::PlotLegendPosition legend) const {
    QwtPlot::LegendPosition qwtLegend;
    switch(legend) {
    case SUI::PlotLegendPositionEnum::Left: qwtLegend = QwtPlot::LeftLegend;
        break;
    case SUI::PlotLegendPositionEnum::Right: qwtLegend = QwtPlot::RightLegend;
        break;
    case SUI::PlotLegendPositionEnum::Bottom: qwtLegend = QwtPlot::BottomLegend;
        break;
    default: qwtLegend = QwtPlot::TopLegend;
        break;
    }
    return qwtLegend;
}

SUI::RangeRectangle::RangeRectangle() {
    setZ(0.0);
}

void SUI::RangeRectangle::setRectangle(const int x, const int y, const int width, const int height, ColorEnum::Color color, PlotAxisEnum::PlotAxis axis, const std::string &label)
{
    mRangeRect = QRect(x, y, width, height);
    mColor = color;
    mLabel = QString::fromStdString(label);
    if (axis != PlotAxisEnum::xBottom)
    {
        mAxis = axis;
    }
    if (mAxis == PlotAxisEnum::yRight)
    {
        setAxes(QwtPlot::xBottom, QwtPlot::yRight);
    }
    else
    {
        setAxes(QwtPlot::xBottom, QwtPlot::yLeft);
    }
}

void SUI::RangeRectangle::draw(QPainter *painter, const QwtScaleMap &xMap, const QwtScaleMap &yMap, const QRectF &) const
{
    painter->save();
    QColor  color = mapColor(mColor);
    color.setAlpha(25);
    QBrush  brush;
    brush.setColor(color);
    brush.setStyle(Qt::SolidPattern);
    const QRectF    drawRect = QwtScaleMap::transform(xMap, yMap, mRangeRect);
    painter->fillRect(drawRect, brush);
    painter->drawText(drawRect, Qt::AlignBottom | Qt::AlignHCenter, mLabel);
    painter->restore();
}

QColor SUI::RangeRectangle::mapColor(ColorEnum::Color color)
{
    switch (color)
    {
        case SUI::ColorEnum::Blue: return Qt::blue;
        case SUI::ColorEnum::Green: return Qt::green;
        case SUI::ColorEnum::Red: return Qt::red;
        case SUI::ColorEnum::Yellow: return Qt::yellow;
        case SUI::ColorEnum::Gray: return Qt::gray;
        case SUI::ColorEnum::White: return Qt::white;
        case SUI::ColorEnum::Orange:
        {
            static const int red = 255;
            static const int green = 165;
            static const int blue = 0;
            return QColor(red,green,blue);
        }
        default: return Qt::black;
    }
}

SUI::ZoneRectangle::ZoneRectangle(QwtPlot *parent) :
    mMin(0),
    mMax(0),
    mParent(parent),
    mLabelMarker(new QwtPlotMarker())
{}

void SUI::ZoneRectangle::setColor(const QColor &color)
{
    QColor recColor = color;
    recColor.setAlpha(100);
    setPen(recColor);
    recColor.setAlpha(15);
    setBrush(recColor);
}

void SUI::ZoneRectangle::setLabel(QString label)
{
    mLabelMarker->setLabel(label);
    mLabelMarker->attach(mParent);
}

void SUI::ZoneRectangle::setLabelPosition()
{
    mLabelMarker->setLabelOrientation(Qt::Horizontal);

    QwtScaleMap   ymap = mParent->canvasMap(QwtPlot::xBottom);
    double xMin = ymap.s1();
    double xMax = ymap.s2();
    if (this->orientation() == Qt::Vertical)
    {
        ymap = mParent->canvasMap(QwtPlot::yLeft);
        mLabelMarker->setLabelAlignment(Qt::AlignHCenter | Qt::AlignBottom);
        mLabelMarker->setValue(QPointF((mMax + mMin) / 2.0, ymap.s2()));
    }
    else
    {
        mLabelMarker->setYAxis(this->yAxis());
        ymap = mParent->canvasMap(this->yAxis());
        if (this->yAxis() == QwtPlot::yRight)
        {
            mLabelMarker->setValue(QPointF(xMax, (mMax + mMin) / 2.0));
            mLabelMarker->setLabelAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        }
        else
        {
            mLabelMarker->setValue(QPointF(xMin, (mMax + mMin) / 2.0));
            mLabelMarker->setLabelAlignment(Qt::AlignRight | Qt::AlignVCenter);
        }
    }
}

void SUI::ZoneRectangle::setVisible(bool set)
{
    QwtPlotZoneItem::setVisible(set);
    mLabelMarker->setVisible(set);
}

void SUI::ZoneRectangle::setInterval(double min, double max)
{
    mMin = min;
    mMax = max;
    QwtPlotZoneItem::setInterval(min, max);
}


SUI::PickerPlotWidget::PickerPlotWidget(int xAxis, int yAxis, QwtPicker::RubberBand rubberBand, QwtPicker::DisplayMode trackerMode, QWidget *canvas):
    QwtPlotPicker(xAxis, yAxis, rubberBand, trackerMode, canvas)
{
    mXAxis = PlotAxisEnum::NORMAL;
    setTrackerPen(QColor(Qt::red));
}

void SUI::PickerPlotWidget::setXAxisScale(PlotAxisEnum::XAxisDateTime aAxis)
{
    mXAxis = aAxis;
}

QwtText SUI::PickerPlotWidget::trackerTextF(const QPointF &pos) const
{
    QString text;
    if(mXAxis == PlotAxisEnum::NORMAL) {
        text.sprintf("%.2f, %.2f", pos.x(), pos.y());
    }
    else {
        QDateTime t;
        t.setTime_t(pos.x());
        if (mXAxis == PlotAxisEnum::DATE)
        {
            QString a = t.toString("MM/dd/yyyy");
            text.append(a);
            a.sprintf(", %.2f", pos.y());
            text.append(a);
        }
        else if (mXAxis == PlotAxisEnum::TIME)
        {
            QString a = t.toString("hh:mm:ss");
            text.append(a);
            a.sprintf(", %.2f", pos.y());
            text.append(a);
        }
        else if (mXAxis == PlotAxisEnum::TIMESMALL ||
                 mXAxis == PlotAxisEnum::CUSTOMTIME)
        {
            QString a = t.toString("hh:mm");
            text.append(a);
            a.sprintf(", %.2f", pos.y());
            text.append(a);
        }
        else if (mXAxis == PlotAxisEnum::DATETIME)
        {
            QString a = t.toString("MM/dd/yyyy hh:mm:ss");
            text.append(a);
            a.sprintf(", %.2f", pos.y());
            text.append(a);
        }
    }

    QwtText returnValue = QwtText(text);
    returnValue.setBackgroundBrush(QBrush(QColor(Qt::black)));
    returnValue.setBorderPen(QPen(Qt::black));
    returnValue.setColor(QColor(Qt::white));
    return returnValue;
}


SUI::ZoomPlotWidget::ZoomPlotWidget(int xAxis, int yAxis, QWidget *canvas):
    QwtPlotZoomer(xAxis, yAxis, canvas)
{
    //set the default zoomer settings
    setTrackerMode( QwtPicker::AlwaysOff );
    setRubberBand( QwtPicker::NoRubberBand );
}


SUI::DateTimeScaleDraw::DateTimeScaleDraw(Qt::TimeSpec timeSpec):
    QwtDateScaleDraw(timeSpec)
{
    mXAxis = PlotAxisEnum::NORMAL;
}

void SUI::DateTimeScaleDraw::setXAxisScale(PlotAxisEnum::XAxisDateTime aAxis) {
    mXAxis = aAxis;
    if(mXAxis == PlotAxisEnum::CUSTOMTIME) {
        setTickLength( QwtScaleDiv::MinorTick, 0 );
        setTickLength( QwtScaleDiv::MediumTick, 0 );
    }
}

QwtText SUI::DateTimeScaleDraw::label(double value) const {
    QwtText retText;
    QDateTime ThisDate = QDateTime::fromTime_t(value);
    if (mXAxis == PlotAxisEnum::DATE) {
        retText = ThisDate.toString("yyyy-mm-dd");
    }
    else if (mXAxis == PlotAxisEnum::TIME) {
        retText = ThisDate.toString("hh:mm:ss");
    }
    else if (mXAxis == PlotAxisEnum::TIMESMALL ||
             mXAxis == PlotAxisEnum::CUSTOMTIME) {
        retText = ThisDate.toString("hh:mm");
    }
    else if (mXAxis == PlotAxisEnum::DATETIME) {
        retText = ThisDate.toString("yyyy/MM/dd       _\nhh:mm:ss");
    }
    return retText;
}
