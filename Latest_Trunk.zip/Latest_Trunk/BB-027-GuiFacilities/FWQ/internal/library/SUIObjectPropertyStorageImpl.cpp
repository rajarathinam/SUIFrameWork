//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::ObjectPropertyStorageImpl.
// !\description Class implementation file for SUI::ObjectPropertyStorageImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIObjectPropertyStorageImpl.h"

#include "FWQxCore/SUIArgumentException.h"

#include <QStringList>

SUI::ObjectPropertyStorageImpl::ObjectPropertyStorageImpl()
{

}

QSet<SUI::ObjectPropertyTypeEnum::Type> SUI::ObjectPropertyStorageImpl::getPropertyTypes() const {
    return mStoredProperties.keys().toSet();
}

QMap<QString, QString> SUI::ObjectPropertyStorageImpl::getIncludes() const {
    return mIncludes;
}

void SUI::ObjectPropertyStorageImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    mStoredProperties.insert(propertyID, propertyValue);
}

QString SUI::ObjectPropertyStorageImpl::getPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID) const {
     return (mStoredProperties.keys().contains(propertyID) == true) ? mStoredProperties[propertyID]: QString("");
}

void SUI::ObjectPropertyStorageImpl::setInclude(const QString &include, const QString &fileName) {
    mIncludes.insert(include,fileName);
}

