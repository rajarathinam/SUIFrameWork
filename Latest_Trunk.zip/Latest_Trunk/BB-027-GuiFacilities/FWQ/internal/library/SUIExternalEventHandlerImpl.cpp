//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::ExternalEventHandlerImpl.
// !\description Class implementation file for SUI::ExternalEventHandlerImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUIExternalEventHandlerImpl.h"
#include "FWQxCore/SUIAbstractExternalEvent.h"
#include <QMetaType>

SUI::ExternalEventHandlerImpl::ExternalEventHandlerImpl(QObject *parent) :
    QObject(parent)
{
    qRegisterMetaType<SUI::AbstractExternalEvent*>("SUI::AbstractExternalEvent*");
}

SUI::ExternalEventHandlerImpl::~ExternalEventHandlerImpl()
{
}

void SUI::ExternalEventHandlerImpl::emitEvent(SUI::AbstractExternalEvent *event) {
    event->emitEvent();
    delete event;
}
