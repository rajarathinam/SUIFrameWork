//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ExternalEventHandlerImpl.
// !\description Header file for class SUI::ExternalEventHandlerImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|
#ifndef SUIEXTERNALEVENTHANDLERIMPL_H
#define SUIEXTERNALEVENTHANDLERIMPL_H

#include <QObject>

namespace SUI {

class AbstractExternalEvent;

class ExternalEventHandlerImpl : public QObject
{
    Q_OBJECT
public:
    explicit ExternalEventHandlerImpl(QObject *parent = NULL);
    virtual ~ExternalEventHandlerImpl();

public slots:
    void emitEvent(SUI::AbstractExternalEvent *event);
};
} // namespace SUI
#endif // SUIEXTERNALEVENTHANDLERIMPL_H
