//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::TimeImpl.
// !\description Header file for class SUI::TimeImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUITIMEIMPL_H
#define SUITIMEIMPL_H

#include "FWQxUtils/SUITime.h"
#include <QTime>

#include <boost/shared_ptr.hpp>

namespace SUI {

class TimeImpl : public QTime, public Time
{

private:
    TimeImpl();
    //TimeImpl(int h, int m, int s = 0, int ms = 0);

    friend class Time;

public:
    virtual void addMSecs(int ms);
    virtual void addSecs(int s);
    virtual int getElapsed() const;
    virtual int getHour() const;
    virtual bool isNull() const;
    virtual bool isValid() const;
    virtual int getMinute() const;
    virtual int getMsec() const;
//    virtual int msecsTo(const Time &t) const;
    virtual int restart();
    virtual int getSecond() const;
//    virtual int secsTo(const Time &t) const;
    virtual bool setHMS(int h, int m, int s, int ms = 0);
    virtual void start();
    virtual std::string toString(const std::string &format) const;
    virtual std::string toString(DateTimeEnum::DateFormat format = DateTimeEnum::TextDate) const;

    virtual bool operator!=(const boost::shared_ptr<Time> &d) const;
    virtual bool operator<(const boost::shared_ptr<Time> &d) const;
    virtual bool operator<=(const boost::shared_ptr<Time> &d) const;
    virtual bool operator==(const boost::shared_ptr<Time> &d) const;
    virtual bool operator>(const boost::shared_ptr<Time> &d) const;
    virtual bool operator>=(const boost::shared_ptr<Time> &d) const;

};

} // namespace SUI

#endif // SUI_SUITIMEIMPL_H
