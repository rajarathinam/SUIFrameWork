//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief
// !\description
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIQUILOADER_H
#define SUIQUILOADER_H

#include <QMap>

class QWidget;

class TabOrder
{
public:
    QMap<QWidget *, int> getTabOrder() const;
    void addTabOrder(const int order, QWidget *widget);
    QMap<QWidget *, int> getTabs() const;
    void setTabs(QWidget *widget, const int order);

    void clear();

private:
    QMap<QWidget *, int> tabOrder;
    QMap<QWidget *, int> tabs;
};

#include "SUIObjectPropertyStorageImpl.h"
#include "SUIGUIDefinitionVisitor.h"
#include "FWQxCore/SUIObjectFactory.h"
#include "SUIBaseWidget.h"
#include "FWQxCore/SUIObjectList.h"

namespace SUI {
class DialogImpl;
}

class GUIViewerWidgetController: public QObject, public GUIDefinitionVisitor, public SUI::ObjectPropertyStorageImpl
{
    Q_OBJECT
public:
    GUIViewerWidgetController();
    virtual ~GUIViewerWidgetController();

    virtual void writeWidgetProperty(SUI::ObjectPropertyTypeEnum::Type key, const QString &value);
    virtual void writeInclude(const QString &include, const QString &fileName);

    virtual GUIDefinitionVisitor &openChildWidget();
    virtual void closeChildWidget();

    SUI::BaseWidget *addToWidget(QWidget *parent, SUI::ObjectList &widgetList, TabOrder &tabOrder,
                                QList<GUIViewerWidgetController *> *uctrlList, const QString &uctrlID);


    void addUserControl(GUIViewerWidgetController *usercontrol);
    QList<GUIViewerWidgetController *> getUserControls();
    QList<GUIViewerWidgetController *> getUserChildren();

private:
    virtual SUI::ObjectProperty *getProperty(SUI::ObjectPropertyTypeEnum::Type /*propertyID*/) const { return NULL; }

    void addTreeChild(GUIViewerWidgetController *childWidget, SUI::BaseWidget *pDragAndDropWidget);

    SUI::BaseWidget *mWidget;
    QList<GUIViewerWidgetController *> mUserControls;
    QList<GUIViewerWidgetController *> mChildren;

signals:
    void shot();
};

namespace SUI {
class QUiLoader
{
public:
    static QWidget* loadQUi(const QString uiFilename, SUI::ObjectList &objectList, TabOrder &tabOrder);

private:
    static GUIViewerWidgetController* readInclude(const QString &filename);
};
}

#endif // UILOADER_H
