//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::DoubleSpinBoxImpl.
// !\description Header file for class SUI::DoubleSpinBoxImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIDOUBLESPINBOXIMPL_H
#define SUIDOUBLESPINBOXIMPL_H

#include "FWQxWidgets/SUIDoubleSpinBox.h"

#include "SUIBaseWidget.h"

#include "CustomDoubleSpinBox.h"

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The DoubleSpinBox class
 */
class DoubleSpinBoxImpl : public BaseWidget, public DoubleSpinBox
{
    Q_OBJECT
public:
    explicit DoubleSpinBoxImpl(QWidget *parent = NULL);

    virtual void setDefaultProperties(const ObjectContext &context);
    virtual CustomDoubleSpinBox *getWidget() const;
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);
    virtual QString getPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID) const;

    void setBold(bool bold);

    virtual void setMode(ErrorModeEnum::ErrorMode mode);

    virtual void setValue(const double val);
    virtual double getValue() const;
    virtual void setMinValue(const double val);
    virtual double getMinValue() const;
    virtual void setMaxValue(const double val);
    virtual double getMaxValue() const;
    virtual void setStepSize(const double val);
    virtual double getStepSize() const;
    virtual void setStepSizeValueToFactor(const bool on);
    virtual void setPrecision(const int val);
    virtual int getPrecision() const;
    virtual void setAlignment(AlignmentEnum::Alignment align);
    virtual AlignmentEnum::Alignment getAlignment() const;

private slots:
    void handleValueChanged();

private:
    DoubleSpinBoxImpl(const DoubleSpinBoxImpl &rhs);
    DoubleSpinBoxImpl &operator = (const DoubleSpinBoxImpl &rhs);
};
}

#endif // SUIDOUBLESPINBOXIMPL_H
