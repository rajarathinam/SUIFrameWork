//-----------------------------------------------------------------------------|
//                                                                             |
//                            C++ Header File                                  |
//                                                                             |
//-----------------------------------------------------------------------------|
//
// Ident        : SUIWebViewImpl.h
// Author       : Patrick van Tongeren
// Description  : Header file for class SUI::SUIWebViewImpl.
//
// ! \file        SUIWebViewImpl.h
// ! \brief       Header file for class SUI::SUIWebViewImpl.
//
//-----------------------------------------------------------------------------|
//                                                                             |
//        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
//                           All rights reserved                               |
//                                                                             |
//-----------------------------------------------------------------------------|

#ifndef SUIWEBVIEWIMPL_H
#define SUIWEBVIEWIMPL_H

#include "SUIBaseWidget.h"
#include "FWQxWidgets/SUIWebView.h"

#include <QtWebKit/QWebView>

namespace SUI
{

class WebViewImpl : public BaseWidget, public WebView
{
    Q_OBJECT

public:
    explicit WebViewImpl(QWidget *parent = NULL);
    virtual ~WebViewImpl();

    virtual void setUrl(const std::string &url);
    virtual std::string getUrl() const;
    virtual void setHtml(const std::string &html);
    virtual void setHtml(const std::string &html, const std::string &baseUrl);
    virtual std::string getHtml() const;
    virtual void setZoomFactor(const double factor);
    virtual double getZoomFactor() const;

    virtual QWebView *getWidget() const;
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);
    virtual void setDefaultProperties(const ObjectContext &context);
 
private slots:
    void onLoadFinished(bool success);

private:
    WebViewImpl();
    WebViewImpl(const WebViewImpl &rhs);
    WebViewImpl &operator=(const WebViewImpl &rhs);
};


}

#endif // SUIWEBVIEWIMPL_H
