//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ImageWidgetImpl.
// !\description Header file for class SUI::ImageWidgetImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIIMAGEWIDGETIMPL_H
#define SUIIMAGEWIDGETIMPL_H

#include <QImage>
#include <QLabel>

#include "SUIBaseWidget.h"
#include "FWQxWidgets/SUIImageWidget.h"

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The Image class
 */
class ImageWidgetImpl : public BaseWidget, public ImageWidget
{
public:
    explicit ImageWidgetImpl(QWidget *parent = NULL);

    virtual QLabel *getWidget() const;

    virtual void setDefaultProperties(const ObjectContext &context);
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

    virtual void setImage(const std::string &fileName);
    virtual void setImage(unsigned char *data , int width, int height, ImageEnum::Format format);

protected:
    virtual void setGeometry();

private:
    ImageWidgetImpl(const ImageWidgetImpl &rhs);
    ImageWidgetImpl &operator=(const ImageWidgetImpl &rhs);
};
}

#endif // SUIIMAGEWIDGETIMPL_H
