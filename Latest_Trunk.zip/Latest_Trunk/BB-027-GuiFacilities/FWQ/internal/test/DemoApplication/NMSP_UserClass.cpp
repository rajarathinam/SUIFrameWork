//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source File                                |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author FBE Auto generated
// !\brief Demo Application
// !\description GUIFramework Demo Application
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2017, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

//----------------------------------------------------------------------------|
//                                 Includes                                   |
//----------------------------------------------------------------------------|
#include "NMSP_UserClass.hpp"
#include "NMSP_MOC_UserClass.hpp"

//----------------------------------------------------------------------------|
//                             Class definition                               |
//----------------------------------------------------------------------------|
NMSP::UserClass::UserClass() :
    sui(new MOC::UserClass)
{
    sui->setupSUI("NMSP_UserClass.xml");
}

NMSP::UserClass::~UserClass()
{
    delete sui;
}

SUI::Button *NMSP::UserClass::getStartButton() {
    return sui->startButton;
}

SUI::Button *NMSP::UserClass::getStopButton() {
    return sui->stopButton;
}

SUI::Label *NMSP::UserClass::getTimeLabel() {
    return sui->timeLabel;
}

SUI::ProgressBar *NMSP::UserClass::getProgressBar() {
    return sui->progressBar;
}

SUI::Dialog *NMSP::UserClass::getDialog() {
    return sui->dialog;
}
