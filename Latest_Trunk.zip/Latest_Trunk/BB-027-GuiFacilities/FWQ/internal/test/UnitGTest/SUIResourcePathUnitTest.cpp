
#include <gtest.h>
#include <FWQxCore/SUIResourcePath.h>
#include "FWQxCore/SUIArgumentException.h"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class SUIResourcePathUnitTest : public ::testing::Test
{
 public:
    SUIResourcePathUnitTest(): ResPath(*SUI::ResourcePath::getInstance()){}
    virtual ~SUIResourcePathUnitTest(){}

protected:
     SUI::ResourcePath ResPath;

};

TEST_F(SUIResourcePathUnitTest, VerifySetResourcePath)
{
    std::string path = "//home/adt";
    ResPath.setResourcePath(path);
    EXPECT_STREQ(path.c_str(), ResPath.getResourcePath().c_str());
}

TEST_F(SUIResourcePathUnitTest, CheckSetResourcePathThrowsExceptionIfPathIsInvalid)
{
    std::string file = "//home/hhh"; //Here we can write different test cases for validation of path.
    try
    {
          ResPath.setResourcePath(file);
          FAIL() << "Argument path is invalid";
    }
    catch(SUI::ArgumentException* err)
    {
          EXPECT_EQ(err->what(),std::string("Argument path is invalid"));
    }
    catch(...)
    {
         FAIL() << "Expected Argument path is invalid";
    }
}
