//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for Presenter.
// !\description Class implementation file for Presenter
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "MVP_Presenter.hpp"
#include "MVP_Model.hpp"

MVP::Presenter::Presenter(IMainView *view) :
    m_view(view),
    m_model(new MVP::Model)
{

}

MVP::Presenter::~Presenter() {
    delete m_model;
    m_model = NULL;
}

void MVP::Presenter::onLogin(const std::string &userName, const std::string &password) {
    bool loginResult = m_model->login(userName, password);
    m_view->showMessage(loginResult);
}
