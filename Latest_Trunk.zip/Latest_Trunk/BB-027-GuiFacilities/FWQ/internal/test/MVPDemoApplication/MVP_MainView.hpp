//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Header File                                |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author FBE Auto generated
// !\brief Brief description here
// !\description Description
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2017, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|
#ifndef MVP_MAINVIEW_HPP
#define MVP_MAINVIEW_HPP

//----------------------------------------------------------------------------|
//                                 Forward declaration                        |
//----------------------------------------------------------------------------|
#include "MVP_IMainView.hpp"
#include "MVP_Presenter.hpp"
#include <boost/thread.hpp>

namespace MVP {
namespace MOC {
    class MainView;
} //namespace MOC
//----------------------------------------------------------------------------|
//                                 Class declaration                          |
//----------------------------------------------------------------------------|
class MainView : public IMainView
{

public:
    MainView();
    virtual ~MainView();
    virtual void showMessage(const bool &result);
    void onLoginClicked();
    void onStartClockClicked();
    void show();
    void fireEvents();
    void handleCloseApplication();
    void handleMessageBoxClicked();

private:
    std::string getUser() const;
    std::string getPassword() const ;

    MOC::MainView *sui;
    MVP::Presenter *m_presenter;
    boost::thread *m_thread;
    bool m_startThread;
    boost::function<void(const std::string &)> labelFunction;
};
} //namespace MVP
#endif // MVP_MAINVIEW_HPP
