//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class Presenter.
// !\description Header file for class Presenter.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef MVPPRESENTER_HPP
#define MVPPRESENTER_HPP

#include "MVP_IMainView.hpp"
#include "MVP_Model.hpp"
namespace MVP {
class Presenter
{
public:
    explicit Presenter(MVP::IMainView *view);
    ~Presenter();

    void onLogin(const std::string &userName ,const  std::string &password);
private:
    Presenter(const Presenter &presenter);
    Presenter& operator=(const Presenter &presenter);
    MVP::IMainView *m_view;
    MVP::Model *m_model;
};
} //namespace MVP
#endif // MVPPRESENTER_HPP
