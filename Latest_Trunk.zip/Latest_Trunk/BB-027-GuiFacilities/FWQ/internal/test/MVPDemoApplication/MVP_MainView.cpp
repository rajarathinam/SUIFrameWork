//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source File                                |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author FBE Auto generated
// !\brief Brief description here
// !\description Description
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2017, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

//----------------------------------------------------------------------------|
//                                 Includes                                   |
//----------------------------------------------------------------------------|
#include "MVP_MainView.hpp"
#include "MVP_MOC_MainView.hpp"

#include <FWQxWidgets/SUILineEdit.h>
#include <FWQxWidgets/SUIMessageBox.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUIDialog.h>
#include <FWQxUtils/SUIDateTime.h>
#include <FWQxUtils/SUITime.h>
#include <FWQxWidgets/SUILabel.h>
#include <FWQxCore/SUIExternalEvent.h>
#include <FWQxCore/SUIExternalEventHandler.h>

#include <boost/bind.hpp>
#include <boost/thread.hpp>


const std::string LOGIN_SUCCESS = "Login Success";
const std::string LOGIN_FAIL = "Login Failed";
const std::string MSGBOX_OK = "OK";
const std::string MSGBOX_CANCEL = "Cancel";
const std::string MSGBOX_TITLE = "Close Application";
const std::string UI_FILE = "MVP_MainView.xml";
//----------------------------------------------------------------------------|
//                             Class definition                               |
//----------------------------------------------------------------------------|
MVP::MainView::MainView() :
    sui(new MOC::MainView),
    m_thread(NULL),
    m_startThread(false),
    labelFunction()
{
    m_presenter = new MVP::Presenter(this);
    sui->setupSUI(UI_FILE.c_str());
    sui->btnlogin->clicked = boost::bind(&MainView::onLoginClicked, this);
    sui->btnStartClock->clicked = boost::bind(&MainView::onStartClockClicked, this);
    sui->dialog->setCloseable(false);
    sui->dialog->aboutToClose = boost::bind(&MainView::handleCloseApplication, this);
    labelFunction = boost::bind(&SUI::Label::setText, sui->lblShowClock, _1);
}

MVP::MainView::~MainView()
{
    if (m_thread != NULL) {
        delete m_thread;
        m_thread = NULL;
    }
    delete m_presenter;
    m_presenter = NULL;
    delete sui;
    sui = NULL;
}

std::string MVP::MainView::getUser() const
{
    return sui->lneUsername->getText();
}

std::string MVP::MainView::getPassword() const
{
    return sui->lnePassword->getText();
}


void MVP::MainView::showMessage(const bool &result)
{
    std::string message = result ? LOGIN_SUCCESS : LOGIN_FAIL;
    sui->msgBox->setText(message);
    sui->msgBox->show();
}

void MVP::MainView::onLoginClicked()
{
    m_presenter->onLogin(getUser(), getPassword());
}

void MVP::MainView::onStartClockClicked()
{
    if (m_thread == NULL) {
        m_thread = new boost::thread(&MainView::fireEvents, this);
        m_startThread = true;
    }
}

void MVP::MainView::show()
{
    sui->dialog->show();
}

void MVP::MainView::fireEvents()
{
    while (m_startThread) {
        boost::shared_ptr<SUI::Time> time= SUI::Time::createTime();
        SUI::ExternalEvent<std::string> *event = new SUI::ExternalEvent<std::string>(labelFunction, time->toString());
        SUI::ExternalEventHandler::raiseEvent(event);
        boost::this_thread::sleep(boost::posix_time::milliseconds(500));
    }
}

void MVP::MainView::handleCloseApplication() {
    if (sui->msgBox) {
        sui->msgBox->clicked = boost::bind(&MainView::handleMessageBoxClicked,this);
        sui->msgBox->setIcon(SUI::MessageBoxIconEnum::Warning);
        sui->msgBox->setText(MSGBOX_TITLE);
        std::list<std::string> btnText;
        btnText.push_back(MSGBOX_OK);
        btnText.push_back(MSGBOX_CANCEL);
        sui->msgBox->setButtonText(btnText);
        sui->msgBox->show();
    }
}

void MVP::MainView::handleMessageBoxClicked() {
    if (sui->msgBox->handleButtonRetour() == MSGBOX_OK) {
        m_startThread = false;
        if (m_thread != NULL) {
            m_thread->join();
        }
        sui->dialog->setCloseable(true);
        sui->dialog->quit();
    }
}


