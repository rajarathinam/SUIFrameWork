//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class MainView.
// !\description Header file for class MainView.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef MVP_APPLICATION_HPP
#define MVP_APPLICATION_HPP

#include <FWQxCore/SUIApplication.h>
namespace MVP {
class MainView;

class Application {
public:
    explicit Application(int argc, char *argv[], const std::string &resourcepath);
    ~Application();

    int exec();
private:
    boost::shared_ptr<SUI::Application> m_app;
    int m_argc;
    char** m_argv;
    std::string m_resourcepath;
    MainView *m_mainview;

};
}
#endif // MVP_APPLICATION_HPP
