//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Implementation file for main.
// !\description Implementation file for main.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|
#include <iostream>
#include "MVP_Application.hpp"

const std::string STRING_RESOURCE = "/Resource/";
int main(int argc, char *argv[]) {

    // instantiate the application
    char* currentDir = get_current_dir_name();
    boost::shared_ptr<MVP::Application> app (new MVP::Application(argc,argv, currentDir + STRING_RESOURCE));


    //execute the application (main eventloop)
    int result = app->exec();
    app.reset();
    delete currentDir;

    return result;
}

