//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class Model.
// !\description Header file for class Model.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef MVPMODEL_HPP
#define MVPMODEL_HPP

#include <map>
#include <list>
#include <string>

namespace MVP {
class Model
{
private:
    std::map<std::string, std::string> usersAndPasswords;
public:
    Model();
    bool login(const std::string &user, const std::string &password);
};

} //namespace MVP
#endif // MVPMODEL_HPP
