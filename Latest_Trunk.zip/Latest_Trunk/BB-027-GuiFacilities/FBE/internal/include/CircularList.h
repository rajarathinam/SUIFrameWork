//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class CircularList.
// !\description Header file for class CircularList.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef CIRCULARLIST_H
#define CIRCULARLIST_H

#include <QObject>
#include <QList>

class WidgetDefinition;

enum UNDO_ACTION { ACT_NONE, ACT_NEW, ACT_DELETE, ACT_MOVE, ACT_PROPERTY, ACT_COMPLEX, ACT_UCTRL, ACT_SPLITUCTRL };

typedef struct WIDGETSTATE
{
    WIDGETSTATE() : sAction(ACT_NONE), sIsSaved(false), sPrevState(NULL), sNewState(NULL)   {}
    QString                 sActionText;
    UNDO_ACTION             sAction;
    bool                    sIsSaved;
    WidgetDefinition    *sPrevState;    //   = NULL;
    WidgetDefinition    *sNewState;     //   = NULL;
    QString                 sOldParentID;
    QString                 sNewparentID;
} WidgetState;

class UndoInfo
{
public:
    UndoInfo() : sAction(ACT_NONE)        {}
    UNDO_ACTION             sAction;
    QList<WidgetState *>    sStateList;
};


class CircularList : public QObject
{
    Q_OBJECT

public:
    CircularList();
    virtual ~CircularList();

    void                Init(int size);
    void                enqueue(const UndoInfo *undoinf);
    const UndoInfo      *prev();
    const UndoInfo      *next();
    void                clear();
    void                setCurrentSaved();
    QList<WidgetState *> printBuffer() const;

private:
    int                     mQueueSize;
    int                     mCurrentPoint;
    int                     mInQueue;
    QList<UndoInfo *>       mData;
    static const QString    mEmptyString;

signals:
    void        doDelete(UndoInfo *);
    void        doEnableUndo(bool);
    void        doEnableRedo(bool);
    void        sendUndoRedoText(const QString &, const QString &);
};

#endif  // CIRCULARLIST_H
