 # -*- coding: utf-8 -*-

"""
Aim of the script  : Verify if the orientation of the Progress Bar can be set in the editor
Reference document : TAR-TPS-001-TPS_ADT_FBE_ITV_FWQ_Sprint 45
Test case ID       : TC210
"""

import general


def main():
    try:
        # Step 1:Start the FBE application
        general.launch_application('FBE', write_result=True)

        # Step 2:Place a ProgressBar widget on the form.
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_ProgressBar',
                                    widget_name='ProgressBar Widget',
                                    target_name='Editor Form')
        # Step 3 & 4:Verify if the Progress Bar has a property Percentage.Change the property Percentage
        #  and verify if the percentage is shown
        general.update_property_value_in_editor(widget_name='ProgressBar', property_name='Percentage',
                                    value_to_be_set='false', write_result=True)
        
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='ProgressBar', widget_id='pgb29', expected_prop_value={'Percentage':'false'},
                    write_result=True)
        #Step 5:Place a Progress Bar on the form
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_ProgressBar',
                                    widget_name='ProgressBar Widget',
                                    target_name='Editor Form',target_x_coord=350,
                                    target_y_coord=350)
        
        #Step 6:Change the property Percentage to True and verify if the percentage is shown
        general.update_property_value_in_editor(widget_name='ProgressBar', property_name='Percentage',
                                    value_to_be_set='true', write_result=True)
        
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='ProgressBar', widget_id='pgb30', expected_prop_value={'Percentage':'true'},
                    write_result=True)
        
        # Step 7:Save the file as test_Percentage.xml and Close application FBE
        general.quit_application(app_name='FBE', file_name='test_Percentage.xml',
                directory_path='/home/adt/ADT/ASML-ADT/Trunk/targets/bin/')

               
    except Exception as runtime_args:
        raise Exception(str(runtime_args.message))
