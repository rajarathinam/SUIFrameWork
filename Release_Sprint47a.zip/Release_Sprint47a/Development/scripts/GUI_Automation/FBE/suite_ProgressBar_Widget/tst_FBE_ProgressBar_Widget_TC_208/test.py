 # -*- coding: utf-8 -*-

"""
Aim of the script  : Verify if the orientation of the Progress Bar can be set in the editor
Reference document : TAR-TPS-001-TPS_ADT_FBE_ITV_FWQ_Sprint 45
Test case ID       : TC208
"""

import general


def main():
    try:
        # Step 1:Start the FBE application
        general.launch_application('FBE', write_result=True)

        # Step 2:Place a ProgressBar widget on the form. Set Checked to true
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_ProgressBar',
                                    widget_name='ProgressBar Widget',
                                    target_name='Editor Form')
        # Step 3 & 4:Verify if the Progress Bar has a property Orientation.Change the property Orientation to Vertical
        #  and verify if the Progress Bar is filled vertically
        general.update_property_value_in_editor(widget_name='ProgressBar', property_name='Orientation',
                                    value_to_be_set='Vertical', write_result=True)
        
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='ProgressBar', widget_id='pgb29', expected_prop_value={'Orientation':'Vertical'},
                    write_result=True)
        
        #Step 5:Verify if the visual orientation of the Progress Bar can be changed by setting the height to 200 and the width to 30
        general.update_property_value_in_editor(widget_name='ProgressBar', property_name='Height',
                                    value_to_be_set='200', write_result=True)
        
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='ProgressBar', widget_id='pgb29', expected_prop_value={'Height':'200'},
                    write_result=True)
        

        general.update_property_value_in_editor(widget_name='ProgressBar', property_name='Width',
                                    value_to_be_set='30', write_result=True)
        
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='ProgressBar', widget_id='pgb29', expected_prop_value={'Width':'30'},
                    write_result=True)

        # Close application FBE
        general.quit_application(app_name='FBE', file_name='',
                directory_path='/home/adt/ADT/ASML-ADT/Trunk/targets/bin/')

               
    except Exception as runtime_args:
        raise Exception(str(runtime_args.message))
