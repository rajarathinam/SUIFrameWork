"""
Aim of the Script     : Verify if images can be added to a button widget in
                        the editor.
Reference Document    : TAR-TPS-001-TPS_ADT_FBE_ITV_FWQ_Sprint 47
Test case ID          : TC97
"""
import general
import qt_convenient_squish_apis
APP_NAME = "FBE"


def main():
    try:
        # Step 1:Start the FBE application
        general.launch_application('FBE', write_result=True)
        # Step 2:Place a Button widget on the form. Set Checked to true
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_Button',
                                    widget_name='Button',
                                    target_name='Editor Form')

        general.update_property_value_in_editor(widget_name='Button',
                                    property_name='Bold',
                                    value_to_be_set='true', write_result=True)
        general.verify_properties_in_preview(tab_obj_id='tbp2',
                    widget_name='Button', widget_id='btn29',
                    expected_prop_value={'Bold': 'true'},
                    write_result=True)
        general.update_property_value_in_editor(widget_name='Button',
                                    property_name='Text',
                                    value_to_be_set='Button123',
                                    write_result=True)
        general.verify_properties_in_preview(tab_obj_id='tbp2',
                    widget_name='Button', widget_id='btn29',
                    expected_prop_value={'Text': 'Button123'},
                    write_result=True)
        general.update_property_value_in_editor(widget_name='Button',
                                    property_name='ImageData',
                                    value_to_be_set='Select File',
                                    write_result=True)
        images_directoty_path = general.get_path("images")
        general.select_file("GraphicsViewBackGnd.jpg",
                                      images_directoty_path)
        general.verify_with_vp(
        "FormEditor_CustomPushButton_ImageData_With_GraphicsViewBackGnd",
        write_result=True)
        general.go_to_preview_screen("tbp2")
        general.verify_with_vp(
        "Preview_CustomPushButton_ImageData_With_GraphicsViewBackGnd",
        write_result=True)
        general.close_preview()
        # Step 2:Place a Button widget on the form. Set Checked to true
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_Button',
                                    widget_name='Button',
                                    target_name='Editor Form',
                                    target_x_coord=350,
                                    target_y_coord=350)
        general.update_property_value_in_editor(widget_name='Button',
                                    property_name='ImageDataPressed',
                                    value_to_be_set='Select File',
                                    write_result=True)
        general.select_file("GraphicsViewBackGnd.jpg",
                                      images_directoty_path)
        general.verify_with_vp(
        "FormEditor_CustomPushButton2_ImageDataPressed_With_GraphicsViewBackGnd",
        write_result=True)

        general.go_to_preview_screen("tbp2")
        general.verify_with_vp(
        "Preview_CustomPushButton2_ImageDataPressed_WithoutImage",
        write_result=True)
        pushbutton_children = general.get_children_of_type(
                                    "FBE_PreviewWindow_Container_AllWidgets",
                                    "CustomPushButton")
        for pushbutton_child in pushbutton_children:
            if str(pushbutton_child.objectName) == "btn30":
                # mouse press on the middle of the objectOrName
                # object
                qt_convenient_squish_apis.mouse_click(pushbutton_child)
                break
        general.verify_with_vp(
        "Preview_CustomPushButton2_ImageDataPressed_With_GraphicsViewBackGnd",
        write_result=True)
        general.close_preview()
        # Step 6:Save the file as test_Checked.xml
        general.save_file_in_editor(file_name='test_Button_width.xml')
        # Step 7:Close and re-launch FBE
        general.quit_application(app_name='FBE', file_name='')
        general.launch_application('FBE', write_result=True)
        # Step 8:Open the file test_Checked.xml and preview
        general.open_file_in_editor(file_name='test_Button_width.xml')
        general.go_to_preview_screen("tbp2")
        general.verify_with_vp(
        "Preview_CustomPushButton_ImageData_With_GraphicsViewBackGnd",
        write_result=True)
        general.verify_with_vp(
        "Preview_CustomPushButton2_ImageDataPressed_With_GraphicsViewBackGnd",
        write_result=True)
        general.close_preview()
        _post_condition()
    except Exception as runtime_args:
        raise Exception(str(runtime_args.message))


def _post_condition():
    general.quit_application(APP_NAME)

#===========================Revision History===================================
#Modifier       Modified On                 Modification Reason
#Girish Nair    29/07/2017                  Applied new coding standards
#==============================================================================
