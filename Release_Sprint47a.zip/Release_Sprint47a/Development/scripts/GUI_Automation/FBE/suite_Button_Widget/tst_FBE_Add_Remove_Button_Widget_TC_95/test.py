"""
Aim of the Script     : Verify if the Button widget can be added to and removed
                        from the form.
Reference Document    : TAR-TPS-001-TPS_ADT_FBE_ITV_FWQ_Sprint 43
Test case ID          : TC95
"""
import general
APP_NAME = "FBE"


def main():
    try:
        # Step 1:Start the FBE application
        general.launch_application('FBE', write_result=True)

        # Step 2:Verify if TextArea widget is displayed in widget selector list
        general.verify_widget_in_widgets_selector(
                                    'FBE_MainWindow_WidgetIcon_Button',
                                    "Button", 2)

        # Step 3:Verify if TextArea widget can be added to editor form by
        # dragging and dropping
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_Button',
                                    widget_name='Button',
                                    target_name='Editor Form')
        general.verify_properties_in_preview(tab_obj_id='tbp2',
                                widget_name='Button', widget_id='btn29',
                                expected_prop_value={}, write_result=True)

        # Step 4:Verify exposed properties
        data_set = testData.dataset(general.get_path("testdata") +
                            "/FBE_Add_Remove_Button_Widget_TC_95.tsv")
        expected_properties = []
        for row in data_set:
            expected_properties.append(testData.field(row,
                                                      'Expected_Properties'))
        general.verify_properties_in_editor(expected_properties)

        # Step 5:Verify if TextArea widget can be removed from editor by dragging
        # and dropping it back in widget selector panel
        editor_child = general.get_children_of_type(
                                    'FBE_MainWindow_SubContainer_EditorForm',
                                    'WidgetController', 1)[0]
        widget_to_drag = general.get_children_of_type(editor_child,
                                                      'WidgetController')[0]
        general.verify_widget_drag_and_drop(widget_to_drag,
                            'FBE_MainWindow_WidgetsDisplayWindowWithScroll',
                            widget_name='Button', target_name='Widget Selector')

        # Step 6:Verify if TextArea widget can be added to editor form by
        # dragging and dropping
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_Button',
                                    widget_name='Button',
                                    target_name='Editor Form')

        editor_child = general.get_children_of_type(
                                    'FBE_MainWindow_SubContainer_EditorForm',
                                    'WidgetController', 1)[0]
        widget_to_delete = general.get_children_of_type(editor_child,
                                                      'WidgetController')[0]

        #Step 7:Verify if TextArea widget can be removed from editor by pressing
        general.verify_widget_deletion(widget_to_delete, 'Button')

    except Exception as runtime_args:
        raise Exception(str(runtime_args.message))


def _post_condition():
    # quit the FBE application
    general.quit_application(APP_NAME)
#===========================Revision History===================================
#Modifier       Modified On                 Modification Reason
#Girish Nair    14/07/2017                  Applied new coding standards
#Girish Nair    17/08/2017                  Applied new framework methods
#==============================================================================
