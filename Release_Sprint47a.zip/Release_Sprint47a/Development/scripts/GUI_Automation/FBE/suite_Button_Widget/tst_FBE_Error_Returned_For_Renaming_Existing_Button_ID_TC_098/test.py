"""
Aim of the Script     : Verify if the error message returns the correct widget
                        name.
Reference Document    : TAR-TPS-001-TPS_ADT_FBE_ITV_FWQ_Sprint 47
Test case ID          : TC98
"""
import general
import logger
APP_NAME = "FBE"


def main():
    try:
        # Step 1:Start the FBE application
        general.launch_application('FBE', write_result=True)
        # Step 2:Place a Button widget on the form. Set Checked to true
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_Button',
                                    widget_name='Button',
                                    target_name='Editor Form')
        general.verify_properties_in_preview(tab_obj_id='tbp2',
                                widget_name='Button', widget_id='btn29',
                                expected_prop_value={}, write_result=True)
        # Step 5:Place another Button widget on the form. Set Checked to false
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_Button',
                                    widget_name='Button',
                                    target_name='Editor Form',
                                    target_x_coord=350,
                                    target_y_coord=350)
        general.verify_properties_in_preview(tab_obj_id='tbp2',
                                widget_name='Button', widget_id='btn30',
                                expected_prop_value={}, write_result=True)
        try:
            general.update_property_value_in_editor(widget_name='Button',
                                    property_name='ID',
                                    value_to_be_set='btn29')
        except Exception as runtime_args:
            if "value could not be set to 'btn29'" in runtime_args.message:
                logger.write_to_result("Pass",
                                """Renaming 2nd button ID same as 1st Button ID
                                and verify if an error message is shown""",
                                "An error message is shown",
                                "An error message is shown")
            else:
                logger.write_to_result("Fail",
                                """Renaming 2nd button ID same as 1st Button ID
                                and verify if an error message is shown""",
                                "An error message is shown",
                                "An error message is not shown")
        _post_condition()
    except Exception as runtime_args:
        raise Exception(str(runtime_args.message))


def _post_condition():
    general.quit_application(APP_NAME)

#===========================Revision History===================================
#Modifier       Modified On                 Modification Reason
#Girish Nair    29/07/2017                  Applied new coding standards
#==============================================================================
