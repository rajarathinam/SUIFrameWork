 # -*- coding: utf-8 -*-

"""
Aim of the script  : IT SHOULD BE POSSIBLE TO SET THE BACKGROUND COLOR OF A
                        GROUPBOX.
Reference document : TAR-TPS-001-TPS_ADT_FBE_ITV_FWQ_Sprint 44
Test case ID       : TC108
"""

import general


def main():
    try:
        # Step 1:Start the FBE application
        general.launch_application('FBE', write_result=True)

        # Step 2:Drag and drop a Groupbox widget in form
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_CheckGroupBox',
                                    widget_name='CheckGroupBox Widget',
                                    target_name='Editor Form')

        # Step 3:Change the groupbox property  BGcolor to red 
        general.update_property_value_in_editor(widget_name='CheckGroupBox', property_name='BGColor',
                                    value_to_be_set='red', write_result=True)
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='CheckGroupBox', widget_id='cgb29', expected_prop_value={'BGColor':'red'},
                    write_result=True)
        
        # Step 4:Take another Group box and set the BGcolor to green
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_CheckGroupBox',
                                    widget_name='CheckGroupBox Widget',
                                    target_name='Editor Form',
                                    target_x_coord=350,
                                    target_y_coord=350)
         
        general.update_property_value_in_editor(widget_name='CheckGroupBox', property_name='BGColor',
                                    value_to_be_set='green', write_result=True)
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='CheckGroupBox', widget_id='cgb30', expected_prop_value={'BGColor':'green'},
                    write_result=True)
        
        # Step 5:Save the file testGbx_BGcolor.xml
        general.save_file_in_editor(file_name='testGbx_BGcolor.xml',
              directory_path='/home/adt/ADT/ASML-ADT/Trunk/targets/bin/')
        # Step 6:Close and relaunch FBE
        general.quit_application(app_name='FBE', file_name='',
                directory_path='/home/adt/ADT/ASML-ADT/Trunk/targets/bin/')
        general.launch_application('FBE', write_result=True)
        
        # Step 7:Open the file testGbx_BGcolor.xml and preview
        general.open_file_in_editor(file_name='testGbx_BGcolor.xml',
              directory_path='/home/adt/ADT/ASML-ADT/Trunk/targets/bin/')
        
        general.select_item_in_widget_tree_view('cgb30')
        # Step 8:Change the color in to different color the red or green
        general.update_property_value_in_editor(widget_name='CheckGroupBox', property_name='BGColor',
                                    value_to_be_set='blue', write_result=True)
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='CheckGroupBox', widget_id='cgb30', expected_prop_value={'BGColor':'blue'},
                    write_result=True)       
    except Exception as runtime_args:
        raise Exception(str(runtime_args.message))
