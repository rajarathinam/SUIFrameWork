# -*- coding: utf-8 -*-

"""
Aim of the script  : To verify if the SpinBox widget can be added to and
                     removed from the form
Reference document : TAR-TPS-001-TPS_ADT_FBE_ITV_FWQ_Sprint 44
Test case ID       : TC0125
"""

import general


def main():
    try:
        # Step 1:Start the FBE application
        general.launch_application('FBE', write_result=True)

        # Step 2:Verify is the SpinBox Widget is shown in the Widget Selector
        # of the editor
        general.verify_widget_in_widgets_selector(
                                    'FBE_MainWindow_WidgetIcon_SpinBox',
                                    "SpinBox Widget", 2)

        # Step 3:Verify if the SpinBox widget can be added to the form by
        # dragging it onto the form
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_SpinBox',
                                    widget_name='SpinBox Widget',
                                    target_name='Editor Form')
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='SpinBox', widget_id='isb29', expected_prop_value={ },
                    write_result=True)

        # Step 4:Verify exposed properties
        data_set = testData.dataset(general.get_path("testdata") +
                            "/FBE_SpinBox_Widget_TC_115.tsv")
        expected_properties = []
        for row in data_set:
            expected_properties.append(testData.field(row,
                                                      'Expected_Properties'))
        general.verify_properties_in_editor(expected_properties)

        # Step 5:Verify if the SpinBox widget can be removed from the form by
        # dragging and dropping it to the widget selector
        editor_child = general.get_children_of_type(
                                    'FBE_MainWindow_SubContainer_EditorForm',
                                    'WidgetController', 1)[0]
        widget_to_drag = general.get_children_of_type(editor_child,
                                                      'WidgetController')[0]
        general.verify_widget_drag_and_drop(widget_to_drag,
                            'FBE_MainWindow_WidgetsDisplayWindowWithScroll',
                            widget_name='SpinBox Widget', target_name='Widget Selector')

        # Step 6:Verify if the SpinBox widget can be added to the form by
        # dragging it onto the form
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_SpinBox',
                                    widget_name='SpinBox Widget',
                                    target_name='Editor Form')

        editor_child = general.get_children_of_type(
                                    'FBE_MainWindow_SubContainer_EditorForm',
                                    'WidgetController', 1)[0]
        widget_to_delete = general.get_children_of_type(editor_child,
                                                      'WidgetController')[0]

        #Step 7:Verify if the SpinBox widget can be removed from the form by
        # selecting the widget and pressing the Delete key on the keyboard
        general.verify_widget_deletion(widget_to_delete, 'SpinBox Widget')

    except Exception as runtime_args:
        raise Exception(str(runtime_args.message))

#===========================Revision History===================================
#Modifier       Modified On                 Modification Reason
#Saisivaprasad   14/07/2017                  Applied new coding standards
#Saisivaprasad    21/08/2017                  Applied new framework methods
#==============================================================================