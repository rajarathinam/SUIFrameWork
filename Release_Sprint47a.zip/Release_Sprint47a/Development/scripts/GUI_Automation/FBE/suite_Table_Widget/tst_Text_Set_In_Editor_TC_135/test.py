# -*- coding: utf-8 -*-

"""
Aim of the script  : VERIFY THAT THE CELL ID’S ARE UPDATED ON ADDING AND
                     REMOVING ROWS AND COLUMNS
Reference document : TAR-TPS-001-TPS_ADT_FBE_ITV_FWQ_Sprint 45.docx
Test case ID       : TC138
"""

import general
app_name = "FBE"


def _pre_condition():
    #Open the editor by running ./FBE
    general.launch_application(app_name, write_result=False)


def main():
    try:
        # Call the test script pre-requisites
        _pre_condition()
        # Step 1:Verify if table widget can be added to editor form by
        # dragging and dropping
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_TableWidget',
                                    widget_name='Table Widget',
                                    target_name='Editor Form')

        data_set = testData.dataset(general.get_path("testdata") +
                            "/Text_Set_In_Editor_TC_135.tsv")
        # Declare an iterator variable
        iterator = 0
        # Declare a variable to set the text of a block in table
        initial_text_in_table_block = ''
        for row in data_set:
            property_name = testData.field(row, 'property_name')
            property_value = testData.field(row, 'property_value')
            context_menu_item = testData.field(row, 'context_menu_item')
            tree_view_widget_name = testData.field(row,
                                                   'tree_view_widget_name')
            target_block = testData.field(row, 'target_block')
            if(iterator <= 1):
                #Step6 : Right click on the added Table Widget, select Insert
                #        Rows
                #Step8 : Right click on the added Table Widget, select Insert
                #        Columns
                #general.manage_table_entries(tree_view_widget_name,
                #                             context_menu_item, property_name,
                #                            property_value)
                general.update_and_verify_table_entries(tree_view_widget_name,
                                             context_menu_item, property_name,
                                             property_value, write_result=True)
                general.verify_table_entries_in_preview(tree_view_widget_name,
                         'objectName', tab_name='tbp2',
                         write_result=True)
            if(iterator >= 2):
                general.update_property_for_table_entries(property_name,
                                                target_block,
                                                property_value,
                                                tree_view_widget_name)
                general.verify_property_for_table_entries_in_preview(
                                            tree_view_widget_name,
                                            target_block,
                                            property_name,
                                            property_value)
            iterator += 1
        _post_condition()

    except Exception as runtime_args:
        raise Exception(str(runtime_args.message))


def _post_condition():
    # quit the FBE application
    general.quit_application(app_name)

#===========================Revision History===================================
#Modifier       Modified On                 Modification Reason
#Girish Nair    04/08/2017                  New script created
#==============================================================================
