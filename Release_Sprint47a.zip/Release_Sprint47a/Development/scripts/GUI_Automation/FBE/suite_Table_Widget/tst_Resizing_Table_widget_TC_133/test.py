# -*- coding: utf-8 -*-

"""
Aim of the script  : Verify that a Table Widget can be resized.
Reference document : TAR-TPS-001-TPS_ADT_FBE_ITV_FWQ_Sprint 45.docx
Test case ID       : TC133
"""

import general
app_name = "FBE"


def _pre_condition():
    pass


def main():
    try:
        #call the test script pre-requisites
        _pre_condition()
        # Step 1: Open the editor by running ./FBE
        general.launch_application(app_name, write_result=False)
        # Step 2:Verify if table widget can be added to editor form by
        # dragging and dropping
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_TableWidget',
                                    widget_name='Table Widget',
                                    target_name='Editor Form')
        # get the test data for this test script
        data_set = testData.dataset(general.get_path("testdata") +
                            "/Resizing_Table_widget_TC_133.tsv")
        expected_prop_values = {}
        for row in data_set:
            property_name = testData.field(row, "property_name")
            property_value = testData.field(row, "property_value")
            expected_prop_values[property_name] = property_value
            general.update_property_value_in_editor("TableWidget",
                                    property_name, property_value, True)
            general.verify_properties_in_preview('tbp2',
                                        widget_name="TableWidget",
                                        widget_id="taw29",
                                    expected_prop_value=expected_prop_values,
                                    write_result=True)
        # Call the post condition
        _post_condition()
    except Exception as runtime_args:
        raise Exception(str(runtime_args.message))


def _post_condition():
    # quit the FBE application
    general.quit_application(app_name)