# -*- coding: utf-8 -*-

"""
Aim of the script  : Verify that the column width can be set per column in the
                     editor
Reference document : TAR-TPS-001-TPS_ADT_FBE_ITV_FWQ_Sprint 45.docx
Test case ID       : TC139
"""

import general
app_name = "FBE"


def _pre_condition():
    #Open the editor by running ./FBE
    general.launch_application(app_name, write_result=False)


def main():
    try:
        # Call the test script pre-requisites
        _pre_condition()
        # Step 1:Verify if table widget can be added to editor form by
        # dragging and dropping
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_TableWidget',
                                    widget_name='Table Widget',
                                    target_name='Editor Form')
        data_set = testData.dataset(general.get_path("testdata") +
                            "/Setting_Column_Width_TC_139.tsv")
        # Declare an iterator variable
        iterator = 0
        for row in data_set:
            property_name = testData.field(row, 'property_name')
            property_value = testData.field(row, 'property_value')
            context_menu_item = testData.field(row, 'context_menu_item')
            tree_view_widget_name = testData.field(row,
                                                   'tree_view_widget_name')
            target_block = testData.field(row, 'target_block')
            if(iterator <= 1):
                #Step6 : Right click on the added Table Widget, select Insert
                #        Rows
                #Step8 : Right click on the added Table Widget, select Insert
                #        Columns
                general.update_and_verify_table_entries(tree_view_widget_name,
                                             context_menu_item, property_name,
                                             property_value, write_result=True)
                general.verify_table_entries_in_preview(tree_view_widget_name,
                         'objectName', tab_name='tbp2',
                         write_result=True)
            if(iterator > 1):
                # select the tree view widget for the table widget
                general.select_item_in_widget_tree_view(tree_view_widget_name)
                general.update_property_value_in_editor("TableWidget",
                                                        property_name,
                                                        property_value,
                                                        True)
            iterator += 1
        _post_condition()

    except Exception as runtime_args:
        raise Exception(str(runtime_args.message))


def _post_condition():
    # quit the FBE application
    general.quit_application(app_name)

#===========================Revision History===================================
#Modifier       Modified On                 Modification Reason
#Girish Nair    09/08/2017                  New script created
#==============================================================================
