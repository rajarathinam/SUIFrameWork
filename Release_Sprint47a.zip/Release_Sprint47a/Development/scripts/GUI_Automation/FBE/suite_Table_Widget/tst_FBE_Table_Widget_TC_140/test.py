# -*- coding: utf-8 -*-

"""
Aim of the script  : VERIFY THAT THE TABLE WIDGET IS SHOWN AS DESIGNED IN THE VIEWER.
                     Reference document : TAR-TPS-001-TPS_ADT_FBE_ITV_FWQ_Sprint 45.docx
Test case ID       : TC140
"""

import general

app_name = 'FBE' 

def _pre_condition():
    #Open the editor by running ./FBE
    general.launch_application(app_name)

def main():
    try:
        # Step 1:Verify that the table widget is shown as designed in the viewer
        _pre_condition()

        # dragging and dropping
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_TableWidget',
                                    widget_name='TableWidget',
                                    target_name='Editor Form')

        general.update_property_value_in_editor(widget_name='TableWidget', property_name='width',
                                    value_to_be_set='100')
        
        general.quit_application('FBE', file_name='testTablewidget.xml')
      
        general.launch_application('FBE')
    
        general.open_file_in_editor('testTablewidget.xml')
        
        general.verify_properties_in_preview(tab_obj_id='tbp2',
                                             widget_name='TableWidget',
                                             widget_id='taw29',
                                    expected_prop_value={'width': '100'},
                                    write_result=True)
       
        _post_condition()
        
        
    except Exception as runtime_args:
        raise Exception(str(runtime_args.message))


def _post_condition():
   # quit the FBE application
   general.quit_application(app_name)