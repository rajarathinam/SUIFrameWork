# -*- coding: utf-8 -*-

"""
Aim of the script  : VERIFY THE FONT SIZE CAN BE SET IN THE  EDITOR
Reference document : TAR-TPS-001-TPS_ADT_FBE_ITV_FWQ_Sprint 44
Test case ID       : TC082
"""

import general


def main():
    try:
        # Step 1:Start the FBE application
        general.launch_application('FBE', write_result=True)

        # Step 2:Place a Label widget on the form
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_Label',
                                    widget_name='Label Widget',
                                    target_name='Editor Form')

        # Step 3 & 4:Verify if the FontSize of the Label can be set to small
        general.update_property_value_in_editor(widget_name='Label', property_name='FontSize',
                                    value_to_be_set='Small', write_result=True)
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='Label', widget_id='lbl29', expected_prop_value={'FontSize':'small'},
                   write_result=True)
        #Step 5:Place a Label widget on the form
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_Label',
                                    widget_name='Label Widget',
                                    target_name='Editor Form',target_x_coord=350,
                                    target_y_coord=350)
        # Step 6:Verify if the FontSize of the Label can be set to Normal
        general.update_property_value(widget_name='Label', property_name='FontSize',
                                    value_to_be_set='Normal', write_result=True)
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='Label', widget_id='lbl30', expected_prop_value={'FontSize':'normal'},
                   write_result=True)
        #Step 7:Place a Label widget on the form
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_Label',
                                    widget_name='Label Widget',
                                    target_name='Editor Form',target_x_coord=450,
                                    target_y_coord=450)
         # Step 8:Verify if the FontSize of the Label can be set to Big
        general.update_property_value(widget_name='Label', property_name='FontSize',
                                    value_to_be_set='Big', write_result=True)
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='Label', widget_id='lbl31', expected_prop_value={'FontSize':'big'},
                   write_result=True)
        # Step 9:Save the file as testLblFontSize.xml
        general.save_file_in_editor(file_name='testLbl_FontSize.xml',
              directory_path='/home/adt/ADT/ASML-ADT/Trunk/targets/bin/')
        # Step 10:Close and relaunch FBE
        general.quit_application(app_name='FBE', file_name='',
                directory_path='/home/adt/ADT/ASML-ADT/Trunk/targets/bin/')
        general.launch_application('FBE', write_result=True)
        
        # Step 11:Open the file testLbl_FrontSize.xml and preview
        general.open_file_in_editor(file_name='testLbl_FontSize.xml',
              directory_path='/home/adt/ADT/ASML-ADT/Trunk/targets/bin/')
        # Step 12:Verify if 3 labels are shown: 1 small, 1 normal, 1 big
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='Label',widget_id='lbl29', expected_prop_value={'FontSize':'small'},
                   write_result=True)
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='Label', widget_id='lbl30', expected_prop_value={'FontSize':'normal'},
                   write_result=True)
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='Label', widget_id='lbl31', expected_prop_value={'FontSize':'big'},
                   write_result=True)
               
    except Exception as runtime_args:
        raise Exception(str(runtime_args.message))
