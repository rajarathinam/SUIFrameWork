 # -*- coding: utf-8 -*-

"""
Aim of the script  : VERIFY IF THE PROPERTY CHECKED IS SHOWN CORRECTLY IN THE VIEWER  
Reference document : TAR-TPS-001-TPS_ADT_FBE_ITV_FWQ_Sprint 44
Test case ID       : TC114
"""

import general


def main():
    try:
        # Step 1:Start the FBE application
        general.launch_application('FBE', write_result=True)

        # Step 2:Place a RadioButton widget on the form. Set Checked to true
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_RadioButton',
                                    widget_name='RadioButton Widget',
                                    target_name='Editor Form')
       
        general.update_property_value_in_editor(widget_name='RadioButton', property_name='Checked',
                                    value_to_be_set='true', write_result=True)
        
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='RadioButton',widget_id='rbn29', expected_prop_value={'Checked':'true'},
                    write_result=True)
        
        #Step 3:Place another RadioButton widget on the form. Set Checked to True
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_RadioButton',
                                    widget_name='RadioButton Widget',
                                    target_name='Editor Form',target_x_coord=350,
                                    target_y_coord=350)
        
        general.update_property_value_in_editor(widget_name='RadioButton', property_name='Checked',
                                    value_to_be_set='true', write_result=True)
        
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='RadioButton',widget_id='rbn30', expected_prop_value={'Checked':'true'},
                    write_result=True)
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='RadioButton',widget_id='rbn29', expected_prop_value={'Checked':'false'},
                    write_result=True)
        # Step 4:Place another RadioButton widget on the form. Set Checked to false
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_RadioButton',
                                    widget_name='RadioButton Widget',
                                    target_name='Editor Form',target_x_coord=450,
                                    target_y_coord=450)
        
        general.update_property_value_in_editor(widget_name='RadioButton', property_name='Checked',
                                    value_to_be_set='false', write_result=True)
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='RadioButton',widget_id='rbn31', expected_prop_value={'Checked':'false'},
                    write_result=True)
        # Step 5:Save the file as test_Checked.xml
        general.save_file_in_editor(file_name='test_Checked.xml',
              directory_path='/home/adt/ADT/ASML-ADT/Trunk/targets/bin/')
        # Step 8:Close and relaunch FBE
        general.quit_application(app_name='FBE', file_name='',
                directory_path='/home/adt/ADT/ASML-ADT/Trunk/targets/bin/')
        general.launch_application('FBE', write_result=True)
        
        # Step 9:Open the file test_Checked.xml and preview
        general.open_file_in_editor(file_name='test_Checked.xml',
              directory_path='/home/adt/ADT/ASML-ADT/Trunk/targets/bin/')
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='RadioButton',widget_id='rbn29', expected_prop_value={'Checked':'false'},
                    write_result=True)
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='RadioButton',widget_id='rbn30', expected_prop_value={'Checked':'true'},
                    write_result=True)
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='RadioButton',widget_id='rbn31', expected_prop_value={'Checked':'false'},
                    write_result=True)
               
    except Exception as runtime_args:
        raise Exception(str(runtime_args.message))
