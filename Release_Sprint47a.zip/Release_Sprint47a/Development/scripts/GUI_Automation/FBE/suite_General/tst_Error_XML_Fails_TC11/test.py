# -*- coding: utf-8 -*-

"""
Aim of the script  : VERIFY THAT THE TABLE WIDGET IS SHOWN AS DESIGNED IN THE
                    VIEWER.
                     Reference document : TAR-TPS-001-TPS_ADT_FBE_ITV_FWQ_
                    Sprint 45.docx
Test case ID       : TC140
"""

import general
import native_squish_apis
import qt_convenient_squish_apis
import logger

app_name = 'FBE'


def main():
    try:
        #step1:Start the editor by running ./FBE
        general.launch_application(app_name)

        #Step2:Place a random widget on the form and save the file. Try to
        #overwrite the write-protected file
        # dragging and dropping
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_Button',
                                    widget_name='ButtonWidget',
                                    target_name='Editor Form')

        general.save_file_in_editor('Error_File', '/home/adt/GUI_Automation_04_08_2017/shared/testdata/FBE/General/Error_XML_Fails_TC11/')

        if(native_squish_apis.object_exists(
                                        'FBE_IOExceptionPopup', 2)):
            logger.write_to_result('Pass',
            'VERIFY THAT AN ERROR MESSAGE IS GIVEN IF SAVING OF XML FAILS',
            'An pop up message is given, stating that an error has occurred'
            + ' while saving the file',
            'An pop up message is given, stating that an error has occurred'
            + ' while saving the file')
        else:
            logger.write_to_result('Fail',
            'VERIFY THAT AN ERROR MESSAGE IS GIVEN IF SAVING OF XML FAILS',
            'An pop up message is given, stating that an error has occurred'
            + ' while saving the file',
            'An pop up message is, stating that an error has occurred while'
            + ' saving the file is not shown')

        _post_condition()

    except Exception as runtime_args:
        raise Exception(str(runtime_args.message))


def _post_condition():
    # quit the FBE application

    qt_convenient_squish_apis.click_button(
                                        'FBE_IOExceptionPopup_Button_Ok', 2)
    general.quit_application(app_name)

#===========================Revision History===================================
#Modifier       Modified On                 Modification Reason
#Saisivaprasad    08/08/2017                  New script created
#==============================================================================
