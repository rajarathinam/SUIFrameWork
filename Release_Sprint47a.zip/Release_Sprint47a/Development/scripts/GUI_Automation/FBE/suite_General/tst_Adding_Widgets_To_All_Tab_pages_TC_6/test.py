# -*- coding: utf-8 -*-

"""
Aim of the script  : Verify that widgets can be added to the currently selected
                     Tab page.
Reference document : TAR-TPS-001-TPS_ADT_FBE_ITV_FWQ_Sprint_45.docx
Test case ID       : TC6
"""

import general
import native_squish_apis

app_name = "FBE"


def _pre_condition():
    #Open the editor by running ./FBE
    general.launch_application(app_name, write_result=False)


def main():
    try:
        #call the test script pre-requisites
        _pre_condition()
        # declare an iterator variable
        iterator = 0
        # get the test data set from the corresponding test script data file.
        data_set = testData.dataset(general.get_path("testdata") +
                            "/Adding_Widgets_To_All_Tab_pages_TC_6.tsv")
        for row in data_set:
            tree_view_item_name = testData.field(row,
                                                    "tree_view_element")
            tab_name = testData.field(row,
                                                    "tab_name")
            tab_object = testData.field(row,
                                                    "tab_object")
            widget_id = testData.field(row,
                                                    "widget_id")
            if iterator == 0:
                # Step 1: Select the main Tab widget in the Form Editor by
                # clicking on it with the mouse.
                general.select_item_in_widget_tree_view(tree_view_item_name)
                # Step 2: Right click on the Main tab widget and add a Tab page
                general.select_context_menu_item(
                                  "FBE_MainWindow_SubContainer_EditorForm",
                                  "Add Tab Page")
                # check if the pop-up is opened and provide the name of the new
                # tab.
                if not native_squish_apis.object_exists(
                                            "FBE_SetNewTabName_Dialog"):
                    raise Exception("""FBE_SetNewTabName_Dialog is not
                            available to create a new tab.""")
                general.set_value_for_an_object(
                                        "FBE_SetNewTabName_Widget_Layout",
                                        "Tab Name", tab_name,
                                         write_result=True)
                #close the new tab object
                general.close_pop_up("FBE_SetNewTabName_Dialog_Btn_Ok")
            if iterator == 1 or iterator == 2:
                # Step 3: Click the Tab button
                general.select_item_in_widget_tree_view(tree_view_item_name,
                                                        True)
                # Step 6:Verify if table widget can be added to editor form by
                # dragging and dropping
                general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_Button',
                                    tab_obj=tab_object,
                                    widget_name='Button',
                                    target_name='Editor Form')
            if iterator == 3 or iterator == 4:
                # go to Preview and verify the items
                general.verify_properties_in_preview(
                                    tab_obj_id=tree_view_item_name,
                                    widget_id=widget_id,
                                    expected_prop_value={},
                                    write_result=True)
            iterator += 1
        # call the post condition for the script
        _post_condition()

    except Exception as runtime_args:
        raise Exception(str(runtime_args.message))


def _post_condition():
    # quit the FBE application
    general.quit_application(app_name)

#===========================Revision History===================================
#Modifier       Modified On                 Modification Reason
#Girish Nair    28/07/2017                  New script created
#==============================================================================
