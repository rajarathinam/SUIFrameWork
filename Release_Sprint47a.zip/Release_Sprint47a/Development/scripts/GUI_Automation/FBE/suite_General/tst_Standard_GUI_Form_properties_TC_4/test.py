# -*- coding: utf-8 -*-

"""
Aim of the script  : Verify the standard GUI Form properties: HasStatusBar,
                     HasRightButtonBar, HasBottomButtonBar, Height, Width
Reference document : TAR-TPS-001-TPS_ADT_FBE_ITV_FWQ_Sprint_45.docx
Test case ID       : TC4
"""

import general

app_name = "FBE"


def main():
    try:
        # Start the FBE application
        general.launch_application(app_name, write_result=False)

        # Step 1:Verify if the Form Properties window can be opened from the
        # Edit Menu.
        general.go_to_menu_item("Edit", "Form Properties")
        #declare an iterator object
        iterator = 0
        # get the test data set from the corresponding test script data file.
        data_set = testData.dataset(general.get_path("testdata") +
                            "/Standard_GUI_Form_properties_TC_4.tsv")
        for row in data_set:
            property_name = testData.field(row,
                                                    "property_name")
            property_value = testData.field(row,
                                                    "property_value")
            if iterator < 6:
                # Step1: Click on the Edit item in the menu and select Form
                # Properties
                general.verify_properties("FormProperties",
                                                 property_name, property_value,
                                                 property_type="Editable")
            else:
                # Step2: Verify the height and/or the width property
                general.verify_properties("FormProperties",
                                                 property_name, property_value)
            iterator += 1
        # call the post condition for the script
        _post_condition()
    except Exception as runtime_args:
        raise Exception(str(runtime_args.message))


def _post_condition():
    # close the Form Properties window
    general.close_pop_up("FBE_FormProperties_Window_Btn_OK",
                                         True)
    # quit the FBE application
    general.quit_application(app_name)