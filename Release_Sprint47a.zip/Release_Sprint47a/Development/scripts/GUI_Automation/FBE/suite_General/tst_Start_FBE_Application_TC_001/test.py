"""
Aim of the Script     : Verify that the GUI Editor starts up.
Reference Document    : TAR-TPS-001-TPS_ADT_FBE_ITV_FWQ_Sprint 43
Test case ID          : TC1
"""
import general
import logger

#declare a static variable to contain the application name to be tested.
APP_NAME = "FBE"


def main():
    try:
        #start application and verify
        if(general.launch_application(APP_NAME)):
            logger.write_to_result("Pass", "Open FBE",
                                "The GUI Editor starts up and is visible.",
                                "Application is Launched")
        else:
            logger.write_to_result("Fail", "Open FBE",
                                "The GUI Editor starts up and is visible.",
                                "Application is not Launched")

    except Exception as e:
        logger.failed(str.format("Exception : {0}", e))
    finally:
        #call the post condition for the test script.
        posCondition()
        logger.write_log(str("Test Completed..."))


def posCondition():
    general.quit_application(APP_NAME)

#===========================Revision History===================================
#Modifier       Modified On                 Modification Reason
#Girish Nair    13/07/2017                  Applied new coding standards
#==============================================================================
