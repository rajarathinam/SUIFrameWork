"""
Aim of the Script     : VERIFY IF THE TEXT ALIGNMENT CAN BE SET IN THE EDITOR
Reference Document    : TAR-TPS-001-TPS_ADT_FBE_ITV_FWQ_Sprint 47
Test case ID          : TC091
"""
import general
APP_NAME = "FBE"


def main():
    try:
        # Step 1:Start the FBE application
        general.launch_application('FBE', write_result=True)

        # Step 2:Place a LineEdit widget on the form. Set Checked to true
        general.verify_widget_drag_and_drop(
            'FBE_MainWindow_WidgetIcon_LineEdit',
             widget_name='LineEdit',
             target_name='Editor Form',
             target_x_coord=120,
             target_y_coord=120)

        # step 3 & 4: Verify if the alignment of the line edit can be set to
        #center
        general.update_property_value_in_editor(widget_name='LineEdit',
            property_name='Alignment', value_to_be_set='Center',
            write_result=True)

        general.verify_properties_in_preview(tab_obj_id='tbp2',
                    widget_name='LineEdit', widget_id='lne29',
                    expected_prop_value={'Alignment': 'Center'},
                    write_result=True)

        # Step 5:Place a LineEdit widget on the form. Set Checked to true
        general.verify_widget_drag_and_drop(
                    'FBE_MainWindow_WidgetIcon_LineEdit',
                    widget_name='LineEdit',
                    target_name='Editor Form',
                    target_x_coord=200, target_y_coord=200)

        # step 6 & 7: Verify if the alignment of the line edit can be set to
        #Right
        general.update_property_value_in_editor(widget_name='LineEdit',
                    property_name='Alignment', value_to_be_set='Right',
                    write_result=True)

        general.verify_properties_in_preview(tab_obj_id='tbp2',
                    widget_name='LineEdit', widget_id='lne30',
                    expected_prop_value={'Alignment': 'Right'},
                    write_result=True)

        # Step 8:Place a LineEdit widget on the form. Set Checked to true
        general.verify_widget_drag_and_drop(
                   'FBE_MainWindow_WidgetIcon_LineEdit',
                    widget_name='LineEdit',
                    target_name='Editor Form',
                    target_x_coord=400, target_y_coord=400)

        # step 9 & 10: Verify if the alignment of the line edit can be set to
        #Left
        general.update_property_value_in_editor(widget_name='LineEdit',
                   property_name='Alignment', value_to_be_set='Left',
                   write_result=True)

        general.verify_properties_in_preview(tab_obj_id='tbp2',
                    widget_name='LineEdit', widget_id='lne31',
                    expected_prop_value={'Alignment': 'Left'},
                    write_result=True)

        # Step 11:Save the file as testSetColor_LineEdit.xml
        general.save_file_in_editor(file_name='testSetAlignment_LineEdit.xml')

        # Step 12:Close and relaunch FBE
        general.quit_application(app_name='FBE', file_name='')
        general.launch_application('FBE', write_result=True)

        # Step 13:Open the file testSetAlignment_LineEdit.xmll and preview
        general.open_file_in_editor(file_name='testSetAlignment_LineEdit.xml')

        # Step 14:Verify if 3 line edit are shown: 1 aligned left, 1 aligned
        #right, 1 centered
        data_set = testData.dataset(general.get_path("testdata") +
                            "/FBE_LineEdit_Widget_TC_91.tsv")
        for row in data_set:
            property_name = testData.field(row, "property_name")
            property_value = testData.field(row, "property_value")
            widget_id = testData.field(row, "widget_id")

            general.verify_properties_in_preview(tab_obj_id='tbp2',
                    widget_name='LineEdit', widget_id=widget_id,
                    expected_prop_value={property_name: property_value},
                        write_result=True)

        _post_condition()

    except Exception as runtime_args:
        raise Exception(str(runtime_args.message))


def _post_condition():
    general.quit_application(APP_NAME)

#===========================Revision History===================================
#Modifier       Modified On                 Modification Reason
#Saisivaprasad    22/08/2017                  Applied new coding standards
#==============================================================================
