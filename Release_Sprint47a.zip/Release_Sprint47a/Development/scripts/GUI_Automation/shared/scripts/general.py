# -*- coding: utf-8 -*-

import __builtin__
import os
import re

import preview
import logger
import qt_convenient_squish_apis
import native_squish_apis
from gui_classes import *
import gui_classes

import squish
import test
import objectMap
import object
from collections import OrderedDict

# Global dictionary to hold the widget name
widget_name_object = {}
# Global variable to hold the maximum time out
MAX_TIME_OUT = 3
# Global variable to hold the minimum time out
MIN_TIMEOUT_VALUE = 0.20
# Global variable to determine the context menu is already available
# or not
context_pop_up_avaiable = False


def _open_new_fbe():
    """
    This function will close the 'Do you want to restore this file' pop-up
    and remove the backup file, there opens a new session of FBE application.
    After opening the application, it also maximizes the FBE editor window.
    """
    try:
        # Loop to close multiple pop-ups
        while True:
            # Check if 'Restore backup file' pop-up exists, if yes
            # consider the respective pop-up object for further actions
            if native_squish_apis.object_exists(
                        'FBE_RestoreBackupFilePopup_MsgBox', 1):
                popup_obj = 'FBE_RestoreBackupFilePopup_MsgBox'
            # Check if 'Remove backup file' pop-up exists, if yes
            # consider the respective pop-up object for further actions            
            elif native_squish_apis.object_exists(
                        'FBE_RemoveBackupFilePopup_MsgBox', 1):
                popup_obj = 'FBE_RemoveBackupFilePopup_MsgBox'
            # If none of the pop-up exists, break the while loop
            else:
                break

            # Get the reference of the existing pop-up object
            popup_obj_ref = native_squish_apis.wait_for_object(popup_obj, 1)

            # If the pop-up text contains a message 'Do you want to restore
            # this file', then we should be clicking 'No' button in the pop-up  
            if("DO YOU WANT TO RESTORE THIS FILE" in 
                                            str(popup_obj_ref.text).upper()):
                button_to_click = 'FBE_RestoreBackupFilePopup_Btn_No'
            # If the pop-up text contains a message 'Do you want to remove
            # this backup file', then we should be clicking 'Yes' button
            elif("DO YOU WANT TO REMOVE THIS BACKUP FILE" in 
                                            str(popup_obj_ref.text).upper()):
                button_to_click = 'FBE_RemoveBackupFilePopup_Btn_Yes'

            # Click on the required button    
            qt_convenient_squish_apis.click_button(button_to_click, 1)

        # Maximize the window FBE window
        qt_convenient_squish_apis.set_window_state('FBE_MainWindow_Screen',
                                                   'Maximize')

    except Exception as run_time_args:
        raise Exception("general._open_new_fbe(): "
                        + str(run_time_args.message))


def launch_application(app_name, time_out=1, write_result=False):
    """This function is to launch the required application"""
    try:
        # Raise exception if invalid application name is passed
        if not app_name in ['FBE', 'FWQ_UerTest']:
            raise Exception("'" + str(app_name) + "' is not a valid"
                            " application name to launch.")

        # Get the application context
        app_context = native_squish_apis.application_context(app_name)
        # Check if the application is already running and detach from it
        if app_context.isRunning:
            logger.write_log("'" + str(app_name) + "' is already running."
                             " Detaching from and starting new session.")
            app_context.detach()

        # Start the required application
        app_context = native_squish_apis.start_application(app_name, time_out)
        # Get the application status.
        app_status = app_context.isRunning

        # Check if the application has started. Else raise exception
        if app_status == True:
            logger.write_log("'" + str(app_name) + "' application started.")
        else:
            raise Exception("Could not start '" + str(app_name) +
                            "' application.")
        if(app_name == "FBE"):
            # Open fresh session of FBE editor
            _open_new_fbe()

        # check if the app_name is FWQ_UserTest
        elif(app_name == "FWQ_UserTest"):
            pass

        # If user wishes, write the test result
        if write_result == True:
            logger.write_to_result('Pass',
                        'To verify if the FBE editor starts up successfully',
                        'FBE editor should start up successfully',
                        'FBE editor started successfully')

        #get all the widgets from the widget selector and store it in a
        #dictionary
        get_all_widgets_from_selector_area()

        # return app_status
        return app_status

    except Exception as run_time_args:
        raise Exception("general.launch_application(): "
                        + str(run_time_args.message))


def quit_application(app_name='FBE', file_name='',
                directory_path='/home/adt/ADT/ASML-ADT/Trunk/targets/bin/'):
    """
    This function is to quit the running application and save the
    changes if required.
    app_name = Name of the application which needs to be quit
            Ex: 'FBE'
    file_name = Name (with extension) with which the file should be saved
            Ex: 'MyButton.xml'
    directory_path = Directory path where the file needs to be saved.
            Ex: '/home/share/'
    """
    try:
        # Raise exception if the passed application is invalid
        if app_name not in  ['FBE', 'FBE_QMessageBox']:
            raise Exception("'" + str(app_name) + "' is an invalid "
                            "application name")

        if(app_name == 'FBE'):
            # Go to 'Quit' menu item
            go_to_menu_item('File', 'Quit')

            # Check if 'Save your changes' pop-up exists
            if native_squish_apis.object_exists(
                                        'FBE_SaveEditorChangesPopup', 3):
                # Check if user wants to save the changes
                if file_name != '':
                    # Click on 'Yes' button in the pop-up
                    qt_convenient_squish_apis.click_button(
                                    'FBE_SaveEditorChangesPopup_Button_Yes')
                    # Save the changes
                    _save_file(file_name, directory_path)
                else:
                    # Click on 'No' button in the pop-up
                    qt_convenient_squish_apis.click_button(
                                    'FBE_SaveEditorChangesPopup_Button_No')
            else:
                logger.write_log("'" + str(app_name) + "' application "
                                 "was quit")

        elif(app_name == "FWQ_UserTest"):
            pass

    # Handle all other exceptions other than 'LookupError' exception
    except Exception as run_time_args:
        raise Exception("general.quit_fbe_app(): "
                            + str(run_time_args.message))


def get_children(parent_object, depth=1000):
    """
    This function will fetch all children from the parent and returns 
    in a list
    """
    return [child for child in walk_through_children(parent_object, depth)]


def get_children_of_type(parent_object, child_type_name, depth=1000):
    """
    This function will fetch the children of required type (type_name)
    from the parent and returns all children in a list
    """
    return [child for child in walk_through_children(parent_object, depth)
            if squish.className(child) == child_type_name]


def walk_through_children(parent_object, depth=1000):
    """
    This is generator function.
    This generator is to walk through each child in the parent-child
    hierarchy and yield each child
    """
    try:
        # Get the reference of the parent object using wait_for_object
        parent_obj_ref = native_squish_apis.wait_for_object(parent_object, 1)

    except LookupError:
        # Get the reference of the parent object using find_object
        parent_obj_ref = native_squish_apis.find_object(parent_object)

    # Iterate through each child of the parent object
    for child in object.children(parent_obj_ref):
        # Yield the child found
        yield child
        # If user wishes to dig down further to grand-children
        if depth:
            # Walk through the children of the current child
            for grand_child in walk_through_children(child, depth - 1):
                # Yield the grand child found
                yield grand_child


def _save_file(file_name='',
              directory_path='/home/adt/ADT/ASML-ADT/Trunk/targets/bin/'):
    """
    This function is to save the required file in the required path.
    If the file name already exists, it replaces the existing file
    with new file.
    file_name = Mandatory argument - Name (with extension) with which
            the file should be saved
            Ex: 'MyButton.xml'
    directory_path = Optional argument - Directory path where the file
            needs to be saved.
            Ex: '/home/share/'
    """
    try:
        # Wait for the file name input box
        file_name_inputbox = native_squish_apis.wait_for_object(
                                    'FBE_SaveFileWindow_InputBox_FileName', 5)
        # Enter the file name along with the path in the file name input box
        qt_convenient_squish_apis.type(file_name_inputbox,
                                       directory_path + file_name)
        logger.write_log("Entered '" + str(directory_path + file_name) + "' "
                         "in 'File Name' input box of 'Save File' window")
        # Click on 'Save' button
        qt_convenient_squish_apis.click_button(
                                        'FBE_SaveFileWindow_Button_Save', 2)

        # Check if 'File already exists' pop-up is displayed
        if(native_squish_apis.object_exists('FBE_FileAlreayExistsPopup', 2)):
            # Click on 'Yes' button in the pop-up so that old file gets
            # replaced with new one
            qt_convenient_squish_apis.click_button(
                                    'FBE_FileAlreayExistsPopup_Button_Yes', 2)

    except Exception as sf_run_time_args:
        raise Exception("general.save_file(): "
                        + str(sf_run_time_args.message))


def _open_file(file_name,
              directory_path='/home/adt/ADT/ASML-ADT/Trunk/targets/bin/'):
    """
    This private function is to open the given file from the given
    directory.
    file_name = Mandatory argument - Name (with extension) of the file
            to be opened
            Ex: 'MyButton.xml'
    directory_path = Optional argument - Directory path where the file
            is saved.
            Ex: '/home/share/'
    """
    try:
        # Wait for the file name input box
        file_name_inputbox = native_squish_apis.wait_for_object(
                                    'FBE_OpenFileWindow_InputBox_FileName', 5)
        # Enter the file name to be opened in the input box
        qt_convenient_squish_apis.type(file_name_inputbox,
                                       directory_path + file_name)
        # Click on 'Open' button
        qt_convenient_squish_apis.click_button(
                                            'FBE_OpenFileWindow_Button_Open')

    except Exception as of_run_time_args:
        raise Exception("general._open_file(): "
                        + str(of_run_time_args.message))


def save_file_in_editor(file_name='',
              directory_path='/home/adt/ADT/ASML-ADT/Trunk/targets/bin/'):
    """
    This is function selects 'Save As' menu item in the editor and then
    calls '_save_file' private method.
    file_name = Mandatory argument - Name (with extension) with which
            the file should be saved
            Ex: 'MyButton.xml'
    directory_path = Optional argument - Directory path where the file
            needs to be saved.
            Ex: '/home/share/'
    """
    try:
        # Go to 'Save As' menu item
        go_to_menu_item('File', 'Save As')
        # '_save_file' API
        _save_file(file_name, directory_path)

    except Exception as sfie_runtime_args:
        raise Exception('general.save_file_in_editor(): '
                        + str(sfie_runtime_args.message))


def open_file_in_editor(file_name='',
              directory_path='/home/adt/ADT/ASML-ADT/Trunk/targets/bin/'):
    """
    This is function selects 'Open' menu item in the editor and then
    calls '_open_file' private method.
    file_name = Mandatory argument - Name (with extension) of the file
            to be opened
            Ex: 'MyButton.xml'
    directory_path = Optional argument - Directory path where the file
            is saved.
            Ex: '/home/share/'
    """
    try:
        # Go to 'Open' menu item
        go_to_menu_item('File', 'Open')
        # '_open_file' API
        _open_file(file_name, directory_path)

    except Exception as ofie_runtime_args:
        raise Exception('general.open_file_in_editor(): '
                        + str(ofie_runtime_args.message))


def close_fbe_app(time_out=1):
    """Method to close the FBE application using the close button on the right
    corner of the application."""
    try:
        #give the time for squish to wait for the next command
        squish.snooze(time_out)
        #method to send an event to the application
        qt_convenient_squish_apis.send_event("QCloseEvent",
                                             "MainWindow_MainWindow")
        #give the time for squish to wait for the next command
        squish.snooze(time_out)
        return True
    except Exception:
        return False


def get_all_widgets_from_selector_area(iDepth=20):
    """Method to get all the available widget object names from the widget
    Selector section"""
    try:
        global widget_name_object
        diSelectorWidgets = {}
        liController = []
        liLabel = []
        # call the native_squish_apis object exists API to verify the
        # existence of the object
        if(native_squish_apis.object_exists("FBE_MainWindow_AvailableWidgetsList")):
            liLabelChildObject = get_children_of_type(
                    "FBE_MainWindow_AvailableWidgetsList", "QLabel")
            liControllerChildObject = get_children_of_type(
                    "FBE_MainWindow_AvailableWidgetsList",
                    "WidgetController")
            for oChild in liControllerChildObject:
                if(oChild.height > 4):
                    liController.append(oChild)
            for oChild in liLabelChildObject:
                if not (oChild.text == None):
                    liLabel.append(str(oChild.text))
                else:
                    liLabelChildObject.remove(oChild)
            diSelectorWidgets = dict(zip(liLabel, liController))
            diSelectorWidgets = OrderedDict(sorted(diSelectorWidgets.items(),
                                            key=lambda iValue: iValue[1]))
            widget_name_object = diSelectorWidgets
        else:
            raise Exception("stPropertyType windows object not found...")
    except Exception as run_time_args:
        raise Exception("general.get_all_widgets_from_selector_area(): "
                        + str(run_time_args.message))


def verify_popup_text_and_close_pop_up(pop_up_object, pop_up_type,
                                close_window_text,
                                pop_up_child_text=None,
                                time_out=1):
    """Method to check for the text of the pop is as expected"""
    try:
        found_text = False
        #declare a variable to get the final result
        button_text_clicked = False
        #give the time for squish to wait for the next command
        squish.snooze(time_out)
        # call the native_squish_apis object exists API to verify the
        # existence of the object
        if(native_squish_apis.object_exists(pop_up_object)):
            # get the children object from the parent object of given type
            pop_up_children_object = get_children_of_type(pop_up_object,
                                                            pop_up_type)
            if pop_up_child_text:
                # loop through pop_up_children_object
                for pop_up_child in pop_up_children_object:
                    # compare the po_up_child_textwith current object text
                    if pop_up_child_text in str(pop_up_child.text):
                        found_text = True
                    else:
                        found_text = False
            else:
                found_text = True
            # check if the found_text is True
            if(found_text):
                #give the time for squish to wait for the next command
                squish.snooze(time_out)
                #loop throough the list of pop_up_children_objects
                for pop_up_object in pop_up_children_object:
                    # get the children object from the parent object of given
                    # type
                    pop_up_button_object = get_children_of_type(pop_up_object,
                                                            "QPushButton")
                    for button_obj in pop_up_button_object:
                        if close_window_text.lower() in str(button_obj.text).lower():
                            # give the time for squish to wait for the next
                            # command
                            squish.snooze(time_out)
                            # mouse press on the middle of the objectOrName
                            # object
                            native_squish_apis.mouse_press(button_obj)
                            # give the time for squish to wait for the next
                            # command
                            squish.snooze(time_out)
                            # release the specified mouse button
                            native_squish_apis.mouse_release(
                                    mouse_button="left_button")
                            button_text_clicked = True
                            break
                        else:
                            button_text_clicked = False
                            logger.write_log(str.format("""{0} text not found
                            in the pop-up continue...""", close_window_text))
            else:
                button_text_clicked = False
                logger.write_log(str.format("""{0} text not found in the
                pop-up...""", found_text))
        else:
            logger.write_log(str.format("Object {0} does not exists...", str(
                                                    pop_up_object)))
        try:
            if (button_text_clicked and
                not native_squish_apis.object_exists(pop_up_object)):
                logger.write_to_result('Pass',
                    "To verify if pop-up can be closed.",
                    "Pop-up can be closed by clicking on the " +
                    str(close_window_text) + " button",
                    "Pop-up is closed by clicking on the " +
                    str(close_window_text) + " button",)
            else:
                logger.write_to_result('Fail',
                    "To verify if pop-up can be closed.",
                    "Pop-up can be closed by clicking on the " +
                    str(close_window_text) + " button",
                    "Pop-up is not closed by clicking on the " +
                    str(close_window_text) + " button",)
        # Handle the LookupError thrown by 'object_exists' Squish API, if any
        except LookupError as lookup_error:
            # If the lookup error is raised because of object not found
            # or because of object not ready, try scrolling down and check
            if(' not found' in str(lookup_error.message) or
               ' not ready' in str(lookup_error.message)):
                logger.write_to_result('Pass',
                    "To verify if pop-up can be closed.",
                    "Pop-up can be closed by clicking on the " +
                    str(close_window_text) + " button",
                    "Pop-up is closed by clicking on the " +
                    str(close_window_text) + " button",)
            else:
                logger.write_to_result('Fail',
                    "To verify if pop-up can be closed.",
                    "Pop-up can be closed by clicking on the " +
                    str(close_window_text) + " button",
                    "Pop-up is not closed by clicking on the " +
                    str(close_window_text) + " button",)
    except Exception as run_time_args:
        raise Exception("general.verify_popup_text_and_close_pop_up(): "
                        + str(run_time_args.message))


def select_item_in_widget_tree_view(text_name='',
                                    write_result=False):
    """
    This function is to select (by clicking) a child object in the widget
    tree view window of FBE main window. The actual name of the child
    (ex: tbw1) should be passed in order to select the default child item
    """
    # Check if 'name' argument is null or not passed and raise exception
    if(text_name == ''):
        raise Exception("general.select_item_in_widget_tree_view(): Name of"
                        " the child to be selected should not be blank")

    try:
        # Scroll to the top, if scroll bar is present, as the default
        # child will be at the top
        qt_convenient_squish_apis.scroll_up_or_down(
                    'FBE_MainWindow_ScrollBar_WidgetTreeViewVerticalScroll',
                    'Up', full=True)
        child_item_in_tree = verify_item_in_widget_tree_view(text_name, False)
        while True:
            try:
                # Try clicking on the child object
                qt_convenient_squish_apis.mouse_click(child_item_in_tree)
                # For screen synchronization
                squish.snooze(1)
                # Check if the 'selected' property of the object has
                # not changed to 'true'
                if child_item_in_tree.selected == False:
                    scroll_flag = qt_convenient_squish_apis.scroll_up_or_down(
                    'FBE_MainWindow_ScrollBar_WidgetTreeViewVerticalScroll',
                    'Down')
                    if scroll_flag == False:
                        raise Exception("Could not select the item in"
                                                " widget tree view")
                        # Continue the while loop
                        continue
                else:
                    item_selected = True
                    logger.write_log("'" + str(text_name) + "' item"
                                             " is selected in widget tree"
                                             " view")
                    return True

            # In case other exception, raise exception
            except Exception as run_time_args:
                raise Exception(str(run_time_args.args))

        if item_selected == False:
            raise Exception("'" + str(text_name) + "' item could not be found"
                            " in the widget tree view parent-child hierarchy")
        # Write log result
        if write_result:
            logger.write_to_result('Pass',
                    "To verify if an item can be selected in the widget tree view",
                    "User should be able to select '" + str(text_name) +
                    " item in the widget tree view",
                    "User is able to select '" + str(text_name) +
                    " item in the widget tree view")

    except Exception as run_time_args:
        raise Exception("general.select_item_in_widget_tree_view(): "
                        + str(run_time_args.message))


def verify_widget_in_widgets_selector(widget_obj_name='', widget_name='',
                                      time_out=MIN_TIMEOUT_VALUE):
    """
    This function is to browse the the widget selector window and check if
    required widget is present in the list. Returns boolean 'True' if found
    and accessible, else returns boolean 'False'
    """
    # Raise exception if widget object name is not passed
    if widget_obj_name == '':
        raise Exception("general.access_widget_in_widgets_list(): Widget "
                        "object name (symbolic name) cannot be empty")

    # If widget verbal name is not passed, use the object name itself as 
    # verbal name to write the result
    if widget_name == '':
        widget_name = widget_obj_name

    # To scroll down page by page and try getting the required widget object
    # reference
    while True:
        try:
            # Scroll to the top, if scroll bar is present, to start from top
            qt_convenient_squish_apis.scroll_up_or_down(
                        'FBE_MainWindow_ScrollBar_WidgetsVerticalScroll',
                        'Up', full=True)
            # Try to get the required widget object's reference. If successful
            # without any exceptions, return True
            widget_obj_ref = native_squish_apis.wait_for_object(
                                widget_obj_name, time_out)
            logger.write_to_result('Pass', "To verify if '" +
                str(widget_name) + "' is shown in the widget selector of the"
                " editor", "'" + str(widget_name) + "' should be available in"
                " the widget selector", "'" + str(widget_name) + "' is "
                "available in widget selector")
            
            break

        # Handle the LookupError thrown by 'watForObject' Squish API, if any
        except LookupError as lookup_error:
            # If the lookup error is raised because of object not found
            # or because of object not ready, try scrolling down and check
            if(' not found' in str(lookup_error.message) or
               ' not ready' in str(lookup_error.message)):
                scroll_flag = qt_convenient_squish_apis.scroll_up_or_down(
                            'FBE_MainWindow_ScrollBar_WidgetsVerticalScroll',
                            'Down')

                # If scroll is False means end of scroll. Write the message
                # accordingly and return False
                if scroll_flag == False:
                    logger.write_log(
                        "general.verify_widget_in_widgets_selector(): Reached"
                        " end of widget selector. '" + str(widget_obj_name) +
                        "' object could not be found/not ready")

                logger.write_to_result('Fail', "To verify if '" +
                    str(widget_name) + "' is shown in the widget selector of "
                    "the editor", "'" + str(widget_name) + "' should be "
                    "available in widget selector", "'" + str(widget_name) +
                    "' is available in widget selector")
                
                break

            # If the LooupError was raised because of some other exception,
            # raise exception with that error message
            else:
                raise Exception("general.verify_widget_in_widgets_selector(): "
                                + str(lookup_error.message))

        # Handle all other exceptions other than 'LookupError' exception
        except Exception as vwiws_runtime_args:
            raise Exception("general.verify_widget_in_widgets_selector(): "
                            + str(vwiws_runtime_args.message))


def verify_widget_drag_and_drop(widget_obj='',
                         target_obj='FBE_MainWindow_SubContainer_EditorForm',
                         tab_obj='FBE_MainWindow_DefaultFirstChild_TBP2',
                         widget_name='', target_name='',
                         target_x_coord=0, target_y_coord=0):
    """
    This function is to drag and drop a widget from one place to another.
    This function makes use of 'qt_convenient_squish_apis.drag_and_drop'
    API. It returns boolean True if the object drag and drop is successful,
    which is verified by increment or decrement of entries in widget tree
    view container.
    """
    # Assign right value to the widget name and target name
    if widget_name == '':
        widget_name = widget_obj
    if target_name == '':
        target_name = target_obj
    while True:
        try:
            # Get the number of QModelIndex children present under root object
            initial_children = len(get_children_of_type(
                                    tab_obj,
                                    'QModelIndex', 5))
            # Drag and drop the required widget
            qt_convenient_squish_apis.drag_and_drop(widget_obj, target_obj,
                                            target_x_coord, target_y_coord)
            # Get the number of QModelIndex children present under root object
            final_children = len(get_children_of_type(
                                    tab_obj,
                                    'QModelIndex', 5))

            # If there is a change in the number of children under default
            # first child in widget tree view, drag drag and drop was
            # successful! Write success message to the log and return True
            if final_children != initial_children:
                logger.write_to_result('Pass',
                    "To verify if '" + str(widget_name) + "' can be dragged "
                    "and dropped on to '" + str(target_name) + "'",
                    "User should be able to drag and drop '"
                    + str(widget_name) + "' onto '" + str(target_name) + "'",
                    "User is able to drag and drop '" + str(widget_name) + "'"
                    " onto '" + str(target_name) + "'")

                return True

            else:
                status = False

                # If the request was to drag and drop the widget from widget
                # selector to edit form, retry by scrolling down the widget
                # selector by one page. Else raise exception
                if target_obj == 'FBE_MainWindow_SubContainer_EditorForm':
                    status = qt_convenient_squish_apis.scroll_up_or_down(
                            'FBE_MainWindow_ScrollBar_WidgetsVerticalScroll',
                            'Down')

                if status == False:
                    raise Exception("'" + str(widget_name) + "' widget "
                            "could not be dragged and dropped onto '"
                            + str(target_name) + "'")

        except Exception as dadw_runtime_args:
            raise Exception("general.drag_and_drop_widget(): "
                            + str(dadw_runtime_args.message))


def verify_properties_in_editor(expected_properties=[]):
    """
    This function is to verify the properties displayed in the FBE editor
    window for a selected widget. The list of expected property names should
    be passed as an argument.
    """
    # Raise exception if expected properties list is empty
    if expected_properties == []:
        raise Exception("general.verify_properties_in_editor(): The expected"
                        " properties list should not be empty")

    try:
        # Raise exception if properties display window object does not exist
        if not native_squish_apis.object_exists(
                        'FBE_MainWindow_PropertiesDisplayWindowWithScroll',
                        MAX_TIME_OUT):
            raise Exception("general.verify_properties_in_editor(): "
                        "'FBE_MainWindow_PropertiesDisplayWindowWithScroll' "
                        "object does not exist in the screen")

        # Get 'QModelIndex' children from properties display window object
        qmodelindex_children = get_children_of_type(
                        'FBE_MainWindow_PropertiesDisplayWindowWithScroll',
                        'QModelIndex', 1)
        # List variable to hold actual property names
        actual_properties_name = []
        # List variable to hold actual property values of type editable
        actual_properties_values = []
        # Dictionary variable to hold actual property names and values
        actual_properties = {}
        # declare a integer to control the loop
        index = 0
        # Loop through each child in QModelIndex children and get the list
        # of actual property names
        for child in qmodelindex_children:
            # The property name child will have column value as 0. Get it and
            # append it to actual property names list
            if child.column == 0:
                actual_properties_name.append(str(child.text).upper())
                index += 1
            if child.column == 1:
                actual_properties_values.append(str(child.editable).upper())
                actual_properties[actual_properties_name[index-1]] = actual_properties_values[index-1]
        # declare a list for holding the property names
        expected_properties_dict = {}
        # loop through the whole list to get the property names and their
        # corresponding property values
        for expected_item in expected_properties:
            # generate a temporary list to contain the property name and
            # value
            temp_list = expected_item.split(':')
            if len(temp_list) == 2:
                # add the first item in the temporary list(property names) to
                # expected_properties_dict as the key and second item in
                # temporary list(property names) as the value
                expected_properties_dict[str(temp_list[0]).upper()] = str(
                                                        temp_list[1]).upper()
            else:
                expected_properties_dict[str(expected_item).upper()] = "TRUE"
        # If the length of actual properties list is not same as expected
        # properties list, write step failure log and return from the function
        if not len(actual_properties) == len(expected_properties_dict):
            logger.write_to_result('Fail', 'To verify the exposed properties',
                                   "Expected properties to be displayed: "
                                   + str(expected_properties_dict),
                                   "Actual properties displayed: "
                                   + str(actual_properties))
            return

        # order the dictionary according to the key name
        expected_properties_dict = OrderedDict(sorted(
                                            expected_properties_dict.items()))
        # order the dictionary according to the key name
        actual_properties = OrderedDict(sorted(actual_properties.items()))

        # check for each actual property exists as expected.
        for expected_property_key, expected_property_value in expected_properties_dict.items():
            for actual_property_key, actual_property_value in actual_properties.items():
                if actual_property_key == expected_property_key:
                    if not actual_property_value == expected_property_value:
                        logger.write_to_result('Fail',
                                    'To verify the exposed properties',
                                    "Expected properties to be displayed: "
                                   + str(
                        expected_property_key + ":" + expected_property_value),
                                   "Actual properties displayed: "
                                   + str(
                        actual_property_key + ":" + actual_property_value))
                        break
                    else:
                        logger.write_to_result('Pass',
                                   'To verify the exposed properties',
                                   "Expected properties to be displayed: "
                                   + str(
                        expected_property_key + ":" + expected_property_value),
                                   "Actual properties displayed: "
                                   + str(
                        actual_property_key + ":" + actual_property_value))

    except Exception as vpie_runtime_args:
        raise Exception("general.verify_properties_in_editor(): "
                        + str(vpie_runtime_args.message))


def verify_widget_deletion(widget_obj='', widget_name=''):
    """
    This function is to click on the passed widget object and delete from the
     editor form. Also writes the result accordingly.
    """
    # Raise exception if widget object is passed
    if widget_obj == '':
        raise Exception("general.verify_widget_deletion(): Widget to be "
                        "deleted should not be blank.")

    # Assign right value to the widget name
    if widget_name == '':
        widget_name = widget_obj

    try:
        # Get the number of QModelIndex children present under default child 
        # in the widget tree view
        initial_children = len(get_children_of_type(
                                'FBE_MainWindow_DefaultFirstChild_TBP2',
                                'QModelIndex', 5))
        # Mouse click on the passed widget
        qt_convenient_squish_apis.mouse_click(widget_obj)
        # Delete the widget by pressing 'Delete' key
        qt_convenient_squish_apis.type(widget_obj, '<Delete>')
        # Get the number of QModelIndex children present under default child 
        # in the widget tree view
        final_children = len(get_children_of_type(
                                'FBE_MainWindow_DefaultFirstChild_TBP2',
                                'QModelIndex', 5))
        
        # If there is a change in the number of children under default
        # first child in widget tree view, deletion was successful! Write
        # success message to the log and return True
        if final_children != initial_children:
            logger.write_to_result('Pass',
                "To verify if '" + str(widget_name) + "' can be deleted "
                "from 'Editor Form' by selecting and pressing 'Delete' key",
                "User should be able to delete '" + str(widget_name) +
                "' from 'Editor Form' by selecting and pressing 'Delete' key",
                "User is able to delete '" + str(widget_name) + "' from"
                " 'Editor Form' by selecting and pressing 'Delete' key")

            return True

        else:
            raise Exception("'" + str(widget_name) + "' could not be deleted"
                            " from 'Editor Form' by selecting and pressing "
                            "'Delete' key")
            
    except Exception as vwd_runtime_args:
        raise Exception("general.verify_widget_deletion(): "
                        + str(vwd_runtime_args))


def update_property_value_in_editor(widget_name='', property_name='',
                                    value_to_be_set='', write_result=False):
    """
    This function is an abstract function which in turn calls
    'update_property_value'. The property parent object, which is an 
    extract parameter in 'update_property_value', here will be the 
    properties display window in the editor.
    """
    try:
        # Assign the properties display window object as property parent obj
        prop_parent_obj = 'FBE_MainWindow_PropertiesDisplayWindowWithScroll'
        # Call 'update_property_value' API
        update_property_value(widget_name, prop_parent_obj, property_name,
                              value_to_be_set, write_result)
        
    except Exception as upvip_runtime_args:
        raise Exception("general.update_property_value_in_editor"
                        + str(upvip_runtime_args.message))


def update_property_value_in_form_properties(widget_name='', property_name='',
                                value_to_be_set='', write_result=False):
    """
    This function is an abstract function which in turn calls
    'update_property_value'. The property parent object, which is an 
    extract parameter in 'update_property_value', here will be the 
    properties display window in the editor.
    """
    try:
        # Assign the properties display window object as property parent obj
        prop_parent_obj = 'FBE_FormPropertiesPopup_PropertiesDisplayAreaWithScroll'
        # Call 'update_property_value' API
        update_property_value(widget_name, prop_parent_obj, property_name,
                              value_to_be_set, write_result)
    except Exception as upvip_runtime_args:
        raise Exception("general.update_property_value_in_editor"
                        + str(upvip_runtime_args.message))


def update_property_value(widget_name='', prop_parent_obj='',
                          property_name='', value_to_be_set='',
                          write_result=False):
    """
    This function is to update a specific property value present under
    the 'Properties' column in the editor form. If requires, it also
    writes the result(pass/exception) to Squish log.
    widget_name = Name of the widget who's property value should be
        updated. The name should be exactly same as the class name
        present in 'gui_classes' module.
        Ex: 'TableWidget', 'GraphicsView'
    property_name = Name of the property who's value should
        be updated. The name should be same as in the 'Properties'
        column of the editor form but case-insensitive and without
        spaces in between the words.
        Ex: 'ToolTipEnable', 'StyleSheetClass'
    value_to_be_set = Value to be set for the required property. Should be a
        string value and should be same as the value present in the
        'Properties' column of the editor form.
        Ex: '100', 'true', 'green'
    write_result = Should be boolean True if result needs to written
        to Squish log. Else boolean False.
    """
    # Raise exception if any of the argument is not passed
    if(widget_name == '' or property_name == '' or value_to_be_set == ''):
        raise Exception("general.update_property_value_in_editor(): Name of "
                        "the widget, property name to be updated and value "
                        "cannot be blank.")

    # If property object is not passed, let us assume the changes to be made
    # in editor form. Assign the parent accordingly
    if prop_parent_obj == '':
        prop_parent_obj = 'FBE_MainWindow_PropertiesDisplayWindowWithScroll'

    try:
        # Convert the property name to lower case string
        property_name = property_name.lower()
        # Create an instance of the required class based on widget_name
        class_name = globals()[widget_name]
        required_instance = class_name()
        # Get the required property object using the instance created
        property_obj = __builtin__.getattr(required_instance, property_name)
        #method to set a object values depending on the type of object
        if not _set_object_value(property_obj, property_name, value_to_be_set,
                     prop_parent_obj):
            raise Exception("'" + str(property_name) + "' property value "
                        "could not be set to '" + str(value_to_be_set) +
                        "' in the editor form")
        # Write log result
        if write_result:
            logger.write_to_result('Pass',
                    "To verify if '" + str(property_name) + "' property "
                    "value can be set to '" + str(value_to_be_set) +
                    "' in editor form",
                    "User should be able to set '" + str(property_name) +
                    "' property value to '" + str(value_to_be_set) + "'",
                    "User is able to set '" + str(property_name) + "' "
                    "property value to '" + str(value_to_be_set) + "'")

    except Exception as runtime_runtime_args:
        raise Exception("general.update_property_value_in_editor(): "
                        + str(runtime_runtime_args.message))


def get_path(folder_name):
    """
    Method to get the path of the user defined folder type.
    """
    try:
        # create an instance of the class gui_classes.GetPath()
        get_path_name = gui_classes.GetPath()
        # using the instance call the get_path method from the class
        # to get the complete path name
        complete_path_name = get_path_name.get_path(folder_name)
        return complete_path_name
    except Exception as run_runtime_args:
        raise Exception("general.get_path(): "
                        + str(run_runtime_args))


def get_name(folder_name):
    """
    Method to get the name of the user defined folder.
    """
    try:
        # create an instance of the class gui_classes.GetName()
        get_folder_name = gui_classes.GetName()
        # using the instance call the get_name method from the class
        # to get the complete path name
        return_folder_name = get_folder_name.get_name(folder_name)
        return return_folder_name
    except Exception as run_runtime_args:
        raise Exception("general.get_name(): "
                        + str(run_runtime_args))


def go_to_menu_item(menu_name='', menu_item_name=''):
    """
    This function is to select a required menu item from the top menu
    bar of editor form.
    
    menu_name = Name of the menu from which an item needs to be selected
            Ex: 'Tools'
    menu_item_name =  Name of the item to be selected from the menu drop
            down box
            Ex: 'Preview'
    """
    try:
        # Activate the required menu in the top menu bar
        qt_convenient_squish_apis.activate_item(
                                    'FBE_MainWindow_Container_TopMenuBar',
                                    menu_name)
        logger.write_log("Selected '" + str(menu_name) + "' in top menu bar")
        # Dictionary of menu names and corresponding drop down objects
        drop_down_objects = {
                        'Edit': 'FBE_MainWindow_DropDownWindow_EditMenu',
                        'File': 'FBE_MainWindow_DropDownWindow_FileMenu',
                        'Tools': 'FBE_MainWindow_DropDownWindow_ToolsMenu'}
        # For screen stabilization
        squish.snooze(1)
        # Activate the required menu item from the drop down window
        qt_convenient_squish_apis.activate_item(drop_down_objects[menu_name],
                                                menu_item_name)
        logger.write_log("Selected '" + str(menu_item_name) + "' menu item")

    except Exception as run_time_args:
        raise Exception("general.go_to_menu_item(): "
                        + str(run_time_args.message))


def verify_properties_in_preview(tab_obj_id='tbp2', widget_name='',
                                 widget_id='', expected_prop_value={},
                                 write_result=False):
    """
    This function is to verify the property names and corresponding 
    values of a widget in 'Preview' window. In case of failure, i.e.,
    if a property name is not found or property value is mismatching,
    by default failure log will written. In case of writing log result
    for pass scenarios, it is optional.
    tab_obj_id = The 'ID' property value of a tab in which the widget
            is present. It should be as displayed in editor form
            Ex: 'tbp2' for default tab
    widget_id = The 'ID' property value of a widget who's property 
            names and values needs to be verified in preview window.
            It should be as displayed in editor form
            Ex: 'btn29'
    expected_prop_value = Dictionary of property name (as displayed in 
            the preview window) and property values to be verified.
            Ex: {'x': 180, 'y': 213, 'width': 200}
    write_result = Should be boolean True if log result needs to be
            written. Else, boolean False
    """
    try:
        # Method to traverse to the tab object id provided
        widget_children = go_to_preview_screen(tab_obj_id)
        # Variable to hold the required widget object
        required_widget = ''

        # Loop through all widget children and obtain the required widget
        # child who's properties needs to be verified
        for widget_child in widget_children:
            try:
                if str(widget_child.objectName) == widget_id:
                    required_widget = widget_child
                    break
            except Exception as runtime_Exception:
                if "No such Property" in runtime_Exception.message:
                    pass
        # If user has not passed any expected property and values, then just
        # verify if the widget is visible in Preview window and write the result
        if expected_prop_value == {}:
            if required_widget != '':
                logger.write_to_result("Pass",
                    "To verify if '" + str(widget_id) + "' widget added to "
                    "form in the editor is visible in 'Preview' window",
                    "The '" + str(widget_id) + "' widget added to form in "
                    "the editor should be visible in 'Preview' window",
                    "The '" + str(widget_id) + "' widget added to form in "
                    "the editor is visible in 'Preview' window")
            else:
                logger.write_to_result("Fail",
                    "To verify if '" + str(widget_id) + "' widget added to "
                    "form in the editor is visible in 'Preview' window",
                    "The '" + str(widget_id) + "' widget added to form in "
                    "the editor should be visible in 'Preview' window",
                    "The '" + str(widget_id) + "' widget added to form in "
                    "the editor is not visible in 'Preview' window")

            # For screen stabilization
            squish.snooze(1)
            # Close the 'Preview' window
            close_preview()

            return

        # Get the class name from the globals using the widget name
        class_name = globals()[widget_name]
        # Create an instance of the class
        required_instance = class_name()
        # Get the properties map of the widget using the instance
        properties_map = __builtin__.getattr(required_instance,
                                             'properties_map')

        key_not_found = False
        value_mismatch = False
        actual = {}
        expected = {}
        expected_key = []

        # Loop through expected property-value dictionary
        for property_name, expected_value in expected_prop_value.iteritems():
            # Check if the expected property is present in the properties map
            # of the widget
            if property_name.lower() in str(properties_map.keys()):
                # Get the actual property value
                actual_value = get_property_value_in_preview(required_widget,
                                        properties_map[property_name.lower()])
                # If the actual value and expected value are not matching
                # note down the property name and values to write in log
                if str(expected_value.lower()) != str(actual_value.lower()):
                    expected[property_name] = expected_value
                    actual[property_name] = actual_value
                    value_mismatch = True
            else:
                expected_key.append(property_name)
                key_not_found = True

        if write_result:
            # If any of the property name is not found, write failure
            # message log accordingly
            if key_not_found:
                logger.write_to_result('Fail',
                    "To verify the property name(s) and corresponding "
                    "value(s) of the widget in 'Preview' window",
                    "Property name(s) and corresponding value(s) of the "
                    "widget should be verified in the 'Preview' window",
                    str(expected_key) + " property name(s) was/were "
                    "not found in the 'Preview' window")

            # If any of the property value is mismatched, write failure
            # message log accordingly
            if value_mismatch:
                logger.write_to_result('Fail',
                    "To verify the property name(s) and corresponding "
                    "value(s) of the widget in 'Preview' window",
                    "Property name(s) and corresponding value(s) of the "
                    "widget should be verified in the 'Preview' window",
                    "Mismatch in one or more property values.\n"
                    "Expected: " + str(expected) + "\n"
                    "Actual: " + str(actual))

            else:
                logger.write_to_result('Pass',
                    "To verify the property name(s) and corresponding "
                    "value(s) of the widget in 'Preview' window",
                    "Property name(s) and corresponding value(s) of the "
                    "widget should be verified in the 'Preview' window",
                    "Property names and corresponding values verified: "
                    + str(expected_prop_value))

        # For screen stabilization
        squish.snooze(1)
        # Close the 'Preview' window
        close_preview()

    except Exception as vip_runtime_args:
        raise Exception("general.verify_properties_in_preview(): "
                        + str(vip_runtime_args))


def verify_properties(widget_name, property_name,
                          property_value, property_type=None,
                          pop_up_object=None, verify_property_set=True):
    try:
        # Create an instance of the required class based on widget_name
        class_name = globals()[widget_name]
        required_instance = class_name()
        # Get the required property object using the instance created
        property_obj = __builtin__.getattr(required_instance,
                                           property_name.lower())
        if property_type == None:
            if "type='QSpinBox'" in property_obj:
                property_type = "QSpinBox"
            elif "type='QModelIndex'" in property_obj:
                property_type = "QModelIndex"
            elif "type='QComboBox'" in property_obj:
                property_type = "QComboBox"
            elif "type='QPushButton'" in property_obj:
                property_type = "QPushButton"
        #call this method to enter a text value
        _verify_property_value(property_obj, property_value,
                              verify_property_set, property_type)
    except Exception as run_time_args:
        raise Exception("general.verify_properties(): "
                        + str(run_time_args.message))


def _verify_property_value(property_object, property_value,
                               verify_property_set, verify_by_property,
                               latest_property_object=None,
                               time_out=2):
    try:
        # check if the property just set has to be verified now
        if(verify_property_set):
            #verify the object of property exists
            if((native_squish_apis.object_exists(property_object)) & (
                                                verify_property_set)):
                if latest_property_object == None:
                    #get the latest object properties of the given object
                    latest_property_object = native_squish_apis.wait_for_object(
                                                            property_object)
                if(verify_by_property == "QModelIndex"):
                    # get the text property and convert to lower case
                    property_text_value = str(latest_property_object.text).lower()
                    # get the text property which was set and convert to lower case
                    current_property_set = str(property_value).lower()
                elif(verify_by_property == "QSpinBox"):
                    # get the text property and convert to lower case
                    property_text_value = str(latest_property_object.text)
                    # get the text property which was set and convert to lower case
                    current_property_set = property_value
                elif(verify_by_property == "QComboBox"):
                    # get the text property and convert to lower case
                    property_text_value = str(
                        latest_property_object.currentText).lower()
                    # get the text property which was set and convert to lower case
                    current_property_set = str(property_value).lower()
                elif(verify_by_property == "Editable"):
                    # get the text property and convert to lower case
                    property_text_value = str(latest_property_object.editable).lower()
                    # get the text property which was set and convert to lower case
                    current_property_set = str(property_value).lower()
                elif(verify_by_property == "QPushButton"):
                    #give the time for squish to wait for the next command
                    squish.snooze(time_out)
                    #method verify with the VP name provided
                    if(preview.verify_with_vp("form_" + str(property_value))):
                        logger.write_to_result('Pass',
                                   'To verify the image',
                                   "Expected image name "
                                   + str(property_value),
                                   "Actual image found on widget "
                                   + str(property_value))
                    else:
                        logger.write_to_result('Pass',
                                   'To verify the image',
                                   "Expected image name "
                                   + str(property_value),
                                   "Actual image found on widget "
                                   + str(property_value))
                # compare the set value and current text values of the object
                if(property_text_value == current_property_set):
                        logger.write_to_result('Pass',
                                   'To verify the exposed property',
                                   "Expected property value is "
                                   + str(current_property_set),
                                   "Actual property is "
                                   + str(property_text_value))
                else:
                        logger.write_to_result('Fail',
                                   'To verify the exposed property',
                                   "Expected property value is "
                                   + str(current_property_set),
                                   "Actual property is "
                                   + str(property_text_value))
            else:
                raise Exception(str.format("Object Not found : {0}",
                                       property_object))
        else:
            logger.write_log("""Verification not required...""")
    except Exception as run_time_args:
        if "not ready" in run_time_args.message:
            #get the latest object properties of the given object
            latest_property_object = native_squish_apis.find_object(
                                                            property_object)
            _verify_property_value(property_object, property_value,
                               verify_property_set, verify_by_property,
                               latest_property_object)
        else:
            raise Exception("general.verify_property_value(): "
                        + str(run_time_args.message))


def verify_properties_of_preview_window(expected_prop_value={},
                                 write_result=False):
    """
    This method is used to verify the property of the preview window
    itself(not for verifying properties of items in preview).
    It take the property name and property value to be verified and checks
    they are as expected or not. If property values not matching the method
    can return or write_result.
    property_name - name of the property to be verified.
    property_value - value of the property which has to be verified.
    write_result - can be set to boolean True if log result needs to be
            written.otherwise, can be set to boolean False
    """
    try:
        if (len(expected_prop_value.items()) == 0):
            raise Exception("""Please provide the property keys and values
                                and try again...""")
        # declare a variable to hold the preview screen object
        preview_main_window = "FBE_PreviewWindow_Screen"
        # Go to Preview screen
        go_to_menu_item('Tools', 'Preview')
        #verify for the Preview window object
        if(native_squish_apis.object_exists(preview_main_window)):
            latest_object_properties = native_squish_apis.wait_for_object(
                        "FBE_PreviewWindow_Container_AllWidgets")
            for property_name, property_value in expected_prop_value.items():
                if str(latest_object_properties[property_name.lower()]).lower() == str(
                                                            property_value):
                    if write_result:
                        logger.write_to_result('Pass',
                                   'To verify the exposed property',
                                   'Expected property value of ' + str(
                                   property_name) + ' is ' +
                                   str(property_value),
                                   'Actual property value of ' + str(
                                   property_name) + ' is ' +
                                   str(latest_object_properties[property_name.lower()]).lower())
                    else:
                        logger.write_log("Actual and Expected values are equal...")
                        return True
                else:
                    if write_result:
                        logger.write_to_result('Fail',
                                   'To verify the exposed property',
                                   "Expected property value of " + str(
                                   property_name) + " is " +
                                   str(property_value),
                                   "Actual property value of " + str(
                                   property_name) + " is " +
                                   str(latest_object_properties[property_name.lower()]).lower())
                    else:
                        logger.write_log("""Expected and Actual property values
                                           are not equal""")
                        return False
        else:
            raise Exception(str.format("object {0} does not exists",
                            preview_main_window))
    except Exception as run_time_args:
        raise Exception("general.verify_properties_of_preview(): "
                        + str(run_time_args.message))


def close_preview():
    """
    This function is to close the 'Preview' window by click on the
    'Close' button in the top right corner of the window.
    """
    try:
        # Call 'send_event' API
        qt_convenient_squish_apis.send_event('QCloseEvent',
                                             'FBE_PreviewWindow_Screen')
        logger.write_log("Closed 'Preview' window by clicking on 'Close' button")

    except Exception as run_time_args:
        raise Exception("general.close_preview(): "
                        + str(run_time_args.message))


def verify_object_text(object_name, object_text_value,
                       write_result=False,  time_out=1):
    """
    Method to verify the text of any object provided by the user.
    object_name - name of the object as mentioned in the object map.
    object_text_value - text value of the object to be verified.
    write_result - decides whether to write the result from this
    API or not, just pass the result.
    time_out - total time out for snooze operations
    """
    try:
        latest_property_object = None
        try:
            #get the latest object properties of the given object
            latest_property_object = native_squish_apis.wait_for_object(
                                                            object_name)
            # get the real name of the object from the object.map file
            obj_real_name = get_real_name_of_object(object_name)
        # Handle the LookupError thrown by 'object_exists' Squish API, if any
        except LookupError as lookup_error:
            # If the lookup error is raised because of object not found
            # or because of object not ready, try scrolling down and check
            if(' not found' in str(lookup_error.message) or
               ' not ready' in str(lookup_error.message)):
                logger.write_log(str.format("Object {0} is not in focus",
                                            obj_real_name))
                return False
            else:
                raise Exception(str.format("Object {0} not found...",
                                           str(object_name)))
        if("QModelIndex" in obj_real_name) or (
                            "QSpinBox" in obj_real_name) or (
                            "QPushButton" in obj_real_name):
            # get the text property and convert to lower case
            actual_text_value = str(latest_property_object.text).lower()
            # get the text property which was set and convert to lower case
            current_text_set = str(object_text_value).lower()
        elif("QComboBox" in obj_real_name):
            # get the text property and convert to lower case
            actual_text_value = str(
                        latest_property_object.currentText).lower()
            # get the text property which was set and convert to lower case
            current_text_set = str(object_text_value).lower()
        # compare the set value and current text values of the object
        if(actual_text_value == current_text_set):
            if write_result:
                logger.write_to_result('Pass',
                    str.format("""To verify {0} of the object {1}""",
                               current_text_set, str(obj_real_name)),
                    str.format("Expected Object {0} should contain text {1}",
                    str(obj_real_name), current_text_set),
                    str.format("Actual Object {0} contains text {1}",
                    str(obj_real_name), actual_text_value))
            else:
                logger.write_log(str.format("Object {0} with text {1} exists",
                                        obj_real_name, actual_text_value))
                return True
        else:
            if write_result:
                logger.write_to_result('Fail',
                    str.format("""To verify {0} of the object {1}""",
                               current_text_set, str(obj_real_name)),
                    str.format("Expected Object {0} should contain text {1}",
                    str(obj_real_name), current_text_set),
                    str.format("Actual Object {0} does not contain text {1}",
                    str(obj_real_name), actual_text_value))
            else:
                logger.write_log(str.format("""Object {0} with text {1} does
                            not exists""", str(obj_real_name), actual_text_value))
                return False
    except Exception as run_time_args:
        raise Exception("general._verify_object_text(): "
                        + str(run_time_args.message))


def close_pop_up(object_name, write_result=False, time_out=1):
    """
    Method to close a pop-up with the object id of the pop-up
    button whioch has to be pressed.
    object_name - name of the object as mentioned in the object map.
    write_result - decides wheather to write the result from this
    API or not, just pass the result.
    time_out - total time out for snooze operations.
    """
    try:
        # call the native_squish_apis object exists API to verify the
        # existence of the object
        if(native_squish_apis.object_exists(object_name)):
            # give the time for squish to wait for the next command
            squish.snooze(time_out)
            # mouse press on the middle of the objectOrName
                            # object
            native_squish_apis.mouse_press(object_name)
            # give the time for squish to wait for the next command
            squish.snooze(time_out)
            # release the specified mouse button
            native_squish_apis.mouse_release(
                                    mouse_button="left_button")
            # give the time for squish to wait for the next command
            squish.snooze(time_out)
            if write_result:
                try:
                    if not native_squish_apis.object_exists(object_name):
                        logger.write_to_result('Pass',
                                "To verify if pop-up can be closed.",
                                "Pop-up can be closed by clicking on the " +
                                 str(object_name) + " object",
                                 "Pop-up is closed by clicking on the " +
                                 str(object_name) + " object")
                    else:
                        logger.write_to_result('Fail',
                                "To verify if pop-up can be closed.",
                                "Pop-up can be closed by clicking on the " +
                                str(object_name) + " object",
                                "Pop-up is not closed by clicking on the " +
                                str(object_name) + " object")
                # Handle the LookupError thrown by 'object_exists' Squish API,
                # if any
                except LookupError as lookup_error:
                    # If the lookup error is raised because of object not found
                    # or because of object not ready, try scrolling down and
                    # check
                    if(' not found' in str(lookup_error.message) or
                       ' not ready' in str(lookup_error.message)):
                        logger.write_to_result('Pass',
                                "To verify if pop-up can be closed.",
                                "Pop-up can be closed by clicking on the " +
                                str(object_name) + " object",
                                "Pop-up is closed by clicking on the " +
                                str(object_name) + " object")
                    else:
                        logger.write_to_result('Fail',
                                "To verify if pop-up can be closed.",
                                "Pop-up can be closed by clicking on the " +
                                str(object_name) + " object",
                                "Pop-up is not closed by clicking on the " +
                                str(object_name) + " object")
            else:
                logger.write_log(str.format("""Object {0} exists""",
                                            object_name))
        else:
            raise Exception(str.format("""Object {0} does
                            not exists""", object_name))
    except Exception as run_time_args:
        raise Exception("general.close_pop_up(): "
                        + str(run_time_args.message))


def select_context_menu_item(property_obj='', value_to_be_set='', time_out=1):
    try:
        # give the time for squish to wait for the next command
        squish.snooze(time_out)
        # method to open the context menu
        open_context_menu_item(property_obj, time_out)
        # give the time for squish to wait for the next command
        squish.snooze(time_out)
        qt_convenient_squish_apis.activate_item("FBE_MainWindow_ContextMenu",
                                                value_to_be_set)
    except Exception as run_time_args:
        raise Exception("general.open_context_menu(): "
                        + str(run_time_args.message))


def get_real_name_of_object(property_obj):
    """
    This function returns the real (multi-property) name for the given object,
    or for the object with the given symbolicName.
    property_obj - Symbolic name of object.
    """
    try:
        #check whether the object exists
        if(native_squish_apis.object_exists(property_obj)):
            #wait for the object to become active
            latest_property_obj = native_squish_apis.wait_for_object(
                                                        property_obj)
            x = objectMap.realName(latest_property_obj)
            return x
    except Exception as run_runtime_args:
        raise Exception("general.get_path(): "
                        + str(run_runtime_args))


def _set_object_value(property_obj='', property_name='', value_to_be_set='',
                     prop_parent_obj='', time_out=1):
    """
    This function is to update the value of an object with its name
    If requires, it also writes the result(pass/exception) to Squish log.
    widget_name = Name of the widget who's property value should be
        updated. The name should be exactly same as the class name
        present in 'gui_classes' module.
        Ex: 'TableWidget', 'GraphicsView'
    property_name = Name of the property who's value should
        be updated. The name should be same as in the 'Properties'
        column of the editor form but case-insensitive and without
        spaces in between the words.
        Ex: 'ToolTipEnable', 'StyleSheetClass'
    value_to_be_set = Value to be set for the required property. Should be a
        string value and should be same as the value present in the
        'Properties' column of the editor form.
        Ex: '100', 'true', 'green'.
    prop_parent_obj = parent object for forming the dynamic object names
        for its children. Mainly used for objects of type QModelIndex.
    """
    try:
        # Check if the property object, who's value needs to be update, is of
        # type 'QSpinBox'
        if "type='QSpinBox'" in property_obj or "type='QWidget'" in property_obj:
            # Get the first 'QLineEdit' child from the property object
            line_edit_obj = get_children_of_type(property_obj,
                                                 'QLineEdit', 1)[0]
            # Get the current text value of 'QLineEdit' object
            initial_text = str(line_edit_obj.text)
            # Write squish log if the current value is same as value to be set
            # and return from the function
            if initial_text == value_to_be_set:
                logger.write_log("'" + str(property_name) + "' property value"
                        " is already set to '" + str(value_to_be_set) + "'")
                return True

            # Double click on the object to select existing value
            qt_convenient_squish_apis.double_click(line_edit_obj)
            qt_convenient_squish_apis.mouse_click(line_edit_obj)
            # Enter the value to be updated
            qt_convenient_squish_apis.type(line_edit_obj, value_to_be_set)
            # Get the text value of 'QLineEdit' object after updating
            updated_text = str(line_edit_obj.text)

            # Raise exception if the desired property value is not updated
            # required value
            if not updated_text == value_to_be_set:
                return False
            else:
                return True

        # Check if the property object, who's value needs to be update, is of
        # type 'QSpinBox'
        elif "type='QComboBox'" in property_obj:
            # Get the property object reference
            property_obj_ref = native_squish_apis.wait_for_object(
                                                        property_obj, 2)
            # Get the current text value of the required property
            initial_text = str(property_obj_ref.currentText)

            # Write squish log if the current value is same as value to be set
            # and return from the function
            if initial_text == value_to_be_set:
                logger.write_log("'" + str(property_name) + "' property value"
                        " is already set to '" + str(value_to_be_set) + "'")
                return True

            # Click on the property object
            qt_convenient_squish_apis.mouse_click(property_obj_ref)
            # Get the item identifier (value to be list) reference
            item_ref = native_squish_apis.wait_for_object_item(
                                                        property_obj_ref,
                                                        value_to_be_set)
            # Click on the obtained item identifier reference
            qt_convenient_squish_apis.mouse_click(item_ref)
            # Get the property object reference
            property_obj_ref = native_squish_apis.wait_for_object(
                                                        property_obj, 2)
            # Get the current text value of the required property
            updated_text = str(property_obj_ref.currentText)

            # Raise exception if the current value of the required
            # property is not same as the value to be set
            if not updated_text == value_to_be_set:
                return False
            else:
                return True

        # Check if the property object, who's value needs to be update, is of
        # type 'QModelIndex'
        elif "type='QModelIndex'" in property_obj:
            # Get 'QModelIndex' children from properties editor object
            qmodel_children = get_children_of_type(prop_parent_obj,
                                                   'QModelIndex', 1)

            # Parse all of the 'QModelIndex' children obtained above
            for child in qmodel_children:
                # Check if the column count of the current child is 0
                # (property name lies in the column 0). If yes, check if it is
                # the required property name
                if(child.column == 0 and
                   str(child.text).lower() == property_name.lower()):
                    # Get the current child's row number
                    row = child.row
                    # Assign current row number to the 'QExpandingLineEdit'
                    # static object to get the required value object
                    value_obj = ("{columnIndex='1' container=':"
                                 + str(prop_parent_obj) + "' rowIndex='"
                                 + str(row) + "' type='QExpandingLineEdit' "
                                 "unnamed='1' visible='1'}")
                    break

            # Get the current text of the property value
            initial_text = str(native_squish_apis.wait_for_object_item(
                                                    prop_parent_obj,
                                                    str(row) + "/1").text)
            # Write squish log if the current value is same as value to be set
            # and return from the function
            if initial_text == value_to_be_set:
                logger.write_log("'" + str(property_name) + "' property value"
                        " is already set to '" + str(value_to_be_set) + "'")
                return True

            # Double click on the required property value to update
            qt_convenient_squish_apis.double_click_item(prop_parent_obj,
                                                        str(row) + "/1")
            # Update the required value to the property value
            qt_convenient_squish_apis.type(value_obj, value_to_be_set)
            # Press 'Enter' button after typing the required value
            qt_convenient_squish_apis.type(value_obj, '<Return>')

            # Handle the 'Valid Prefix Added' pop-up which appears while
            # updating 'ID' property value of a widget
            if property_name == 'id':
                # Click on 'Ok' button in the 'Valid Prefix Added' pop-up
                qt_convenient_squish_apis.click_button(
                                        'FBE_ValidPrefixAddedPopup_Btn_Ok', 1)
                # Prefix the value to be set string with first 3 letters of
                # the existing ID name (as per functionality)
                value_to_be_set = initial_text[:3] + value_to_be_set
            # Get the current text of the property value
            updated_text = str(native_squish_apis.wait_for_object_item(
                                                        prop_parent_obj,
                                                        str(row) + "/1").text)

            # Raise exception if updated text is not same as value to be set
            if updated_text != value_to_be_set:
                return False
            else:
                return True
        # Check if the property object, who's value needs to be update, is of
        # type 'QPushButton'
        elif "type='QPushButton'" in property_obj:
            # Get 'QModelIndex' children from properties editor object
            qpushbutton_object = native_squish_apis.wait_for_object(
                                                    property_obj, 1)
            # Get the current text value of 'QLineEdit' object
            initial_text = str(qpushbutton_object.text)
            # Write squish log if the current value is same as value to be set
            # and return from the function
            if initial_text == value_to_be_set:
                            # mouse press on the middle of the objectOrName
                            # object
                qt_convenient_squish_apis.mouse_click(qpushbutton_object)
                            # give the time for squish to wait for the next
                            # command
                squish.snooze(time_out)
                return True
            else:
                return False
        # Check if the property object, who's value needs to be update, is of
        # type 'QRadioButton'
        elif "type='QRadioButton'" in property_obj:
            # Get 'QModelIndex' children from properties editor object
            qradiobutton_object = native_squish_apis.wait_for_object(
                                                    property_obj, 1)
            if(qradiobutton_object.text == value_to_be_set and qradiobutton_object.checked):
                logger.write_log("'" + str(property_name) + "' property value"
                        " is already set to '" + str(value_to_be_set) + "'")
                return True
            else:
                # mouse press on the middle of the objectOrName
                            # object
                qt_convenient_squish_apis.mouse_click(qradiobutton_object)
                # give the time for squish to wait for the next
                            # command
                squish.snooze(time_out)
                if(qradiobutton_object.text == value_to_be_set and qradiobutton_object.checked):
                    return True
                else:
                    return False
        # Check if the property object, who's value needs to be update, is of
        # type 'QCheckBox'
        elif "type='QCheckBox'" in property_obj:
            # Get 'QModelIndex' children from properties editor object
            qcheckbox_object = native_squish_apis.wait_for_object(
                                                    property_obj, 1)
            if(str(qcheckbox_object.checked).lower() == str(value_to_be_set).lower()):
                logger.write_log("'" + str(property_name) + "' property value"
                        " is already set to '" + str(value_to_be_set) + "'")
                return True
            else:
                # mouse press on the middle of the objectOrName
                            # object
                qt_convenient_squish_apis.mouse_click(qcheckbox_object)
                # give the time for squish to wait for the next
                            # command
                squish.snooze(time_out)
                if(str(qcheckbox_object.checked).lower() == str(value_to_be_set).lower()):
                    return True
                else:
                    return False
    except Exception as run_runtime_args:
        if "not ready" in run_runtime_args.message:
            property_obj_ref = native_squish_apis.find_object(property_obj)
            # check for the enabled and editable properties of the object
            if property_obj_ref.enabled & property_obj_ref.editable:
                raise Exception("'" + str(property_name) + "' property "
                                "value could not be set to '"
                                + str(value_to_be_set) + "'")
            else:
                logger.write_log(str.format("""Object {0} is disabled and
                non-editable. Only verification of current value is
                possible""", str(property_obj_ref)))
                return True
        else:
            raise Exception("general.set_object_value(): "
                        + str(run_runtime_args.message))


def set_value_for_an_object(property_obj='', property_name='',
                            value_to_be_set='', prop_parent_obj='',
                            write_result=False):
    """
    This function is to update the value of an object with its name
    If requires, it also writes the result(pass/exception) to Squish log.
    widget_name = Name of the widget who's property value should be
        updated. The name should be exactly same as the class name
        present in 'gui_classes' module.
        Ex: 'TableWidget', 'GraphicsView'
    property_name = Name of the property who's value should
        be updated. The name should be same as in the 'Properties'
        column of the editor form but case-insensitive and without
        spaces in between the words.
        Ex: 'ToolTipEnable', 'StyleSheetClass'
    value_to_be_set = Value to be set for the required property. Should be a
        string value and should be same as the value present in the
        'Properties' column of the editor form.
        Ex: '100', 'true', 'green'
    prop_parent_obj = parent object for forming the dynamic object names
        for its children. Mainly used for objects of type QModelIndex.
    write_result = Should be boolean True if log result needs to be
            written. Else, boolean False
    """
    try:
        # get the real name of the object from the object.map file
        obj_real_name = get_real_name_of_object(property_obj)
        #method to set a object values depending on the type of object
        if not _set_object_value(obj_real_name, property_name, value_to_be_set,
                     prop_parent_obj):
            raise Exception("'" + str(property_name) + "' property value "
                        "could not be set to '" + str(value_to_be_set) +
                        "' in the editor form")
        # Write log result
        if write_result:
            logger.write_to_result('Pass',
                    "To verify if '" + str(property_name) + "' property "
                    "value can be set to '" + str(value_to_be_set) +
                    "' in editor form",
                    "User should be able to set '" + str(property_name) +
                    "' property value to '" + str(value_to_be_set) + "'",
                    "User is able to set '" + str(property_name) + "' "
                    "property value to '" + str(value_to_be_set) + "'")
    except Exception as run_runtime_args:
        raise Exception("general.set_object_value(): "
                        + str(run_runtime_args.message))


def open_context_menu_item(property_obj='', x_coord=0, y_coord=0, time_out=1):
    try:
        #check if the property object is provided or not
        if property_obj == '':
            raise Exception("""Property Object not provided.
                               Please provide the object on which the context
                               menu is to be opened...""")
        # give the time for squish to wait for the next command
        squish.snooze(time_out)
        qt_convenient_squish_apis.open_context_menu(property_obj)
    except Exception as run_time_args:
        raise Exception("general.open_context_menu_item(): "
                        + str(run_time_args.message))


def verify_item_in_widget_tree_view(text_name='',
                                    write_result=False):
    """
    Method to verify if an item exists in the widget tree view.
    """
    try:
        # Get the default child object reference
        default_child_obj_ref = native_squish_apis.wait_for_object(
                                    'FBE_MainWindow_Container_WidgetTreeView',
                                    2)
        # Get all 'QModelIndex' children using default child object reference
        q_model_index_children = get_children_of_type(default_child_obj_ref,
                                                      'QModelIndex', 5)

        # Iterate through each child
        for child in q_model_index_children:
            # Check if the current child's text matches with the expected
            if str(child.text) == text_name:
                if(write_result):
                    logger.write_to_result('Pass',
                    "To verify if an item is available in widget tree view",
                    "User should be able to find '" + str(text_name) +
                    " item in the widget tree view",
                    "User is able to find '" + str(text_name) +
                    " item in the widget tree view")
                else:
                    return child
    except Exception as run_time_args:
        raise Exception("general.open_context_menu_item(): "
                        + str(run_time_args.message))


def go_to_preview_screen(tab_obj_id=''):
    """
    Method to traverse to appropriate tab in preview screen
    tab_obj_id = tab object id
    """
    try:
        # Declare a variable for getting the index of tab to be selected
        index_of_tab_object = 0
        # Go to Preview screen
        go_to_menu_item('Tools', 'Preview')
        # Wait for preview window to appear
#         native_squish_apis.wait_for_object('FBE_PreviewWindow_Screen', 5)
        # Get 'QFrame' children from stacked widgets parent object
        if 'wpg' in tab_obj_id:
            qframe_children = get_children_of_type(
                                'FBE_MainWindow_Container_WidgetTreeView',
                                'QWidget', 1)
        else:
            qframe_children = get_children_of_type(
                                'FBE_PreviewWindow_Container_StackedWidgets',
                                'QFrame', 1)

        # Loop through each 'QFrame' child (tab object) to get the required
        # child. From obtained child, extract all children (widget objects)
        for qframe_child in qframe_children:
            if str(qframe_child.objectName) == tab_obj_id:
                widget_children = get_children(qframe_child, 1)
                index_of_tab_object = qframe_children.index(qframe_child)
                break
        # Get 'TabItem' children from Container_TabBar parent object
        qTabBar_children = get_children_of_type(
                                'FBE_PreviewWindow_Container_TabBar',
                                'TabItem', 1)
        # Loop through each 'QFrame' child (tab object) to get the required
        # child. From obtained child, extract all children (widget objects)
        for qTabItem_child in qTabBar_children:
            if qTabItem_child.index == index_of_tab_object:
                qt_convenient_squish_apis.mouse_click(qTabItem_child)
                break
        return widget_children
    except Exception as run_time_args:
        raise Exception("general.go_to_preview_screen(): "
                        + str(run_time_args.message))


def get_children_of_widget_type_in_preview(tab_obj_id='tbp2', widget_id='',
                            widget_children_type='QModelIndex'):
    """
    Method to get list of items of widget in Preview screen with a particular
    type. Like for table widget there could be many row and columns and they
    are of type QModelIndex.
    tab_obj_id = name of the tab as in the widget tree view
    widget_id = name of the widget as in the widget tree view
    widget_children_type = type of children objects of the widget_id.
    """
    try:
        # go to preview and check for the created rows and columns of
        # the table widget
        widget_children = go_to_preview_screen(tab_obj_id)
        # Variable to hold the required widget object
        required_widget = ''
        # Loop through all widget children and obtain the required
                # widget child who's properties needs to be verified
        for widget_child in widget_children:
            if str(widget_child.objectName) == widget_id:
                required_widget = widget_child
                break
        qt_widget_children = get_children_of_type(
                            required_widget,
                                widget_children_type, 1)
        return qt_widget_children
    except Exception as runtime_args:
        raise Exception(str(runtime_args.message))


def verify_widget_property_value(preview_widget, property_name,
                                  property_value, write_result=False):
    """
    Method to verify value of a property of or items in the preview_widget.
    preview_widget = name of the widget as in the widget tree view.
    property_name = name of the property to be verified
    property_value = expected value of the property name provided.
    write_result = option to write the results from this method.
    """
    try:
        # declare a variable to hold the status of the verification
        preview_widgets = False
        # verify the verify_current_property for current widget
        # is True or False
        if (preview.verify_current_property(preview_widget, property_name,
                                                    property_value)):
            if(write_result):
                logger.write_to_result('Pass',
                    """To verify the actual and expected property values are
                    same.""",
                    str.format("To verify property {0} has the value {1}",
                               property_name, property_value),
                    str.format("Property {0} has the value {1}",
                               property_name, property_value),)
                preview_widgets = True
            else:
                # set preview_widgets to True
                preview_widgets = True
        else:
            # set preview_widgets to False
            preview_widgets = False
        return preview_widgets
    except Exception as run_time_args:
        raise Exception("general.verify_widget_property_value(): "
                        + str(run_time_args.message))


def get_widget_tree_children(tree_view_widget_name,
                             tab_obj='FBE_MainWindow_DefaultFirstChild_TBP2'):
    """
    Method to get all the widget tree view items for a tree_view_widget_name
    tree_view_widget_name = name of the widget as in the widget tree view
    no_of_rows = No of rows()
    no_of_columns = No of columns
    """
    try:
        # Declare a list to hold the expected values
        expected_prop_value = []
        # Get the number of QModelIndex children present under root object
        widget_children = get_children_of_type(tab_obj,
                                    'QModelIndex', 2)
        for item in widget_children:
            if item.text == tree_view_widget_name:
                # Get the number of QModelIndex children present under root
                # object
                table_children = get_children_of_type(
                                    item,
                                    'QModelIndex', 2)
                break
        for table_blocks in table_children:
            expected_prop_value.append(table_blocks.text)
        return expected_prop_value
    except Exception as run_time_args:
        raise Exception("general.get_widget_tree_children(): "
                        + str(run_time_args.message))


def manage_table_entries(tree_view_widget_name='taw29', action='',
                         dialog_property='', dialog_property_value=''):
    """
    Method for managing actions for a table widget. This method select's the
    tree_view_widget as per the name provide and will then perform the actions
    like action - Remove / Add(rows and columns) and Cancel operations.
    tree_view_widget_name - name of the table tree view widget(taw29 etc)
    action - string likes "Remove Rows", "Insert Columns" etc.
    dialog_property - if a property has to be updated with the name of the
    property.
    dialog_property_value - the value of the property to be set.
    """
    try:
        # Declare a variable to determine whether the object
        # FBE_MainWindow_DisplayWindowFormEditorWidget is already available
        global context_pop_up_avaiable
        # Declare a variable to determine whether the pop dialog has to be
        # closed or not
        exit_pop_up = True
        # Declare a variable to select the close option for context the dialog
        close_object = ''
        # Declare a variable to select an option for context the dialog
        action_object = ''
        if "Insert" in action:
            close_object = "FBE_TableWidget_Dialog_Button_Add"
        elif "Remove" in action:
            close_object = "FBE_TableWidget_Dialog_Button_Remove"
        else:
            close_object = "FBE_TableWidget_Dialog_Button_Cancel"
        # Determine which property on the current dialog has to be updated
        if (dialog_property == 'count'):
            action_object = "FBE_TableWidget_Dialog_SpinBox_Count"
        elif (dialog_property == 'position'):
            action_object = "FBE_TableWidget_Dialog_SpinBox_Position"
            select_item_in_widget_tree_view(tree_view_widget_name)
            exit_pop_up = False
        if not context_pop_up_avaiable:
            # Select an item from the context menu opened for the table widget
            select_context_menu_item(
                        "FBE_MainWindow_DisplayWindowFormEditorWidget",
                                        action)
            context_pop_up_avaiable = True
        # Verify the appropriate dialog is opened
        if(native_squish_apis.object_exists("FBE_TableWidget_Dialog")):
            try:
                set_value_for_an_object(
                                        action_object,
                                        dialog_property, dialog_property_value,
                                         write_result=True)
            except Exception as run_time_args:
                if "could not be set to" in run_time_args.message:
                            logger.write_log(str.format("""{0} cannot be
                                            removed when there are no (1) in
                                            the table""", dialog_property))
        else:
            raise Exception(run_time_args.message)
        # close the pop-up with the appropriate close_object defined with the
        # help of action variable.
        if exit_pop_up:
            close_pop_up(close_object)
            context_pop_up_avaiable = False
    except Exception as run_time_args:
        raise Exception("general.manage_table_entries(): "
                        + str(run_time_args.message))


def update_and_verify_table_entries(tree_view_widget_name, action,
                         dialog_property, dialog_property_value,
                         tab_obj='FBE_MainWindow_DefaultFirstChild_TBP2',
                         write_result=False):
    """
    This method uses the manage_table_entries() an also verifies the changes in
    widget tree view.
    """
    try:
        # Declare and define a list to contain the no of rows and columns in a
        # table widgettree_view_widget_name
        expected_prop_value = get_widget_tree_children(
                             tree_view_widget_name, tab_obj)
        # Declare a variable to contain the length of list containing the rows
        # and columns in a table widget.
        initial_total_no_of_table_blocks = len(expected_prop_value)
        # Call the manage_table_entries to perform the appropriate action.
        manage_table_entries(tree_view_widget_name, action, dialog_property,
                             dialog_property_value)
        if "position" in dialog_property:
            return
        # Declare and define a list to contain the no of rows and columns in a
        # table widgettree_view_widget_name
        expected_prop_value = get_widget_tree_children(
                             tree_view_widget_name, tab_obj)
        # Declare a variable to contain the length of list containing the rows
        # and columns in a table widget.
        updated_total_no_of_table_blocks = len(expected_prop_value)
        # Check for the action command and length of the list containing the
        # rows and columns in a table widget is equal to zero.
        if 'Remove' in action and updated_total_no_of_table_blocks == 0:
            if write_result:
                logger.write_to_result("Pass",
                                       """When there are no rows or columns in
                                       table nothing can be removed.""",
                                       """To verify that no rows or columns can
                                       be removed when the table is empty.""",
                                       """No rows or columns can are
                                       removed when the table is empty.""")
            else:
                return True
        elif 'Remove' in action and updated_total_no_of_table_blocks > 0:
            if not updated_total_no_of_table_blocks < initial_total_no_of_table_blocks:
                raise Exception(str.format("""Table was not updated with {0}
                    having {1} value""", action, dialog_property_value))
        elif 'Insert' in action and updated_total_no_of_table_blocks > 0:
            if not updated_total_no_of_table_blocks > initial_total_no_of_table_blocks:
                raise Exception(str.format("""Table was not updated with {0}
                    having {1} value""", action, dialog_property_value))
        if write_result:
            logger.write_to_result("Pass",
                                       """When rows or columns are inserted in
                                       table the total size of the table should
                                       increase accordingly""",
                                       str.format("""To verify that {0} {1}
                                       were added.""", dialog_property_value,
                                       action.split(' ')[1]),
                                       str.format("""{0} {1} were added
                                       successfully.""", dialog_property_value,
                                       action.split(' ')[1]))
#         table_block_row_col_val = total_no_of_table_blocks[total_no_of_table_blocks-1]
#         table_block_row_col = table_block_row_col_val.split(':')
#         table_block_row_col_val.append(table_block_row_col[1].split('-'))
#         total_no_of_rows = len(table_block_row_col_val[0])
#         total_no_of_columns = len(table_block_row_col_val[1])
    except Exception as run_time_args:
        raise Exception("general.verify_table_entries(): "
                        + str(run_time_args.message))


def update_property_for_table_entries(property_name,
                                      target_block,
                                      value_to_set,
                                      tree_view_widget_name,
                                      tab_obj='FBE_MainWindow_DefaultFirstChild_TBP2'):
    """
    Method to update the property of the a selected tree view object.
    property_name - if a property has to be updated with the name of the
    property.
    expected_value - the value of the property to be set.
    tree_view_widget_name - name of the table tree view widget(taw29 etc)
    no_of_rows - count of the number of rows
    no_of_columns - count of the number of columns
    """
    try:
        # Define a variable to hold the list of current property values
        expected_prop_value = get_widget_tree_children(
                             tree_view_widget_name, tab_obj)
        for prop_item in expected_prop_value:
            if target_block in prop_item:
                select_item_in_widget_tree_view(prop_item)
                update_property_value_in_editor("TableWidget",
                                                property_name,
                                                value_to_set,
                                                True)
                break
    except Exception as run_time_args:
        raise Exception("general.update_property_for_table_entries(): "
                        + str(run_time_args.message))


def verify_property_for_table_entries_in_preview(tree_view_widget_name,
                                      target_block,
                                      property_name='',
                                      property_value='',
                                      tab_name='tbp2'):
    """
    This method is used to verify the property value of a table block in preview screen.
    """
    try:
        # Declare a variable to get the result
        verified_property = False
        #get the rows and columns from the target_block
        table_rows_columns = target_block.split('-')
        table_row = table_rows_columns[0]
        table_column = table_rows_columns[1]
        # Decrease the value of table row by 1 since the indexing of
        # QModelIndex elements starts with zero.
        table_row_value = 0
        table_row_value = __builtin__.int(table_row) - 1
        # Decrease the value of table columns by 1 since the indexing of
        # QModelIndex elements starts with zero.
        table_column_value = 0
        table_column_value = __builtin__.int(table_column) - 1
        # of the table widget
        table_model_children = get_children_of_widget_type_in_preview(
                            tab_name, tree_view_widget_name, 'QModelIndex')
        for table_model_child in table_model_children:
            if ((table_row_value == table_model_child.row) and (
                            table_column_value == table_model_child.column)):
                if (preview.verify_current_property(table_model_child,
                                                    property_name,
                                                    property_value,
                                                    latest_available=True)):
                    logger.write_to_result("Pass", """Ensure
                                    that the cell property has been updated""",
                                    str.format("""Verify the property {0} has
                                    the expected value {1}""", property_name,
                                    property_value),
                                    str.format("""The property {0} has
                                    the expected value {1}""",
                                    property_name,
                                    property_value))
                    verified_property = True
                    break
        if not verified_property:
            logger.write_to_result("Fail", """Ensure
                                    that the cell property has been updated""",
                                    str.format("""Verify the property {0} has
                                    the expected value {1}""", property_name,
                                    property_value),
                                    str.format("""The property {0} does not
                                    have the expected value {1}""",
                                    property_name,
                                    property_value))
        close_preview()
    except Exception as run_time_args:
        raise Exception("general.verify_property_for_table_entries(): "
                        + str(run_time_args.message))


def verify_table_entries_in_preview(tree_view_widget_name,
                         property_type, tab_name='tbp2',
                         expected_prop_value=[],
                         qt_widget_children=[],
                         write_result=False):
    """
    This method is to verify the changes in number of rows and columns for a
    table widget in Preview screen.
    """
    try:
        if expected_prop_value == []:
            # Declare a list to hold the expected values
            expected_prop_value = get_widget_tree_children(
                             tree_view_widget_name)
        # go to preview and check for the created rows and columns of
        # the table widgets
        if qt_widget_children == []:
            qt_widget_children = get_children_of_widget_type_in_preview(
                            tab_name, tree_view_widget_name, 'QFrame')
        if len(qt_widget_children) == 0:
            if write_result:
                logger.write_to_result("Pass",
                                       """When there are no rows or columns in
                                       table nothing can be removed.""",
                                       """To verify that no rows or columns can
                                       be removed when the table is empty.""",
                                       """No rows or columns can are
                                       removed when the table is empty.""")
        else:
            for object_name in qt_widget_children:
                for property_value in expected_prop_value:
                    if (verify_widget_property_value(object_name, property_type,
                                                property_value, write_result)):
                        if write_result:
                            logger.write_to_result("Pass",
                                        str.format("""Table cell object are
                                        available in tree view"""),
                                        str.format("""To verify Table cell
                                        object are available in tree view"""),
                                        str.format("""Table cell object {0} are
                                        available in tree view""",
                                        property_value))
        close_preview()
    except Exception as run_time_args:
        raise Exception("general.verify_table_entries_in_preview(): "
                        + str(run_time_args.message))


def get_property_value_in_preview(widget_obj='', property_name=''):
    """
    This function is to get the actual value of a property name in the
    'Preview' window, format it as per the requirement and return the
    same. This function is basically called through
    'verify_properties_in_preview' API.
    
    widget_obj = Widget object symbolic/real name who's value needs to
            be fetched from the 'Preview' window
    property_name = Property name who's value needs to be fetched from
            the 'Preview' window
            Ex: 'BGColor', 'font.bold'
    """
    try:
        # Declare a dictionary of color Hex codes and names
        color_codes = {'#000000': 'black',
                       '#008000': 'green',
                       '#ff0000': 'red',
                       '#808080': 'gray',
                       '#0000ff': 'blue',
                       '#ffffff': 'white',
                       '#ffff00': 'yellow',
                       '#ffa500': 'orange'
                       }
        # Get the widget object reference
        widget_obj_ref = native_squish_apis.wait_for_object(widget_obj, 2)
        # Check if the property to be fetched is 'font.bold'
        if property_name == 'font.bold':
            # Get the font object from the widget object
            font_obj = __builtin__.getattr(widget_obj_ref, 'font')
            # Get bold property value and return it as string in lower case
            return str(__builtin__.getattr(font_obj, 'bold')).lower()
        
        elif property_name == 'font.pointSize':
            # Get the font object from the widget object
            font_obj = __builtin__.getattr(widget_obj_ref, 'font')
            # Get the 'pointSize' property value using the font object
            point_size = str(__builtin__.getattr(font_obj, 'pointSize'))
            # Declare a dictionary of point sizes and respective strings
            point_sizes_dict = {'9': 'small',
                                '11': 'normal',
                                '14': 'big'
                                }
            # Return point size string value
            return point_sizes_dict[point_size]
 
        # Check if the property to be fetched is 'alignment'
        elif property_name == 'alignment':
            # Get the actual alignment value from the widget object
            actual_value = str(__builtin__.getattr(widget_obj_ref,
                                        'alignment')).split('|')[0].strip()
            # Declare a dictionary of actual values and formatted value
            alignment_values = {'Qt::AlignLeft': 'left',
                                'Qt::AlignRight': 'right',
                                'Qt::AlignHCenter': 'center'
                                }
            # Return the formatted value
            return alignment_values[actual_value]
        
        # Check if the property to be fetched is 'BGColor'
        elif property_name == 'BGColor':
            # Get the background color name using widget object reference
            bgcolor_name = str(widget_obj_ref.backgroundColor().name)
            # Return the color name
            return color_codes[bgcolor_name]

        # Check if the property to be fetched is 'color'
        elif property_name == 'color':
            # Get the foreground color name using widget object reference
            color_name = str(widget_obj_ref.foregroundColor().name)
            # Return the color name
            return color_codes[color_name]

        # Check if the property to be fetched is 'orientation'
        elif property_name == 'orientation':
            # Get the orientation value in string format
            actual_value = str(__builtin__.getattr(widget_obj_ref,
                                                        'orientation'))
            # Declare dictionary of orientation values & corresponding strings
            orientation_dict = {'1': 'horizontal',
                                '2': 'vertical'
                                }
            # Return the orientation string value
            return orientation_dict[actual_value]

        # In case of Text Area widget, the alignment value lies within the
        # hmtl value. Fetch the same using regular expression
        elif property_name == 'html':
            # Get the html value of the widget object
            html_value = str(__builtin__.getattr(widget_obj_ref, 'html'))
            # Get the alignment value using regular expression search
            alignment_value = re.search(r"align=\"(.+?)\" style", html_value).group(1)
            return alignment_value

        else:
            # Return the property value
            return str(__builtin__.getattr(widget_obj_ref,
                                           property_name)).lower()

    except Exception as run_time_args:
        raise Exception("general.get_property_value_in_preview(): "
                        + str(run_time_args.message))


def _form_item_dialog_dict(widget_name='Default', table_entity='Rows', start='1',
                    end='1', set_border=False):
    """
    Method to form dictionary to set the values in Item Widget Dialog(Set Item
    Type) for Table widget.
    """
    try:
        # Declare a dictionary to hold the key value pairs for each action to
        # be performed on the item dialog box
        item_dialog_dict = OrderedDict()
        item_dialog_dict["Select Widget Type"] = (
                            "FBE_ItemWidget_Dialog_ComboBox_Widget_Type",
                            widget_name)
        if (table_entity == "Rows"):
            item_dialog_dict["Set Item For"] = (
                            "FBE_ItemWidget_Dialog_GroupBox_RadioButton_Rows",
                            "Rows")
        elif (table_entity == "Columns"):
            item_dialog_dict["Set Item For"] = (
                        "FBE_ItemWidget_Dialog_GroupBox_RadioButton_Columns",
                        "Columns")
        elif (table_entity == "SingleCell"):
            item_dialog_dict["Set Item For"] = (
                    "FBE_ItemWidget_Dialog_GroupBox_RadioButton_SingleCell",
                    "Single Cell")
        item_dialog_dict["Start"] = (
                            "FBE_ItemWidget_Dialog_SpinBox_Start", start)
        item_dialog_dict["End"] = (
                            "FBE_ItemWidget_Dialog_SpinBox_End", end)
        item_dialog_dict["Set Border Line On"] = (
                            "FBE_ItemWidget_Dialog_CheckBox_BorderOn",
                            set_border)
        return item_dialog_dict
    except Exception as arguments:
        raise Exception("general._form_item_dialog_dict(): "
                        + str(arguments.message))


def set_table_item(widget_name='Default', table_entity='Rows', start='1',
                    end='1', set_border=False):
    """
    Method to set value in Item Widget Dialog(Set Item Type) for Table widget.
    """
    try:
        item_dialog_dict = _form_item_dialog_dict(widget_name, table_entity,
                                        start, end, set_border)
        # loop through the dictionary to get the keys and its values to be
        # passed to the _set_object_value method.
        for keys, list_of_values in item_dialog_dict.iteritems():
            property_name = keys
            property_object = list_of_values[0]
            property_value = list_of_values[1]
            # get the real name of the object from the object.map file
            obj_real_name = get_real_name_of_object(property_object)
            # method to set a object values depending on the type of object
            if not _set_object_value(obj_real_name,
                                     property_name,
                                     property_value):
                raise Exception(str.format("""Cannot set the value {0}
                            for Property {1}""", property_value,
                            property_name))
        # get the real name of the object from the object.map file
        obj_real_name = get_real_name_of_object(
                                "FBE_ItemWidget_Dialog_Button_Ok")
        # method to set a object values depending on the type of object
        if not _set_object_value(obj_real_name, "Ok", "Ok"):
            raise Exception(str.format("""Cannot select the button
                            with name Ok"""))
    except Exception as run_time_args:
        raise Exception("general.set_table_item(): "
                        + str(run_time_args.message))


def verify_table_item_tree_view_names(
                            tab_obj='FBE_MainWindow_DefaultFirstChild_TBP2',
                            widget_id="taw29", widget_name="Default",
                            table_entity='SingleCell', start='1', end='1',
                            no_of_row_column='1', set_border=False,
                            write_result=False):
    """
    Method to verify the table cell items in preview.
    """
    try:
        # Declare a list to store the tree view children of the table widget
        table_tree_view_children = []
        table_tree_view_children = get_table_item_tree_view_names(tab_obj,
                                                                  widget_id)
        # Declare an object for getting the
        # Create an instance of the required class based on widget_name
        class_name = globals()[widget_name]
        required_instance = class_name()
        # Get the required tree_view_name using the instance created
        widget_tree_view_name = __builtin__.getattr(required_instance,
                                                        "treeviewname")
        table_cell_name_list = []
        if table_entity == "SingleCell":
            table_cell_name = widget_tree_view_name + '-' + widget_id + ':' + start +"-"+ end
            table_cell_name_list.append(table_cell_name)
        elif table_entity == "Rows":
            for start_value in range(__builtin__.int(start), __builtin__.int(end) + 1):
                for end_value in range(1, __builtin__.int(no_of_row_column) + 2):
                    table_cell_name = widget_tree_view_name + '-' + widget_id + ':' + str(start_value) +"-"+ str(end_value)
                    table_cell_name_list.append(table_cell_name)
        elif table_entity == "Columns":
            for start_value in range(__builtin__.int(start), __builtin__.int(end) + 1):
                for end_value in range(1, __builtin__.int(no_of_row_column) + 2):
                    table_cell_name = widget_tree_view_name + '-' + widget_id + ':' + str(end_value)  +"-"+ str(start_value)
                    table_cell_name_list.append(table_cell_name)
                    #dynamic_table_cell_obj = "{container=':"+tab_obj_id+"."+widget_id+"_QTableView'" +" name='"+table_cell_objectName+"' type='"+widget_type+ "' visible='1'}"
        item_found = 0
        # Declare a list to contain the currently identified table cell items
        identified_table_cell_name_list = []
        for cell_name in table_cell_name_list:
            for table_tree_view_child in table_tree_view_children:
                if table_tree_view_child.text == cell_name:
                    if write_result:
                        logger.write_to_result("Pass",
                                       """Widgets can be set in
                                       multiple table rows and columns.""",
                                       """To verify the item set using
                                       'set item type' in table are updated
                                       accordingly in tree view""",
                                       str.format("""The item set using
                                       'set item type' in table are updated
                                       accordingly in tree view {0}""",
                                       cell_name))
                        item_found += 1
                        identified_table_cell_name_list.append(cell_name)
        if not len(table_cell_name_list) == item_found:
            cell_name = [x for x in table_cell_name_list if x not in identified_table_cell_name_list]
            raise Exception(str.format("""The items set using
                                       'set item type' in table are not updated
                                       accordingly in tree view {0}""",
                                       cell_name))
        return table_cell_name_list
    except Exception as run_time_args:
        raise Exception("general.verify_table_item_in_preview(): "
                        + str(run_time_args.message))


def get_table_item_tree_view_names(
                            tab_obj='FBE_MainWindow_DefaultFirstChild_TBP2',
                            widget_id="taw29"):
    """
    Method to verify the table cell items in tree view.
    """
    try:
        # Declare a list to contain all the tree view children of widget_id
        tree_view_children = []
        # Declare another list to contain sub-children of table widget
        table_tree_view_children = []
        tree_view_children = get_children_of_type(tab_obj, "QModelIndex")
        for tree_view_child in tree_view_children:
            if tree_view_child.text == widget_id:
                table_tree_view_children = get_children_of_type(
                                                        tree_view_child,
                                                          "QModelIndex")
        return table_tree_view_children
    except Exception as run_time_args:
        raise Exception("general.verify_table_item_in_preview(): "
                        + str(run_time_args.message))


def verify_table_item_obj_in_preview(
                            tab_obj='tbp2',
                            widget_id="taw29", widget_name="Default",
                            table_cell_name_list=[],
                            write_result=False):
    """
    Method to verify the table cell items in tree view.
    """
    try:
        # Declare an object for getting the
        # Create an instance of the required class based on widget_name
        class_name = globals()[widget_name]
        required_instance = class_name()
        # Get the required tree_view_name using the instance created
        widget_type = __builtin__.getattr(required_instance,
                                                        "widgettype")
        # go to preview screen
        go_to_preview_screen(tab_obj)
        # Declare a list to hold the dynamic widget objects in the table widget
        dynamic_preview_obj_list = []
        # create the dynamic object
        for preview_widget_object_name in table_cell_name_list:
            dynamic_preview_obj = "{container=':" + tab_obj + "." + widget_id + "_QTableView'" + " name='" + preview_widget_object_name + "' type='" + widget_type + "' visible='1'}"
            if native_squish_apis.object_exists(dynamic_preview_obj):
                if write_result:
                        logger.write_to_result("Pass",
                                       """Widgets can be set in
                                       multiple rows and columns of table
                                       widget.""",
                                       """To verify in preview the item object
                                       set using 'set item type' in table are
                                       updated accordingly.""",
                                       str.format("""The item object set using
                                       'set item type' in table are updated
                                       accordingly in Preview {0}""",
                                       dynamic_preview_obj))
                        dynamic_preview_obj_list.append(dynamic_preview_obj)
            else:
                close_preview()
                raise Exception(str.format("""table widget object {0} not found
                in preview window""", preview_widget_object_name))
        close_preview()
        return dynamic_preview_obj_list
    except Exception as run_time_args:
        raise Exception("general.verify_table_item_in_preview(): "
                        + str(run_time_args.message))


def verify_with_vp(name_of_vp, write_result=False):
    """Method to compare images. Comparison of the testdata folder VP and the
    current image of the object on the screen."""
    try:
        # declare a variable to hold the end result
        vp_verified = False
        #get the extension for the verification point
        name_of_vp = _get_image_extension(name_of_vp)
        #get the complete path of the verification point
        complete_vp_path = get_path("verification_point")
        #get the test case name
        test_case_name = get_name("testcase")
        #check if the name_of_vp is not empty
        if(name_of_vp == None):
            #get the complete path of the verification point with textcase name
            complete_vp_path = complete_vp_path + "/" + test_case_name
        else:
            #get the complete path of the verification point with VP name
            complete_vp_path = (
                    complete_vp_path + "/" + name_of_vp)
        #check if the complete_vp_path exists before proceeding
        if(os.path.exists(complete_vp_path)):
            #method to verify with the VP provide
            if(test.vp(complete_vp_path)):
                vp_verified = True
            else:
                vp_verified = False
        else:
            raise Exception(str.format("{0} path not found", complete_vp_path))
        if(write_result):
            if vp_verified:
                logger.write_to_result("Pass",
                            str.format("Verify with screenshot"),
                            str.format("""To verify an image is loaded
                            successfully"""),
                            str.format("""Image is loaded onto the widget
                            successfully"""))
            else:
                logger.write_to_result("Fail",
                            str.format("Verify with screenshot"),
                            str.format("""To verify an image is loaded
                            successfully"""),
                            str.format("""Image is not loaded onto the widget
                            """))
        else:
            return vp_verified
    except Exception as run_time_args:
        raise Exception("general.verify_with_vp(): "
                        + str(run_time_args.message))


def _get_image_extension(name_of_vp):
    """
    private method to get the extension of VP provided
    """
    try:
        finished_removing_extension = []
        if not name_of_vp == None:
            for item in name_of_vp:
                if not item == ".":
                    finished_removing_extension.append(item)
                else:
                    break
            name_of_vp = ''.join(finished_removing_extension)
        else:
            raise Exception("Name of vp is not provided...")
        return name_of_vp
    except Exception as run_time_args:
        raise Exception("general._get_image_extension(): "
                        + str(run_time_args.message))


def select_file(file_name,
              directory_path='/home/adt/ADT/ASML-ADT/Trunk/targets/bin/'):
    """
    This private function is to select the given file from the given
    directory.
    file_name = Mandatory argument - Name (with extension) of the file
            to be opened
            Ex: 'MyButton.xml'
    directory_path = Optional argument - Directory path where the file
            is saved.
            Ex: '/home/share/'
    """
    try:
        # get the complete file path
        complete_path = directory_path + file_name
        # Wait for the file name input box
        file_name_inputbox = native_squish_apis.wait_for_object(
                            'FBE_SelectFileWindow_InputBox_FileName', 5)
        # Enter the file name to be opened in the input box
        qt_convenient_squish_apis.type(file_name_inputbox,
                                       complete_path)
        # Click on 'Open' button
        qt_convenient_squish_apis.click_button(
                                            'FBE_SelectFileWindow_Button_Open')

    except Exception as of_run_time_args:
        raise Exception("general._open_file(): "
                        + str(of_run_time_args.message))
#===============================Revision History==============================
# Modified By       Modified On     Modification Reason
# Vasanth S N       13-Jun-2017     1. Added new API 'walk_through_children'
#                                   2. Updated 'get_all_children_of_type' API
# Vasanth S N       14-Jun-2017     3. Update 'get_children_of_type' API and
#                                     removed 'get_all_children_of_type' API
# Girish Nair        29-Jun-2017        1. All comments fixed.
#                                    2. Modofied method name 'object_exists' to
#                                       'find_object_exists
#                                    3. Modified method 'widget_drag_and_drop'.
#                                    4. Added new method
#                                       'get_test_folder_variable_list'
# Girish Nair        20-Jul-2017     1. Added two methods get_name & get_path.
#                                     2. Modified go_to_menu_item().
# Girish Nair        26-Jul-2017      1. Added verify_properties_of_preview_window()
#                                     2. Added verify_properties() and
#												_verify_property_value()
#                    			      3. Added verify_object_text()
#                    27-Jul-2017      1. Added close_pop_up(), close_preview()
#									  2. Added update_property_value_in_form_properties()
#									  3. Modified quit_application()
# Girish Nair        28-Jul-2017      1. Added public method set_object_value()
#									  2. Added private method _set_object_value()
#									  3. Added method get_real_name_of_object()
#									  4. Added method select_context_menu_item()
#									  5. Modified method close_pop_up()
#									  6. Modified method update_property_value()
# Girish Nair        31-Jul-2017      1. Added public method set_value_for_an_object()
#									  2. Added public method open_context_menu_item()
#									  3. Added method verify_item_in_widget_tree_view()
# Girish Nair        03-Aug-2017      1. Added public method go_to_preview_screen()
#									  2. Added public method get_children_of_widget_type_in_preview()
#									  3. Added method verify_widget_property_value()
#									  4. Added public method get_widget_tree_children()
#									  5. Modified method verify_properties_in_preview()
# Girish Nair        08-Aug-2017      1. Added public method manage_table_entries()
#									  2. Added method update_and_verify_table_entries()
#									  3. Added public method verify_property_for_table_entries_in_preview()
#									  4. Added method verify_table_entries_in_preview()
#									  5. Modified method get_children_of_widget_type_in_preview() 
# Girish Nair        23-Aug-2017      1. Added public method verify_with_vp()
#									  2. Added private method _get_image_extension()
#									  3. Added public method select_file()
# Girish Nair        30-Aug-2017      1. Added public method verify_table_item_obj_in_preview()
#									  2. Added private method verify_table_item_tree_view_names()
#									  3. Added public method _form_item_dialog_dict()
#=============================================================================