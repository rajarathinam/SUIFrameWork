# -*- coding: utf-8 -*-
import test


def write_log(log_msg=""):
    """
    This function is to write general log to squish log.
    This is wrapper function for 'test.log' squish API
    """
    #Write a message to squish log
    test.log(log_msg)


def passed(value):
    test.passes(str.format(value))


def failed(value):
    test.fail(str.format(value))


def write_to_result(step_result='', step_description='', expected_result='',
                    actual_result = ''):
    """
    This function is to write the test script result to squish log
    """
    if(step_result == "" or step_description == "" or expected_result == "" or
       actual_result == ""):
        #raise exception
        raise Exception('logger.write_result(): All parameters are mandatory')

    elif(step_result.upper() == 'PASS'):
        #Write the all the step details to squish log
        test.passes("Step Description: " + str(step_description) + "\n"
                    + "Expected Result: " + str(expected_result) + "\n"
                    + "Actual Result: " + str(actual_result))
    else:
        #Write the all the step details to squish log
        test.fail("Step Description: " + str(step_description) + "\n"
                  + "Expected Result: " + str(expected_result) + "\n"
                  + "Actual Result: " + str(actual_result))

