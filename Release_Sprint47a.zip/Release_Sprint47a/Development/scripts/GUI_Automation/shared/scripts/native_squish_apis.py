# -*- coding: utf-8 -*-

import squish
import object
import __builtin__

MAX_TIME_OUT = 1


def wait_for(condition_statement='', time_out=MAX_TIME_OUT):
    """
    This is a wrapper function for squish's 'waitFor' API.
    """
    # Check if condition_statement is blank
    if condition_statement == '':
        raise Exception("native_squish_apis.wait_for(): Condition to be "
                        "checked should not be empty")

    return squish.waitFor(condition_statement, time_out * 1000)


def object_exists(object_name='', time_out=MAX_TIME_OUT):
    """
    This is a wrapper function for squish's 'object.exists' API.
    Return boolean True if passed object exists, else returns boolean False
    """
    try:
        # Check if obj_name is blank
        if object_name == '':
            raise Exception("native_squish_apis.object_exist(): Object name"
                        " whose existence to be checked should not be blank")

        # Check if the object_name is not of type 'object'
        if not 'Object' in str(__builtin__.type(object_name)):
            # Call wait_for API to poll the condition for required amount of
            # time
            obj_exist_flag = squish.waitFor("object.exists(':' + object_name)",
                                            time_out * 1000)
        else:
            # Call wait_for API to poll the condition for required amount of
            # time
            obj_exist_flag = squish.waitFor("object.exists(object_name)",
                                        time_out * 1000)

        return obj_exist_flag
    except Exception as e:
        raise Exception(str.format("Caught Exception {0} in 'object_exists'",
                                   e))


def wait_for_object(object_name='', time_out=MAX_TIME_OUT):
    """
    This is a wrapper function for squish's 'waitForObject' API.
    Returns the reference of the object if found, visible and enabled
    """
    # Check if 'object_name' argument is null or not passed and raise exception
    if(object_name == ''):
        raise Exception("native_squish_apis.wait_for_object(): Object name "
                        "(symbolic name) should not be blank")

    # Check if the object_name is not of type 'object'
    if not 'Object' in str(__builtin__.type(object_name)):
        # Call waitForObject API and get the object reference
        object_reference = squish.waitForObject(
                                ':' + object_name, time_out * 1000)
    else:
        # Use the passed object reference itself
        object_reference = squish.waitForObject(object_name, time_out * 1000)

    return object_reference


def find_object(object_name=''):
    """
    This is a wrapper function for squish's 'findObject' API.
    Returns the reference of the object
    """
    # Check if 'object_name' argument is null or not passed and raise exception
    if(object_name == ''):
        raise Exception("general.find_object(): Object name (symbolic"
                        " name) should not be blank")

    # Check if the object_name is not of type 'object'
    if not 'Object' in str(__builtin__.type(object_name)):
        # Call findObject API and get the object reference
        object_reference = squish.findObject(':' + object_name)
    else:
        # Use the passed object reference itself
        object_reference = object_name

    return object_reference


def mouse_press(object='', x_coordinate=0, y_coordinate=0,
                mouse_button="left_button", time_out=MAX_TIME_OUT):
    """
    This function is a wrapper for Squish's 'mousePress' API.
    This function comes handy while trying to press and hold an object using
    it's reference.
    """
    try:
        # Wait for the object and get the object reference
        obj_reference = wait_for_object(object)
        # check the values for x and y coordinates
        if ((x_coordinate == 0) & (y_coordinate == 0)):
            # Call Squish's 'mousePress' API
            squish.mousePress(obj_reference)
        else:
            # verify mouse_button has some value else raise an exception and
            # exit
            if not mouse_button == '':
                #MouseButton value will be updated with LeftButton
                if(mouse_button == "left_button"):
                    # Call Squish's 'mousePress' API
                    squish.mousePress(obj_reference, x_coordinate,
                               y_coordinate, squish.MouseButton.LeftButton)
                elif(mouse_button == "right_button"):
                    # Call Squish's 'mousePress' API
                    squish.mousePress(obj_reference, x_coordinate,
                               y_coordinate, squish.MouseButton.RightButton)
            else:
                raise Exception("No value provided for mouse button...")

    except Exception as runtime_args:
        raise Exception("native_squish_apis.mouse_press(): "
                        + str(runtime_args.args))


def mouse_release(mouse_button='', time_out=MAX_TIME_OUT):
    """
    This function is a wrapper for Squish's 'mouseRelease' API.
    This function comes handy while trying to release the appropriate pressed
    mouse button using it's reference.
    Some values for mouse_button argument are given below:
    left_button, right_button
    """
    try:
        #verify mouse_button has some value else raise an exception and exit
        if not mouse_button == '':
            #MouseButton value will be updated with LeftButton
            if(mouse_button == "left_button"):
                # Call Squish's 'mouseRelease' API and pass the mouse_button
                # variable to this
                squish.mouseRelease(wait_for("squish.MouseButton.LeftButton",
                                               time_out))
            #MouseButton value will be updated with RightButton
            elif(mouse_button == "right_button"):
                # Call Squish's 'mouseRelease' API and pass the mouse_button
                # variable to this
                squish.mouseRelease(wait_for("squish.MouseButton.RightButton",
                                               time_out))
        else:
            raise Exception("No value provided for mouse button...")

    except Exception as runtime_args:
        raise Exception("native_squish_apis.mouse_release(): "
                        + str(runtime_args.args))


def native_type(keyboard_input='', text_input='', time_out=0):
    """
    This function is a wrapper for Squish's 'nativeType' API.
    This function is used to simulate user keyboard input using the operating
    system's facilities.
    """
    try:
        type_native_value = None
        #verify keyboard_input has some value and format it according to a
        #keyboard input to type_native_value
        if not keyboard_input == '':
            type_native_value = "<" + keyboard_input + ">"
        #verify text_input has some value and set the same text as
        #type_native_value
        elif not text_input == '':
            type_native_value = text_input
        else:
            type_native_value = None
        #enter the value for the object
        if not type_native_value == None:
            # Call Squish's 'wait_for' API
            wait_for(str.format("squish.nativeType('{0}')",
                            type_native_value), time_out)
        else:
            raise Exception("No value provided for native type value...")

    except Exception as runtime_args:
        raise Exception("native_squish_apis.native_type(): "
                        + str(runtime_args.args))


def key_press(keyboard_input='', time_out=1):
    """
    This function is a wrapper for Squish's 'nativeType' API.
    This function performs a key press of the specified key keyboard key.
    """
    try:
        type_native_value = None
        #verify keyboard_input has some value and format it according to a
        #keyboard input to type_native_value
        if not keyboard_input == '':
            type_native_value = "<" + keyboard_input + ">"
        #enter the value for the object
        if not type_native_value == None:
            # Call Squish's 'wait_for' API
            wait_for(str.format("squish.keyPress('{0}')",
                            type_native_value), 0)
        else:
            raise Exception("No value provided for native type value...")

    except Exception as runtime_args:
        raise Exception("native_squish_apis.key_press(): "
                        + str(runtime_args.args))


def key_release(keyboard_input='', time_out=1):
    """
    This function is a wrapper for Squish's 'nativeType' API.
    This function performs a key release of the specified key keyboard key.
    """
    try:
        type_native_value = None
        #verify keyboard_input has some value and format it according to a
        #keyboard input to type_native_value
        if not keyboard_input == '':
            type_native_value = "<" + keyboard_input + ">"
        #enter the value for the object
        if not type_native_value == None:
            # Call Squish's 'wait_for' API
            wait_for(str.format("squish.keyRelease('{0}')",
                            type_native_value), 0)
        else:
            raise Exception("No value provided for native type value...")

    except Exception as runtime_args:
        raise Exception("native_squish_apis.key_release(): "
                        + str(runtime_args.args))


def application_context(app_name):
    """
    This function is a wrapper for Squish's 'applicationContext' API
    """
    try:
        # Get the application context of the required application and return
        return squish.applicationContext(app_name)
        
    except Exception as ac_runtime_args:
        raise Exception("native_squish_apis.application_context(): "
                        + str(ac_runtime_args.message))


def start_application(app_name, time_out=10):
    """This function is a wrapper for Squish's 'startApplication' API """
    try:
        # Start the required application
        return squish.startApplication(app_name, '', -1, time_out)
        
    except Exception as sa_runtime_args:
        raise Exception("native_squish_apis.start_application() "
                        + str(sa_runtime_args.message))


def wait_for_object_item(object_name='', item_identifier='',
                         time_out=MAX_TIME_OUT):
    """
    This function is wrapper function of 'waitForObjectItem' Squish's
    Qt convenient API
    """
    # Check if 'object_name' argument is null or not passed and raise exception
    if(object_name == '' or item_identifier == ''):
        raise Exception("native_squish_apis.wait_for_object_item(): Object "
                        "name and item identifier should not be blank")

    try:
        # Check if the object_name is not of type 'object'
        if not 'Object' in str(__builtin__.type(object_name)):
            # Call waitForObjectItem API and get the object reference
            object_reference = squish.waitForObjectItem(':' + object_name,
                                                        item_identifier,
                                                        time_out * 1000)
        else:
            # Use the passed object reference itself
            object_reference = squish.waitForObjectItem(object_name,
                                                        item_identifier,
                                                        time_out * 1000)

        return object_reference

    except Exception as wfoi_runtime_args:
        raise Exception("native_squish_apis.wait_for_object_item(): "
                        + str(wfoi_runtime_args))


#===============================Revision History==============================
# Modified By       Modified On     Modification Reason
# Vasanth S N       13-Jun-2017     Initial creation of the module with
#                                  'wait_for_object' API and 'find_object' API
# Vasanth S N       14-Jun-2017     Added 'wait_for' and 'object_exists' APIs
# Girish Nair       23-Jun-2017     Implemented PEP8 coding guidelines
#                                   Added 'mouse_press', 'mouse_release' and
#                                   'native_type' API's
# Girish Nair       05-Jul-2017    Added 'key_press', and 'key_release' API's.
#=============================================================================
