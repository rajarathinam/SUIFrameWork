//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for UndoHandler.
// !\description Class implementation file for UndoHandler.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include <QDebug>
#include <QTimer>

#include <SUITextAreaImpl.h>
#include <boost/foreach.hpp>
#include "UndoHandler.h"
#include "Model.h"
#include "rticWidgetDefinition.h"
#include "WidgetController.h"
#include "formeditor.h"
#include "mainwindow.h"


UndoHandler *UndoHandler::mInstance = NULL;
const QStringList UndoHandler::cmActionList = QString("ACT_NONE,ACT_NEW,ACT_DELETE,ACT_MOVE,ACT_PROPERTY,ACT_COMPLEX,ACT_UCTRL").split(",");
const WidgetController *UndoHandler::cmUndefinedPointer = reinterpret_cast<WidgetController *>(0xfffffff);

/*****************************************************************************\
 *  FUNCTION    :   UndoHandler
 *  PARAMETERS  :   n.a.
 *  RETURN      :   n.a.
 *
 *  This is the ctor.
\*****************************************************************************/
UndoHandler::UndoHandler() :
    mUndoBlocked(false),
    mCurrentlyHandled(const_cast<WidgetController *>(cmUndefinedPointer))
{
    mUndoBuffer.Init(30);
    connect(&mUndoBuffer, SIGNAL(doDelete(UndoInfo *)), this, SLOT(onDeleteUndoInfo(UndoInfo *)));
    connect(&mUndoBuffer, SIGNAL(doEnableUndo(bool)), this, SLOT(onEnableUndo(bool)));
    connect(&mUndoBuffer, SIGNAL(doEnableRedo(bool)), this, SLOT(onEnableRedo(bool)));
    connect(&mUndoBuffer, SIGNAL(sendUndoRedoText(const QString &, const QString &)), this, SLOT(onSendUndoRedoText(const QString &, const QString &)));
}

UndoHandler::~UndoHandler()
{
}

/*****************************************************************************\
 *  FUNCTION    :   Instance
 *  PARAMETERS  :   void
 *  RETURN      :   UndoHandler*
 *                      Pointer to the one instance of this class
 *
 *  This function returns a pointer to the instance of this class. If there is
 *  no instance of this class yet, it will instantiate it.
\*****************************************************************************/
UndoHandler *UndoHandler::instance()
{
    if (mInstance == NULL)
    {
        mInstance = new UndoHandler;
    }
    return mInstance;
}

void UndoHandler::deleteInstance()
{
    if (mInstance != NULL)
    {
        delete mInstance;
        mInstance = NULL;
    }
}

/*****************************************************************************\
 *  FUNCTION    :   addToUndoGroup
 *  PARAMETERS  :   QList<WidgetState *> stateList
 *                      A list with WidgetState pointers
 *  RETURN      :   void
 *
 *  This function enqueues the QList<WidgetState*> to the UndoBuffer.
\*****************************************************************************/
void UndoHandler::addToUndoGroup(QList<WidgetState *> stateList)
{
    if (stateList.count() > 0 && !mUndoBlocked)
    {
        UndoInfo    *undoInf = new UndoInfo;
        if (stateList.at(0) != NULL)
        {
            undoInf->sAction = stateList.at(0)->sAction;
            BOOST_FOREACH(WidgetState * wsState, stateList)
            {
                if (wsState != NULL)
                {
                    undoInf->sStateList.append(wsState);
                }
            }
            mUndoBuffer.enqueue(undoInf);
        }
    }
}

/*****************************************************************************\
 *  FUNCTION    :   addToUndoGroup
 *  PARAMETERS  :   WidgetState *wsState
 *  RETURN      :   void
 *
 *  This function enqueues the WidgetState pointer to the UndoBuffer. The
 *  UndoIndo instances that are created here, will be deleted by the clear()
 *  and dtor functions of CircularList.
\*****************************************************************************/
void UndoHandler::addToUndoGroup(WidgetState *wsState)
{
    if (wsState != NULL && !mUndoBlocked)
    {
        UndoInfo    *undoInf = new UndoInfo;
        undoInf->sAction = wsState->sAction;
        undoInf->sStateList.append(wsState);
        mUndoBuffer.enqueue(undoInf);
    }
}

/*****************************************************************************\
 *  FUNCTION    :   addUCtrlToWSList
 *  PARAMETERS  :   QList<WidgetState *> wsList
 *                      A list with WidgetState pointers
 *                  WidgetController *wcUCtrl
 *                      Pointer to the UserControl
 *  RETURN      :   void
 *
 *  Creating the WidgetState's when creating a UserControl involves special
 *  treatment. The previous state and new state of the widgets can not be filled
 *  within the same loop. So a list of WidgetState pointers has to be created
 *  in which only the widgets are that will be added to the UserControl. So
 *  the WidgetState's in this list only have sPrevState and sOldParentID
 *  filled. The UserControl is the NewState of all Widgets and therefor is the
 *  same for all widgets. This function adds this NewState to the first
 *  WidgetState's sNewState and sNewParentID.
\*****************************************************************************/
void UndoHandler::addNewUCtrlToWSList(QList<WidgetState *> wsList, WidgetController *wcUCtrl)
{
    if ((wsList.count() > 0) && (wcUCtrl != NULL))
    {
        WidgetDefinition    *wcInfo = new WidgetDefinition();
        wcUCtrl->acceptVisitor(*wcInfo);
        wsList.at(0)->sNewState = wcInfo;
        wsList.at(0)->sNewparentID = wcUCtrl->getParent()->getId();
    }
}

/*****************************************************************************\
 *  FUNCTION    :   addOldUCtrlToWSList
 *  PARAMETERS  :   QList<WidgetState *> wsList
 *                      A list with WidgetState pointers
 *                  WidgetController *wcUCtrl
 *                      Pointer to the UserControl
 *  RETURN      :   void
 *
 *  This is the reverse function of addNewUCtrlToWSList.
\*****************************************************************************/
void UndoHandler::addOldUCtrlToWSList(QList<WidgetState *> wsList, WidgetState *wsUCtrl)
{
    if ((wsList.count() > 0) && (wsUCtrl != NULL))
    {
        wsList.at(0)->sPrevState = wsUCtrl->sPrevState;
        wsList.at(0)->sOldParentID = wsUCtrl->sOldParentID;
    }
}

/*****************************************************************************\
 *  FUNCTION    :   getNewUndoInfo
 *  PARAMETERS  :   WidgetController *wcUndo
 *                      Pointer to the widget in the previous state.
 *                  UNDO_ACTION action
 *                      The action to be saved in the Undo Buffer
 *  RETURN      :   WidgetState *
 *
 *  This function creates a new WidgetState and fills the widgets previous state.
 *  It returns this new widgetState's pointer to be filled with the new state
 *  later.
\*****************************************************************************/
WidgetState *UndoHandler::getNewUndoInfo(WidgetController *wcUndo, UNDO_ACTION action , QString actiontext)
{
    WidgetState *widgState = NULL;
    if (wcUndo != mCurrentlyHandled)
    {
        mCurrentlyHandled = wcUndo;
        widgState = new WidgetState;
        widgState->sAction = action;
        widgState->sActionText = actiontext;
        widgState->sIsSaved = !Model::instance()->dataChanged();
        if (wcUndo != NULL)
        {
            WidgetDefinition    *wcInfo = new WidgetDefinition();
            wcUndo->acceptVisitor(*wcInfo);
            widgState->sPrevState = wcInfo;
            widgState->sOldParentID = wcUndo->getParent()->getId();
        }
        else
        {
            widgState->sPrevState = NULL;
            widgState->sOldParentID = QString("");
        }
        widgState->sNewState = NULL;
        widgState->sNewparentID = QString("");
    }
    return widgState;
}

/*****************************************************************************\
 *  FUNCTION    :   finishUndoInfo
 *  PARAMETERS  :   WidgetState *wsState
 *                      Pointer to the WidgetState returned by getNewUndoInfo
 *                  WidgetController *wcUndo
 *                      The widget in the new state.
 *  RETURN      :   void
 *
 *  This function fills the WidgetState with the new state of the widget.
\*****************************************************************************/
void UndoHandler::finishUndoInfo(WidgetState *wsState, WidgetController *wcUndo)
{
    if (wsState != NULL)
    {
        if (wcUndo != NULL)
        {
            WidgetDefinition    *wcInfo = new WidgetDefinition();
            wcUndo->acceptVisitor(*wcInfo);
            wsState->sNewState = wcInfo;
            wsState->sNewparentID = wcUndo->getParent()->getId();
        }
        else
        {
            wsState->sNewState = NULL;
            wsState->sNewparentID = QString("");
        }
        mCurrentlyHandled = const_cast<WidgetController *>(cmUndefinedPointer);
    }
}

/*****************************************************************************\
 *  FUNCTION    :   undoDelete
 *  PARAMETERS  :   UndoInfo *undoInf
 *                      This class contains a list of WidgetState pointers and
 *                      the Action, belonging to one Undo/Redo step.
 *  RETURN      :   void
 *
 *  This function undo's a delete action.
\*****************************************************************************/
void UndoHandler::undoDelete(UndoInfo *undoInf)
{
    if (undoInf != NULL)
    {
        Model::instance()->deselectAll();
        for (int ind = undoInf->sStateList.size() - 1; ind >= 0; --ind)
        {
            WidgetState *wsState = undoInf->sStateList.at(ind);
            if (wsState != NULL)
            {
                WidgetController *wcParent = Model::instance()->getWidgetController(wsState->sOldParentID);
                if (NULL == wcParent)
                {
                    wcParent = dynamic_cast<WidgetController*>(const_cast<FormEditor*>(Model::instance()->getFormEditor()));
                }
                WidgetController *wcPrev = wsState->sPrevState->addToWidget(wcParent, false);
                Model::instance()->addToSelectionList(wcPrev);
                Model::instance()->getModelHandler()->newWidgetProperties(wcPrev);
                Model::instance()->getModelHandler()->newWidgetSelection(wcPrev);
            }
        }
        Model::instance()->getModelHandler()->sendNewWidget();
    }
}

/*****************************************************************************\
 *  FUNCTION    :   undoNew
 *  PARAMETERS  :   UndoInfo *undoInf
 *                      This class contains a list of WidgetState pointers and
 *                      the Action, belonging to one Undo/Redo step.
 *  RETURN      :   void
 *
 *  This function undo's a new action.
\*****************************************************************************/
void UndoHandler::undoNew(UndoInfo *undoInf)
{
    if (undoInf != NULL)
    {
        BOOST_FOREACH(WidgetState * wsState, undoInf->sStateList)
        {
            if (wsState != NULL)
            {
                WidgetController *wcNew = Model::instance()->getWidgetController(wsState->sNewState->getPropertyValue(SUI::ObjectPropertyTypeEnum::ID));
                if (wcNew != NULL)
                {
                    WidgetController    *wcParent = wcNew->getParent();
                    wcParent->removeChild(wcNew);

                    if (wcNew->getObjectType() == SUI::ObjectType::UserControl)
                    {
                        Model::instance()->removeUsedUserControl(wcNew->getId());
                        wcNew->removeFromModel();
                    }
                    wcNew->deleteLater();
                    Model::instance()->setNewSelected(NULL);
                    Model::instance()->getModelHandler()->newWidgetSelection(wcParent);
                    Model::instance()->getModelHandler()->newWidgetProperties(wcParent);
                }
            }
        }
        Model::instance()->getModelHandler()->sendNewWidget();
    }
}

/*****************************************************************************\
 *  FUNCTION    :   undoMove
 *  PARAMETERS  :   UndoInfo *undoInf
 *                      This class contains a list of WidgetState pointers and
 *                      the Action, belonging to one Undo/Redo step.
 *  RETURN      :   void
 *
 *  This function undo's a move action. There is a difference between a move
 *  within the same parent, or a move from one parent to another parent.
 *  If the parent in the previous state is the same as the parent in the new
 *  state, we could have just simply moved the widget. But since this action is
 *  also used for To Forground / To Background, we have to delete the new state
 *  and add the previous state.
\*****************************************************************************/
void UndoHandler::undoMove(UndoInfo *undoInf)
{
    if (undoInf != NULL)
    {
        BOOST_FOREACH(WidgetState * wsState, undoInf->sStateList)
        {
            if (wsState != NULL)
            {
                WidgetController *wcCurrent = Model::instance()->getWidgetController(wsState->sPrevState->getPropertyValue(SUI::ObjectPropertyTypeEnum::ID));
                if (wcCurrent != NULL)
                {
                    WidgetController *wcPrev = wsState->sPrevState->addToWidget(Model::instance()->getWidgetController(wsState->sOldParentID), false);
                    if (wcCurrent->getParent() != NULL)
                    {
                        wcCurrent->getParent()->removeChild(wcCurrent);
                    }
                    wcCurrent->deleteLater();
                    Model::instance()->addToSelectionList(wcPrev);
                    Model::instance()->getModelHandler()->newWidgetProperties(wcPrev);
                    Model::instance()->getModelHandler()->newWidgetSelection(wcPrev);
                }
                Model::instance()->getModelHandler()->sendNewWidget();
            }
        }
    }
}

/*****************************************************************************\
 *  FUNCTION    :   undoProperty
 *  PARAMETERS  :   UndoInfo *undoInf
 *                      This class contains a list of WidgetState pointers and
 *                      the Action, belonging to one Undo/Redo step.
 *  RETURN      :   void
 *
 *  This function undo's a property change action.
\*****************************************************************************/
void UndoHandler::undoProperty(UndoInfo *undoInf)
{
    if (undoInf != NULL)
    {
        Model::instance()->deselectAll();
        BOOST_FOREACH(WidgetState * wsState, undoInf->sStateList)
        {
            if (wsState != NULL)
            {
                WidgetController *wcCurrent = Model::instance()->getWidgetController(wsState->sPrevState->getPropertyValue(SUI::ObjectPropertyTypeEnum::ID));
                if (wcCurrent != NULL)
                {
                    BOOST_FOREACH(SUI::ObjectPropertyTypeEnum::Type property, wsState->sPrevState->getPropertyTypes())
                    {
                        if (wcCurrent->getPropertyValue(property) != wsState->sPrevState->getPropertyValue(property))
                        {
                            wcCurrent->setPropertyValue(property, wsState->sPrevState->getPropertyValue(property));
                        }
                    }
                    if (wcCurrent->getObjectType() == SUI::ObjectType::TextArea)
                    {
                        dynamic_cast<SUI::TextAreaImpl *>(wcCurrent->getBaseWidget())->clearText();
                        wcCurrent->setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, "TBD");
                        wcCurrent->setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, wsState->sPrevState->getPropertyValue(SUI::ObjectPropertyTypeEnum::Text));
                    }
                    else if (wcCurrent->getObjectType() == SUI::ObjectType::TreeViewItem)
                    {
                        WidgetController *wcParent = wcCurrent;
                        while (wcParent->getObjectType() != SUI::ObjectType::TreeView)
                        {
                            wcParent = wcParent->getParent();
                        }
                        wcParent->updatePixmap();
                    }
                }
                else
                {
                    //  Property ID has been changed
                    wcCurrent = Model::instance()->getWidgetController(wsState->sNewState->getPropertyValue(SUI::ObjectPropertyTypeEnum::ID));
                    if (wcCurrent != NULL)
                    {
                        wcCurrent->setPropertyValue(SUI::ObjectPropertyTypeEnum::ID, wsState->sPrevState->getPropertyValue(SUI::ObjectPropertyTypeEnum::ID));
                        if (wcCurrent->getObjectType() == SUI::ObjectType::TableWidget)
                        {
                            wcCurrent->renameTableWidgetItems();
                        }
                    }
                }
                if (wcCurrent != NULL)
                {
                    Model::instance()->addToSelectionList(wcCurrent);
                    Model::instance()->getModelHandler()->newWidgetProperties(wcCurrent);
                    Model::instance()->getModelHandler()->newWidgetSelection(wcCurrent);
                    wcCurrent->updatePixmap();
                    if ((wcCurrent->getParent()!=NULL) && (wcCurrent->getParent()->getObjectType() == SUI::ObjectType::TableWidget))
                    {
                        wcCurrent->getParent()->updatePixmap();
                    }
                }
            }
        }
        Model::instance()->getModelHandler()->sendNewWidget();
    }
}

/*****************************************************************************\
 *  FUNCTION    :   undoComplexChange
 *  PARAMETERS  :   UndoInfo *undoInf
 *                      This class contains a list of WidgetState pointers and
 *                      the Action, belonging to one Undo/Redo step.
 *  RETURN      :   void
 *
 *  This function undo's a complex change action. In case ot the deletion of the
 *  MainTabWidget, the previous state is the MainTabWidget and the new state
 *  is the WidgetPage.
\*****************************************************************************/
void UndoHandler::undoComplexChange(UndoInfo *undoInf)
{
    if (undoInf != NULL)
    {
        Model::instance()->deselectAll();
        WidgetController *wcPrev = NULL;
        BOOST_FOREACH(WidgetState * wsState, undoInf->sStateList)
        {
            if (wsState != NULL)
            {
                bool    bIsTopWidget = false;
                WidgetController *wcCurrent = Model::instance()->getWidgetController(wsState->sNewState->getPropertyValue(SUI::ObjectPropertyTypeEnum::ID));
                WidgetController *wcParent = Model::instance()->getWidgetController(wsState->sOldParentID);
                if (NULL == wcParent)
                {
                    wcParent = const_cast<FormEditor*>(Model::instance()->getFormEditor());
                    bIsTopWidget = true;
                }
                wcPrev = wsState->sPrevState->addToWidget(wcParent, false);
                wcParent->removeChild(wcCurrent);
                wcCurrent->deleteLater();
                Model::instance()->getModelHandler()->newWidgetProperties(wcPrev);
                Model::instance()->getModelHandler()->newWidgetSelection(wcPrev);
                Model::instance()->addToSelectionList(wcPrev);
                if (bIsTopWidget)
                {
                    Model::instance()->setTopWidget(wcPrev);
                }
            }
        }
        Model::instance()->getModelHandler()->sendNewWidget();
    }
}

/*****************************************************************************\
 *  FUNCTION    :   undoUCtrl
 *  PARAMETERS  :   UndoInfo *undoInf
 *                      This class contains a list of WidgetState pointers and
 *                      the Action, belonging to one Undo/Redo step.
 *  RETURN      :   void
 *
 *  This function undo's the creation of a UserControl.
\*****************************************************************************/
void UndoHandler::undoUCtrl(UndoInfo *undoInf)
{
    if (undoInf != NULL)
    {
        Model::instance()->deselectAll();
        if (undoInf->sStateList.count() > 0)
        {
            WidgetController *wcNew = Model::instance()->getWidgetController(undoInf->sStateList.at(0)->sNewState->getPropertyValue(SUI::ObjectPropertyTypeEnum::ID));
            wcNew->getParent()->removeChild(wcNew);
            Model::instance()->removeUsedUserControl(wcNew->getId());
            wcNew->deleteLater();
        }
        BOOST_FOREACH(WidgetState * wsState, undoInf->sStateList)
        {
            if (wsState != NULL)
            {
                WidgetController *wcOldParent = Model::instance()->getWidgetController(wsState->sOldParentID);
                WidgetController *wcPrev = wsState->sPrevState->addToWidget(wcOldParent, false);
                Model::instance()->addToSelectionList(wcPrev);
                Model::instance()->getModelHandler()->newWidgetProperties(wcPrev);
                Model::instance()->getModelHandler()->newWidgetSelection(wcPrev);
            }
        }
        Model::instance()->getModelHandler()->sendNewWidget();
    }

}

/*****************************************************************************\
 *  FUNCTION    :   undoSplitUCtrl
 *  PARAMETERS  :   UndoInfo *undoInf
 *                      This class contains a list of WidgetState pointers and
 *                      the Action, belonging to one Undo/Redo step.
 *  RETURN      :   void
 *
 *  This function undo's the splitting of a UserControl.
\*****************************************************************************/
void UndoHandler::undoSplitUCtrl(UndoInfo *undoInf)
{
    if (undoInf != NULL)
    {
        Model::instance()->deselectAll();
        BOOST_FOREACH(WidgetState * wsState, undoInf->sStateList)
        {
            if (wsState != NULL)
            {
                WidgetController *wcPrev = Model::instance()->getWidgetController(wsState->sNewState->getPropertyValue(SUI::ObjectPropertyTypeEnum::ID));
                if (wcPrev != NULL)
                {
                    wcPrev->getParent()->removeChild(wcPrev);
                    wcPrev->deleteLater();
                }
            }
        }
        if (undoInf->sStateList.count() > 0)
        {
            WidgetController *wcParent = Model::instance()->getWidgetController(undoInf->sStateList.at(0)->sOldParentID);
            WidgetController *wcUCtrl = undoInf->sStateList.at(0)->sPrevState->addToWidget(wcParent, false);
            Model::instance()->addUsedUserControl(wcUCtrl->getId());
            Model::instance()->getModelHandler()->sendNewWidget();
            Model::instance()->addToSelectionList(wcUCtrl);
            Model::instance()->getModelHandler()->newWidgetProperties(wcUCtrl);
            Model::instance()->getModelHandler()->newWidgetSelection(wcUCtrl);
        }
    }
}

/*****************************************************************************\
 *  FUNCTION    :   redoNew
 *  PARAMETERS  :   UndoInfo *undoInf
 *                      This class contains a list of WidgetState pointers and
 *                      the Action, belonging to one Undo/Redo step.
 *  RETURN      :   void
 *
 *  This function redo's a new action.
\*****************************************************************************/
void UndoHandler::redoNew(UndoInfo *undoInf)
{
    if (undoInf != NULL)
    {
        Model::instance()->deselectAll();
        BOOST_FOREACH(WidgetState * wsState, undoInf->sStateList)
        {
            WidgetController    *wcParent = Model::instance()->getWidgetController(wsState->sNewparentID);
            WidgetController    *wcNew = wsState->sNewState->addToWidget(wcParent, false);
            Model::instance()->addToSelectionList(wcNew);
            Model::instance()->getModelHandler()->newWidgetProperties(wcNew);
            Model::instance()->getModelHandler()->newWidgetSelection(wcNew);
        }
        Model::instance()->getModelHandler()->sendNewWidget();
    }
}

/*****************************************************************************\
 *  FUNCTION    :   redoDelete
 *  PARAMETERS  :   UndoInfo *undoInf
 *                      This class contains a list of WidgetState pointers and
 *                      the Action, belonging to one Undo/Redo step.
 *  RETURN      :   void
 *
 *  This function redo's a delete action.
\*****************************************************************************/
void UndoHandler::redoDelete(UndoInfo *undoInf)
{
    if (undoInf != NULL)
    {
        BOOST_FOREACH(WidgetState * wsState, undoInf->sStateList)
        {
            WidgetController    *wcDelete = Model::instance()->getWidgetController(wsState->sPrevState->getPropertyValue(SUI::ObjectPropertyTypeEnum::ID));
            WidgetController    *wcParent = wcDelete->getParent();
            wcParent->removeChild(wcDelete);
            if (wcDelete->getObjectType() == SUI::ObjectType::UserControl)
            {
                Model::instance()->removeUsedUserControl(wcDelete->getId());
                wcDelete->removeFromModel();
            }
            wcDelete->deleteLater();
            Model::instance()->getModelHandler()->sendNewWidget();
            Model::instance()->setNewSelected(wcParent);
        }
    }
}

/*****************************************************************************\
 *  FUNCTION    :   redoMove
 *  PARAMETERS  :   UndoInfo *undoInf
 *                      This class contains a list of WidgetState pointers and
 *                      the Action, belonging to one Undo/Redo step.
 *  RETURN      :   void
 *
 *  This function redo's a move action.
 *  If the parent in the previous state is the same as the parent in the new
 *  state, we could have just simply moved the widget. But since this action is
 *  also used for To Forground / To Background, we have to delete the previous
 *  state and add the new state.
\*****************************************************************************/
void UndoHandler::redoMove(UndoInfo *undoInf)
{
    if (undoInf != NULL)
    {
        BOOST_FOREACH(WidgetState * wsState, undoInf->sStateList)
        {
            if (wsState != NULL)
            {
                WidgetController *wcCurrent = Model::instance()->getWidgetController(wsState->sPrevState->getPropertyValue(SUI::ObjectPropertyTypeEnum::ID));
                if (wcCurrent != NULL)
                {
                    WidgetController *wcNew = wsState->sNewState->addToWidget(Model::instance()->getWidgetController(wsState->sNewparentID),false);
                    wcCurrent->getParent()->removeChild(wcCurrent);
                    wcCurrent->deleteLater();
                    Model::instance()->addToSelectionList(wcNew);
                    Model::instance()->getModelHandler()->newWidgetProperties(wcNew);
                    Model::instance()->getModelHandler()->newWidgetSelection(wcNew);
                }
            }
        }
        Model::instance()->getModelHandler()->sendNewWidget();
    }
}

/*****************************************************************************\
 *  FUNCTION    :   redoProperty
 *  PARAMETERS  :   UndoInfo *undoInf
 *                      This class contains a list of WidgetState pointers and
 *                      the Action, belonging to one Undo/Redo step.
 *  RETURN      :   void
 *
 *  This function redo's a property change action.
\*****************************************************************************/
void UndoHandler::redoProperty(UndoInfo *undoInf)
{
    if (undoInf != NULL)
    {
        Model::instance()->deselectAll();
        BOOST_FOREACH(WidgetState * wsState, undoInf->sStateList)
        {
            if (wsState != NULL)
            {
                WidgetController *wcCurrent = Model::instance()->getWidgetController(wsState->sNewState->getPropertyValue(SUI::ObjectPropertyTypeEnum::ID));
                if (wcCurrent != NULL)
                {
                    BOOST_FOREACH(SUI::ObjectPropertyTypeEnum::Type property, wsState->sNewState->getPropertyTypes())
                    {
                        if (wcCurrent->getPropertyValue(property) != wsState->sNewState->getPropertyValue(property))
                        {
                            wcCurrent->setPropertyValue(property, wsState->sNewState->getPropertyValue(property));
                        }
                    }
                    if (wcCurrent->getObjectType() == SUI::ObjectType::TextArea)
                    {
                        dynamic_cast<SUI::TextAreaImpl *>(wcCurrent->getBaseWidget())->clearText();
                        wcCurrent->setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, "TBD");
                        wcCurrent->setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, wsState->sPrevState->getPropertyValue(SUI::ObjectPropertyTypeEnum::Text));
                    }
                    else if (wcCurrent->getObjectType() == SUI::ObjectType::TreeViewItem)
                    {
                        WidgetController *wcParent = wcCurrent;
                        while (wcParent->getObjectType() != SUI::ObjectType::TreeView)
                        {
                            wcParent = wcParent->getParent();
                        }
                        wcParent->updatePixmap();
                    }
                }
                else
                {
                    //  Property ID has been changed
                    wcCurrent = Model::instance()->getWidgetController(wsState->sPrevState->getPropertyValue(SUI::ObjectPropertyTypeEnum::ID));
                    if (wcCurrent != NULL)
                    {
                        wcCurrent->setPropertyValue(SUI::ObjectPropertyTypeEnum::ID, wsState->sNewState->getPropertyValue(SUI::ObjectPropertyTypeEnum::ID));
                        if (wcCurrent->getObjectType() == SUI::ObjectType::TableWidget)
                        {
                            wcCurrent->renameTableWidgetItems();
                        }
                    }
                }
                if (wcCurrent != NULL)
                {
                    Model::instance()->addToSelectionList(wcCurrent);
                    Model::instance()->getModelHandler()->newWidgetProperties(wcCurrent);
                    Model::instance()->getModelHandler()->newWidgetSelection(wcCurrent);
                    wcCurrent->updatePixmap();
                    if ((wcCurrent->getParent()!= NULL) && (wcCurrent->getParent()->getObjectType() == SUI::ObjectType::TableWidget))
                    {
                        wcCurrent->getParent()->updatePixmap();
                    }
                }
            }
        }
        Model::instance()->getModelHandler()->sendNewWidget();
    }
}

/*****************************************************************************\
 *  FUNCTION    :   redoComplexChange
 *  PARAMETERS  :   UndoInfo *undoInf
 *                      This class contains a list of WidgetState pointers and
 *                      the Action, belonging to one Undo/Redo step.
 *  RETURN      :   void
 *
 *  This function redo's a complex change action.
\*****************************************************************************/
void UndoHandler::redoComplexChange(UndoInfo *undoInf)
{
    if (undoInf != NULL)
    {
        Model::instance()->deselectAll();
        WidgetController *wcNew = NULL;
        BOOST_FOREACH(WidgetState * wsState, undoInf->sStateList)
        {
            if (wsState != NULL)
            {
                bool    bIsTopWidget = false;
                WidgetController *wcCurrent = Model::instance()->getWidgetController(wsState->sPrevState->getPropertyValue(SUI::ObjectPropertyTypeEnum::ID));
                WidgetController *wcParent = Model::instance()->getWidgetController(wsState->sNewparentID);
                if (NULL == wcParent)
                {
                    wcParent = const_cast<FormEditor*>(Model::instance()->getFormEditor());
                    bIsTopWidget = true;
                }
                wcNew = wsState->sNewState->addToWidget(wcParent, false);
                wcParent->removeChild(wcCurrent);
                wcCurrent->deleteLater();
                Model::instance()->addToSelectionList(wcNew);
                Model::instance()->getModelHandler()->newWidgetProperties(wcNew);
                Model::instance()->getModelHandler()->newWidgetSelection(wcNew);
                if (bIsTopWidget)
                {
                    Model::instance()->setTopWidget(wcNew);
                }
            }
        }
        Model::instance()->getModelHandler()->sendNewWidget();
    }
}

/*****************************************************************************\
 *  FUNCTION    :   redoUCtrl
 *  PARAMETERS  :   UndoInfo *undoInf
 *                      This class contains a list of WidgetState pointers and
 *                      the Action, belonging to one Undo/Redo step.
 *  RETURN      :   void
 *
 *  This function redo's a UserControl change action, which recreates the
 *  UserControl.
\*****************************************************************************/
void UndoHandler::redoUCtrl(UndoInfo *undoInf)
{
    if (undoInf != NULL)
    {
        Model::instance()->deselectAll();
        BOOST_FOREACH(WidgetState * wsState, undoInf->sStateList)
        {
            WidgetController *wcPrev = Model::instance()->getWidgetController(wsState->sPrevState->getPropertyValue(SUI::ObjectPropertyTypeEnum::ID));
            wcPrev->getParent()->removeChild(wcPrev);
            wcPrev->deleteLater();
        }
        if (undoInf->sStateList.count() > 0)
        {
            WidgetController *wcParent = Model::instance()->getWidgetController(undoInf->sStateList.at(0)->sNewparentID);
            WidgetController *wcUCtrl = undoInf->sStateList.at(0)->sNewState->addToWidget(wcParent, false);
            Model::instance()->addUsedUserControl(wcUCtrl->getId());
            Model::instance()->getModelHandler()->sendNewWidget();
            Model::instance()->addToSelectionList(wcUCtrl);
            Model::instance()->getModelHandler()->newWidgetProperties(wcUCtrl);
            Model::instance()->getModelHandler()->newWidgetSelection(wcUCtrl);
        }
    }
}

/*****************************************************************************\
 *  FUNCTION    :   redoSplitUCtrl
 *  PARAMETERS  :   UndoInfo *undoInf
 *                      This class contains a list of WidgetState pointers and
 *                      the Action, belonging to one Undo/Redo step.
 *  RETURN      :   void
 *
 *  This function redo's the splitting of a UserControl.
\*****************************************************************************/
void UndoHandler::redoSplitUCtrl(UndoInfo *undoInf)
{
    if (undoInf != NULL)
    {
        Model::instance()->deselectAll();
        if (undoInf->sStateList.count() > 0)
        {
            WidgetController *wcPrev = Model::instance()->getWidgetController(undoInf->sStateList.at(0)->sPrevState->getPropertyValue(SUI::ObjectPropertyTypeEnum::ID));
            Model::instance()->removeUsedUserControl(wcPrev->getId());
            wcPrev->getParent()->removeChild(wcPrev);
            wcPrev->deleteLater();
        }
        BOOST_FOREACH(WidgetState * wsState, undoInf->sStateList)
        {
            if (wsState != NULL)
            {
                WidgetController *wcParent = Model::instance()->getWidgetController(wsState->sNewparentID);
                WidgetController *wcNew = wsState->sNewState->addToWidget(wcParent, false);
                Model::instance()->addToSelectionList(wcNew);
                Model::instance()->getModelHandler()->newWidgetProperties(wcNew);
                Model::instance()->getModelHandler()->newWidgetSelection(wcNew);
            }
        }
        Model::instance()->getModelHandler()->sendNewWidget();
    }
}

/*****************************************************************************\
 *  FUNCTION    :   undo
 *  PARAMETERS  :   n.a.
 *  RETURN      :   void
 *
 *  This function executes one undo step. It retrieves the previous step from
 *  the Undo Buffer and, depending on the action, redirects it to the
 *  appropriate undo function.
\*****************************************************************************/
void UndoHandler::undo()
{
    UndoInfo    *prevStep = const_cast<UndoInfo *>(mUndoBuffer.prev());
    if (prevStep != NULL)
    {
        switch (prevStep->sAction)
        {
        case ACT_NEW:
            undoNew(prevStep);
            break;
        case ACT_DELETE:
            undoDelete(prevStep);
            break;
        case ACT_MOVE:
            undoMove(prevStep);
            break;
        case ACT_PROPERTY:
            undoProperty(prevStep);
            break;
        case ACT_COMPLEX:
            undoComplexChange(prevStep);
            break;
        case ACT_UCTRL:
            undoUCtrl(prevStep);
            break;
        case ACT_SPLITUCTRL:
            undoSplitUCtrl(prevStep);
            break;
        default:
            break;
        }
        if ((prevStep->sStateList.at(0)!= NULL) && prevStep->sStateList.at(0)->sIsSaved)
        {
            QTimer::singleShot(10, const_cast<MainWindow*>(Model::instance()->getMainWindow()), SLOT(onLoadFinished()));
        }
    }
}

/*****************************************************************************\
 *  FUNCTION    :   redo
 *  PARAMETERS  :   n.a.
 *  RETURN      :   void
 *
 *  This function executes one redo step. It retrieves the next step from the
 *  Undo Buffer and, depending on the action, redirects it to the appropriate
 *  redo function.
\*****************************************************************************/
void UndoHandler::redo()
{
    UndoInfo    *nextStep = const_cast<UndoInfo *>(mUndoBuffer.next());
    if (nextStep != NULL)
    {
        switch (nextStep->sAction)
        {
        case ACT_NEW:
            redoNew(nextStep);
            break;
        case ACT_DELETE:
            redoDelete(nextStep);
            break;
        case ACT_MOVE:
            redoMove(nextStep);
            break;
        case ACT_PROPERTY:
            redoProperty(nextStep);
            break;
        case ACT_COMPLEX:
            redoComplexChange(nextStep);
            break;
        case ACT_UCTRL:
            redoUCtrl(nextStep);
            break;
        case ACT_SPLITUCTRL:
            redoSplitUCtrl(nextStep);
            break;
        default:
            break;
        }
        if ((nextStep->sStateList.at(0) != NULL) && nextStep->sStateList.at(0)->sIsSaved)
        {
            QTimer::singleShot(10, const_cast<MainWindow*>(Model::instance()->getMainWindow()), SLOT(onLoadFinished()));
        }
    }
}

/*****************************************************************************\
 *  FUNCTION    :   deleteWidgetState
 *  PARAMETERS  :   WidgetState *wsState
 *                      The WidgetState to be deleted
 *  RETURN      :   void
 *
 *  This function executes one redo step. It retrieves the next step from the
 *  Undo Buffer and, depending on the action, redirects it to the appropriate
 *  redo function.
\*****************************************************************************/
void UndoHandler::deleteWidgetState(WidgetState *wsState)
{
    if (wsState != NULL)
    {
        if (wsState->sPrevState != NULL)
        {
            delete wsState->sPrevState;
        }
        if (wsState->sNewState != NULL)
        {
            delete wsState->sNewState;
        }
        delete wsState;
        wsState = NULL;
    }
}

/*****************************************************************************\
 *  FUNCTION    :   printUndoBuffer const
 *  PARAMETERS  :   n.a.
 *  RETURN      :   void
 *
 *  This function prints the Undo Buffer. This function is merely for debugging
 *  purposes.
\*****************************************************************************/
void UndoHandler::printUndoBuffer() const
{
    QList<WidgetState *> printList = mUndoBuffer.printBuffer();
    qDebug() << "==================================================";
    BOOST_FOREACH(WidgetState * inf, printList)
    {
        if (inf != NULL)
        {
            qDebug() << "Action:          " << cmActionList.at(inf->sAction)
                     << "\nPrevious state:  " << inf->sPrevState
                     << "\nPrevious parent: " << inf->sOldParentID
                     << "\nNew state:       " << inf->sNewState
                     << "\nNew parent:      " << inf->sNewparentID;
        }
        else
        {
            qDebug() << "CurrentPoint";
        }
        qDebug() << "--------------------------------------------------";
    }
}

/*****************************************************************************\
 *  FUNCTION    :   getUndoActions const
 *  PARAMETERS  :   n.a.
 *  RETURN      :   QStringList
 *
 *  This function returns the action text of all actions in the Undo Buffer. If
 *  mCuurentPoint is not at the top of the Undo Buffer (after one or more
 *  undo's), an empty line is placed above the mCurrentPoint.
\*****************************************************************************/
QStringList UndoHandler::getUndoActions() const
{
    QStringList actionList;
    QList<WidgetState *> printList = mUndoBuffer.printBuffer();
    BOOST_FOREACH(WidgetState * inf, printList)
    {
        if (inf != NULL)
        {
            actionList.append(inf->sActionText);
        }
        else
        {
            actionList.append(QString(""));
        }
    }
    return actionList;
}

/*****************************************************************************\
 *  FUNCTION    :   onDeleteUndoInfo
 *  PARAMETERS  :   UndoInfo *undoInf
 *  RETURN      :   void
 *
 *  This is a SLOT function, emitted by CircularList::doDelete(). We have to
 *  delete the WidgetState's here, because it can not be done in the
 *  CircularList class, because we can not include rticWidgetDefinition.h there.
 *  That would create a circular dependency.
\*****************************************************************************/
void UndoHandler::onDeleteUndoInfo(UndoInfo *undoInf)
{
    BOOST_FOREACH(WidgetState * wcChild, undoInf->sStateList)
    {
        deleteWidgetState(wcChild);
    }
}

/*****************************************************************************\
 *  FUNCTION    :   onEnableUndo
 *  PARAMETERS  :   bool enable
 *  RETURN      :   void
 *
 *  This is a SLOT function, emitted by CircularList::doEnableUndo. It emits a
 *  a signal meant for MainWindow to enable / disable the undo action.
\*****************************************************************************/
void UndoHandler::onEnableUndo(bool enable)
{
    emit doEnableUndo(enable);
}

/*****************************************************************************\
 *  FUNCTION    :   onEnableRedo
 *  PARAMETERS  :   bool enable
 *  RETURN      :   void
 *
 *  This is a SLOT function, emitted by CircularList::doEnableRedo. It emits a
 *  signal meant for MainWindow to enable / disable the redo action.
\*****************************************************************************/
void UndoHandler::onEnableRedo(bool enable)
{
    emit doEnableRedo(enable);
}

/*****************************************************************************\
 *  FUNCTION    :   onSendUndoRedoText
 *  PARAMETERS  :   const QString &undotxt
 *                      The text belonging to the Undo action.
 *                  const QString &redotxt
 *                      The text belonging to the Redo action.
 *  RETURN      :   void
 *
 *  This is a SLOT function, emitted by CircularList::sendUndoRedoText. It
 *  emits a signal meant for MainWindow to display the undo and redo texts.
\*****************************************************************************/
void UndoHandler::onSendUndoRedoText(const QString &undotxt, const QString &redotxt)
{
    emit doSendUndoRedoText(undotxt, redotxt);
}
