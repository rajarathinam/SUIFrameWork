//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SplashScreen.
// !\description Header file for class SplashScreen.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SPLASHSCREEN_H
#define SPLASHSCREEN_H

#include <QSplashScreen>
#include <QProgressBar>
#include <QLabel>
#include <QVBoxLayout>

class SplashScreen : public QSplashScreen
{
    Q_OBJECT
public:
    SplashScreen();
    virtual ~SplashScreen();

private:
    int mWidgetCount;
    QVBoxLayout  *mLayout;
    QProgressBar *mProgress;
    QLabel *mTextLabel;

private slots:
    void onWidgetProcessed();
    void onNewMessage(QString msg);
    void onSetWidgetCount(int count);
};

#endif // SPLASHSCREEN_H
