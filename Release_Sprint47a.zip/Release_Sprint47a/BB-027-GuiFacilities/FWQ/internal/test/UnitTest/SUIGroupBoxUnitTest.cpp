#include "SUIGroupBoxUnitTest.h"
#include <FWQxWidgets/SUIGroupBox.h>
#include <QTest>
#include "SUIITextUnitTest.h"
#include "SUIIBGColorableUnitTest.h"

SUI::GroupBoxUnitTest::GroupBoxUnitTest(SUI::GroupBox *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::GroupBoxUnitTest::~GroupBoxUnitTest() {
    delete object;
}

void SUI::GroupBoxUnitTest::callInterfaceTests() {
    // IText UnitTests
    ITextUnitTest iTextUnitTest(object);
    QVERIFY(iTextUnitTest.setText());
    QVERIFY(iTextUnitTest.clearText());
    QVERIFY(iTextUnitTest.setBold());

    //IBGColorable tests
    IBGColorableUnitTest iBGColorableUnitTest(object);
    //valid colors
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Standard));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Black));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Green));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Red));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Gray));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Blue));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::White));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Yellow));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Orange));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Transparent));
}

