
#ifndef SUISPLITTERIMPLUNITTEST_H
#define SUISPLITTERIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class SplitterImpl;

class SplitterImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit SplitterImplUnitTest(SplitterImpl *object, QObject *parent = 0);
    virtual ~SplitterImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    SplitterImpl *object;
};

}
#endif // SUISPLITTERIMPLUNITTEST_H
