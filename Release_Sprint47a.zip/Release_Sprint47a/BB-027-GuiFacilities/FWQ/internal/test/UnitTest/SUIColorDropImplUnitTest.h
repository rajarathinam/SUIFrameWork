
#ifndef SUICOLORDROPIMPLUNITTEST_H
#define SUICOLORDROPIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class ColorDropImpl;

class ColorDropImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit ColorDropImplUnitTest(ColorDropImpl *object, QObject *parent = 0);
    virtual ~ColorDropImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    ColorDropImpl *object;
};

}
#endif // SUICOLORDROPIMPLUNITTEST_H
