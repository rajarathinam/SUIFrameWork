#include "SUIScienceSpinBoxUnitTest.h"
#include <FWQxWidgets/SUIScienceSpinBox.h>
#include "SUIIAlignableUnitTest.h"
#include "SUIIErrorModeUnitTest.h"
#include <QTest>

SUI::ScienceSpinBoxUnitTest::ScienceSpinBoxUnitTest(SUI::ScienceSpinBox *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::ScienceSpinBoxUnitTest::~ScienceSpinBoxUnitTest()
{
    delete object;
}

void SUI::ScienceSpinBoxUnitTest::callInterfaceTests()
{
    //IAlignable unit test
    IAlignableUnitTest iAlignableUnitTest(object);
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::HCenter));
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Left));
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Right));
    QCOMPARE(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Stretch), false );

    //IErrorMode
    IErrorModeUnitTest iErrorModeUnitTest(object);
    QVERIFY(iErrorModeUnitTest.setErrorMode());
}
