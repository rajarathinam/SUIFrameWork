
#ifndef SUITABPAGEIMPLUNITTEST_H
#define SUITABPAGEIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class TabPageImpl;

class TabPageImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit TabPageImplUnitTest(TabPageImpl *object, QObject *parent = 0);
    virtual ~TabPageImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    TabPageImpl *object;
};

}
#endif // SUITABPAGEIMPLUNITTEST_H
