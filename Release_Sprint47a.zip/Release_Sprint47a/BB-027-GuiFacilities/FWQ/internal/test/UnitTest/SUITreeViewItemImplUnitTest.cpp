
#include "SUITreeViewItemImplUnitTest.h"
#include "SUITreeViewItemImpl.h"
#include "SUIBaseObject.h"

SUI::TreeViewItemImplUnitTest::TreeViewItemImplUnitTest(SUI::TreeViewItemImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::TreeViewItemImplUnitTest::~TreeViewItemImplUnitTest()
{
   delete object;
}

void SUI::TreeViewItemImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::EditorForm);
    object->setDefaultProperties(SUI::BaseObject::EditorSelector);
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
