
#ifndef SUITABLEWIDGETITEMIMPLUNITTEST_H
#define SUITABLEWIDGETITEMIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class TableWidgetItemImpl;

class TableWidgetItemImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit TableWidgetItemImplUnitTest(TableWidgetItemImpl *object, QObject *parent = 0);
    virtual ~TableWidgetItemImplUnitTest();

private slots:
    void setDefaultProperties();
    void callInterfaceTests();
    void colorPropertyTest();

private:
    TableWidgetItemImpl *object;
};

}
#endif // SUITABLEWIDGETITEMIMPLUNITTEST_H
