
#ifndef SUIFILEDIALOGIMPLUNITTEST_H
#define SUIFILEDIALOGIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class FileDialogImpl;

class FileDialogImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit FileDialogImplUnitTest(FileDialogImpl *object, QObject *parent = 0);
    virtual ~FileDialogImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    FileDialogImpl *object;
};

}
#endif // SUIFILEDIALOGIMPLUNITTEST_H
