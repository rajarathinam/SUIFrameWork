#include "SUIProgressBarUnitTest.h"
#include "SUIIColorableUnitTest.h"
#include "SUIITextUnitTest.h"
#include "SUIIOrientableUnitTest.h"
#include <QTest>

SUI::ProgressBarUnitTest::ProgressBarUnitTest(SUI::ProgressBar *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::ProgressBarUnitTest::~ProgressBarUnitTest() {
    delete object;
}

void SUI::ProgressBarUnitTest::callInterfaceTests() {
    // IText UnitTests
    ITextUnitTest iTextUnitTest(object);
    // ProgressBar sets text as value, so must be numeric
    // default interface tests will fail because of this
    //QVERIFY(iTextUnitTest.setText());
    //QVERIFY(iTextUnitTest.clearText());
    QVERIFY(iTextUnitTest.setBold());

    //IColorable tests
    IColorableUnitTest iColorableUnitTest(object);
    // Valid colors
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Standard));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Green));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Red));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Gray));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Blue));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Yellow));
    // Invalid colors
    object->setColor(SUI::ColorEnum::Black);
    QCOMPARE(object->getColor(), SUI::ColorEnum::Yellow);
    object->setColor(SUI::ColorEnum::White);
    QCOMPARE(object->getColor(), SUI::ColorEnum::Yellow);
    object->setColor(SUI::ColorEnum::Orange);
    QCOMPARE(object->getColor(), SUI::ColorEnum::Yellow);
    object->setColor(SUI::ColorEnum::Transparent);
    QCOMPARE(object->getColor(), SUI::ColorEnum::Yellow);

    //IOrientable UnitTest
    IOrientableUnitTest iOrientableUnitTest(object);
    QVERIFY(iOrientableUnitTest.setOrientation(OrientationEnum::Horizontal));
    QVERIFY(iOrientableUnitTest.setOrientation(OrientationEnum::Vertical));
}

void SUI::ProgressBarUnitTest::setText() {
    const std::string value = "65";

    object->setText(value);
    QCOMPARE(object->getText(), value);
}

void SUI::ProgressBarUnitTest::clearText() {
    const std::string value = "80";
    const std::string empty = "0";

    object->setText(value);
    QCOMPARE(object->getText(), value);

    object->clearText();
    QCOMPARE(object->getText(), empty);
}

void SUI::ProgressBarUnitTest::setValue() {
    int value = 74;
    int low = -10;
    int high = 110;

    object->setValue(value);
    QCOMPARE(object->getValue(), value);

    // Min value is 0 so -10 shall not be accepted
    // and value remains unchanged
    object->setValue(low);
    QCOMPARE(object->getValue(), value);

    // Max value is 100 so 110 shall not be accepted
    // and value remains unchanged
    object->setValue(high);
    QCOMPARE(object->getValue(), value);
}

void SUI::ProgressBarUnitTest::disablePercentage() {
    object->disablePercentage(false);
    QVERIFY(!object->isPercentageDisabled());
    object->disablePercentage(true);
    QVERIFY(object->isPercentageDisabled());
}

void SUI::ProgressBarUnitTest::startTimedProgress() {
    object->startTimedProgress(60);
    QVERIFY(object->getText()!="100");

    object->stopTimedProgress(0);
    QVERIFY(object->getText()=="100");
}
