#ifndef SUICHECKBOXKUNITTEST_H
#define SUICHECKBOXUNITTEST_H

#include "SUIWidgetUnitTest.h"
#include "SUIICheckableUnitTest.h"

#include <QTest>
namespace SUI {

class CheckBox;

class CheckBoxUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    explicit CheckBoxUnitTest(CheckBox *object, QObject *parent = 0);
    virtual ~CheckBoxUnitTest();

protected:
    void callInterfaceTests();

private:
    CheckBox *object;
};

}
#endif // SUICHECKBOXUNITTEST_H
