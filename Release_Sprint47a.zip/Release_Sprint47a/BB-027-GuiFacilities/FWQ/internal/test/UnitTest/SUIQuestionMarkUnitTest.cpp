#include"SUIQuestionMarkUnitTest.h"

#include <FWQxWidgets/SUIQuestionMark.h>
#include <QTest>

SUI::QuestionMarkUnitTest::QuestionMarkUnitTest(SUI::QuestionMark *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::QuestionMarkUnitTest::~QuestionMarkUnitTest() {
    delete object;
}

void SUI::QuestionMarkUnitTest::callInterfaceTests() {
}

