
#ifndef SUICONTAINERIMPLUNITTEST_H
#define SUICONTAINERIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class ContainerImpl;

class ContainerImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit ContainerImplUnitTest(SUI::ContainerImpl *object, QObject *parent = 0);
    virtual ~ContainerImplUnitTest();

private slots:
    void setDefaultProperties();
    void setUIFile();

private:
    ContainerImpl *containerObject;
};

}
#endif // SUICONTAINERIMPLUNITTEST_H
