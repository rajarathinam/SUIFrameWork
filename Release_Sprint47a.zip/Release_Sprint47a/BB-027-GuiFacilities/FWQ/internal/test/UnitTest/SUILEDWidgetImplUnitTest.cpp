
#include "SUILEDWidgetImplUnitTest.h"
#include "SUILEDWidgetImpl.h"
#include "SUIBaseObject.h"

SUI::LEDWidgetImplUnitTest::LEDWidgetImplUnitTest(SUI::LEDWidgetImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::LEDWidgetImplUnitTest::~LEDWidgetImplUnitTest()
{
   delete object;
}

void SUI::LEDWidgetImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
