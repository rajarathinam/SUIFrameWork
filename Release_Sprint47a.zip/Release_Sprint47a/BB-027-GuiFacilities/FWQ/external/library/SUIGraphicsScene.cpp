//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for GraphicsScene.
// !\description Class implementation file for GraphicsScene.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "FWQxGraphicsItems/SUIGraphicsScene.h"

#include <QImage>

#include <boost/bind.hpp>

#include "FWQxGraphicsItems/SUIGraphicsItem.h"
#include "FWQxGraphicsItems/SUIGraphicsSceneMouseEvent.h"

#include "CustomGraphicsScene.h"

#include <QGraphicsSvgItem>

SUI::GraphicsScene::GraphicsScene() :
    implementation(new CustomGraphicsScene)
{
   CustomGraphicsScene *internalScene = static_cast<CustomGraphicsScene*>(implementation);
   internalScene->mousePressed = boost::bind(&GraphicsScene::onMousePressEvent,this,_1);
   internalScene->mouseMoved = boost::bind(&GraphicsScene::onMouseMoveEvent,this,_1);
   internalScene->mouseReleased = boost::bind(&GraphicsScene::onMouseReleaseEvent,this,_1);
   internalScene->mouseWheelMoved = boost::bind(&GraphicsScene::onWheelEvent,this,_1);
}

SUI::GraphicsScene::~GraphicsScene()
{
    delete static_cast<CustomGraphicsScene*>(implementation);
}

void SUI::GraphicsScene::addItem(GraphicsItem *item) {
    if ((item != NULL) && std::find(items.begin(),items.end(),item) == items.end()) {
        items.push_back(item);

        if(item->getObjectType() == SUI::ObjectType::GraphicsSvgItem) {
            static_cast<CustomGraphicsScene*>(implementation)->addItem(static_cast<QGraphicsSvgItem*>(item->implementation));
        }
        else {
            static_cast<CustomGraphicsScene*>(implementation)->addItem(static_cast<QGraphicsItem*>(item->implementation));
        }
    }
}

void SUI::GraphicsScene::removeItem(GraphicsItem *item) {
    if ((item != NULL) && std::find(items.begin(),items.end(),item) != items.end()) {
        items.remove(item);

        if(item->getObjectType() == SUI::ObjectType::GraphicsSvgItem) {
            static_cast<CustomGraphicsScene*>(implementation)->removeItem(static_cast<QGraphicsSvgItem*>(item->implementation));
        }
        else {
            static_cast<CustomGraphicsScene*>(implementation)->removeItem(static_cast<QGraphicsItem*>(item->implementation));
        }
    }
}

std::list<SUI::GraphicsItem*> SUI::GraphicsScene::getItems() const {
   return items;
}

void SUI::GraphicsScene::setBackgroundImage(unsigned char *data , int width, int height, ImageEnum::Format format) {
    static_cast<CustomGraphicsScene*>(implementation)->setBackgroundImage(data,width,height,(QImage::Format)format);
}

void SUI::GraphicsScene::setBackgroundImage(const std::string &value) {
    static_cast<CustomGraphicsScene*>(implementation)->setBackgroundImage(value);
}

void SUI::GraphicsScene::setBackgroundImageFile(const std::string &fileName) {
    static_cast<CustomGraphicsScene*>(implementation)->setBackgroundImageFile(fileName);
}

void SUI::GraphicsScene::onMousePressEvent(const boost::shared_ptr<SUI::GraphicsSceneMouseEvent> &event) {
    if (!mousePressed.empty()) {
         mousePressed(event);
    }
}

void SUI::GraphicsScene::onMouseMoveEvent(const boost::shared_ptr<SUI::GraphicsSceneMouseEvent> &event) {
    if (!mouseMoved.empty()) {
         mouseMoved(event);
    }
}

void SUI::GraphicsScene::onMouseReleaseEvent(const boost::shared_ptr<SUI::GraphicsSceneMouseEvent> &event) {
    if (!mouseReleased.empty()) {
         mouseReleased(event);
    }
}

void SUI::GraphicsScene::onWheelEvent(const boost::shared_ptr<SUI::GraphicsSceneMouseEvent> &event) {
    if (!mouseWheelMoved.empty()) {
         mouseWheelMoved(event);
    }
}
