//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for LineEdit.
// !\description Class implementation file for LineEdit.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "FWQxWidgets/SUILineEdit.h"

#include "FWQxCore/SUIObjectFactory.h"

SUI::LineEdit::LineEdit() : 
    Widget(SUI::ObjectType::LineEdit)
{
}

SUI::LineEdit::~LineEdit()
{
}
