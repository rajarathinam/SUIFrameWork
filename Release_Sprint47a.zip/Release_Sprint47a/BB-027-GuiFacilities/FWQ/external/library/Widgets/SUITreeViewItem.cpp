//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for TreeViewItem.
// !\description Class implementation file for TreeViewItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "FWQxWidgets/SUITreeViewItem.h"

#include "FWQxCore/SUIObjectFactory.h"

SUI::TreeViewItem::TreeViewItem() : 
    Widget(SUI::ObjectType::TreeViewItem)
{
}

SUI::TreeViewItem::~TreeViewItem()
{
}
