/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIApplication.cpp
| Author       :
| Description  : Class implementation file for Application.
|
| ! \file        SUIApplication.cpp
| ! \brief       Class implementation file for Application.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIApplication.h"

#include "SUIApplicationImpl.h"

SUI::Application::~Application()
{
}

boost::shared_ptr<SUI::Application> SUI::Application::createApplication(int &argc, char *argv[]) {
    return boost::shared_ptr<Application>(new ApplicationImpl(argc,argv));
}
