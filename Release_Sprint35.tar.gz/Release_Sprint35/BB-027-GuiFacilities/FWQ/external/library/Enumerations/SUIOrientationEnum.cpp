/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIOrientationEnum.cpp
| Author       :
| Description  : Class implementation file for OrientationEnum.
|
| ! \file        SUIOrientationEnum.cpp
| ! \brief       Class implementation file for OrientationEnum.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIOrientationEnum.h"

#include <algorithm>
#include <sstream>

std::map<SUI::OrientationEnum::Orientation,std::string> SUI::OrientationEnum::orientationMap = {
    {SUI::OrientationEnum::Horizontal,"Horizontal"},
    {SUI::OrientationEnum::Vertical,"Vertical"}
};

std::list<std::string> SUI::OrientationEnum::orientationStringList =
        std::list<std::string>({
                                   SUI::OrientationEnum::toString(SUI::OrientationEnum::Horizontal),
                                   SUI::OrientationEnum::toString(SUI::OrientationEnum::Vertical)
                               });

std::string SUI::OrientationEnum::toString(Orientation orientation) {
    std::map<Orientation,std::string>::const_iterator it = orientationMap.find(orientation);
    return it == orientationMap.end() ? orientationMap.find(OrientationEnum::Horizontal)->second : it->second;
}

std::list<std::string> SUI::OrientationEnum::getOrientationStringList() {
    return orientationStringList;
}

std::string SUI::OrientationEnum::toString(const std::list<Orientation> &list, const std::string &separator) {
    std::stringstream ss;
    for (std::list<OrientationEnum::Orientation>::const_iterator i = list.begin(); i != list.end(); i++)
        ss << toString(*i) << separator;

    std::string s = ss.str();
    return s.substr(0,s.size()-1);
}
