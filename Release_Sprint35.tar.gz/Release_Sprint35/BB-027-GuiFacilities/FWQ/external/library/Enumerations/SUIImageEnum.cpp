/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIImageEnum.cpp
| Author       :
| Description  : Class implementation file for ImageEnum.
|
| ! \file        SUIImageEnum.cpp
| ! \brief       Class implementation file for ImageEnum.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#include "SUIImageEnum.h"

std::string SUI::ImageEnum::getFileExtension(FileType fileType) {
    switch (fileType)
    {
    case ImageEnum::JPG:    return ".jpg";
    case ImageEnum::TIFF:   return ".tiff";
    case ImageEnum::BMP:    return ".bmp";
    case ImageEnum::PNG:    return ".png";
    default: return ""; // is never called
    }
}
