/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIDragModeEnum.cpp
| Author       :
| Description  : Class implementation file for DragModeEnum.
|
| ! \file        SUIDragModeEnum.cpp
| ! \brief       Class implementation file for DragModeEnum.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/


#include "SUIDragModeEnum.h"


SUI::DragModeEnum::Mode SUI::DragModeEnum::fromString(const std::string &mode) {
   DragModeEnum::Mode returnValue = ScrollHandDrag;       
   if (mode == "area selection") {
      returnValue = RubberBandDrag;
   }
   else if (mode == "none"){
      returnValue = None;
   }
   return returnValue;
}

std::string SUI::DragModeEnum::toString(const SUI::DragModeEnum::Mode &style) {
   std::string returnValue = "none";       
   switch (style) {
   case None: returnValue = "none"; break;
   case RubberBandDrag: returnValue = "area selection"; break;
   case ScrollHandDrag: returnValue = "panning"; break;
   }
   return returnValue;
}
