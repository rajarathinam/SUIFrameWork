/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIICloseable.cpp
| Author       :
| Description  : Class implementation file for ICloseable.
|
| ! \file        SUIICloseable.cpp
| ! \brief       Class implementation file for ICloseable.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include <SUIICloseable.h>


SUI::ICloseable::ICloseable()
{
    closeable = true ;
}

bool SUI::ICloseable::isCloseable() {
    return closeable;
}


void SUI::ICloseable::setCloseable(bool value) {
    closeable = value;
}
