/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIExternalEventHandler.cpp
| Author       :
| Description  : Class implementation file for ExternalEventHandler.
|
| ! \file        SUIExternalEventHandler.cpp
| ! \brief       Class implementation file for ExternalEventHandler.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/


#include "SUIExternalEventHandler.h"
#include "SUIExternalEventHandlerImpl.h"

#include <QApplication>

bool SUI::ExternalEventHandler::raiseEvent(SUI::ExternalEvent *event) {
    ExternalEventHandlerImpl *t = new ExternalEventHandlerImpl(event);
    t->moveToThread(QApplication::instance()->thread());
    return QMetaObject::invokeMethod(t, "emitEvent", Qt::QueuedConnection);
}
