/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUILineWidget.cpp
| Author       :
| Description  : Class implementation file for LineWidget.
|
| ! \file        SUILineWidget.cpp
| ! \brief       Class implementation file for LineWidget.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUILineWidget.h"

#include "SUIObjectFactory.h"

SUI::LineWidget::LineWidget() : 
    Widget(SUI::ObjectType::LineWidget)
{
}

SUI::LineWidget::~LineWidget()
{
}
