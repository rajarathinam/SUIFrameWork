/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIWidget.cpp
| Author       :
| Description  : Class implementation file for Widget.
|
| ! \file        SUIWidget.cpp
| ! \brief       Class implementation file for Widget.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIWidget.h"

#include "SUIObjectPropertyTypeEnum.h"
#include "SUIBaseWidget.h"
#include "SUIObjectFactory.h"

#include <QStyle>

SUI::Widget::Widget(const ObjectType::Type &type) : 
    Object(type)
{
}

SUI::Widget::~Widget()
{
}

void SUI::Widget::setEnabled(bool enabled) { 
   ObjectFactory::getInstance()->toBaseWidget(this)->setEnabled(enabled); 
}

bool SUI::Widget::isEnabled() const { 
   return ObjectFactory::getInstance()->toBaseWidget(this)->isEnabled(); 
}

void SUI::Widget::setContextMenuItems(const std::list<std::string> &items) { 
   ObjectFactory::getInstance()->toBaseWidget(this)->setContextMenuItems(items); 
}

std::list<std::string> SUI::Widget::getContextMenuItems() const { 
   return ObjectFactory::getInstance()->toBaseWidget(this)->getContextMenuItems(); 
}

void SUI::Widget::setFocus() { 
   ObjectFactory::getInstance()->toBaseWidget(this)->getWidget()->setFocus(); 
}

void SUI::Widget::clearFocus() { 
   ObjectFactory::getInstance()->toBaseWidget(this)->getWidget()->clearFocus(); 
}

bool SUI::Widget::hasFocus() const { 
    return ObjectFactory::getInstance()->toBaseWidget(this)->getWidget()->hasFocus(); 
}

void SUI::Widget::setToolTip(const std::string &toolTip) {
   dynamic_cast<SUI::BaseWidget*>(SUI::ObjectFactory::getInstance()->toBaseObject(const_cast<Widget*>(this)))->setToolTip(toolTip);
}


void SUI::Widget::setStyleSheetClass(const std::string &styleSheetClass) {
    BaseWidget *baseWidget = dynamic_cast<BaseWidget*>(SUI::ObjectFactory::getInstance()->toBaseObject(this));
    baseWidget->getWidget()->setProperty("StyleClass", QString::fromStdString(styleSheetClass));
    baseWidget->getWidget()->style()->polish( baseWidget->getWidget());

    if (baseWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::StyleSheetClass) != QString::fromStdString(styleSheetClass))
        baseWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::StyleSheetClass,QString::fromStdString(styleSheetClass));
}


std::string SUI::Widget::getStyleSheetClass() const {
    BaseWidget *baseWidget = dynamic_cast<BaseWidget*>(SUI::ObjectFactory::getInstance()->toBaseObject(const_cast<SUI::Widget*>(this)));
    return baseWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::StyleSheetClass).toStdString();
}
