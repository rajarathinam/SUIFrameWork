/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUILEDWidget.cpp
| Author       :
| Description  : Class implementation file for LEDWidget.
|
| ! \file        SUILEDWidget.cpp
| ! \brief       Class implementation file for LEDWidget.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUILEDWidget.h"

#include "SUIObjectFactory.h"

SUI::LEDWidget::LEDWidget() : 
    Widget(SUI::ObjectType::LEDWidget)
{
}

SUI::LEDWidget::~LEDWidget()
{
}
