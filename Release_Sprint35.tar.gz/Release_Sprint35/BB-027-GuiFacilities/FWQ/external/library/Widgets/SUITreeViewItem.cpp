/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUITreeViewItem.cpp
| Author       :
| Description  : Class implementation file for TreeViewItem.
|
| ! \file        SUITreeViewItem.cpp
| ! \brief       Class implementation file for TreeViewItem.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUITreeViewItem.h"

#include "SUIObjectFactory.h"

SUI::TreeViewItem::TreeViewItem() : 
    Widget(SUI::ObjectType::TreeViewItem)
{
}

SUI::TreeViewItem::~TreeViewItem()
{
}
