/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUISplitter.cpp
| Author       :
| Description  : Class implementation file for Splitter.
|
| ! \file        SUISplitter.cpp
| ! \brief       Class implementation file for Splitter.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUISplitter.h"

#include "SUIObjectFactory.h"

SUI::Splitter::Splitter() : 
    Widget(SUI::ObjectType::Splitter)
{
}

SUI::Splitter::~Splitter()
{
}
