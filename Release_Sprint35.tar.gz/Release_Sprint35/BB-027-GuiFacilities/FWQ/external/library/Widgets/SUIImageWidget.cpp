/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIImageWidget.cpp
| Author       :
| Description  : Class implementation file for ImageWidget.
|
| ! \file        SUIImageWidget.cpp
| ! \brief       Class implementation file for ImageWidget.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIImageWidget.h"

#include "SUIObjectFactory.h"

SUI::ImageWidget::ImageWidget() :
    Widget(SUI::ObjectType::ImageWidget)
{
}

SUI::ImageWidget::~ImageWidget()
{
}
