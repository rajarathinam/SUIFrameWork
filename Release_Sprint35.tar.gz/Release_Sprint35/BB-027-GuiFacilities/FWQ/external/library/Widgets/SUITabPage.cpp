/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUITabPage.cpp
| Author       :
| Description  : Class implementation file for TabPage.
|
| ! \file        SUITabPage.cpp
| ! \brief       Class implementation file for TabPage.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUITabPage.h"

#include "SUIObjectFactory.h"

SUI::TabPage::TabPage() : 
    Widget(SUI::ObjectType::TabPage) 
{       
}

SUI::TabPage::~TabPage()
{       
}
