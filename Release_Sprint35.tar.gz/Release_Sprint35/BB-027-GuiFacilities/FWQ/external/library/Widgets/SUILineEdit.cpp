/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUILineEdit.cpp
| Author       :
| Description  : Class implementation file for LineEdit.
|
| ! \file        SUILineEdit.cpp
| ! \brief       Class implementation file for LineEdit.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUILineEdit.h"

#include "SUIObjectFactory.h"

SUI::LineEdit::LineEdit() : 
    Widget(SUI::ObjectType::LineEdit)
{
}

SUI::LineEdit::~LineEdit()
{
}
