/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUITabWidget.cpp
| Author       :
| Description  : Class implementation file for TabWidget.
|
| ! \file        SUITabWidget.cpp
| ! \brief       Class implementation file for TabWidget.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUITabWidget.h"

#include "SUIObjectFactory.h"

SUI::TabWidget::TabWidget() : 
    Widget(SUI::ObjectType::TabWidget)
{
}

SUI::TabWidget::~TabWidget()
{
}
