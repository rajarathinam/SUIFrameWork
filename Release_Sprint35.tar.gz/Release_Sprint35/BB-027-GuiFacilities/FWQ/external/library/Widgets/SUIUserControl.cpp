/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIUserControl.cpp
| Author       :
| Description  : Class implementation file for UserControl.
|
| ! \file        SUIUserControl.cpp
| ! \brief       Class implementation file for UserControl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIUserControl.h"

#include "SUIObjectFactory.h"

SUI::UserControl::UserControl() : 
    Widget(SUI::ObjectType::UserControl)
{
}

SUI::UserControl::~UserControl()
{
}
