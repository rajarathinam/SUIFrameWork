/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUISpinBox.cpp
| Author       :
| Description  : Class implementation file for SpinBox.
|
| ! \file        SUISpinBox.cpp
| ! \brief       Class implementation file for SpinBox.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUISpinBox.h"

#include "SUIObjectFactory.h"

SUI::SpinBox::SpinBox() : 
    Widget(SUI::ObjectType::SpinBox)
{
}

SUI::SpinBox::~SpinBox()
{
}
