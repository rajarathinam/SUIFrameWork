/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIDoubleSpinBox.cpp
| Author       :
| Description  : Class implementation file for DoubleSpinBox.
|
| ! \file        SUIDoubleSpinBox.cpp
| ! \brief       Class implementation file for DoubleSpinBox.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIDoubleSpinBox.h"

#include "SUIObjectFactory.h"

SUI::DoubleSpinBox::DoubleSpinBox() : 
    Widget(SUI::ObjectType::fromString(SUI::ObjectFactory::getClassName<DoubleSpinBox>()))
{
}

SUI::DoubleSpinBox::DoubleSpinBox(const SUI::ObjectType::Type &type) : 
    Widget(type)
{
}

SUI::DoubleSpinBox::~DoubleSpinBox()
{
}
