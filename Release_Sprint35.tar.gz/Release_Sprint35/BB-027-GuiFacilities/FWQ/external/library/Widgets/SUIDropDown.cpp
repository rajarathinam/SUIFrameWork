/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIDropDown.cpp
| Author       :
| Description  : Class implementation file for DropDown.
|
| ! \file        SUIDropDown.cpp
| ! \brief       Class implementation file for DropDown.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIDropDown.h"

#include "SUIObjectFactory.h"

SUI::DropDown::DropDown() : 
    Widget(SUI::ObjectType::DropDown) 
{       
}

SUI::DropDown::~DropDown()
{
}
