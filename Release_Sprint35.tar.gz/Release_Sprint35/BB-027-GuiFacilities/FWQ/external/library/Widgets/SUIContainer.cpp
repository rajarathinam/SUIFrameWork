/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIContainer.cpp
| Author       :
| Description  : Class implementation file for Container.
|
| ! \file        SUIContainer.cpp
| ! \brief       Class implementation file for Container.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIContainer.h"

#include "SUIObjectFactory.h"

SUI::Container::Container() : 
    Widget(SUI::ObjectType::fromString(SUI::ObjectFactory::getClassName<Container>()))
{
}

SUI::Container::~Container()
{
}
