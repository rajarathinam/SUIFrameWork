/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIBusyIndicator.cpp
| Author       :
| Description  : Class implementation file for BusyIndicator.
|
| ! \file        SUIBusyIndicator.cpp
| ! \brief       Class implementation file for BusyIndicator.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIBusyIndicator.h"

#include "SUIObjectFactory.h"

SUI::BusyIndicator::BusyIndicator() : 
    Widget(SUI::ObjectType::fromString(SUI::ObjectFactory::getClassName<BusyIndicator>()))
{
}

SUI::BusyIndicator::~BusyIndicator()
{
}
