/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIButtonBar.cpp
| Author       :
| Description  : Class implementation file for ButtonBar.
|
| ! \file        SUIButtonBar.cpp
| ! \brief       Class implementation file for ButtonBar.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIButtonBar.h"

#include "SUIObjectFactory.h"

SUI::ButtonBar::ButtonBar() : 
    Widget(SUI::ObjectType::fromString(SUI::ObjectFactory::getClassName<ButtonBar>()))
{
}

SUI::ButtonBar::~ButtonBar()
{
}
