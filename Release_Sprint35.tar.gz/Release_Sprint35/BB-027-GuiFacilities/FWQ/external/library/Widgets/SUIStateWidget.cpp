/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIStateWidget.cpp
| Author       :
| Description  : Class implementation file for StateWidget.
|
| ! \file        SUIStateWidget.cpp
| ! \brief       Class implementation file for StateWidget.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIStateWidget.h"

#include "SUIObjectFactory.h"

SUI::StateWidget::StateWidget() : 
    Widget(SUI::ObjectType::StateWidget)
{
}

SUI::StateWidget::StateWidget(const SUI::ObjectType::Type &type) : 
    Widget(type)
{
}

SUI::StateWidget::~StateWidget()
{
}
