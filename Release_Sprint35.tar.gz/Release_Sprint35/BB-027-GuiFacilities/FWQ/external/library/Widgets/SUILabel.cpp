/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUILabel.cpp
| Author       :
| Description  : Class implementation file for Label.
|
| ! \file        SUILabel.cpp
| ! \brief       Class implementation file for Label.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUILabel.h"

#include "SUIObjectFactory.h"

SUI::Label::Label() : 
    Widget(SUI::ObjectType::Label) 
{       
}

SUI::Label::~Label()
{
}
