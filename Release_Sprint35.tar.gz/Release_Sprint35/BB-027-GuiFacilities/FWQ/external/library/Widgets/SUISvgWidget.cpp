/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUISvgWidget.cpp
| Author       :
| Description  : Class implementation file for SvgWidget.
|
| ! \file        SUISvgWidget.cpp
| ! \brief       Class implementation file for SvgWidget.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUISvgWidget.h"

#include "SUIObjectFactory.h"

SUI::SvgWidget::SvgWidget() : 
    Widget(SUI::ObjectType::SvgWidget)
{
}

SUI::SvgWidget::~SvgWidget()
{
}
