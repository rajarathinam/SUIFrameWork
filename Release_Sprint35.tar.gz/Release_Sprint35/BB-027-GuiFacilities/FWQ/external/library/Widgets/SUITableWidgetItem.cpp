/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUITableWidgetItem.cpp
| Author       :
| Description  : Class implementation file for TableWidgetItem.
|
| ! \file        SUITableWidgetItem.cpp
| ! \brief       Class implementation file for TableWidgetItem.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUITableWidgetItem.h"

#include "SUIObjectFactory.h"

SUI::TableWidgetItem::TableWidgetItem() : 
    Widget(SUI::ObjectType::TableWidgetItem)
{
}

SUI::TableWidgetItem::~TableWidgetItem()
{
}
