/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUICheckGroupBox.cpp
| Author       :
| Description  : Class implementation file for CheckGroupBox.
|
| ! \file        SUICheckGroupBox.cpp
| ! \brief       Class implementation file for CheckGroupBox.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUICheckGroupBox.h"

#include "SUIObjectFactory.h"

SUI::CheckGroupBox::CheckGroupBox() : 
    Widget(SUI::ObjectType::fromString(SUI::ObjectFactory::getClassName<CheckGroupBox>()))
{
}

SUI::CheckGroupBox::CheckGroupBox(const SUI::ObjectType::Type &type) :
    Widget(type)
{
}

SUI::CheckGroupBox::~CheckGroupBox()
{
}
