/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIQuestionMark.cpp
| Author       :
| Description  : Class implementation file for QuestionMark.
|
| ! \file        SUIQuestionMark.cpp
| ! \brief       Class implementation file for QuestionMark.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIQuestionMark.h"

#include "SUIObjectFactory.h"

SUI::QuestionMark::QuestionMark() : 
    Widget(SUI::ObjectType::QuestionMark)
{
}

SUI::QuestionMark::~QuestionMark()
{
}
