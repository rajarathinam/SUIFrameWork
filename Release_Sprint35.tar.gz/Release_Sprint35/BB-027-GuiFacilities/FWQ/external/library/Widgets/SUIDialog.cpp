/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIDialog.cpp
| Author       :
| Description  : Class implementation file for Dialog.
|
| ! \file        SUIDialog.cpp
| ! \brief       Class implementation file for Dialog.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIDialog.h"

#include "SUIObjectFactory.h"

SUI::Dialog::Dialog() : 
    Widget(SUI::ObjectType::fromString(SUI::ObjectFactory::getClassName<Dialog>()))
{
}
