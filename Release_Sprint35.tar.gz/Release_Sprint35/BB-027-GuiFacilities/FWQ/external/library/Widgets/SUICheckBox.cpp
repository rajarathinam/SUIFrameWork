/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUICheckBox.cpp
| Author       :
| Description  : Class implementation file for CheckBox.
|
| ! \file        SUICheckBox.cpp
| ! \brief       Class implementation file for CheckBox.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUICheckBox.h"

#include "SUIObjectFactory.h"

SUI::CheckBox::CheckBox() : 
    Widget(SUI::ObjectType::fromString(SUI::ObjectFactory::getClassName<CheckBox>()))
{
}

SUI::CheckBox::~CheckBox()
{
}
