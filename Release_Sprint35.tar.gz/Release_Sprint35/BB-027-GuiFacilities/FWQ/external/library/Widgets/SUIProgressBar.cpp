/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIProgressBar.cpp
| Author       :
| Description  : Class implementation file for ProgressBar.
|
| ! \file        SUIProgressBar.cpp
| ! \brief       Class implementation file for ProgressBar.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIProgressBar.h"

#include "SUIObjectFactory.h"

SUI::ProgressBar::ProgressBar() : 
    Widget(SUI::ObjectType::ProgressBar)
{
}

SUI::ProgressBar::~ProgressBar()
{
}
