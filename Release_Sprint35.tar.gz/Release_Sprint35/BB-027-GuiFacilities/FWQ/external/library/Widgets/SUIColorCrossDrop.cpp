/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIColorCrossDrop.cpp
| Author       :
| Description  : Class implementation file for ColorCrossDrop.
|
| ! \file        SUIColorCrossDrop.cpp
| ! \brief       Class implementation file for ColorCrossDrop.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIColorCrossDrop.h"

#include "SUIObjectFactory.h"

SUI::ColorCrossDrop::ColorCrossDrop() : 
    Widget(SUI::ObjectType::fromString(SUI::ObjectFactory::getClassName<ColorCrossDrop>()))
{
}

SUI::ColorCrossDrop::~ColorCrossDrop()
{
}
