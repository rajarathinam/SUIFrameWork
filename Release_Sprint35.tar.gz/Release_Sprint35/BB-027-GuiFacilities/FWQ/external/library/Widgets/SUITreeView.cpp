/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUITreeView.cpp
| Author       :
| Description  : Class implementation file for TreeView.
|
| ! \file        SUITreeView.cpp
| ! \brief       Class implementation file for TreeView.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUITreeView.h"

#include "SUIObjectFactory.h"

SUI::TreeView::TreeView() : 
    Widget(SUI::ObjectType::TreeView)
{
}

SUI::TreeView::~TreeView()
{
}
