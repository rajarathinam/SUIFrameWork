/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUICheckMark.cpp
| Author       :
| Description  : Class implementation file for CheckMark.
|
| ! \file        SUICheckMark.cpp
| ! \brief       Class implementation file for CheckMark.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUICheckMark.h"

#include "SUIObjectFactory.h"

SUI::CheckMark::CheckMark() : 
    Widget(SUI::ObjectType::fromString(SUI::ObjectFactory::getClassName<CheckMark>()))
{
}

SUI::CheckMark::~CheckMark()
{
}
