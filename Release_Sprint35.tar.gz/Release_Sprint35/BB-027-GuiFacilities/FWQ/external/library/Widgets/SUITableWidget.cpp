/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUITableWidget.cpp
| Author       :
| Description  : Class implementation file for TableWidget.
|
| ! \file        SUITableWidget.cpp
| ! \brief       Class implementation file for TableWidget.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUITableWidget.h"

#include "SUIObjectFactory.h"

SUI::TableWidget::TableWidget() : 
    Widget(SUI::ObjectType::TableWidget)
{
}

SUI::TableWidget::~TableWidget()
{
}
