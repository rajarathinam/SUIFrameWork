/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIListView.cpp
| Author       :
| Description  : Class implementation file for ListView.
|
| ! \file        SUIListView.cpp
| ! \brief       Class implementation file for ListView.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIListView.h"

#include "SUIObjectFactory.h"

SUI::ListView::ListView() : 
    Widget(SUI::ObjectType::ListView)
{
}

SUI::ListView::~ListView()
{
}
