/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIWidgetPage.cpp
| Author       :
| Description  : Class implementation file for WidgetPage.
|
| ! \file        SUIWidgetPage.cpp
| ! \brief       Class implementation file for WidgetPage.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIWidgetPage.h"

#include "SUIObjectFactory.h"

SUI::WidgetPage::WidgetPage() : 
    Widget(SUI::ObjectType::WidgetPage)
{
}

SUI::WidgetPage::~WidgetPage()
{
}
