/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIControlWidget.cpp
| Author       :
| Description  : Class implementation file for ControlWidget.
|
| ! \file        SUIControlWidget.cpp
| ! \brief       Class implementation file for ControlWidget.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIControlWidget.h"

#include "SUIObjectFactory.h"

SUI::ControlWidget::ControlWidget() : 
    StateWidget(SUI::ObjectType::fromString(SUI::ObjectFactory::getClassName<ControlWidget>()))
{
}

SUI::ControlWidget::~ControlWidget()
{
}
