/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIScienceSpinBox.cpp
| Author       :
| Description  : Class implementation file for ScienceSpinBox.
|
| ! \file        SUIScienceSpinBox.cpp
| ! \brief       Class implementation file for ScienceSpinBox.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIScienceSpinBox.h"

#include "SUIObjectFactory.h"

SUI::ScienceSpinBox::ScienceSpinBox() : 
    DoubleSpinBox(SUI::ObjectType::ScienceSpinBox)
{
}

SUI::ScienceSpinBox::~ScienceSpinBox()
{
}
