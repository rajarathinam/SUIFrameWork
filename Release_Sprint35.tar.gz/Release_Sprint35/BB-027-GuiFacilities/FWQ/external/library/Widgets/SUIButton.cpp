/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIButton.cpp
| Author       :
| Description  : Class implementation file for Button.
|
| ! \file        SUIButton.cpp
| ! \brief       Class implementation file for Button.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIButton.h"

#include "SUIObjectFactory.h"

SUI::Button::Button() : 
    Widget(SUI::ObjectType::fromString(SUI::ObjectFactory::getClassName<Button>()))
{
}

SUI::Button::~Button()
{
}
