/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUITextArea.cpp
| Author       :
| Description  : Class implementation file for TextArea.
|
| ! \file        SUITextArea.cpp
| ! \brief       Class implementation file for TextArea.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUITextArea.h"

#include "SUIObjectFactory.h"

SUI::TextArea::TextArea() : 
    Widget(SUI::ObjectType::TextArea)
{
}

SUI::TextArea::~TextArea()
{
}
