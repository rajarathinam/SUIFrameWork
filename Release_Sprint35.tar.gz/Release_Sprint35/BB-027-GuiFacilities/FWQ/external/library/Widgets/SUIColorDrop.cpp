/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIColorDrop.cpp
| Author       :
| Description  : Class implementation file for ColorDrop.
|
| ! \file        SUIColorDrop.cpp
| ! \brief       Class implementation file for ColorDrop.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIColorDrop.h"

#include "SUIObjectFactory.h"

SUI::ColorDrop::ColorDrop() : 
    Widget(SUI::ObjectType::fromString(SUI::ObjectFactory::getClassName<ColorDrop>()))
{
}

SUI::ColorDrop::~ColorDrop()
{
}
