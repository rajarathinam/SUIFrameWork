/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIPlotWidget.cpp
| Author       :
| Description  : Class implementation file for PlotWidget.
|
| ! \file        SUIPlotWidget.cpp
| ! \brief       Class implementation file for PlotWidget.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIPlotWidget.h"

#include "SUIObjectFactory.h"

SUI::PlotWidget::PlotWidget() : 
    Widget(SUI::ObjectType::PlotWidget)
{
}

SUI::PlotWidget::~PlotWidget()
{
}
