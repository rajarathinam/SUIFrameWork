/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIGraphicsTextItem.cpp
| Author       :
| Description  : Class implementation file for GraphicsTextItem.
|
| ! \file        SUIGraphicsTextItem.cpp
| ! \brief       Class implementation file for GraphicsTextItem.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIGraphicsTextItem.h"

#include <QString>
#include <QColor>
#include <QBrush>
#include <QPen>
#include <QFont>
#include <QGraphicsSimpleTextItem>

#include "SUIObjectFactory.h"

SUI::GraphicsTextItem::GraphicsTextItem(SUI::GraphicsItem *parent) : 
    GraphicsItem(
          SUI::ObjectType::GraphicsTextItem,
          new QGraphicsSimpleTextItem(parent ? static_cast<QGraphicsItem*>(ObjectFactory::getImplementation(parent)) : NULL),
          parent),
    penColor(SUI::ColorEnum::Black)
{     
    QGraphicsSimpleTextItem *item = static_cast<QGraphicsSimpleTextItem*>(implementation);
    item->setZValue(1);
    item->setPen(QPen(QBrush(Qt::black),1));
    setPenColor(ColorEnum::Black);
    setBrushColor(ColorEnum::Black);
}


SUI::GraphicsTextItem::~GraphicsTextItem()
{
    delete static_cast<QGraphicsSimpleTextItem*>(implementation);
}

void SUI::GraphicsTextItem::setText(const std::string &value) {
    if (getText() == value) return;
    static_cast<QGraphicsSimpleTextItem*>(implementation)->setText(QString::fromStdString(value));
}

std::string SUI::GraphicsTextItem::getText() const {
    return static_cast<QGraphicsSimpleTextItem*>(implementation)->text().toStdString();
}

void SUI::GraphicsTextItem::clearText() {
    setText("");
}

void SUI::GraphicsTextItem::setPenWidth(int width) {
    QGraphicsSimpleTextItem *item = static_cast<QGraphicsSimpleTextItem*>(implementation);
    QPen pen = item->pen();
    pen.setWidth(width < 1 ? 1 : (width < 6 ? width : 5));
    item->setPen(pen);
}

int SUI::GraphicsTextItem::getPenWidth() const {
    return static_cast<QGraphicsSimpleTextItem*>(implementation)->pen().width();
}

void SUI::GraphicsTextItem::setPenColor(const SUI::ColorEnum::Color color) {
    if (!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color)) return;
    penColor = color;
    QGraphicsSimpleTextItem *item = static_cast<QGraphicsSimpleTextItem*>(implementation);
    QPen pen = item->pen();
    pen.setColor(QColor(QString::fromStdString(ColorEnum::toString(color))));
    item->setPen(pen);
}

SUI::ColorEnum::Color SUI::GraphicsTextItem::getBrushColor() const {
    return getPenColor();
}

void SUI::GraphicsTextItem::setBrushColor(const SUI::ColorEnum::Color color) {
    if (!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color) && color != ColorEnum::Transparent) return;
    if (color != ColorEnum::Transparent) {
        setPenColor(color);
    }
    static_cast<QGraphicsSimpleTextItem*>(implementation)->setBrush(color == ColorEnum::Transparent ? Qt::NoBrush : QBrush(QColor(QString::fromStdString(ColorEnum::toString(color)))));
}

void SUI::GraphicsTextItem::setBold(bool bold) {
    QGraphicsSimpleTextItem *item = static_cast<QGraphicsSimpleTextItem*>(implementation);
    QFont font = item->font();
    font.setBold(bold);
    item->setFont(font);
}

bool SUI::GraphicsTextItem::isBold() const {
    return static_cast<QGraphicsSimpleTextItem*>(implementation)->font().bold();
}

void SUI::GraphicsTextItem::setFontSize(int size) {
    QGraphicsSimpleTextItem *item = static_cast<QGraphicsSimpleTextItem*>(implementation);
    QFont font = item->font();
    font.setPointSize(size > 0 ? size : 1);
    item->setFont(font);
}

SUI::ColorEnum::Color SUI::GraphicsTextItem::getPenColor() const {
    return penColor;
}
