/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIGraphicsSvgItem.cpp
| Author       :
| Description  : Class implementation file for GraphicsSvgItem.
|
| ! \file        SUIGraphicsSvgItem.cpp
| ! \brief       Class implementation file for GraphicsSvgItem.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIGraphicsSvgItem.h"

#include <boost/bind.hpp>

#include "SUIObjectFactory.h"

#include "CustomGraphicsSvgItem.h"

SUI::GraphicsSvgItem::GraphicsSvgItem(SUI::GraphicsItem *parent) : 
    GraphicsItem(
          SUI::ObjectType::GraphicsSvgItem,
          new CustomGraphicsSvgItem(parent ? static_cast<QGraphicsItem*>(ObjectFactory::getImplementation(parent)) : NULL),
          parent) 
{
}

SUI::GraphicsSvgItem::~GraphicsSvgItem() {
    delete static_cast<CustomGraphicsSvgItem*>(implementation);
}

void SUI::GraphicsSvgItem::setImage(const std::string &image) {
    static_cast<CustomGraphicsSvgItem*>(implementation)->setImage(image);
}

void SUI::GraphicsSvgItem::setImage(unsigned char *data, int width, int height, ImageEnum::Format format) {
   Q_UNUSED(data); Q_UNUSED(width); Q_UNUSED(height); Q_UNUSED(format);
}

void SUI::GraphicsSvgItem::setElementId(const std::string &id){
    static_cast<CustomGraphicsSvgItem*>(implementation)->setElementId(id);
}

std::string SUI::GraphicsSvgItem::elementId(){
    return static_cast<CustomGraphicsSvgItem*>(implementation)->elementId();
}

void SUI::GraphicsSvgItem::scale(int width, int height) {
   static_cast<CustomGraphicsSvgItem*>(implementation)->scale(width,height);
}

std::list<std::string> SUI::GraphicsSvgItem::getElementIdList() {
    return static_cast<CustomGraphicsSvgItem*>(implementation)->getElementIdList();
}

void SUI::GraphicsSvgItem::setElementColor(const std::string id, const SUI::ColorEnum::Color color) {
   if (!SUI::ColorEnum::exists(SUI::ColorEnum::getColorEnumList(SUI::Object::getObjectType()),color)) return;
   static_cast<CustomGraphicsSvgItem*>(implementation)->setElementColor(id,color);
   static_cast<CustomGraphicsSvgItem*>(implementation)->update();
}

void SUI::GraphicsSvgItem::setElementBorderColor(const std::string id, const SUI::ColorEnum::Color borderColor) {
   if(!SUI::ColorEnum::exists(SUI::ColorEnum::getColorEnumList(SUI::Object::getObjectType()),borderColor)) return;
   static_cast<CustomGraphicsSvgItem*>(implementation)->setElementBorderColor(id,borderColor);
   static_cast<CustomGraphicsSvgItem*>(implementation)->update();
}

void SUI::GraphicsSvgItem::setElementText(const std::string id, const std::string text) {
    static_cast<CustomGraphicsSvgItem*>(implementation)->setElementText(id,text);
    static_cast<CustomGraphicsSvgItem*>(implementation)->update();
}

std::string SUI::GraphicsSvgItem::getElementText(const std::string idvalue) {
    return static_cast<CustomGraphicsSvgItem*>(implementation)->getElementText(idvalue);
}

void SUI::GraphicsSvgItem::elideText(int maxwidth) {
    static_cast<CustomGraphicsSvgItem*>(implementation)->elideText(maxwidth);
    static_cast<CustomGraphicsSvgItem*>(implementation)->update();
}

void SUI::GraphicsSvgItem::resetElideText() {
   static_cast<CustomGraphicsSvgItem*>(implementation)->resetElideText();
   static_cast<CustomGraphicsSvgItem*>(implementation)->update();
}

void SUI::GraphicsSvgItem::setElementBorderWidth(const std::string id, const int borderWidth) {
    static_cast<CustomGraphicsSvgItem*>(implementation)->setElementBorderWidth(id,borderWidth);
    static_cast<CustomGraphicsSvgItem*>(implementation)->update();
}

void SUI::GraphicsSvgItem::setElementTextColor(const std::string id, const SUI::ColorEnum::Color color) {
   if(!SUI::ColorEnum::exists(SUI::ColorEnum::getColorEnumList(SUI::Object::getObjectType()),color)) return;
   static_cast<CustomGraphicsSvgItem*>(implementation)->setElementTextColor(id,color);
   static_cast<CustomGraphicsSvgItem*>(implementation)->update();
}

void SUI::GraphicsSvgItem::setElementToolTip(const std::string id, const std::string tipText) {
   static_cast<CustomGraphicsSvgItem*>(implementation)->setElementToolTip(id,tipText);
   static_cast<CustomGraphicsSvgItem*>(implementation)->update();
}

void SUI::GraphicsSvgItem::setElementToDoublClickEvent(const std::string idvalue, SUI::GraphicsSvgItem::function_type func) {
    static_cast<CustomGraphicsSvgItem*>(implementation)->setElementDoubleClickEvent(idvalue, func);
}
