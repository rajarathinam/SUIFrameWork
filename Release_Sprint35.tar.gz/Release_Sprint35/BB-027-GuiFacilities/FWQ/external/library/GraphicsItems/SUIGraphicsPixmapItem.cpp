/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIGraphicsPixmapItem.cpp
| Author       :
| Description  : Class implementation file for GraphicsPixmapItem.
|
| ! \file        SUIGraphicsPixmapItem.cpp
| ! \brief       Class implementation file for GraphicsPixmapItem.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIGraphicsPixmapItem.h"

#include "SUIObjectFactory.h"

#include <QGraphicsPixmapItem>
#include <QImage>

SUI::GraphicsPixmapItem::GraphicsPixmapItem(SUI::GraphicsItem *parent) : 
    GraphicsItem(
          SUI::ObjectType::GraphicsPixmapItem,
          new QGraphicsPixmapItem(parent ? static_cast<QGraphicsItem*>(ObjectFactory::getImplementation(parent)) : NULL),
          parent),
          image(new QImage(":/image/IndicatorBlue.png")),
          scaledImage(new QPixmap(QPixmap::fromImage(*static_cast<QImage*>(image))))
{
}

SUI::GraphicsPixmapItem::~GraphicsPixmapItem()
{
    delete static_cast<QImage*>(image);
    delete static_cast<QPixmap*>(scaledImage);
}

void SUI::GraphicsPixmapItem::setImage(const std::string &fileName) {
    delete static_cast<QImage*>(image);
    delete static_cast<QPixmap*>(scaledImage);
    image = new QImage(QString::fromStdString(fileName));
    scaledImage = new QPixmap(QPixmap::fromImage(*static_cast<QImage*>(image)));
    static_cast<QGraphicsPixmapItem*>(implementation)->setPixmap(QPixmap::fromImage(*static_cast<QImage*>(image)));
}

void SUI::GraphicsPixmapItem::setImage(unsigned char *data, int width, int height, SUI::ImageEnum::Format format) {
    delete static_cast<QImage*>(image);
    delete static_cast<QPixmap*>(scaledImage);
    image = new QImage(data,width,height,static_cast<QImage::Format>(format));
    scaledImage = new QPixmap(QPixmap::fromImage(*static_cast<QImage*>(image)));
    static_cast<QGraphicsPixmapItem*>(implementation)->setPixmap(QPixmap::fromImage(*static_cast<QImage*>(image)));
}

void SUI::GraphicsPixmapItem::scale(int width, int height, const SUI::ImageEnum::AspectRatioMode &aspectRatioMode, const SUI::ImageEnum::TransformationMode &transformationMode) {
    static_cast<QGraphicsPixmapItem*>(implementation)->setPixmap(static_cast<QPixmap*>(scaledImage)->scaled(width,height, static_cast<Qt::AspectRatioMode>(aspectRatioMode),static_cast<Qt::TransformationMode>(transformationMode)));
}
