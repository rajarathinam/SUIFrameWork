/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIGraphicsRectItem.cpp
| Author       :
| Description  : Class implementation file for GraphicsRectItem.
|
| ! \file        SUIGraphicsRectItem.cpp
| ! \brief       Class implementation file for GraphicsRectItem.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIGraphicsRectItem.h"

#include <QSize>
#include <QPen>
#include <QGraphicsRectItem>

#include "SUIColorEnum.h"
#include "SUIObjectFactory.h"

SUI::GraphicsRectItem::GraphicsRectItem(SUI::GraphicsItem *parent) : 
    GraphicsItem(
          SUI::ObjectType::GraphicsRectItem,
          new QGraphicsRectItem(parent ? static_cast<QGraphicsItem*>(ObjectFactory::getImplementation(parent)) : NULL),
          parent),
    penColor(SUI::ColorEnum::Black)
{      
}

SUI::GraphicsRectItem::~GraphicsRectItem()
{
    delete static_cast<QGraphicsRectItem*>(implementation);
}

void SUI::GraphicsRectItem::setSize(double width, double height) {
    QGraphicsRectItem *item = static_cast<QGraphicsRectItem*>(implementation);
    QRectF r = item->rect();
    r.setSize(QSize(width,height));
    item->setRect(r);
}

double SUI::GraphicsRectItem::getWidth() const {
    return static_cast<QGraphicsRectItem*>(implementation)->rect().width();  
}

double SUI::GraphicsRectItem::getHeight() const {
   return static_cast<QGraphicsRectItem*>(implementation)->rect().height();  
}

void SUI::GraphicsRectItem::setPenWidth(int width) {
    QGraphicsRectItem *item = static_cast<QGraphicsRectItem*>(implementation);
    QPen pen = item->pen();
    pen.setWidth(width < 1 ? 1 : (width < 6 ? width : 5));
    item->setPen(pen);
}

int SUI::GraphicsRectItem::getPenWidth() const {
    return static_cast<QGraphicsRectItem*>(implementation)->pen().width();
}

SUI::ColorEnum::Color SUI::GraphicsRectItem::getPenColor() const {
    return penColor;
}

void SUI::GraphicsRectItem::setPenColor(const SUI::ColorEnum::Color color) {
    if (ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color)) {
       penColor = color;
       QGraphicsRectItem *item = static_cast<QGraphicsRectItem*>(implementation);
       QPen pen = item->pen();
       pen.setColor(QColor(QString::fromStdString(ColorEnum::toString(color))));
       item->setPen(pen);
    }
}

SUI::ColorEnum::Color SUI::GraphicsRectItem::getBrushColor() const {
    return getPenColor();
}

void SUI::GraphicsRectItem::setBrushColor(const SUI::ColorEnum::Color color) {
    if (ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color) || color == ColorEnum::Transparent) {
       if (color != ColorEnum::Transparent) {
          setPenColor(color);
       }
       static_cast<QGraphicsRectItem*>(implementation)->setBrush(color == ColorEnum::Transparent ? Qt::NoBrush : QBrush(QColor(QString::fromStdString(ColorEnum::toString(color)))));
    }
}
