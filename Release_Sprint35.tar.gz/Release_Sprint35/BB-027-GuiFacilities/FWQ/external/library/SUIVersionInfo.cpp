/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIVersionInfo.cpp
| Author       :
| Description  : Class implementation file for VersionInfo.
|
| ! \file        SUIVersionInfo.cpp
| ! \brief       Class implementation file for VersionInfo.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIVersionInfo.h"

#include <sstream>

SUI::VersionInfo::VersionInfo(int majorVersion, int minorVersion, int revision):
    mMajor(majorVersion),
    mMinor(minorVersion),
    mRevision(revision)
{
}

int SUI::VersionInfo::majorVersion() const {
    return mMajor;
}

int SUI::VersionInfo::minorVersion() const {
    return mMinor;
}

int SUI::VersionInfo::revision() const {
    return mRevision;
}


std::string SUI::VersionInfo::toString() const {
    std::stringstream ss;
    ss << mMajor << "." << mMinor << "." << mRevision;
    return ss.str();
}

std::string SUI::VersionInfo::toStringMajorMinor() const {
    std::stringstream ss;
    ss << mMajor << "." << mMinor;
    return ss.str();
}
