/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIDate.cpp
| Author       :
| Description  : Class implementation file for Date.
|
| ! \file        SUIDate.cpp
| ! \brief       Class implementation file for Date.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIDate.h"

#include "SUIDateImpl.h"

SUI::Date::~Date()
{
}

boost::shared_ptr<SUI::Date> SUI::Date::createDate() {
    return boost::shared_ptr<Date>(new DateImpl);
}
