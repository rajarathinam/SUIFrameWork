/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUITimer.cpp
| Author       :
| Description  : Class implementation file for Timer.
|
| ! \file        SUITimer.cpp
| ! \brief       Class implementation file for Timer.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUITimer.h"

#include "SUITimerImpl.h"

SUI::Timer::~Timer()
{
}

boost::shared_ptr<SUI::Timer> SUI::Timer::createTimer() {
    return boost::shared_ptr<Timer>(new TimerImpl);
}

