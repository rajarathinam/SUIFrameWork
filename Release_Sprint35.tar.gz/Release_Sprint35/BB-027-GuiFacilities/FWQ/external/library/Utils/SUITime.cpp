/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUITime.cpp
| Author       :
| Description  : Class implementation file for Time.
|
| ! \file        SUITime.cpp
| ! \brief       Class implementation file for Time.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUITime.h"

#include "SUITimeImpl.h"

SUI::Time::~Time()
{
}

boost::shared_ptr<SUI::Time> SUI::Time::createTime() {
    return boost::shared_ptr<Time>(new TimeImpl);
}
