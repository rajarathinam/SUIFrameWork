/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIXmlException.cpp
| Author       :
| Description  : Class implementation file for XmlException.
|
| ! \file        SUIXmlException.cpp
| ! \brief       Class implementation file for XmlException.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIXmlException.h"

SUI::XmlException::XmlException(const std::string &msg) :
    Exception(msg)
{
}
