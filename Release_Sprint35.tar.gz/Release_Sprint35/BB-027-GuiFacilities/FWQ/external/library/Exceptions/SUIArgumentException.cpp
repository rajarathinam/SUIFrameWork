/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIArgumentException.cpp
| Author       :
| Description  : Class implementation file for ArgumentException.
|
| ! \file        SUIArgumentException.cpp
| ! \brief       Class implementation file for ArgumentException.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIArgumentException.h"

SUI::ArgumentException::ArgumentException(const std::string &msg) :
    Exception(msg)
{
}


SUI::ArgumentException::~ArgumentException() throw()
{
}
