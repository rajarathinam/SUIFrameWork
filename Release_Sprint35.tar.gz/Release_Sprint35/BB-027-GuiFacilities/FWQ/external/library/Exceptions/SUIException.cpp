/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIException.cpp
| Author       :
| Description  : Class implementation file for Exception.
|
| ! \file        SUIException.cpp
| ! \brief       Class implementation file for Exception.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIException.h"

SUI::Exception::Exception(const std::string &msg) :
    mMessage(msg)
{
}

SUI::Exception::~Exception() throw()
{
}

std::string SUI::Exception::getExceptionMessage() const {
    return mMessage;
}

const char *SUI::Exception::what() const throw() {
    return mMessage.c_str();
}
