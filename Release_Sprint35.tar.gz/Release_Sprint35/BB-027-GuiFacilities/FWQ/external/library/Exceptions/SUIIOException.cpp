/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIIOException.cpp
| Author       :
| Description  : Class implementation file for IOException.
|
| ! \file        SUIException.cpp
| ! \brief       Class implementation file for IOException.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUIIOException.h"

SUI::IOException::IOException(const std::string &msg) :
    Exception(msg)
{
}
