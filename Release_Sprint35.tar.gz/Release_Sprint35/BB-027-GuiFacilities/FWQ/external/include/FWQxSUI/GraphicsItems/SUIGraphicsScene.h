/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIGraphicsScene.h
| Author       :
| Description  : Header file for class SUI::GraphicsScene.
|
| ! \file        SUIGraphicsScene.h
| ! \brief       Header file for class SUI::GraphicsScene.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUI_SUIGRAPHICSSCENE_H
#define SUI_SUIGRAPHICSSCENE_H

#include "SUISharedExport.h"

#include <boost/function.hpp>
#include <boost/shared_ptr.hpp>

#include <list>

#include "SUIAspectRatioEnum.h"
#include "SUIImageEnum.h"

namespace SUI {
/*!
 * \ingroup FWQxGraphicsItems
 *
 * \brief The GraphicsScene is a model class that contains GraphicsItems. The GraphicsScene is placed
 * into a GraphicsView but has its own coordinate system. Each GraphicsItem has a x and y coordinate
 * that correspond to their position in the GraphicsScene.
 */

class GraphicsItem;
class GraphicsSceneMouseEvent;
class SUI_SHARED_EXPORT GraphicsScene
{
public:
    explicit GraphicsScene();
    ~GraphicsScene();

    /*!
     * \brief addItem
     * Adds or moves the item and all its childen to this graphics scene.
     * The scene takes ownership of the item.
     */
    void addItem(GraphicsItem *item);

    /*!
     * \brief removeItem
     * Removes the item item and all its children from the graphics scene.
     * The ownership of item is passed on to the caller (i.e.,
     * GraphicsScene will no longer delete item when destroyed)
     */
    void removeItem(GraphicsItem *item);

    /*!
     * \brief clear
     * Removes all graphic items from the graphics scene
     */
    void clear();
    
    /*!
     * \brief getItems
     * Returns a list of the graphics items that are part of the graphics scene
     */
    std::list<GraphicsItem*> getItems() const;
    
    
    /*!
     * \brief setBackgroundImage
     * Sets the background image data of the graphics scene. It constructs an image
     * with the given width, height and format, that uses an existing memory buffer, data.
     * The width and height must be specified in pixels, data must be 32-bit aligned,
     * and each scanline of data in the image must also be 32-bit aligned. The buffer must
     * remain valid throughout the life of the QImage. The image does not delete the
     * buffer at destruction.
     */
    void setBackgroundImage(unsigned char *data , int width, int height, ImageEnum::Format format);
    
    /*!
     * \brief setBackgroundImage
     * Set the background image data of the graphics scene. The image data is
     * available in the (8-bit) 'value'
     */
    void setBackgroundImage(const std::string &value);

    /*!
     * \brief setBackgroundImageFile
     * Set the background image data of the graphics scene, by loading image
     * data from file
     */
    void setBackgroundImageFile(const std::string &fileName);

    /*!
     * \brief mouseMoved
     * Callback function that is triggered when the mouse moved over the graphics scene
     */
    boost::function<void(const boost::shared_ptr<SUI::GraphicsSceneMouseEvent>&)> mouseMoved;

    /*!
     * \brief mousePressed
     * Callback function that is triggered when a mouse button was pressed on the graphics scene
     */
    boost::function<void(const boost::shared_ptr<SUI::GraphicsSceneMouseEvent>&)> mousePressed;

    /*!
     * \brief mouseReleased
     * Callback function that is triggered when a mouse button was released on the graphics scene
     */
    boost::function<void(const boost::shared_ptr<SUI::GraphicsSceneMouseEvent>&)> mouseReleased;

    /*!
     * \brief mouseWheelMoved
     * Callback function that is triggered when the mouse wheel was used on the graphics scene
     */
    boost::function<void(const boost::shared_ptr<SUI::GraphicsSceneMouseEvent>&)> mouseWheelMoved;

private:
    // private administration to be able to give back a list efficiently
    std::list<GraphicsItem*> items;
    
    void onMousePressEvent(const boost::shared_ptr<SUI::GraphicsSceneMouseEvent> &event);
    void onMouseMoveEvent(const boost::shared_ptr<SUI::GraphicsSceneMouseEvent> &event);
    void onMouseReleaseEvent(const boost::shared_ptr<SUI::GraphicsSceneMouseEvent> &event);
    void onWheelEvent(const boost::shared_ptr<SUI::GraphicsSceneMouseEvent> &event);
    
    friend class GraphicsView;
    friend class GraphicsViewImpl; //TODO remove when widgets refactored
    
    void *implementation;
};

} // namespace SUI

#endif // SUI_SUIGRAPHICSSCENE_H
