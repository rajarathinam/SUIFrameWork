/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIImageWidget.h
| Author       :
| Description  : Header file for class SUI::ImageWidget.
|
| ! \file        SUIImageWidget.h
| ! \brief       Header file for class SUI::ImageWidget.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIIMAGEWIDGET_H
#define SUIIMAGEWIDGET_H

#include "SUIWidget.h"
#include "SUIIImage.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief The ImageWidget class
 */
class SUI_SHARED_EXPORT ImageWidget : public Widget, public IImage
{
public:
    virtual ~ImageWidget();
    
protected:
    ImageWidget();

};
}

#endif // SUIIMAGEWIDGET_H
