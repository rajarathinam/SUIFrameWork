/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUICheckMark.h
| Author       :
| Description  : Header file for class SUI::CheckMark.
|
| ! \file        SUICheckMark.h
| ! \brief       Header file for class SUI::CheckMark.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUICHECKMARK_H
#define SUICHECKMARK_H

#include "SUIDeprecated.h"

#include "SUIWidget.h"
#include "SUIIColorable.h"

namespace SUI {

/*!
 * \ingroup FWQxWidgets
 *
 * \brief The CheckMark class
 */
class SUI_DEPRECATED CheckMark : public Widget, public IColorable
{
public:
    virtual ~CheckMark();
    
protected:
    CheckMark();

};
}

#endif // SUICHECKMARK_H
