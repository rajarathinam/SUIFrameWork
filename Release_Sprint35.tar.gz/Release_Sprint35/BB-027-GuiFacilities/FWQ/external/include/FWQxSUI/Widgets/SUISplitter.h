/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUISplitter.h
| Author       :
| Description  : Header file for class SUI::Splitter.
|
| ! \file        SUISplitter.h
| ! \brief       Header file for class SUI::Splitter.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUISPLITTER_H
#define SUISPLITTER_H

#include "SUIWidget.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief The Splitter class
 */
class SUI_SHARED_EXPORT Splitter : public Widget
{
public:
    virtual ~Splitter();
    
protected:
    Splitter();

};
}

#endif // SUISPLITTER_H
