/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIMessageBox.h
| Author       :
| Description  : Header file for class SUI::MessageBox.
|
| ! \file        SUIMessageBox.h
| ! \brief       Header file for class SUI::MessageBox.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IRITCMESSAGEBOX_H
#define IRITCMESSAGEBOX_H


#include "SUIWidget.h"
#include "SUIIClickable.h"
#include "SUIIText.h"

#include "SUIMessageBoxIconEnum.h"
#include "SUIStandardButtonEnum.h"

#include <string>

namespace SUI {

/*!
 * \ingroup FWQxWidgets
 *
 * \brief The MessageBox class
 */
class MessageBox : public Widget, public IClickable, public IText
{
public:
    virtual ~MessageBox();

    /*!
     * \brief setButtonText
     * Sets the text for available buttons
     * \param text: list of button texts
     */
    virtual void setButtonText(const std::list<std::string> &text) = 0;

    /*!
     * \brief handleButtonRetour
     * Returns the text of the button that has been clicked
     * \return
     */
    virtual std::string handleButtonRetour() = 0;

    /*!
     * \brief setDefaultButton
     * Sets the default button
     * \param button: name of the button to set as default
     */
    virtual void setDefaultButton(const std::string &button) = 0;

    /*!
     * \brief setIcon
     * Sets the icon of the messagebox. For available icons see MessageBoxIconEnum::MessageBoxIconType.
     * \param icon: messagebox icon
     */
    virtual void setIcon(MessageBoxIconEnum::MessageBoxIconType icon) = 0;

    /*!
     * \brief setTitle
     * Sets the title of the messagebox
     * \param title: Title to be set
     */
    virtual void setTitle(const std::string &title) = 0;

    /*!
     * \brief getTitle
     * Returns the title of the messagebox
     * \return
     */
    virtual std::string getTitle() const = 0;

    /*!
     * \brief about
     * Shows an About message box
     * \param parent: Parent of the message box
     * \param title: Title of the message box
     * \param text: Text of the message box
     */
    static void about(Widget *parent, const std::string &title, const std::string &text);

    /*!
     * \brief critical
     * Shows a Critical message box
     * \param parent: Parent of the message box
     * \param title: Title of the message box
     * \param text: Text of the message box
     * \param buttons: Buttons to be displayed
     * \param defaultButton: The default button
     * \return
     */
    static StandardButtonEnum::Button critical(
            Widget *parent = NULL, const std::string &title = "Critical", const std::string &text = "",
            StandardButtonEnum::Buttons buttons = (int)StandardButtonEnum::Ok,
            StandardButtonEnum::Button defaultButton = StandardButtonEnum::NoButton);

    /*!
     * \brief information
     * Shows an Informative message box
     * \param parent: Parent of the message box
     * \param title: Title of the message box
     * \param text: Text of the message box
     * \param buttons: Buttons to be displayed
     * \param defaultButton: The default button
     * \return
     */
    static StandardButtonEnum::Button information(
            Widget *parent = NULL, const std::string &title = "Information", const std::string &text = "",
            StandardButtonEnum::Buttons buttons = (int)StandardButtonEnum::Ok,
            StandardButtonEnum::Button defaultButton = StandardButtonEnum::NoButton);

    /*!
     * \brief message
     * Shows a message box
     * \param parent: Parent of the message box
     * \param title: Title of the message box
     * \param text: Text of the message box
     * \param buttons: Buttons to be displayed
     * \param defaultButton: The default button
     * \return
     */
    static StandardButtonEnum::Button message(
            Widget *parent = NULL, const std::string &title = "Message", const std::string &text = "",
            StandardButtonEnum::Buttons buttons = (int)StandardButtonEnum::Ok,
            StandardButtonEnum::Button defaultButton = StandardButtonEnum::NoButton);

    /*!
     * \brief question
     * Shows a question message box
     * \param parent: Parent of the message box
     * \param title: Title of the message box
     * \param text: Text of the message box
     * \param buttons: Buttons to be displayed
     * \param defaultButton: The default button
     * \return
     */
    static StandardButtonEnum::Button question(
            Widget *parent = NULL, const std::string &title = "Question", const std::string &text = "",
            StandardButtonEnum::Buttons buttons = (int)StandardButtonEnum::Ok,
            StandardButtonEnum::Button defaultButton = StandardButtonEnum::NoButton);

    /*!
     * \brief warning
     * Shows a warning message box
     * \param parent: Parent of the message box
     * \param title: Title of the message box
     * \param text: Text of the message box
     * \param buttons: Buttons to be displayed
     * \param defaultButton: The default button
     * \return
     */
    static StandardButtonEnum::Button warning(
            Widget *parent = NULL, const std::string &title = "Warning", const std::string &text = "",
            StandardButtonEnum::Buttons buttons = (int)StandardButtonEnum::Ok,
            StandardButtonEnum::Button defaultButton = StandardButtonEnum::NoButton);

    /*!
     * \brief custom
     * Shows a custom message box
     * \param parent: Parent of the message box
     * \param title: Title of the message box
     * \param text: Text of the message box
     * \param icon: Icon to be shown on the messagebox
     * \param buttons: Buttons to be displayed
     * \param defaultButton: The default button
     * \return
     */
    static std::string custom(
            Widget *parent = NULL, const std::string &title = "Warning", const std::string &text = "",
            MessageBoxIconEnum::MessageBoxIconType icon = MessageBoxIconEnum::None,
            const std::string &buttons = "Ok",
            const std::string &defaultButton = "");

protected:
    MessageBox();
    
private:
    static void *getParent(Widget *parent);
};
}

#endif // IRITCMESSAGEBOX_H
