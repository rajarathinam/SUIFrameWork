/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIButton.h
| Author       :
| Description  : Header file for class SUI::Button.
|
| ! \file        SUIButton.h
| ! \brief       Header file for class SUI::Button.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIBUTTON_H
#define SUIBUTTON_H

#include "SUIIClickable.h"
#include "SUIIAlignable.h"
#include "SUIIText.h"
#include "SUIIImage.h"
#include "SUIWidget.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 *
 * \brief The Button class
 */
class SUI_SHARED_EXPORT Button : public Widget, public IClickable, public IText, public IImage, public IAlignable
{
public:
    virtual ~Button();
    
protected:
    Button();
};
}

#endif // SUIBUTTON_H
