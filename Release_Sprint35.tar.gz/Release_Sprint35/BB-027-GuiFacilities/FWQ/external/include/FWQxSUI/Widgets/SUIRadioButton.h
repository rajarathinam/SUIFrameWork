/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIRadioButton.h
| Author       :
| Description  : Header file for class SUI::RadioButton.
|
| ! \file        SUIRadioButton.h
| ! \brief       Header file for class SUI::RadioButton.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIRADIOBUTTON_H
#define SUIRADIOBUTTON_H

#include "SUIWidget.h"
#include "SUIICheckable.h"
#include "SUIIText.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief The RadioButton class
 */
class SUI_SHARED_EXPORT RadioButton : public Widget, public ICheckable, public IText
{
public:
    virtual ~RadioButton();
    
protected:
    RadioButton();

};
}

#endif // SUIRADIOBUTTON_H
