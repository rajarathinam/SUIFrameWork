/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUITreeView.h
| Author       :
| Description  : Header file for class SUI::TreeView.
|
| ! \file        SUITreeView.h
| ! \brief       Header file for class SUI::TreeView.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUITREEVIEW_H
#define SUITREEVIEW_H

#include "SUIWidget.h"
#include "SUIStringList.h"

#include "SUIIText.h"

#include "SUISortOrderEnum.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief The TreeView class
 */
class SUI_SHARED_EXPORT TreeView : public Widget, public IText, public StringList
{
public:
    virtual ~TreeView();

    /*!
     * \brief addNewTree
     * This adds a new treeItem to the treeView
     * \param text - The Text of the new Item.
     * \param newID - The new WidgetID of the TreeItem
     * \param parentID - The ParentID to add the new Item to
     */
    virtual void addTreeItem(const std::string &text, std::string &newID , const std::string &parentID) = 0 ;

    /*!
     * \brief disableHeader
     * Disables the header in the Treeview
     * \param disableHeader - Disabled or not
     */
    virtual void disableHeader(bool disableHeader) = 0;

    /*!
     * \brief isLeafNode
     * Returns true if the indicated item is a leaf node, false otherwise
     * \param itemID - The ID of the item.
     * \return True if the item is a leaf node. Otherwise false.
     */
    virtual bool isLeafNode(const std::string &itemID) = 0;

    /*!
     * \brief sort
     * Sorts the TreeView in the given order
     * \param order - The order to sort in (ascending or descending). See SortOrderEnum::SortOrder
     * for details
     */
    virtual void sort(SortOrderEnum::SortOrder order = SortOrderEnum::Unsorted) = 0;

    /*!
     * \brief setTitle
     * Sets the title of a widget.
     * \param title - The text to set. If title is an empty string, the title disappears
     */
    virtual void setTitle(const std::string &title) = 0;

    /*!
     * \brief getTitle
     * Returns the current title of the treeview widget
     * \return - the title text
     */
    virtual std::string getTitle() const = 0;
    
protected:
    TreeView();
};
}

#endif // SUITREEVIEW_H
