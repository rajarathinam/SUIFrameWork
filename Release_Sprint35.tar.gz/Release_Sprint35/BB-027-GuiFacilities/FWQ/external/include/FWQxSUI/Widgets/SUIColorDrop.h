/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIColorDrop.h
| Author       :
| Description  : Header file for class SUI::ColorDrop.
|
| ! \file        SUIColorDrop.h
| ! \brief       Header file for class SUI::ColorDrop.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUICOLORDROP_H
#define SUICOLORDROP_H

#include "SUIWidget.h"
#include "SUIIColorable.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 *
 * \brief The ColorDrop class
 */
class SUI_SHARED_EXPORT ColorDrop : public Widget, public IColorable
{
public:
    virtual ~ColorDrop();

    /*!
     * \brief currentIndexChanged
     * Callback function that is called whenever the index of this widget changed. Returns the new index
     */
    boost::function<void(int)> currentIndexChanged;

protected:
    ColorDrop();
};
}

#endif // SUICOLORDROP_H
