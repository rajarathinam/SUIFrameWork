/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIScienceSpinBox.h
| Author       :
| Description  : Header file for class SUI::ScienceSpinBox.
|
| ! \file        SUIScienceSpinBox.h
| ! \brief       Header file for class SUI::ScienceSpinBox.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUISCIENCESPINBOX_H
#define SUISCIENCESPINBOX_H

#include "SUIDoubleSpinBox.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief Specific Interface for the ScienceSpinBox Widget
 */
class SUI_SHARED_EXPORT ScienceSpinBox : public DoubleSpinBox
{
public:
    virtual ~ScienceSpinBox();

    /*!
     * \brief setPrecision
     * Sets the precision of the spin box in decimals, used for displaying and interpreting doubles.
     * Warning: The maximum value for decimals is DBL_MAX_10_EXP + DBL_DIG (ie. 323) because of the
     * limitations of the double type. Note: The maximum, minimum and value might change as a result
     * of changing this property.
     * \param val - Number of decimals
     */
    virtual void setPrecision(const int val) = 0;
    
protected:
    ScienceSpinBox();
};
}

#endif // SUISCIENCESPINBOX_H
