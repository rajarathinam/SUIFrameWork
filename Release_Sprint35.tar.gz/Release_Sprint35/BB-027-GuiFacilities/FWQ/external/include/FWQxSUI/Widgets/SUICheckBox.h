/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUICheckBox.h
| Author       :
| Description  : Header file for class SUI::CheckBox.
|
| ! \file        SUICheckBox.h
| ! \brief       Header file for class SUI::CheckBox.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUICHECKBOX_H
#define SUICHECKBOX_H

#include "SUIWidget.h"
#include "SUIICheckable.h"
#include "SUIIText.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 *
 * \brief The CheckBox class
 */
class SUI_SHARED_EXPORT CheckBox : public Widget, public ICheckable, public IText
{
public:
    virtual ~CheckBox();
    
protected:
    CheckBox();
};
}

#endif // SUICHECKBOX_H
