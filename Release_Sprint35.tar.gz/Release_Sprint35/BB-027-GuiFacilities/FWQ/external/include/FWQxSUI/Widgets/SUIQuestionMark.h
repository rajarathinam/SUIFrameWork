/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIQuestionMark.h
| Author       :
| Description  : Header file for class SUI::QuestionMark.
|
| ! \file        SUIQuestionMark.h
| ! \brief       Header file for class SUI::QuestionMark.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIQUESTIONMARK_H
#define SUIQUESTIONMARK_H

#include "SUIWidget.h"
#include "SUIIText.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief The QuestionMark class
 */
class SUI_SHARED_EXPORT QuestionMark : public Widget, public IText
{
public:
    virtual ~QuestionMark();
    
protected:
    QuestionMark();

};
}

#endif // SUIQUESTIONMARK_H
