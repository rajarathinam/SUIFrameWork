/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUILEDWidget.h
| Author       :
| Description  : Header file for class SUI::LEDWidget.
|
| ! \file        SUILEDWidget.h
| ! \brief       Header file for class SUI::LEDWidget.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUILEDWIDGET_H
#define SUILEDWIDGET_H

#include "SUIDeprecated.h"

#include "SUIIColorable.h"
#include "SUIWidget.h"

namespace SUI {

/*!
 * \ingroup FWQxWidgets
 *
 * \brief The LEDWidget class
 */
class SUI_DEPRECATED LEDWidget : public Widget, public IColorable
{
public:
    virtual ~LEDWidget();
    
protected:
    LEDWidget();

};
}

#endif // SUILEDWIDGET_H
