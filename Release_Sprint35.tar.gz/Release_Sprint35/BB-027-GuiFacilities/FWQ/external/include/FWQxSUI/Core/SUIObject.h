/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIObject.h
| Author       :
| Description  : Header file for class SUI::Object.
|
| ! \file        SUIObject.h
| ! \brief       Header file for class SUI::Object.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIOBJECT_H
#define SUIOBJECT_H

#include "SUISharedExport.h"

#include "SUIObjectType.h"
#include "SUIIViewable.h"

#include <string>

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief The Object class
 */
class SUI_SHARED_EXPORT Object : public IViewable
{

public:
    Object(const SUI::ObjectType::Type &type);
    
    virtual ~Object();

    /*!
     * \brief getId
     * Returns the id of the object.
     * \return std::string
     */
    virtual std::string getId() const;

    /*!
     * \brief getObjectType
     * Returns the an enum entry that represents the object type.
     * \return SUI::ObjectType::Type
     */
    SUI::ObjectType::Type getObjectType() const;

    /*!
     * \brief setEnabled
     * Sets the enabled/disabled state of the object
     * \param enabled
     */
    virtual void setEnabled(bool enabled) = 0;

    /*!
     * \brief isEnabled
     * Returns whether the object is disabled or not
     * \return
     */
    virtual bool isEnabled() const = 0;
    
    /*!
     * \brief setVisible
     * Sets the (in)visibility of an object
     * \param visible
     */
    virtual void setVisible(bool visible);

    /*!
     * \brief isVisible
     * Returns whether the object is visible or not
     * \return
     */
    virtual bool isVisible() const;

private:
    const SUI::ObjectType::Type type;
};
}

#endif // SUIOBJECT_H
