/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIIAnimatable.h
| Author       :
| Description  : Header file for class SUI::IAnimatable.
|
| ! \file        SUIIAnimatable.h
| ! \brief       Header file for class SUI::IAnimatable.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IANIMATABLE_H
#define IANIMATABLE_H

namespace SUI {

/*!
 * \ingroup FWQxCore
 *
 * \brief Generic Interface class for interaction with the animation property of a widget
 */
class IAnimatable
{
public:
    virtual ~IAnimatable() {}

    /*!
     * \brief startAnimation
     * starts the animation
     */
    virtual void startAnimation() = 0;

    /*!
     * \brief stopAnimation
     * stops the animation
     */
    virtual void stopAnimation() = 0;
};
}

#endif // IANIMATABLE_H
