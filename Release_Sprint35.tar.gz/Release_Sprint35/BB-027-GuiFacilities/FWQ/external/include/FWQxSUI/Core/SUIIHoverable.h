/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIIHoverable.h
| Author       :
| Description  : Header file for class SUI::IHoverable.
|
| ! \file        SUIIHoverable.h
| ! \brief       Header file for class SUI::IHoverable.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IHOVERABLE_H
#define IHOVERABLE_H

#include <boost/function.hpp>

namespace SUI {

/*!
 * \ingroup FWQxCore
 *
 * \brief Generic Interface class for the purpose of the chickable widgets
 */
class IHoverable
{
public:
    virtual ~IHoverable() {}

    /*!
     * \brief Callback function that is called when the widget was hovered.
     * \fn hoverEntering
     * \fn hoverLeaving
     */
    boost::function<void()> hoverEntered;
    boost::function<void()> hoverLeft;
};
}

#endif // IHOVERABLE_H
