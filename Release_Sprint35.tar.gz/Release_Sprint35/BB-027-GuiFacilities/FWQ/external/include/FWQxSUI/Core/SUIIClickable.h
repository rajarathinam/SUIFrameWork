/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIIClickable.h
| Author       :
| Description  : Header file for class SUI::IClickable.
|
| ! \file        SUIIClickable.h
| ! \brief       Header file for class SUI::IClickable.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef ICLICKABLE_H
#define ICLICKABLE_H

#include <boost/function.hpp>

namespace SUI {

/*!
 * \ingroup FWQxCore
 *
 * \brief Generic Interface class for the purpose of the chickable widgets
 */
class IClickable
{
public:
    virtual ~IClickable() {}

    /*!
     * \brief clicked
     * Callback function that is called when the widget was clicked.
     * \fn clicked
     */
    boost::function<void()> clicked;

};
}

#endif // ICLICKABLE_H
