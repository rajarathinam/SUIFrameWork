/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIXmlException.h
| Author       :
| Description  : Header file for class SUI::XmlException.
|
| ! \file        SUIXmlException.h
| ! \brief       Header file for class SUI::XmlException.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIXMLEXCEPTION_H
#define SUIXMLEXCEPTION_H

#include "SUIException.h"

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief The XmlException class
 */
class SUI_SHARED_EXPORT XmlException : public Exception
{
public:
    /*!
     * \brief XmlException
     * Creates/constructs an XML exception object with the given message
     * \param msg
     */
    XmlException(const std::string &msg);

private:
    XmlException();
};
}

#endif // SUIXMLEXCEPTION_H
