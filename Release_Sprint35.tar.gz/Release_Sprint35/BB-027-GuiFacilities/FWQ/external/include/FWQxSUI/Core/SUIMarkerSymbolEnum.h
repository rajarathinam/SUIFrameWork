/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIMarkerSymbolEnum.h
| Author       :
| Description  : Header file for class SUI::MarkerSymbolEnum.
|
| ! \file        SUIMarkerSymbolEnum.h
| ! \brief       Header file for class SUI::MarkerSymbolEnum.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIMARKERSYMBOLENUM_H
#define SUIMARKERSYMBOLENUM_H

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief This enum type is used to describe marker styles
 */
class MarkerSymbolEnum
{
public:
    /*!
     * \brief MarkerSymbol
     * This enumerated type is used to specify marker symbol
     */
    typedef enum
    {
        NoSymbol,
        Ellipse,
        Rect,
        Diamond,
        Triangle,
        Cross,
        Star
    } MarkerSymbol;
};
}
#endif // SUIMARKERSYMBOLENUM_H
