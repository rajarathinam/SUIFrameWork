/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIGridStyleEnum.h
| Author       :
| Description  : Header file for class SUI::GridStyleEnum.
|
| ! \file        SUIGridStyleEnum.h
| ! \brief       Header file for class SUI::GridStyleEnum.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/


#ifndef SUIGRIDSTYLEENUM
#define SUIGRIDSTYLEENUM

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief This enum type is used to describe grid styles.
 */
class GridStyleEnum
{
public:
    /*!
     * \brief GridStyle
     * The grid style enumeration
     */
    typedef enum
    {
        Off,
        Normal,
        Detail
    } GridStyle;
};
}
#endif // SUIGRIDSTYLEENUM_H
