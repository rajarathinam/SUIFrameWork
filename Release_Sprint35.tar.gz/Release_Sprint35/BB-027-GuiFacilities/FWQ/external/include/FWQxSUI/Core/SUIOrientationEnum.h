/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIOrientationEnum.h
| Author       :
| Description  : Header file for class SUI::OrientationEnum.
|
| ! \file        SUIOrientationEnum.h
| ! \brief       Header file for class SUI::OrientationEnum.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIORIENTATIONENUM_H
#define SUIORIENTATIONENUM_H

#include <map>
#include <list>
#include <string>

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief This enum type is used to describe orientations.
 */
class OrientationEnum
{
public:
    /*!
     * \brief Orientation
     * The orientation enumeration
     */
    typedef enum
    {
        Horizontal,
        Vertical
    } Orientation;

    /*!
     * \brief toString
     * Converts an orientation element to a string
     * \param orientation
     * \return
     */
    static std::string toString(OrientationEnum::Orientation orientation);

    /*!
     * \brief toString
     * Concatenates a list of orientation elements to one string. The elements are separated by
     * the given separator
     * \param list
     * \param separator
     * \return
     */
    static std::string toString(const std::list<OrientationEnum::Orientation> &list, const std::string &separator);

    /*!
     * \brief getOrientationStringList
     * Retrieves a string list of orientation elements
     * \return
     */
    static std::list<std::string> getOrientationStringList();

private:
    static std::map<OrientationEnum::Orientation,std::string> orientationMap;
    static std::list<std::string> orientationStringList;
};
}
#endif // SUIORIENTATIONENUM_H

