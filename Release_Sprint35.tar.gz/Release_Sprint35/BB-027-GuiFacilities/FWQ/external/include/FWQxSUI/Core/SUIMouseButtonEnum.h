/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIMessageBoxIconEnum.h
| Author       :
| Description  :
|
| ! \file        SUIMessageBoxIconEnum.h
| ! \brief
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIMOUSEBUTTONENUM_H
#define SUIMOUSEBUTTONENUM_H

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief MouseButton
 * This enum type is used to describe mouse button (clicks).
 */
enum MouseButton
{
    NoButton = 0x00000000,
    Left     = 0x00000001,
    Right    = 0x00000002,
    Middle   = 0x00000004
};

typedef int MouseButtons;


/*!
 * \ingroup FWQxCore
 *
 * \brief WheelDirection
 * The enumeration lists the available wheel events
 */
enum WheelDirection { Up, Down };

}

#endif // SUIMOUSEBUTTONENUM_H
