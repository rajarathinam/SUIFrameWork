/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIVersionInfo.h
| Author       :
| Description  : Header file for class SUI::VersionInfo.
|
| ! \file        SUIVersionInfo.h
| ! \brief       Header file for class SUI::VersionInfo.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIVERSIONINFO_H
#define SUIVERSIONINFO_H

#include <string>
#include <vector>
namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief The VersionInfo class
 */
class VersionInfo
{
public:
    /*!
     * \brief VersionInfo
     * Constructs a version info object
     * \param majorVersion
     * \param minorVersion
     * \param revision
     */
    VersionInfo(int majorVersion, int minorVersion, int revision);

    /*!
     * \brief majorVersion
     * Returns the major version of the version number
     * \return
     */
    int majorVersion() const;

    /*!
     * \brief minorVersion
     * Returns the minor version of the version number
     * \return
     */
    int minorVersion() const;

    /*!
     * \brief revision
     * Returns the revision of the version number
     * \return
     */
    int revision() const;

    /*!
     * \brief toString
     * Converts the version number to a string
     * \return
     */
    std::string toString() const;

    /*!
     * \brief toStringMajorMinor
     * Concatenates the major and minor version number to a string.
     * They are separated by a '.'
     * \return
     */
    std::string toStringMajorMinor() const;

private:
    const int mMajor;
    const int mMinor;
    const int mRevision;
};
}

#endif // SUIVERSIONINFO_H
