/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIIOException.h
| Author       :
| Description  : Header file for class SUI::IOException.
|
| ! \file        SUIIOException.h
| ! \brief       Header file for class SUI::IOException.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIIOEXCEPTION_H
#define SUIIOEXCEPTION_H

#include "SUIException.h"

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief The IOException class
 */
class SUI_SHARED_EXPORT IOException : public Exception
{

public:
    /*!
     * \brief IOException
     * constructs an IOException with a message
     * \param msg
     */
    IOException(const std::string &msg);

private:
    IOException();
};
}
#endif // SUIIOEXCEPTION_H
