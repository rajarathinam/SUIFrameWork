/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIICheckable.h
| Author       :
| Description  : Header file for class SUI::ICheckable.
|
| ! \file        SUIICheckable.h
| ! \brief       Header file for class SUI::ICheckable.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIICHECKED_H
#define SUIICHECKED_H

#include <boost/function.hpp>

namespace SUI {

/*!
 * \ingroup FWQxCore
 *
 * \brief Generic Interface class for the purpose of the checkable widgets
 */
class ICheckable
{
public:
    virtual ~ICheckable() {}

    /*!
     * \brief setChecked
     * Sets the "checked" value of a checkable widget like a checkbox or radio button.
     * \param checked The checked state.
     */
    virtual void setChecked(bool checked) = 0;

    /*!
     * \brief checkStateChanged
     * Callback function that is called when the checked state changed.
     */
    boost::function<void(bool)> checkStateChanged;

    /*!
     * \brief isChecked
     * Gets the "checked" value of a checkable widget like a checkbox or radio button.
     * \return The checked state
     */
    virtual bool isChecked() const = 0;
};
}

#endif // SUIICHECKED_H
