/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIExternalEventHandler.h
| Author       :
| Description  : Header file for class SUI::ExternalEventHandler.
|
| ! \file        SUIExternalEventHandler.h
| ! \brief       Header file for class SUI::ExternalEventHandler.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIEXTERNALEVENTHANDLER_H
#define SUIEXTERNALEVENTHANDLER_H

#include "SUIExternalEvent.h"
#include "SUISharedExport.h"

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief The ExternalEventHandler class
 */
class SUI_SHARED_EXPORT ExternalEventHandler
{
public:
    /*!
     * \brief raiseEvent
     *
     * \remark Notice that ownership is transferred, so don't delete the event
     *
     * \param event
     * \return
     */
    static bool raiseEvent(SUI::ExternalEvent *event);
};
}
#endif // SUIEXTERNALEVENTHANDLER_H
