/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIScaleTypeEnum.h
| Author       :
| Description  : Header file for class SUI::ScaleTypeEnum.
|
| ! \file        SUIScaleTypeEnum.h
| ! \brief       Header file for class SUI::ScaleTypeEnum.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUISCALETYPEENUM_H
#define SUISCALETYPEENUM_H

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief This enum type is used to describe scale type options.
 */
class ScaleTypeEnum
{
public:
    /*!
     * \brief ScaleType
     * The scale type enumeration
     */
    typedef enum
    {
        Linear,
        Logarithmic
    } ScaleType;
};
}
#endif // SUISCALETYPEENUM_H
