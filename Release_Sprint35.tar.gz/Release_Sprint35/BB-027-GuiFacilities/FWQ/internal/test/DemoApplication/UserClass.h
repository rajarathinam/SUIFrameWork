#ifndef USERCLASS_H
#define USERCLASS_H

namespace SUI {
class UserClass;

class Button;
class ProgressBar;
class Dialog;
class Label;

}

class UserClass
{

public:
    explicit UserClass();
    ~UserClass();

    SUI::Button *getStartButton();
    SUI::Button *getStopButton();
    SUI::Label *getTimeLabel();
    SUI::ProgressBar *getProgressBar();

    SUI::Dialog *getDialog();

private:
    SUI::UserClass *sui;
};
#endif // USERCLASS_H
