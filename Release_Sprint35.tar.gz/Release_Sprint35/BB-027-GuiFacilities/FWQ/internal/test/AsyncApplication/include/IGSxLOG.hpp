/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxLOG.hpp
| Author       : Thijs Jacobs
| Description  : IGS log macro
|
| ! \file        IGSxLOG.hpp
| ! \brief       IGS log macro
|
|-----------------------------------------------------------------------------|
|                                                                             |
|                Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IGSXLOG_HPP
#define IGSXLOG_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <fstream>
#include <iostream>
#include <sys/time.h>

/*----------------------------------------------------------------------------|
|                                     Type Defs                               |
|----------------------------------------------------------------------------*/
namespace IGS {

typedef enum
{
    LOG_LEVEL_FATAL = 0,
    LOG_LEVEL_ERROR,
    LOG_LEVEL_WARNING,
    LOG_LEVEL_INFO,
    LOG_LEVEL_DEBUG
} LogLevelEnum;

LogLevelEnum LogLevel = LOG_LEVEL_DEBUG;

static inline char* Timestamp(char *buff, int max)
{
    const int FORMAT_SIZE = 128;
    const int OFFSET_SIZE = 50;

    struct timeval tval;
    struct timezone tzone;
    struct tm tms;
    char format_buff[FORMAT_SIZE];
    char utcOffset[OFFSET_SIZE];
    gettimeofday(&tval, &tzone);

    time_t rawtime;
    time ( &rawtime );
    tms = *localtime(&rawtime);
    tval.tv_sec = static_cast<long>(rawtime);

    struct tm gmt = *gmtime(&rawtime);
    int offset = ((tms.tm_hour - gmt.tm_hour) * 60) + (tms.tm_min - gmt.tm_min);
    std::string offsetSign;
    offsetSign = "+";
    if (0 > offset)
    {
        offset *= -1;
        offsetSign = "-";
    }

    snprintf(utcOffset, OFFSET_SIZE, "%s%02d%02d", offsetSign.c_str(), offset/60, offset % 60);
    snprintf(format_buff, FORMAT_SIZE,"%s%06d %s","%Y-%b-%d %H:%M:%S.", static_cast<int>(tval.tv_usec), utcOffset);
    strftime(buff, max, format_buff, &tms);

    return buff;
}

} // namespace IGS


// log macro's
#ifndef IGS_DEBUG
#define IGS_DEBUG(msg) IGS_MESSAGE(IGS::LOG_LEVEL_DEBUG, msg)
#endif

#ifndef IGS_INFO
#define IGS_INFO(msg) IGS_MESSAGE(IGS::LOG_LEVEL_INFO, msg)
#endif

#ifndef IGS_WARNING
#define IGS_WARNING(msg) IGS_MESSAGE(IGS::LOG_LEVEL_WARNING, msg)
#endif

#ifndef IGS_ERROR
#define IGS_ERROR(msg) IGS_MESSAGE(IGS::LOG_LEVEL_ERROR, msg)
#endif

#ifndef IGS_FATAL
#define IGS_FATAL(msg) IGS_MESSAGE(IGS::LOG_LEVEL_FATAL, msg)
#endif

#ifndef IGS_MESSAGE
#define IGS_MESSAGE(level, msg) \
{ \
    if (IGS::LogLevel >= (level)) \
    { \
        static char buf[50]; \
        char *time = IGS::Timestamp(buf, sizeof(buf)); \
        std::cerr << time << " : " << __FILE__ << ":" << __LINE__ << ":" << (msg) << std::endl; \
    } \
} 
#endif

#endif // IGSXLOG_HPP

