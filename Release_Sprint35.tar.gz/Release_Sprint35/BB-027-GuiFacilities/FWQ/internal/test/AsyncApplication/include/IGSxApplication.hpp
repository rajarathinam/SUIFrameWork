/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxApplication.hpp
| Author       : Thijs Jacobs
| Description  : IGS application classes
|
| ! \file        IGSxApplication.hpp
| ! \brief       IGS application classes
|
|-----------------------------------------------------------------------------|
|                                                                             |
|                Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IGSXAPPLICATION_HPP
#define IGSXAPPLICATION_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/thread.hpp>


namespace IGS {

/*----------------------------------------------------------------------------|
|                                     Type Defs                               |
|----------------------------------------------------------------------------*/


/*----------------------------------------------------------------------------|
|                                     Class Definition                        |
|----------------------------------------------------------------------------*/
class Application
{
public:
    // instance
    Application();
    virtual ~Application();

private:
    // this function is run in a seperate thread to host the EHXA main loop
    void handleEvents();

private:
    boost::thread* m_thread;
};

} // namespace IGS

#endif // IGSXAPPLICATION_HPP

