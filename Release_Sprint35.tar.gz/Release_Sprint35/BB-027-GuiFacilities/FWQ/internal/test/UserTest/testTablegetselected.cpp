#include "testTablegetselected.h"

#include <SUITableWidget.h>
#include <SUIIText.h>
#include <SUIINumeric.h>
#include <SUIDialogImpl.h>

TestTableGetSelected::TestTableGetSelected(QString aTargetWidgetID, QString aSourceWidgetID,
                                           SUI::DialogImpl *apGui, TestTableGetSelected::Act aAction):
    mTargetWidgetID(aTargetWidgetID),
    mSourceWidgetID(aSourceWidgetID),
    mpGui(apGui),
    mAction(aAction)
{
}

void TestTableGetSelected::handleClicked() {
    SUI::TableWidget *tableWidget = mpGui->getObjectList()->getObject<SUI::TableWidget>(mSourceWidgetID.toStdString());
    if (tableWidget)
    {
        std::list<std::string> textList = tableWidget->getSelectedItems();
        std::string text;
        SUI::IText *textWidget = NULL;
        SUI::INumeric<int> *widgetNum = NULL;
        SUI::StringList *itemWidget = NULL;

        foreach (std::string item, textList)
            text += item + ";";

        switch (mAction)
        {
        case TestTableGetSelected::GET:
            textWidget = mpGui->getObjectList()->getObject<SUI::IText>(mTargetWidgetID.toStdString());
            if (textWidget)
                textWidget->setText(text);
            break;
        case TestTableGetSelected::SELECT:
            itemWidget = mpGui->getObjectList()->getObject<SUI::StringList>(mSourceWidgetID.toStdString());
            widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<int>>(mTargetWidgetID.toStdString());
            if (itemWidget && widgetNum)
                itemWidget->selectItem( widgetNum->getValue());
            break;
        }
    }
}

void TestTableGetSelected::handleSelectionChanged() {
    SUI::TableWidget *table = mpGui->getObjectList()->getObject<SUI::TableWidget>(mSourceWidgetID.toStdString());
    if (!table) return;
    QStringList itemList;
    foreach(std::string item, table->getSelectedItems())
        itemList.append(QString::fromStdString(item));

    SUI::IText *textWidget = mpGui->getObjectList()->getObject<SUI::IText>(mTargetWidgetID.toStdString());
    if (textWidget)
        textWidget->setText(itemList.join(":").toStdString());
}
