#include "testBrowserforSaving.h"

#include <SUIFileDialog.h>
#include <SUIDialogImpl.h>

testBrowserforSaving::testBrowserforSaving(QString aWidgetID, QString aRb1, SUI::FileDialog::AcceptMode aMode, SUI::DialogImpl *apGui):
    mWidgetID(aWidgetID),
    mpGui(apGui),
    mRb1(aRb1),
    fMode(aMode)
{
}

void testBrowserforSaving::handleCheckedChanged(bool checked)
{
    SUI::FileDialog *fbrdialog = mpGui->getObjectList()->getObject<SUI::FileDialog>(mWidgetID.toStdString());
    if (fbrdialog && checked)
    {
        fbrdialog->setAcceptMode(fMode);
    }
}

