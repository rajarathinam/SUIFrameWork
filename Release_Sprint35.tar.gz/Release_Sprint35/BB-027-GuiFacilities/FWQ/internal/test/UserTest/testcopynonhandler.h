#ifndef TESTCOPYNONHANDLER_H
#define TESTCOPYNONHANDLER_H

#include <SUIDialogImpl.h>

class testCopyNonHandler
{
private:
    QString mTargetWidgetid;
    QString mSourceWidgetid;
    SUI::DialogImpl  *mpGui;
public:
    void handleClicked();
    void handleValueChanged();
    testCopyNonHandler(QString aSourceWidgetID, QString aTargetWidgetID , SUI::DialogImpl *apGui);
};


#endif // TESTCOPYNONHANDLER_H
