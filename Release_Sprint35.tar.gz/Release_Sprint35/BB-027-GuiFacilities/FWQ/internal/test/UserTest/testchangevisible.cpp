#include "testchangevisible.h"

#include <SUIIText.h>

testChangeVisible::testChangeVisible(QString aSourcWidgetID, SUI::DialogImpl *apGui):
    mSourceWidgetid1(aSourcWidgetID),
    mpGui(apGui)
{
}

void testChangeVisible::handleImageWidgetChangeVisibility(bool Widgetchanged)
{
    SUI::IText *Widget = mpGui->getObjectList()->getObject<SUI::IText>("txaStatus");
    if (Widget)
    {
        if (Widgetchanged)
        {
            Widget->setText("ImageWidget is visible");
        }
        else
        {
            Widget->setText("ImageWidget is not visible");
        }
    }
}
