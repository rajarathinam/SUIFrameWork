#ifndef TESTSHOWITEM_H
#define TESTSHOWITEM_H

#include <QString>



namespace SUI {
class DialogImpl;
}

class testShowItem
{
private:
    QString mTargetWidgetid;
    QString mDropDownText;
    SUI::DialogImpl *mpGui;

public:
    testShowItem(QString aDropDownText, SUI::DialogImpl *apGui);
    void handleClicked();
};


#endif // TESTSHOWITEM_H
