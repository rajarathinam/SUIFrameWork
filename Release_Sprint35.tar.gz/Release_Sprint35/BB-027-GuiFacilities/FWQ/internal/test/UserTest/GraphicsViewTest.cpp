#include "GraphicsViewTest.h"

#include <SUIGraphicsView.h>
#include <SUIDialogImpl.h>
#include <SUIICheckable.h>
#include <SUIGraphicsScene.h>
#include <SUIMouseButtonEnum.h>
#include <SUIIText.h>
#include <SUIIClickable.h>
#include <SUIINumeric.h>
#include <SUIColorCrossDrop.h>
#include <SUILineEdit.h>
#include <SUIDropDown.h>
#include <SUIDoubleSpinBox.h>

#include <boost/bind.hpp>
#include <boost/shared_ptr.hpp>

#include "GraphicsSceneMouseEventTest.h"
#include "testchangevisible.h"
#include "testsetitemcolor.h"
#include "testcopyhandler.h"
#include "testmakepicture.h"
#include "testsetbackgroundstyle.h"
#include "testsetzoomstyle.h"
#include "testsetscrollzoom.h"

GraphicsViewTest::GraphicsViewTest(SUI::DialogImpl *dialog) :
    dialog(dialog),
    graphicsView(dialog->getObjectList()->getObject<SUI::GraphicsView>("imv395")),
    graphicsSceneMouseEventTest(new GraphicsSceneMouseEventTest(dialog))
{
    Q_ASSERT(graphicsView);

    SUI::ICheckable *checkable = dialog->getObjectList()->getObject<SUI::ICheckable>("cbx690");
    checkable->checkStateChanged = boost::bind(&GraphicsViewTest::onScrollBarsEnable ,this, _1);
    checkable->setChecked(false);
    onScrollBarsEnable(false);

    checkable = dialog->getObjectList()->getObject<SUI::ICheckable>("cbx399");
    checkable->checkStateChanged = boost::bind(&GraphicsViewTest::onEnableChecked ,this, _1);
    checkable->setChecked(true);

    checkable = dialog->getObjectList()->getObject<SUI::ICheckable>("cbx400");
    checkable->checkStateChanged = boost::bind(&GraphicsViewTest::onVisibleChecked ,this, _1);
    checkable->setChecked(true);

    //MouseHandlers
    SUI::GraphicsScene *graphicsScene = graphicsView->getGraphicsScene();
    Q_ASSERT(graphicsScene);
    graphicsScene->mousePressed = boost::bind(&GraphicsSceneMouseEventTest::mouseClickEvent, graphicsSceneMouseEventTest, _1);
    graphicsScene->mouseMoved = boost::bind(&GraphicsSceneMouseEventTest::mouseMoveEvent, graphicsSceneMouseEventTest, _1);
    graphicsScene->mouseReleased = boost::bind(&GraphicsSceneMouseEventTest::mouseReleaseEvent, graphicsSceneMouseEventTest, _1);
    graphicsScene->mouseWheelMoved = boost::bind(&GraphicsSceneMouseEventTest::mouseWheelEvent, graphicsSceneMouseEventTest, _1);

    //Zoom
    dialog->getObjectList()->getObject<SUI::IClickable>("btn579")->clicked = boost::bind(&GraphicsViewTest::onZoomButtonClicked , this);
    dialog->getObjectList()->getObject<SUI::IClickable>("btn588")->clicked = boost::bind(&GraphicsViewTest::onCropZoomButtonClicked, this);

    //VisibilityChange
    testChangeVisible *tChangeVisible = new testChangeVisible("imv395", dialog);
    SUI::IViewable *changeableVis = dialog->getObjectList()->getObject<SUI::IViewable>("imv395");
    if(changeableVis != NULL)
        changeableVis->visibilityChanged = boost::bind(&testChangeVisible::handleImageWidgetChangeVisibility , tChangeVisible, _1);

    // Color Change graphic items
    testSetItemColor *tSetItemColor = new testSetItemColor("ccd367", "ddb357", dialog);
    SUI::ColorCrossDrop *colorCrossDrop = dialog->getObjectList()->getObject<SUI::ColorCrossDrop>("ccd367");
    colorCrossDrop->colorChanged = boost::bind(&testSetItemColor::onGraphicsItemColorChanged , tSetItemColor);

    //    Set text
    testCopyHandler *tCopyHandler27 = new testCopyHandler("lne370", "Text", dialog);
    SUI::LineEdit *lineEdit = dialog->getObjectList()->getObject<SUI::LineEdit>("lne370");
    lineEdit->textChanged = boost::bind(&testCopyHandler::onTextChanged , tCopyHandler27, _1);

    // create picture
    testMakePicture *tMakePicture = new testMakePicture("imv395", "lne722", "ddb723", "ddb724", dialog);
    SUI::IClickable *clickable = dialog->getObjectList()->getObject<SUI::IClickable>("btn720");
    clickable->clicked = boost::bind(&testMakePicture::handleClicked , tMakePicture);

    // Set Background style
    testSetBackgroundStyle *tSetBackgroundStyle = new testSetBackgroundStyle("ddb732", "imv395", dialog);
    SUI::DropDown *dropDown = dialog->getObjectList()->getObject<SUI::DropDown>("ddb732");
    dropDown->valueChanged = boost::bind(&testSetBackgroundStyle::handleValueChanged , tSetBackgroundStyle);

    testSetBackGndImage *tSetBackGndImage = new testSetBackGndImage("imv395", dialog);
    clickable = dialog->getObjectList()->getObject<SUI::IClickable>("btn922");
    clickable->clicked = boost::bind(&testSetBackGndImage::handleClicked , tSetBackGndImage);

    // Set Zoom style
    testSetZoomStyle *tSetZoomStyle = new testSetZoomStyle("ddb734", "imv395", dialog);
    dropDown = dialog->getObjectList()->getObject<SUI::DropDown>("ddb734");
    dropDown->valueChanged = boost::bind(&testSetZoomStyle::handleValueChanged , tSetZoomStyle);

    // Set Scroll zoom
    testSetScrollZoom *tSetScrollZoom = new testSetScrollZoom("imv395", dialog);
    checkable = dialog->getObjectList()->getObject<SUI::ICheckable>("cbx921");
    checkable->checkStateChanged = boost::bind(&testSetScrollZoom::handleCheckedChanged ,tSetScrollZoom, _1);
    checkable->setChecked(true);


    // Get ZoomFactor
//    testGetZoomFactor *tGetZoomFactor = new testGetZoomFactor("imv395", "lne745", dialog);
//    clickable = dialog->getObjectList()->getObject<SUI::IClickable>("btn744");
//    clickable->clicked = boost::bind(&testGetZoomFactor::handleClicked , tGetZoomFactor);

}

GraphicsViewTest::~GraphicsViewTest()
{
    delete graphicsSceneMouseEventTest;
}

void GraphicsViewTest::onScrollBarsEnable(bool checked) {
    graphicsView->setScrollBarsEnabled(checked);
}

void GraphicsViewTest::onEnableChecked(bool checked) {
    graphicsView->setEnabled(checked);
}

void GraphicsViewTest::onVisibleChecked(bool checked) {
    graphicsView->setVisible(checked);
}

void GraphicsViewTest::onZoomButtonClicked() {
    SUI::IText *widgetTextmFact = dialog->getObjectList()->getObject<SUI::IText>("lne581");
    SUI::IText *widgetTextmX = dialog->getObjectList()->getObject<SUI::IText>("lne585");
    SUI::IText *widgetTextmY = dialog->getObjectList()->getObject<SUI::IText>("lne586");

    graphicsView->zoom(
                QString::fromStdString(widgetTextmFact->getText()).toDouble(),
                QString::fromStdString(widgetTextmX->getText()).toInt(),
                QString::fromStdString(widgetTextmY->getText()).toInt());

    SUI::IText *statusBar = dialog->getObjectList()->getObject<SUI::IText>("txaStatus");
    statusBar->setText(QString("Zoom factor: %1").arg(QString::number(graphicsView->getScale(), 'g', 2)).toStdString());
}

void GraphicsViewTest::onCropZoomButtonClicked() {
    SUI::IText *widgetTextmX = dialog->getObjectList()->getObject<SUI::IText>("lne589");
    SUI::IText *widgetTextmY = dialog->getObjectList()->getObject<SUI::IText>("lne593");
    SUI::IText *widgetTextmW = dialog->getObjectList()->getObject<SUI::IText>("lne594");
    SUI::IText *widgetTextmH = dialog->getObjectList()->getObject<SUI::IText>("lne596");

    graphicsView->fitInView(
                QString::fromStdString(widgetTextmX->getText()).toInt(),
                QString::fromStdString(widgetTextmY->getText()).toInt(),
                QString::fromStdString(widgetTextmW->getText()).toInt(),
                QString::fromStdString(widgetTextmH->getText()).toInt());

    SUI::IText *statusBar = dialog->getObjectList()->getObject<SUI::IText>( "txaStatus" );
    statusBar->setText(QString("Zoom factor: %1").arg(QString::number(graphicsView->getScale(), 'g', 2 )).toStdString());
}
