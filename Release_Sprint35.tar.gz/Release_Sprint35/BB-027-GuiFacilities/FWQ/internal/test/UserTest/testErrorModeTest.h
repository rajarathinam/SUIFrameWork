#ifndef TESTERRORMODETEST_H
#define TESTERRORMODETEST_H

#include <QString>

namespace SUI {
class DialogImpl;
}

class testErrorMode
{
private:
    QString mDropdown;
    QString mWidgetid;
    SUI::DialogImpl  *mpGui;

public:
    testErrorMode(QString aDropdown, QString aWidget, SUI::DialogImpl *apGui);
    void onSelectionChanged();
};

#endif // TESTERRORMODETEST_H
