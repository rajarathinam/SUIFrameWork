#include "testplotaddpoint.h"

#include <SUIIText.h>
#include <SUIINumeric.h>
#include <SUIPlotWidget.h>

#include <sstream>

testPlotAddPoint::testPlotAddPoint(QString pltWidgetID, QString CurveNameID, QString XPointID, QString YPointID, SUI::DialogImpl *apGui) :
    mPlotWidgetID(pltWidgetID),
    mCurveNameID(CurveNameID),
    mAddXID(XPointID),
    mAddYID(YPointID),
    mpGui(apGui)
{

}

void testPlotAddPoint::handleClicked()
{
    SUI::PlotWidget *plotWidget = mpGui->getObjectList()->getObject<SUI::PlotWidget>(mPlotWidgetID.toStdString());
    SUI::IText *widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mCurveNameID.toStdString());
    if (plotWidget && widgetText)
    {
        std::string curveName = widgetText->getText();
        SUI::INumeric<double> *widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<double>>(mAddXID.toStdString());
        if (widgetNum)
        {
            double XPoint = widgetNum->getValue();
            widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<double>>(mAddYID.toStdString());
            if (widgetNum)
            {
                double YPoint = widgetNum->getValue();
                plotWidget->setDataPoint(curveName, XPoint, YPoint);
            }
        }
    }
}

testPlotAddDataSet::testPlotAddDataSet(QString pltWidgetID, QString CurveNameID, QString DataSetID, SUI::DialogImpl *apGui) :
    mPlotWidgetID(pltWidgetID),
    mCurveNameID(CurveNameID),
    mDataSetID(DataSetID),
    mpGui(apGui)
{

}

void testPlotAddDataSet::handleClicked()
{
    SUI::IText *widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mCurveNameID.toStdString());
    SUI::PlotWidget *plotWidget = mpGui->getObjectList()->getObject<SUI::PlotWidget>(mPlotWidgetID.toStdString());
    if (plotWidget && widgetText)
    {
        std::string curveName = widgetText->getText();
        widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mDataSetID.toStdString());
        if (widgetText)
        {
            std::stringstream ss(widgetText->getText());
            std::string split;
            int count = 0;
            while (std::getline(ss, split, ';'))
            {
                QString qStrCoordinates = QString::fromUtf8(split.c_str());
                QStringList qStrXandY = qStrCoordinates.split(",", QString::SkipEmptyParts);
                if ((qStrXandY.size() == 2) && !qStrXandY.at(0).isEmpty() && !qStrXandY.at(1).isEmpty())
                {
                    xData[count] = qStrXandY.at(0).toDouble();
                    yData[count] = qStrXandY.at(1).toDouble();
                    ++count;
                }
            }
            plotWidget->setDataPoints(curveName, xData, yData, count);
        }
    }
}

testPlotAddRawDataSet::testPlotAddRawDataSet(QString pltWidgetID, QString CurveNameID, QString DataSetID, SUI::DialogImpl *apGui) :
    mPlotWidgetID(pltWidgetID),
    mCurveNameID(CurveNameID),
    mDataSetID(DataSetID),
    mpGui(apGui)
{

}

void testPlotAddRawDataSet::handleClicked()
{
    SUI::IText *widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mCurveNameID.toStdString());
    SUI::PlotWidget *plotWidget = mpGui->getObjectList()->getObject<SUI::PlotWidget>(mPlotWidgetID.toStdString());
    if (plotWidget && widgetText)
    {
        std::string curveName = widgetText->getText();
        widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mDataSetID.toStdString());
        if (widgetText)
        {
            std::stringstream ss(widgetText->getText());
            std::string split;
            int count = 0;
            while (std::getline(ss, split, ';'))
            {
                QString qStrCoordinates = QString::fromUtf8(split.c_str());
                QStringList qStrXandY = qStrCoordinates.split(",", QString::SkipEmptyParts);
                if ((qStrXandY.size() == 2) && !qStrXandY.at(0).isEmpty() && !qStrXandY.at(1).isEmpty())
                {
                    xData[count] = qStrXandY.at(0).toDouble();
                    yData[count] = qStrXandY.at(1).toDouble();
                    ++count;
                }
            }
            plotWidget->setRawDataPoints(curveName, xData, yData, count);
        }
    }
}


