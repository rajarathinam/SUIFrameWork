#ifndef TESTSETAUTOSCROLL_H
#define TESTSETAUTOSCROLL_H

#include <QString>

namespace SUI {
class DialogImpl;
}

class testSetAutoScroll
{
    QString mTargetWidgetID;
    SUI::DialogImpl  *mpGui;
public:
    testSetAutoScroll(QString aTargetWidgetID, SUI::DialogImpl *apGui);
    void handleCheckedChanged(bool checked);
};

#endif // TESTSETAUTOSCROLL_H
