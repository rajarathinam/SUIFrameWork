#ifndef TESTPLOTGETDATASETNAMES_H
#define TESTPLOTGETDATASETNAMES_H

#include <QString>



namespace SUI {
class DialogImpl;
}

class testPlotGetDataSetNames
{
public:
    testPlotGetDataSetNames(QString pltWidgetID, QString textAreaID, SUI::DialogImpl *apGui);

    void    handleClicked();

private:
    QString mPlotWidgetID;
    QString mTextAreaID;
    SUI::DialogImpl  *mpGui;
};

#endif // TESTPLOTGETDATASETNAMES_H
