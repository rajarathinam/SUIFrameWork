#include "testEditContextMenu.h"

#include <SUIIText.h>
#include <SUIDialogImpl.h>

testEditContextMenu::testEditContextMenu(QString aSourceWidgetID, QString aTargetWidgetID, SUI::DialogImpl *apGui):
    mSourceWidgetid(aSourceWidgetID),
    mTargetWidgetid(aTargetWidgetID),
    mpGui(apGui)
{
}

void testEditContextMenu::handleClicked()
{
    std::list<std::string> stdItemList;
    // The source widget text will be the new context menu item list
    // MenuItems should be ';' or '\n' seperated strings e.g. "1;2;3" or "1\n2\n3"
    SUI::IText *widget = mpGui->getObjectList()->getObject<SUI::IText>(mSourceWidgetid.toStdString());
    if (widget)
    {
        //FIXME getWidgetProperties is not available anymore
        QString menuItems = QString::fromStdString(widget->getText());
        QStringList itemList = menuItems.split(";");
        foreach(QString item, itemList)
        {
            stdItemList.push_back(item.toStdString());
        }
        SUI::Widget   *widgetProp = mpGui->getObjectList()->getObject<SUI::Widget>(mTargetWidgetid.toStdString());
        if (widgetProp)
        {
            widgetProp->setContextMenuItems(stdItemList);
        }
    }
}

void testEditContextMenu::onContextMenuSelected(std::string selectedText)
{
    SUI::IText *textWidget = mpGui->getObjectList()->getObject<SUI::IText>(mSourceWidgetid.toStdString());
    if (textWidget)
        textWidget->setText(selectedText);
}
