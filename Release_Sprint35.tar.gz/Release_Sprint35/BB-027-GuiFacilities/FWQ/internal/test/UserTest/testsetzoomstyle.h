#ifndef TESTSETZOOMSTYLE_H
#define TESTSETZOOMSTYLE_H

#include "SUIDialogImpl.h"

class testSetZoomStyle
{
private:
    QString mTargetWidgetid;
    QString mSourceWidgetid;
    SUI::DialogImpl  *mpGui;

public:
    testSetZoomStyle(QString aSourceWidgetID, QString aTargetWidgetID , SUI::DialogImpl *apGui);
    void handleValueChanged();
};

#endif // TESTSETZOOMSTYLE_H
