#ifndef TESTSETFOCUS_H
#define TESTSETFOCUS_H

#include <QString>



namespace SUI {
class DialogImpl;
}

class testSetFocus
{
private:
    QString mTargetWidgetid;
    SUI::DialogImpl  *mpGui;

public:
    void handleClicked();
    testSetFocus(QString aTargetWidgetID , SUI::DialogImpl *apGui);
};

#endif // TESTSETFOCUS_H
