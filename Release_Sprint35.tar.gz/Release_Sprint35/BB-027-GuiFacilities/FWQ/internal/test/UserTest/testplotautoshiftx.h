#ifndef TESTPLOTAUTOSHIFTX_H
#define TESTPLOTAUTOSHIFTX_H

#include <SUIDialogImpl.h>

class testPlotAutoShiftX
{
public:
    testPlotAutoShiftX(QString pltWidgetID, SUI::DialogImpl *apGui);

    void handleCheckedChanged(bool checked);

private:
    QString mPlotWidgetID;
    QString mCheckedWidgetID;

    SUI::DialogImpl  *mpGui;
};

#endif // TESTPLOTAUTOSHIFTX_H
