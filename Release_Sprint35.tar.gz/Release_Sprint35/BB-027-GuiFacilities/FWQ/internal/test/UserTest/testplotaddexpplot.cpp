#include "testplotaddexpplot.h"

#include <qmath.h>

#include <SUIPlotWidget.h>
#include <SUIIText.h>
#include <SUIDialogImpl.h>

testPlotAddExpPlot::testPlotAddExpPlot(QString pltWidgetID, QString CurveNameID, SUI::DialogImpl *apGui) :
    mPlotWidgetID(pltWidgetID),
    mCurveNameID(CurveNameID),
    mpGui(apGui)
{

}

void testPlotAddExpPlot::handleClicked()
{
    SUI::PlotWidget *plotWidget = mpGui->getObjectList()->getObject<SUI::PlotWidget>(mPlotWidgetID.toStdString());
    SUI::IText     *widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mCurveNameID.toStdString());
    if (plotWidget && widgetText)
    {
        std::string     curveName = widgetText->getText();
        double k;
        for (k = 0; k < 10; k += 0.01)
        {
            plotWidget->setDataPoint(curveName, k, qExp(k));
        }
    }
}
