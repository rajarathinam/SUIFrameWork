#ifndef TESTPLOTCLEARDATA_H
#define TESTPLOTCLEARDATA_H

#include <SUIDialogImpl.h>



class testPlotClearData
{
public:
    testPlotClearData(QString pltWidgetID, QString CurveNameID , SUI::DialogImpl *apGui);

    void    handleClicked();

private:
    QString mPlotWidgetID;
    QString mCurveNameID;

    SUI::DialogImpl  *mpGui;
};

#endif // TESTPLOTCLEARDATA_H
