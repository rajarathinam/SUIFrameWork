#ifndef TESTPLOTSETYGRID_H
#define TESTPLOTSETYGRID_H

#include <QString>

namespace SUI {
class DialogImpl;
}

class testPlotSetYGrid
{
public:
    testPlotSetYGrid(QString pltWidgetID, QString xMaxGridID, QString xMinGridID, SUI::DialogImpl *apGui);
    void handleCheckedChanged(bool checked);

private:
    QString mPlotWidgetID;
    QString mYMaxGridID;
    QString mYMinGridID;
    SUI::DialogImpl  *mpGui;
};

#endif // TESTPLOTSETYGRID_H
