#include "testplotsetlegend.h"

#include <SUIPlotWidget.h>
#include <SUIDialogImpl.h>

testPlotSetLegend::testPlotSetLegend(QString pltWidgetID , SUI::DialogImpl *apGui) :
    mPlotWidgetID(pltWidgetID),
    mpGui(apGui)
{
}

void testPlotSetLegend::handleCheckedChanged(bool checked) {
    SUI::PlotWidget *plotWidget = mpGui->getObjectList()->getObject<SUI::PlotWidget>(mPlotWidgetID.toStdString());
    if (plotWidget)
    {
        plotWidget->enableLegend(checked);
    }
}
