#ifndef TESTSETVALUEASFACTOR_H
#define TESTSETVALUEASFACTOR_H

#include <QString>

namespace SUI {
class DialogImpl;
}

class testSetValueAsFactor
{
    QString mWidgetID;
    SUI::DialogImpl  *mpGui;

public:
    testSetValueAsFactor(QString aWidgetID, SUI::DialogImpl *apGui);

    void    handleCheckedChanged(bool checked);
};

#endif // TESTSETVALUEASFACTOR_H
