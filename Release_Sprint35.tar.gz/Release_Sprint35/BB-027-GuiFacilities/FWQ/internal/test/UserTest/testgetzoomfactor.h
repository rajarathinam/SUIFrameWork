#ifndef TESTGETZOOMFACTOR_H
#define TESTGETZOOMFACTOR_H

#include <QString>



namespace SUI {
class DialogImpl;
}

class testGetZoomFactor
{
public:
    testGetZoomFactor(QString aSourceWidget, QString aTargetWidgetID, SUI::DialogImpl *apGui);
    void handleClicked();
private:

    QString mTargetWidgetid;
    QString mSourceWidget;
    SUI::DialogImpl  *mpGui;

};

#endif // TESTGETZOOMFACTOR_H
