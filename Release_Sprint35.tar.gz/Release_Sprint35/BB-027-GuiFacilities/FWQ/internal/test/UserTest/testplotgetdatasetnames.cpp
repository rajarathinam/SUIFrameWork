#include "testplotgetdatasetnames.h"

#include <SUIIText.h>
#include <SUIPlotWidget.h>
#include <SUIDialogImpl.h>

testPlotGetDataSetNames::testPlotGetDataSetNames(QString pltWidgetID, QString textAreaID, SUI::DialogImpl *apGui) :
    mPlotWidgetID(pltWidgetID),
    mTextAreaID(textAreaID),
    mpGui(apGui)
{
}

void testPlotGetDataSetNames::handleClicked()
{
    SUI::PlotWidget *plotWidget = mpGui->getObjectList()->getObject<SUI::PlotWidget>(mPlotWidgetID.toStdString());
    SUI::IText     *widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mTextAreaID.toStdString());
    if (plotWidget && widgetText)
    {
        std::string     allDataNames = plotWidget->getDatasetList();
        widgetText->setText(allDataNames);
    }
}
