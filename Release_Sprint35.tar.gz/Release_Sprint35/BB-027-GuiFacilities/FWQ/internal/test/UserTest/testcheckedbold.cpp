#include "testcheckedbold.h"

#include <SUIIText.h>
#include <SUIDialogImpl.h>

testCheckedBold::testCheckedBold(QString aWidgetID, SUI::DialogImpl *apGui):
    mWidgetID(aWidgetID),
    mpGui(apGui)
{
}

void testCheckedBold::handleCheckedChanged(bool checked)
{
    SUI::IText *widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mWidgetID.toStdString());
    if (widgetText)
    {
        widgetText->setBold(checked);
    }
}
