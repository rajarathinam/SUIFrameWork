#ifndef TESTBROWSERFORSAVING_H
#define TESTBROWSERFORSAVING_H

#include <QString>

namespace SUI {
class DialogImpl;
}

#include <SUIFileDialog.h>

class testBrowserforSaving
{
    QString mWidgetID;
    SUI::DialogImpl  *mpGui;
    QString mRb1;
    SUI::FileDialog::AcceptMode fMode;
public:
    testBrowserforSaving(QString aWidgetID, QString aRb1, SUI::FileDialog::AcceptMode aMode, SUI::DialogImpl *apGui);
    void handleCheckedChanged(bool checked);
};

#endif // TESTBROWSERFORSAVING_H
