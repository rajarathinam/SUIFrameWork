#ifndef TESTSTYLESHEET_H
#define TESTSTYLESHEET_H


#include <SUIDialogImpl.h>
class testStyleSheet
{
public:
    testStyleSheet(QString aTextWidgetId, QString aWidgetId, SUI::DialogImpl* apGui);

    void    onSetStyleSheetClicked();
    void    onResetStyleSheetClicked();

private:
    QString mTextWidgetId;
    QString mWidgetId;
    SUI::DialogImpl  *mpGui;
};

#endif
