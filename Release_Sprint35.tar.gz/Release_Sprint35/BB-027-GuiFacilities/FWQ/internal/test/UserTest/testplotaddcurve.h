#ifndef TESTPLOTWIDGET_H
#define TESTPLOTWIDGET_H

#include <SUIDialogImpl.h>



class testPlotAddCurve
{
public:
    testPlotAddCurve(QString pltWidgetID, QString CurveNameID, QString Left_RightID, SUI::DialogImpl *apGui);

    void    handleClicked();

private:
    QString mPlotWidgetID;
    QString mCurveNameID;
    QString mLeft_RightID;
    SUI::DialogImpl  *mpGui;
};

class testPlotDeleteCurve
{
public:
    testPlotDeleteCurve(QString pltWidgetID, QString CurveNameID, SUI::DialogImpl *apGui);

    void    handleClicked();

private:
    QString mPlotWidgetID;
    QString mCurveNameID;
    SUI::DialogImpl  *mpGui;
};

#endif // TESTPLOTWIDGET_H
