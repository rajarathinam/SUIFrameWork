#ifndef TESTSETITEMCOLOR_H
#define TESTSETITEMCOLOR_H


#include "SUIDialogImpl.h"

class testSetItemColor
{
private:
    QString mSourceWidgetid;
    QString mDropDownText;

    SUI::DialogImpl  *mpGui;

public:
    void onGraphicsItemColorChanged();
    testSetItemColor(QString aSourceWidgetID, QString aDropDownText , SUI::DialogImpl *apGui);
};

#endif // TESTSETITEMCOLOR_H
