#ifndef TESTTABPAGE_H
#define TESTTABPAGE_H


#include <SUIDialogImpl.h>

class testTabPageIcon
{
public:
    testTabPageIcon(QString srcID, QString trgID, QString lineeditID, SUI::DialogImpl *apGui);

    void    handleClicked();

private:
    QString     mSrcID;
    QString     mTrgID;
    QString     mLineEditID;
    SUI::DialogImpl      *mpGui;
};

class testTabPageIconNames
{
public:
    testTabPageIconNames(QString srcID, QString trgID, SUI::DialogImpl *apGui);

    void    handleClicked();

private:
    QString     mSrcID;
    QString     mTrgID;
    SUI::DialogImpl      *mpGui;
};

class testTabRemoveIcon
{
public:
    testTabRemoveIcon(QString tbpID, SUI::DialogImpl *apGui);

    void    handleClicked();
private:
    QString mTabPageID;
    SUI::DialogImpl  *mpGui;
};

class testTabCurrentIconName
{
public:
    testTabCurrentIconName(QString tbpID, QString lneID, SUI::DialogImpl *apGui);

    void    handleClicked();

private:
    QString mTabPageID;
    QString mLineEditID;
    SUI::DialogImpl  *mpGui;
};

class testfocusTabPage
{
    QString mWidgetID;
    QString mTargetID;
    SUI::DialogImpl  *mpGui;
public:
    testfocusTabPage(QString aWidgetID, QString aTargetID, SUI::DialogImpl *apGui);
    void handleClicked();
};
#endif // TESTTABPAGE_H
