#ifndef TESTPLOTYRIGHTLABEL_H
#define TESTPLOTYRIGHTLABEL_H

#include <QString>

namespace SUI {
class DialogImpl;
}

class testPlotYRightLabel
{
public:
    testPlotYRightLabel(QString pltWidgetID, QString YLabelWidgetID, SUI::DialogImpl *apGui);

    void    handleClicked();

private:
    QString mPlotWidgetID;
    QString mYLabelWidgetID;

    SUI::DialogImpl  *mpGui;
};

#endif // TESTPLOTYRIGHTLABEL_H
