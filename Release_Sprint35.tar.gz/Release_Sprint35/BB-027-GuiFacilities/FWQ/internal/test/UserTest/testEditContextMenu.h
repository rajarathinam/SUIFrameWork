#ifndef TESTEDITCONTEXTMENU_H
#define TESTEDITCONTEXTMENU_H

#include <QString>



namespace SUI {
class DialogImpl;
}

class testEditContextMenu
{
private:
    QString mSourceWidgetid;
    QString mTargetWidgetid;
    SUI::DialogImpl  *mpGui;
public:
    testEditContextMenu(QString aSourceWidgetID, QString aTargetWidgetID, SUI::DialogImpl *apGui);
    void handleClicked();
    void onContextMenuSelected(std::string selectedText);
};

#endif // TESTEDITCONTEXTMENU_H
