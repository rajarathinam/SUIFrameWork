#include "testplotsetrectangle.h"

#include <SUIIText.h>
#include <SUIPlotAxisEnum.h>
#include <SUICurveColorEnum.h>

#include <SUIIText.h>
#include <SUIPlotWidget.h>
#include <SUIDialogImpl.h>
#include <SUIDropDown.h>
#include <SUISpinBox.h>

testPlotSetRectangle::testPlotSetRectangle(QString pltWidgetID, QString IdWidgetID, QString XMinID, QString XMaxID,
                                           QString LabelID, QString colorWidgetID, QString orientWidgetID, QString ySideWidgetID, SUI::DialogImpl *apGui) :
    mPlotWidgetID(pltWidgetID),
    mIdWidgetID(IdWidgetID),
    mXMinID(XMinID),
    mXMaxID(XMaxID),
    mLabelID(LabelID),
    mColorWidgetID(colorWidgetID),
    mOrientWidgetID(orientWidgetID),
    mYSideWidgetID(ySideWidgetID),
    mpGui(apGui)
{
}
void testPlotSetRectangle::handleCheckedChanged(bool checked)
{
    SUI::PlotWidget *plotWidget = mpGui->getObjectList()->getObject<SUI::PlotWidget>(mPlotWidgetID.toStdString());
    SUI::IText *widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mIdWidgetID.toStdString());
    if (plotWidget && widgetText)
    {
        int rectId = QString::fromStdString(widgetText->getText()).toInt();
        SUI::SpinBox *widgetNum = mpGui->getObjectList()->getObject<SUI::SpinBox>(mXMinID.toStdString());
        if (widgetNum)
        {
            int XMin = widgetNum->getValue();
            widgetNum = mpGui->getObjectList()->getObject<SUI::SpinBox>(mXMaxID.toStdString());
            if (widgetNum)
            {
                int XMax = widgetNum->getValue();
                widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mLabelID.toStdString());
                if (widgetText)
                {
                    QString labelText = QString::fromStdString(widgetText->getText());
                    SUI::DropDown *dropColor = mpGui->getObjectList()->getObject<SUI::DropDown>(mColorWidgetID.toStdString());
                    if (dropColor)
                    {
                        QString colorString = QString::fromStdString(dropColor->getSelectedItems().front());
                        SUI::DropDown *dropOrient = mpGui->getObjectList()->getObject<SUI::DropDown>(mOrientWidgetID.toStdString());
                        if (dropOrient)
                        {
                            QString orientation = QString::fromStdString(dropOrient->getSelectedItems().front());
                            SUI::DropDown *dropYSide = mpGui->getObjectList()->getObject<SUI::DropDown>(mYSideWidgetID.toStdString());
                            if (dropYSide)
                            {
                                QString yside = QString::fromStdString(dropYSide->getSelectedItems().front());
                                SUI::PlotAxisEnum::PlotAxis axis;

                                if (orientation.toLower() == "vertical")
                                {
                                    axis = SUI::PlotAxisEnum::xBottom;
                                }
                                else if (yside.toLower() == "right")
                                {
                                    axis = SUI::PlotAxisEnum::yRight;
                                }
                                else
                                {
                                    axis = SUI::PlotAxisEnum::yLeft;
                                }

                                SUI::CurveColorEnum::CurveColor color;
                                if (colorString == "Blue")
                                {
                                    color = SUI::CurveColorEnum::Blue;
                                }
                                else if (colorString == "Green")
                                {
                                    color = SUI::CurveColorEnum::Green;
                                }
                                else if (colorString == "Red")
                                {
                                    color = SUI::CurveColorEnum::Red;
                                }
                                else if (colorString == "Yellow")
                                {
                                    color = SUI::CurveColorEnum::Yellow;
                                }
                                else
                                {
                                    color = SUI::CurveColorEnum::Black;
                                }
                                plotWidget->setRectangle(rectId, XMin, XMax, color, checked, labelText.toStdString(), axis);
                            }
                        }
                    }
                }
            }
        }
    }
}


testPlotSetRangeRectangle::testPlotSetRangeRectangle(QString pltWidgetID, QString nameWidgetID, QString xWidgetID, QString yWidgetID, QString widthWidgetID,
                                                     QString heightWidgetID, QString colorWidgetID, QString yaxisWidgetID, QString LabelID, SUI::DialogImpl *apGui) :
    mPlotWidgetID(pltWidgetID),
    mNameWidgetID(nameWidgetID),
    mXWidgetID(xWidgetID),
    mYWidgetID(yWidgetID),
    mWidthWidgetID(widthWidgetID),
    mHeightWidgetID(heightWidgetID),
    mColorWidgetID(colorWidgetID),
    mYAxisWidgetID(yaxisWidgetID),
    mLabelID(LabelID),
    mpGui(apGui)
{
}

void testPlotSetRangeRectangle::handleCheckedChanged(bool checked)
{
    SUI::PlotWidget *plotWidget = mpGui->getObjectList()->getObject<SUI::PlotWidget>(mPlotWidgetID.toStdString());
    SUI::IText *widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mNameWidgetID.toStdString());
    if (plotWidget && widgetText)
    {
        int id = QString::fromStdString(widgetText->getText()).toInt();
        SUI::SpinBox *widgetNum = mpGui->getObjectList()->getObject<SUI::SpinBox>(mXWidgetID.toStdString());
        if (widgetNum)
        {
            int xstart = widgetNum->getValue();
            widgetNum = mpGui->getObjectList()->getObject<SUI::SpinBox>(mYWidgetID.toStdString());
            if (widgetNum)
            {
                int ystart = widgetNum->getValue();
                widgetNum = mpGui->getObjectList()->getObject<SUI::SpinBox>(mWidthWidgetID.toStdString());
                if (widgetNum)
                {
                    int xend = widgetNum->getValue();
                    widgetNum = mpGui->getObjectList()->getObject<SUI::SpinBox>(mHeightWidgetID.toStdString());
                    if (widgetNum)
                    {
                        int yend = widgetNum->getValue();
                        SUI::DropDown *dropColor = mpGui->getObjectList()->getObject<SUI::DropDown>(mColorWidgetID.toStdString());
                        if (dropColor)
                        {
                            QString color = QString::fromStdString(dropColor->getSelectedItems().front());
                            SUI::DropDown *dropYAxis = mpGui->getObjectList()->getObject<SUI::DropDown>(mYAxisWidgetID.toStdString());
                            if (dropYAxis)
                            {
                                QString yaxis = QString::fromStdString(dropYAxis->getSelectedItems().front());

                                widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mLabelID.toStdString());
                                if (widgetText)
                                {
                                    QString label = QString::fromStdString(widgetText->getText());
                                    SUI::CurveColorEnum::CurveColor Color;
                                    SUI::PlotAxisEnum::PlotAxis Axis;
                                    if (color == "Blue")
                                    {
                                        Color = SUI::CurveColorEnum::Blue;
                                    }
                                    else if (color == "Green")
                                    {
                                        Color = SUI::CurveColorEnum::Green;
                                    }
                                    else if (color == "Red")
                                    {
                                        Color = SUI::CurveColorEnum::Red;
                                    }
                                    else if (color == "Yellow")
                                    {
                                        Color = SUI::CurveColorEnum::Yellow;
                                    }
                                    else
                                    {
                                        Color = SUI::CurveColorEnum::Black;
                                    }

                                    if (yaxis.toLower() == "right")
                                    {
                                        Axis = SUI::PlotAxisEnum::yRight;
                                    }
                                    else
                                    {
                                        Axis = SUI::PlotAxisEnum::yLeft;
                                    }
                                    plotWidget->setROI(id, checked, label.toStdString(), xstart, xend, ystart, yend, Color, Axis);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
