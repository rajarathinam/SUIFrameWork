#ifndef TESTZOOMIMAGEVIEWER_H
#define TESTZOOMIMAGEVIEWER_H

#include <QString>



namespace SUI {
class DialogImpl;
}

class testZoomImageViewer
{
public:
    testZoomImageViewer(QString Factor, QString X, QString Y, QString aTargetWidgetid, SUI::DialogImpl *apGui);
    void handleClicked();
private:
    QString mFactor;
    QString mX;
    QString mY;
    QString mTargetWidgetid;
    SUI::DialogImpl  *mpGui;
};

#endif // TESTZOOMIMAGEVIEWER_H
