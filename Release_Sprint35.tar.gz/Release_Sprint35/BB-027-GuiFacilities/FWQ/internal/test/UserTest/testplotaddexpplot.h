#ifndef TESTPLOTADDEXPPLOT_H
#define TESTPLOTADDEXPPLOT_H

#include <QString>



namespace SUI {
class DialogImpl;
}

class testPlotAddExpPlot
{
public:
    testPlotAddExpPlot(QString pltWidgetID, QString CurveNameID, SUI::DialogImpl *apGui);

    void    handleClicked();

private:
    QString mPlotWidgetID;
    QString mCurveNameID;
    SUI::DialogImpl *mpGui;
};

#endif // TESTPLOTADDEXPPLOT_H
