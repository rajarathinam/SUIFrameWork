#include "testLineEditValidation.h"

#include <SUIIText.h>
#include <SUIIErrorMode.h>
#include <SUIDialogImpl.h>

testLineEditValidation::testLineEditValidation(QString awidgetID, SUI::DialogImpl *apGui) :
    mWidgetid(awidgetID),
    mpGui(apGui)
{
}

void testLineEditValidation::ValidationFailed()
{
    SUI::IText *textWidget = mpGui->getObjectList()->getObject<SUI::IText>("txaStatus");
    if (textWidget)
    {
        textWidget->setText("ObjectName = " + mWidgetid.toStdString() + " input does not comply ");
    }
}

void testLineEditValidation::handleCheckedChanged(bool checked)
{
    SUI::IErrorMode *widget = mpGui->getObjectList()->getObject<SUI::IErrorMode>(mWidgetid.toStdString());
    if (widget)
    {
        if (checked)
        {
            widget->setMode(SUI::ErrorModeEnum::Error);
        }
        else
        {
            widget->setMode(SUI::ErrorModeEnum::None);
        }
    }
}

