#include "CustomPlotDataSet.h"
#include "testplotsetstyle.h"

#include <SUIIText.h>
#include <SUIINumeric.h>
#include <SUIPlotWidget.h>
#include <SUIDialogImpl.h>
#include <SUIDropDown.h>

testPlotSetStyle::testPlotSetStyle(QString pltWidgetID, QString CurveNameID, QString colorWidgID, QString linetypeWidgID,
                                   QString penwidthID, SUI::DialogImpl *apGui) :
    mPlotWidgetID(pltWidgetID),
    mCurveNameID(CurveNameID),
    mColorWidgetID(colorWidgID),
    mLinetypeWidgetID(linetypeWidgID),
    mPenwidthWidgetID(penwidthID),
    mpGui(apGui)
{
}

void testPlotSetStyle::handleClicked() {
    SUI::PlotWidget *plotWidget = mpGui->getObjectList()->getObject<SUI::PlotWidget>(mPlotWidgetID.toStdString());
    SUI::IText *widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mCurveNameID.toStdString());
    if (plotWidget && widgetText)
    {
        std::string curveName = widgetText->getText();
        SUI::DropDown *dropColWidget = mpGui->getObjectList()->getObject<SUI::DropDown>(mColorWidgetID.toStdString());
        if (dropColWidget)
        {
            QString color = QString::fromStdString(dropColWidget->getSelectedItems().front());
            SUI::DropDown *dropLineType = mpGui->getObjectList()->getObject<SUI::DropDown>(mLinetypeWidgetID.toStdString());
            if (dropLineType)
            {
                QString linetype = QString::fromStdString(dropLineType->getSelectedItems().front());
                SUI::INumeric<int> *widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<int>>(mPenwidthWidgetID.toStdString());
                if (widgetNum)
                {
                    int penwidth = widgetNum->getValue();
                    SUI::CurveColorEnum::CurveColor Color;
                    if (color == "Blue")
                    {
                        Color = SUI::CurveColorEnum::Blue;
                    }
                    else if (color == "Green")
                    {
                        Color = SUI::CurveColorEnum::Green;
                    }
                    else if (color == "Red")
                    {
                        Color = SUI::CurveColorEnum::Red;
                    }
                    else if (color == "Yellow")
                    {
                        Color = SUI::CurveColorEnum::Yellow;
                    }
                    else
                    {
                        Color = SUI::CurveColorEnum::Black;
                    }

                    SUI::LineStyleEnum::LineStyle linestyle;
                    if (linetype == "Dash")
                    {
                        linestyle = SUI::LineStyleEnum::Dash;
                    }
                    else if (linetype == "Dot")
                    {
                        linestyle = SUI::LineStyleEnum::Dot;
                    }
                    else if (linetype == "DashDot")
                    {
                        linestyle = SUI::LineStyleEnum::DashDot;
                    }
                    else if (linetype == "DashDotDotLine")
                    {
                        linestyle = SUI::LineStyleEnum::DashDotLine;
                    }
                    else
                    {
                        linestyle = SUI::LineStyleEnum::Solid;
                    }
                    plotWidget->setStyle(curveName, Color, linestyle, penwidth);
                }
            }
        }
    }
}


testPlotMarkers::testPlotMarkers(QString pltWidgetID, QString CurveNameID, QString colorWidgID, QString linetypeWidgID,QString penwidthID, SUI::DialogImpl *apGui) :
    mPlotWidgetID(pltWidgetID),
    mCurveNameID(CurveNameID),
    mColorWidgetID(colorWidgID),
    mLinetypeWidgetID(linetypeWidgID),
    mPenwidthWidgetID(penwidthID),
    mpGui(apGui)
{

}

void testPlotMarkers::handleCheckedChanged(bool checked){
    SUI::PlotWidget *plotWidget = mpGui->getObjectList()->getObject<SUI::PlotWidget>(mPlotWidgetID.toStdString());
    SUI::IText *widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mCurveNameID.toStdString());
    if (plotWidget && widgetText)
    {
        std::string curveName = widgetText->getText();
        SUI::DropDown *dropColWidget = mpGui->getObjectList()->getObject<SUI::DropDown>(mColorWidgetID.toStdString());
        if (dropColWidget)
        {
            QString color = QString::fromStdString(dropColWidget->getSelectedItems().front());
            SUI::DropDown *dropLineType = mpGui->getObjectList()->getObject<SUI::DropDown>(mLinetypeWidgetID.toStdString());
            if (dropLineType)
            {
                SUI::INumeric<int> *widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<int>>(mPenwidthWidgetID.toStdString());
                if (widgetNum)
                {
                    int penwidth = widgetNum->getValue();
                    SUI::CurveColorEnum::CurveColor Color;
                    if (color == "Blue")
                    {
                        Color = SUI::CurveColorEnum::Blue;
                    }
                    else if (color == "Green")
                    {
                        Color = SUI::CurveColorEnum::Green;
                    }
                    else if (color == "Red")
                    {
                        Color = SUI::CurveColorEnum::Red;
                    }
                    else if (color == "Yellow")
                    {
                        Color = SUI::CurveColorEnum::Yellow;
                    }
                    else
                    {
                        Color = SUI::CurveColorEnum::Black;
                    }

                    QString marker = QString::fromStdString(dropLineType->getSelectedItems().front());
                    SUI::MarkerSymbolEnum::MarkerSymbol markerSymbol;
                    if (marker == "NoSymbol")
                    {
                        markerSymbol = SUI::MarkerSymbolEnum::NoSymbol;
                    }
                    else if (marker == "Ellipse")
                    {
                        markerSymbol = SUI::MarkerSymbolEnum::Ellipse;
                    }
                    else if (marker == "Rect")
                    {
                        markerSymbol = SUI::MarkerSymbolEnum::Rect;
                    }
                    else if (marker == "Diamond")
                    {
                        markerSymbol = SUI::MarkerSymbolEnum::Diamond;
                    }
                    else if (marker == "Traingle")
                    {
                        markerSymbol = SUI::MarkerSymbolEnum::Triangle;
                    }
                    else if (marker == "Cross")
                    {
                        markerSymbol = SUI::MarkerSymbolEnum::Cross;
                    }
                    else
                    {
                        markerSymbol = SUI::MarkerSymbolEnum::Star;
                    }

                    if(checked) { plotWidget->setPlotMarker(curveName, Color, markerSymbol, penwidth);}
                    else { plotWidget->setPlotMarker(curveName, Color, SUI::MarkerSymbolEnum::NoSymbol, penwidth);}
                }
            }
        }
    }
}
