#ifndef testTreeView_H
#define testTreeView_H


#include <SUIDialogImpl.h>

class testTreeWidget 
{
public:
    enum Act { SETTEXT, SELECT };
    testTreeWidget(QString aTargetWidgetID, QString aSourceWidgetID, SUI::DialogImpl *apGui , testTreeWidget::Act aAction);
    void handleClicked();
    void handleCheckedChanged(bool checked);
private:
    QString mTargetWidgetID;
    QString mSourceWidgetID;
    SUI::DialogImpl  *mpGui;
    testTreeWidget::Act mAction;

//    void handleValueChanged();
};

class testTreeViewSort
{
public:
    testTreeViewSort(QString treeviewID, QString sortDropDID, SUI::DialogImpl *apGui);

    void    handleClicked();

private:
    QString     mTreeViewID;
    QString     mDropDownID;
    SUI::DialogImpl      *mpGui;
};

#endif // testTreeView_H
