#ifndef TESTADDTABLEWIDGETROW_H
#define TESTADDTABLEWIDGETROW_H

#include <QString>



namespace SUI {
class DialogImpl;
}

class testAddTableWidgetRow
{
private:
    QString mTargetWidgetid;
    QString mStatus;
    SUI::DialogImpl  *mpGui;

public:
    testAddTableWidgetRow(QString aTargetWidgetID , QString aStatus, SUI::DialogImpl *apGui);
    void handleClicked();
};

class testGetItems
{
private:
    QString     mSourceID;
    QString     mTargetID;
    SUI::DialogImpl      *mpGui;

public:
    testGetItems(QString sourceID, QString targetID, SUI::DialogImpl *apGui);
    void    handleClicked();
};

class testShowGrid
{
private:
    QString mWidgetID;
    SUI::DialogImpl *mpGui;

public:
    testShowGrid(QString aWidgetID, SUI::DialogImpl *apGui);
    void onEnabled(bool checked);
};

#endif // TESTADDTABLEWIDGETROW_H
