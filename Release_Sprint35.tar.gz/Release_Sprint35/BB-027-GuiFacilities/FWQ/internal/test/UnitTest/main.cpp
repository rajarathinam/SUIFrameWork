/*****************************************************************************\
 *
 *  main
 *
 *  This is the main of the adt_unittest.
 *  Because of CentOS we add the '-sync' parameter to the application
 *  parameters.
 *  In this UnitTest project we don't want all tests in one big source file,
 *  but every test should have its own class. That is why we don't use the
 *  QTEST_MAIN macro, but have our own main function. For every test class, we
 *  instantiate it and call QTestLLqExec with the address of those
 *  instantiations. Because the test classes inherite from QObject, we use
 *  the deleteLater*(function, to delete them.
 *  Because we test (sub)classes of QWidget, we have to instantiate
 *  QApplication, though we don't use it.
\*****************************************************************************/

#include <QApplication>

//TODO remove start
#include "ITextUnitTest.h"
//#include "TableWidgetUnitTest.h"
#include "ObjectUnitTest.h"
#include "TreeViewUnitTest.h"
#include "ProgressBarUnitTest.h"
#include "TabWidgetUnitTest.h"
#include "DialogUnitTest.h"
#include "DropDownUnitTest.h"
#include "IToolTipUnitTest.h"
#include "ICheckableUnitTest.h"
//TODO remove end


// Widget unit tests include here
#include "SUILabelUnitTest.h"
#include "SUILineEditUnitTest.h"
#include "SUIButtonUnitTest.h"
#include "SUICheckBoxUnitTest.h"
#include "SUICheckGroupBoxUnitTest.h"
#include "SUICheckMarkUnitTest.h"
#include "SUIColorCrossDropUnitTest.h"
#include "SUIColorDropUnitTest.h"
#include "SUIDoubleSpinBoxUnitTest.h"
#include "SUIDropDownUnitTest.h"
#include "SUITableWidgetUnitTest.h"
#include "SUILEDWidgetUnitTest.h"
#include "SUIIColorableUnitTest.h"
#include "SUIListViewUnitTest.h"
#include "SUIMessageBoxUnitTest.h"
#include "SUIPlotWidgetUnitTest.h"
#include "SUIGroupBoxUnitTest.h"
#include "SUIDialogUnitTest.h"
#include "SUILineWidgetUnitTest.h"
#include "SUIButtonBarUnitTest.h"
#include "SUIStateWidgetUnitTest.h"
#include "SUIBusyIndicatorUnitTest.h"
#include "SUIGraphicsViewUnitTest.h"
#include "SUIFileDialogUnitTest.h"
#include "SUIUILoader.h"
#include "SUIRadioButtonUnitTest.h"
#include "SUITabWidgetUnitTest.h"
#include "SUITabPageUnitTest.h"
#include "SUISpinBoxUnitTest.h"
#include "SUITextAreaUnitTest.h"
#include "SUIProgressBarUnitTest.h"
#include "SUISplitterUnitTest.h"

// GraphicsItem unit tests include here
#include "SUIGraphicsLineItemUnitTest.h"

int main(int argc, char *argv[])
{
    /*
     *  Because we test QWidgets (sub)classes, we have to instantiate a QApplication.
     */
    QApplication a(argc, argv);

    /*
     *  Add tests here.
     */
    QVector<QObject*> tests = {
        // TODO REMOVE OBSELETE TESTS START
        new ITextUnitTest(),
//        new TableWidgetUnitTest(),
        new ObjectUnitTest(),
        new TreeViewUnitTest(),
        new ProgressBarUnitTest(),
        new TabWidgetUnitTest(),
        new DialogUnitTest(),
        new DropDownUnitTest(),
        new BaseObjectToolTipUnitTest(),
        new ICheckableUnitTest(),
        // TODO REMOVE OBSELETE TESTS END

        // NEW TESTS START
        // one UnitTest class for every widget
        new SUI::LabelUnitTest(new SUI::LabelImpl(NULL)),
        new SUI::LineEditUnitTest(new SUI::LineEditImpl(NULL)),
        new SUI::ButtonUnitTest(new SUI::ButtonImpl(NULL)),
        new SUI::CheckBoxUnitTest(new SUI::CheckBoxImpl(NULL)),
        new SUI::CheckGroupBoxUnitTest(new SUI::CheckGroupBoxImpl(NULL)),
        new SUI::CheckMarkUnitTest(new SUI::CheckMarkImpl(NULL)),
        new SUI::ColorCrossDropUnitTest(new SUI::ColorCrossDropImpl(NULL)),
        new SUI::ColorDropUnitTest(new SUI::ColorDropImpl(NULL)),
        new SUI::DoubleSpinBoxUnitTest(new SUI::DoubleSpinBoxImpl(NULL)),
        new SUI::DropDownUnitTest(new SUI::DropDownImpl(NULL)),
        new SUI::GroupBoxUnitTest(new SUI::GroupBoxImpl(NULL)),
        new SUI::LEDWidgetUnitTest(new SUI::LEDWidgetImpl(NULL)),
        new SUI::ListViewUnitTest(new SUI::ListViewImpl(NULL)),
        new SUI::MessageBoxUnitTest(new SUI::MessageBoxImpl(NULL)),
        new SUI::PlotWidgetUnitTest(new SUI::PlotWidgetImpl(NULL)),
        new SUI::TableWidgetUnitTest(new SUI::TableWidgetImpl(NULL)),
        new SUI::DialogUnitTest(SUI::UILoader::loadUI(":/UnitTest.xml")),
        new SUI::LineWidgetUnitTest(new SUI::LineWidgetImpl(NULL)),
        new SUI::ButtonBarUnitTest(new SUI::ButtonBarImpl(NULL)),
        new SUI::StateWidgetUnitTest(new SUI::StateWidgetImpl(NULL)),
        new SUI::BusyIndicatorUnitTest(new SUI::BusyIndicatorImpl(NULL)),
        new SUI::FileDialogUnitTest(new SUI::FileDialogImpl(NULL)),
        new SUI::RadioButtonUnitTest(new SUI::RadioButtonImpl(NULL)),
        new SUI::TabWidgetUnitTest(new SUI::TabWidgetImpl(NULL)),
        new SUI::TabPageUnitTest(new SUI::TabPageImpl(NULL)),
        new SUI::SpinBoxUnitTest(new SUI::SpinBoxImpl(NULL)),
        new SUI::TextAreaUnitTest(new SUI::TextAreaImpl(NULL)),
        new SUI::ProgressBarUnitTest(new SUI::ProgressBarImpl(NULL)),
        new SUI::SplitterUnitTest(new SUI::SplitterImpl(NULL)),
        // etc ...

        new SUI::GraphicsViewUnitTest(new SUI::GraphicsViewImpl(NULL)),
        new SUI::GraphicsLineItemUnitTest(SUI::ObjectFactory::getInstance()->createGraphicsItem<SUI::GraphicsLineItem>(NULL))
        // new SUI::GraphicsCrosshairItemUnitTest ...
        // new SUI::GraphicsTextItemUnitTest ...
        // etc ...
        // NEW TESTS STOP
    };

    /*
     *  Tests run here
     */
    int status = 0;
    foreach (QObject *test, tests) status &= QTest::qExec(test,argc,argv);
    foreach (QObject *test, tests) test->deleteLater();
    tests.clear();

    return status;
}
