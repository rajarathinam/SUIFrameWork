#include "SUILEDWidgetUnitTest.h"
#include "SUILEDWidget.h"
#include <QTest>
#include "SUIIColorableUnitTest.h"

SUI::LEDWidgetUnitTest::LEDWidgetUnitTest(SUI::LEDWidget *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::LEDWidgetUnitTest::~LEDWidgetUnitTest() {
    delete object;
}

void SUI::LEDWidgetUnitTest::callInterfaceTests() {
    //IColorable test
    //valid colors
    IColorableUnitTest iColorableUnitTest(object);
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Red));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Green));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Blue));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Gray));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Yellow));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::White));
    //test invalid colors

}
