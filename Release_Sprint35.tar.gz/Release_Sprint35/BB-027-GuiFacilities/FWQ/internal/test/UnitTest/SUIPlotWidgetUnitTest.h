#ifndef SUIPLOTWIDGETUNITTEST_H
#define SUIPLOTWIDGETUNITTEST_H

#include "SUIWidgetUnitTest.h"


namespace SUI {

class PlotWidget;

class PlotWidgetUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
     PlotWidgetUnitTest(PlotWidget *object, QObject *parent = 0);
    ~PlotWidgetUnitTest();

protected:
    void callInterfaceTests();

private slots:

private:
    PlotWidget *object;
};

}

#endif // SUIPLOTWIDGETUNITTEST_H
