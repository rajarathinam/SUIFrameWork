#ifndef SUIBUTTONUNITTEST_H
#define SUIBUTTONUNITTEST_H

#include "SUIWidgetUnitTest.h"

namespace SUI {

class Button;

class ButtonUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
     ButtonUnitTest(Button *object, QObject *parent = 0);
    ~ButtonUnitTest();

protected:
    void callInterfaceTests();

private slots:

private:
    Button *object;
};

}
#endif // SUIBUTTONUNITTEST_H
