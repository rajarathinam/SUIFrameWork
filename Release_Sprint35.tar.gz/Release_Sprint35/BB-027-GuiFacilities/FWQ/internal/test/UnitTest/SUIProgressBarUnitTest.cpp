#include "SUIProgressBarUnitTest.h"

SUI::ProgressBarUnitTest::ProgressBarUnitTest(SUI::ProgressBar *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::ProgressBarUnitTest::~ProgressBarUnitTest() {
    delete object;
}
