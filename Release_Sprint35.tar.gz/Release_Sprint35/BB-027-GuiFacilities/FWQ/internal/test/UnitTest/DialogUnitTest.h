#ifndef DIALOGUNITTEST_H
#define DIALOGUNITTEST_H

#include <QObject>

namespace SUI {
class Dialog;
}

class DialogUnitTest : public QObject
{
    Q_OBJECT

public:
    DialogUnitTest();

private Q_SLOTS:
    void    cleanupTestCase();

/// Unit testen
    // Change the Window Name
    void    testchangeWindowNameCase1();
    void    testchangeWindowNameCase1_data();

/// Interface Unit Testen
    void    testchangeWindowNameCase2();
    void    testchangeWindowNameCase2_data();
private:
    SUI::Dialog *mGui;
};

#endif // DIALOGUNITTEST_H
