//#include "TableWidgetUnitTest.h"

//TableWidgetUnitTest::TableWidgetUnitTest() :
//    mTableWidg(new SUI::TableWidgetImpl(NULL)),
//    mITableWidg(dynamic_cast<SUI::TableWidget *>(mTableWidg))
//{
//    mTableWidg->setId("twiTableWidget");
//    mTableWidg->initialize(SUI::BaseObject::Gui);
//}

//void TableWidgetUnitTest::initTestCase() {
//}

//void TableWidgetUnitTest::cleanupTestCase()
//{
//    if (mTableWidg)
//    {
//        delete mTableWidg;
//    }
//}

//void TableWidgetUnitTest::testTableWidget()
//{
//    QFETCH(int, ActionCode);
//    QFETCH(int, CompareValue);
//    QFETCH(int, Number);
//    QFETCH(QStringList, ItemID);

//    switch (ActionCode)
//    {
//    case 0:     //  Do nothing
//        QCOMPARE(mTableWidg->rowCount(), CompareValue);
//        QCOMPARE(mTableWidg->columnCount(), Number);
//        break;
//    case 1:     //  Add row
//        mTableWidg->addRow();
//        QCOMPARE(mTableWidg->rowCount(), CompareValue);
//        break;
//    case 2:     // Remove row
//        mTableWidg->removeRow(Number);
//        QCOMPARE(mTableWidg->rowCount(), CompareValue);
//        break;
//    case 3:     // Rename TableWidget Items
//        QStringList idList;
//        mTableWidg->renameItems();
//        std::list<std::string> itemList = mTableWidg->getItems();

//        std::list<std::string>::iterator cit;
//        for (cit = itemList.begin(); cit != itemList.end(); ++cit)
//        {
//            idList.append(QString::fromStdString(*cit));
//        }

//        QCOMPARE(idList, ItemID);
//        break;
//    }
//}

//void TableWidgetUnitTest::testTableWidget_data()
//{
//    // Insert 2 rows and 4 columns
//    mTableWidg->removeRows(0,mTableWidg->rowCount());
//    QVERIFY(mTableWidg->rowCount() == 0);
//    mTableWidg->insertRows(0, 2);
//    QVERIFY(mTableWidg->rowCount() == 2);
//    mTableWidg->insertColumns(1, 3);
//    QVERIFY(mTableWidg->columnCount() == 4);

//    QTest::addColumn<int>("ActionCode");
//    QTest::addColumn<int>("CompareValue");
//    QTest::addColumn<int>("Number");
//    QTest::addColumn<QStringList>("ItemID");

//    QTest::newRow("Do nothing") << int(0) << int(2) << int(4) << QStringList(QStringList());
//    QTest::newRow("Add row") << int(1) << int(3) << int(0) << QStringList(QStringList());
//    QTest::newRow("Remove row") << int(2) << int(2) << int(1) << QStringList();
//    QTest::newRow("Rename items") << int(3) << int(0) << int(0)
//                                    << QStringList(QString("twi-twiTableWidget:1-1;twi-twiTableWidget:1-2;twi-twiTableWidget:1-3;twi-twiTableWidget:1-4;twi-twiTableWidget:2-1;twi-twiTableWidget:2-2;twi-twiTableWidget:2-3;twi-twiTableWidget:2-4").split(";"));
//}

//void TableWidgetUnitTest::testSelectItemCase1()
//{
//    QFETCH(QString, itemName);
//    QFETCH(int, row);
//    QFETCH(int, col);

//    mTableWidg->selectItem(row, col);
//    QStringList itemList;
//    foreach(std::string item, mTableWidg->getSelectedItems())
//    {
//        itemList.append(QString::fromStdString(item));
//    }

//    QCOMPARE(itemList.join(";"), itemName);
//}

//void TableWidgetUnitTest::testSelectItemCase1_data()
//{
//    QTest::addColumn<QString>("itemName");
//    QTest::addColumn<int>("row");
//    QTest::addColumn<int>("col");
//    QTest::newRow("Pass Remove from item") << QString("twi-twiTableWidget:1-1") << int(0) << int(0);
//}

//void TableWidgetUnitTest::testRowCount()
//{
//    QFETCH(int, RowCount);
//    QCOMPARE(mITableWidg->rowCount(), RowCount);
//}

//void TableWidgetUnitTest::testRowCount_data()
//{
//    mITableWidg = dynamic_cast<SUI::TableWidget *>(mTableWidg);
//    QTest::addColumn<int>("RowCount");
//    QTest::newRow("Row count result") << int(2);
//}

//void TableWidgetUnitTest::testColumnCount()
//{
//    QFETCH(int, ColumnCount);
//    QCOMPARE(mITableWidg->columnCount(), ColumnCount);
//}

//void TableWidgetUnitTest::testColumnCount_data()
//{
//    QTest::addColumn<int>("ColumnCount");
//    QTest::newRow("Column count result") << int(4);
//}

//void TableWidgetUnitTest::testCellID()
//{
//    QFETCH(int, RowNr);
//    QFETCH(int, ColumnNr);
//    QFETCH(QString, CellID);
//    QCOMPARE(QString::fromStdString(mITableWidg->getCellID(RowNr, ColumnNr)), CellID);
//}

//void TableWidgetUnitTest::testCellID_data()
//{
//    QTest::addColumn<int>("RowNr");
//    QTest::addColumn<int>("ColumnNr");
//    QTest::addColumn<QString>("CellID");
//    QTest::newRow("ID") << int(1) << int(1) << QString("twi-twiTableWidget:1-1");
//}

//void TableWidgetUnitTest::testCellType()
//{
//    QFETCH(int, RowNr);
//    QFETCH(int, ColumnNr);
//    QFETCH(int, CellType);
//    QCOMPARE(mITableWidg->getCellType(RowNr, ColumnNr), (SUI::ObjectType::Type)CellType);
//}

//void TableWidgetUnitTest::testCellType_data()
//{
//    QTest::addColumn<int>("RowNr");
//    QTest::addColumn<int>("ColumnNr");
//    QTest::addColumn<QString>("CellType");
//    QTest::newRow("Type") << int (1) << int(1) << QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::TableWidgetItem));
//}

//void TableWidgetUnitTest::testItemData()
//{
//    QFETCH(QStringList, DataList);
//    std::list<std::string>  strlst = mITableWidg->getItems();
//    QStringList             qtStrLst;
//    for (int rowind = 0; rowind < 2; ++rowind)
//    {
//        for (int colind = 0; colind < 4; ++colind)
//        {
//            qtStrLst.append(mTableWidg->itemText(rowind, colind));
//        }

//    }
//    QCOMPARE(DataList, qtStrLst);
//}

//void TableWidgetUnitTest::testItemData_data()
//{
//    mTableWidg->setItemText(0, 0, "Cell 1-1");
//    mTableWidg->setItemText(0, 1, "Cell 1-2");
//    mTableWidg->setItemText(0, 2, "Cell 1-3");
//    mTableWidg->setItemText(0, 3, "Cell 1-4");
//    mTableWidg->setItemText(1, 0, "Cell 2-1");
//    mTableWidg->setItemText(1, 1, "Cell 2-2");
//    mTableWidg->setItemText(1, 2, "Cell 2-3");
//    mTableWidg->setItemText(1, 3, "Cell 2-4");

//    QTest::addColumn<QStringList>("DataList");
//    QStringList dataList;
//    dataList << QString("Cell 1-1") << QString("Cell 1-2") << QString("Cell 1-3") << QString("Cell 1-4")
//             << QString("Cell 2-1") << QString("Cell 2-2") << QString("Cell 2-3") << QString("Cell 2-4");
//    QTest::newRow("Data") << dataList;
//}
