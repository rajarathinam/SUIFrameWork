#ifndef SUIFILEDIALOGUNITTEST_H
#define SUIFILEDIALOGUNITTEST_H

#include "SUIWidgetUnitTest.h"
#include "SUIFileDialog.h"

namespace SUI {

class FileDialog;

class FileDialogUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
     FileDialogUnitTest(SUI::FileDialog *object, QObject *parent = 0);
    virtual ~FileDialogUnitTest();

private:
    FileDialog *object;
};

}
#endif // SUIFILEDIALOGUNITTEST_H
