#include "SUIPlotWidgetUnitTest.h"
#include "SUIPlotWidget.h"
#include <QTest>
#include "SUIITextUnitTest.h"

SUI::PlotWidgetUnitTest::PlotWidgetUnitTest(SUI::PlotWidget *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::PlotWidgetUnitTest::~PlotWidgetUnitTest() {
    delete object;
}

void SUI::PlotWidgetUnitTest::callInterfaceTests() {
    // IText UnitTests
    ITextUnitTest iTextUnitTest(object);
    QVERIFY(iTextUnitTest.setText());
    QVERIFY(iTextUnitTest.clearText());
    QVERIFY(iTextUnitTest.setBold());

    //TO DO IClickable tests
}


