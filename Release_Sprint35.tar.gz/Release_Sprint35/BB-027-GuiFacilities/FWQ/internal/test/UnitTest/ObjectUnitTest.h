#ifndef OBJECTUNITTEST_H
#define OBJECTUNITTEST_H

#include <QTest>
#include <QString>
#include <QCheckBox>

#include <SUIBaseWidget.h>
#include <SUIObjectList.h>
#include <SUITableWidgetImpl.h>
#include <SUITreeViewImpl.h>
#include <SUIButtonImpl.h>
#include <SUIBusyIndicatorImpl.h>
#include <SUICheckBoxImpl.h>
#include <SUICheckGroupBoxImpl.h>
#include <SUICheckMarkImpl.h>
#include <SUIColorCrossDropImpl.h>
#include <SUIColorDropImpl.h>
#include <SUIControlWidgetImpl.h>
#include <SUIDoubleSpinBoxImpl.h>
#include <SUIFileDialogImpl.h>
#include <SUIGroupBoxImpl.h>
#include <SUIGraphicsView.h>
#include <SUILabelImpl.h>
#include <SUILEDWidgetImpl.h>
#include <SUIListViewImpl.h>
#include <SUIMessageBoxImpl.h>
#include <SUIPlotWidgetImpl.h>
#include <SUIProgressBarImpl.h>
#include <SUIQuestionMarkImpl.h>
#include <SUIRadioButtonImpl.h>
#include <SUIScienceSpinBoxImpl.h>
#include <SUISpinBoxImpl.h>
#include <SUIStateWidgetImpl.h>
#include <SUITextAreaImpl.h>
#include <SUIUserControlImpl.h>
#include <SUILineEditImpl.h>
#include <SUITableWidgetItemImpl.h>
#include <SUISplitterImpl.h>

#include <SUILineWidgetImpl.h>
#include <SUIButtonBarImpl.h>
#include <SUIFileDialogImpl.h>
#include <SUIGraphicsViewImpl.h>
#include <SUIGraphicsLineItem.h>
#include <SUIGraphicsEllipseItem.h>
#include <SUIGraphicsPixmapItem.h>
#include <SUIGraphicsRectItem.h>
#include <SUIGraphicsTextItem.h>
#include <SUIGraphicsCrosshairItem.h>

class ObjectUnitTest : public QObject
{
    Q_OBJECT
public:
    ObjectUnitTest();

private Q_SLOTS:
    void cleanupTestCase();

    void testVisibilityCase1();
    void testVisibilityCase1_data();

    void testVisibilityCase2();
    void testVisibilityCase2_data();

    void testEnabledCase1();
    void testEnabledCase1_data();

    void testEnabledCase2();
    void testEnabledCase2_data();

private:
    SUI::BusyIndicator *busyindicator;
    SUI::Button *button;
    SUI::CheckBox *checkbox;
    SUI::CheckGroupBox *checkboxgroup;
    SUI::CheckMark *checkmark;
    SUI::ColorCrossDrop *colorcrossdrop;
    SUI::ColorDrop *colordrop;
    SUI::ControlWidget *controlwidget;
    SUI::DoubleSpinBox *dblspinbox;
    SUI::FileDialog *filebrowser;
    SUI::GroupBox *groupbox;
    SUI::GraphicsView *graphicsView;
    SUI::Label *label;
    SUI::LEDWidget *led;
    SUI::LineEdit *lineedit;
    SUI::ListView *listview;
    SUI::MessageBox *messagebox;
    SUI::PlotWidget *plotwidget;
    SUI::ProgressBar *progressbar;
    SUI::QuestionMark *questionmark;
    SUI::RadioButton *radiobutton;
    SUI::ScienceSpinBox *sciencespinbox;
    SUI::SpinBox *spinbox;
    SUI::StateWidget *statewidget;
    SUI::TableWidget *tablewidget;
    SUI::TableWidgetItem *tablewidgetitem;
    SUI::TextArea *textarea;
    SUI::TreeViewItem *treeitem;
    SUI::UserControl *usercontrol;

    SUI::GraphicsCrosshairItem *graphicscrosshair;
    SUI::GraphicsEllipseItem *graphicsellipse;
    SUI::GraphicsLineItem *graphicsline;
    SUI::GraphicsPixmapItem *graphicspixmap;
    SUI::GraphicsRectItem *graphicsrect;
    SUI::GraphicsTextItem *graphicstext;

    SUI::Widget *ibusyindicator;
    SUI::Widget *ibutton;
    SUI::Widget *icheckbox;
    SUI::Widget *icheckboxgroup;
    SUI::Widget *icheckmark;
    SUI::Widget *icolorcrossDrop;
    SUI::Widget *icolorDrop;
    SUI::Widget *icontrolwidget;
    SUI::Widget *idblspinbox;
    SUI::Widget *ifilebrowser;
    SUI::Widget *igroupbox;
    SUI::Widget *igraphicsView;
    SUI::Widget *ilabel;
    SUI::Widget *iled;
    SUI::Widget *ilineedit;
    SUI::Widget *ilistview;
    SUI::Widget *imessagebox;
    SUI::Widget *iplotwidget;
    SUI::Widget *iprogressbar;
    SUI::Widget *iquestionmark;
    SUI::Widget *iradiobutton;
    SUI::Widget *isciencespinbox;
    SUI::Widget *ispinbox;
    SUI::Widget *istatewidget;
    SUI::Widget *itablewidget;
    SUI::Widget *itablewidgetitem;
    SUI::Widget *itextarea;
    SUI::Widget *itreeitem;
    SUI::Widget *iusercontrol;

    SUI::GraphicsItem *igraphicscrosshair;
    SUI::GraphicsItem *igraphicsellipse;
    SUI::GraphicsItem *igraphicsline;
    SUI::GraphicsItem *igraphicspixmap;
    SUI::GraphicsItem *igraphicsrect;
    SUI::GraphicsItem *igraphicstext;
};

#endif // OBJECTUNITTEST_H
