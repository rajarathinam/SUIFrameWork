#ifndef SUILEDWIDGETUNITTEST_H
#define SUILEDWIDGETUNITTEST_H

#include "SUIWidgetUnitTest.h"


namespace SUI {

class LEDWidget;

class LEDWidgetUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
     LEDWidgetUnitTest(LEDWidget *object, QObject *parent = 0);
    ~LEDWidgetUnitTest();

protected:
    void callInterfaceTests();

private slots:

private:
     LEDWidget *object;
     bool setColorForLEDWidget();
};

}

#endif // SUILEDWIDGETUNITTEST_H
