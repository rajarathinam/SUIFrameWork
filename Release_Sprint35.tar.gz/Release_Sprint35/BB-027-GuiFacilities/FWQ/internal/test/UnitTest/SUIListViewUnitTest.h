#ifndef SUILISTVIEWUNITTEST_H
#define SUILISTVIEWUNITTEST_H

#include "SUIWidgetUnitTest.h"


namespace SUI {

class ListView;

class ListViewUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
     ListViewUnitTest(ListView *object, QObject *parent = 0);
    ~ListViewUnitTest();

protected:
    void callInterfaceTests();

private slots:

private:
    ListView *object;
};

}
#endif // SUILISTVIEWUNITTEST_H
