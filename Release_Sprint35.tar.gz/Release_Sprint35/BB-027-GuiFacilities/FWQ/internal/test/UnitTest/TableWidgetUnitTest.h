//#ifndef TABLEWIDGETUNITTEST_H2
//#define TABLEWIDGETUNITTEST_H2

//#include <QTest>
//#include <QString>
//#include <QStringList>

//#include <SUIObjectList.h>
//#include <SUIBaseWidget.h>
//#include <SUITableWidgetImpl.h>

//class TableWidgetUnitTest : public QObject
//{
//    Q_OBJECT

//public:
//    TableWidgetUnitTest();

//private:
//    SUI::TableWidgetImpl *mTableWidg;
//    SUI::TableWidget *mITableWidg;

//private Q_SLOTS:
//    void initTestCase();
//    void cleanupTestCase();
//    void testTableWidget();
//    void testTableWidget_data();

//    // selectItem
//    void testSelectItemCase1();
//    void testSelectItemCase1_data();

//    void testRowCount();
//    void testRowCount_data();

//    void testColumnCount();
//    void testColumnCount_data();

//    void testCellID();
//    void testCellID_data();

//    void testCellType();
//    void testCellType_data();

//    void testItemData();
//    void testItemData_data();
//};

//#endif // TABLEWIDGETUNITTEST_H
