#ifndef ICHECKABLEUNITTEST_H
#define ICHECKABLEUNITTEST_H

#include <QTest>

class ICheckableUnitTest : public QObject
{
    Q_OBJECT

public:
    ICheckableUnitTest();

private Q_SLOTS:
    void    cleanupTestCase();

    void    testCheckboxCase();
    void    testRadioButtonCase();
    void    testCheckGroupBoxCase();
};

#endif // ICHECKABLEUNITTEST_H
