/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SplashScreen.cpp
| Author       :
| Description  : Class implementation file for SplashScreen.
|
| ! \file        SplashScreen.cpp
| ! \brief       Class implementation file for SplashScreen.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SplashScreen.h"

#include <QPixmap>

#include "Model.h"

SplashScreen::SplashScreen() :
    QSplashScreen(),
    mWidgetCount(0),
    mLayout(new QVBoxLayout()),
    mProgress(new QProgressBar()),
    mTextLabel(new QLabel())
{
    this->setWindowFlags(Qt::WindowStaysOnTopHint | Qt::SplashScreen);
    connect(Model::instance(), SIGNAL(widgetProcessed()), this, SLOT(onWidgetProcessed()));
    connect(Model::instance(), SIGNAL(newMessage(QString)), this, SLOT(onNewMessage(QString)));
    connect(Model::instance(), SIGNAL(setWidgetCount(int)), this, SLOT(onSetWidgetCount(int)));

    QPixmap *pixmap = new QPixmap(":/image/asml_logo.png");
    QLabel *pixLabel = new QLabel();
    pixLabel->setPixmap(*pixmap);
    mProgress->setMinimum(0);
    mLayout->addWidget(pixLabel);
    mLayout->addStretch();
    mLayout->addWidget(mTextLabel);
    setLayout(mLayout);
    this->setWindowFlags(Qt::SplashScreen | Qt::WindowStaysOnTopHint | Qt::X11BypassWindowManagerHint);
}

SplashScreen::~SplashScreen()
{
    disconnect(Model::instance(), SIGNAL(widgetProcessed()), this, SLOT(onWidgetProcessed()));
    disconnect(Model::instance(), SIGNAL(newMessage(QString)), this, SLOT(onNewMessage(QString)));
    disconnect(Model::instance(), SIGNAL(setWidgetCount(int)), this, SLOT(onSetWidgetCount(int)));
    mProgress->deleteLater();
    mTextLabel->deleteLater();
    mLayout->deleteLater();
}

void SplashScreen::onWidgetProcessed()
{
    this->activateWindow();
    this->raise();
    ++mWidgetCount;
    mProgress->setValue(mWidgetCount);
}

void SplashScreen::onNewMessage(QString msg) {
    mTextLabel->setText(msg);
}

void SplashScreen::onSetWidgetCount(int count)
{
    mProgress->setMaximum(count);
    mLayout->addWidget(mProgress);
}
