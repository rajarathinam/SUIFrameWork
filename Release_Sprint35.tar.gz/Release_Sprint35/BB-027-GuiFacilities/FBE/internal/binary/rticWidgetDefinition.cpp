/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : rticWidgetDefinition.cpp
| Author       :
| Description  : Class implementation file for WidgetDefinition.
|
| ! \file        rticWidgetDefinition.cpp
| ! \brief       Class implementation file for WidgetDefinition.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "rticWidgetDefinition.h"

#include <QApplication>

#include <SUIStyleSheet.h>
#include <SUITabWidgetImpl.h>
#include <SUITabPageImpl.h>
#include <SUISplitterImpl.h>
#include <SUITreeViewImpl.h>
#include <SUITableWidgetImpl.h>

#include "Model.h"


WidgetDefinition::WidgetDefinition() :
    mIsSelected(false)
{
    setPropertyValue(SUI::ObjectPropertyTypeEnum::UserControl, "");
}

WidgetDefinition::~WidgetDefinition()
{
    foreach(WidgetDefinition *defChild, mChildren) delete defChild;
}

void WidgetDefinition::writeInclude(const QString &include, const QString &fileName) {
    setInclude(include,fileName);
}

void WidgetDefinition::writeWidgetProperty(SUI::ObjectPropertyTypeEnum::Type key, const QString &value) {
    setPropertyValue(key, value);
}

GUIDefinitionVisitor &WidgetDefinition::openChildWidget() {
    WidgetDefinition *childWidget = new WidgetDefinition();

    mChildren.append(childWidget);

    return *childWidget;
}

void WidgetDefinition::closeChildWidget() {

}

void WidgetDefinition::reset() {
    foreach(WidgetDefinition * defChild, mChildren)
        delete defChild;

    mChildren.clear();
    mIsSelected = false;
}

WidgetController *WidgetDefinition::addToWidget(QWidget *parent, bool isNew) {
    int currentTabPageIndex = 0;
    SUI::ObjectType::Type widgetType = SUI::ObjectType::fromString(getPropertyValue(SUI::ObjectPropertyTypeEnum::ObjectType).toStdString());
    SUI::BaseWidget  *widget = SUI::ObjectFactory::getInstance()->createWidget(widgetType);

    Model::instance()->callWidgetProcessed();
    if ( widget == NULL ) return NULL;

    widget->initialize(SUI::BaseWidget::EditorForm);

    foreach(SUI::ObjectPropertyTypeEnum::Type propertyID,  getPropertyTypes()) {
        if (propertyID == SUI::ObjectPropertyTypeEnum::DefaultState) {
            //In the Editor DefaultState is a dropdown, so we need  mValues initialisation
            //Note: StateList and ImageList need to be initialised before DefaultState
            widget->setPropertyValue(SUI::ObjectPropertyTypeEnum::StateList, getPropertyValue(SUI::ObjectPropertyTypeEnum::StateList));
            widget->setPropertyValue(SUI::ObjectPropertyTypeEnum::ImageList, getPropertyValue(SUI::ObjectPropertyTypeEnum::ImageList));
            QString lst = QString("%1;%2").arg(getPropertyValue(SUI::ObjectPropertyTypeEnum::StateList)).arg(getPropertyValue(SUI::ObjectPropertyTypeEnum::ImageList));
            widget->setPropertyValues(propertyID, lst);
        }
        if ((propertyID == SUI::ObjectPropertyTypeEnum::CellAlignment) ||
                        (propertyID == SUI::ObjectPropertyTypeEnum::CellName)) {
            //add property
            widget->addCellProperties();
        }
        widget->setPropertyValue(propertyID, getPropertyValue(propertyID));
    }

    if (widgetType == SUI::ObjectType::TabWidget) {
        currentTabPageIndex = widget->getPropertyValue(SUI::ObjectPropertyTypeEnum::CurrentTabPage).toInt();
    }

    //  Children of UserControls should not get a new ID
    if (isNew && (getPropertyValue(SUI::ObjectPropertyTypeEnum::UserControl).isEmpty() || (widgetType == SUI::ObjectType::UserControl))) {
        widget->setId(Model::instance()->createNewId(QString::fromStdString(SUI::ObjectType::getIdPrefix(widget->getObjectType()))).toStdString());
    }

    WidgetController *pDragAndDropWidget = new WidgetController(parent, widget->childrenSupported() ? WidgetController::ParentWidgetMode : WidgetController::SingleWidgetMode, widget);

    int x = getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt();
    int y = getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt();
    int width = getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt();
    int height = getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt();

    pDragAndDropWidget->move(x, y);
    pDragAndDropWidget->setGeometry(x,y,width,height);

    Model::instance()->addWidget(pDragAndDropWidget);
    pDragAndDropWidget->show();

    WidgetController *parentWidget = dynamic_cast<WidgetController *>(parent);
    parentWidget->addChild(pDragAndDropWidget);

    if (parentWidget->getObjectType() == SUI::ObjectType::UserControl) {
        pDragAndDropWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::UserControl, parentWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::ID));
    }

    else if (pDragAndDropWidget->getObjectType() != SUI::ObjectType::UserControl) {
        if ( parentWidget->getBaseWidget() != NULL ) {   //  Propagate the UserControl property from the parent to this child
            pDragAndDropWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::UserControl, parentWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::UserControl));
        }
        else {
            pDragAndDropWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::UserControl, "");
        }

    }
    else if ( mChildren.size() == 0 ){
        //  This is a UserControl. Retrieve its children from the UserControl definition in Model's UserControl list.
        QString uctrlID = getPropertyValue(SUI::ObjectPropertyTypeEnum::UserControl);
        WidgetController *wcUCtrl = Model::instance()->retrieveFromStore(uctrlID);
        if ( wcUCtrl != NULL ) {
            foreach(WidgetController *wcChild, wcUCtrl->childList()) {
                WidgetDefinition newDefinition;
                wcChild->acceptVisitor(newDefinition);
                newDefinition.addToWidget(pDragAndDropWidget, isNew);
            }
            pDragAndDropWidget->renameChildren(pDragAndDropWidget->getId());
            Model::instance()->addUsedUserControl(pDragAndDropWidget->getId());
        }
        if (parentWidget->getObjectType() == SUI::ObjectType::TableWidget){
            if (isNew) Model::instance()->getModelHandler()->sendNewWidget();
            return pDragAndDropWidget;
        }
    }

    foreach(WidgetDefinition * childWidget, mChildren) {
        WidgetController *child = childWidget->addToWidget(pDragAndDropWidget, isNew);

        switch (pDragAndDropWidget->getObjectType()) {
        case SUI::ObjectType::TabWidget:
        {
            if(child->getObjectType() == SUI::ObjectType::TabPage) {
                QString tabName = child->getPropertyValue(SUI::ObjectPropertyTypeEnum::Text);
                SUI::TabPageImpl *tabPage = dynamic_cast<SUI::TabPageImpl *>(child->getBaseWidget());
                tabPage->setTabText(tabName.toStdString());
                dynamic_cast<SUI::TabWidgetImpl *>(pDragAndDropWidget->getBaseWidget())->addNewTab(tabPage);
            }
            break;
        }

        case SUI::ObjectType::TableWidget:
        {
            SUI::TableWidgetImpl *table = dynamic_cast<SUI::TableWidgetImpl *>(pDragAndDropWidget->getBaseWidget());
            if (table->startReading(
                    getPropertyValue(SUI::ObjectPropertyTypeEnum::RowCount).toInt(),
                    getPropertyValue(SUI::ObjectPropertyTypeEnum::ColumnCount).toInt()))
            {
                if (child->getObjectType() != SUI::ObjectType::TableWidgetItem) child->setVisible(false);

                table->addNewTableWidgetItem(dynamic_cast<SUI::Widget *>(child->getBaseWidget()));
            }
            break;
        }
        case SUI::ObjectType::TreeView:
        {
            child->setVisible(false);
            QString parentID = dynamic_cast<SUI::TreeViewImpl *>(pDragAndDropWidget->getBaseWidget())->
                               addNewTreeItem(dynamic_cast<SUI::TreeViewItemImpl *>(child->getBaseWidget()));
            foreach(WidgetDefinition * pChild, childWidget->mChildren)
                addTreeChild(pChild, pDragAndDropWidget, parentID);

            break;
        }
        case SUI::ObjectType::Splitter:
            dynamic_cast<SUI::SplitterImpl *>(pDragAndDropWidget->getBaseWidget())->addSplitterWidget(child->getBaseWidget());
            break;

        default:
            break;
        }
    }
    QApplication::processEvents();

    switch (widgetType) {
    case SUI::ObjectType::TabWidget:
    {
        SUI::TabWidgetImpl *tabWidget = dynamic_cast<SUI::TabWidgetImpl *>(pDragAndDropWidget->getBaseWidget());
        if ( tabWidget->getCurrentTabPage() != NULL ) {
            pDragAndDropWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::CurrentTabPage, QString::number(currentTabPageIndex));
            tabWidget->setCurrentTabPage(currentTabPageIndex);
            Model::instance()->selectNewWidget(QString::fromStdString(tabWidget->getCurrentTabPage()->getId()));
            Model::instance()->setNewSelected(Model::instance()->getWidgetController(QString::fromStdString(tabWidget->getCurrentTabPage()->getId())));
        }
        break;
    }
    case SUI::ObjectType::TableWidget:
        dynamic_cast<SUI::TableWidgetImpl *>(pDragAndDropWidget->getBaseWidget())->stopReading();
        pDragAndDropWidget->setChildrenPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable, "false");
        pDragAndDropWidget->setChildrenPropertyValue(SUI::ObjectPropertyTypeEnum::Sizeable, "false");
        pDragAndDropWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable, "true");
        pDragAndDropWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::Sizeable, "true");
        pDragAndDropWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::ColumnWidths, getPropertyValue(SUI::ObjectPropertyTypeEnum::ColumnWidths));
        break;
    case SUI::ObjectType::TabPage:
        pDragAndDropWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable, "false");
        pDragAndDropWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::Sizeable, "false");
        break;
    default:
        break;
    }

    if (isNew) Model::instance()->getModelHandler()->sendNewWidget();

    return pDragAndDropWidget;
}

void WidgetDefinition::setSelected(bool selected) {
    mIsSelected = selected;
}

bool WidgetDefinition::isSelected() const {
    return mIsSelected;
}

void WidgetDefinition::addTreeChild(WidgetDefinition *childWidget, WidgetController *pDragAndDropWidget, QString parentID) {
    WidgetController *child = Model::instance()->getWidgetController(childWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::ID));
    SUI::TreeViewImpl *treeView = dynamic_cast<SUI::TreeViewImpl *>(pDragAndDropWidget->getBaseWidget());
    QString childID = treeView->addNewTreeItemToItem(dynamic_cast<SUI::TreeViewItemImpl *>(child->getBaseWidget()),parentID);

    foreach(WidgetDefinition * pChild, childWidget->mChildren) addTreeChild(pChild, pDragAndDropWidget, childID);
}
