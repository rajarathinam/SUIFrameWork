/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : usercontroldialog.cpp
| Author       :
| Description  : Class implementation file for UserControlDialog.
|
| ! \file        usercontroldialog.cpp
| ! \brief       Class implementation file for UserControlDialog.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "usercontroldialog.h"
#include "ui_usercontroldialog.h"

UserControlDialog::UserControlDialog(const QString &instanceID, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::UserControlDialog)
{
    ui->setupUi(this);
    ui->mUsrCtrlIdLE->setText(instanceID);
    ui->mInstanceGB->setChecked(true);
    connect(ui->mOkPB, SIGNAL(clicked()), this, SLOT(accept()));
    connect(ui->mCancelPB, SIGNAL(clicked()), this, SLOT(reject()));
}

UserControlDialog::~UserControlDialog()
{
    delete ui;
}

QString UserControlDialog::getUserCtrlName() const
{
    return ui->mUserCtrlNameLE->text();
}

QString UserControlDialog::getId() const
{
    return ui->mUsrCtrlIdLE->text();
}

bool UserControlDialog::idChecked() const
{
    return ui->mInstanceGB->isChecked();
}


