/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUISourceCodeGenerator.cpp
| Author       :
| Description  : Class implementation file for SUI::SourceCodeGenerator.
|
| ! \file        SUISourceCodeGenerator.cpp
| ! \brief       Class implementation file for SUI::SourceCodeGenerator.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUISourceCodeGenerator.h"

#include <SUIDialog.h>
#include <SUIObjectList.h>
#include <SUIObject.h>

#include <QStringList>
#include <QFile>
#include <QTextStream>
#include <QSet>
#include <QFileInfo>
#include <QDebug>
#include <QDateTime>
#include <QApplication>
#include <QMessageBox>

//TODO remove includes if possible
#include "formeditor.h"
#include "Model.h"

#include <assert.h>

void SUI::SourceCodeGenerator::dialogToSource(const QString &fileName, SUI::Dialog *dialog) {

    QFileInfo fileInfo(fileName);
    QString className = fileInfo.fileName().remove(".xml");
    className = className.replace(":", "_").replace("-", "_").replace(".", "_");

    //TODO check if className is valid
    SUI::ObjectList *list;
    std::vector<Object *> objects;
    if ( dialog != NULL ){
        list = dialog->getObjectList();
        objects = list->getObjectList();
    }

    QStringList objectStringList;

    for(size_t n = 0; n < objects.size(); n++) {
        Object *object = objects.at(n);

        if ( !(QString::fromStdString(object->getId()).contains(":")) &&
           !( object->getObjectType() == SUI::ObjectType::TableWidgetItem || object->getObjectType() == SUI::ObjectType::TreeViewItem )){

            QString objectDefinition("%1 *%2");
            objectStringList.append(objectDefinition.arg(QString::fromStdString(SUI::ObjectType::toString(object->getObjectType()))).arg(QString::fromStdString(object->getId())));
        }

    }

    QFile mocHeader(fileInfo.absolutePath().append("/moc_%1.h").arg(className));
    QFile mocSource(fileInfo.absolutePath().append("/moc_%1.cpp").arg(className));
    QFile header(fileInfo.absolutePath().append("/%1.h").arg(className));
    QFile source(fileInfo.absolutePath().append("/%1.cpp").arg(className));
    QFile python(fileInfo.absolutePath().append("/%1_constants.py").arg(className));

    writeMocHeader(&mocHeader,className,objectStringList);
    writeMocSource(&mocSource,className,objectStringList);
    writeHeader(&header,className);
    writeSource(&source,fileName);
    writePythonFile(&python,className);
}

void SUI::SourceCodeGenerator::writeMocHeader(QFile *file, const QString &className, const QStringList &objectStringList) {
    file->open(QIODevice::WriteOnly | QIODevice::Text);
    if (!isFileOpen(file)) return;

    QTextStream stream(file);

    QSet<QString> uniqueObjectList;
    foreach (const QString &objectDefinition, objectStringList)
        uniqueObjectList.insert(objectDefinition.split(" ").at(0));

    stream
            << "#ifndef SUI_MOC_" << className.toUpper() << "_H" << endl
            << "#define SUI_MOC_" << className.toUpper() << "_H" << endl;

    stream
            << endl
            << "/*!" << endl
            << " * This is an automatically generated file. DO NOT MODIFY!" << endl
            << " *" << endl
            << " * Generation date : " + QDateTime::currentDateTime().toString("dd-MM-yyyy, hh:mm") << endl
            << " *" << endl
            << " * " << generatorString() << qApp->applicationName() << " (version " << Model::instance()->getFormEditor()->getPropertyValue(SUI::ObjectPropertyTypeEnum::SUIVersion) << ")" << endl
            << " *" << endl
            << " */" << endl;

    stream
            << endl
            << "class " << className << ";" << endl << endl
            << "namespace SUI {" << endl
            << "class Dialog;" << endl
            << "class ObjectList;" << endl
            << "class Container;" << endl;

    foreach (const QString &objectDefinition, uniqueObjectList)
        stream << "class " << objectDefinition << ";" << endl; // forward declarations

    stream
            << "class " << className << endl
            << "{" << endl
            << "private:" << endl
            << "    " << className << "();" << endl
            << endl
            << "    void setupSUI(const char *xmlFileName);" << endl
            << "    void setupSUIContainer(const char *xmlFileName, Container *container);" << endl
            << "    void loadObjects(ObjectList *objectList);" << endl
            << endl
            << "    Dialog *dialog;" << endl;

    foreach (const QString &objectDefinition, objectStringList)
        stream << "    " << objectDefinition << ";" << endl;

    stream
            << endl
            << "    friend class ::" << className << ";" << endl << endl
            << "};" << endl
            << "} //namespace SUI" << endl
            << "#endif // SUI_MOC_" << className.toUpper() << "_H" << endl;


    file->close();
}

void SUI::SourceCodeGenerator::writeMocSource(QFile *file, const QString &className, const QStringList &objectStringList) {
    file->open(QIODevice::WriteOnly | QIODevice::Text);
    if (!isFileOpen(file)) return;

    QTextStream stream(file);

    QSet<QString> uniqueObjectList;
    foreach (const QString &objectDefinition, objectStringList)
        uniqueObjectList.insert(objectDefinition.split(" ").at(0));

    stream
            << "/*!" << endl
            << " * This is an automatically generated file. DO NOT MODIFY!" << endl
            << " *" << endl
            << " * Generation date : " + QDateTime::currentDateTime().toString("dd-MM-yyyy, hh:mm") << endl
            << " *" << endl
            << " * " << generatorString() << " (version " << Model::instance()->getFormEditor()->getPropertyValue(SUI::ObjectPropertyTypeEnum::SUIVersion) << ")" << endl
            << " *" << endl
            << " */" << endl;

    stream
            << endl
            << "#include \"" << "moc_" << className << ".h\"" << endl << endl
            << "#include <SUIUILoader.h>" << endl
            << "#include <SUIObjectList.h>" << endl
            << "#include <SUIDialog.h>" << endl
            << "#include <SUIContainer.h>" << endl << endl
            << endl;
    foreach (const QString &object, uniqueObjectList)
        stream << "#include <SUI" << object << ".h>" << endl;

    stream
            << endl
            << "SUI::" << className << "::" << className << "()";
    if (objectStringList.size() > 0) stream << " : ";

    stream << endl
           << "    " << "dialog(NULL)";
    if (objectStringList.size() > 0) stream << ",";

    stream << endl;

    foreach (const QString &objectDefinition, objectStringList) {
        QString name = objectDefinition.split(" ").at(1).mid(1);
        stream << "    " << name << "(NULL)";
        if (objectDefinition != objectStringList.last()) stream << ",";
        stream << endl;
    }

    stream
            << endl
            << "{" << endl
            << "}" << endl;

    stream
            << endl
            << "void SUI::" << className << "::setupSUI(const char* xmlFileName) {" <<endl
            << "   dialog = UILoader::loadUI(xmlFileName);" << endl
            << "   loadObjects(dialog->getObjectList());" << endl
            << "}" << endl << endl;

    stream
            << endl
            << "void SUI::" << className << "::setupSUIContainer(const char* xmlFileName, Container* container) {" << endl
            << "   container->setUiFilename(xmlFileName);" << endl
            << "   loadObjects(container->getObjectList());" << endl
            << "}" << endl << endl;

    stream
            << endl
            << "void SUI::" << className << "::loadObjects(ObjectList* objectList) {" << endl;

    foreach (const QString &objectDefinition, objectStringList) {
        QString type = objectDefinition.split(" ").at(0);
        QString name = objectDefinition.split(" ").at(1).mid(1);
        stream << "    " << name << " = objectList->getObject<"<< type << ">(\""<< name << "\");" << endl;
    }

    stream << "}" << endl;

    file->close();
}


void SUI::SourceCodeGenerator::writeHeader(QFile *file, const QString &className) {
    file->open(QIODevice::WriteOnly | QIODevice::Text);
    if (!isFileOpen(file)) return;

    QTextStream stream(file);

    stream
        << "#ifndef " << className.toUpper() << "_H" << endl
        << "#define " << className.toUpper() << "_H" << endl
        << endl
        << "namespace SUI {" << endl
        << "class " << className << ";" << endl
        << "}" << endl
        << endl
        << "class " << className << endl
        << "{" << endl
        << endl
        << "public:" << endl
        << "    explicit " << className << "();" << endl
        << "    ~" << className << "();" << endl
        << endl
        << "private:" << endl
        << "    SUI::" << className << " *sui;" << endl
        << "};" << endl
        << "#endif // " << className.toUpper() << "_H" << endl;

    file->close();
}

void SUI::SourceCodeGenerator::writeSource(QFile *file, const QString &fileName) {
    file->open(QIODevice::WriteOnly | QIODevice::Text);
    if (!isFileOpen(file)) return;

    QTextStream stream(file);
    QFileInfo fileInfo(fileName);
    QString className = fileInfo.fileName().remove(".xml");
    className = className.replace(":", "_").replace("-", "_").replace(".", "_");

    stream
            << "#include \"" << className << ".h\"" << endl
            << "#include \"moc_" << className << ".h\"" << endl
            << endl
            << className << "::" << className << "() :" << endl
            << "    sui(new SUI::" << className << ")" << endl
            << "{" << endl
            << "    sui->setupSUI(\"" << fileInfo.fileName() << "\");" << endl
            << "}" << endl
            << className << "::~" << className << "()" << endl
            << "{" << endl
            << "    delete sui;" << endl
            << "}" << endl
                           << endl;

    file->close();
}

void SUI::SourceCodeGenerator::writePythonFile(QFile *file, const QString &className) {
    file->open(QIODevice::WriteOnly | QIODevice::Text);
    if (!isFileOpen(file)) return;

    const FormEditor  *formEditor = Model::instance()->getFormEditor();

    QTextStream stream(file);

    stream
            << "###########################################" << endl
            << "#" << endl
            << "#  This is a generated file, DO NOT MODIFY!" << endl
            << "#" << endl
            << "#  File            : " << className << "_constants.py" << endl
            << "#" << endl
            << "#  Generation date : " << QDateTime::currentDateTime().toString("dd-MM-yyyy, hh:mm") << endl
            << "#" << endl
            << "#  " << generatorString() << " (version " << formEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::SUIVersion) << ")" << endl
            << "#" << endl
            << "###########################################" << endl;

    stream << "class " << className << "Constants(object):\n";

    stream
            << "    Height = '" << formEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height) << "'" << endl
            << "    Width = '" << formEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width) << "'" << endl
            << "    Name = '" << formEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::SUIName) << "'" << endl
            << "    Description = '" << formEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::SUIDescription) << "'" << endl;

    QStringList idList; // TODO clean up this mess with getIDList
    idList = formEditor->getIDList(idList);
    idList.removeOne("Height");
    idList.removeOne("Width");
    idList.removeOne("Name");
    idList.removeOne("Description");
    for (int ind = 0; ind < idList.size(); ++ind) {
        QString id = idList.at(ind);
        stream << "    " << id.replace(":", "_").replace("-", "_").replace(".", "_") << " = '" << id << "'" << endl;
    }

    stream << endl;

    file->close();

}

bool SUI::SourceCodeGenerator::writeFileAllowed(QFile *file) {
    if (!file->exists()) return true;

    file->open(QIODevice::ReadOnly | QIODevice::Text);
    if (file->isOpen()) {
        QTextStream stream(file);
        QString fileString = stream.readAll();
        file->close();
        if (fileString.contains(generatorString())) {
            int ret = QMessageBox::critical(
                        NULL, qApp->applicationName(),
                        QString("File %1 already exists and was generated by this application.\nDo you want to overwrite this file?").arg(file->fileName()),
                        QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
            if (ret == QMessageBox::No) return false;
        }
        else {
            int ret = QMessageBox::critical(
                        NULL, qApp->applicationName(),
                        QString("File %1 already exists but was not generated by this application.\nDo you want to overwrite this file?").arg(file->fileName()),
                        QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
            if (ret == QMessageBox::No) return false;
        }
    }
    return true;
}

QString SUI::SourceCodeGenerator::generatorString() {
    return QString("Generated by: %1").arg(qApp->applicationName());
}

bool SUI::SourceCodeGenerator::isFileOpen(QFile *file) {
    if (file->isOpen()) return true;
    else {
        QMessageBox::critical(
                    NULL, qApp->applicationName(),
                    QString("File %1 could not be opened ...").arg(file->fileName()),
                    QMessageBox::Ok, QMessageBox::Ok);
    }
    return false;
}

