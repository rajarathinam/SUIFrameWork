/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : main.cpp
| Author       :
| Description  : main function.
|
| ! \file        main.cpp
| ! \brief       On CentOS the application would crash if a UserControl was
|                deleted. That happened somewhere in the Event Loop and not
|                always on the same code line, or in the same function. The
|                functions QCoreApplication::flush or QApplication::synX which
|                should synchronize with the X server, did not seem to work.
|                However, using the '-sync' option with FBE, did seem to work.
|                Since it is a bit awkward to have to start FBE with an extra
|                option, it is added here in the main before calling QApplication.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include <QApplication>
#include <QSplashScreen>
#include <QFileInfo>
#include <QCleanlooksStyle>

#include "mainwindow.h"
#include "SplashScreen.h"

#include <SUIApplication.h>

int main(int argc, char *argv[])
{

    char *newArgv[argc + 1];
    for (int i = 0; i < argc; ++i) newArgv[i] = argv[i];

    newArgv[argc] = new char(8);
    strcpy(newArgv[argc], "-sync");
    ++argc;

    boost::shared_ptr<SUI::Application> app = SUI::Application::createApplication(argc,argv);

    QApplication::setStyle(new QCleanlooksStyle);

    SplashScreen *splash = new SplashScreen();
    splash->show();

    QFileInfo fi(argv[0]);
    qApp->setApplicationName(fi.fileName());

    MainWindow w;
    w.show();

    splash->finish(&w);
    splash->deleteLater();
    splash = NULL;

    return app->exec();
}
