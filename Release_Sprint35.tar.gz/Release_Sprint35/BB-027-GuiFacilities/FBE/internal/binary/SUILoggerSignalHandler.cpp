/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUILoggerSignalHandler.cpp
| Author       :
| Description  : Class implementation file for SUI::LoggerSignalHandler.
|
| ! \file        SUILoggerSignalHandler.cpp
| ! \brief       Class implementation file for SUI::LoggerSignalHandler.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "SUILoggerSignalHandler.h"

SUI::LoggerSignalHandler::LoggerSignalHandler(QObject *parent) :
    QObject(parent)
{
}

void SUI::LoggerSignalHandler::sendLogEvent(QString logmsg, int level) {
    emit newLogEvent(logmsg, level);
}
