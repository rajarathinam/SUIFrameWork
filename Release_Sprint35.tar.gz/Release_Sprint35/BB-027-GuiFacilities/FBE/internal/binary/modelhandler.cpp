/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : modelhandler.cpp
| Author       :
| Description  : Class implementation file for ModelHandler.
|
| ! \file        modelhandler.cpp
| ! \brief       Class implementation file for ModelHandler.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include "modelhandler.h"

ModelHandler::ModelHandler(QObject *parent) :
    QObject(parent)
{
}

