/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : formpropertiesdialog.h
| Author       :
| Description  : Header file for class FormPropertiesDialog.
|
| ! \file        formpropertiesdialog.h
| ! \brief       Header file for class FormPropertiesDialog.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef FORMPROPERTIESDIALOG_H
#define FORMPROPERTIESDIALOG_H

#include <QDialog>
#include <QSet>

#include "WidgetControllerInfo.h"
#include "formeditor.h"

namespace Ui
{
class Dialog;
}


class FormPropertiesDialog : public QDialog
{
    Q_OBJECT
public:
    explicit FormPropertiesDialog(FormEditor *ddwidg, QWidget *parent = 0);
    virtual ~FormPropertiesDialog();

private:
    Ui::Dialog                  *mFormUi;
    FormEditor                  *mDDWidg;
    QMap<QString, QString>      mTmpPropertyList;
    static const QList<SUI::ObjectPropertyTypeEnum::Type> cmUnusedPropertyList;

signals:

public slots:
    void    onOk();
    void    onCancel();
    void    onPropertyChanged(QString key, QString value);

};

#endif // FORMPROPERTIESDIALOG_H
