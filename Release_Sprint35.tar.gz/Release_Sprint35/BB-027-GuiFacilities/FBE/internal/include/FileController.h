/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : FileController.h
| Author       :
| Description  : Header file for class FileController.
|
| ! \file        FileController.h
| ! \brief       Header file for class FileController.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef FILECONTROLLER_H
#define FILECONTROLLER_H

#include <QObject>
#include <QTemporaryFile>

class FormEditor;
class UserControlSelector;
class WidgetController;

class QSettings;
class QAction;
class QMenu;

class FileController : public QObject
{
    Q_OBJECT
public:
    virtual ~FileController();
    static FileController *instance();

    /*!
     * \brief initialize Must be called after the first call to FileController::instance().
     *
     * \param formEditor
     * \param userControlSelector
     * \param fileMenu
     * \param settings
     *
     */
    void initialize(FormEditor *formEditor, UserControlSelector *userControlSelector, QMenu *fileMenu, QSettings *settings);
    /*!
     * \brief openFile
     * \param fileName
     */
    void openFile(QString fileName);

    /*!
     * \brief Opens a user control file.
     */
    void importUserControl(const QString &fileName);

    /*!
     *  \brief This function saves the definition to a definition file.
     *  If the file name (mFileName) is known it will save the Form with that file
     *  name. Otherwise it will call onSaveAs(), which calls this function again,
     *  to save the Form. It then uses the serializer to write the created gui to
     *  file.
     */
    void save(QString filename);
    void saveAs();


    /*!
     * \brief This function will add the current file to the recent file list
     */
    void setCurrentFile(const QString &fileName);

    /*!
     * \brief saveDialog
     * \return
     */
    bool saveDialog();

    /*!
     * \brief This function updates visible the filenames in the 'File' menu
     */
    void resetRecentFilesMenu();

    /*!
     * \brief clearFileName
     */
    void clearFileName();

    /*!
     * \brief getFileName
     * \return
     */
    QString getFileName();
    QString getBackupTempFileName();

signals:
    void enableShowProperties(const QString &functionName);
    void disableShowProperties(const QString &functionName);
    void startWidgetProcess(int);
    void finishWidgetProcess();
    void loadProperties(WidgetController *ddwidg);
    void fillObjectTree();
    void statusMessage(const QString &message,int timeout);
    void enableStandardButtonArea(bool);
    void changeWindowTitle(const QString &title);

    void fileSaved();
    void fileOpened();

public slots:
    void setDataChanged(bool changed);   

private slots:
    void onRecentFileActionTriggered();
    void onFileLoaded();

protected:
    virtual void timerEvent(QTimerEvent *event);

private:
    /*!
     *  \brief This function will load the given filename in the editor.
     *  At the end of this function a singleshot timer is used to emit
     *  onLoadFinished. This will set Model's setDataChanged to false. The timer
     *  is necessary, because after this function ends, a number of temporary
     *  WidgetControllers are deleted, which will cause Model's mDataChanged to be
     *  set to true. onLoadFinished will put this right again.
     */
    void loadFile(QString filename);

    /*!
     * \brief This function will update the recent used files in the 'File' menu
     */
    void updateRecentFileActions();

    /*!
     * \brief Generates the source and header files in the user specified folder from the specified xml file.
     */
    static void generateSourceCode(const QString &fileName);

    /*!
     *  \brief This function generates the backup file name, depending on the current
     *  ui definition file name.
     */
    void resetBackupFile(const QString &fileName = "backup.xml");

    void deleteBackupFile();

    static QString getBaseName(QString fileName);

    enum {
        MaxRecentFiles = 5,
        SaveTimerInterval = 500 // 500ms, once saved the timer waits
    };

    FormEditor *formEditor;
    UserControlSelector *userControlSelector;
    QMenu *fileMenu;
    QSettings *settings;

    int saveTimerId;

    bool dataChanged;

    QAction *recentFileActions[MaxRecentFiles];

    QString mFileName;
    QTemporaryFile *mBackupTempFile;

    static QString SUI_FILE_EXTENSION;
    static QString TEMP_FILE_EXTENSION;
    static QString TEMP_FILE_TEMPLATE;
    static QString MAINWINDOW_TITLE_TEMPLATE;

    FileController();
    FileController(const FileController &);
    FileController operator=(const FileController &);
};

#endif // FILECONTROLLER_H
