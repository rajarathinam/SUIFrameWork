/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : UndoHandler.h
| Author       :
| Description  : Header file for class UndoHandler.
|
| ! \file        UndoHandler.h
| ! \brief       Header file for class UndoHandler.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef UNDOHANDLER_H
#define UNDOHANDLER_H

#include <QString>
#include <QList>

#include "CircularList.h"

class WidgetController;
class FormEditor;
class WidgetDefinition;

class UndoHandler : public QObject
{
    Q_OBJECT

public:

    static UndoHandler  *instance();
    static void         deleteInstance();
    void                addToUndoGroup(QList<WidgetState *> stateList);
    void                addToUndoGroup(WidgetState *wsState);
    void                addNewUCtrlToWSList(QList<WidgetState *> wsList, WidgetController *wcUCtrl);
    void                addOldUCtrlToWSList(QList<WidgetState *> wsList, WidgetState *wsUCtrl);
    WidgetState         *getNewUndoInfo(WidgetController *wcUndo, UNDO_ACTION action, QString actiontext = QString(""));
    void                finishUndoInfo(WidgetState *wsState, WidgetController *wcUndo);
    void                undo();
    void                redo();
    void                deleteWidgetState(WidgetState *wsState);
    void                printUndoBuffer() const;
    QStringList         getUndoActions() const;
    void                setCurrentSaved()                                           { mUndoBuffer.setCurrentSaved(); }
    void                block(bool block)                                         { mUndoBlocked = block; }
    void                clearBuffer()                                               { mUndoBuffer.clear(); mCurrentlyHandled = const_cast<WidgetController *>(cmUndefinedPointer); }

private:
    bool                            mUndoBlocked;
    static UndoHandler              *mInstance;
    CircularList                    mUndoBuffer;
    WidgetController                *mCurrentlyHandled;

    static const QStringList        cmActionList;
    static const WidgetController   *cmUndefinedPointer;

    UndoHandler();
    UndoHandler(const UndoHandler &rhs);
    UndoHandler &operator=(const UndoHandler &rhs);
    virtual ~UndoHandler();

    void                undoDelete(UndoInfo *undoInf);
    void                undoNew(UndoInfo *undoInf);
    void                undoMove(UndoInfo *undoInf);
    void                undoProperty(UndoInfo *undoInf);
    void                undoComplexChange(UndoInfo *undoInf);
    void                undoUCtrl(UndoInfo *undoInf);
    void                undoSplitUCtrl(UndoInfo *undoInf);
    void                redoNew(UndoInfo *undoInf);
    void                redoDelete(UndoInfo *undoInf);
    void                redoMove(UndoInfo *undoInf);
    void                redoProperty(UndoInfo *undoInf);
    void                redoComplexChange(UndoInfo *undoInf);
    void                redoUCtrl(UndoInfo *undoInf);
    void                redoSplitUCtrl(UndoInfo *undoInf);

public slots:
    void        onDeleteUndoInfo(UndoInfo *undoInf);
    void        onEnableUndo(bool enable);
    void        onEnableRedo(bool enable);
    void        onSendUndoRedoText(const QString &undotxt, const QString &redotxt);

signals:
    void        doEnableUndo(bool);
    void        doEnableRedo(bool);
    void        doSendUndoRedoText(const QString &, const QString &);
};

#endif // UNDOHANDLER_H
