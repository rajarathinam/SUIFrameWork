/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : formeditor.h
| Author       :
| Description  : Header file for class FormEditor.
|
| ! \file        formeditor.h
| ! \brief       Header file for class FormEditor.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef FormEditor_H
#define FormEditor_H

#include "WidgetController.h"

#include <QGroupBox>

#include <SUIVersionInfo.h>

class FormEditor : public WidgetController
{
public:
    FormEditor(QWidget *parent = 0);
    virtual ~FormEditor() {}

    void acceptVisitor(GUIDefinitionVisitor &visitor , bool bSkipUCtrl = false);
    void reset();
    void readInclude(const QString &incfile);
    void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);
    void setInclude(const QString &include, const QString &fileName);

    QString getPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID) const;
    void setGridPixmap();

    bool hasRightButtonBar() const;
    bool hasBottomButtonBar() const;
    bool hasStatusBar() const;
    int rightButtonBarWidth() const;
    int bottomButtonBarHeight() const;
    int statusBarHeight() const;

    static SUI::VersionInfo getVersion();
    static SUI::VersionInfo getEditorVersion();

private:
    WidgetController *mBaseWidgetController;
    QMap<QString, QString> mUtcProperties;
    static const int cm_RightButtonBarWidth = 220;
    static const int cm_BottomButtonBarHeight = 50;
    static const int cm_StatusBarHeight = 50;

    static const SUI::VersionInfo suiVersion;
    static const SUI::VersionInfo suiEditorVersion;

};

#endif // FormEditor_H
