/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : usercontrolselector.h
| Author       :
| Description  : Header file for class UserControlSelector.
|
| ! \file        usercontrolselector.h
| ! \brief       Header file for class UserControlSelector.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef USERCONTROLSELECTOR_H
#define USERCONTROLSELECTOR_H

#include <QVBoxLayout>
#include <SUIObjectFactory.h>
#include "WidgetController.h"

class UserControlSelector : public WidgetController
{
public:
//    UserControlSelector();
    UserControlSelector(QWidget *parent = 0);
    virtual ~UserControlSelector();

    void    initUserControls();
    void    init();
    void    clear();

private:
    QVBoxLayout                 *mUCtrlLayout;
    QList<WidgetController *>    mSeparatorList;

    UserControlSelector(const UserControlSelector &rhs);
    UserControlSelector &operator=(const UserControlSelector &rhs);
};

#endif // USERCONTROLSELECTOR_H
