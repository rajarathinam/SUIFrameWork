/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUISourceCodeGenerator.h
| Author       :
| Description  : Header file for class SUI::SourceCodeGenerator.
|
| ! \file        SUISourceCodeGenerator.h
| ! \brief       Header file for class SUI::SourceCodeGenerator.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUI_SUISOURCECODEGENERATOR_H
#define SUI_SUISOURCECODEGENERATOR_H

#include <QStringList>

class QFile;

namespace SUI {
class Dialog;

class SourceCodeGenerator
{
public:
    static void dialogToSource(const QString &fileName, SUI::Dialog *dialog);

private:
    // cpp
    static void writeMocHeader(QFile *file, const QString &className, const QStringList &objectStringList);
    static void writeMocSource(QFile *file, const QString &className, const QStringList &objectStringList);
    static void writeHeader(QFile *file, const QString &className);
    static void writeSource(QFile *file, const QString &fileName);

    //python
    static void writePythonFile(QFile *file, const QString &className);

    static bool writeFileAllowed(QFile *file);

    static QString generatorString();

    static bool isFileOpen(QFile *file);

};

} // namespace SUI

#endif // SUI_SUISOURCECODEGENERATOR_H
