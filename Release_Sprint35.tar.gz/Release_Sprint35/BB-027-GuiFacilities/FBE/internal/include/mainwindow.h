/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : mainwindow.h
| Author       :
| Description  : Header file for mainwindow class.
|
| ! \file        mainwindow.h
| ! \brief       Header file for mainwindow class.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QItemSelection>

#include <SUIObjectPropertyTypeEnum.h>

class QStandardItem;
class QTableWidgetItem;
class QStandardItemModel;
class QSettings;
class QProgressBar;

class FormEditor;
class WidgetController;

namespace Ui
{
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

    typedef QList<QStandardItem *> StdItemList;

public:
    explicit MainWindow(QWidget *parent = 0);
    virtual ~MainWindow();

    FormEditor *getFormEditor() const;

private slots:
    void onLoadFinished();
    void onNew();
    void onSaveClicked();
    void onSaveAs();
    void onOpen();

    void onPropertiesDialog();
    void onPropertyItemChanged(QTableWidgetItem *valueItem);
    void onPropertyChanged(QString key, QString value);
    void onPropertyIndexedValueChanged(QString typeString, QString value);

    void onGetNewDoubleValue(QString key, QString value);

    void fillObjectTree();

    void selectionChangedSlot(const QItemSelection &newSelection, const QItemSelection &oldSelection);
    void setSelection(WidgetController *ddwidg);

    void onCustomContextMenuRequest(QPoint point);

    void onDisablePasteAction(bool setDisabled);
    void onCopyWidget();
    void onPasteWidget();

    void onQuit();

    void onEnableStandardButtonArea(bool enabled);

    void onDisableShowProperties(const QString &funcname);
    void onEnableShowProperties(const QString &funcname);

    void loadProperties(WidgetController *ddwidg);

    void onAddStandardButtonArea();
    void onImportUserControl();
    void onToForground();
    void onBackground();
    void onForward();
    void onBackward();
    void onEnableForwardbackward(bool on);

    void onAddTabPageAct();
    void onMoveNextAct();
    void onMovePrevAct();    
    void onDeleteAct();

    void onPreview();

    void onCollapseAll();
    void onExpandAll();

    void onUndo();
    void onRedo();

    void onEnableUndo(bool enable);
    void onEnableRedo(bool enable);

    void onUndoRedoText(const QString &undotxt, const QString &redotxt);
    void onPrintUndoBuffer();

    void onGridChanged(bool set);
    void onGridOptions();

    void onWidgetProcessed();
    void onWidgetProcessMessage(QString msg);
    void onWidgetProcessStart(int count);

    void onDataChanged(bool changed);

    void onFinishWidgetProcess();

    void onNewLogMessage(QString title, QString msg, int level);

signals:
    void sendDoubleValue(QString, QString);

protected:
    virtual void keyPressEvent(QKeyEvent *ke);
    virtual void keyReleaseEvent(QKeyEvent *ke);

private:
    enum { MaxRecentFiles = 5 };

    Ui::MainWindow *ui;

    QStandardItemModel *mStandardModel;

    QString mSendDisableShowFunction;

    QSettings *mSettings;

    int mWidgetCount;
    QProgressBar *mWidgetCountProgressBar;

    virtual void closeEvent(QCloseEvent *event);
    void addItemToObjectTree(QStandardItem *parentItem, WidgetController *pWidget);
    QStandardItem *searchItem(QStandardItem *parentItem, const QString &id);
    void addMainTabWidget();
    void rightButtonBar();
    void bottomButtonBar();
    void addStatusBar();
    void statusbarSplitter();
    void addStatusbarSplitter();
    void removeStatusbarSplitter();
    void handleFormLayout();
    void checkMaintabwidgetParent();
    void changeMaintabwidgetParent(WidgetController *newParent);
    void newUserControl(QString &uctrlname, QString &id);
    void splitUserControl(WidgetController *UctWidget);

    void expandNode(const QModelIndex &parentIndex, bool expand);
    void moveTabPage(bool direction);
    void makeTmpFileName();

    void removeUCtrlFromSelector(WidgetController *widget);

    typedef struct PROPERTYSTRUCT
    {
        bool readOnly;
        SUI::ObjectPropertyTypeEnum::Type key;
    } PropertyStruct;
};

#endif // MAINWINDOW_H
