//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::SourceCodeGenerator.
// !\description Class implementation file for SUI::SourceCodeGenerator.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUISourceCodeGenerator.h"

#include <FWQxWidgets/SUIDialog.h>
#include <FWQxCore/SUIObjectList.h>
#include <FWQxCore/SUIObject.h>

#include <QStringList>
#include <QFile>
#include <QTextStream>
#include <QSet>
#include <QFileInfo>
#include <QDebug>
#include <QDateTime>
#include <QApplication>
#include <QMessageBox>
#include <boost/foreach.hpp>
#include "formeditor.h"
#include "Model.h"

void SUI::SourceCodeGenerator::dialogToSource(const QString &fileName, const QString &generationPath, SUI::Dialog *dialog, const SUI::SourceCodeGenerator::GenerateFiles fileType) {

    QFileInfo genInfo(generationPath);
    SUI::ObjectList *list;
    std::vector<Object *> objects;
    if ( dialog != NULL ){
        list = dialog->getObjectList();
        objects = list->getObjectList();
    }

    QStringList objectStringList;
    for(size_t n = 0; n < objects.size(); n++) {
        Object *object = objects.at(n);

        if ((QString::fromStdString(object->getId()).contains(":") == false) &&
                        !( object->getObjectType() == SUI::ObjectType::TableWidgetItem || object->getObjectType() == SUI::ObjectType::TreeViewItem )){

            QString objectDefinition("%1 *%2");
            objectStringList.append(objectDefinition.arg(QString::fromStdString(SUI::ObjectType::toString(object->getObjectType()))).arg(QString::fromStdString(object->getId())));
        }
    }

    if(fileType == SUI::SourceCodeGenerator::mocFiles ) {
        QFile mocHeader(genInfo.absoluteFilePath().append("/%1_MOC_%2.hpp").arg(getNamespace()).arg(getClassName()));
        if(!checkFileExists(&mocHeader, fileType)) {
            mocHeader.remove();
            QFile mocSource(genInfo.absoluteFilePath().append("/%1_MOC_%2.cpp").arg(getNamespace()).arg(getClassName()));
            if(mocSource.exists()) mocSource.remove();
            writeMocHeader(&mocHeader,objectStringList);
            writeMocSource(&mocSource,objectStringList);
        }
    } else {
        QFile header(genInfo.absoluteFilePath().append("/%1_%2.hpp").arg(getNamespace()).arg(getClassName()));
        if(!checkFileExists(&header, fileType)) {
            header.remove();
            QFile source(genInfo.absoluteFilePath().append("/%1_%2.cpp").arg(getNamespace()).arg(getClassName()));
            if(source.exists()) source.remove();
            writeHeader(&header);
            writeSource(&source, fileName);
        }
    }
}

void SUI::SourceCodeGenerator::writeMocHeader(QFile *file, const QStringList &objectStringList) {

    file->open(QIODevice::WriteOnly | QIODevice::Text);
    if (!isFileOpen(file)) return;

    QTextStream stream(file);

    QSet<QString> uniqueObjectList;
    BOOST_FOREACH (const QString &objectDefinition, objectStringList) {
        uniqueObjectList.insert(objectDefinition.split(" ").at(0));
    }

    stream
            << "//----------------------------------------------------------------------------|" << endl
            << "//                                                                            |" << endl
            << "//                             C++ MOC Header File                            |" << endl
            << "//                                                                            |" << endl
            << "//----------------------------------------------------------------------------|" << endl
            << "//" << endl
            << "// !\\author FBE Auto generated" << endl
            << "// !\\brief " << getBriefDescription() << endl
            << "// !\\description " << getDescription() << endl
            << "//" << endl
            << "//----------------------------------------------------------------------------|" << endl
            << "//                                                                            |" << endl
            << "//               Copyright (c) 2017, ASML Netherlands B.V.                    |" << endl
            << "//                          All rights reserved                               |" << endl
            << "//                                                                            |" << endl
            << "//----------------------------------------------------------------------------|" << endl
            << endl
            << "// This is an automatically generated file. DO NOT MODIFY!" << endl
            << "// Generation date : " + QDateTime::currentDateTime().toString("dd-MM-yyyy, hh:mm") << endl
            << "// " + generatorString() << " (version " << Model::instance()->getFormEditor()->getPropertyValue(SUI::ObjectPropertyTypeEnum::SUIVersion) << ")" << endl
            << endl
            << "#ifndef " << getNamespace().toUpper() << "_MOC_" << getClassName().toUpper() <<"_HPP" << endl
            << "#define " << getNamespace().toUpper() << "_MOC_" << getClassName().toUpper() <<"_HPP" << endl
            << endl
            << "//----------------------------------------------------------------------------|" << endl
            << "//                          Forward Declarations                              |" << endl
            << "//----------------------------------------------------------------------------|" << endl;

    stream
            << "namespace " <<  getNamespace() <<" {" << endl
            << "    class " << getClassName() << ";" << endl
            << "} //namespace "<< getNamespace() << endl << endl
            << "namespace SUI {" << endl
            << "class Dialog;" << endl
            << "class ObjectList;" << endl
            << "class Container;" << endl;

    BOOST_FOREACH (const QString &objectDefinition, uniqueObjectList) {
        stream << "class " << objectDefinition << ";" << endl; // forward declarations
    }
    stream
            << endl
            << "} //namespace SUI" << endl
            << "//----------------------------------------------------------------------------|" << endl
            << "//                             Class declaration                              |" << endl
            << "//----------------------------------------------------------------------------|" << endl
            << "namespace " <<  getNamespace() <<" {" << endl
            << "namespace MOC {" << endl
            << "class " << getClassName() << endl
            << "{" << endl
            << "private:" << endl
            << "    " << getClassName() << "();" << endl
            << endl
            << "    void setupSUI(const char *xmlFileName);" << endl
            << "    void setupSUIContainer(const char *xmlFileName, SUI::Container *container);" << endl
            << "    void loadObjects(SUI::ObjectList *objectList);" << endl
            << endl
            << "    SUI::Dialog *dialog;" << endl;

    BOOST_FOREACH (const QString &objectDefinition, objectStringList) {
        stream << "    SUI::" << objectDefinition << ";" << endl;
    }

    stream
            << endl
            << "    friend class ::"<<  getNamespace() << "::" << getClassName() << ";" << endl
            << "};" << endl
            << "} //namespace MOC" << endl
            << "} //namespace " << getNamespace() << endl
            << "#endif // " << getNamespace().toUpper() << "_MOC_" << getClassName().toUpper() <<"_HPP" << endl;

    file->close();
}

void SUI::SourceCodeGenerator::writeMocSource(QFile *file, const QStringList &objectStringList) {

    file->open(QIODevice::WriteOnly | QIODevice::Text);
    if (!isFileOpen(file)) return;

    QTextStream stream(file);

    QSet<QString> uniqueObjectList;
    BOOST_FOREACH (const QString &objectDefinition, objectStringList) {
        uniqueObjectList.insert(objectDefinition.split(" ").at(0));
    }

    stream
             << "//----------------------------------------------------------------------------|" << endl
             << "//                                                                            |" << endl
             << "//                             C++ MOC Source File                            |" << endl
             << "//                                                                            |" << endl
             << "//----------------------------------------------------------------------------|" << endl
             << "//" << endl
             << "// !\\author FBE Auto generated" << endl
             << "// !\\brief " << getBriefDescription() << endl
             << "// !\\description " << getDescription() << endl
             << "//" << endl
             << "//----------------------------------------------------------------------------|" << endl
             << "//                                                                            |" << endl
             << "//               Copyright (c) 2017, ASML Netherlands B.V.                    |" << endl
             << "//                          All rights reserved                               |" << endl
             << "//                                                                            |" << endl
             << "//----------------------------------------------------------------------------|" << endl
             << endl
             << "// This is an automatically generated file. DO NOT MODIFY!" << endl
             << "// Generation date : " + QDateTime::currentDateTime().toString("dd-MM-yyyy, hh:mm") << endl
             << "// " + generatorString() << " (version " << Model::instance()->getFormEditor()->getPropertyValue(SUI::ObjectPropertyTypeEnum::SUIVersion) << ")" << endl
             << endl;

    stream
            << "//----------------------------------------------------------------------------|" << endl
            << "//                                 Includes                                   |" << endl
            << "//----------------------------------------------------------------------------|" << endl
            << "#include \"" << getNamespace() << "_MOC_" << getClassName() << ".hpp\"" << endl << endl
            << "#include \"FWQxCore/SUIUILoader.h\"" << endl
            << "#include \"FWQxCore/SUIObjectList.h\"" << endl
            << "#include \"FWQxWidgets/SUIDialog.h\"" << endl
            << "#include \"FWQxWidgets/SUIContainer.h\"" << endl
            << endl;
    BOOST_FOREACH (const QString &object, uniqueObjectList) {
        stream << "#include \"FWQxWidgets/SUI" << object << ".h\"" << endl;
    }
    stream
            << endl
            << "//----------------------------------------------------------------------------|" << endl
            << "//                             Class definition                               |" << endl
            << "//----------------------------------------------------------------------------|" << endl
            << getNamespace() <<"::MOC::" << getClassName() << "::" << getClassName() << "()";
    if (objectStringList.size() > 0) stream << " : ";

    stream << endl
           << "    " << "dialog(NULL)";
    if (objectStringList.size() > 0) stream << ",";

    stream << endl;

    BOOST_FOREACH (const QString &objectDefinition, objectStringList) {
        QString name = objectDefinition.split(" ").at(1).mid(1);
        stream << "    " << name << "(NULL)";
        if (objectDefinition != objectStringList.last()) stream << ",";
        stream << endl;
    }

    stream
            << endl
            << "{" << endl
            << "}" << endl;

    stream
            << endl
            << "void " << getNamespace() << "::MOC::" << getClassName() << "::setupSUI(const char* xmlFileName) {" <<endl
            << "   dialog = SUI::UILoader::loadUI(xmlFileName);" << endl
            << "   loadObjects(dialog->getObjectList());" << endl
            << "}" << endl << endl;

    stream
            << endl
            << "void " << getNamespace() << "::MOC::" << getClassName()  << "::setupSUIContainer(const char* xmlFileName, SUI::Container* container) {" << endl
            << "   container->setUiFilename(xmlFileName);" << endl
            << "   loadObjects(container->getObjectList());" << endl
            << "}" << endl << endl;

    stream
            << endl
            << "void " << getNamespace() << "::MOC::" << getClassName()  << "::loadObjects(SUI::ObjectList* objectList) {" << endl;

    BOOST_FOREACH (const QString &objectDefinition, objectStringList) {
        QString type = objectDefinition.split(" ").at(0);
        QString name = objectDefinition.split(" ").at(1).mid(1);
        stream << "    " << name << " = objectList->getObject<SUI::"<< type << ">(\""<< name << "\");" << endl;
    }

    stream << "}" << endl;

    file->close();
}


void SUI::SourceCodeGenerator::writeHeader(QFile *file) {

    file->open(QIODevice::WriteOnly | QIODevice::Text);
    if (!isFileOpen(file)) return;

    QTextStream stream(file);
    stream
        << "//----------------------------------------------------------------------------|" << endl
        << "//                                                                            |" << endl
        << "//                             C++ Header File                                |" << endl
        << "//                                                                            |" << endl
        << "//----------------------------------------------------------------------------|" << endl
        << "//" << endl
        << "// !\\author FBE Auto generated" << endl
        << "// !\\brief " << getBriefDescription() << endl
        << "// !\\description " << getDescription() << endl
        << "//" << endl
        << "//----------------------------------------------------------------------------|" << endl
        << "//                                                                            |" << endl
        << "//               Copyright (c) 2017, ASML Netherlands B.V.                    |" << endl
        << "//                          All rights reserved                               |" << endl
        << "//                                                                            |" << endl
        << "//----------------------------------------------------------------------------|" << endl
        << "#ifndef " << getNamespace().toUpper() << "_" << getClassName().toUpper() << "_HPP" << endl
        << "#define " << getNamespace().toUpper() << "_" << getClassName().toUpper() << "_HPP" << endl
        << endl
        << "//----------------------------------------------------------------------------|" << endl
        << "//                                 Forward declaration                        |" << endl
        << "//----------------------------------------------------------------------------|" << endl
        << "namespace " <<  getNamespace() <<" {" << endl
        << "namespace MOC {" << endl
        << "    class " << getClassName() << ";" << endl
        << "} //namespace MOC" << endl
        << "//----------------------------------------------------------------------------|" << endl
        << "//                                 Class declaration                          |" << endl
        << "//----------------------------------------------------------------------------|" << endl
        << "class " << getClassName() << endl
        << "{" << endl
        << endl
        << "public:" << endl
        << "    " << getClassName() << "();" << endl
        << "    ~" << getClassName() << "();" << endl
        << endl
        << "private:" << endl
        << "    MOC::" << getClassName() << " *sui;" << endl
        << "};" << endl
        << "} //namespace "<< getNamespace() << endl
        << "#endif // " << getNamespace().toUpper() << "_" << getClassName().toUpper() <<"_HPP" << endl;

    file->close();
}

void SUI::SourceCodeGenerator::writeSource(QFile *file, const QString &fileName) {

    file->open(QIODevice::WriteOnly | QIODevice::Text);
    if (!isFileOpen(file)) return;

    QTextStream stream(file);
    QFileInfo fileInfo(fileName);

    stream
            << "//----------------------------------------------------------------------------|" << endl
            << "//                                                                            |" << endl
            << "//                             C++ Source File                                |" << endl
            << "//                                                                            |" << endl
            << "//----------------------------------------------------------------------------|" << endl
            << "//" << endl
            << "// !\\author FBE Auto generated" << endl
            << "// !\\brief " << getBriefDescription() << endl
            << "// !\\description " << getDescription() << endl
            << "//" << endl
            << "//----------------------------------------------------------------------------|" << endl
            << "//                                                                            |" << endl
            << "//               Copyright (c) 2017, ASML Netherlands B.V.                    |" << endl
            << "//                          All rights reserved                               |" << endl
            << "//                                                                            |" << endl
            << "//----------------------------------------------------------------------------|" << endl
            << endl
            << "//----------------------------------------------------------------------------|" << endl
            << "//                                 Includes                                   |" << endl
            << "//----------------------------------------------------------------------------|" << endl
            << "#include \"" << getNamespace() << "_" << getClassName()<< ".hpp\"" << endl
            << "#include \"" << getNamespace() << "_MOC_" << getClassName()<< ".hpp\"" << endl
            << endl
            << "//----------------------------------------------------------------------------|" << endl
            << "//                             Class definition                               |" << endl
            << "//----------------------------------------------------------------------------|" << endl
            << getNamespace() << "::" << getClassName() << "::" << getClassName() << "() :" << endl
            << "    sui(new MOC::" << getClassName() << ")" << endl
            << "{" << endl
            << "    sui->setupSUI(\"" << fileInfo.fileName() << "\");" << endl
            << "}" << endl << endl
            << getNamespace() << "::" << getClassName() << "::~" << getClassName() << "()" << endl
            << "{" << endl
            << "    delete sui;" << endl
            << "}" << endl
            << endl;

    file->close();
}

bool SUI::SourceCodeGenerator::writeFileAllowed(QFile *file) {
    if (!file->exists()) return true;

    file->open(QIODevice::ReadOnly | QIODevice::Text);
    if (file->isOpen()) {
        QTextStream stream(file);
        QString fileString = stream.readAll();
        file->close();
        if (fileString.contains(generatorString()) ==true) {
            QMessageBox::StandardButton ret = QMessageBox::critical(
                        NULL, QApplication::applicationName(),
                        QString("File %1 already exists and was generated by this application.\nDo you want to overwrite this file?").arg(file->fileName()),
                        QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
            if (ret == QMessageBox::No) return false;
        }
        else {
            QMessageBox::StandardButton ret = QMessageBox::critical(
                        NULL, QApplication::applicationName(),
                        QString("File %1 already exists but was not generated by this application.\nDo you want to overwrite this file?").arg(file->fileName()),
                        QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
            if (ret == QMessageBox::No) return false;
        }
    }
    return true;
}

bool SUI::SourceCodeGenerator::checkFileExists(QFile *file, GenerateFiles fileType) {
    QString files = (fileType == GenerateFiles::mocFiles) ? "MOC files" : "C++ files" ;
    if (file->exists()) {
        QMessageBox::StandardButton ret = QMessageBox::warning(NULL, QApplication::applicationName(),
                                       QString("%1 already exists. Do you want to replace it?").arg(files),
                                       QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
        if (ret != QMessageBox::Yes) return true;
    }
    return false;
}

QString SUI::SourceCodeGenerator::generatorString() {
    return QString("Generated by: %1").arg(QApplication::applicationName());
}

QString SUI::SourceCodeGenerator::getClassName() {
    return Model::instance()->getFormEditor()->getPropertyValue(SUI::ObjectPropertyTypeEnum::ClassName);
}

QString SUI::SourceCodeGenerator::getNamespace() {
    return Model::instance()->getFormEditor()->getPropertyValue(SUI::ObjectPropertyTypeEnum::Namespace);
}

QString SUI::SourceCodeGenerator::getDescription() {
    return Model::instance()->getFormEditor()->getPropertyValue(SUI::ObjectPropertyTypeEnum::SUIDescription);
}

QString SUI::SourceCodeGenerator::getBriefDescription() {
    return Model::instance()->getFormEditor()->getPropertyValue(SUI::ObjectPropertyTypeEnum::SUIName);
}

bool SUI::SourceCodeGenerator::isFileOpen(QFile *file) {
    if (file->isOpen()) return true;
    else {
        QMessageBox::critical(
                    NULL, QApplication::applicationName(),
                    QString("File %1 could not be opened ...").arg(file->fileName()),
                    QMessageBox::Ok, QMessageBox::Ok);
    }
    return false;
}

