//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for WidgetController.
// !\description This class provides a Drag-and-Dropable Widget. It contains
//                a widget that a user can use in the GUI Editor and contains
//                additional data, that the GUI Editor needs and is written to
//                the ui definition (xml) file. This class implements the Drag
//                and drop behaviour.
//
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "WidgetController.h"

#include <QStylePainter>
#include <QDragEnterEvent>
#include <QApplication>
#include <boost/foreach.hpp>

#include <CustomTabWidget.h>

#include <SUIBasePageImpl.h>
#include <SUIListViewImpl.h>
#include <SUITabWidgetImpl.h>
#include <SUITabPageImpl.h>
#include <SUISplitterImpl.h>
#include <SUITreeViewImpl.h>
#include <SUITableWidgetItemImpl.h>
#include <SUIUserControlImpl.h>
#include <SUIStyleSheet.h>

#include <SUIDialogSerializer.h>
#include <FWQxCore/SUIIOException.h>
#include <FWQxCore/SUIXmlException.h>
#include <FWQxWidgets/SUIWidget.h>
#include "Model.h"
#include "tablewidgetdialog.h"
#include "Itemwidgetdialog.h"
#include "UndoHandler.h"
#include "formeditor.h"

/*****************************************************************************\
 * FUNCTION : WidgetController
 * PARAMETERS : QWidget *parent
 * WidgetControllerModeEnum mode
 * RETURN : n.a.
 *
 * This is the constructor
 \****************************************************************************/
WidgetController::WidgetController(QWidget *parent, WidgetControllerModeEnum mode) :
    QLabel(parent),
    mIsSelected(false),
    mMode(mode),
    mSUIBaseWidget(NULL),
    mParent(NULL),
    mButtomResizeBound(3),
    mStartPos(smove),
    mRubberBandShown(false),
    mUndoState(NULL),
    mStartPoint(0, 0),
    initializedInEditor(false),
    mPreviousUCFileName(QString::null)
{
    mChangedProperties.chcdef = 0;
    this->setMouseTracking(true);
    mChildren.clear();
    mGUID = QUuid::createUuid();
    init(mode);
    setFocusPolicy(Qt::StrongFocus);
    if (getObjectType() != SUI::ObjectType::FormEditor)
    {
        setStyleSheet("background:transparent;");
        setAttribute(Qt::WA_TranslucentBackground);
    }
}

/*****************************************************************************\
 * FUNCTION : WidgetController
 * PARAMETERS : QWidget *parent
 * WidgetControllerModeEnum mode
 * RticBaseWidget* RticWidget
 * RETURN : n.a.
 *
 * This is the constructor
 \****************************************************************************/
WidgetController::WidgetController(QWidget *parent, WidgetControllerModeEnum mode, SUI::BaseWidget *baseWidget):
    QLabel(parent),
    mIsSelected(false),
    mMode(mode),
    mSUIBaseWidget(baseWidget),
    mParent(dynamic_cast<WidgetController *>(parent)),
    mButtomResizeBound(3),
    mStartPos(smove),
    mRubberBandShown(false),
    mUndoState(NULL),
    mStartPoint(0, 0),
    initializedInEditor(false),
    mPreviousUCFileName(QString::null)
{
    mChangedProperties.chcdef = 0;
    this->setMouseTracking(true);
    mChildren.clear();
    if (mMode != WidgetController::RootWidgetMode)
    {
        QRect wdgRect = mSUIBaseWidget->getWidget()->geometry();
        mSUIBaseWidget->getWidget()->move(wdgRect.x() + 3, wdgRect.y() + 3);
        setGeometry(QRect(wdgRect.x(), wdgRect.y(), wdgRect.width() + 6, wdgRect.height() + 6));
        setPixmap(QPixmap::grabWidget(mSUIBaseWidget->getWidget()));
        mGUID = QUuid::createUuid();
        init(mode);
        setFocusPolicy(Qt::StrongFocus);
    }
    else
    {
        QRect wdgRect = QRect(0, 0, 500, 600);
        this->setGeometry(QRect(wdgRect.x(), wdgRect.y(), wdgRect.width(), wdgRect.height()));
        this->setPixmap(QPixmap::grabWidget(mSUIBaseWidget->getWidget()));
    }
    if (getObjectType() != SUI::ObjectType::FormEditor)
    {
        setStyleSheet("background:transparent;");
        setAttribute(Qt::WA_TranslucentBackground);
    }
}


/*****************************************************************************\
 * FUNCTION : ~WidgetController
 * PARAMETERS : n.a.
 * RETURN : n.a.
 *
 * This is the destructor
 * Deleting the children of this WidgetController, can result in segmentation
 * fault crashes. Especially when deleting a more complex WidgetController,
 * like a UserController. These crashes always happen somewhere in the Eventloop
 * and thus are not really traceable. Also gdb is not able to pinpoint the
 * location of the crash.
 * My suspicion is that Qt will delete all children of a Widget itself. When
 * this happens, before the code reaches the destructor of children when calling
 * child->deleteLater() then this child might already have been deleted and
 * that will cause a segmentation fault.
 \****************************************************************************/
WidgetController::~WidgetController()
{
    mChildren.clear();
    Model::instance()->removeWidget(mGUID);
}

/*****************************************************************************\
 * FUNCTION : Init
 * PARAMETERS : WidgetControllerModeEnum mode
 * RETURN : void
 *
 * This function does some initialization
 \****************************************************************************/
void WidgetController::init(WidgetControllerModeEnum mode) {
    mDropAction = mode == WidgetSelectorMode ? Qt::CopyAction : Qt::MoveAction;
    setAcceptDrops(mode != SingleWidgetMode);
}

/*****************************************************************************\
 * FUNCTION : acceptVisitor
 * PARAMETERS : IRticGUIVisitor* visitor
 * RETURN : void
 *
 * This function writes all properties to the XML Writer.
 \****************************************************************************/
void WidgetController::acceptVisitor(GUIDefinitionVisitor &visitor, bool bSkipUCtrl) const
{
    visitor.writeWidgetProperty(SUI::ObjectPropertyTypeEnum::ID, QString::fromStdString(mSUIBaseWidget->getId()));
    visitor.writeWidgetProperty(SUI::ObjectPropertyTypeEnum::ObjectType, QString::fromStdString(SUI::ObjectType::toString(mSUIBaseWidget->getObjectType())));
    BOOST_FOREACH(SUI::ObjectPropertyTypeEnum::Type propertyID, mSUIBaseWidget->getPropertyTypes())
    {
        // No need to add SUICoreVersion, SUIEditorVersion, .. for all widgets
        // Height and Width are not always exposed, but are alway present.
        // Skip it for now and add it after this loop ID and WidgetType have already been written.
        if ((propertyID != SUI::ObjectPropertyTypeEnum::SUICoreVersion) && (propertyID != SUI::ObjectPropertyTypeEnum::SUIEditorVersion) &&
                (propertyID != SUI::ObjectPropertyTypeEnum::SUIObjectFactory) && (propertyID != SUI::ObjectPropertyTypeEnum::SUIName) &&
                (propertyID != SUI::ObjectPropertyTypeEnum::SUIDescription) && (propertyID != SUI::ObjectPropertyTypeEnum::Height) && (propertyID != SUI::ObjectPropertyTypeEnum::Width) &&
                (propertyID != SUI::ObjectPropertyTypeEnum::HasRightButtonBar) && (propertyID != SUI::ObjectPropertyTypeEnum::HasBottomButtonBar) &&
                (propertyID != SUI::ObjectPropertyTypeEnum::HasStatusBar) && (propertyID != SUI::ObjectPropertyTypeEnum::SUIVersion) &&
                (propertyID != SUI::ObjectPropertyTypeEnum::SUIStyleSheet)  && (propertyID != SUI::ObjectPropertyTypeEnum::ID) && (propertyID != SUI::ObjectPropertyTypeEnum::ObjectType))
        {
            if(mSUIBaseWidget->getPropertyValue(propertyID) != "" || propertyID == SUI::ObjectPropertyTypeEnum::Text) {
                visitor.writeWidgetProperty(propertyID, mSUIBaseWidget->getPropertyValue(propertyID));
            }
        }
    }
    visitor.writeWidgetProperty(SUI::ObjectPropertyTypeEnum::Height, mSUIBaseWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height));
    visitor.writeWidgetProperty(SUI::ObjectPropertyTypeEnum::Width, mSUIBaseWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width));

    // The TableWidget has its own list of children,
    // because they need to be addressed by row- and column number.
    // The TableWidget supplies this addressing method.
    if (getObjectType() == SUI::ObjectType::TableWidget)
    {
        SUI::TableWidgetImpl *table = dynamic_cast<SUI::TableWidgetImpl *>(mSUIBaseWidget);
        int dMaxInd = table->rowCount() * table->columnCount();
        for (int ind = 0; ind < dMaxInd && ind < mChildren.size(); ind++) {
            GUIDefinitionVisitor &childVisitor = visitor.openChildWidget();
            mChildren[ind]->acceptVisitor(childVisitor, bSkipUCtrl);
            visitor.closeChildWidget();
        }
    }
    else if ((bSkipUCtrl && (getObjectType() == SUI::ObjectType::UserControl)) == false) {
        for (int childInd = 0; childInd < mChildren.size(); ++childInd) {
            GUIDefinitionVisitor &childVisitor = visitor.openChildWidget();
            mChildren[childInd]->acceptVisitor(childVisitor, bSkipUCtrl);
            visitor.closeChildWidget();
        }
    }
}

/*****************************************************************************\
 * FUNCTION : dragEnterEvent
 * PARAMETERS : QDragEnterEvent *event
 * RETURN : void
 *
 * This function is a reimplementation of QLabel's virtual protected function.
 \****************************************************************************/
void WidgetController::dragEnterEvent(QDragEnterEvent *event)
{
    if (event->mimeData()->hasFormat("application/SUIEditor/WidgetController"))
    {
        if (event->source() == this)
        {
            event->setDropAction(mDropAction);
            event->accept();
        }
        else
        {
            event->acceptProposedAction();
        }
    }
    else
    {
        event->ignore();
    }
}

/*****************************************************************************\
 * FUNCTION : dropEvent
 * PARAMETERS : QDropEvent *event
 * RETURN : void
 *
 * This function is a reimplementation of QLabel's virtual protected function.
 * There are a number of different drop situations.
 * - This is when a widget is dragged from the WidgetSelector. The original
 * widget ha sto remain there, so a copy is made, which will have to get
 * its own ID.
 * - This is when the parent of the dragged widget is the same as this. That
 * means that the widget is just moved within its parent widget.
 * - This is when a widget is draaged from the FormEditor and dropped onto
 * the WidgetSelector. This means that the widget is deleted.
 * - This is when a widget is dragged from a different parent widget onto this
 * parent widget. That means that it has to be copied to a newly created
 * widget into this and the original widget has to be deleted. The third
 * parameter of addToWidget(), being false, indecates that the ID is being
 * copied to the new widget.
 * - This is when a GroupBox widget is being moved and the new cursor position
 * is still within that same GroupBox. That means that the GroupBox is just
 * being moved.
 *
 * To prevent a lot of Property Table Widget and Object Tree View updating
 * overhead, the SIGNAL - SLOT connections handling this, are temporarely
 * disabled.
 *
 * In the WidgetSelector, the RticTableWidget is displayed with one row and
 * column. If dragged to the FormEditor, this row and column are removed.
 *
 * When dragging a UserControl to the WidgetSelector (or UserControl Selector),
 * the application crashes regurlarly. Not setting pNewDDWidg = NULL in this
 * code section, seems to help. Since this always happens somewhere in the
 * EventLoop, it is not really clear what causes this.
 *
 \****************************************************************************/
void WidgetController::dropEvent(QDropEvent *event)
{
    WidgetControllerInfo *dragDropInfo = Model::instance()->mWidgetDragged;
    if ((event->mimeData()->hasFormat("application/SUIEditor/WidgetController")) &&
            !((dragDropInfo->getDraggedWidget()->getStartPoint() == event->pos()) && (dragDropInfo->getParentWidget() == this->getParent())))
    {
        bool bWidgetDeleted = false;
        bool bIsUserControl = false;
        bool widgetsMoved = false;
        WidgetController *pNewDDWidg = dragDropInfo->getDraggedWidget();
        WidgetController *wcDropWidget = this;
        QString widgetTypeString;
        QPoint offset;
        QByteArray itemData = event->mimeData()->data( "application/SUIEditor/WidgetController" );
        QDataStream dataStream( &itemData, QIODevice::ReadOnly );

        QList<WidgetController *> copySelList = Model::instance()->getSelectionList();
        QPoint eventPos = event->pos();

        dataStream >> widgetTypeString >> offset;
        SUI::ObjectType::Type widgetType = SUI::ObjectType::fromString(widgetTypeString.toStdString());
        QPoint position = eventPos - offset;

        Model::instance()->getModelHandler()->sendDisableShowProperties(__FUNCTION__);

        if (mMode != WidgetSelectorMode)
        {
            // If this (= wcDropWidget) is a child of a UserControl,
            // move upwards until we got to that UserControl's parent.
            // Because we are not allowed to drop a widget within a
            // UserControl so we drop it on it's parent instead.
            while (wcDropWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::UserControl).isEmpty() == false)
                wcDropWidget = wcDropWidget->getParent() ? wcDropWidget->getParent() : dragDropInfo->getParentWidget();
        }

        if (wcDropWidget != this) {
            position = this->mapTo(wcDropWidget, position);
            eventPos = this->mapTo(wcDropWidget, eventPos);
        }

        if (dragDropInfo->getParentWidget() == NULL) {
            if (mMode != WidgetSelectorMode) {
                // Is from Widget Selector, create a new instance and add it as child of this widget
                if (getId() == QString("rbbRight")) {
                    if ((widgetType != SUI::ObjectType::Button) && (widgetType != SUI::ObjectType::Label))
                        return;

                    int dX = ((getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt()) - dragDropInfo->getDraggedWidget()->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt()) / 2;
                    position.setX(dX);
                }
                else if ((getId() == QString("rbbBottom")) || (getId() == QString("rbbStatus")) || getObjectType() == SUI::ObjectType::TabWidget)
                {
                    return;
                }
                WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo(NULL, ACT_NEW, "New Widget");
                position.setX(position.x() < 0 ? 0 : position.x());
                position.setY(position.y() < 0 ? 0 : position.y());
                if (Model::instance()->gridActive()) {
                    position = Model::instance()->formEditor()->snapToGrid(position);
                }
                dragDropInfo->getDraggedWidget()->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, QString::number(position.x()));
                dragDropInfo->getDraggedWidget()->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, QString::number(position.y()));
                dragDropInfo->getDraggedWidget()->setPropertyValue(SUI::ObjectPropertyTypeEnum::ObjectType, QString::fromStdString(SUI::ObjectType::toString(widgetType)));

                WidgetDefinition newDefinition;
                dragDropInfo->getDraggedWidget()->acceptVisitor(newDefinition);
                pNewDDWidg = newDefinition.addToWidget(wcDropWidget, true);
                if (widgetType == SUI::ObjectType::TableWidget) {
                    dynamic_cast<SUI::TableWidgetImpl *>(pNewDDWidg->getBaseWidget())->clearItems();
                }
                else if (widgetType == SUI::ObjectType::UserControl) {
                    pNewDDWidg->renameChildren(pNewDDWidg->getId());
                    Model::instance()->addUsedUserControl(pNewDDWidg->getId());
                }
                else if (widgetType == SUI::ObjectType::ListView) {
                    dynamic_cast<SUI::ListViewImpl *>(pNewDDWidg->getBaseWidget())->clearItems();
                }

                if (pNewDDWidg->getPropertyList().contains(SUI::ObjectPropertyTypeEnum::TabOrder)) {
                    tabReorder();
                    pNewDDWidg->getBaseWidget()->setPropertyValue(SUI::ObjectPropertyTypeEnum::TabOrder,
                                                                  QString::number(dynamic_cast<SUI::BasePageImpl *>(Model::instance()->getCurrentTopPage()->getBaseWidget())->addTabOrder("", pNewDDWidg->getId())));
                }
                QList<WidgetController *> wcList;
                wcList.append(pNewDDWidg);
                UndoHandler::instance()->finishUndoInfo(wsState, pNewDDWidg);
                UndoHandler::instance()->addToUndoGroup(wsState);
            }
            else {
                dragDropInfo->getDraggedWidget()->setSelected(false);
                dragDropInfo->getDraggedWidget()->updatePixmap();
                pNewDDWidg = NULL;
                bWidgetDeleted = true;
            }
        }
        else {
            if (dragDropInfo->getParentWidget() == wcDropWidget) {
                // Moved within this widget
                if (getId() == QString("rbbRight")) {
                    int dX = ((getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt())
                              - dragDropInfo->getDraggedWidget()->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt()) / 2;
                    position.setX(dX);
                }
                if ((getId() != QString("rbbBottom")) && (getId() != QString("rbbStatus"))) {
                    if (!((position.x() == 0) && (position.y() == 0)) &&
                            (dragDropInfo->getDraggedWidget()->getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt() != position.x() ||
                             dragDropInfo->getDraggedWidget()->getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt() != position.y()))
                    {
                        QList<WidgetState *> wsStateList;
                        BOOST_FOREACH(WidgetController * wdgt, Model::instance()->getSelectionList())
                        {
                            WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo(wdgt, ACT_MOVE, "Move Widget");
                            QPoint dropPoint = eventPos - QPoint(offset - QPoint(QPoint(wdgt->getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt(), wdgt->getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt())));

                            if (Model::instance()->gridActive()) {
                                dropPoint = Model::instance()->formEditor()->snapToGrid(dropPoint);
                            }
                            wdgt->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, QString::number(dropPoint.x()));
                            wdgt->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, QString::number(dropPoint.y()));
                            UndoHandler::instance()->finishUndoInfo(wsState, wdgt);
                            wsStateList.append(wsState);
                            wdgt->move(wdgt->getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt(), wdgt->getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt());
                            Model::instance()->getModelHandler()->newWidgetProperties(wdgt);
                        }
                        UndoHandler::instance()->addToUndoGroup(wsStateList);
                        Model::instance()->setDataChanged(true);
                    }
                }
            }
            else
            {
                if (mMode == WidgetSelectorMode) {
                    bool taborder = false;
                    // The widget is dropped to the selector, so it is deleted
                    // Remove the widget from its old parent and from the list of widgets
                    QList<WidgetState *> wsStateList;
                    BOOST_FOREACH(WidgetController * wdgt, Model::instance()->getSelectionList())
                    {
                        WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo(wdgt, ACT_DELETE, "Delete Widget");
                        wdgt->setSelected(false);
                        if (wdgt->getParent() != NULL)
                        {
                            wdgt->getParent()->removeChild(wdgt);
                        }
                        if (wdgt->getObjectType() == SUI::ObjectType::UserControl)
                        {
                            //If the removed widget is a UserControl, set bIsUserControl true
                            bIsUserControl = true;
                            Model::instance()->removeUsedUserControl(wdgt->getId());
                        }
                        if (wdgt->getPropertyList().contains(SUI::ObjectPropertyTypeEnum::TabOrder))
                        {
                            dynamic_cast<SUI::BasePageImpl *>(Model::instance()->getCurrentTopPage()->getBaseWidget())->removeTabOrder(wdgt->getId());
                            taborder = true;
                        }
                        wdgt->removeFromModel();
                        wdgt->deleteLater();
                        UndoHandler::instance()->finishUndoInfo(wsState, NULL);
                        wsStateList.append(wsState);
                    }
                    UndoHandler::instance()->addToUndoGroup(wsStateList);


                    // The next line can not be moved to the end of this function, because that can cause a segmentation fault,
                    // when repeating the adding and deleting of a UserControl a number of times. This segmentation fault,
                    // happens somewhere in the EventLoop and can not be pinpointed.
                    Model::instance()->getModelHandler()->newWidgetProperties(NULL);
                    QApplication::syncX();
                    QCoreApplication::flush();

                    bWidgetDeleted = true;
                    if (taborder)
                    {
                        tabReorder();
                    }
                }
                else
                {
                    QPoint newPoint = position;
                    if (wcDropWidget != dragDropInfo->getDraggedWidget() &&
                            (wcDropWidget->isChildOfDDWidget(dragDropInfo->getDraggedWidget(), newPoint) == false) &&
                            (Model::instance()->getSelectionList().contains(wcDropWidget) == false))
                    {
                        // The widget is moved from another widget to this one. Create a new instance.
                        if (getId() == QString("rbbRight"))
                        {
                            if ((widgetType != SUI::ObjectType::Button) && (widgetType != SUI::ObjectType::Label))
                            {
                                dragDropInfo->getDraggedWidget()->updatePixmap();
                                return;
                            }
                            int dX = ((getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt()) - dragDropInfo->getDraggedWidget()->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt()) / 2;
                            position.setX(dX);
                        }
                        else if ((getId() == QString("rbbBottom")) || (getId() == QString("rbbStatus")))
                        {
                            dragDropInfo->getDraggedWidget()->updatePixmap();
                            return;
                        }
                        copySelList.clear();
                        QList<WidgetState *> wsStateList;
                        BOOST_FOREACH(WidgetController * wdgt, Model::instance()->getSelectionList())
                        {
                            WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo(wdgt, ACT_MOVE, "Move Widget");
                            QPoint dropPoint = eventPos - QPoint(offset - QPoint(wdgt->getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt(), wdgt->getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt()));

                            if (Model::instance()->gridActive())
                            {
                                dropPoint = Model::instance()->formEditor()->snapToGrid(dropPoint);
                            }
                            WidgetDefinition newDefinition;
                            wdgt->acceptVisitor(newDefinition);
                            pNewDDWidg = newDefinition.addToWidget(wcDropWidget, false);
                            pNewDDWidg->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, QString::number(dropPoint.x()));
                            pNewDDWidg->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, QString::number(dropPoint.y()));

                            copySelList.append(pNewDDWidg);
                            UndoHandler::instance()->finishUndoInfo(wsState, pNewDDWidg);
                            wsStateList.append(wsState);

                            if (wdgt->getParent() != NULL)
                            {
                                wdgt->getParent()->removeChild(wdgt);
                            }
                            Model::instance()->removeFromSelectionList(wdgt);
                            wdgt->deleteLater();
                            widgetsMoved = true;
                        }
                        UndoHandler::instance()->addToUndoGroup(wsStateList);

                        QApplication::processEvents();
                        dragDropInfo->setDraggedWidget(NULL);
                    }
                    else
                    {
                        // This is the case when moving a groupbox or tabwidget and the new cursor position
                        // is still within this old groupbox or tabwiget/tabpage area or a subchild area.
                        QList<WidgetState *> wsStateList;
                        BOOST_FOREACH(WidgetController * wcTmp, Model::instance()->getSelectionList())
                        {
                            QPoint widgPoint = QPoint(wcTmp->getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt(), wcTmp->getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt());
                            QPoint mapPoint = this->mapTo(wcTmp->getParent(), eventPos);
                            QPoint dropPoint = QPoint(widgPoint.x() + (mapPoint.x() - offset.x()), widgPoint.y() + (mapPoint.y() - offset.y()));

                            if (widgPoint != dropPoint)
                            {
                                WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo(wcTmp, ACT_MOVE, "Move Widget");
                                if (Model::instance()->gridActive())
                                {
                                    dropPoint = Model::instance()->formEditor()->snapToGrid(dropPoint);
                                }
                                wcTmp->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, QString::number(dropPoint.x()));
                                wcTmp->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, QString::number(dropPoint.y()));
                                wcTmp->move(dropPoint.x(), dropPoint.y());
                                UndoHandler::instance()->finishUndoInfo(wsState, wcTmp);
                                wsStateList.append(wsState);
                            }
                        }
                        UndoHandler::instance()->addToUndoGroup(wsStateList);
                        Model::instance()->setDataChanged(true);
                    }
                }
            }
        }
        if (event->source() == this)
        {
            event->setDropAction(mDropAction);
            event->accept();
        }
        else
        {
            event->acceptProposedAction();
        }

        QApplication::processEvents();
        if (bWidgetDeleted == false)
        {
            Model::instance()->getModelHandler()->sendNewWidget();
            if (widgetsMoved)
            {
                BOOST_FOREACH(WidgetController * wdgt, copySelList)
                {
                    Model::instance()->addToSelectionList(wdgt);
                }
            }
            else
            {
                if (!Model::instance()->hasSelectionList())
                {
                    Model::instance()->setNewSelected(pNewDDWidg);
                }
            }
            // If an User Control is deleted, bWidgetDeleted will be false (as part of workaround). Therefore
            // we need to check if bIsUserControl is true or false. If true, set call newWidgetProperties(NULL)
            // to clear the shown properties.
            if (bIsUserControl)
            {
                Model::instance()->getModelHandler()->newWidgetProperties(NULL);
            }

        }
        else
        {
            Model::instance()->setNewSelected(NULL);
            Model::instance()->getModelHandler()->sendNewWidget();
        }
        Model::instance()->getModelHandler()->sendEnableShowProperties(__FUNCTION__);
    }
    else
    {
        event->ignore();
    }
    delete dragDropInfo;
    dragDropInfo = NULL;
    QApplication::syncX();
    QApplication::flush();

}

/*****************************************************************************\
 * FUNCTION : updatePixmap
 * PARAMETERS : void
 * RETURN : void
 *
 * This function updates the underlying QWidget and this (being a QLabel
 * subclass).
 \****************************************************************************/
void WidgetController::updatePixmap()
{
    // Start by updating the underlaying widget
    if ((this->mMode == ParentWidgetMode) && (getObjectType() != SUI::ObjectType::TableWidget))
    {
        for (int ind = 0; ind < mChildren.size(); ++ind)
        {
            mChildren[ind]->updatePixmap();
        }
    }
    if (mSUIBaseWidget != NULL)
    {
        if ( mSUIBaseWidget->getWidget() != NULL )
        {
            setPixmap(QPixmap::grabWidget(mSUIBaseWidget->getWidget()));
            this->setGeometry(getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt(),
                              getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt(),
                              mSUIBaseWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt(),
                              mSUIBaseWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt());
            this->update();
            mSUIBaseWidget->getWidget()->update();
            if (Model::instance()->getFormEditor() != NULL)
            {
                const_cast<FormEditor*>(Model::instance()->getFormEditor())->update();
            }
        }
    }
}

/*****************************************************************************\
 * FUNCTION : mousePressEvent
 * PARAMETERS : QMouseEvent *event
 * RETURN : void
 *
 * This function is a reimplementation of QLabel's virtual protected function.
 * This function is being called twice, when a user clicks the mouse button.
 * The first time RticWidget will become NULL. The second time it will point
 * to the widget being clicked on. The Main Tab Widget and Tab Pages are not
 * allowed to be copied, moved or deleted.
 * When a widget is selected, mimedata is being filled and a temporary Pixmap
 * is being created to show the original widget when moving the dragged widget.
 * Furthermore, a DragAndDropInfo instance is created, to save to imported
 * data of the dragged widget.
 * This function also handles right mouse button clicks. In case this is a
 * Tab Widget, HandleTabWidgetMenu is being called.
 *
 * To prefent a user from clicking on a Widget which is still being drawn
 * (by dropEvent()), a kind of mutex is used, implemented in Model. When
 * drag->exec is finished, the dropEvent function() is finished as well.
 *
 * Release 11:
 * UserControls are now shown in the UserControl selector as 'thumbnails'.
 * These thumbnails are WidgetControllers with a scaled QImage. When being
 * dragged from the selector, a copy is made from the UserControl, retrieved
 * from the Models UserControl list, with the same ID. This copy is then being
 * dragged upon the form.
 \****************************************************************************/
void WidgetController::mousePressEvent(QMouseEvent *event) {
    WidgetController *widgetController = dynamic_cast<WidgetController *>(childAt(event->pos()));

    Qt::MouseButtons mouseButtons = event->buttons();
    if (mouseButtons == Qt::LeftButton) {
        mStartPoint = event->pos();
        if (widgetController != NULL) {
            WidgetController *topdownChild = widgetController;
            QPoint newPoint = event->pos() - widgetController->pos();

            // If RticWidget is a child of a UserControl, move upwards until we got to that UserControl.
            // Because that is the Widget we are dealing with.
            while ( (widgetController->getParent() != NULL) &&
                   (widgetController->getParent()->getBaseWidget() != NULL) &&
                   (widgetController->getObjectType() != SUI::ObjectType::UserControl) &&
                   (widgetController->getParent()->getPropertyValue(SUI::ObjectPropertyTypeEnum::UserControl).isEmpty() == false) )
            {
                widgetController = widgetController->getParent();
            }
            if (widgetController != topdownChild) newPoint = topdownChild->getParent()->mapTo(widgetController, event->pos());
            if (widgetController->getObjectType() == SUI::ObjectType::ImageWidget) widgetController = Model::instance()->retrieveFromStore(widgetController->getId());
            if (widgetController->getObjectType() == SUI::ObjectType::TabWidget) {
                SUI::TabWidgetImpl *tabWidget = dynamic_cast<SUI::TabWidgetImpl *>(widgetController->getBaseWidget());
                int index = tabWidget->getWidget()->getTabBar()->tabAt(newPoint);
                if (index != tabWidget->getCurrentIndex()) {
                    tabWidget->setCurrentTabPage(index);
                    Model::instance()->selectNewWidget(QString::fromStdString(tabWidget->getCurrentTabPage()->getId()));
                    widgetController->tabReorder();
                }
            }

            if (Model::instance()->acquire(widgetController) == false) return;

            if (widgetController->getPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable).toLower() == "true") {
                if ((newPoint.x() <= mButtomResizeBound || newPoint.y() <= mButtomResizeBound
                     || newPoint.x() >= widgetController->width() - mButtomResizeBound
                     || newPoint.y() >= widgetController->height() - mButtomResizeBound)
                        && widgetController->getPropertyValue(SUI::ObjectPropertyTypeEnum::Sizeable).toLower() == "true")
                {
                    Model::instance()->setCurrentWidget(widgetController);
                }
                else {
                    if (Model::instance()->isCtrlPressed()) {
                        Model::instance()->addToSelectionList(widgetController);
                    }
                    else {
                        Model::instance()->setNewSelected(widgetController);
                    }

                    performDrag(newPoint, widgetController);
                }
            }
            else {
                Model::instance()->getModelHandler()->sendNewWidget();
                if (widgetController->isWidgetSelector() == false)
                {
                    Model::instance()->setNewSelected(widgetController);
                }
            }
            Model::instance()->release(widgetController);
        }
        else {
            if ((mParent != NULL) && (mParent->objectName() != "widgetSelector")) {
                mRubberBandrect.setTopLeft(event->pos());
                mRubberBandrect.setTopRight(event->pos());
                updateRubberBandRegion();
            }
            this->update();
            Model::instance()->setNewSelected(NULL);
            // Do not handle the event. Make sure it is propagated up the parent widget chain
            event->ignore();
        }
    }
}

/*****************************************************************************\
 * FUNCTION : mouseMoveEvent
 * PARAMETERS : QMouseEvent *event
 * RETURN : void
 *
 * This function is a reimplementation of QLabel's virtual protected function.
 \****************************************************************************/
void WidgetController::mouseMoveEvent(QMouseEvent *event)
{
    if ((mParent != NULL && mParent->objectName() != "widgetSelector") && (this->hasUCtrlParent() == false) &&
            (this != Model::instance()->getTopWidget()) && (getObjectType() != SUI::ObjectType::TabPage))
    {
        if (!(event->buttons() & Qt::LeftButton))
        {
            if (event->x() <= mButtomResizeBound && event->y() <= mButtomResizeBound && mSUIBaseWidget->isHeightExposed() == true && mSUIBaseWidget->isWidthExposed() == true)
            {
                mStartPos = topleft;
                setCursor(Qt::SizeFDiagCursor);
            }
            else if (event->x() <= mButtomResizeBound && event->y() >= height() - mButtomResizeBound && mSUIBaseWidget->isHeightExposed() == true && mSUIBaseWidget->isWidthExposed() == true)
            {
                mStartPos = bottomleft;
                setCursor(Qt::SizeBDiagCursor);
            }
            else if (event->x() >= width() - mButtomResizeBound && event->y() <= mButtomResizeBound && mSUIBaseWidget->isHeightExposed() == true && mSUIBaseWidget->isWidthExposed() == true)
            {
                mStartPos = topright;
                setCursor(Qt::SizeBDiagCursor);
            }
            else if (event->x() >= width() - mButtomResizeBound && event->y() >= height() - mButtomResizeBound && mSUIBaseWidget->isHeightExposed() == true && mSUIBaseWidget->isWidthExposed() == true)
            {
                mStartPos = bottomright;
                setCursor(Qt::SizeFDiagCursor);
            }
            else if (event->x() <= mButtomResizeBound && mSUIBaseWidget->isWidthExposed() == true)
            {
                mStartPos = left;
                setCursor(Qt::SizeHorCursor);
            }
            else if (event->x() >= width() - mButtomResizeBound && mSUIBaseWidget->isWidthExposed() == true)
            {
                mStartPos = right;
                setCursor(Qt::SizeHorCursor);
            }
            else if (event->y() <= mButtomResizeBound && mSUIBaseWidget->isHeightExposed() == true)
            {
                mStartPos = top;
                setCursor(Qt::SizeVerCursor);
            }
            else if (event->y() >= height() - mButtomResizeBound && mSUIBaseWidget->isHeightExposed() == true)
            {
                mStartPos = bottom;
                setCursor(Qt::SizeVerCursor);

            }
            else
            {
                mStartPos = smove;
                setCursor(Qt::ArrowCursor);
            }
            return;
        }

        QPoint snapPoint(event->x(), event->y());
        switch (mStartPos)
        {
        case topleft:
            if ( mUndoState == NULL ) {
                mUndoState = UndoHandler::instance()->getNewUndoInfo(this, ACT_PROPERTY, "Resize Widget");
            }

            if (Model::instance()->gridActive()) {
                snapPoint = snapToGrid(snapPoint);
            }

            mSUIBaseWidget->incrementPropertyValue(SUI::ObjectPropertyTypeEnum::Height, - snapPoint.y());
            mSUIBaseWidget->incrementPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, snapPoint.y());
            mSUIBaseWidget->incrementPropertyValue(SUI::ObjectPropertyTypeEnum::Width, - snapPoint.x());
            mSUIBaseWidget->incrementPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, snapPoint.x());

            updatePixmap();
            Model::instance()->getModelHandler()->newWidgetProperties(this);
            break;

        case bottomleft:
            if ( mUndoState == NULL ) {
                mUndoState = UndoHandler::instance()->getNewUndoInfo(this, ACT_PROPERTY, "Resize Widget");
            }

            if (Model::instance()->gridActive()) {
                snapPoint = snapToGrid(snapPoint);
            }

            mSUIBaseWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, QString::number(snapPoint.y()));
            mSUIBaseWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, QString::number(mSUIBaseWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt() - snapPoint.x()));
            mSUIBaseWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, QString::number(mSUIBaseWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt() + snapPoint.x()));

            updatePixmap();
            Model::instance()->getModelHandler()->newWidgetProperties(this);
            break;

        case topright:
            if ( mUndoState == NULL ) {
                mUndoState = UndoHandler::instance()->getNewUndoInfo(this, ACT_PROPERTY, "Resize Widget");
            }

            if (Model::instance()->gridActive()) {
                snapPoint = snapToGrid(snapPoint);
            }

            mSUIBaseWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, QString::number(mSUIBaseWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt() - snapPoint.y()));
            mSUIBaseWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, QString::number(mSUIBaseWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt() + snapPoint.y()));
            mSUIBaseWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, QString::number(snapPoint.x()));

            updatePixmap();
            Model::instance()->getModelHandler()->newWidgetProperties(this);
            break;

        case bottomright:
            if ( mUndoState == NULL ) {
                mUndoState = UndoHandler::instance()->getNewUndoInfo(this, ACT_PROPERTY, "Resize Widget");
            }

            if (Model::instance()->gridActive())
                snapPoint = snapToGrid(snapPoint);

            mSUIBaseWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, QString::number(snapPoint.x()));
            mSUIBaseWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, QString::number(snapPoint.y()));
            updatePixmap();
            Model::instance()->getModelHandler()->newWidgetProperties(this);
            break;

        case left:
            if ( mUndoState == NULL ) {
                mUndoState = UndoHandler::instance()->getNewUndoInfo(this, ACT_PROPERTY, "Resize Widget");
            }

            if (Model::instance()->gridActive()) {
                snapPoint = snapToGrid(snapPoint);
            }

            mSUIBaseWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, QString::number(mSUIBaseWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt() - snapPoint.x()));
            mSUIBaseWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, QString::number(mSUIBaseWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt() + snapPoint.x()));
            updatePixmap();
            Model::instance()->getModelHandler()->newWidgetProperties(this);
            break;

        case right:
            if ( mUndoState == NULL ) {
                mUndoState = UndoHandler::instance()->getNewUndoInfo(this, ACT_PROPERTY, "Resize Widget");
            }

            if (Model::instance()->gridActive()) {
                snapPoint = snapToGrid(snapPoint);
            }

            mSUIBaseWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, QString::number(snapPoint.x()));
            updatePixmap();
            Model::instance()->getModelHandler()->newWidgetProperties(this);
            break;

        case top:
            if ( mUndoState == NULL ) {
                mUndoState = UndoHandler::instance()->getNewUndoInfo(this, ACT_PROPERTY, "Resize Widget");
            }
            if (Model::instance()->gridActive()) {
                snapPoint = snapToGrid(snapPoint);
            }

            mSUIBaseWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, QString::number(mSUIBaseWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt() - snapPoint.y()));
            mSUIBaseWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, QString::number(mSUIBaseWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt() + snapPoint.y()));
            updatePixmap();
            Model::instance()->getModelHandler()->newWidgetProperties(this);
            break;

        case bottom:
            if ( mUndoState == NULL ) {
                mUndoState = UndoHandler::instance()->getNewUndoInfo(this, ACT_PROPERTY, "Resize Widget");
            }

            if (Model::instance()->gridActive()) {
                snapPoint = snapToGrid(snapPoint);
            }

            mSUIBaseWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, QString::number(snapPoint.y()));

            Model::instance()->getModelHandler()->newWidgetProperties(this);
            this->updatePixmap();
            break;

        default:
            break;
        }
        if ((mStartPos >= topleft) && (mStartPos < smove)) Model::instance()->setDataChanged(true);

        if (getObjectType() == SUI::ObjectType::TabWidget) this->tabWidgetResized();
    }
    if (((mParent != NULL) && mParent->objectName() != "widgetSelector") &&
            ((event->buttons() & Qt::LeftButton) == Qt::LeftButton) &&
            (this != Model::instance()->getMainTabWidget()) && (mStartPos == smove)) {
        if (this == Model::instance()->getCurrentMainTabPage() || this == Model::instance()->getTopWidget()) {
            // Drag Rubberband to select multiple widgets
            mRubberBandShown = true;
            setCursor(Qt::CrossCursor);
            updateRubberBandRegion();
            mRubberBandrect.setBottomRight(event->pos());
            updateRubberBandRegion();
        }
    }
}

/*****************************************************************************\
 * FUNCTION : performDrag
 * PARAMETERS : QPoint point
 * point of where the drag starts
 * WidgetController* curWidg
 * The widget where is pressed
 * RETURN : void
 *
 * This function will take care of the dragged widgets
 \****************************************************************************/
void WidgetController::performDrag(QPoint point, WidgetController *widgetController)
{
    if ( widgetController == NULL ) {
        if (mSUIBaseWidget != NULL ) widgetController = Model::instance()->getWidgetController(QString::fromStdString(mSUIBaseWidget->getId()));
    }

    BOOST_FOREACH(WidgetController * wcTopWidget, Model::instance()->getSelectionList()) {
        if (Model::instance()->getSelectionList().contains(wcTopWidget->mParent) == true) {
            widgetController = wcTopWidget->mParent;
            Model::instance()->removeFromSelectionList(wcTopWidget);
            wcTopWidget->setSelected(false);
        }
    }


    if (Model::instance()->getSelectionList().contains(Model::instance()->getTopWidget()) == TRUE) {
        Model::instance()->removeFromSelectionList(Model::instance()->getTopWidget());
        Model::instance()->getTopWidget()->setSelected(false);
    }

    if ( (widgetController != NULL) && (widgetController->getPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable).toLower() == "true") ) {
        QPixmap pixmap;
        QByteArray itemData;
        QDataStream dataStream(&itemData, QIODevice::WriteOnly);
        if (mMode == WidgetSelectorMode) {
            pixmap = *widgetController->pixmap();
            dataStream << QString::fromStdString(SUI::ObjectType::toString(widgetController->getObjectType())) << point;
        }
        else {
            pixmap = makeFramePixmap(point, widgetController);
            dataStream << QString::fromStdString(SUI::ObjectType::toString(widgetController->getObjectType())) << widgetController->mapToParent(point);
            point = mStartPoint;
        }

        QMimeData *mimeData = new QMimeData;
        mimeData->setData("application/SUIEditor/WidgetController", itemData);

        QDrag *drag = new QDrag(this);
        drag->setMimeData(mimeData);
        drag->setPixmap(pixmap);
        drag->setHotSpot(point);

        WidgetController *parentWidget = widgetController->getParent();
        if (mMode == WidgetSelectorMode) {
            // Parent widget of dragdropinfo is used to delete children when needed
            // but we never want to delete children from our selector
            parentWidget = NULL;
        }
        // DDInfo will be deleted in dropEvent() as dragDropInfo
        WidgetControllerInfo *DDInfo = new WidgetControllerInfo(parentWidget, widgetController);

        Model::instance()->mWidgetDragged = DDInfo;

        if (drag->exec(mDropAction, mDropAction) != Qt::MoveAction) {
            if (mMode == WidgetSelectorMode) {
                widgetController->show();
                widgetController->setPixmap(pixmap);
            }
        }

        Model::instance()->setDataChanged();
    }

}

void WidgetController::mouseReleaseEvent(QMouseEvent *event) {
    Q_UNUSED(event);
    if (mRubberBandShown) {

        mRubberBandShown = false;

        QRect rect = updateRubberBandRegion();
        int xRect = rect.x();
        int yRect = rect.y();

        if (qAbs(mRubberBandrect.height()) > 8 || qAbs(mRubberBandrect.width()) > 8)
        {
            Model::instance()->deselectAll();
            Model::instance()->setCtrlPressed(true);
            BOOST_FOREACH(WidgetController * childController, mChildren) {
                int X = childController->getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt();
                int Y = childController->getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt();
                if (X > xRect && Y > yRect
                        && (xRect + rect.width()) > (X + childController->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt())
                        && (yRect + rect.height()) > (Y + childController->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt()))
                {
                    Model::instance()->setNewSelected(childController);
                    Model::instance()->getModelHandler()->newWidgetProperties(childController);
                }
            }
            Model::instance()->getModelHandler()->sendEnableShowProperties(__FUNCTION__);
            Model::instance()->setCtrlPressed(false);
        }
        unsetCursor();
    }
    else {
        if ( mUndoState != NULL ) {
            UndoHandler::instance()->finishUndoInfo(mUndoState, this);
            UndoHandler::instance()->addToUndoGroup(mUndoState);
            // It is UndoHandler's responsibility to manage the WidgetState's memory
            mUndoState = NULL;
        }
    }
}

/*****************************************************************************\
 * FUNCTION : updateRubberBandRegion
 * PARAMETERS : N.A.
 * RETURN : QRect
 *
 * This function sets the rubberband selection
 \****************************************************************************/
QRect WidgetController::updateRubberBandRegion() {
    QRect rect = mRubberBandrect.normalized();
    update(rect.left(), rect.top(), rect.width(), 1);
    update(rect.left(), rect.top(), 1, rect.height());
    update(rect.left(), rect.bottom(), rect.width(), 1);
    update(rect.right(), rect.top(), 1, rect.height());
    return rect;
}


/*****************************************************************************\
 * FUNCTION : paintEvent
 * PARAMETERS : QPaintEvent *paintEvent
 * RETURN : void
 *
 * This function is a reimplementation of QLabel's virtual protected function.
 * It is being called whenever this widgets update() function is called.
 * If the mIsSelected is true, drawSelected() is called, which draws the blue
 * rectangles to indicate that this widget is selected.
 \****************************************************************************/
void WidgetController::paintEvent(QPaintEvent *paintEvent) {
    QLabel::paintEvent(paintEvent);
    if (mIsSelected) drawSelected();
    QStylePainter painter(this);

    if (mRubberBandShown && supportsChildren()) {
        QPen p;
        p.setColor(Qt::gray);
        p.setStyle(Qt::DashLine);
        painter.setPen(p);
        painter.drawRect(mRubberBandrect.normalized().adjusted(0, 0, -1, -1));
    }
}

/*****************************************************************************\
 * FUNCTION : keyPressEvent
 * PARAMETERS : QKeyEvent *ke
 * RETURN : void
 *
 * This is a virtual function to handle the key events. Here we want to handle
 * the arrow keys. If more than one widget is selected all selected widgets are
 * moved.
 \****************************************************************************/
void WidgetController::keyPressEvent(QKeyEvent *ke) {
    WidgetController *curWidg = NULL;

    if ((mMode != WidgetSelectorMode) && (Model::instance()->getSelectionList().size() > 0)) {
        QList<WidgetController *> wcList;
        QList<WidgetState *> wsStateList;
        for (int ind = 0; ind < Model::instance()->getSelectionList().size(); ++ind) {
            curWidg = Model::instance()->getSelectionList()[ind];

            if (curWidg != NULL)
            {
                bool bMoveable = false;
                while (!curWidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::UserControl).isEmpty() && (curWidg->getObjectType() != SUI::ObjectType::UserControl))
                {
                    curWidg = curWidg->getParent();
                }

                if ( (curWidg != NULL) && (curWidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable).toLower() != "false") &&
                        (curWidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::UserControl).isEmpty() || (curWidg->getObjectType() == SUI::ObjectType::UserControl)))
                {
                    bMoveable = true;
                }
                int dXStepSize = 1;
                int dYStepSize = 1;
                if (Model::instance()->gridActive() && Model::instance()->xSnap())
                {
                    dXStepSize = Model::instance()->XGridDistance();
                }
                else if (Model::instance()->isCtrlPressed())
                {
                    dXStepSize = 5;
                }
                if (Model::instance()->gridActive() && Model::instance()->ySnap())
                {
                    dYStepSize = Model::instance()->YGridDistance();
                }
                else if (Model::instance()->isCtrlPressed())
                {
                    dYStepSize = 5;
                }

                bool bAddToUndoMove = false;
                int newXPos = curWidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt();
                int newYPos = curWidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt();
                WidgetState *wsState = NULL;
                switch (ke->key())
                {
                case Qt::Key_Up:
                    if (bMoveable)
                    {
                        wsState = UndoHandler::instance()->getNewUndoInfo(curWidg, ACT_MOVE, "Move Up");
                        newYPos = (curWidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt() - dYStepSize) < 0 ?
                                    0 : curWidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt() - dYStepSize;
                        bAddToUndoMove = true;
                    }
                    break;
                case Qt::Key_Down:
                    if (bMoveable)
                    {
                        wsState = UndoHandler::instance()->getNewUndoInfo(curWidg, ACT_MOVE, "Move Down");
                        newYPos = curWidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt() + dYStepSize;
                        bAddToUndoMove = true;
                    }
                    break;
                case Qt::Key_Left:
                    if (bMoveable)
                    {
                        wsState = UndoHandler::instance()->getNewUndoInfo(curWidg, ACT_MOVE, "Move Left");
                        newXPos = (curWidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt() - dXStepSize) < 0 ?
                                    0 : curWidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt() - dXStepSize;
                        bAddToUndoMove = true;
                    }
                    break;
                case Qt::Key_Right:
                    if (bMoveable)
                    {
                        wsState = UndoHandler::instance()->getNewUndoInfo(curWidg, ACT_MOVE, "Move Right");
                        newXPos = curWidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt() + dXStepSize;
                        bAddToUndoMove = true;
                    }
                    break;
                default:
                    QWidget::keyPressEvent(ke);
                    break;
                }
                if (bAddToUndoMove)
                {
                    QPoint newPoint(newXPos, newYPos);
                    if (Model::instance()->gridActive())
                    {
                        newPoint = snapToGrid(newPoint);
                    }
                    curWidg->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, QString::number(newPoint.x()));
                    curWidg->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, QString::number(newPoint.y()));
                    Model::instance()->getModelHandler()->newWidgetProperties(curWidg);
                    UndoHandler::instance()->finishUndoInfo(wsState, curWidg);
                    wsStateList.append(wsState);
                }
                else
                {
                    UndoHandler::instance()->deleteWidgetState(wsState);
                }
            }
        }
        UndoHandler::instance()->addToUndoGroup(wsStateList);
        Model::instance()->setDataChanged(true);
    }
    if (ke->key() == Qt::Key_Control || ke->key() == Qt::Key_Shift)
    {
        Model::instance()->setCtrlPressed(true);
    }
}

/*****************************************************************************\
 * FUNCTION : keyReleaseEvent
 * PARAMETERS : QKeyEvent *ke
 * RETURN : void
 *
 * This is a virtual function to handle the key events. Here we want to handle
 * the Ctrl key,
 \****************************************************************************/
void WidgetController::keyReleaseEvent(QKeyEvent *ke) {
    if (ke->key() == Qt::Key_Control || ke->key() == Qt::Key_Shift) Model::instance()->setCtrlReleased();
}

void WidgetController::addProperty(SUI::ObjectProperty *property) {
    getBaseWidget()->addProperty(property);
}

bool WidgetController::isInitializedInEditor() const {
    return initializedInEditor;
}

void WidgetController::setInitializedInEditor(bool value) {
    initializedInEditor = value;
}


/*****************************************************************************\
 * FUNCTION : drawSelected
 * PARAMETERS : void
 * RETURN : void
 *
 * This function draws the blue rectangles to indicate that this widget is
 * selected.
 \****************************************************************************/
void WidgetController::drawSelected() {
    QPoint pos(0, 0);
    QPoint topLeft(pos), topMid, topRight;
    QPoint midLeft, midRight;
    QPoint bottomLeft, bottomMid, bottomRight;
    QSize rectSize(6, 6);

    topMid.setX(pos.x() + ((width() / 2) - 3));
    topMid.setY(pos.y());

    topRight.setX(pos.x() + (width() - 7));
    topRight.setY(pos.y());

    midLeft.setX(pos.x());
    midLeft.setY(pos.y() + ((height() / 2) - 3));

    midRight.setX(pos.x() + (width() - 7));
    midRight.setY(pos.y() + ((height() / 2) - 3));

    bottomLeft.setX(pos.x());
    bottomLeft.setY(pos.y() + (height() - 7));

    bottomMid.setX(pos.x() + ((width() / 2) - 3));
    bottomMid.setY(pos.y() + (height() - 7));

    bottomRight.setX(pos.x() + (width() - 7));
    bottomRight.setY(pos.y() + (height() - 7));

    QPainter painter(this);
    painter.setPen(Qt::blue);

    painter.drawRect(QRect(topLeft, rectSize));
    painter.drawRect(QRect(topMid, rectSize));
    painter.drawRect(QRect(topRight, rectSize));

    painter.drawRect(QRect(midLeft, rectSize));
    painter.drawRect(QRect(midRight, rectSize));

    painter.drawRect(QRect(bottomLeft, rectSize));
    painter.drawRect(QRect(bottomMid, rectSize));
    painter.drawRect(QRect(bottomRight, rectSize));
}

/*****************************************************************************\
 * FUNCTION : addTabPage
 * PARAMETERS : const QString tabname
 * RETURN : void
 *
 * This function should only be used when this widget is a Tab Widget. It adds
 * a new Tab and its corresponding Tab Page to the Tab Widget. Its size and
 * place is being calculated and depends on the size of the Tab Widget and the
 * height of the Tab Bar.
\*****************************************************************************/
WidgetController *WidgetController::addTabPage(const QString tabname) {
    if (getObjectType() != SUI::ObjectType::TabWidget) return NULL;
    WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo(this, ACT_COMPLEX, "Add Tabpage");
    SUI::TabWidgetImpl *tabWidget = dynamic_cast<SUI::TabWidgetImpl *>(mSUIBaseWidget);

    int dHeight = getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt() - tabWidget->getTabbarHeight() - (tabWidget->getTabPageMargin() * 2);
    int dWidth = getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt() - (tabWidget->getTabPageMargin() * 2);

    WidgetDefinition widgetDefinition;
    widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, QString::number(dHeight));
    widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, QString::number(dWidth));
    widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, QString::number(tabWidget->getTabPageMargin()));
    widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, QString::number(tabWidget->getTabbarHeight() + tabWidget->getTabPageMargin()));
    widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::ObjectType, QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::TabPage)));
    widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable, "false");
    widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::Sizeable, "false");
    widgetDefinition.setSelected(true);

    WidgetController *tabPageController = widgetDefinition.addToWidget(this, true);
    SUI::TabPageImpl *tabPageImpl = dynamic_cast<SUI::TabPageImpl *>(tabPageController->getBaseWidget());
    tabPageController->getBaseWidget()->setDefaultProperties(SUI::BaseObject::Gui);
    tabPageController->getBaseWidget()->setVisible(true);

    tabPageController->setParent(this);
    tabPageController->setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, tabname);

    tabPageImpl->setTabText(tabname.toStdString());
    tabWidget->addNewTab(tabPageImpl);
    tabWidget->setCurrentTabPage(tabWidget->getWidget()->count() - 1);

    Model::instance()->selectNewWidget(QString::fromStdString(tabWidget->getCurrentTabPage()->getId()));
    tabPageController->updatePixmap();
    updatePixmap();

    UndoHandler::instance()->finishUndoInfo(wsState, this);
    UndoHandler::instance()->addToUndoGroup(wsState);

    return tabPageController;
}

/*****************************************************************************\
 * FUNCTION : tabWidgetResized() const
 * PARAMETERS : none
 * RETURN : void
 *
 * This function resizes all TabPages of this TabWidget.
\*****************************************************************************/
void WidgetController::tabWidgetResized() const {
    if (getObjectType() != SUI::ObjectType::TabWidget) return;
    SUI::TabWidgetImpl *tabWidget = dynamic_cast<SUI::TabWidgetImpl *>(mSUIBaseWidget);
    int margin = tabWidget->getTabPageMargin();
    int tabbarHeight = tabWidget->getTabbarHeight();
    int height = getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt() - tabbarHeight - (margin * 2);
    int width = getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt() - (margin * 2);
    BOOST_FOREACH(WidgetController * child, mChildren) {
        child->setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, QString::number(height));
        child->setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, QString::number(width));
    }
}

/*****************************************************************************\
 * FUNCTION : addSplitterWidget
 * PARAMETERS : const WidgetController *widgcontr
 * RETURN : void
 *
 * This function adds a new WidgetController to this, if this is a RtiSplitter.
\*****************************************************************************/
void WidgetController::addSplitterWidget(const WidgetController *widgcontr) {
    if (getObjectType() != SUI::ObjectType::Splitter) return;
    dynamic_cast<SUI::SplitterImpl *>(getBaseWidget())->addSplitterWidget(widgcontr->getBaseWidget());
}

/*****************************************************************************\
 * FUNCTION : HandlePasteAction
 * PARAMETERS : QPoint point
 * RETURN : void
 *
 * This function is being called by MainWindow::onPasteWidget. It retrieves the
 * important data of the widget being copied, from a DragAndDropInfo structure
 * and the widget that is being copied. It then creates a new widget with the
 * same properties, not including its point and parent.
 * If the point is outside the parents area, a new point is calculated, which
 * is within its boundaries.
 \****************************************************************************/
void WidgetController::handlePasteAction() {
    QPoint point;
    Model::instance()->deselectAll();
    WidgetController *wcParent = this;
    QList<WidgetState *> wsStateList;
    BOOST_FOREACH(WidgetControllerInfo * wciChild, Model::instance()->getCopiedWidgetList()) {
        WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo(NULL, ACT_NEW, "Copy/Paste");
        WidgetDefinition newDefinition;
        wciChild->getDraggedWidget()->acceptVisitor(newDefinition);
        if (wciChild->getDraggedWidget() == wcParent) wcParent = getParent();

        WidgetController *wcNewDDWidg = newDefinition.addToWidget(wcParent, true);

        point.setX(wcNewDDWidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt() + 10);
        point.setY(wcNewDDWidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt() + 10);
        int dParentWidth = wcParent->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt();
        int dParentHeight = wcParent->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt();
        int dNewWidgetWidth = wcNewDDWidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt();
        int dNewWidgetHeight = wcNewDDWidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt();

        if (wcParent->getId() == "rbbRight") point.setX(10);
        if (point.x() > (dParentWidth - dNewWidgetWidth)) point.setX(dParentWidth - dNewWidgetWidth);
        if (point.y() > (dParentHeight - dNewWidgetHeight)) point.setY(dParentHeight - dNewWidgetHeight);

        wcNewDDWidg->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, QString::number(point.x()));
        wcNewDDWidg->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, QString::number(point.y()));
        if (wcNewDDWidg->getPropertyList().contains(SUI::ObjectPropertyTypeEnum::TabOrder)) {
            wcNewDDWidg->setPropertyValue(SUI::ObjectPropertyTypeEnum::TabOrder, QString::number(dynamic_cast<SUI::BasePageImpl *>(Model::instance()->getCurrentTopPage()->getBaseWidget())->addTabOrder("", wcNewDDWidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::ID))));
        }
        wcNewDDWidg->move(point.x(), point.y());
        if (wcNewDDWidg->getObjectType() == SUI::ObjectType::TabWidget) {
            dynamic_cast<SUI::TabWidgetImpl *>(wcNewDDWidg->mSUIBaseWidget)->setCurrentTabPage(dynamic_cast<SUI::TabWidgetImpl *>(wcNewDDWidg->mSUIBaseWidget)->getCurrentIndex());
        }
        else if (wcNewDDWidg->getObjectType() == SUI::ObjectType::UserControl) {
            wcNewDDWidg->renameChildren(QString(""));
            wcNewDDWidg->renameChildren(wcNewDDWidg->getId());
            Model::instance()->addUsedUserControl(wcNewDDWidg->getId());
        }
        Model::instance()->addToSelectionList(wcNewDDWidg);
        Model::instance()->getModelHandler()->newWidgetProperties(wcNewDDWidg);
        UndoHandler::instance()->finishUndoInfo(wsState, wcNewDDWidg);
        wsStateList.append(wsState);
    }
    UndoHandler::instance()->addToUndoGroup(wsStateList);
}

/*****************************************************************************\
 * FUNCTION : showProperTabPages() const
 * PARAMETERS : none
 * RETURN : void
 *
 * This function shows the right TabPages of all its parent TabWidgets, so
 * that it becomes visible when it is selected in the object tree.
\*****************************************************************************/
void WidgetController::showProperTabPages() const {
    WidgetController *wcItem = const_cast<WidgetController *>(this);
    WidgetController *wcParent = getParent();
    WidgetController *wcMainTabWidget = Model::instance()->getTopWidget();
    if ( wcMainTabWidget != NULL ) {
        while (wcParent != NULL && wcItem != wcMainTabWidget) {
            if (wcItem->getObjectType() == SUI::ObjectType::TabPage) {
                SUI::TabPageImpl *wTabPage = dynamic_cast<SUI::TabPageImpl *>(wcItem->getBaseWidget());
                SUI::TabWidgetImpl *wTabWidget = dynamic_cast<SUI::TabWidgetImpl *>(wcParent->getBaseWidget());
                wTabWidget->setCurrentTabPage(wTabWidget->getTabPageIndex(wTabPage));
                Model::instance()->selectNewWidget(QString::fromStdString(wcParent->getBaseWidget()->getId()));
            }
            wcItem = wcParent;
            wcParent = wcItem->getParent();
        }
    }
}

/*****************************************************************************\
 * FUNCTION : getPropertyList const
 * PARAMETERS : none
 * RETURN : QStringList
 *
 * This function returns the propertylist.
\*****************************************************************************/
QSet<SUI::ObjectPropertyTypeEnum::Type> WidgetController::getPropertyList() const {
    return getBaseWidget() ? getBaseWidget()->getPropertyTypes() : QSet<SUI::ObjectPropertyTypeEnum::Type>();
}

/*****************************************************************************\
 * FUNCTION : getPropertyValue const
 * PARAMETERS : QString propertyID
 * The property to get the value from.
 * RETURN : QString
 * The property value.
 *
 * This function returns the value of the property propertyID.
\*****************************************************************************/
QString WidgetController::getPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID) const {
    return (getBaseWidget() == NULL) ? QString::null : getBaseWidget()->getPropertyValue(propertyID);
}

/*****************************************************************************\
 * FUNCTION : isChildOfThis const
 * PARAMETERS : const WidgetController *wcCtrl
 * The WidgetController to test if it is a child
 * RETURN : bool
 *
 * This function test if the wcCtrl is a child of this, somewhere in it's
 * child (sub)tree.
\*****************************************************************************/
bool WidgetController::isChildOfThis(const WidgetController *wcCtrl) const
{
    bool bRet = false;
    if (this->supportsChildren())
    {
        for (int ind1 = 0; ind1 < mChildren.size(); ++ind1)
        {
            WidgetController *wcTest = mChildren.at(ind1);
            if (wcTest == wcCtrl)
            {
                bRet = true;
                break;
            }
            bRet = wcTest->isChildOfThis(wcCtrl);
        }
    }
    return bRet;
}

/*****************************************************************************\
 * FUNCTION : getParentList const
 * PARAMETERS : none
 * RETURN : WidgetController::DDWidgetList
 *
 * This function returns a WidgetController pointer list of its parents,
 * including the TopTabPage.
\*****************************************************************************/
WidgetController::WidgetControllerList WidgetController::getParentList() const  {
    WidgetControllerList parentList;
    WidgetController *wcTest = const_cast<WidgetController *>(this)->getParent();
    while (wcTest != Model::instance()->getCurrentTopPage()) {
        parentList.append(wcTest);
        wcTest = wcTest->getParent();
    }
    parentList.append(wcTest);
    return parentList;
}

void WidgetController::setPixmapSize() {
    if (mSUIBaseWidget != NULL ) {
        QRect wdgRect = mSUIBaseWidget->getWidget()->geometry();
        mSUIBaseWidget->getWidget()->move(0, 0);
        this->setGeometry(QRect(0, 0, wdgRect.width(), wdgRect.height()));
    }
}

QStringList &WidgetController::getIDList(QStringList &idList) const {
    QString id = this->getId();
    if (getObjectType() != SUI::ObjectType::FormEditor)
        idList.append(id);
    else {
        idList.append("Height");
        idList.append("Width");
        idList.append("Name");
        idList.append("Description");
    }
    BOOST_FOREACH(WidgetController *wcChild, mChildren) {
        wcChild->getIDList(idList);
    }
    return idList;
}


/*****************************************************************************\
 * FUNCTION : sortTableWidgetChildren
 * PARAMETERS : none
 * RETURN : void
 *
 * This function sorts the children of a TableWidget on row number and column
 * number.
\*****************************************************************************/
void WidgetController::sortTableWidgetChildren() {
    if (getObjectType() == SUI::ObjectType::TableWidget) {
        qSort(mChildren.begin(), mChildren.end(), tableWidgetItemLessThan);
    }
}

/*****************************************************************************\
 * FUNCTION : HandleTableWidgetMenu
 * PARAMETERS : QString selectedAct
 * RETURN : void
 *
 * This function is being called by mousePressEvent(), whenever a user clicks
 * the right mouse button and this is a Table Widget. It creates a popup menu
 * and handles the choosen action. The QActions are:
 * - insertRows Insert a number of rows at the given position.
 * - insertColumns Insert a number of columns at the given position.
 * - removeRows Remove a number of rows at the given position.
 * - removeColumns Remove a number of columns at the given position.
 *
 * The TableWidgetDialog calls the appropriate WidgetController function to
 * execute the chosen action.
 *
 * In the initial version, the tablewidget contains only TableWidgetItems. Later
 * it must be able to contain other widgets as well. The commented out code is
 * intended for insertion of other widgets.
 \****************************************************************************/
void WidgetController::onCustomContextItemMenu(QString selectedAct) {
    SUI::TableWidgetImpl *table = dynamic_cast<SUI::TableWidgetImpl *>(this->getBaseWidget());

    bool bActionExecuted = false;

    TableWidgetDialog *twDialog = NULL;
    Itemwidgetdialog *iwDialog = NULL;

    WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo(this, ACT_COMPLEX, "Change Tablewidget");
    if (selectedAct == "insertRowsAct") twDialog = new TableWidgetDialog(TableWidgetDialog::ID_ADDROWS, this);
    else if (selectedAct == "insertColumnsAct") twDialog = new TableWidgetDialog(TableWidgetDialog::ID_ADDCOLUMNS, this);
    else if (selectedAct == "removeRowsAct") twDialog = new TableWidgetDialog(TableWidgetDialog::ID_REMOVEROWS, this);
    else if (selectedAct == "removeColumnsAct") twDialog = new TableWidgetDialog(TableWidgetDialog::ID_REMOVECOLUMNS, this);
    else if (selectedAct == "setItemPropAct") iwDialog = new Itemwidgetdialog(this, mChangedProperties.chcdef);
    else if (selectedAct == "fillTableAct") fillTableWidget();
    else if (selectedAct == "clearTableAct") clearTableWidget();

    if ( twDialog != NULL ) {
        twDialog->setStyleSheet(QString::fromStdString(SUI::StyleSheet::getInstance()->getStyleSheet()));
        if (twDialog->exec() == QDialog::Accepted)
        {
            bActionExecuted = true;
            Model::instance()->setNewSelected(this);
        }
        twDialog->deleteLater();
    }
    else if ( iwDialog != NULL ) {
        iwDialog->setStyleSheet(QString::fromStdString(SUI::StyleSheet::getInstance()->getStyleSheet()));
        if (iwDialog->exec() == QDialog::Accepted)
        {
            WidgetDefinition widgetDefinition;

            bActionExecuted = true;

//            bool headersOn = table->getPropertyValue(SUI::ObjectPropertyTypeEnum::HeadersOn).toLower() == "true";
//            table->setPropertyValue(SUI::ObjectPropertyTypeEnum::HeadersOn,"false");

            switch (mChangedProperties.chcdef)
            {
            case 0: // Set Row widget type
                if (mChangedProperties.bTypeChanged || !mChangedProperties.bBorderOnChanged) {
                    for (int row = mChangedProperties.dStart; row <= mChangedProperties.dEnd; row++) {
                        for (int column = 0; column < table->columnCount(); column++) {
                            setCellWidget(row,column,&widgetDefinition);
                        }
                    }
                }
                if (mChangedProperties.bBorderOnChanged || !mChangedProperties.bTypeChanged) {
                    for (int row = mChangedProperties.dStart; row <= mChangedProperties.dEnd; row++) {
                        for (int column = 0; column < table->columnCount(); column++) {
                            table->setCellBorderEnabled(row, column, mChangedProperties.bBorderOnChanged);
                        }
                    }
                }
                break;
            case 1: // Set Column widget type
                if (mChangedProperties.bTypeChanged || !mChangedProperties.bBorderOnChanged) {
                    for (int column = mChangedProperties.dStart; column <= mChangedProperties.dEnd; column++) {
                        for (int row = 0; row < table->rowCount(); row++) {
                            setCellWidget(row,column,&widgetDefinition);
                        }
                    }
                }
                if (mChangedProperties.bBorderOnChanged || !mChangedProperties.bTypeChanged) {
                    for (int column = mChangedProperties.dStart; column <= mChangedProperties.dEnd; column++) {
                        for (int row = 0; row < table->rowCount(); row++) {
                            table->setCellBorderEnabled(row, column, mChangedProperties.bBorderOnChanged);
                        }
                    }
                }
                break;
            case 2: // Set Cell widget type
                if (mChangedProperties.bTypeChanged || !mChangedProperties.bBorderOnChanged) {
                    setCellWidget(mChangedProperties.dStart, mChangedProperties.dEnd, &widgetDefinition);
                }
                if (mChangedProperties.bBorderOnChanged || !mChangedProperties.bTypeChanged) {
                    table->setCellBorderEnabled(mChangedProperties.dStart, mChangedProperties.dEnd, mChangedProperties.bBorderOnChanged);
                }
                break;
            default:
                break;
            }
//            if (headersOn)
//                table->setPropertyValue(SUI::ObjectPropertyTypeEnum::HeadersOn,"true");

        }
        iwDialog->deleteLater();
    }
    QApplication::processEvents();

    if (bActionExecuted) {
        renameTableWidgetItems();
        this->sortTableWidgetChildren();
        Model::instance()->getModelHandler()->sendNewWidget();
        UndoHandler::instance()->finishUndoInfo(wsState, this);
        UndoHandler::instance()->addToUndoGroup(wsState);
        dynamic_cast<QTableView*>(this->getBaseWidget()->getWidget())->update();
        Model::instance()->setNewSelected(this);
        Model::instance()->getModelHandler()->newWidgetSelection(this);
        this->updatePixmap();
    }
    else {
        UndoHandler::instance()->deleteWidgetState(wsState);
    }
}

void WidgetController::setCellWidget(int row, int column, WidgetDefinition *widgetDefinition) {
    SUI::TableWidgetImpl *table = dynamic_cast<SUI::TableWidgetImpl *>(this->getBaseWidget());

    //check if property CellName,CellAlignment,Text is set
    SUI::Widget *widget = table->getWidgetItem(row,column);
    SUI::BaseWidget *bwidget = dynamic_cast<SUI::BaseWidget*>(SUI::ObjectFactory::getInstance()->toBaseObject(widget));
    if( bwidget != NULL ) {
            widgetDefinition->setPropertyValue(SUI::ObjectPropertyTypeEnum::CellName, bwidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::CellName));
            widgetDefinition->setPropertyValue(SUI::ObjectPropertyTypeEnum::CellAlignment, bwidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::CellAlignment));
            widgetDefinition->setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, bwidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::Text));
    }
    widgetDefinition->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, "0");
    widgetDefinition->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, "0");
    widgetDefinition->setPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable, "false");
    widgetDefinition->setPropertyValue(SUI::ObjectPropertyTypeEnum::Sizeable, "false");

    SUI::ObjectType::Type objectType = SUI::ObjectType::fromString(mChangedProperties.sWidgetType.toStdString());

    // if the type equals None, we probably have a UserControl
    if (objectType == SUI::ObjectType::None)
    {
        setCellUserControlWidget(row,column,widgetDefinition);
    }
    else
    {
        // it’s a normal Widget, nothing changes
        widgetDefinition->setPropertyValue(SUI::ObjectPropertyTypeEnum::ObjectType, mChangedProperties.sWidgetType);
        WidgetController *pNewContr = widgetDefinition->addToWidget(this, true);
        QStringList idList;
        idList.append(QString::fromStdString(table->getWidgetItem(row, column)->getId()));
        SUI::Widget* widget = dynamic_cast<SUI::Widget*>(SUI::ObjectFactory::getInstance()->toObject(pNewContr->getBaseWidget()));
        if(NULL != widget)
        {
            table->setCellWidgetType(row, column, widget);
        }
        removeChildren(idList);
        pNewContr->setVisible(false);
    }
}

void WidgetController::setCellUserControlWidget(int row, int column, WidgetDefinition *widgetDefinition)
{
    SUI::TableWidgetImpl *table = dynamic_cast<SUI::TableWidgetImpl *>(this->getBaseWidget());
    // Construct the fileName
    QString fileName = mChangedProperties.sFileName;
    if(fileName.isEmpty())
    {
        fileName = mChangedProperties.sWidgetType;
        fileName.append(".xml");
    }

    // Does the file exists
    if ( QFile::exists(fileName)) // If true, then it’s a valid UserControl and fileName can be used to create it.
    {

        if (mPreviousUCFileName != fileName)
        {
            mPreviousUCFileName = fileName;
            SUI::DialogSerializer mySerializer("UserControl", SUI::DialogSerializer::Read);
            try
            {

                mySerializer.openFile(fileName);
                mySerializer.acceptVisitor(*widgetDefinition);
            }
            catch (SUI::XmlException *re)
            {

                mySerializer.closeFile();
                Model::instance()->getModelHandler()->sendMessage("XmlException", QString::fromStdString(re->getExceptionMessage()) , 1);
                return;
            }
            catch (SUI::IOException *re)
            {
                mySerializer.closeFile();
                Model::instance()->getModelHandler()->sendMessage("IOException", QString::fromStdString(re->getExceptionMessage()), 1);
                return;
            }
        }

        WidgetController *pNewContr = widgetDefinition->addToWidget(this, true);

        SUI::BaseWidget *baseUCT = pNewContr->getBaseWidget();
        baseUCT->setPropertyValue(SUI::ObjectPropertyTypeEnum::FileName,fileName);
        SUI::UserControlImpl *uct = dynamic_cast<SUI::UserControlImpl*>(baseUCT);
        QStringList idList;
        idList.append(QString::fromStdString(table->getWidgetItem(row, column)->getId()));
        table->setCellWidgetType(row, column, uct);
        Model::instance()->addUsedUserControl( pNewContr->getId());
        removeChildren(idList);
        pNewContr->setVisible(false);
    }
}


/*****************************************************************************\
 * FUNCTION : removeChildren
 * PARAMETERS : QStringList idList
 * List with the items to delete
 * RETURN : void
 *
 * This function will delete the widgets that are provided at the list from
 * it's parent and from the model.
 \****************************************************************************/
void WidgetController::removeChildren(QStringList idList) {
    for (int ind = 0; ind < idList.size(); ++ind) {
        WidgetController *childController = Model::instance()->getWidgetController(idList.at(ind));
        if ( childController != NULL ) {
            this->removeChild(childController);
            Model::instance()->removeWidget(childController->widgetGUID());
            childController->deleteLater();
        }
    }
}

void WidgetController::insertTreeItem(QTreeWidgetItem *Item) {
    WidgetDefinition widgetDefinition;
    WidgetController *treeItem;
    WidgetController *treeItem2 = this;
    QString ParenColumn = "";
    if (!Item->text(2).isEmpty())
    {
        if (Item->parent() != NULL)
        {
            ParenColumn = Item->parent()->text(2);
        }
        treeItem = Model::instance()->getWidgetController(Item->text(2));
        treeItem->setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, Item->text(0));
    }
    else
    {
        widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::ObjectType, QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::TreeViewItem)));
        widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable, "false");
        widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::Sizeable, "false");
        widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, "0");
        widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, "0");
        widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, Item->text(0));

        if (Item->parent() != NULL)
        {
            ParenColumn = Item->parent()->text(2);
            treeItem2 = Model::instance()->getWidgetController(ParenColumn);
        }

        treeItem = widgetDefinition.addToWidget(treeItem2, true);
        Item->setText(2, treeItem->getId());
        treeItem->setVisible(false);
        treeItem->setParent(treeItem2);
    }
    dynamic_cast<SUI::TreeViewImpl *>(mSUIBaseWidget)->appendRow(Item->text(0), ParenColumn, treeItem->getId());

    for (int i = 0; i < Item->childCount(); i++) {
        Item->setText(1, treeItem->getId());
    }
    updatePixmap();
}

/*****************************************************************************\
 * FUNCTION : renameTableWidgetItems
 * PARAMETERS : void
 * RETURN : void
 *
 * This function renames the RticTableWidgetItem's of this RticTableWidget.
 * Since the ID's of the RticTableWidgetItem, should contain it's position in
 * the TableWidget, its RticTableWidget ID plus its row number and column
 * number (1-based) are added to the proper prefix. Every time rows and
 * columns are added or deleted, this rename should take place.
 \****************************************************************************/
void WidgetController::renameTableWidgetItems() {
    dynamic_cast<SUI::TableWidgetImpl *>(mSUIBaseWidget)->updateTable();
    // tabReorder();
    Model::instance()->getModelHandler()->sendNewWidget();
}

/*****************************************************************************\
 * FUNCTION : removeChild
 * PARAMETERS : WidgetController *childWidget
 * The childwidget to be removed from the mChildren list.
 * RETURN : void
 *
 * This function checks if the childwidget is in the mChildren list and if so,
 * removes it from that list.
\*****************************************************************************/

void WidgetController::removeChild(WidgetController *childWidget)
{
    if (childWidget->getObjectType() == SUI::ObjectType::TableWidget
            || childWidget->getObjectType() == SUI::ObjectType::GroupBox
            || childWidget->getObjectType() == SUI::ObjectType::CheckGroupBox
            /*|| childWidget->getObjectType() == SUI::WidgetType::TabPage"*/)
    {
        BOOST_FOREACH(WidgetController * child, childWidget->mChildren)
        {
            dynamic_cast<SUI::BasePageImpl *>(Model::instance()->getCurrentTopPage()->getBaseWidget())->
                    removeTabOrder(child->getId());
        }
        Model::instance()->getCurrentTopPage()->tabReorder();
    }

    int ind = mChildren.indexOf(childWidget);
    if (ind != -1)
    {
        mChildren.removeAt(ind);
    }
}

/*****************************************************************************\
 * FUNCTION : renameChildren
 * PARAMETERS : const QString &topid
 * The ID of the top level WidgetController, being this.
 * RETURN : void
 *
 * This function renames (changes id's) of all this' children. If topid is not
 * empty, all children's id's are being prefixed with topid followed by a ':'.
 * If topid is empty, the prefix is removed and the remaining id is being
 * checked for its exixtance. If so, the number part is being increased until
 * it doesn't exist.
\*****************************************************************************/
void WidgetController::renameChildren(const QString &topid)
{
    if (!topid.isEmpty())
    {
        if (topid != this->getId())
        {
            this->setId(QString("%1:%2").arg(topid).arg(this->getPropertyValue(SUI::ObjectPropertyTypeEnum::ID)));
        }
    }
    else
    {
        QString id = this->getId();
        int dBreak = id.indexOf(":");
        if (dBreak != -1)
        {
            QString newId = id.right(id.length() - dBreak - 1);
            int dSubWidgetChck = newId.indexOf(":");
            QString prefix = QString::fromStdString(SUI::ObjectType::getIdPrefix(getBaseWidget()->getObjectType()));
            int dNum = newId.right(newId.length() - 3).toInt();

            // If there is another ':' in the ID, this is a subwidget (within a TableWidget i.e.). Don't check
            // for its existance in the Model class WidgetMap.
            if (dSubWidgetChck == -1)
            {
                while (Model::instance()->IDExists(newId))
                {
                    ++dNum;
                    newId = QString("%1%2").arg(prefix).arg(dNum);
                }
            }
            this->setId(newId);
        }
    }
    BOOST_FOREACH(WidgetController * child, mChildren)
    {
        child->renameChildren(topid);
    }
}

/*****************************************************************************\
 * FUNCTION : removeFromModel
 * PARAMETERS : void
 * RETURN : void
 *
 * This function removes this and all its children from the Model's widget map.
\*****************************************************************************/
void WidgetController::removeFromModel()
{
    Model::instance()->removeWidget(this->widgetGUID());
    BOOST_FOREACH(WidgetController * child, mChildren)
    {
        child->removeFromModel();
    }
}

/*****************************************************************************\
 * FUNCTION : setChildrenPropertyValue
 * PARAMETERS : QString propertyID
 * QString propertyValue
 * RETURN : void
 *
 * This function sets all the propertyID of this and all its children to
 * propertyValue.
\*****************************************************************************/
void WidgetController::setChildrenPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue)
{
    setPropertyValue(propertyID, propertyValue);
    BOOST_FOREACH(WidgetController * child, mChildren) {
        child->setChildrenPropertyValue(propertyID, propertyValue);
    }
}

/*****************************************************************************\
 * FUNCTION : setChildrenWidgetMode
 * PARAMETERS : const WidgetController::WidgetControllerModeEnum mode
 * RETURN : void
 *
 * This function sets the WidgetControllerModeEnum of this and all its children
 * to mode.
\*****************************************************************************/
void WidgetController::setChildrenWidgetMode(const WidgetController::WidgetControllerModeEnum mode)
{
    this->mMode = mode;
    BOOST_FOREACH(WidgetController * wcChild, mChildren)
    {
        wcChild->setChildrenWidgetMode(mode);
    }
}

/*****************************************************************************\
 * FUNCTION : hasUCtrlParent
 * PARAMETERS : void
 * RETURN : bool
 *
 * This function checks if this is a (sub) child of an UserControlSelector.
\*****************************************************************************/
bool WidgetController::hasUCtrlParent()
{
    WidgetController *wcTst = this;

    while (wcTst->getParent() != NULL)
    {
        if (wcTst->getObjectType() == SUI::ObjectType::UserControl)
        {
            return true;
        }
        wcTst = wcTst->getParent();
    }
    return (wcTst->isWidgetSelector());
}

/*****************************************************************************\
 * FUNCTION : setChildrenPropertyReadOnly
 * PARAMETERS : none
 * RETURN : void
 *
 * This function sets all properties of UserControl children on ReadOnly. And
 * the Height, Width and Sizeable properties of the UserControl are set to
 * ReadOnly.
\*****************************************************************************/
void WidgetController::setChildrenPropertyReadOnly() const
{
    if (!(getPropertyValue(SUI::ObjectPropertyTypeEnum::UserControl).isEmpty()))
    {
        if (getObjectType() == SUI::ObjectType::UserControl)
        {
            QList<SUI::ObjectPropertyTypeEnum::Type> propList = {
                SUI::ObjectPropertyTypeEnum::Height,
                SUI::ObjectPropertyTypeEnum::Width,
                SUI::ObjectPropertyTypeEnum::Sizeable
            };
            BOOST_FOREACH(SUI::ObjectPropertyTypeEnum::Type prop, propList)
                getBaseWidget()->setPropertyReadonly(prop);
        }
        else
        {
            if (getBaseWidget() != NULL)
            {
                BOOST_FOREACH(SUI::ObjectPropertyTypeEnum::Type prop, getBaseWidget()->getPropertyTypes())
                    getBaseWidget()->setPropertyReadonly(prop);
            }
        }
        BOOST_FOREACH(WidgetController * wcChild, mChildren)
        {
            wcChild->setChildrenPropertyReadOnly();
        }
    }
}

/*****************************************************************************\
 * FUNCTION : splitUserControl
 * PARAMETERS : none
 * RETURN : bool
 *
 * This function splits the UserControl into its children. So the parent of this
 * UserControl becomes the parent of this UserControl's children. Furthermore,
 * the ID's of its children aren stripped from this UserControl's ID prefix.
\*****************************************************************************/
bool WidgetController::splitUserControl()
{
    bool bRet = false;
    if (getObjectType() == SUI::ObjectType::UserControl)
    {
        int uctrlX = getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt();
        int uctrlY = getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt();

        WidgetState *wsUCtrlState = UndoHandler::instance()->getNewUndoInfo(this, ACT_SPLITUCTRL, "Split UserControl");

        Model::instance()->removeUsedUserControl(getId());
        WidgetController *wcParent = getParent();
        setChildrenPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable, "true");
        renameChildren(QString(""));
        removeFromModel();
        QList<WidgetState *> wsStateList;
        BOOST_FOREACH(WidgetController * wcChild, mChildren)
        {
            int X = wcChild->getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt();
            int Y = wcChild->getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt();
            X += uctrlX;
            Y += uctrlY;
            WidgetDefinition newDef;
            wcChild->acceptVisitor(newDef);
            newDef.setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, QString::number(X));
            newDef.setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, QString::number(Y));
            newDef.setPropertyValue(SUI::ObjectPropertyTypeEnum::UserControl, QString(""));
            WidgetController *newChild = newDef.addToWidget(wcParent, false);
            removeChild(wcChild);
            wcChild->deleteLater();
            newChild->move(X, Y);

            WidgetController *wcTstParent = wcParent;
            bool bParentInSelection = false;
            while (wcTstParent != NULL && !bParentInSelection)
            {
                if (Model::instance()->isInSelectionList(wcTstParent))
                {
                    bParentInSelection = true;
                }
                wcTstParent = wcTstParent->getParent();
            }
            if (!bParentInSelection)
            {
                Model::instance()->addToSelectionList(newChild);
            }

            WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo(NULL, ACT_SPLITUCTRL, "Split UserControl");
            UndoHandler::instance()->finishUndoInfo(wsState, newChild);
            wsStateList.append(wsState);
        }
        UndoHandler::instance()->addOldUCtrlToWSList(wsStateList, wsUCtrlState);
        UndoHandler::instance()->addToUndoGroup(wsStateList);
        wcParent->removeChild(this);
        bRet = true;
    }
    return bRet;
}

/*****************************************************************************\
 * FUNCTION : searchForUserControl
 * PARAMETERS : none
 * RETURN : WidgetController*
 *
 * This function searches in the children of this, for UserControl's.
\*****************************************************************************/
WidgetController *WidgetController::searchForUserControl()
{
    WidgetController *wcRet = NULL;
    if (getObjectType() == SUI::ObjectType::UserControl)
    {
        wcRet = this;
    }
    for (int ind = 0; (wcRet == NULL) && (ind < mChildren.size()); ++ind)
    {
        wcRet = mChildren[ind]->searchForUserControl();
    }
    return wcRet;
}

/*****************************************************************************\
 * FUNCTION : getTableWidgetItemRowNr const
 * PARAMETERS : none
 * RETURN : int
 *
 * This function retrieves the row number of a TableWidget Item.
\*****************************************************************************/
int WidgetController::getTableWidgetItemRowNr() const
{
    int dRet = 0;
    int posStart = this->getId().lastIndexOf(":");
    if (posStart != -1)
    {
        int posEnd = this->getId().indexOf("-", posStart + 1);
        if (posEnd != -1)
        {
            ++posStart;
            dRet = this->getId().mid(posStart, posEnd - posStart).toInt();
        }
    }
    return dRet;
}

/*****************************************************************************\
 * FUNCTION : getTableWidgetItemColumnNr const
 * PARAMETERS : none
 * RETURN : int
 *
 * This function retrieves the column number of a TableWidget Item.
\*****************************************************************************/
int WidgetController::getTableWidgetItemColumnNr() const
{
    QString idStr = this->getId();
    int dRet = 0;
    int posStart = idStr.lastIndexOf("-");
    if (posStart != -1)
    {
        dRet = idStr.right(idStr.length() - ++posStart).toInt();
    }
    return dRet;
}

/*****************************************************************************\
 * FUNCTION : toForground
 * PARAMETERS : const WidgetController *wcChild
 * The widget that is to be moved to the front.
 * RETURN : void
 *
 * This function moves this widget to the front within its parent list. Moving
 * to the front means putting it last in the children list, because that one
 * is drawn last.
\*****************************************************************************/
void WidgetController::toForground(const WidgetController *wcChild)
{
    if (wcChild != NULL)
    {
        int ind = mChildren.indexOf(const_cast<WidgetController *>(wcChild));
        if ((ind != -1) && (ind < mChildren.size() - 1))
        {
            WidgetController *wcTemp = mChildren.takeAt(ind);
            mChildren.append(wcTemp);
        }
    }
}

/*****************************************************************************\
 * FUNCTION : toBackground
 * PARAMETERS : const WidgetController *wcChild
 * The widget that is to be moved to the back.
 * RETURN : void
 *
 * This function moves this widget to the back within its parent list. Moving
 * to the back means putting it first in the children list, because that one
 * is drawn first.
\*****************************************************************************/
void WidgetController::toBackground(const WidgetController *wcChild)
{
    if (wcChild != NULL)
    {
        int ind = mChildren.indexOf(const_cast<WidgetController *>(wcChild));
        if (ind > 0)
        {
            WidgetController *wcTemp = mChildren.takeAt(ind);
            mChildren.prepend(wcTemp);
        }
    }
}

/*****************************************************************************\
 * FUNCTION : forward
 * PARAMETERS : const WidgetController *wcChild
 * The widget that is to be moved up one step.
 * RETURN : void
 *
 * This function moves this widget one step to the front within its parent list.
\*****************************************************************************/
void WidgetController::forward(const WidgetController *wcChild)
{
    if (wcChild != NULL)
    {
        int ind = mChildren.indexOf(const_cast<WidgetController *>(wcChild));
        if ((ind != -1) && (ind < mChildren.size() - 1))
        {
            mChildren.swap(ind, ind + 1);
        }
    }
}

/*****************************************************************************\
 * FUNCTION : backward
 * PARAMETERS : const WidgetController *wcChild
 * The widget that is to be moved up one step.
 * RETURN : void
 *
 * This function moves this widget one step to the back within its parent list.
\*****************************************************************************/
void WidgetController::backward(const WidgetController *wcChild)
{
    if (wcChild != NULL)
    {
        int ind = mChildren.indexOf(const_cast<WidgetController *>(wcChild));
        if (ind > 0)
        {
            mChildren.swap(ind, ind - 1);
        }
    }
}

/*****************************************************************************\
 * FUNCTION : repaint
 * PARAMETERS : none
 * RETURN : void
 *
 * This function repaints its children. Just calling the updatePixmap()
 * function in the proper sequence does not work. One really has to delete all
 * children and add them again in the proper sequence.
\*****************************************************************************/
void WidgetController::redraw()
{
    QList<WidgetDefinition *> definitionList;
    BOOST_FOREACH(WidgetController *wcChild, mChildren)
    {
        WidgetDefinition *newDefinition = new WidgetDefinition();
        wcChild->acceptVisitor(*newDefinition);
        definitionList.append(newDefinition);
        this->removeChild(wcChild);
        Model::instance()->removeWidget(wcChild->widgetGUID());
        wcChild->deleteLater();
    }
    QApplication::processEvents();
    QCoreApplication::sendPostedEvents();
    QCoreApplication::flush();
    BOOST_FOREACH(WidgetDefinition *newDefinition, definitionList)
    {
        WidgetController *wcChild = newDefinition->addToWidget(this, false);
        Q_UNUSED(wcChild);
        delete newDefinition;
        newDefinition = NULL;
    }
}

/*****************************************************************************\
 * FUNCTION : fillTableWidget
 * PARAMETERS : void
 * RETURN : void
 *
 * This function is being called by TableWidgetDialog::onActionTriggered(). It
 * fills all TableWidgetItems that have no text, with its row and column
 * numbers. This is for debugging purposes only.
 \****************************************************************************/
void WidgetController::fillTableWidget() {
    SUI::TableWidget *table = dynamic_cast<SUI::TableWidgetImpl *>(mSUIBaseWidget);
    for (int row = 0, rows = table->rowCount(); row < rows; row++) {
        for (int column = 0, columns = table->columnCount(); column < columns; column++) {
            if (table->getItemText(row, column).empty()) {
                QString text = QString("%1 - %2").arg(row + 1).arg(column + 1);
                table->setItemText(row, column, text.toStdString());
            }
        }
    }
    updatePixmap();
}

void WidgetController::clearTableWidget() {
    SUI::TableWidget *table = dynamic_cast<SUI::TableWidgetImpl *>(mSUIBaseWidget);
    for (int row = 0, rows = table->rowCount(); row < rows; row++) {
        for (int column = 0, columns = table->columnCount(); column < columns; column++) {
            table->setItemText(row, column, "");
        }
    }
    updatePixmap();
}

/*****************************************************************************\
 * FUNCTION : getID const
 * PARAMETERS : void
 * RETURN : QString
 *
 * This is a convenience function to retieve its ID.
 \****************************************************************************/
QString WidgetController::getId() const
{
    return mSUIBaseWidget ? QString::fromStdString(mSUIBaseWidget->getId()) : "";
}

/*****************************************************************************\
 * FUNCTION : isChildOfDDWidget
 * PARAMETERS : const WidgetController *ddw
 * QPoint &dropPoint
 * The recalculated drop point
 * RETURN : bool
 *
 * This function checks if this is a child in the child tree of ddw. If so, the
 * new drop point has to be calculated.
 \****************************************************************************/
bool WidgetController::isChildOfDDWidget(const WidgetController *ddw, QPoint &dropPoint) const
{
    bool bIsParent = false;
    WidgetController *currentTopTab = Model::instance()->getCurrentTopPage();
    QPoint tmpPoint = dropPoint;

    for (WidgetController *tstWidg = this->getParent(); (bIsParent == false) && (tstWidg != NULL) && (tstWidg != currentTopTab); tstWidg = tstWidg->getParent())
    {
        if (tstWidg->isWidgetSelector())
        {
            break;
        }
        tmpPoint += QPoint(tstWidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt(), tstWidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt());
        if (tstWidg == ddw)
        {
            bIsParent = true;
        }
    }
    // Add offset of this to new drop point.
    dropPoint = tmpPoint + QPoint(getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt(), getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt());
    return bIsParent;
}

/*****************************************************************************\
 * FUNCTION : setPropertyValue
 * PARAMETERS : QString propertyID
 * QString propertyValue
 * RETURN : void
 *
 * This function is necessary in case this is a Tab Widget and the size is
 * being adjusted. When the size of a Tab Widget is altered, the size of the
 * underlying Tab Pages must be altered accordingly.
 \****************************************************************************/
void WidgetController::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue)
{
    mSUIBaseWidget->setPropertyValue(propertyID, propertyValue);

    if (getObjectType() == SUI::ObjectType::TabWidget)
    {
        int marg = dynamic_cast<SUI::TabWidgetImpl *>(mSUIBaseWidget)->getTabPageMargin() * 2;
        int val = 0;
        int tabHght = dynamic_cast<SUI::TabWidgetImpl *>(mSUIBaseWidget)->getTabbarHeight();
        switch (propertyID)
        {
        case SUI::ObjectPropertyTypeEnum::Height:
            val = propertyValue.toInt() - tabHght - marg;
            break;
        case SUI::ObjectPropertyTypeEnum::Width:
            val = propertyValue.toInt() - marg;
            break;
        default:
            break;
        }
        if (propertyID == SUI::ObjectPropertyTypeEnum::Height || propertyID == SUI::ObjectPropertyTypeEnum::Width) {
            for (int ind = 0; ind < mChildren.size(); ++ind) mChildren[ind]->setPropertyValue(propertyID, QString::number(val));
        }
    }
    else if ((getObjectType() == SUI::ObjectType::TabPage) && (propertyID == SUI::ObjectPropertyTypeEnum::Text))
    {
        WidgetController *wcTabWidget = this->getParent();
        dynamic_cast<SUI::TabWidgetImpl *>(wcTabWidget->getBaseWidget())->renameTab(dynamic_cast<SUI::TabPageImpl *>(this->getBaseWidget()), propertyValue);
        wcTabWidget->updatePixmap();
    }
    else if (propertyID == SUI::ObjectPropertyTypeEnum::TabOrder)
    {
        dynamic_cast<SUI::BasePageImpl *>(Model::instance()->getCurrentTopPage()->getBaseWidget())->addTabOrder(propertyValue, QString::fromStdString(mSUIBaseWidget->getId()));
        tabReorder();
    }

    updatePixmap();
    if (getObjectType() == SUI::ObjectType::TabPage)
    {
        this->getParent()->updatePixmap();
    }
}

/*****************************************************************************\
 * FUNCTION : getCurrentDaDTabpage const
 * PARAMETERS : void
 * RETURN : WidgetController*
 *
 * If this is a Tab Widget, this function returns the current tab page of this.
 * Otherwise it returns NULL.
 \****************************************************************************/
WidgetController *WidgetController::getCurrentDaDTabpage() const {
    WidgetController *tabPageController = NULL;
    if (getObjectType() == SUI::ObjectType::TabWidget) {
        SUI::BaseWidget *currentTabPage = dynamic_cast<SUI::BaseWidget*>(SUI::ObjectFactory::getInstance()->toBaseObject(dynamic_cast<SUI::TabWidgetImpl *>(mSUIBaseWidget)->getCurrentTabPage()));
        for (int ind = 0; ind < mChildren.size(); ++ind) {
            if (mChildren[ind]->getBaseWidget() != currentTabPage) continue;
            tabPageController = mChildren[ind];
            break;
        }
    }
    return tabPageController;
}

/*****************************************************************************\
 * FUNCTION : setSelected
 * PARAMETERS : bool selected
 * RETURN : void
 *
 * This function sets the mIsSelected property.
 \****************************************************************************/
void WidgetController::setSelected(bool selected) {
    mIsSelected = selected;
    if (!mIsSelected) update();
}

/*****************************************************************************\
 * FUNCTION : getIndexedValue const
 * PARAMETERS : QString key
 * The key of the IndexedValue property to search.
 * val
 * The index of the IndexedValue to search
 * RETURN : QString
 * The value of the given index of the given key, if found.
 * Otherwise an empty string.
 *
 * This function retrieves the value with index val of the given key.
 \****************************************************************************/
QString WidgetController::getIndexedValue(QString propertyType, QString val) const {
    QStringList existingValues = getPropertyValue(SUI::ObjectPropertyTypeEnum::fromString(propertyType.toStdString())).split(';', QString::SkipEmptyParts);
    BOOST_FOREACH(const QString &value, existingValues)
        if (value.split(',').at(0) == val)
            return value.split(',').at(1);

    return "";
}

/*****************************************************************************\
 * FUNCTION : widgetType const
 * PARAMETERS : void
 * RETURN : QString
 * The widget type of the RticBaseWidget's subclass. Or an
 * empty string if baseWidget is NULL.
 *
 * This function retrieves the widget type.
\*****************************************************************************/
SUI::ObjectType::Type WidgetController::getObjectType() const {
    return mSUIBaseWidget ? mSUIBaseWidget->getObjectType() : SUI::ObjectType::None;
}

/*****************************************************************************\
 * FUNCTION : TableWidgetItemLessThan
 * PARAMETERS : const WidgetController *wc1
 * const WidgetController *wc2
 * RETURN : bool
 *
 * This is a non-class function used for sorting the children of a TableWidget.
\*****************************************************************************/
bool tableWidgetItemLessThan(const WidgetController *wc1, const WidgetController *wc2) {
    if ( (wc1 == NULL) || (wc2 == NULL) ) return false;
    if (wc1->getTableWidgetItemRowNr() < wc2->getTableWidgetItemRowNr()) return true;
    if (wc1->getTableWidgetItemRowNr() > wc2->getTableWidgetItemRowNr()) return false;
    if (wc1->getTableWidgetItemColumnNr() < wc2->getTableWidgetItemColumnNr()) return true;
    return false;
}

/*****************************************************************************\
 * FUNCTION : tabReorder
 * PARAMETERS :
 * RETURN : void
 *
 * This function set the correct tabOrder within the current mainTabPage.
\*****************************************************************************/
void WidgetController::tabReorder() {
    if (Model::instance()->getCurrentTopPage() != NULL) {
        SUI::BaseWidget *baseWidget = Model::instance()->getCurrentTopPage()->getBaseWidget();
        SUI::BasePageImpl *basePage = dynamic_cast<SUI::BasePageImpl *>(baseWidget);
        if (basePage != NULL) {
        QMapIterator<int, QString> it(basePage->getTablist());
        while (it.hasNext()) {
            it.next();
            WidgetController *widget = Model::instance()->getWidgetController(it.value());
            if (widget == NULL) continue;
            SUI::BasePageImpl *basePage = dynamic_cast<SUI::BasePageImpl *>(Model::instance()->getCurrentTopPage()->getBaseWidget());
            if (widget->getPropertyValue(SUI::ObjectPropertyTypeEnum::TabOrder) != QString::number(basePage->indexof(widget->getId())))
                widget->setPropertyValue(SUI::ObjectPropertyTypeEnum::TabOrder,QString::number(basePage->indexof(widget->getId())));
        }
    }
}
}


/*****************************************************************************\
 * FUNCTION : addToTaborder
 * PARAMETERS :
 * RETURN : void
 *
 * This function (set)refills the tabOrderlist with the widgets of the current
 * mainTabPage. Part 1/2
\*****************************************************************************/
void WidgetController::addToTaborder() {
    WidgetController *crtl = Model::instance()->getCurrentMainTabPage();
    if (crtl == NULL) crtl = Model::instance()->getTopWidget()->getParent();

    addToTaborder2(crtl);
}

/*****************************************************************************\
 * FUNCTION : addToTaborder
 * PARAMETERS :
 * RETURN : void
 *
 * This function (set)refills the tabOrderlist with the widgets of the current
 * mainTabPage. Part 2/2
\*****************************************************************************/
void WidgetController::addToTaborder2(WidgetController *wdctrl) {
    BOOST_FOREACH(WidgetController * wdctrl2, wdctrl->childList()) {
        SUI::BasePageImpl *basePage = dynamic_cast<SUI::BasePageImpl *>(Model::instance()->getCurrentTopPage()->getBaseWidget());
        if (wdctrl2->getPropertyList().contains(SUI::ObjectPropertyTypeEnum::TabOrder) && basePage != NULL) {
            basePage->addTabOrder(getPropertyValue(SUI::ObjectPropertyTypeEnum::TabOrder), wdctrl2->getId());
        }
        if (!wdctrl2->children().isEmpty()) addToTaborder2(wdctrl2);
    }
}

/*****************************************************************************\
 * FUNCTION : updateTableCell
 * PARAMETERS : int row :cell row index
 * int col :cell column index
 * QString WidgetType :string containing FWQ Widget type
 * QString Alignment :string containing alignment information
 * RETURN : void
 *
 * This function updates the Widget Cell alignment at position (row,col)
 * First it creates a new widget of type WidgetType
 * Then it will call updateCell(..) of the specific RticTableWidget
 * Next it will delete the former Widget from the model instance
 * And finally it will rename the RticTableWidget items
\*****************************************************************************/
void WidgetController::updateTableCell(int row, int column, SUI::ObjectType::Type objectType, SUI::AlignmentEnum::Alignment alignment) {
    using namespace SUI;

    TableWidgetImpl *table = dynamic_cast<SUI::TableWidgetImpl *>(getBaseWidget());
    QString         id = QString::fromStdString( table->getWidgetItem( row, column )->getId() );
    WidgetController *previousController = Model::instance()->getWidgetController( id );
    //create new widget
    WidgetDefinition widgetDefinition;
    widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, "0");
    widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, "0");
    widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::ObjectType, QString::fromStdString(SUI::ObjectType::toString(objectType)));
    widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable, "false");
    widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::Sizeable, "false");

    WidgetController *newController = widgetDefinition.addToWidget(this, true);
    newController->setVisible(false);

    BaseWidget *baseWidget = newController->getBaseWidget();
    Widget *widget = dynamic_cast<SUI::Widget*>(SUI::ObjectFactory::getInstance()->toObject(baseWidget));

    //commit the Cell update
    table->updateCell(row, column, alignment, widget);
    table->updateTable();

    //copy properties of old widget
    BOOST_FOREACH(SUI::ObjectPropertyTypeEnum::Type prop, previousController->getPropertyList())
        baseWidget->setPropertyValue(prop, previousController->getPropertyValue(prop));

    //clean up
    removeChild(previousController);
    Model::instance()->removeWidget(previousController->widgetGUID());
    previousController->deleteLater();

    //TableWidget administration
    sortTableWidgetChildren();
    updatePixmap();
    update();

    Model::instance()->getModelHandler()->sendNewWidget();
}

/*****************************************************************************\
 * FUNCTION : makeFramePixmap
 * PARAMETERS : QPoint point
 * point of where the drag starts
 * WidgetController* curWidg
 * The widget where is pressed
 * RETURN : QPixmap
 * the pixmap of the selected widgets
 *
 * This function retuns a pixmap of the selected widgets during dragging
\*****************************************************************************/
QPixmap WidgetController::makeFramePixmap(QPoint point, WidgetController *curWidg) {
    QPixmap pixmap = NULL;

    // Calculate dimensions
    int xTop = -1;
    int yTop = -1;
    int xBottom = -1;
    int yBottom = -1;

    BOOST_FOREACH(WidgetController * topWidget, Model::instance()->getSelectionList()) {
        QPoint Pos = QPoint(topWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt(),
                            topWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt());

        if ((Pos.x() < xTop) || (xTop == -1)) xTop = Pos.x();
        if ((Pos.y() < yTop) || (yTop == -1)) yTop = Pos.y();
        if ((xBottom == -1) || ((Pos.x() + topWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt()) > xBottom)) {
            xBottom = Pos.x() + topWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt();
        }
        if ((yBottom == -1) || ((Pos.y() + topWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt()) > yBottom)) {
            yBottom = Pos.y() + topWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt();
        }
    }

    // Set the Position of the pixmap (hotspot)
    mStartPoint = QPoint(point.x() + curWidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt() - xTop,
                         point.y() + curWidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt() - yTop);

    //Create a QFrame Set all the widgets and take a pixmap
    QList<WidgetController *> list = Model::instance()->getSelectionList();
    QFrame *frame = new QFrame();
    frame->setGeometry(xTop, yTop, xBottom - xTop, yBottom - yTop);

    if (list.count() != 0) {
        QObject *parentObject = list.at(0)->getBaseWidget()->getWidget()->parent();
        frame ->setAttribute(Qt::WA_NoSystemBackground);

        BOOST_FOREACH(WidgetController * wdgt, list) {
            wdgt->getBaseWidget()->getWidget()->setParent(frame);
            wdgt->getBaseWidget()->getWidget()->setGeometry(wdgt->getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt() - xTop,
                                                            wdgt->getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt() - yTop,
                                                            wdgt->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt(),
                                                            wdgt->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt());
            wdgt->getBaseWidget()->getWidget()->setParent(frame);
        }
        pixmap = QPixmap::grabWidget(frame);

        BOOST_FOREACH(WidgetController * wdgt, list)
            wdgt->getBaseWidget()->getWidget()->setParent(dynamic_cast<QWidget *>(parentObject));
    }

    delete frame;
    frame = NULL;
    return pixmap;
}

/*****************************************************************************\
 * FUNCTION : snapToGrid
 * PARAMETERS : QPoint point
 * point to be converted
 * RETURN : QPoint
 * the converted point
 *
 * This function retuns a converted point. The point is converted to the nearest
 * point on the gridmap.
\*****************************************************************************/
QPoint WidgetController::snapToGrid(QPoint &point)
{
    int dXGridDist = Model::instance()->XGridDistance();
    int dYGridDist = Model::instance()->YGridDistance();
    QPoint mappedPoint = point;
    int mappedX = Model::instance()->xSnap() ? (qRound(((double)mappedPoint.x()) / ((double)dXGridDist)) * dXGridDist) : point.x();
    int mappedY = Model::instance()->ySnap() ? (qRound(((double)mappedPoint.y()) / ((double)dYGridDist)) * dYGridDist) : point.y();
    mappedPoint.setX(mappedX);
    mappedPoint.setY(mappedY);
    return mappedPoint;
}

void WidgetController::removeWidgetFromTable(int row, int column) {
    QString id = QString::fromStdString(dynamic_cast<SUI::TableWidgetImpl *>(mSUIBaseWidget)->getWidgetItem(row, column)->getId());
    int ind = mChildren.indexOf(Model::instance()->getWidgetController(id));
    if (ind != -1)
    {
        dynamic_cast<SUI::BasePageImpl *>(Model::instance()->getCurrentTopPage()->getBaseWidget())->removeTabOrder(mChildren[ind]->getId());
        Model::instance()->removeWidget(mChildren[ind]->widgetGUID());
        mChildren[ind]->deleteLater();
        this->mChildren.removeAt(ind);
    }
}

