
#ifndef SUISTATEWIDGETIMPLUNITTEST_H
#define SUISTATEWIDGETIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class StateWidgetImpl;

class StateWidgetImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit StateWidgetImplUnitTest(StateWidgetImpl *object, QObject *parent = 0);
    virtual ~StateWidgetImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    StateWidgetImpl *object;
};

}
#endif // SUISTATEWIDGETIMPLUNITTEST_H
