
#include "SUIQuestionMarkImplUnitTest.h"
#include "SUIQuestionMarkImpl.h"
#include "SUIBaseObject.h"

SUI::QuestionMarkImplUnitTest::QuestionMarkImplUnitTest(SUI::QuestionMarkImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::QuestionMarkImplUnitTest::~QuestionMarkImplUnitTest()
{
   delete object;
}

void SUI::QuestionMarkImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(BaseObject::EditorForm);
    object->setDefaultProperties(BaseObject::EditorSelector);
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
