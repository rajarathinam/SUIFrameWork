
#ifndef SUISCIENCESPINBOXIMPLUNITTEST_H
#define SUISCIENCESPINBOXIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class ScienceSpinBoxImpl;

class ScienceSpinBoxImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit ScienceSpinBoxImplUnitTest(ScienceSpinBoxImpl *object, QObject *parent = 0);
    virtual ~ScienceSpinBoxImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    ScienceSpinBoxImpl *object;
};

}
#endif // SUISCIENCESPINBOXIMPLUNITTEST_H
