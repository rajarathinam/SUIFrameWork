
#ifndef SUIBUTTONBARIMPLUNITTEST_H
#define SUIBUTTONBARIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class ButtonBarImpl;

class ButtonBarImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit ButtonBarImplUnitTest(ButtonBarImpl *object, QObject *parent = 0);
    virtual ~ButtonBarImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    ButtonBarImpl *object;
};

}
#endif // SUIBUTTONBARIMPLUNITTEST_H
