#include "SUIImageEnumUnitTest.h"
#include <QTest>

SUI::ImageEnumUnitTest::ImageEnumUnitTest()
{
}

SUI::ImageEnumUnitTest::~ImageEnumUnitTest() {
}

void SUI::ImageEnumUnitTest::testgetFileExtension() {
    std::string jpg = SUI::ImageEnum::getFileExtension(SUI::ImageEnum::JPG);
    QCOMPARE(QString::fromStdString(jpg), QString(".jpg"));
    std::string tiff = SUI::ImageEnum::getFileExtension(SUI::ImageEnum::TIFF);
    QCOMPARE(QString::fromStdString(tiff), QString(".tiff"));
    std::string bmp = SUI::ImageEnum::getFileExtension(SUI::ImageEnum::BMP);
    QCOMPARE(QString::fromStdString(bmp), QString(".bmp"));
    std::string png = SUI::ImageEnum::getFileExtension(SUI::ImageEnum::PNG);
    QCOMPARE(QString::fromStdString(png), QString(".png"));
}


