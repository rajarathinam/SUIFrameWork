
#ifndef SUITREEVIEWIMPLUNITTEST_H
#define SUITREEVIEWIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class TreeViewImpl;

class TreeViewImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit TreeViewImplUnitTest(TreeViewImpl *object, QObject *parent = 0);
    virtual ~TreeViewImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    TreeViewImpl *object;
};

}
#endif // SUITREEVIEWIMPLUNITTEST_H
