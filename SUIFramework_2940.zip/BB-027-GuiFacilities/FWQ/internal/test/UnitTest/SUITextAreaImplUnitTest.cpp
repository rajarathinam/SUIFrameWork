
#include "SUITextAreaImplUnitTest.h"
#include "SUITextAreaImpl.h"
#include "SUIBaseObject.h"

SUI::TextAreaImplUnitTest::TextAreaImplUnitTest(SUI::TextAreaImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::TextAreaImplUnitTest::~TextAreaImplUnitTest()
{
   delete object;
}

void SUI::TextAreaImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::EditorForm);
    object->setDefaultProperties(SUI::BaseObject::EditorSelector);
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
