#ifndef SUIORIENTATIONENUMUNITTEST_H
#define SUIORIENTATIONENUMUNITTEST_H

#include <QObject>

#include "FWQxCore/SUIOrientationEnum.h"

namespace SUI {

class OrientationEnumUnitTest : public QObject
{
    Q_OBJECT

public:
    OrientationEnumUnitTest();
    virtual ~OrientationEnumUnitTest();

private slots:
    void testToString();
    void testToString2();
    void testGetOrientationList();

};

}
#endif // SUIORIENTATIONENUMUNITTEST_H
