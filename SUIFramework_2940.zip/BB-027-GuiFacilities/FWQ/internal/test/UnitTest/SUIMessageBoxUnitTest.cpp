#include "SUIMessageBoxUnitTest.h"
#include <FWQxWidgets/SUIMessageBox.h>
#include <FWQxWidgets/SUICheckBox.h>
#include <FWQxCore/SUIObjectFactory.h>
#include <QTest>
#include "SUIITextUnitTest.h"
#include "SUIIClickableUnitTest.h"

SUI::MessageBoxUnitTest::MessageBoxUnitTest(SUI::MessageBox *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::MessageBoxUnitTest::~MessageBoxUnitTest() {
    delete object;
}

void SUI::MessageBoxUnitTest::messageBoxWithParent() {
    SUI::DialogRejecter dialogRejector;
    Q_UNUSED(dialogRejector);
    //parent CheckBox
    SUI::CheckBox *chkBox = SUI::ObjectFactory::getInstance()->createWidget_<SUI::CheckBox>(NULL);
    object->about(chkBox, "Checkbox parent about", "");
    object->critical(chkBox, "Checkbox parent critical", "" );
    object->custom(chkBox,"checkbox parent custom", "");
    object->warning(chkBox,"checkbox parent warning", "");
    object->question(chkBox,"checkbox parent question", "");
    object->message(chkBox,"checkbox parent message", "");

    delete chkBox;
}

void SUI::MessageBoxUnitTest::callInterfaceTests() {
    // IText UnitTests
    ITextUnitTest iTextUnitTest(object);
    QVERIFY(iTextUnitTest.setText());
    QVERIFY(iTextUnitTest.clearText());
    QVERIFY(iTextUnitTest.setBold());

    //IClickable tests
    IClickableUnitTest iClickable(object);
    iClickable.clickable();
}
