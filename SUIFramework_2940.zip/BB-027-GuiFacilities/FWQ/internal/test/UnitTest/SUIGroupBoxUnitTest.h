#ifndef SUIGROUPBOXUNITTEST_H
#define SUIGROUPBOXUNITTEST_H

#include "SUIWidgetUnitTest.h"


namespace SUI {

class GroupBox;

class GroupBoxUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
     explicit GroupBoxUnitTest(GroupBox *object, QObject *parent = 0);
    ~GroupBoxUnitTest();

protected:
    void callInterfaceTests();

private:
    GroupBox *object;
};

}

#endif // SUIGROUPBOXUNITTEST_H
