#include "SUIWebViewUnitTest.h"
#include <QTest>

SUI::WebViewUnitTest::WebViewUnitTest(SUI::WebView *object, QObject *parent) :
    WidgetUnitTest(object, parent),
    object(object)
{
}

SUI::WebViewUnitTest::~WebViewUnitTest()
{
    delete object;
}

void SUI::WebViewUnitTest::setUrl() {
    std::string url = "http://www.nu.nl/";
    object->setUrl(url);
    QCOMPARE(object->getUrl(), url);
}

void SUI::WebViewUnitTest::setHtml() {
    std::string html = "<!DOCTYPE html><html lang=\"en\"><head><title>Simple HTML document</title></head><body><h1>Hello World!</h1></body></html>";
    object->setHtml(html, "");
    QCOMPARE(object->getHtml(), html);
}

void SUI::WebViewUnitTest::setZoomFactor() {
    double factor = 1.5;
    object->setZoomFactor(factor);
    QCOMPARE(object->getZoomFactor(), factor);
}

