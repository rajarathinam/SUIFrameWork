
#include "SUIIPressableUnitTest.h"

#include <FWQxCore/SUIIPressable.h>
#include <boost/bind.hpp>

#include <QTest>

SUI::IPressableUnitTest::IPressableUnitTest(SUI::IPressable *object) :
    obj(object)
{
    Q_ASSERT(obj);
}

void SUI::IPressableUnitTest::pressable() {
    QVERIFY(obj->pressed.empty());
    obj->pressed = boost::bind(&IPressableUnitTest::onPress,this);
    QVERIFY(!obj->pressed.empty());
}

void SUI::IPressableUnitTest::onPress() {
    QVERIFY2(obj, "Mouse Pressed" );
}
