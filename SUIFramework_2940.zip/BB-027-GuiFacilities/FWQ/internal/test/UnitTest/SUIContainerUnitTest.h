#ifndef SUICONTAINERUNITTEST_H
#define SUICONTAINERUNITTEST_H

#include "SUIWidgetUnitTest.h"

namespace SUI {

class Container;

class ContainerUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    explicit ContainerUnitTest(Container *object, QObject *parent = 0);
    virtual ~ContainerUnitTest();

protected:
    void callInterfaceTests();

private:
    Container *object;
};

}


#endif // SUICONTAINERUNITTEST_H
