
#include "SUIScienceSpinBoxImplUnitTest.h"
#include "SUIScienceSpinBoxImpl.h"
#include "SUIBaseObject.h"

SUI::ScienceSpinBoxImplUnitTest::ScienceSpinBoxImplUnitTest(SUI::ScienceSpinBoxImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::ScienceSpinBoxImplUnitTest::~ScienceSpinBoxImplUnitTest()
{
   delete object;
}

void SUI::ScienceSpinBoxImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::EditorForm);
    object->setDefaultProperties(SUI::BaseObject::EditorSelector);
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
