#ifndef SUITREEVIEWUNITTEST_H
#define SUITREEVIEWUNITTEST_H

#include <FWQxWidgets/SUITreeView.h>
#include "SUIWidgetUnitTest.h"

namespace SUI {

class TreeView;

class TreeViewUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    explicit TreeViewUnitTest(SUI::TreeView *object, QObject *parent = 0);
    ~TreeViewUnitTest();

private slots:
    void setTitle();
    void testDisableHeader();

    void testAddTreeItem_data();
    void testAddTreeItem();
    void testIsLeafNode();
protected:
    void callInterfaceTests();

private:
    TreeView *object;
};

}

#endif // SUITREEVIEWUNITTEST_H
