//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class WidgetDefinition.
// !\description Header file for class WidgetDefinition.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef RTICWIDGETDEFINITION_H
#define RTICWIDGETDEFINITION_H

#include <QStandardItem>

#include <SUIObjectPropertyStorageImpl.h>
#include <SUIGUIDefinitionVisitor.h>
#include <SUIBaseWidget.h>
#include <FWQxCore/SUIObjectFactory.h>

#include "WidgetController.h"

class WidgetDefinition: public GUIDefinitionVisitor, public SUI::ObjectPropertyStorageImpl
{
public:
    WidgetDefinition();
    virtual ~WidgetDefinition();

    virtual void writeWidgetProperty(SUI::ObjectPropertyTypeEnum::Type key, const QString &value);
    virtual void writeInclude(const QString &include, const QString &fileName);

    virtual GUIDefinitionVisitor &openChildWidget();

    virtual void closeChildWidget();
    void reset();

    WidgetController *addToWidget(QWidget *parent, bool isNew);

    void setSelected(bool selected);
    bool isSelected() const;

    QList<WidgetDefinition *> mChildren;

private:
    bool mIsSelected;

    void addTreeChild(WidgetDefinition *childWidget, WidgetController *pDragAndDropWidget, QString parentID);

    virtual SUI::ObjectProperty *getProperty(SUI::ObjectPropertyTypeEnum::Type /*propertyID*/) const { return NULL; }

};

#endif // RTICWIDGETDEFINITION_H
