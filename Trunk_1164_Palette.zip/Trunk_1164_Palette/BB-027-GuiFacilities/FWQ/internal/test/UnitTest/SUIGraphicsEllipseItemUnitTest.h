#ifndef GRAPHICSELLIPSEITEMUNITTEST_H
#define GRAPHICSELLIPSEITEMUNITTEST_H

#include "SUIObjectUnitTest.h"

namespace SUI {

class GraphicsEllipseItem;

class GraphicsEllipseItemUnitTest : public ObjectUnitTest
{
    Q_OBJECT

public:
    GraphicsEllipseItemUnitTest(GraphicsEllipseItem *object, QObject *parent = 0);
    virtual ~GraphicsEllipseItemUnitTest();

private slots:
    void setPosition();
    void setX();
    void setY();
    void setZValue();
    void setRotation();

private:
    GraphicsEllipseItem *object;
};

}
#endif // GRAPHICSELLIPSEITEMUNITTEST_H
