
#ifndef SUIWIDGETPAGEIMPLUNITTEST_H
#define SUIWIDGETPAGEIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class WidgetPageImpl;

class WidgetPageImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit WidgetPageImplUnitTest(WidgetPageImpl *object, QObject *parent = 0);
    virtual ~WidgetPageImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    WidgetPageImpl *object;
};

}
#endif // SUIWIDGETPAGEIMPLUNITTEST_H
