#ifndef SUIBUTTONIMPLUNITTEST_H
#define SUIBUTTONIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class ButtonImpl;

class ButtonImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit ButtonImplUnitTest(ButtonImpl *object, QObject *parent = 0);
    virtual ~ButtonImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    ButtonImpl *object;
};

}
#endif // SUIBUTTONIMPLUNITTEST_H
