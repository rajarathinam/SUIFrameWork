#ifndef SUILEDWIDGETUNITTEST_H
#define SUILEDWIDGETUNITTEST_H

#include "SUIWidgetUnitTest.h"


namespace SUI {

class LEDWidget;

class LEDWidgetUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    explicit LEDWidgetUnitTest(LEDWidget *object, QObject *parent = 0);
    virtual ~LEDWidgetUnitTest();

protected:
    void callInterfaceTests();

private:
    // TODO why no private slot for this test?
    bool setColorForLEDWidget();
    LEDWidget *object;
};

}

#endif // SUILEDWIDGETUNITTEST_H
