
#ifndef SUIGRAPHICSVIEWIMPLUNITTEST_H
#define SUIGRAPHICSVIEWIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class GraphicsViewImpl;

class GraphicsViewImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit GraphicsViewImplUnitTest(GraphicsViewImpl *object, QObject *parent = 0);
    virtual ~GraphicsViewImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    GraphicsViewImpl *object;
};

}
#endif // SUIGRAPHICSVIEWIMPLUNITTEST_H
