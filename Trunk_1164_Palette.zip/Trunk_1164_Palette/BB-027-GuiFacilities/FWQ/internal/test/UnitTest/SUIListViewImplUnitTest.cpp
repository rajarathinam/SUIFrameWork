
#include "SUIListViewImplUnitTest.h"
#include "SUIListViewImpl.h"
#include "SUIBaseObject.h"

SUI::ListViewImplUnitTest::ListViewImplUnitTest(SUI::ListViewImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::ListViewImplUnitTest::~ListViewImplUnitTest()
{
   delete object;
}

void SUI::ListViewImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::EditorForm);
    object->setDefaultProperties(SUI::BaseObject::EditorSelector);
    object->setDefaultProperties(SUI::BaseObject::Gui);

}

void SUI::ListViewImplUnitTest::testGetSize()
{
  object->clearItems();
  QCOMPARE(0, object->getSize());

  std::list<std::string> datalist;
  datalist.push_back("Data1");
  datalist.push_back("Data2");
  datalist.push_back("Data3");
  datalist.push_back("Data4");
  object->addItems(datalist);
  QCOMPARE(4, object->getSize());
}

void SUI::ListViewImplUnitTest::testAddItems()
{
  object->clearItems();
  QCOMPARE(0, object->getSize());

  std::list<std::string> datalist;
  datalist.push_back("Data1");
  datalist.push_back("Data2");
  datalist.push_back("Data3");
  datalist.push_back("Data4");
  object->addItems(datalist);
  QCOMPARE(4, object->getSize());
}
void SUI::ListViewImplUnitTest::testClearItems()
{
  std::list<std::string> datalist;
  datalist.push_back("Data1");
  datalist.push_back("Data2");
  datalist.push_back("Data3");
  datalist.push_back("Data4");
  object->addItems(datalist);
  QCOMPARE(4, object->getSize());

  object->clearItems();
  QCOMPARE(0, object->getSize());
}

void SUI::ListViewImplUnitTest::testClearText()
{
  std::list<std::string> datalist1;
  datalist1.push_back("Data1");
  datalist1.push_back("Data2");
  datalist1.push_back("Data3");

  object->addItems(datalist1);
  QCOMPARE(3, object->getSize());
  object->clearText();
  QCOMPARE(0, object->getSize());
}

void SUI::ListViewImplUnitTest::testFormatStdString()
{
  // setText and getText also covered here

  std::string input = "ASML;Framework\nSUI";
  object->setText(input);
  std::string actual = object->getText();
  std::string expected = "ASML;Framework;SUI";
  QCOMPARE(actual, expected);

  object->clearItems();
  std::string input1 = "";
  object->setText(input1);
  std::string actual1 = object->getText();
  std::string expected1 = "";
  std::cout << actual1 << std::endl;
  QCOMPARE(actual1, expected1);

  object->clearItems();
  std::string input2 = " ";
  object->setText(input2);
  std::string actual2 = object->getText();
  std::string expected2 = " ";
  QCOMPARE(actual2, expected2);

  object->clearItems();
  std::string input3 = "ASMLSUIFramework";
  object->setText(input3);
  std::string actual3 = object->getText();
  std::string expected3 = "ASMLSUIFramework";
  QCOMPARE(actual3, expected3);

}
void SUI::ListViewImplUnitTest::testGetAllColumnItems()
{
  object->clearItems();
  std::list<std::string> datalist;
  datalist.push_back("Data1");
  datalist.push_back("Data2");
  datalist.push_back("Data3");

  object->addItems(datalist);

  std::string expected = "Data1;Data2;Data3";
  std::string actual = object->getAllColumnItems().toStdString();
  QCOMPARE(actual, expected);

  object->clearItems();

  std::string expected1 = "";
  std::string actual1 = object->getAllColumnItems().toStdString();
  QCOMPARE(actual1, expected1);

}

void SUI::ListViewImplUnitTest::testGetItems()
{
  object->clearItems();
  std::list<std::string> datalist;
  datalist.push_back("Data1");
  datalist.push_back("Data2");
  datalist.push_back("Data3");

  object->addItems(datalist);

  std::list<std::string> actualList = object->getItems();
  int size = actualList.size();
  QCOMPARE(size, 3);

  std::string str1 = "Data1";
  QCOMPARE(actualList.front(), str1);
  actualList.pop_front();

  std::string str2 = "Data2";
  QCOMPARE(actualList.front(), str2);
  actualList.pop_front();

  std::string str3 = "Data3";
  QCOMPARE(actualList.front(), str3);
  actualList.pop_front();

  size = actualList.size();
  QCOMPARE(size, 0);

}
void SUI::ListViewImplUnitTest::testSetBold()
{
  object->setBold(false);
  QVERIFY(!object->isBold());

  object->setBold(true);
  QVERIFY(object->isBold());
}

void SUI::ListViewImplUnitTest::testRemoveItems()
{
  object->clearItems();

  std::list<std::string> datalist;
  datalist.push_back("Data1");
  datalist.push_back("Data2");
  datalist.push_back("Data3");
  datalist.push_back("Data4");
  datalist.push_back("Data5");
  datalist.push_back("Data6");
  datalist.push_back("Data7");

  object->addItems(datalist);

  std::list<std::string> actualList = object->getItems();
  int size = actualList.size();
  QCOMPARE(size, 7);
  object->selectItem(2);
  QCOMPARE(object->getWidget()->currentRow(), 2);

  std::list<std::string> removalDatalist;

  removalDatalist.push_back("Data3");
  removalDatalist.push_back("Data1");
  removalDatalist.push_back("Data5");
  object->removeItems(removalDatalist);

  std::list<std::string> actualList1 = object->getItems();
  int size1 = actualList1.size();
  QCOMPARE(size1, 4);
}

void SUI::ListViewImplUnitTest::testSelectItem()
{
  object->clearItems();

  std::list<std::string> datalist;
  datalist.push_back("Data1");
  datalist.push_back("Data2");
  datalist.push_back("Data3");
  datalist.push_back("Data4");
  datalist.push_back("Data5");
  datalist.push_back("Data6");
  datalist.push_back("Data7");
  datalist.push_back("Data3");

  object->addItems(datalist);

  std::list<std::string> actualList = object->getItems();
  int size = actualList.size();
  QCOMPARE(size, 7);

  object->selectItem(2);
  QCOMPARE(object->getWidget()->currentRow(), 2);

  object->selectItem(6);
  QCOMPARE(object->getWidget()->currentRow(), 6);

  object->selectItem(7);
  QCOMPARE(object->getWidget()->currentRow(), -1);

  object->selectItem(0);
  QCOMPARE(object->getWidget()->currentRow(), 0);
}

void SUI::ListViewImplUnitTest::testSetFilter()
{
  object->clearItems();

  std::list<std::string> datalist;
  datalist.push_back("Data1");
  datalist.push_back("Data2");
  datalist.push_back("Data3");
  datalist.push_back("Data4");
  datalist.push_back("Data5");
  datalist.push_back("Data6");
  datalist.push_back("Data7");

  object->addItems(datalist);

  std::list<std::string> actualList = object->getItems();
  int size = actualList.size();
  QCOMPARE(size, 7);

  std::string str1 = "Data1";
  object->setFilter(str1, true);
  std::list<std::string> actualList1 = object->getItems();
  int size1 = actualList1.size();
  QCOMPARE(size1, 1);


  std::string str2 = "Data";
  object->setFilter(str2, true);
  std::list<std::string> actualList2 = object->getItems();
  int size2 = actualList2.size();
  QCOMPARE(size2, 7);

  std::string str3 = "";
  object->setFilter(str3, true);
  std::list<std::string> actualList3 = object->getItems();
  int size3 = actualList3.size();
  QCOMPARE(size3, 7);

  std::string str4 = "Data3";
  object->setFilter(str4, true, false);
  std::list<std::string> actualList4 = object->getItems();
  int size4 = actualList4.size();
  QCOMPARE(size4, 1);
  std::string actualString = actualList4.front();
  std::string expectedString = "Data3";
  QCOMPARE(actualString, expectedString);

  std::string str5 = "Data";
  object->setFilter(str5, false);
  std::list<std::string> actualList5 = object->getItems();
  int size5 = actualList5.size();
  QCOMPARE(size5, 7);

  std::string str6 = "ASML";
  object->setFilter(str6, true);
  std::list<std::string> actualList6 = object->getItems();
  int size6 = actualList6.size();
  QCOMPARE(size6, 0);

  std::string str7 = "DATA3";
  object->setFilter(str7, true,true);
  std::list<std::string> actualList7 = object->getItems();
  int size7 = actualList7.size();
  QCOMPARE(size7, 0);
}

