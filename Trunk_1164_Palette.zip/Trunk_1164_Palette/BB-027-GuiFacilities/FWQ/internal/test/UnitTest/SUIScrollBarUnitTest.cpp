#include "SUIScrollBarUnitTest.h"
#include "SUIIOrientableUnitTest.h"
#include "SUIINumericUnitTest.h"
#include <QTest>
#include <boost/bind.hpp>

SUI::ScrollBarUnitTest::ScrollBarUnitTest(SUI::ScrollBar *object, QObject *parent) :
    WidgetUnitTest(object, parent),
    object(object)
{
}

SUI::ScrollBarUnitTest::~ScrollBarUnitTest()
{
    delete object;
}

void SUI::ScrollBarUnitTest::callInterfaceTests() {
    //IOrientable UnitTest
    IOrientableUnitTest iOrientableUnitTest(object);
    QVERIFY(iOrientableUnitTest.setOrientation(OrientationEnum::Horizontal));
    QVERIFY(iOrientableUnitTest.setOrientation(OrientationEnum::Vertical));

    //INumeric UnitTest
    INumericUnitTest iNumericUnitTest(object);
    QVERIFY(iNumericUnitTest.testInteger());
}

void SUI::ScrollBarUnitTest::setPageStep() {
    int pageStep = 5;

    object->setPageStep(pageStep);
    QCOMPARE(object->getPageStep(), pageStep);
}

void SUI::ScrollBarUnitTest::valueChanged() {
    const int startVal = 20;
    const int newVal = 40;

    object->setValue(startVal);
    object->valueChanged = boost::bind(&ScrollBarUnitTest::onChange,this);
    object->setValue(newVal);

    QVERIFY(!object->valueChanged.empty());
}

void SUI::ScrollBarUnitTest::onChange() {

}
