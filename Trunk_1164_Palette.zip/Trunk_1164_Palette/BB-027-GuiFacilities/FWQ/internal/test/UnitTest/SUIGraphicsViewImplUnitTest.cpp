
#include "SUIGraphicsViewImplUnitTest.h"
#include "SUIGraphicsViewImpl.h"
#include "SUIBaseObject.h"

SUI::GraphicsViewImplUnitTest::GraphicsViewImplUnitTest(SUI::GraphicsViewImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::GraphicsViewImplUnitTest::~GraphicsViewImplUnitTest()
{
   delete object;
}

void SUI::GraphicsViewImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::EditorForm);
    object->setDefaultProperties(SUI::BaseObject::EditorSelector);
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
