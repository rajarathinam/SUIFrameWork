#include "SUIRadioButtonUnitTest.h"
#include "SUIICheckableUnitTest.h"
#include "SUIITextUnitTest.h"
#include <QTest>

SUI::RadioButtonUnitTest::RadioButtonUnitTest(SUI::RadioButton *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::RadioButtonUnitTest::~RadioButtonUnitTest() {
    delete object;
}

void SUI::RadioButtonUnitTest::callInterfaceTests() {
    // IText UnitTests
    ITextUnitTest iTextUnitTest(object);
    QVERIFY(iTextUnitTest.setText());
    QVERIFY(iTextUnitTest.clearText());
    QVERIFY(iTextUnitTest.setBold());

    //ICheckable unit test
    ICheckableUnitTest icheckable(object);
    QVERIFY(icheckable.setChecked());
}
