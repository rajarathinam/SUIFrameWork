
#include "SUILineWidgetImplUnitTest.h"
#include "SUILineWidgetImpl.h"
#include "SUIBaseObject.h"

SUI::LineWidgetImplUnitTest::LineWidgetImplUnitTest(SUI::LineWidgetImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::LineWidgetImplUnitTest::~LineWidgetImplUnitTest()
{
   delete object;
}

void SUI::LineWidgetImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
