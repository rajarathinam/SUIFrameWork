#ifndef SUIWIDGETPAGEUNITTEST_H
#define SUIWIDGETPAGEUNITTEST_H

#include "SUIWidgetUnitTest.h"
#include <FWQxWidgets/SUIWidgetPage.h>

namespace SUI {

class WidgetPage;

class WidgetPageUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    explicit WidgetPageUnitTest(SUI::WidgetPage *object, QObject *parent = 0);
    virtual ~WidgetPageUnitTest();

private:
    WidgetPage *object;
};

}
#endif // SUIWIDGETPAGEUNITTEST_H
