#include "SUIOrientationEnumUnitTest.h"
#include <QTest>

SUI::OrientationEnumUnitTest::OrientationEnumUnitTest()
{
}

SUI::OrientationEnumUnitTest::~OrientationEnumUnitTest() {
}

void SUI::OrientationEnumUnitTest::testToString()
{
    std::string horizontalString = SUI::OrientationEnum::toString(SUI::OrientationEnum::Horizontal);
    QCOMPARE(QString::fromStdString(horizontalString), QString("Horizontal"));
    std::string verticalString = SUI::OrientationEnum::toString(SUI::OrientationEnum::Vertical);
    QCOMPARE(QString::fromStdString(verticalString), QString("Vertical"));
}


void SUI::OrientationEnumUnitTest::testToString2()
{
    std::list<OrientationEnum::Orientation> list;
    list.push_back(OrientationEnum::Horizontal);
    list.push_back(OrientationEnum::Vertical);
    std::string orientations = OrientationEnum::toString(list, std::string(","));
    QCOMPARE("Horizontal,Vertical", orientations.c_str());

    orientations = OrientationEnum::toString(list, std::string(";"));
    QCOMPARE("Horizontal;Vertical", orientations.c_str());

}

void SUI::OrientationEnumUnitTest::testGetOrientationList()
{
    std::list<std::string> list = OrientationEnum::getOrientationStringList();
    QCOMPARE(list.front(), std::string("Horizontal"));
    QCOMPARE(list.back(), std::string("Vertical"));
}
