
#ifndef SUITEXTAREAIMPLUNITTEST_H
#define SUITEXTAREAIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class TextAreaImpl;

class TextAreaImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit TextAreaImplUnitTest(TextAreaImpl *object, QObject *parent = 0);
    virtual ~TextAreaImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    TextAreaImpl *object;
};

}
#endif // SUITEXTAREAIMPLUNITTEST_H
