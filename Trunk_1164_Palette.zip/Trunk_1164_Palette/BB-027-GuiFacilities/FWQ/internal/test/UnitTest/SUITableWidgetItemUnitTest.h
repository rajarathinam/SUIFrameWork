#ifndef SUITABLEWIDGETITEMUNITTEST_H
#define SUITABLEWIDGETITEMUNITTEST_H
#include "SUIWidgetUnitTest.h"
#include <FWQxWidgets/SUITableWidgetItem.h>

namespace SUI {

class TableWidgetItem;

class TableWidgetItemUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    explicit TableWidgetItemUnitTest(SUI::TableWidgetItem *object, QObject *parent = 0);
    virtual ~TableWidgetItemUnitTest();

private slots:
    void setFontSize();

protected:
    void callInterfaceTests();

private:
    TableWidgetItem *object;
};

}
#endif // SUITABLEWIDGETITEMUNITTEST_H
