#ifndef SUITABLEWIDGETUNITTEST_H
#define SUITABLEWIDGETUNITTEST_H

#include "SUIWidgetUnitTest.h"

namespace SUI {

class TableWidget;

class TableWidgetUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    explicit TableWidgetUnitTest(TableWidget *object, QObject *parent = 0);
    virtual ~TableWidgetUnitTest();

protected:
    void callInterfaceTests();

private slots:
    void addRow();
    void testSetCellWidgetTypeAndAppendRow();
    void testSetCellWidgetTypeAndAppendRow_data();
    void testSpecificTest_AppendRow();
    void insertRow();
    void removeRow();
    void insertColumn();
    void removeColumn();
    void insertRows();
    void removeRows();
    void insertColumns();
    void removeColumns();
    void setItemText();
    void rowClicked();
    void setRowVisible();
    void setColumnVisible();
    void getWidgetItem();
    void testSetListViewMode();
    void testColumnFilter();

private:
    void onRowClicked(int row);

    int mRow;
    TableWidget *object;
};

}
#endif // SUITABLEWIDGETUNITTEST_H
