#ifndef SUIRADIOBUTTONUNITTEST_H
#define SUIRADIOBUTTONUNITTEST_H

#include "SUIWidgetUnitTest.h"
#include <FWQxWidgets/SUIRadioButton.h>

namespace SUI {

class RadioButton;

class RadioButtonUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    explicit RadioButtonUnitTest(SUI::RadioButton *object, QObject *parent = 0);
    virtual ~RadioButtonUnitTest();

protected:
    void callInterfaceTests();

private:
    RadioButton *object;
};

}
#endif // SUIRADIOBUTTONUNITTEST_H
