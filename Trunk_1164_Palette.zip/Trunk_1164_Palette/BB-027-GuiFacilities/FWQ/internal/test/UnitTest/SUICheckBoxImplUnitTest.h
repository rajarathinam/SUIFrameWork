
#ifndef SUICHECKBOXIMPLUNITTEST_H
#define SUICHECKBOXIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class CheckBoxImpl;

class CheckBoxImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit CheckBoxImplUnitTest(CheckBoxImpl *object, QObject *parent = 0);
    virtual ~CheckBoxImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    CheckBoxImpl *object;
};

}
#endif // SUICHECKBOXIMPLUNITTEST_H
