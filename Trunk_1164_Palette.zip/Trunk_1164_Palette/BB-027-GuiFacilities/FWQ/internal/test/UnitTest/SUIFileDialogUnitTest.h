#ifndef SUIFILEDIALOGUNITTEST_H
#define SUIFILEDIALOGUNITTEST_H

#include "SUIWidgetUnitTest.h"
#include <FWQxWidgets/SUIFileDialog.h>

namespace SUI {

class FileDialog;

class FileDialogUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
     explicit FileDialogUnitTest(SUI::FileDialog *object, QObject *parent = 0);
     virtual ~FileDialogUnitTest();

private slots:
     void fileDialogWithParent();

protected:
     void callInterfaceTests();

private:
     FileDialog *object;
};

}
#endif // SUIFILEDIALOGUNITTEST_H
