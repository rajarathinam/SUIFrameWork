
#include "SUIColorCrossDropImplUnitTest.h"
#include "SUIColorCrossDropImpl.h"
#include "SUIBaseObject.h"

SUI::ColorCrossDropImplUnitTest::ColorCrossDropImplUnitTest(SUI::ColorCrossDropImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::ColorCrossDropImplUnitTest::~ColorCrossDropImplUnitTest()
{
   delete object;
}

void SUI::ColorCrossDropImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
