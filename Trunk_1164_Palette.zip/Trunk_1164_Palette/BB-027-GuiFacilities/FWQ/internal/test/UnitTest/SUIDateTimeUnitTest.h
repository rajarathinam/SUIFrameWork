#ifndef SUIDATETIMEUNITTEST_H
#define SUIDATETIMEUNITTEST_H

#include <QObject>
#include <boost/shared_ptr.hpp>

namespace SUI {
class DateTime;
class DateTimeUnitTest : public QObject
{
    Q_OBJECT

public:
    DateTimeUnitTest();

private Q_SLOTS:

    void tesCurrentDateTime();
private:
    boost::shared_ptr<SUI::DateTime> dateTime;
};

}
#endif // SUIDATETIMEUNITTEST_H
