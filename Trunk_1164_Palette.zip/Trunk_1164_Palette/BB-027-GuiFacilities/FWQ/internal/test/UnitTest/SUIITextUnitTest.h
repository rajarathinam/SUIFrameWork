#ifndef ITEXTUNITTEST_H
#define ITEXTUNITTEST_H

namespace SUI {

class IText;

class ITextUnitTest
{
public:
    explicit ITextUnitTest(IText *object);

    bool setText();
    bool clearText();
    bool setBold();

private:
    IText *object;
};

}
#endif // ITEXTUNITTEST_H
