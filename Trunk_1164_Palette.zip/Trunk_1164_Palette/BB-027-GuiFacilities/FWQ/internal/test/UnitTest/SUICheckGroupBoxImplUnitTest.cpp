
#include "SUICheckGroupBoxImplUnitTest.h"
#include "SUICheckGroupBoxImpl.h"
#include "SUIBaseObject.h"

SUI::CheckGroupBoxImplUnitTest::CheckGroupBoxImplUnitTest(SUI::CheckGroupBoxImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::CheckGroupBoxImplUnitTest::~CheckGroupBoxImplUnitTest()
{
   delete object;
}

void SUI::CheckGroupBoxImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::EditorForm);
    object->setDefaultProperties(SUI::BaseObject::EditorSelector);
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
