
#include "SUITableWidgetItemImplUnitTest.h"
#include "SUITableWidgetItemImpl.h"
#include "SUIBaseObject.h"
#include "SUIIColorableUnitTest.h"

SUI::TableWidgetItemImplUnitTest::TableWidgetItemImplUnitTest(SUI::TableWidgetItemImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::TableWidgetItemImplUnitTest::~TableWidgetItemImplUnitTest()
{
   delete object;
}

void SUI::TableWidgetItemImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::EditorForm);
    object->setDefaultProperties(SUI::BaseObject::EditorSelector);
    object->setDefaultProperties(SUI::BaseObject::Gui);
}

void SUI::TableWidgetItemImplUnitTest::callInterfaceTests() {

    //IColorable tests
    IColorableUnitTest iColorableUnitTest(object);
    // Valid colors
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Standard));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Green));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Red));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Gray));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Blue));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::White));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Yellow));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Orange));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Transparent));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Black));

}

void SUI::TableWidgetItemImplUnitTest::colorPropertyTest() {
    object->setPropertyValue(SUI::ObjectPropertyTypeEnum::Color, QString::fromStdString(ColorEnum::toString(SUI::ColorEnum::Blue)));
    QCOMPARE(object->getPropertyValue(SUI::ObjectPropertyTypeEnum::Color), QString::fromStdString(ColorEnum::toString(SUI::ColorEnum::Blue)));
}
