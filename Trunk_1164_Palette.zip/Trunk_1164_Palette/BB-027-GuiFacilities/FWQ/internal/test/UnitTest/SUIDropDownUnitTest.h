#ifndef SUIDROPDOWNUNITTEST_H
#define SUIDROPDOWNUNITTEST_H

#include "SUIWidgetUnitTest.h"

namespace SUI {

class DropDown;

class DropDownUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    explicit DropDownUnitTest(DropDown *object, QObject *parent = 0);
    ~DropDownUnitTest();

protected:
    void callInterfaceTests();

private:
    DropDown *object;
};

}


#endif // SUIDROPDOWNUNITTEST_H
