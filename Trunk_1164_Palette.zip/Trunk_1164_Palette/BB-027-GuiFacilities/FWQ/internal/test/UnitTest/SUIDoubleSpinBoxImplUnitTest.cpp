
#include "SUIDoubleSpinBoxImplUnitTest.h"
#include "SUIDoubleSpinBoxImpl.h"
#include "SUIBaseObject.h"

SUI::DoubleSpinBoxImplUnitTest::DoubleSpinBoxImplUnitTest(SUI::DoubleSpinBoxImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::DoubleSpinBoxImplUnitTest::~DoubleSpinBoxImplUnitTest()
{
   delete object;
}

void SUI::DoubleSpinBoxImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::EditorForm);
    object->setDefaultProperties(SUI::BaseObject::EditorSelector);
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
