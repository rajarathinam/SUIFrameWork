#include "SUITabPageUnitTest.h"
#include <QTest>

SUI::TabPageUnitTest::TabPageUnitTest(SUI::TabPage *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::TabPageUnitTest::~TabPageUnitTest() {
    delete object;
}

void SUI::TabPageUnitTest::iconTest() {
    const std::string icon("ButterflyValveGreen.png");
    const std::string empty("");
    std::list<std::string> list;

    list = object->getAvailableIconNames();
    QVERIFY(list.size() > 20);

    object->setIconName(icon);
    QCOMPARE(object->getIconName(), icon);

    object->removeIcon();
    QCOMPARE(object->getIconName(), empty);
}

void SUI::TabPageUnitTest::tabTest() {
    const std::string title("Tab Test 1");

    object->setTabText(title);
    QCOMPARE(object->getTabText(), title);
}
