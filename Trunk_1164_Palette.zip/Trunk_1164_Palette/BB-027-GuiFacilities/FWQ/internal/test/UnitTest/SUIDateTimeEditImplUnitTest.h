
#ifndef SUIDATETIMEEDITIMPLUNITTEST_H
#define SUIDATETIMEEDITIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class DateTimeEditImpl;

class DateTimeEditImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit DateTimeEditImplUnitTest(DateTimeEditImpl *object, QObject *parent = 0);
    virtual ~DateTimeEditImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    DateTimeEditImpl *object;
};

}
#endif // SUIDATETIMEEDITIMPLUNITTEST_H
