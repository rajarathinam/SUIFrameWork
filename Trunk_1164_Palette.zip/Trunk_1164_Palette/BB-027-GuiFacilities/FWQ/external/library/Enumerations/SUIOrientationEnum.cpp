//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class OrientationEnum.
// !\description Header file for class OrientationEnum.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "FWQxCore/SUIOrientationEnum.h"

#include <algorithm>
#include <sstream>

std::map<SUI::OrientationEnum::Orientation,std::string> SUI::OrientationEnum::orientationMap = {
    {SUI::OrientationEnum::Horizontal,"Horizontal"},
    {SUI::OrientationEnum::Vertical,"Vertical"}
};

std::list<std::string> SUI::OrientationEnum::orientationStringList =
        std::list<std::string>({
                                   SUI::OrientationEnum::toString(SUI::OrientationEnum::Horizontal),
                                   SUI::OrientationEnum::toString(SUI::OrientationEnum::Vertical)
                               });

std::string SUI::OrientationEnum::toString(Orientation orientation) {
    std::map<Orientation,std::string>::const_iterator it = orientationMap.find(orientation);
    return it == orientationMap.end() ? orientationMap.find(OrientationEnum::Horizontal)->second : it->second;
}

std::list<std::string> SUI::OrientationEnum::getOrientationStringList() {
    return orientationStringList;
}

std::string SUI::OrientationEnum::toString(const std::list<Orientation> &list, const std::string &separator) {
    std::stringstream ss;
    for (std::list<OrientationEnum::Orientation>::const_iterator i = list.begin(); i != list.end(); ++i) {
        ss << toString(*i) << separator;
    }
    std::string s = ss.str();
    return s.substr(0,s.size()-1);
}
