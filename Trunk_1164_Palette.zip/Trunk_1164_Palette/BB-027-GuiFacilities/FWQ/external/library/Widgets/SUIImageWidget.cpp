//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for ImageWidget.
// !\description Class implementation file for ImageWidget.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "FWQxWidgets/SUIImageWidget.h"

#include "FWQxCore/SUIObjectFactory.h"

SUI::ImageWidget::ImageWidget() :
    Widget(SUI::ObjectType::ImageWidget)
{
}

SUI::ImageWidget::~ImageWidget()
{
}
