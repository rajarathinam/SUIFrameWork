//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::IPressable.
// !\description Header file for class SUI::IPressable.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|



#ifndef SUIIPRESSABLE_H
#define SUIIPRESSABLE_H

#include <boost/function.hpp>

namespace SUI {

/*!
 * \ingroup FWQxCore
 *
 * \brief Generic Interface class for the purpose of the mouse pressable widgets
 */
class IPressable
{
public:
    virtual ~IPressable() {}

    /*!
     * \brief pressed
     * Callback function that is called when the widget was pressed.
     * \fn pressed
     */
    boost::function<void()> pressed;

};
}

#endif // SUIIPRESSABLE_H
