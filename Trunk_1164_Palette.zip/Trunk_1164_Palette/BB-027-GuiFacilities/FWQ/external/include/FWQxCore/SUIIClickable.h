//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::IClickable.
// !\description Header file for class SUI::IClickable.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIICLICKABLE_H
#define SUIICLICKABLE_H

#include <boost/function.hpp>

namespace SUI {

/*!
 * \ingroup FWQxCore
 *
 * \brief Generic Interface class for the purpose of the clickable widgets
 */
class IClickable
{
public:
    virtual ~IClickable() {}

    /*!
     * \brief clicked
     * Callback function that is called when the widget was clicked.
     * \fn clicked
     */
    boost::function<void()> clicked;

};
}

#endif // ICLICKABLE_H
