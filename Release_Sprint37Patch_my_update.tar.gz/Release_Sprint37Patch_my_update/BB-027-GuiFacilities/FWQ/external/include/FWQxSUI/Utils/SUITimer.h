//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::Timer.
// !\description Header file for class SUI::Timer.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUITIMER_H
#define SUITIMER_H

#include "SUISharedExport.h"

#include <boost/function.hpp>
#include <boost/shared_ptr.hpp>

namespace SUI {

/*!
 * \ingroup FWQxUtils
 *
 * \brief The Timer class
 */
class SUI_SHARED_EXPORT Timer
{

public:
    virtual ~Timer();

    /*!
     * \brief interval
     * Returns the timeout interval in milliseconds.
     * The default value for this property is 0.
     * \return
     */
    virtual int	interval() const = 0;

    /*!
     * \brief isActive
     * Returns true if the timer is active; otherwise false
     * \return
     */
    virtual bool isActive() const = 0;

    /*!
     * \brief isSingleShot
     * Returns true if the timer is a single-shot timer; false otherwise.
     * A single-shot timer fires only once, non-single-shot timers fire every
     * interval milliseconds
     * \return
     */
    virtual bool isSingleShot() const = 0;

    /*!
     * \brief setInterval
     * Sets the timeout interval in milliseconds
     * \param msec
     */
    virtual void setInterval(int msec) = 0;

    /*!
     * \brief setSingleShot
     * Sets the timer to single shot (singleShow == true) or
     * non-single-shot (singleShot == false)
     * \param singleShot
     */
    virtual void setSingleShot(bool singleShot) = 0;

    /*!
     * \brief getTimerId
     * Returns the ID of the timer if the timer is running; otherwise returns -1.
     * \return
     */
    virtual int	getTimerId() const = 0;

    /*!
     * \brief start
     * Starts or restarts the timer with a timeout interval of msec milliseconds.
     * If the timer is already running, it will be stopped and restarted.
     * If singleShot is true, the timer will be activated only once.
     * \param msec
     */
    virtual void start(int msec) = 0;

    /*!
     * \brief start
     * Starts or restarts the timer with the timeout specified in interval.
     * If the timer is already running, it will be stopped and restarted.
     * If singleShot is true, the timer will be activated only once.
     */
    virtual void start() = 0;

    /*!
     * \brief stop
     * Stops the timer.
     */
    virtual void stop() = 0;

    /*!
     * \brief timeout
     * This signal is emitted when the timer times out.
     */
    boost::function<void()> timeout;
    
    /*!
     * \brief createTimer
     * Creates a new timer
     * \return
     */
    static boost::shared_ptr<Timer> createTimer();
};
} // namespace SUI

#endif // SUI_SUITIMER_H
