//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::Application.
// !\description Header file for class SUI::Application.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIAPPLICATION_H
#define SUIAPPLICATION_H

#include "SUISharedExport.h"
#include "SUILocaleEnum.h"

#include <list>
#include <string>

#include <boost/shared_ptr.hpp>

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief The Application class
 */
class SUI_SHARED_EXPORT Application
{
public:
    virtual ~Application();

    /*!
     * \brief createApplication
     *  Create an application object
     * \param argc
     * \param argv

     * \return
     */
    static boost::shared_ptr<Application> createApplication(int &argc, char *argv[]);

    /*!
     * \brief exec
     * \return
     *  Enters the main event loop and waits until exit() is called, then returns the value that was set to exit() (which is 0 if exit() is called via quit()).

     *  It is necessary to call this function to start event handling. The main event loop receives events from the window system and dispatches these to the application widgets.

     * Generally, no user interaction can take place before calling exec(). As a special case, modal widgets like QMessageBox can be used before calling exec(), because modal widgets call exec() to start a local event loop.

     */
    virtual int exec() = 0;

    /*!
     * \brief setLocale
     * If the language/country pair is found in the database, it is used.
     * If the language is found but the country is not, or if the country is AnyCountry, the language is used with the most appropriate available country (for example, Germany for German),
     * If neither the language nor the country are found, Locale defaults to the default locale
     * Sets the global default locale to locale.  If this function is not called, the system's locale is used.
     * \param language
     * \param country
     */
    virtual void setLocale(SUI::LocaleEnum::Language language, SUI::LocaleEnum::Country country) = 0;

    /*!
     * \brief setLocale
     * \param language
     * \param script
     * \param country

     * If the language/script/country is found in the database, it is used.
     * If both script is AnyScript and country is AnyCountry, the language is used with the most appropriate available script and country (for example, Germany for German),
     * If either script is AnyScript or country is AnyCountry, the language is used with the first locale that matches the given script and country.
     * If neither the language nor the country are found, Locale defaults to the default locale.
     * Sets the global default locale to locale.  If this function is not called, the system's locale is used.
     */
    virtual void setLocale(SUI::LocaleEnum::Language language, SUI::LocaleEnum::Script script, SUI::LocaleEnum::Country country) = 0;

    /*!
     * \brief getArguments
     * Returns the list of command-line arguments.
     * Usually arguments().at(0) is the program name, arguments().at(1) is the first argument, and arguments().last() is the last argument.
     * \return
     */
    virtual std::list<std::string> getArguments() const = 0;
    
    
};
}

#endif // SUIAPPLICATION_H
