//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::GraphicsEllipseItem.
// !\description Header file for class SUI::GraphicsEllipseItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUIGRAPHICSELLIPSEITEM_H
#define SUIGRAPHICSELLIPSEITEM_H

#include "SUIGraphicsItem.h"
#include "SUIColorEnum.h"

namespace SUI {
/*!
 * \ingroup FWQxGraphicsItems
 *
 * \brief The GraphicsEllipse class
 */
class SUI_SHARED_EXPORT GraphicsEllipseItem : public GraphicsItem
{
public:
    virtual ~GraphicsEllipseItem();

    /*!
     * \brief getPenColor
     * Returns the pen color
     * \return
     */
    SUI::ColorEnum::Color getPenColor() const;

    /*!
     * \brief setPenColor
     * Sets the pen color
     * \param color
     */
    void setPenColor(const SUI::ColorEnum::Color color);

    /*!
     * \brief setPenWidth
     * Sets the pen width
     * \param width
     */
    void setPenWidth(int width);

    /*!
     * \brief getPenWidth
     * Returns the pen width
     * \return
     */
    int getPenWidth() const;

    /*!
     * \brief setCosmetic
     * Sets the drawing pen to cosmetic or non-cosmetic.
     * Cosmetic pens have a constant width, so its outline
     * will have the same thickness at different scale factors
     * \param enabled
     */
    void setCosmetic(bool enabled);

    /*!
     * \brief getBrushColor
     * Returns the brush color
     * \return
     */
    SUI::ColorEnum::Color getBrushColor() const;

    /*!
     * \brief setBrushColor
     * Sets the brush color.
     * Side effect is that the pen color is also set to the specified color
     * \param color
     */
    void setBrushColor(const SUI::ColorEnum::Color color);

    /*!
     * \brief setSize
     * Sets width and height of the bounding rectangle
     * \param width
     * \param height
     */
    void setSize(double width, double height);
    
    /*!
     * \brief getWidth
     * Returns the width of the bounding rectangle
     * \return
     */
    double getWidth() const;

    /*!
     * \brief getHeight
     * Returns the height of the bounding rectangle
     * \return
     */
    double getHeight() const;

    /*!
     * \brief penColorChanged
     * Callback that is triggered when the pen color has changed
     */
    boost::function<void()> penColorChanged;

    /*!
     * \brief brushColorChanged
     * Callback that is triggered when the brush color has changed
     */
    boost::function<void()> brushColorChanged;

private:
    friend class ObjectFactory;
    explicit GraphicsEllipseItem(SUI::GraphicsItem *parent = NULL);
    GraphicsEllipseItem(const GraphicsEllipseItem &copy);
    GraphicsEllipseItem &operator=(const GraphicsEllipseItem &copy);
    
    SUI::ColorEnum::Color penColor;
};
}

#endif // SUIGRAPHICSELLIPSEITEM_H
