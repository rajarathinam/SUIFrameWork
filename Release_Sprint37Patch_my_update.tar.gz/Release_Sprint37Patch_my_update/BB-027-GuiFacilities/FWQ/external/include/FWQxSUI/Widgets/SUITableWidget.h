//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::TableWidget.
// !\description Header file for class SUI::TableWidget.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUITABLEWIDGET_H
#define SUITABLEWIDGET_H

#include "SUIWidget.h"

#include "SUIStringList.h"
#include "SUIIFilterable.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief The TableWidget class
 */
class SUI_SHARED_EXPORT TableWidget : public Widget, public StringList, public IFilterable
{
public:
    virtual ~TableWidget();

    /*!
     * \brief setListViewMode
     * Sets the selection mode. on == true means that the complete row is selected if
     * a cell in that row is clicked. on == false means that a single cell is
     * selected if clicked
     * \param on
     */
    virtual void setListViewMode(bool on) = 0;

    /*!
     * \brief getColumnItems
     * Retrieves a string list of items of the given column of the widget
     * \param int columnno - The column (zero-based) to retrieve the items from
     * \return
     */
    virtual std::list<std::string> getColumnItems(int column) const = 0;

    /*!
     * \brief getRowItems
     * Retrieves a string list of items of the given row of the widget
     * \param row - the row number (zero based) to the retrieve the items from
     * \return
     */
    virtual std::list<std::string> getRowItems(int row) const = 0;

    /*!
     * \brief addData
     * Adds data (text) to the specified row number (zero based)
     * \param row - the row number (zero based) to add the data to. If row is larger than
     * the current number of rows, rows will be added to the table widget, until row count
     * equals row
     * \param data - a list of data elements that will be added
     */
    virtual void addData(int row, const std::list<std::string> &data) = 0;

    /*!
     * \brief appendRow
     * Adds a row to the end of the TableWidget and copies the widgets of
     * the row above to the newly created row.
     * \param headertag
     */
    virtual void appendRow(const std::string &headertag = std::string("")) = 0;

    /*!
     * \brief removeRow
     * Removes the row at index 'row'. If there's only one row left, the row cannot be removed.
     * If the postion 'row' does not exist, nothing happens
     * \param row - the (zero-based) row to be removed
     */
    virtual void removeRow(int row) = 0;

    /*!
     * \brief rowCount
     * Returns the current number of rows
     * \return
     */
    virtual int rowCount() const = 0;

    /*!
     * \brief columnCount
     * Returns the current column count
     * \return
     */
    virtual int columnCount() const = 0;

    /*!
     * \brief getCellID
     * Returns the cell id of the table cell at position (row, column). Returns an
     * empty string is the position is invalid
     * \param row - row number (zero based)
     * \param column - column number (zero based)
     * \return
     */
    virtual std::string getCellID(int row, int column) const = 0;

    /*!
     * \brief getCellType
     * Returns the widget type of the table cell at position (row, column). Returns 'None'
     * if the position is invalid
     * \param row - row number (zero based)
     * \param column - column number (zero based)
     * \return
     */
    virtual SUI::ObjectType::Type getCellType(int row, int column) const = 0;

    /*!
     * \brief insertRows
     * Inserts a number of rows at a specified position
     * \param pos : start inserting rows here (0 based)
     * \param count : number of rows to add
     */
    virtual void insertRows(int pos, int count) = 0;

    /*!
     * \brief removeRows
     * Removes a number of rows at a specified position
     * \param pos : start removing rows here (0 based)
     * \param count : number of rows to remove
     * \return true if the removal was succesful. False otherwise
     */
    virtual bool removeRows(int pos, int count) = 0;

    /*!
     * \brief insertColumns
     * Inserts a number of columns at a specified position
     * \param pos : start inserting columns here (0 based)
     * \param count : number of columns to add
     */
    virtual void insertColumns(int position, int count) = 0;

    /*!
     * \brief removeColumns
     * Removes a number of columns at a specified position
     * \param pos : start removing columns here (0 based)
     * \param count : number of columns to remove
     * \return true if the removal was succesful. False otherwise
     */
    virtual bool removeColumns(int position, int count) = 0;

    /*!
     * \brief getItemText
     * Returns the text of table cell with given row and column index
     * \param row : row of the cell (0 based)
     * \param column: column of the cell (0 based)
     * \return
     */
    virtual std::string getItemText(int row, int column) const = 0;

    /*!
     * \brief setItemText
     * Sets the text of table cell with given row and column index
     * \param row : row number of the cell (0 based)
     * \param column: column number of the cell (0 based)
     * \param text: text to be set
     */
    virtual void setItemText(int row, int column, const std::string &text) = 0;

    /*!
     * \brief getWidgetItemByName
     * Returns the widget of the cell with cellname 'name'
     * \param name : cell name of the widget to be returned
     * \return Returns NULL if no widget can be found with the given name
     */
    virtual Widget *getWidgetItemByName(const std::string &name) const = 0;

    /*!
     * \brief setWidgetItemName
     * Sets the cell name of a table cell with given row and column number
     * \param row : row number of the cell (0 based)
     * \param column : column number of the cell (0 based)
     * \param name : cell name to be set
     */
    virtual void setWidgetItemName(int row, int column, const std::string &name) = 0;

    /*!
     * \brief swapRows
     * Swaps two rows in a table. Both rows need to be available
     * \param row1 : row number of first row to be swapped
     * \param row2 : row number of second row to be swapped
     * \NOTE: This is not implemented yet
     */
    virtual void swapRows(int row1, int row2) = 0;

    /*!
     * \brief showGrid
     * sets the Table grid to be dislayed (bShow == true) or not
     * \param bShow :True to display grid and false to hide
     */
    virtual void showGrid(const bool bShow) = 0;

    /*!
     * \brief cellClicked
     * Callback function that is called when a cell has been clicked
     * It returns the row/column number and the widget that is inside that cell
     */
    boost::function<void(int,int,Widget*)> cellClicked;

    /*!
     * \brief horizontalHeaderCellClicked
     * Callback function that is called when a horizontal header cell is clicked.
     * It returns the row/column number and the cell text
     */
    boost::function<void(int,int,std::string)> horizontalHeaderCellClicked;

    /*!
     * \brief verticalHeaderCellClicked
     * Callback function that is called when a vertical header cell is clicked.
     * It returns the row/column number and the cell text
     */
    boost::function<void(int,int,std::string)> verticalHeaderCellClicked;

    /*!
     * \brief rowClicked
     * Callback function that is called when a tablewidget cell is clicked.
     * It returns the row number
     */
    boost::function<void(int)> rowClicked;

protected:
    TableWidget();
};
}

#endif // SUITABLEWIDGET_H
