//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ColorCrossDrop.
// !\description Header file for class SUI::ColorCrossDrop.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|



#ifndef SUICOLORCROSSDROP_H
#define SUICOLORCROSSDROP_H

#include "SUIWidget.h"
#include "SUIIColorable.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 *
 * \brief The ColorCrossDrop class
 */
class SUI_SHARED_EXPORT ColorCrossDrop : public Widget, public IColorable
{
public:
    virtual ~ColorCrossDrop();

    /*!
     * \brief currentIndexChanged
     * Callback function that is called whenever the index of this widget changed. Returns the new index
     */
    boost::function<void(int)> currentIndexChanged;

protected:
    ColorCrossDrop();
};
}

#endif // SUICOLORCROSSDROP_H
