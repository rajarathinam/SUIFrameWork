//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ColorDrop.
// !\description Header file for class SUI::ColorDrop.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUICOLORDROP_H
#define SUICOLORDROP_H

#include "SUIWidget.h"
#include "SUIIColorable.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 *
 * \brief The ColorDrop class
 */
class SUI_SHARED_EXPORT ColorDrop : public Widget, public IColorable
{
public:
    virtual ~ColorDrop();

    /*!
     * \brief currentIndexChanged
     * Callback function that is called whenever the index of this widget changed. Returns the new index
     */
    boost::function<void(int)> currentIndexChanged;

protected:
    ColorDrop();
};
}

#endif // SUICOLORDROP_H
