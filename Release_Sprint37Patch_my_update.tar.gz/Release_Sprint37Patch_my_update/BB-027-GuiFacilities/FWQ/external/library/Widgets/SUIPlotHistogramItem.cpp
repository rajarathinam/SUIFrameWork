//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for PlotHistogramItem.
// !\description Class implementation file for PlotHistogramItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUIPlotHistogramItem.h"
#include "SUIPlotWidgetImpl.h"
#include "SUIObjectFactory.h"

#include <qwt_plot_histogram.h>

SUI::PlotHistogramItem::PlotHistogramItem(const std::string &title) :
    PlotItem(
        SUI::ObjectType::PlotHistogramItem
        ),
    penColor(SUI::ColorEnum::Black),
    brushColor(SUI::ColorEnum::Black)
{
    implementation = new QwtPlotHistogram(QString::fromStdString(title));
    static_cast<QwtPlotHistogram*>(implementation)->setStyle(QwtPlotHistogram::HistogramStyle::Columns);
}

SUI::PlotHistogramItem::~PlotHistogramItem() {
    delete static_cast<QwtPlotHistogram*>(implementation);
    implementation = NULL;
}

void SUI::PlotHistogramItem::attach(PlotWidget *plot) {
    if(plot != NULL){
        static_cast<QwtPlotHistogram*>(implementation)->attach(dynamic_cast<SUI::PlotWidgetImpl *>(plot)->plot());
    }
}

void SUI::PlotHistogramItem::detach() {
    intervalSamples.clear();
    static_cast<QwtPlotHistogram*>(implementation)->detach();
}

void SUI::PlotHistogramItem::setTitle(const std::string &title) {
    static_cast<QwtPlotHistogram*>(implementation)->setTitle(QString::fromStdString(title));
}

std::string SUI::PlotHistogramItem::getTitle() const {
    return static_cast<QwtPlotHistogram*>(implementation)->title().text().toStdString();
}

void SUI::PlotHistogramItem::show() {
    static_cast<QwtPlotHistogram*>(implementation)->show();
}

void SUI::PlotHistogramItem::hide() {
    static_cast<QwtPlotHistogram*>(implementation)->hide();
}

void SUI::PlotHistogramItem::setVisible(bool visible) {
    static_cast<QwtPlotHistogram*>(implementation)->setVisible(visible);
}

bool SUI::PlotHistogramItem::isVisible() const {
    return static_cast<QwtPlotHistogram*>(implementation)->isVisible();
}

void SUI::PlotHistogramItem::setAxes(SUI::PlotAxisEnum::PlotAxis xAxis, SUI::PlotAxisEnum::PlotAxis yAxis) {
    static_cast<QwtPlotHistogram*>(implementation)->setAxes(xAxis, yAxis);
}

void SUI::PlotHistogramItem::setXAxis(SUI::PlotAxisEnum::PlotAxis xAxis) {
    static_cast<QwtPlotHistogram*>(implementation)->setXAxis(xAxis);
}

SUI::PlotAxisEnum::PlotAxis SUI::PlotHistogramItem::getXAxis() const {
    return static_cast<SUI::PlotAxisEnum::PlotAxis>(static_cast<QwtPlotHistogram*>(implementation)->xAxis());
}

void SUI::PlotHistogramItem::setYAxis(SUI::PlotAxisEnum::PlotAxis axis) {
    static_cast<QwtPlotHistogram*>(implementation)->setYAxis(axis);
}

SUI::PlotAxisEnum::PlotAxis SUI::PlotHistogramItem::getYAxis() const {
    return static_cast<SUI::PlotAxisEnum::PlotAxis>(static_cast<QwtPlotHistogram*>(implementation)->yAxis());
}

double SUI::PlotHistogramItem::getZ() const {
    return static_cast<QwtPlotHistogram*>(implementation)->z();
}

void SUI::PlotHistogramItem::setZ(double z) {
    static_cast<QwtPlotHistogram*>(implementation)->setZ(z);
}

SUI::ColorEnum::Color SUI::PlotHistogramItem::getPenColor() const {
    return penColor;
}

void SUI::PlotHistogramItem::setPenColor(const SUI::ColorEnum::Color color) {
    if(penColor == color) return;
    if (ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color) == true) {
        penColor = color;
        static_cast<QwtPlotHistogram*>(implementation)->setPen(QColor(QString::fromStdString(SUI::ColorEnum::toString(penColor))));
    }
}

void SUI::PlotHistogramItem::setPenWidth(int width) {
    QPen pen = static_cast<QwtPlotHistogram*>(implementation)->pen();
    pen.setWidth(width);
    static_cast<QwtPlotHistogram*>(implementation)->setPen(pen);

}

int SUI::PlotHistogramItem::getPenWidth() const {
    return static_cast<QwtPlotHistogram*>(implementation)->pen().width();
}

SUI::ColorEnum::Color SUI::PlotHistogramItem::getBrushColor() const {
    return brushColor;
}

void SUI::PlotHistogramItem::setBrushColor(const SUI::ColorEnum::Color color) {
    if(brushColor == color) return ;
    if (ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color) == true) {
        brushColor = color;
        static_cast<QwtPlotHistogram*>(implementation)->setBrush(QColor(QString::fromStdString(SUI::ColorEnum::toString(brushColor))));
    }
}

void SUI::PlotHistogramItem::setSamples(const std::vector<SUI::PlotIntervalSample> &values) {
    for (uint i = 0; i < values.size(); i++)
    {
        intervalSamples.push_back(values.at(i));
    }
    plotHistogram();
}

void SUI::PlotHistogramItem::setSample(const SUI::PlotIntervalSample &value) {
    intervalSamples.push_back(value);
    plotHistogram();
}

void SUI::PlotHistogramItem::clearSamples() {
    intervalSamples.clear();
    //draw an empty histogram
    SUI::PlotIntervalSample sample(0.0,0.0,0.0);
    setSample(sample);
    intervalSamples.clear();
}

void SUI::PlotHistogramItem::plotHistogram() {
    QVector<QwtIntervalSample> samples(intervalSamples.size());
    for (uint i = 0; i < intervalSamples.size(); i++)
    {
        samples[i] = QwtIntervalSample(static_cast<SUI::PlotIntervalSample>(intervalSamples.at(i)).getValue(),
                                       static_cast<SUI::PlotIntervalSample>(intervalSamples.at(i)).getMinValue(),
                                       static_cast<SUI::PlotIntervalSample>(intervalSamples.at(i)).getMaxValue() );
    }
    static_cast<QwtPlotHistogram*>(implementation)->setData(new QwtIntervalSeriesData( samples));
}

