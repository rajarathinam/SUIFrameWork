//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for GraphicsView.
// !\description Class implementation file for GraphicsView.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIGraphicsView.h"

#include "SUIObjectFactory.h"
#include "SUIGraphicsScene.h"
#include "SUIGraphicsViewImpl.h"

#include <QGraphicsItem>
#include <QGraphicsScene>

SUI::GraphicsView::GraphicsView() :
    Widget(SUI::ObjectType::GraphicsView),
    scene(new GraphicsScene)
{
}

SUI::GraphicsView::~GraphicsView()
{
   delete scene;
}

SUI::GraphicsScene *SUI::GraphicsView::getGraphicsScene() {
   return scene;
}

void SUI::GraphicsView::setGraphicsScene(SUI::GraphicsScene *scene_ptr) {
   GraphicsViewImpl *impl = dynamic_cast<GraphicsViewImpl*>(const_cast<GraphicsView*>(this));
   impl->getWidget()->setScene(static_cast<QGraphicsScene*>(scene_ptr->implementation));
}

void SUI::GraphicsView::createScreenshot(const std::string &fileName, bool overLay, ImageEnum::FileType fileType) {
    QString strFileName = QString::fromStdString(fileName);
    strFileName.append(QString::fromStdString(ImageEnum::getFileExtension(fileType)));

    GraphicsViewImpl *impl = dynamic_cast<GraphicsViewImpl*>(const_cast<GraphicsView*>(this));
    // disable the scrollbars
    bool scrollBars = impl->getWidget()->isScrollBarsEnabled();
    setScrollBarsEnabled(false);

    // if overlay, paint all items
    if (overLay) {
        QPixmap pixMap = QPixmap::grabWidget(impl->getWidget());
        pixMap.save(strFileName);
    }
    // else hide items first
    else {
        // save visible status and hide
        QMap<QGraphicsItem *, bool>map;
        foreach(QGraphicsItem * item, impl->getWidget()->scene()->items()) {
            map.insert(item, item->isVisible());
            item->setVisible(false);
        }

        // grab the widget and save to file
        QPixmap pixMap = QPixmap::grabWidget(impl->getWidget());
        pixMap.save(strFileName);

        // restore visible status
        foreach(QGraphicsItem * item, impl->getWidget()->scene()->items()) {
            item->setVisible(map.find(item).value());
        }
    }

    //Restore the Scrollbar settings
    setScrollBarsEnabled(scrollBars);
}

void SUI::GraphicsView::setAspectRatioMode(const AspectRatioEnum::Mode &mode) { 
   GraphicsViewImpl *impl = dynamic_cast<GraphicsViewImpl*>(const_cast<GraphicsView*>(this));
   if (impl->getPropertyValue(ObjectPropertyTypeEnum::AutoFitBG).toStdString() != AspectRatioEnum::toString(mode)) {
      impl->setPropertyValue(ObjectPropertyTypeEnum::AutoFitBG,QString::fromStdString(AspectRatioEnum::toString(mode)));
   }
   impl->getWidget()->fitInView(impl->getWidget()->sceneRect(),static_cast<Qt::AspectRatioMode>(mode));
}

void SUI::GraphicsView::fitInView(int x, int y, int width, int height) {
   GraphicsViewImpl *impl = dynamic_cast<GraphicsViewImpl*>(const_cast<GraphicsView*>(this));
   Qt::AspectRatioMode mode = static_cast<Qt::AspectRatioMode>(
         AspectRatioEnum::fromString(impl->getPropertyValue(ObjectPropertyTypeEnum::AutoFitBG).toStdString())
   );
   impl->getWidget()->fitInView(x,y,width,height,mode); 
}

double SUI::GraphicsView::getScale() const { 
    return dynamic_cast<GraphicsViewImpl*>(const_cast<GraphicsView*>(this))->getWidget()->getScale(); 
}

void SUI::GraphicsView::setMouseWheelZoomEnabled(bool enabled) { 
    dynamic_cast<GraphicsViewImpl*>(const_cast<GraphicsView*>(this))->getWidget()->setMouseWheelZoomEnabled(enabled); 
}

void SUI::GraphicsView::setScrollBarsEnabled(bool enabled) { 
    dynamic_cast<GraphicsViewImpl*>(const_cast<GraphicsView*>(this))->getWidget()->setScrollBarsEnabled(enabled); 
}

void SUI::GraphicsView::setDragMode(const DragModeEnum::Mode &mode) { 
    dynamic_cast<GraphicsViewImpl*>(const_cast<GraphicsView*>(this))->getWidget()->setDragMode(static_cast<QGraphicsView::DragMode>(mode));
}

void SUI::GraphicsView::zoom(double scale, int x, int y) { 
    dynamic_cast<GraphicsViewImpl*>(const_cast<GraphicsView*>(this))->getWidget()->zoom(scale,x,y); 
}

void SUI::GraphicsView::setScaleFactor(double scale) {
    dynamic_cast<GraphicsViewImpl*>(const_cast<GraphicsView*>(this))->getWidget()->setScaleFactor(scale);
}

double SUI::GraphicsView::getScaleFactor() {
    return dynamic_cast<GraphicsViewImpl*>(const_cast<GraphicsView*>(this))->getWidget()->getScaleFactor();
}
