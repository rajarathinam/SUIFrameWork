#ifndef PLOTCURVEITEMTEST_H
#define PLOTCURVEITEMTEST_H
#include <vector>
#include <map>
#include <string>

namespace SUI {
class PlotCurveItem;
class PlotWidget;
class DropDown;
class Dialog;
class SpinBox;
class CheckBox;
class Button;
class LineEdit;
}

class PlotCurveTest
{
public:
    PlotCurveTest(SUI::Dialog *dialog);
    virtual ~PlotCurveTest();
private:
    void onAddCurveClicked();
    void onDeleteCurveClicked();
    void onHideCurveClicked();
    void onClearCurveClicked();
    void onAddRawSamplesClicked();
    void onAddSamplesClicked();
    void onPlotMarkerChecked(bool check);
    void onSetCurveClicked();
    void onShowCurveClicked();
    void onAddSampleClicked();
    void onAddScientificSampleClicked();
    void onPlotWidgetClicked();

    std::map<std::string, SUI::PlotCurveItem *> mapPlotCurves;
    SUI::Dialog *dialog;
    SUI::PlotWidget *plotWidget;

    SUI::Button *addCurve;
    SUI::Button *deleteCurve;
    SUI::Button *hideCurve;
    SUI::Button *addSamples;
    SUI::Button *addRawSamples;
    SUI::Button *clearCurve;
    SUI::Button *setCurve;

    SUI::Button *showCurve;
    SUI::Button *addSample;
    SUI::Button *addScientificSample;

    SUI::CheckBox *plotMarker;

    SUI::LineEdit *le_curveName;
    SUI::LineEdit *le_addSamples;
    SUI::LineEdit *le_addRawSamples;

    uint count;

    SUI::DropDown *dd_yaxis;
    double xRawData[100];
    double yRawData[100];
};

#endif // PLOTCURVETEST_H
