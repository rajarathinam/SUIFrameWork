#include "testWebView.h"

#include <SUIWebView.h>
#include <SUIButton.h>
#include <SUITextArea.h>
#include <SUIDoubleSpinBox.h>

// constructor
testWebView::testWebView(QString urlTextId, QString urlGoId,
            QString htmlTextId, QString htmlTryId, QString htmlSampleId,
            QString zoomSpinnerId, QString logTextId, QString webViewId,
            SUI::DialogImpl *apGui):
    mUrlTextId(urlTextId), mUrlGoId(urlGoId), mHtmlTextId(htmlTextId), mHtmlTryId(htmlTryId), mHtmlSampleId(htmlSampleId),
    mZoomSpinnerId(zoomSpinnerId), mLogTextId(logTextId), mWebViewId(webViewId), mpGui(apGui)
{
    SUI::INumeric<double>* numericWidget = mpGui->getObjectList()->getObject<SUI::INumeric<double> >(mZoomSpinnerId.toStdString());
    if (numericWidget == NULL)
    {
        return; // avoid crashing, do nothing
    }
    numericWidget->setValue(1.0);

    SUI::IWebView* webViewWidget = mpGui->getObjectList()->getObject<SUI::IWebView>(mWebViewId.toStdString());
    if (webViewWidget == NULL)
    {
        return; // avoid crashing, do nothing
    }

    webViewWidget->setZoomFactor(1.0);
}

void testWebView::handleClickedGo()
{
    SUI::IText* textWidget = mpGui->getObjectList()->getObject<SUI::IText>(mUrlTextId.toStdString());
    if (textWidget == NULL)
    {
        return; // avoid crashing, do nothing
    }

    SUI::IWebView* webViewWidget = mpGui->getObjectList()->getObject<SUI::IWebView>(mWebViewId.toStdString());
    if (webViewWidget == NULL)
    {
        return; // avoid crashing, do nothing
    }

    webViewWidget->setUrl(textWidget->getText());
    logText(QString("set URL: %1").arg(QString::fromStdString(webViewWidget->getUrl())));

}

void testWebView::handleClickedTry()
{
    SUI::IText* textWidget = mpGui->getObjectList()->getObject<SUI::IText>(mHtmlTextId.toStdString());
    if (textWidget == NULL)
    {
        return; // avoid crashing, do nothing
    }

    SUI::IWebView* webViewWidget = mpGui->getObjectList()->getObject<SUI::IWebView>(mWebViewId.toStdString());
    if (webViewWidget == NULL)
    {
        return; // avoid crashing, do nothing
    }

    QString htmlText = QString::fromStdString(textWidget->getText());
    logText(QString("Tried HTML : %1").arg(htmlText));
    webViewWidget->setHtml(htmlText.toStdString(), "");

}

void testWebView::handleClickedSample()
{
    SUI::IText* textWidget = mpGui->getObjectList()->getObject<SUI::IText>(mHtmlTextId.toStdString());
    if (textWidget == NULL)
    {
        return; // avoid crashing, do nothing
    }
    QString htmlText = "<!DOCTYPE html><html><body><div style=\"background-color:rgb(0,200,200)\"><fieldset><legend>WebView</legend>Content</fieldset></div></body></html>";
    textWidget->setText(htmlText.toStdString());
}

void testWebView::handleZoomChanged()
{
    SUI::INumeric<double>* numericWidget = mpGui->getObjectList()->getObject<SUI::INumeric<double> >(mZoomSpinnerId.toStdString());
    if (numericWidget == NULL)
    {
        return; // avoid crashing, do nothing
    }

    SUI::IWebView* webViewWidget = mpGui->getObjectList()->getObject<SUI::IWebView>(mWebViewId.toStdString());
    if (webViewWidget == NULL)
    {
        return; // avoid crashing, do nothing
    }

    webViewWidget->setZoomFactor(numericWidget->getValue());

    logText(QString("Zoom Changed: %1").arg(webViewWidget->getZoomFactor()));
}

void testWebView::handleLoadFinished(bool success)
{
    logText(QString("Load Finished: %1").arg(success ? "True" : "False"));
}

void testWebView::logText(QString message)
{
    SUI::IText* textWidget = mpGui->getObjectList()->getObject<SUI::IText>(mLogTextId.toStdString());
    if (textWidget == NULL)
    {
        return; // avoid crashing, do nothing
    }

    textWidget->setText(message.toStdString());
}
