#include "testzoomimageviewer.h"


#include <SUIIText.h>
#include <SUIGraphicsView.h>
#include <SUIDialogImpl.h>
#include <SUIIText.h>


testZoomImageViewer::testZoomImageViewer( QString Factor, QString X, QString Y, QString aTargetWidgetid, SUI::DialogImpl *apGui ):
    mFactor(Factor),
    mX(X),
    mY(Y),
    mTargetWidgetid(aTargetWidgetid),
    mpGui(apGui)
{
}

void testZoomImageViewer::handleClicked()
{
    SUI::GraphicsView *img = mpGui->getObjectList()->getObject<SUI::GraphicsView>(mTargetWidgetid.toStdString());
    SUI::IText *widgetTextmFact = mpGui->getObjectList()->getObject<SUI::IText>(mFactor.toStdString());
    SUI::IText *widgetTextmX = mpGui->getObjectList()->getObject<SUI::IText>(mX.toStdString());
    SUI::IText *widgetTextmY = mpGui->getObjectList()->getObject<SUI::IText>(mY.toStdString());
    if (img && widgetTextmFact && widgetTextmX && widgetTextmY)
    {
        img->zoom(QString::fromStdString(widgetTextmFact->getText()).toDouble(),
                  QString::fromStdString(widgetTextmX->getText()).toInt(), QString::fromStdString(widgetTextmY->getText()).toInt());
        double zoomfact = img->getScale();
        SUI::IText *textWidget = mpGui->getObjectList()->getObject<SUI::IText>( "txaStatus"/*mStatusBox.toStdString()*/);
        if ( textWidget )
        {
            textWidget->setText( QString( QString( "Zoom factor: ") + QString::number( zoomfact, 'g', 2 ) ).toStdString() );
        }

    }
}
