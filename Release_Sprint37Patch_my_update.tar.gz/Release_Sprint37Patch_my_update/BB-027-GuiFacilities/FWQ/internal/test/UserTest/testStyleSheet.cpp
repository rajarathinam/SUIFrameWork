#include "testStyleSheet.h"

#include <SUIWidget.h>
#include <SUIIText.h>
#include <SUIStyleSheet.h>

testStyleSheet::testStyleSheet(QString aTextWidgetId, QString aWidgetId, SUI::DialogImpl *apGui) :
    mTextWidgetId(aTextWidgetId),
    mWidgetId(aWidgetId),
    mpGui(apGui)
{
}

void testStyleSheet::onSetStyleSheetClicked()
{
    SUI::IText *TextWidget = mpGui->getObjectList()->getObject<SUI::IText>(mTextWidgetId.toStdString());
    SUI::Widget *Widget = mpGui->getObjectList()->getObject<SUI::Widget>(mWidgetId.toStdString());
    if (Widget && TextWidget)
    {
        Widget->setStyleSheetClass(TextWidget->getText());
    }
}

void testStyleSheet::onResetStyleSheetClicked() {
    SUI::Widget *Widget = mpGui->getObjectList()->getObject<SUI::Widget>(mWidgetId.toStdString());
    if (Widget)
    {
        Widget->setStyleSheetClass("Default");
    }
}
