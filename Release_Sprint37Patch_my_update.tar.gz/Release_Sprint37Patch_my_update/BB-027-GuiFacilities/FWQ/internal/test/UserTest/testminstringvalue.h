#ifndef TESTMINSTRINGVALUE_H
#define TESTMINSTRINGVALUE_H


#include "SUIDialogImpl.h"

class testMinStringValue
{
public:
    testMinStringValue(QString aSourceWidgetID, QString aTargetWidgetID , SUI::DialogImpl *apGui);

    void    handleValueChanged();

private:
    QString mSourceWidgetid;
    QString mTargetWidgetid;
    SUI::DialogImpl  *mpGui;
};


#endif // TESTMINSTRINGVALUE_H
