#include "testSvgWidgetPage.h"

#include <SUISvgWidget.h>
#include <SUIIText.h>
#include <SUIIColorable.h>

//testSvgSetImage
testSvgSetImage::testSvgSetImage(QString aWidgetID, SUI::DialogImpl *apGui):
    mWidgetid(aWidgetID),
    mpGui(apGui)
{
}

void testSvgSetImage::handleClicked() {
    SUI::SvgWidget *widget = mpGui->getObjectList()->getObject<SUI::SvgWidget>(mWidgetid.toStdString());
    if (widget)
    {
        widget->setImage(":/testimages/testSvgImage.svg");
    }
}

//testSvgGetAllTags
testSvggetElementIdList::testSvggetElementIdList(QString aWidgetID1, QString aWidgetID2, SUI::DialogImpl *apGui):
    mWidgetid1(aWidgetID1),
    mWidgetid2(aWidgetID2),
    mpGui(apGui)
{
}

void testSvggetElementIdList::handleClicked() {
    SUI::IText		*widgetText;
    SUI::SvgWidget	*widget = mpGui->getObjectList()->getObject<SUI::SvgWidget>(mWidgetid1.toStdString());
    if (widget)
    {
        QStringList tagList;
        QString     tagValues;
        foreach(std::string item, widget->getElementIdList())
        {
            tagList.append(QString::fromStdString(item));
        }
        widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mWidgetid2.toStdString());
        if (widgetText)
        {
            tagValues = tagList.join(";");
            widgetText->setText(tagValues.toStdString());
        }
    }
}

//testSvgSetColor
void testSvgSetColor::handleClicked()
{
    SUI::SvgWidget	*widget = mpGui->getObjectList()->getObject<SUI::SvgWidget>(mWidgetid1.toStdString());
    if (widget)
    {
        SUI::IColorable    *widgetColor = mpGui->getObjectList()->getObject<SUI::IColorable>(mWidgetid2.toStdString());
        SUI::IText     *widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mWidgetid3.toStdString());
        if (widgetText && widgetColor)
        {
            widget->setElementColor(widgetText->getText(), widgetColor->getColor());
        }
    }
}

testSvgSetColor::testSvgSetColor(QString aWidgetID1, QString aWidgetID2, QString aWidgetID3, SUI::DialogImpl *apGui):
    mWidgetid1(aWidgetID1),
    mWidgetid2(aWidgetID2),
    mWidgetid3(aWidgetID3),
    mpGui(apGui)
{
}

//testSvgSetBorderColor
void testSvgSetBorderColor::handleClicked() {
    SUI::SvgWidget	*widget = mpGui->getObjectList()->getObject<SUI::SvgWidget>(mWidgetid1.toStdString());
    if (widget)
    {
        SUI::IColorable    *widgetColor = mpGui->getObjectList()->getObject<SUI::IColorable>(mWidgetid2.toStdString());
        SUI::IText     *widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mWidgetid3.toStdString());
        if (widgetText && widgetColor)
        {
            widget->setElementBorderColor(widgetText->getText(), widgetColor->getColor());
        }
    }
}

testSvgSetBorderColor::testSvgSetBorderColor(QString aWidgetID1, QString aWidgetID2, QString aWidgetID3, SUI::DialogImpl *apGui):
    mWidgetid1(aWidgetID1),
    mWidgetid2(aWidgetID2),
    mWidgetid3(aWidgetID3),
    mpGui(apGui)
{
}

//testSvgSetText
testSvgSetText::testSvgSetText(QString aWidgetID1, QString aWidgetID2, QString aWidgetID3, SUI::DialogImpl *apGui):
    mWidgetid1(aWidgetID1),
    mWidgetid2(aWidgetID2),
    mWidgetid3(aWidgetID3),
    mpGui(apGui)
{
}

void testSvgSetText::handleClicked()
{
    SUI::SvgWidget	*widget = mpGui->getObjectList()->getObject<SUI::SvgWidget>(mWidgetid1.toStdString());
    if (widget)
    {
        SUI::IText     *widgetidText = mpGui->getObjectList()->getObject<SUI::IText>(mWidgetid2.toStdString());
        SUI::IText     *widgetsetText = mpGui->getObjectList()->getObject<SUI::IText>(mWidgetid3.toStdString());
        if (widgetidText && widgetsetText)
        {
            widget->setElementText(widgetidText->getText(), widgetsetText->getText());
        }
    }
}
