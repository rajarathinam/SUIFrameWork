#ifndef TESTTABLEGETALL_H
#define TESTTABLEGETALL_H

#include <QString>



namespace SUI {
class DialogImpl;
}

class testTableGetAll
{
public:
    testTableGetAll(QString aTargetWidgetID, QString aSourceWidgetID, QString aSpinWidgetID, SUI::DialogImpl *apGui);
    void handleClicked();
private:
    QString mTargetWidgetID;
    QString mSourceWidgetID;
    QString mSpinWidgetID;
    SUI::DialogImpl  *mpGui;
};

class testTableCount
{
public:
    testTableCount(QString tableID, QString lineeditID, QString row_column, SUI::DialogImpl *apGui);

    void    handleClicked();

private:
    QString     mTableID;
    QString     mLineEditID;
    QString     mRowOrColumn;
    SUI::DialogImpl      *mpGui;
};

class testTableCellInfo
{
public:
    testTableCellInfo(QString tableID, QString lineeditID, QString xIsbID, QString yIsbID, QString IdOrType, SUI::DialogImpl *apGui);

    void    handleClicked();

private:
    QString     mTableID;
    QString     mLineEditID;
    QString     mX_IsbID;
    QString     mY_IsbID;
    QString     mIdOrType;
    SUI::DialogImpl      *mpGui;

};

class testTableSetItemText
{
public:
    testTableSetItemText(QString tableID, QString lineeditID, QString xIsbID, QString yIsbID, SUI::DialogImpl *apGui);

    void    handleClicked();

private:
    QString     mTableID;
    QString     mLineEditID;
    QString     mX_IsbID;
    QString     mY_IsbID;
    SUI::DialogImpl      *mpGui;
};

class testTableGetItemText
{
public:
    testTableGetItemText(QString tableID, QString lineeditID, QString xIsbID, QString yIsbID, SUI::DialogImpl *apGui);

    void    handleClicked();

private:
    QString     mTableID;
    QString     mLineEditID;
    QString     mX_IsbID;
    QString     mY_IsbID;
    SUI::DialogImpl      *mpGui;
};



#endif // TESTTABLEGETALL_H
