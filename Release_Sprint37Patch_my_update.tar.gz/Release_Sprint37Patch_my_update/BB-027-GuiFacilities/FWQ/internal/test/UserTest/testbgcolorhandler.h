#ifndef TESTBGCOLORHANDLER_H
#define TESTBGCOLORHANDLER_H

#include <SUIDialogImpl.h>

class testBGcolorHandler
{
public:
    QString mTargetWidgetid;
    QString mSourceWidgetid;
    SUI::DialogImpl  *mpGui;

public:
    void handleClicked();
    void handleValueChanged();
    testBGcolorHandler(QString aSourceWidgetID, QString aTargetWidgetID , SUI::DialogImpl *apGui);
};

#endif // TESTBGCOLORHANDLER_H
