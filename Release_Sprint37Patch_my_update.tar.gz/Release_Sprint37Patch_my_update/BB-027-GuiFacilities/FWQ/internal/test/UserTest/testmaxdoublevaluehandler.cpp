#include "testmaxdoublevaluehandler.h"

#include <SUIINumeric.h>

testMaxDoubleValueHandler::testMaxDoubleValueHandler(QString aSourceWidgetID, QString aTargetWidgetID, SUI::DialogImpl *apGui) :
    mSourceWidgetid(aSourceWidgetID),
    mTargetWidgetid(aTargetWidgetID),
    mpGui(apGui)
{
}

void testMaxDoubleValueHandler::handleValueChanged()
{
    SUI::INumeric<double> *widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<double>>(mSourceWidgetid.toStdString());
    if (widgetNum)
    {
        double val = widgetNum->getValue();
        widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<double>>(mTargetWidgetid.toStdString());
        if (widgetNum)
        {
            widgetNum->setMaxValue(val);
        }
    }
}
