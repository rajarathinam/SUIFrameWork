/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxEVENT.hpp
| Author       : Thijs Jacobs
| Description  : IGS event handling
|                This is a temporary solution
|                Event handling will become part of the FWQ GUI framework
|
| ! \file        IGSxEVENT.hpp
| ! \brief       IGS event queue
|
|-----------------------------------------------------------------------------|
|                                                                             |
|                Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IGSXEVENT_HPP
#define IGSXEVENT_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/lockfree/queue.hpp>
#include <SUIExternalEvent.h>
#include <SUIAbstractExternalEvent.h>

namespace IGS {

/*----------------------------------------------------------------------------|
|                                     Type Defs                               |
|----------------------------------------------------------------------------*/


/*----------------------------------------------------------------------------|
|                                     Interface Definition                    |
|----------------------------------------------------------------------------*/

// event queue
class EventQueue
{
public:
    static bool push(SUI::ExternalEvent<std::string>* _event) { return m_queue->push(_event); }
    static bool pop(SUI::ExternalEvent<std::string>*& _event) { return m_queue->pop(_event); }
private:
    static boost::lockfree::queue<SUI::ExternalEvent<std::string>*> *m_queue;
};

} // namespace IGS

#endif // IGSXEVENT_HPP

