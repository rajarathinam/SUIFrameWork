/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxITS_Impl.hpp
| Author       : Thijs Jacobs
| Description  : Header file for IGSxITS implementation
|
| ! \file        IGSxITS_Impl.hpp
| ! \brief       Header file for IGSxITS implementation
|
|-----------------------------------------------------------------------------|
|                                                                             |
|                Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IGSXITS_IMPL_HPP
#define IGSXITS_IMPL_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxITS.hpp"
#include <SUIExternalEvent.h>
#include <SUIExternalEventHandler.h>
#include <SUITimer.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Class Definition                        |
|----------------------------------------------------------------------------*/
namespace IGSxITS {

typedef int ErrorId;

class Driver : public MetaDescription
{
public:
    explicit Driver(const std::string& name, const std::string& description, int initializeDuration, int terminateDuration) :
        MetaDescription(name, description),
        m_driverState(DriverState::DS_TERMINATED),
        m_error(0) ,
        m_initializeDuration(initializeDuration),
        m_terminateDuration(terminateDuration),
        m_driverStatus(DriverState::DS_TERMINATED){}
    virtual ~Driver() {}

    DriverState::DriverStateEnum driverState() {return m_driverState;}
    void setDriverState(DriverState::DriverStateEnum state) {m_driverState = state;}

    ErrorId error() {return m_error;}
    void setError(ErrorId error) {m_error = error;}

    int initializeDuration() {return m_initializeDuration;}
    void setInitializeDuration(int duration) {m_initializeDuration = duration;}

    int terminateDuration() {return m_terminateDuration;}
    void setTerminateDuration(int duration) {m_terminateDuration = duration;}

    DriverStatus driverStatus() {return m_driverStatus;}
    void setDriverStatus(DriverStatus status) {m_driverStatus = status;}

private:
    DriverState::DriverStateEnum m_driverState;
    ErrorId m_error;
    int m_initializeDuration;
    int m_terminateDuration;
    DriverStatus m_driverStatus;
};



class InitTerminate_Impl : public InitTerminate
{
public:
    // instance
    static InitTerminate* getInstance();

    // meta data
    virtual MetaDescriptions getSysfuns();
    virtual MetaDescriptions getDrivers(const std::string& sysfunName);
    
    // init-terminate
    virtual void initializeSystem(const InitializeCompletedCallback& cb);
    virtual void initializeDrivers(const DriverNames& driverNames, const InitializeCompletedCallback& cb);
    virtual void terminateSystem(const TerminateCompletedCallback& cb);
    virtual void terminateDrivers(const DriverNames& driverNames, const TerminateCompletedCallback& cb);

    // current driver status
    virtual DriverStatus getDriverStatus(const std::string& driverName);

    // driver status changed event
    virtual void subscribeToDriverStatusChanged(const DriverStatusChangedCallback& cb);
    virtual void unsubscribeToDriverStatusChanged();

protected:
    InitTerminate_Impl();
    virtual ~InitTerminate_Impl();

private:
    Driver& driver(const std::string& driverName);
    void notifyDriverStateChanged(Driver& driver);
    void handleException(const std::string& err);

    // FSD callbacks
    void on_initializeSystemCompleted();
    void on_initializeDriversCompleted();
    void on_terminateSystemCompleted();
    void on_terminateDriversCompleted();
    void on_driverStatusChanged(int result, const std::string& driverName);

private:
//    // FSD servers
//    // FSD subscriptions

    // IGS callbacks
    boost::function<void (int)> m_initializeSystemCompletedCb;
    boost::function<void (int)> m_initializeDriversCompletedCb;
    boost::function<void (int)> m_terminateSystemCompletedCb;
    boost::function<void (int)> m_terminateDriversCompletedCb;
    boost::function<void (const std::string&, const DriverStatus&)> m_driverStatusChangedCb;

    std::vector<Driver> m_drivers; // driver administration
    Driver* m_driver; // initializing/terminating driver
    boost::shared_ptr<SUI::Timer> m_timer; // timer for updating driver states
    int m_elapsedTime; // elapsed time in ms
};

} // namespace IGSxITS

#endif // IGSXITS_IMPL_HPP

