#ifndef SUILINEWIDGETUNITTEST_H
#define SUILINEWIDGETUNITTEST_H

#include "SUIWidgetUnitTest.h"
#include "SUILineWidget.h"

namespace SUI {

class LineWidget;

class LineWidgetUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
     LineWidgetUnitTest(SUI::LineWidget *object, QObject *parent = 0);
    ~LineWidgetUnitTest();

private slots:

private:
    LineWidget *object;
};

}
#endif // SUILINEWIDGETUNITTEST_H
