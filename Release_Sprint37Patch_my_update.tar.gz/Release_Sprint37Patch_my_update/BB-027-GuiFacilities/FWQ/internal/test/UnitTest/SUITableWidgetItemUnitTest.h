#ifndef SUITABLEWIDGETITEMUNITTEST_H
#define SUITABLEWIDGETITEMUNITTEST_H
#include "SUIWidgetUnitTest.h"
#include "SUITableWidgetItem.h"

namespace SUI {

class TableWidgetItem;

class TableWidgetItemUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    TableWidgetItemUnitTest(SUI::TableWidgetItem *object, QObject *parent = 0);
    virtual ~TableWidgetItemUnitTest();

    void setFontSize();
private:
    TableWidgetItem *object;
};

}
#endif // SUITABLEWIDGETITEMUNITTEST_H
