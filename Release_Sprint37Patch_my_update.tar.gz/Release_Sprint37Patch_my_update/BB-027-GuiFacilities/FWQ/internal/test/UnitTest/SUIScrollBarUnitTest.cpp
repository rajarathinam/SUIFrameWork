#include "SUIScrollBarUnitTest.h"

SUI::ScrollBarUnitTest::ScrollBarUnitTest(SUI::ScrollBar *object, QObject *parent) :
    WidgetUnitTest(object, parent),
    object(object)
{
}

SUI::ScrollBarUnitTest::~ScrollBarUnitTest()
{
    delete object;
}

