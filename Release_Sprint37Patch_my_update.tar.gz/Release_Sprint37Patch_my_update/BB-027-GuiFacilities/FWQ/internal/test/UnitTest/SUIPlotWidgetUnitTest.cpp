#include "SUIPlotWidgetUnitTest.h"
#include "SUIPlotWidget.h"
#include <QTest>
#include "SUIITextUnitTest.h"
#include "SUIClickableUnitTest.h"
SUI::PlotWidgetUnitTest::PlotWidgetUnitTest(SUI::PlotWidget *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    plotwidget(object)
{

}

SUI::PlotWidgetUnitTest::~PlotWidgetUnitTest() {
    delete plotwidget;
}

void SUI::PlotWidgetUnitTest::callInterfaceTests() {
    // IText UnitTests
    ITextUnitTest iTextUnitTest(plotwidget);
    QVERIFY(iTextUnitTest.setText());
    QVERIFY(iTextUnitTest.clearText());
    QVERIFY(iTextUnitTest.setBold());

    //IClickable tests
    IClickableUnitTest iClickable(plotwidget);
    iClickable.clickable();
}


