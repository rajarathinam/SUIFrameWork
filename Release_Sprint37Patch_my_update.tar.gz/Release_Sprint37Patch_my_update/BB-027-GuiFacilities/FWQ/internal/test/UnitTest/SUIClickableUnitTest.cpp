#include "SUIClickableUnitTest.h"

#include <SUIIClickable.h>
#include <boost/bind.hpp>

#include <QTest>
SUI::IClickableUnitTest::IClickableUnitTest(SUI::IClickable *object) :
    obj(object)
{
    Q_ASSERT(obj);
}

void SUI::IClickableUnitTest::clickable() {
    QVERIFY(obj->clicked.empty());

    obj->clicked = boost::bind(&IClickableUnitTest::onClick,this);
    QVERIFY(!obj->clicked.empty());
}

void SUI::IClickableUnitTest::onClick() {

}
