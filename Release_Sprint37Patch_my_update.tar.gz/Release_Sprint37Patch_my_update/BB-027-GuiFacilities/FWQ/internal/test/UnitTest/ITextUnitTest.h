#ifndef ITEXTUNITTEST_H
#define ITEXTUNITTEST_H

#include <QTest>
#include <QString>
#include <QCheckBox>
#include <SUIObjectList.h>
#include <SUITableWidgetImpl.h>
#include <SUITreeViewImpl.h>
#include <SUIButtonImpl.h>
#include <SUICheckBoxImpl.h>
#include <SUIDoubleSpinBoxImpl.h>
#include <SUIGroupBoxImpl.h>
#include <SUILabelImpl.h>
#include <SUIListViewImpl.h>
#include <SUIPlotWidgetImpl.h>
#include <SUIProgressBarImpl.h>
#include <SUIQuestionMarkImpl.h>
#include <SUIRadioButtonImpl.h>
#include <SUIScienceSpinBoxImpl.h>
#include <SUISpinBoxImpl.h>
#include <SUITextAreaImpl.h>
#include <SUIMessageBoxImpl.h>
#include <SUILineEditImpl.h>
#include <SUIScrollBarImpl.h>

#include <SUIGraphicsTextItem.h>

class ITextUnitTest : public QObject
{
    Q_OBJECT

public:
    ITextUnitTest();


private Q_SLOTS:
    void cleanupTestCase();

    void testSetTextCase1();
    void testSetTextCase1_data();

    void testClearTextCase1();
    void testClearTextCase1_data();

    void testSetTextCase2();
    void testSetTextCase2_data();

    void testClearTextCase2();
    void testClearTextCase2_data();

    void testSetBoldCase1();
    void testSetBoldCase1_data();

private:
    SUI::ButtonImpl *button;
    SUI::CheckBoxImpl *checkbox;
    SUI::DoubleSpinBoxImpl *dblspinbox;
    SUI::GroupBoxImpl *groupbox;
    SUI::LabelImpl *label;
    SUI::LineEditImpl *lineedit;
    SUI::ListViewImpl *listview;
    SUI::PlotWidgetImpl *plotwidget;
    SUI::ProgressBarImpl *progressbar;
    SUI::QuestionMarkImpl *questionmark;
    SUI::RadioButtonImpl *radiobutton;
    SUI::ScienceSpinBoxImpl *sciencespinbox;
    SUI::SpinBoxImpl *spinbox;
    SUI::TableWidgetItemImpl *tablewidgetitem;
    SUI::TextAreaImpl *textarea;
    SUI::MessageBoxImpl *msgbox;
    SUI::GraphicsTextItem *graphicstext;
    SUI::TreeViewItemImpl *treeItem;

    SUI::IText *ibutton;
    SUI::IText *icheckbox;
    SUI::IText *igroupbox;
    SUI::IText *ilabel;
    SUI::IText *ilineedit;
    SUI::IText *ilistview;
    SUI::IText *iplotwidget;
    SUI::IText *iprogressbar;
    SUI::IText *iquestionmark;
    SUI::IText *iradiobutton;
    SUI::IText *itablewidgetitem;
    SUI::IText *itextarea;
    SUI::IText *imsgbox;
    SUI::IText *igraphicstext;
    SUI::IText *itreeItem;
};

#endif // ITEXTUNITTEST_H
