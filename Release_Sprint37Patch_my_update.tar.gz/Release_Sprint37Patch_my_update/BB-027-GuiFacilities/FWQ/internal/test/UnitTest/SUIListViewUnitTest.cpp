#include "SUIListViewUnitTest.h"
#include "SUIListView.h"
#include <QTest>
#include "SUIITextUnitTest.h"


SUI::ListViewUnitTest::ListViewUnitTest(SUI::ListView *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::ListViewUnitTest::~ListViewUnitTest() {
    delete object;
}

void SUI::ListViewUnitTest::callInterfaceTests() {
    // IText UnitTests
    ITextUnitTest iTextUnitTest(object);
    QVERIFY(iTextUnitTest.setText());
    QVERIFY(iTextUnitTest.clearText());
    QVERIFY(iTextUnitTest.setBold());

    //TO DO IClickable tests
    //TO DO StringList tests
    //TO DO IFilterable tests

}
