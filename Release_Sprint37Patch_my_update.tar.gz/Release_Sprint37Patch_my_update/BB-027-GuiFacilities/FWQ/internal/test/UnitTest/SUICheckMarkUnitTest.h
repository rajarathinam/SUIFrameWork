#ifndef SUICHECKMARKUNITTEST_H
#define SUICHECKMARKUNITTEST_H

#include "SUIWidgetUnitTest.h"

namespace SUI {

class CheckMark;

class CheckMarkUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
     CheckMarkUnitTest(CheckMark *object, QObject *parent = 0);
    ~CheckMarkUnitTest();

protected:
    void callInterfaceTests();

private slots:

private:
    CheckMark *object;
};

}
#endif // SUICHECKMARKUNITTEST_H
