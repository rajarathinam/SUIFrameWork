#include "SUIIViewableUnitTest.h"

#include <QTest>

#include <SUIIViewable.h>

#include <boost/bind.hpp>

SUI::IViewableUnitTest::IViewableUnitTest(IViewable *iViewable, QObject *parent) :
    QObject(parent),
    object(iViewable)
{
    Q_ASSERT(iViewable);
}

SUI::IViewableUnitTest::~IViewableUnitTest() {
    delete object;
}

void SUI::IViewableUnitTest::setVisible() {
    object->setVisible(true);
    QCOMPARE(object->isVisible(),true);

    object->setVisible(false);
    QCOMPARE(object->isVisible(),false);
}

void SUI::IViewableUnitTest::show() {
    object->show();
    QCOMPARE(object->isVisible(),true);
}

void SUI::IViewableUnitTest::hide() {
    object->hide();
    QCOMPARE(object->isVisible(),false);
}

void SUI::IViewableUnitTest::visibilityChanged() {
    QVERIFY(object->visibilityChanged.empty());

    object->visibilityChanged = boost::bind(&IViewableUnitTest::onVisibilityChanged,this, _1);
    QVERIFY(!object->visibilityChanged.empty());

    object->setVisible(true);
    QCOMPARE(mVisible, true);
    object->setVisible(false);
    QCOMPARE(mVisible, false);
}

void SUI::IViewableUnitTest::onVisibilityChanged(bool visible) {
    mVisible = visible;
}

