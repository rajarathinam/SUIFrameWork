//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for WidgetControllerInfo.
// !\description Class implementation file for WidgetControllerInfo.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "WidgetControllerInfo.h"

WidgetControllerInfo::WidgetControllerInfo(WidgetController *parent, WidgetController *dragged) :
    mParent(parent),
    mDragged(dragged),
    mTabPage(NULL)
{

}

WidgetController *WidgetControllerInfo::getParentWidget() const {
    return mParent;
}

WidgetController *WidgetControllerInfo::getDraggedWidget() const {
    return mDragged;
}

WidgetController *WidgetControllerInfo::getTabPageWidget() const {
    return mTabPage;
}

void WidgetControllerInfo::setTabPageWidget(const WidgetController *tpw) {
    mTabPage = const_cast<WidgetController *>(tpw);
}

void WidgetControllerInfo::setDraggedWidget(WidgetController *wcDragged) {
    mDragged = wcDragged;
}

