//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class PropertiesEditor.
// !\description Header file for class PropertiesEditor.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef PROPERTIESEDITOR_H
#define PROPERTIESEDITOR_H

#include <SUIObjectProperty.h>

#include <QWidget>
#include <QTableWidget>
#include <QList>
#include <QSignalMapper>
#include <QAbstractButton>

#include <SUIObjectType.h>
#include <SUIBaseObject.h>

class PropertiesEditor : public QWidget
{
    Q_OBJECT
public:
    PropertiesEditor(QWidget *parent = 0);
    virtual ~PropertiesEditor();

    void setObject(SUI::BaseObject *object);

    void addTableRow(const SUI::ObjectType::Type &objectType, SUI::ObjectProperty *property, const bool &bValueRO = false , int maxkeyval = 0 , int maxvalue = 0);

    void clearTable();
    void setMaxTableHeight();
    QTableWidget *getTablePointer() const;
    void addNonPropertyToTable(QString key, SUI::ObjectProperty::ObjectPropertyDataType property, QStringList list);
private:
    QTableWidget *mpPropertiesTable;
    QSignalMapper *mComboSignalMapper;
    QSignalMapper *mSpinboxSignalMapper;
    QSignalMapper *mPushSignalMapper;
    QSignalMapper *mSpinboxIndexedValueSignalMapper;
    QSignalMapper *mSpinboxKeyMapper;

    QTableWidget *mStateImageTable;
    QString WidgetTypeText;

    void onAddStates();
    void onTreeWidgetEdit();
    void onAddHorizontalHeader();
    void onAddVerticalHeader();
    void changeSpinBox(SUI::ObjectType::Type spinBoxType);
    void showTabImages();

    void createSpinBox(SUI::ObjectProperty *property, int rowNr, bool readOnly);
    void createDoubleSpinBox(SUI::ObjectProperty *property, int rowNr, bool readOnly);
    void createScienceSpinBox(SUI::ObjectProperty *property, int rowNr, bool readOnly);

signals:
    void propertyValueChanged(QString , QString);
    void propertyIndexedValueChanged(QString , QString);
    void getNewDoubleValue(QString, QString);

public slots:
    void onComboValueChanged(QString mapStr);
    void onSpinboxValueChanged(QString mapStr);
    void onButtonPushed(QString mapStr);
    void onSpinboxIndexedValueChanged(QString mapStr);
    void onSpinboxKeyChanged(QString mapStr);
    void onReceiveDoubleValue(QString key, QString val);

private slots:
    void ClickedAddStateTableRow(QAbstractButton *but);
    void ClickedDelStateTableRow(QAbstractButton *but);
};

#endif // PROPERTIESEDITOR_H
