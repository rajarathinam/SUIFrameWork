//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class UserControlDialog.
// !\description Header file for class UserControlDialog.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef USERCONTROLDIALOG_H
#define USERCONTROLDIALOG_H

#include <QDialog>

namespace Ui
{
class UserControlDialog;
}

class UserControlDialog : public QDialog
{
    Q_OBJECT

public:
    explicit UserControlDialog(const QString &instanceID, QWidget *parent = 0);
    virtual ~UserControlDialog();

    QString     getUserCtrlName() const;
    QString     getId() const;
    bool        idChecked() const;

private:
    Ui::UserControlDialog *ui;
};

#endif // USERCONTROLDIALOG_H
