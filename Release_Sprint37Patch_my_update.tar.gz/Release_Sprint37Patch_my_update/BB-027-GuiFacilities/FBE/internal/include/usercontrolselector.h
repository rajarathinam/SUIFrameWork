//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class UserControlSelector.
// !\description Header file for class UserControlSelector.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef USERCONTROLSELECTOR_H
#define USERCONTROLSELECTOR_H

#include <QVBoxLayout>
#include <SUIObjectFactory.h>
#include "WidgetController.h"

class UserControlSelector : public WidgetController
{
public:
//    UserControlSelector();
    explicit UserControlSelector(QWidget *parent = 0);
    virtual ~UserControlSelector();

    void    initUserControls();
    void    init();
    void    clear();

private:
    QVBoxLayout                 *mUCtrlLayout;
    QList<WidgetController *>    mSeparatorList;

    UserControlSelector(const UserControlSelector &rhs);
    UserControlSelector &operator=(const UserControlSelector &rhs);
};

#endif // USERCONTROLSELECTOR_H
