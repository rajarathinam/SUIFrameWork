//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for GraphicsTextItem.
// !\description Class implementation file for GraphicsTextItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "FWQxGraphicsItems/SUIGraphicsTextItem.h"

#include <QString>
#include <QColor>
#include <QBrush>
#include <QPen>
#include <QFont>
#include <QGraphicsSimpleTextItem>

#include "FWQxCore/SUIObjectFactory.h"

SUI::GraphicsTextItem::GraphicsTextItem(SUI::GraphicsItem *parent) : 
    GraphicsItem(
          SUI::ObjectType::GraphicsTextItem,
          new QGraphicsSimpleTextItem(parent ? static_cast<QGraphicsItem*>(ObjectFactory::getImplementation(parent)) : NULL),
          parent),
    penColor(SUI::ColorEnum::Black)
{     
    QGraphicsSimpleTextItem *item = static_cast<QGraphicsSimpleTextItem*>(GraphicsItem::getImplementation());
    item->setZValue(1);
    item->setPen(QPen(QBrush(Qt::black),1));
    setPenColor(ColorEnum::Black);
    setBrushColor(ColorEnum::Black);
}


SUI::GraphicsTextItem::~GraphicsTextItem()
{
    delete static_cast<QGraphicsSimpleTextItem*>(GraphicsItem::getImplementation());
}

void SUI::GraphicsTextItem::setText(const std::string &value) {
    if (getText() == value) return;
    static_cast<QGraphicsSimpleTextItem*>(GraphicsItem::getImplementation())->setText(QString::fromStdString(value));
}

std::string SUI::GraphicsTextItem::getText() const {
    return static_cast<QGraphicsSimpleTextItem*>(GraphicsItem::getImplementation())->text().toStdString();
}

void SUI::GraphicsTextItem::clearText() {
    setText("");
}

void SUI::GraphicsTextItem::setPenWidth(int width) {
    QGraphicsSimpleTextItem *item = static_cast<QGraphicsSimpleTextItem*>(GraphicsItem::getImplementation());
    QPen pen = item->pen();
    pen.setWidth(width < 1 ? 1 : (width < 6 ? width : 5));
    item->setPen(pen);
}

int SUI::GraphicsTextItem::getPenWidth() const {
    return static_cast<QGraphicsSimpleTextItem*>(GraphicsItem::getImplementation())->pen().width();
}

void SUI::GraphicsTextItem::setPenColor(const SUI::ColorEnum::Color color) {
    if (!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color)) return;
    penColor = color;
    QGraphicsSimpleTextItem *item = static_cast<QGraphicsSimpleTextItem*>(GraphicsItem::getImplementation());
    QPen pen = item->pen();
    pen.setColor(QColor(QString::fromStdString(ColorEnum::toString(color))));
    item->setPen(pen);
}

SUI::ColorEnum::Color SUI::GraphicsTextItem::getBrushColor() const {
    return getPenColor();
}

void SUI::GraphicsTextItem::setBrushColor(const SUI::ColorEnum::Color color) {
    if (!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color) && color != ColorEnum::Transparent) return;
    if (color != ColorEnum::Transparent) {
        setPenColor(color);
    }
    static_cast<QGraphicsSimpleTextItem*>(GraphicsItem::getImplementation())->setBrush(color == ColorEnum::Transparent ? Qt::NoBrush : QBrush(QColor(QString::fromStdString(ColorEnum::toString(color)))));
}

void SUI::GraphicsTextItem::setBold(bool bold) {
    QGraphicsSimpleTextItem *item = static_cast<QGraphicsSimpleTextItem*>(GraphicsItem::getImplementation());
    QFont font = item->font();
    font.setBold(bold);
    item->setFont(font);
}

bool SUI::GraphicsTextItem::isBold() const {
    return static_cast<QGraphicsSimpleTextItem*>(GraphicsItem::getImplementation())->font().bold();
}

void SUI::GraphicsTextItem::setFontSize(int size) {
    QGraphicsSimpleTextItem *item = static_cast<QGraphicsSimpleTextItem*>(GraphicsItem::getImplementation());
    QFont font = item->font();
    font.setPointSize(size > 0 ? size : 1);
    item->setFont(font);
}

SUI::ColorEnum::Color SUI::GraphicsTextItem::getPenColor() const {
    return penColor;
}
