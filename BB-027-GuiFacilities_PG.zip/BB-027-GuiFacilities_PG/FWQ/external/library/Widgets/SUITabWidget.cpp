//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for TabWidget.
// !\description Class implementation file for TabWidget.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "FWQxWidgets/SUITabWidget.h"

#include "FWQxCore/SUIObjectFactory.h"

SUI::TabWidget::TabWidget() : 
    Widget(SUI::ObjectType::TabWidget)
{
}

SUI::TabWidget::~TabWidget()
{
}
