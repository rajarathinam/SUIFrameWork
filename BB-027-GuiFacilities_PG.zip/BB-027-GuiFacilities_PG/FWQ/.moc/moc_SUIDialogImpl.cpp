/****************************************************************************
** Meta object code from reading C++ file 'SUIDialogImpl.h'
**
** Created: Wed Jan 17 20:54:43 2018
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../internal/include/Widgets/SUIDialogImpl.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'SUIDialogImpl.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_SUI__DialogImpl[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      32,   17,   16,   16, 0x05,

 // slots: signature, parameters, type, tag, flags
      52,   16,   16,   16, 0x08,
      66,   63,   16,   16, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_SUI__DialogImpl[] = {
    "SUI::DialogImpl\0\0definitionfile\0"
    "sendClosed(QString)\0onClosed()\0id\0"
    "onChildClosed(QString)\0"
};

void SUI::DialogImpl::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        DialogImpl *_t = static_cast<DialogImpl *>(_o);
        switch (_id) {
        case 0: _t->sendClosed((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->onClosed(); break;
        case 2: _t->onChildClosed((*reinterpret_cast< QString(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData SUI::DialogImpl::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject SUI::DialogImpl::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_SUI__DialogImpl,
      qt_meta_data_SUI__DialogImpl, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &SUI::DialogImpl::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *SUI::DialogImpl::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *SUI::DialogImpl::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_SUI__DialogImpl))
        return static_cast<void*>(const_cast< DialogImpl*>(this));
    if (!strcmp(_clname, "Dialog"))
        return static_cast< Dialog*>(const_cast< DialogImpl*>(this));
    return QDialog::qt_metacast(_clname);
}

int SUI::DialogImpl::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    }
    return _id;
}

// SIGNAL 0
void SUI::DialogImpl::sendClosed(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_END_MOC_NAMESPACE
