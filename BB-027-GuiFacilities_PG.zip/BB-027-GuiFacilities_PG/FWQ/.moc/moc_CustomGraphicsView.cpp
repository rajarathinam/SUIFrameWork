/****************************************************************************
** Meta object code from reading C++ file 'CustomGraphicsView.h'
**
** Created: Wed Jan 17 20:54:40 2018
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../internal/include/Custom/CustomGraphicsView.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'CustomGraphicsView.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_CustomGraphicsView[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      20,   19,   19,   19, 0x05,

 // slots: signature, parameters, type, tag, flags
      44,   19,   19,   19, 0x0a,
      77,   56,   19,   19, 0x0a,
     120,  115,   19,   19, 0x2a,
     162,  138,   19,   19, 0x0a,
     225,  217,   19,   19, 0x2a,
     260,   19,   19,   19, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_CustomGraphicsView[] = {
    "CustomGraphicsView\0\0visibilityChanged(bool)\0"
    "fitInView()\0rect,aspectRadioMode\0"
    "fitInView(QRectF,Qt::AspectRatioMode)\0"
    "rect\0fitInView(QRectF)\0x,y,w,h,aspectRadioMode\0"
    "fitInView(qreal,qreal,qreal,qreal,Qt::AspectRatioMode)\0"
    "x,y,w,h\0fitInView(qreal,qreal,qreal,qreal)\0"
    "onSceneRectChanged(QRectF)\0"
};

void CustomGraphicsView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        CustomGraphicsView *_t = static_cast<CustomGraphicsView *>(_o);
        switch (_id) {
        case 0: _t->visibilityChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->fitInView(); break;
        case 2: _t->fitInView((*reinterpret_cast< const QRectF(*)>(_a[1])),(*reinterpret_cast< Qt::AspectRatioMode(*)>(_a[2]))); break;
        case 3: _t->fitInView((*reinterpret_cast< const QRectF(*)>(_a[1]))); break;
        case 4: _t->fitInView((*reinterpret_cast< qreal(*)>(_a[1])),(*reinterpret_cast< qreal(*)>(_a[2])),(*reinterpret_cast< qreal(*)>(_a[3])),(*reinterpret_cast< qreal(*)>(_a[4])),(*reinterpret_cast< Qt::AspectRatioMode(*)>(_a[5]))); break;
        case 5: _t->fitInView((*reinterpret_cast< qreal(*)>(_a[1])),(*reinterpret_cast< qreal(*)>(_a[2])),(*reinterpret_cast< qreal(*)>(_a[3])),(*reinterpret_cast< qreal(*)>(_a[4]))); break;
        case 6: _t->onSceneRectChanged((*reinterpret_cast< QRectF(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData CustomGraphicsView::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject CustomGraphicsView::staticMetaObject = {
    { &QGraphicsView::staticMetaObject, qt_meta_stringdata_CustomGraphicsView,
      qt_meta_data_CustomGraphicsView, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &CustomGraphicsView::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *CustomGraphicsView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *CustomGraphicsView::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_CustomGraphicsView))
        return static_cast<void*>(const_cast< CustomGraphicsView*>(this));
    return QGraphicsView::qt_metacast(_clname);
}

int CustomGraphicsView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QGraphicsView::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    }
    return _id;
}

// SIGNAL 0
void CustomGraphicsView::visibilityChanged(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_END_MOC_NAMESPACE
