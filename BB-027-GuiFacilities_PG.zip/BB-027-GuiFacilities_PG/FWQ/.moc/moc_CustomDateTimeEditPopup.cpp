/****************************************************************************
** Meta object code from reading C++ file 'CustomDateTimeEditPopup.h'
**
** Created: Wed Jan 17 20:55:02 2018
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../internal/include/Custom/CustomDateTimeEditPopup.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'CustomDateTimeEditPopup.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_CustomDateTimeEditPopup[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      41,   25,   24,   24, 0x05,

 // slots: signature, parameters, type, tag, flags
      74,   24,   24,   24, 0x08,
      86,   24,   24,   24, 0x08,
     102,   24,   24,   24, 0x08,
     118,   24,   24,   24, 0x08,
     133,   24,   24,   24, 0x08,
     151,   24,   24,   24, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_CustomDateTimeEditPopup[] = {
    "CustomDateTimeEditPopup\0\0newDate,newTime\0"
    "newDateTimeSelected(QDate,QTime)\0"
    "okClicked()\0cancelClicked()\0upHourClicked()\0"
    "upMinClicked()\0downHourClicked()\0"
    "downMinClicked()\0"
};

void CustomDateTimeEditPopup::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        CustomDateTimeEditPopup *_t = static_cast<CustomDateTimeEditPopup *>(_o);
        switch (_id) {
        case 0: _t->newDateTimeSelected((*reinterpret_cast< const QDate(*)>(_a[1])),(*reinterpret_cast< const QTime(*)>(_a[2]))); break;
        case 1: _t->okClicked(); break;
        case 2: _t->cancelClicked(); break;
        case 3: _t->upHourClicked(); break;
        case 4: _t->upMinClicked(); break;
        case 5: _t->downHourClicked(); break;
        case 6: _t->downMinClicked(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData CustomDateTimeEditPopup::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject CustomDateTimeEditPopup::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_CustomDateTimeEditPopup,
      qt_meta_data_CustomDateTimeEditPopup, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &CustomDateTimeEditPopup::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *CustomDateTimeEditPopup::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *CustomDateTimeEditPopup::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_CustomDateTimeEditPopup))
        return static_cast<void*>(const_cast< CustomDateTimeEditPopup*>(this));
    return QWidget::qt_metacast(_clname);
}

int CustomDateTimeEditPopup::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    }
    return _id;
}

// SIGNAL 0
void CustomDateTimeEditPopup::newDateTimeSelected(const QDate & _t1, const QTime & _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_END_MOC_NAMESPACE
