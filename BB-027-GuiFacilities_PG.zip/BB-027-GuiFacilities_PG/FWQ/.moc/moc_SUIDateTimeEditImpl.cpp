/****************************************************************************
** Meta object code from reading C++ file 'SUIDateTimeEditImpl.h'
**
** Created: Wed Jan 17 20:55:01 2018
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../internal/include/Widgets/SUIDateTimeEditImpl.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'SUIDateTimeEditImpl.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_SUI__DateTimeEditImpl[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      33,   23,   22,   22, 0x0a,
      77,   68,   22,   22, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_SUI__DateTimeEditImpl[] = {
    "SUI::DateTimeEditImpl\0\0date,time\0"
    "onNewDateTimeSelected(QDate,QTime)\0"
    "dateTime\0onDateTimeChanged(QDateTime)\0"
};

void SUI::DateTimeEditImpl::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        DateTimeEditImpl *_t = static_cast<DateTimeEditImpl *>(_o);
        switch (_id) {
        case 0: _t->onNewDateTimeSelected((*reinterpret_cast< const QDate(*)>(_a[1])),(*reinterpret_cast< const QTime(*)>(_a[2]))); break;
        case 1: _t->onDateTimeChanged((*reinterpret_cast< const QDateTime(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData SUI::DateTimeEditImpl::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject SUI::DateTimeEditImpl::staticMetaObject = {
    { &BaseWidget::staticMetaObject, qt_meta_stringdata_SUI__DateTimeEditImpl,
      qt_meta_data_SUI__DateTimeEditImpl, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &SUI::DateTimeEditImpl::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *SUI::DateTimeEditImpl::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *SUI::DateTimeEditImpl::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_SUI__DateTimeEditImpl))
        return static_cast<void*>(const_cast< DateTimeEditImpl*>(this));
    if (!strcmp(_clname, "DateTimeEdit"))
        return static_cast< DateTimeEdit*>(const_cast< DateTimeEditImpl*>(this));
    return BaseWidget::qt_metacast(_clname);
}

int SUI::DateTimeEditImpl::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = BaseWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
