/****************************************************************************
** Meta object code from reading C++ file 'SUITableWidgetImpl.h'
**
** Created: Wed Jan 17 20:54:31 2018
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../internal/include/Widgets/SUITableWidgetImpl.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'SUITableWidgetImpl.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_SUI__TableWidgetImpl[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      22,   21,   21,   21, 0x05,

 // slots: signature, parameters, type, tag, flags
      36,   21,   21,   21, 0x0a,
      52,   50,   21,   21, 0x08,
     108,  102,   21,   21, 0x08,
     147,  102,   21,   21, 0x08,
     184,   21,   21,   21, 0x08,
     206,   21,   21,   21, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_SUI__TableWidgetImpl[] = {
    "SUI::TableWidgetImpl\0\0dataChanged()\0"
    "updateTable()\0,\0"
    "onSelectionChanged(QItemSelection,QItemSelection)\0"
    "index\0onHorizontalHeaderClicked(QModelIndex)\0"
    "onVerticalHeaderClicked(QModelIndex)\0"
    "onHeaderDataChanged()\0"
    "onTableViewClicked(QModelIndex)\0"
};

void SUI::TableWidgetImpl::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        TableWidgetImpl *_t = static_cast<TableWidgetImpl *>(_o);
        switch (_id) {
        case 0: _t->dataChanged(); break;
        case 1: _t->updateTable(); break;
        case 2: _t->onSelectionChanged((*reinterpret_cast< QItemSelection(*)>(_a[1])),(*reinterpret_cast< QItemSelection(*)>(_a[2]))); break;
        case 3: _t->onHorizontalHeaderClicked((*reinterpret_cast< QModelIndex(*)>(_a[1]))); break;
        case 4: _t->onVerticalHeaderClicked((*reinterpret_cast< QModelIndex(*)>(_a[1]))); break;
        case 5: _t->onHeaderDataChanged(); break;
        case 6: _t->onTableViewClicked((*reinterpret_cast< QModelIndex(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData SUI::TableWidgetImpl::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject SUI::TableWidgetImpl::staticMetaObject = {
    { &BaseWidget::staticMetaObject, qt_meta_stringdata_SUI__TableWidgetImpl,
      qt_meta_data_SUI__TableWidgetImpl, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &SUI::TableWidgetImpl::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *SUI::TableWidgetImpl::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *SUI::TableWidgetImpl::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_SUI__TableWidgetImpl))
        return static_cast<void*>(const_cast< TableWidgetImpl*>(this));
    if (!strcmp(_clname, "TableWidget"))
        return static_cast< TableWidget*>(const_cast< TableWidgetImpl*>(this));
    return BaseWidget::qt_metacast(_clname);
}

int SUI::TableWidgetImpl::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = BaseWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    }
    return _id;
}

// SIGNAL 0
void SUI::TableWidgetImpl::dataChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}
QT_END_MOC_NAMESPACE
