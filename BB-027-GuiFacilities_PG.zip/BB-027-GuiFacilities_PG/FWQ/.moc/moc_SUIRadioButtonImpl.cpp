/****************************************************************************
** Meta object code from reading C++ file 'SUIRadioButtonImpl.h'
**
** Created: Wed Jan 17 20:54:15 2018
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../internal/include/Widgets/SUIRadioButtonImpl.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'SUIRadioButtonImpl.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_SUI__RadioButtonImpl[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      31,   22,   21,   21, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_SUI__RadioButtonImpl[] = {
    "SUI::RadioButtonImpl\0\0newState\0"
    "handleCheckedChanged(bool)\0"
};

void SUI::RadioButtonImpl::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        RadioButtonImpl *_t = static_cast<RadioButtonImpl *>(_o);
        switch (_id) {
        case 0: _t->handleCheckedChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData SUI::RadioButtonImpl::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject SUI::RadioButtonImpl::staticMetaObject = {
    { &BaseWidget::staticMetaObject, qt_meta_stringdata_SUI__RadioButtonImpl,
      qt_meta_data_SUI__RadioButtonImpl, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &SUI::RadioButtonImpl::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *SUI::RadioButtonImpl::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *SUI::RadioButtonImpl::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_SUI__RadioButtonImpl))
        return static_cast<void*>(const_cast< RadioButtonImpl*>(this));
    if (!strcmp(_clname, "RadioButton"))
        return static_cast< RadioButton*>(const_cast< RadioButtonImpl*>(this));
    return BaseWidget::qt_metacast(_clname);
}

int SUI::RadioButtonImpl::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = BaseWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
