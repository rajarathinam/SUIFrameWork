//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::DialogSerializer.
// !\description Class implementation file for SUI::DialogSerializer.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIDialogSerializer.h"
#include "FWQxCore/SUIIOException.h"
#include "FWQxCore/SUIXmlException.h"

#include <QTextStream>
#include <QMessageBox>
#include <boost/foreach.hpp>

#include <iostream>

SUI::DialogSerializer::DialogSerializer(const QString startElement, rticGuiSerializerMode mode):
    mXmlWriter(NULL),
    mXmlReader(NULL),
    mFile(NULL),
    mMode(mode),
    mStartElement(startElement),
    mWidgetCount(0)
{
}

SUI::DialogSerializer::~DialogSerializer() {
    if (mXmlWriter != NULL) delete mXmlWriter;
    if (mXmlReader != NULL) delete mXmlReader;
    if (mFile != NULL) delete mFile;
}

void SUI::DialogSerializer::openFile(const QString &filename) {
    mFile = new QFile(filename);
    if (mMode == Write) {
        if (mFile->open(QIODevice::WriteOnly | QIODevice::Text)) {
            mXmlWriter = new QXmlStreamWriter(mFile);
            mXmlWriter->setAutoFormatting(true);
            mXmlWriter->writeStartDocument();
            mXmlWriter->writeStartElement(mStartElement);
        }
        else {
            QString errorStr = mFile->errorString();
            mFile = NULL;
            throw new SUI::IOException(std::string(" Unable to open file").append(filename.toStdString()).append(" for writing. Error: ").append(errorStr.toStdString()));
        }
    }
    else {
        if (mFile->open(QIODevice::ReadOnly | QIODevice::Text)) {
            mWidgetCount = 0;
            mXmlReader = new QXmlStreamReader(mFile);

            bool retVal = false;

            while ((!mXmlReader->atEnd()) && (!mXmlReader->hasError()) && (!retVal)) {
                if (mXmlReader->isStartElement()) {
                    if (mXmlReader->name() == mStartElement) retVal = true;
                }
                mXmlReader->readNext();
            }
            if (mXmlReader->hasError()) {
                throw new SUI::XmlException(std::string("XmlException. Error: ").append(mXmlReader->errorString().toStdString()));
            }
        }
        else {
            QString errorStr = mFile->errorString();
            mFile = NULL;
            throw new SUI::IOException(std::string("IOException").append(" Unable to open file").append(" for reading. Error: ").append(errorStr.toStdString()));
        }
    }
}

void SUI::DialogSerializer::closeFile() {
    if (mMode == Write) {
        if (mXmlWriter != NULL) {
            mXmlWriter->writeEndElement();
            mXmlWriter->writeEndDocument();
            delete mXmlWriter;
            mXmlWriter = NULL;
        }
    }
    else {
        if (mXmlReader != NULL) {
            delete mXmlReader;
            mXmlReader = NULL;
        }
    }
    if (mFile != NULL) {
        mFile->close();
        mFile->deleteLater();
        mFile = NULL;
    }
}

void SUI::DialogSerializer::writeWidgetProperty(SUI::ObjectPropertyTypeEnum::Type key, const QString &value) {
    mXmlWriter->writeStartElement("property");
    mXmlWriter->writeAttribute("", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(key)), value);
    mXmlWriter->writeEndElement();
}

void SUI::DialogSerializer::writeInclude(const QString &include, const QString &fileName) {
    mXmlWriter->writeStartElement("property");
    mXmlWriter->writeAttribute("", include,fileName);
    mXmlWriter->writeEndElement();
}

GUIDefinitionVisitor &SUI::DialogSerializer::openChildWidget() {
    mXmlWriter->writeStartElement("widget");
    return *this;
}

void SUI::DialogSerializer::closeChildWidget() {
    mXmlWriter->writeEndElement();
}

// Accept visitor. Used to read ui definition from file to visitor (e.g. UI)
void SUI::DialogSerializer::isAttributeWidget(GUIDefinitionVisitor &visitor) {
    ++mWidgetCount;
    mXmlReader->readNext();    
    try {
      GUIDefinitionVisitor &widgetVisitor = visitor.openChildWidget();
      recursiveAcceptVisitor(widgetVisitor);
    }
    catch (SUI::XmlException *re) {
       std::cerr << "XmlException " << re->getExceptionMessage() << std::endl;
       exit(1);
    }
}

void SUI::DialogSerializer::readerIsEndElement(GUIDefinitionVisitor &visitor, bool &ready) {
    visitor.closeChildWidget();
    ready = true;
}

void SUI::DialogSerializer::acceptVisitor(GUIDefinitionVisitor &visitor) {
    bool ready = false;

    while ((!mXmlReader->atEnd()) && (!mXmlReader->hasError()) && (!ready)) {
        if (mXmlReader->isStartElement()) {
            if (mXmlReader->name() == "property") {
                BOOST_FOREACH (const QXmlStreamAttribute & att, mXmlReader->attributes()) {
                    if (att.name().toString().startsWith("Include-")) {
                        visitor.writeInclude(att.name().toString(),att.value().toString());
                    }
                    else {
                        visitor.writeWidgetProperty(SUI::ObjectPropertyTypeEnum::fromString(att.name().toString().toStdString()),att.value().toString());
                    }
                }
            }
            else if (mXmlReader->name() == "widget") {
                isAttributeWidget(visitor);
            }
        }
        else if ((mXmlReader->isEndElement()) && (mXmlReader->name() == "widget")) {
            readerIsEndElement(visitor, ready);
        }

        mXmlReader->readNext();
    }
    if (mXmlReader->hasError()) {
       // FIXME throw new SUI::XmlException(std::string(" XmlException Error: ").append(mXmlReader->errorString().toStdString()));
        std::cerr << "XmlException " << mXmlReader->errorString().toStdString() << std::endl;
    }
}

void SUI::DialogSerializer::recursiveAcceptVisitor(GUIDefinitionVisitor &visitor) {
    bool ready = false;

    while ((!mXmlReader->atEnd()) && (!mXmlReader->hasError()) && (!ready)) {
        if (mXmlReader->isStartElement()) {
            if (mXmlReader->name() == "property") {
                BOOST_FOREACH (const QXmlStreamAttribute & att, mXmlReader->attributes()) {
                   visitor.writeWidgetProperty(SUI::ObjectPropertyTypeEnum::fromString(att.name().toString().toStdString()),att.value().toString());
                }
            }
            else if (mXmlReader->name() == "widget") {
                isAttributeWidget(visitor);
            }
        }
        else if ((mXmlReader->isEndElement()) && (mXmlReader->name() == "widget")) {
            readerIsEndElement(visitor, ready);
        }
        mXmlReader->readNext();
    }
    if (mXmlReader->hasError()) {
       // FIXME throw new SUI::XmlException(std::string(" XmlException Error: ").append(mXmlReader->errorString().toStdString()));
        std::cerr << "XmlException " << mXmlReader->errorString().toStdString() << std::endl;
    }
}

int SUI::DialogSerializer::getWidgetCount() const {
    return mWidgetCount;
}

