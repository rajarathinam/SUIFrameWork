//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::ControlProperties.
// !\description Class implementation file for SUI::ControlProperties.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIControlProperties.h"



QList<QString>  SUI::ControlProperties::getTypes() const
{
    return mTypeMap.keys();
}

QString SUI::ControlProperties::getTypesString() const
{
    QString typeNames;
    QList<QString> x = getTypes();
    for (QList<QString>::iterator i = x.begin(); i != x.end(); ++i)
    {
        typeNames += *i;
        if (i != x.end() - 1)
        {
            typeNames += ";";
        }
    }

    return typeNames;
}

QList<QString> SUI::ControlProperties::getStates() const
{
    return mStateMap.keys();
}

QString SUI::ControlProperties::getStatesString() const
{
    QString stateNames;
    QList<QString> x = getStates();
    for (QList<QString>::iterator i = x.begin(); i != x.end(); ++i)
    {
        stateNames += *i;
        if (i != x.end() - 1)
        {
            stateNames += ";";
        }
    }

    return stateNames;
}

QMap<QString, SUI::ControlProperties::ControlType>& SUI::ControlProperties::getTypeMap()
{
    return mTypeMap;
}

QMap<QString, SUI::ControlProperties::ControlState>& SUI::ControlProperties::getStateMap()
{
    return mStateMap;
}
