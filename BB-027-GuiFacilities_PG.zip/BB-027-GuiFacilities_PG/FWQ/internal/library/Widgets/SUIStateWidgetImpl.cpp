//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::StateWidgetImpl.
// !\description Class implementation file for SUI::StateWidgetImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIStateWidgetImpl.h"

#include "FWQxCore/SUIIImage.h" //for ":/controls/Controls/"

#include "FWQxCore/SUIArgumentException.h"
#include <QDir>
#include <boost/foreach.hpp>

SUI::StateWidgetImpl::StateWidgetImpl(QWidget *parent) :
    BaseWidget(new QLabel(parent), SUI::ObjectType::StateWidget, false)
{
    mState.clear();
    mStates.clear();
    mImages.clear();
    setmImage("NoImage.png");
}

QLabel *SUI::StateWidgetImpl::getWidget() const {
    return dynamic_cast<QLabel *>(BaseWidget::getWidget());
}

void SUI::StateWidgetImpl::setDefaultProperties(const SUI::BaseObject::ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "30");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "30");
}

std::string SUI::StateWidgetImpl::getState() const {
    return const_cast<QString &>(mState).toStdString();
}

void SUI::StateWidgetImpl::setmImage(QString aState) {
    QImage img;
    if ((mStates.contains(aState)) && (!mState.isEmpty())) {
        QString file = QString("%1").arg(QDir(":/controls/Controls/").filePath(mImages.at(mStates.indexOf(aState))));
        img.load(file);
    }
    else {
        img.load(QDir(":/controls/Controls/").filePath("NoImage.png"));
    }
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, QString::number(img.height()));
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, QString::number(img.width()));
    mImage = QPixmap::fromImage(img);
    getWidget()->setPixmap(mImage);
}

void SUI::StateWidgetImpl::setState(const std::string &state) {
    QString stateStr = QString::fromStdString(state);
    if (!mStates.isEmpty() && !stateStr.isEmpty())
    {
        if (mStates.contains(stateStr) == true)
        {
            mState = stateStr;
            setmImage(mState);
        }
        else
        {
            throw new SUI::ArgumentException((QString("The State '%1' doesn't exist within StateWidget %2").arg(stateStr).arg(QString::fromStdString(Widget::getId()))).toStdString());
        }
    }
    if (mStates.isEmpty())
    {
        setmImage(stateStr); //display "NoImage.png"
    }
}

void SUI::StateWidgetImpl::commitChangeState(QString aState) {
    setState(aState.toStdString()); //will also set image
}

void SUI::StateWidgetImpl::onCustomContextMenuRequest(QPoint point) {
    QString Result = BaseWidget::getContextMenuSelectedActionString(point);
    commitChangeState(Result);
}

std::list<std::string> SUI::StateWidgetImpl::getSupportedStates() const {
    std::list<std::string> states;
    BOOST_FOREACH (const QString &str, mStates) {
        states.push_back(str.toStdString());
    }
    return states;
}

std::list<std::string> SUI::StateWidgetImpl::getStatesImages() const {
    std::list<std::string> stateImages;
    BOOST_FOREACH (const QString &str, mImages) {
        stateImages.push_back(str.toStdString());
    }
    return stateImages;
}

void SUI::StateWidgetImpl::addStates(std::list<std::string> aStates) {
    mStates.clear();
    if (!aStates.empty())
    {
        for (std::list<std::string>::const_iterator iterator = aStates.begin(); iterator != aStates.end(); ++iterator)
        {
            QString value = QString::fromStdString(*iterator);
            if (!value.isEmpty() && !mStates.contains(value, Qt::CaseSensitive))
            {
                mStates.append(value);
            }
        }
    }
}

void SUI::StateWidgetImpl::addImages(std::list<std::string> aImages) {
    mImages.clear();
    if (!aImages.empty())
    {
        for (std::list<std::string>::const_iterator iterator = aImages.begin(); iterator != aImages.end(); ++iterator)
        {
            QString value = QString::fromStdString(*iterator);
            if(!value.isEmpty() && !mImages.contains(value, Qt::CaseSensitive))
            {
                mImages.append(value);
            }
        }
    }
}
void SUI::StateWidgetImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
      if (propertyID == SUI::ObjectPropertyTypeEnum::DefaultState) {
        if (propertyValue.contains(';') == false)
        {
            mState = propertyValue;
            commitChangeState(propertyValue);
        }
    }
    if (propertyID == SUI::ObjectPropertyTypeEnum::ImageList) mImages = propertyValue.split(';');

    if (propertyID == SUI::ObjectPropertyTypeEnum::StateList) mStates = propertyValue.split(';');

    BaseWidget::setPropertyValue(propertyID, propertyValue);
}

void SUI::StateWidgetImpl::setPropertyValues(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    if (propertyID == SUI::ObjectPropertyTypeEnum::DefaultState)
    {
        QStringList props = propertyValue.split(';');
        QStringList States;
        if ((props.size() % 2) == 0)
        {
            int nmbrOfStates = props.size() / 2;
            for (int i = 0; i < nmbrOfStates; i++)
            {
                States << props.at(i);
                QStringList Imgs;
                Imgs << props.at(i + nmbrOfStates);
            }
        }
        mStates = States;
    }

    BaseWidget::setPropertyValues(propertyID, propertyValue);
}
