//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::DateTimeEditImpl.
// !\description Class implementation file for SUI::DateTimeEditImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUIDateTimeEditImpl.h"
#include "FWQxUtils/SUITime.h"
#include "FWQxUtils/SUIDate.h"
#include "CustomDateTimeEditPopup.h"

#include <QDateTimeEdit>
#include <QGridLayout>
#include <QApplication>
#include <QDesktopWidget>

SUI::DateTimeEditImpl::DateTimeEditImpl(QWidget *parent) :
    BaseWidget(new QWidget(parent), SUI::ObjectType::DateTimeEdit, true),
    mDateTime(new QDateTimeEdit(getWidget()))
{
    mDateTime->setCalendarPopup(false);
    exposeHeightProperty();
    exposeWidthProperty();

    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "35");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "200");

    QGridLayout *gridLayout = new QGridLayout(getWidget());
    gridLayout->addWidget(mDateTime);

    mDateTime->setDateTime(QDateTime::currentDateTime());
    mDateTimePopup = new CustomDateTimeEditPopup(getWidget());
    connect(mDateTime, SIGNAL(dateTimeChanged(QDateTime)), this, SLOT(onDateTimeChanged(QDateTime)));
    connect(mDateTimePopup, SIGNAL(newDateTimeSelected(QDate, QTime)), this, SLOT(onNewDateTimeSelected(QDate, QTime)));
}

SUI::DateTimeEditImpl::~DateTimeEditImpl() {
    delete mDateTime;
    delete mDateTimePopup;
}

void SUI::DateTimeEditImpl::setDefaultProperties(const ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);
}

QWidget *SUI::DateTimeEditImpl::getWidget() const {
    return dynamic_cast<QWidget *>(BaseWidget::getWidget());
}

void SUI::DateTimeEditImpl::setTime(const boost::shared_ptr<SUI::Time> &time) {
    mDateTime->setTime(*boost::dynamic_pointer_cast<QTime>(time));
}

boost::shared_ptr<SUI::Time> SUI::DateTimeEditImpl::getTime() const {
    boost::shared_ptr<Time> t(SUI::Time::createTime());
    t->setHMS(mDateTime->time().hour(), mDateTime->time().minute(), mDateTime->time().second());
    return t;
}

void SUI::DateTimeEditImpl::setTimeSpec(SUI::DateTimeEnum::TimeSpec spec) {
    mDateTime->setTimeSpec((Qt::TimeSpec)spec);
}

SUI::DateTimeEnum::TimeSpec SUI::DateTimeEditImpl::getTimeSpec() const {
    return (SUI::DateTimeEnum::TimeSpec) mDateTime->timeSpec();
}

void SUI::DateTimeEditImpl::setDate(const boost::shared_ptr<SUI::Date> &dt) {
    mDateTime->setDate(*boost::dynamic_pointer_cast<QDate>(dt));
}

void SUI::DateTimeEditImpl::getDate(int *getYear, int *getMonth, int *getDay) {
    mDateTime->date().getDate(getYear, getMonth, getDay);
}

bool SUI::DateTimeEditImpl::isValid() const {
    return mDateTime->date().isValid() && mDateTime->time().isValid();
}

void SUI::DateTimeEditImpl::onNewDateTimeSelected(const QDate &date, const QTime &time) {
    mDateTime->setDate(date);
    mDateTime->setTime(time);
}

void SUI::DateTimeEditImpl::onDateTimeChanged(const QDateTime &dateTime) {
    mDateTimePopup->setDate(dateTime.date());
    mDateTimePopup->setTime(dateTime.time());
    this->positionPopup();
    mDateTimePopup->show();
}

void SUI::DateTimeEditImpl::positionPopup() {
    QPoint pos = (mDateTime->layoutDirection() == Qt::RightToLeft) ? mDateTime->rect().bottomRight() : mDateTime->rect().bottomLeft();
    QPoint pos2 = (mDateTime->layoutDirection() == Qt::RightToLeft) ? mDateTime->rect().topRight() : mDateTime->rect().topLeft();
    pos = mDateTime->mapToGlobal(pos);
    pos2 = mDateTime->mapToGlobal(pos2);
    QSize size = mDateTimePopup->sizeHint();
    QRect screen = QApplication::desktop()->availableGeometry(pos);
    if (pos.y() + size.height() > screen.bottom()) {
        pos.setY(pos2.y() - size.height());
    }
    else if (pos.y() < screen.top()) {
        pos.setY(screen.top());
    }
    if (pos.y() < screen.top()) {
        pos.setY(screen.top());
    }
    if (pos.y()+size.height() > screen.bottom()) {
        pos.setY(screen.bottom()-size.height());
    }
    mDateTimePopup->move(pos);
}
