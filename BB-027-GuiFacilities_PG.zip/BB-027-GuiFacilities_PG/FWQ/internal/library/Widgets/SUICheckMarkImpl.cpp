//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::CheckMarkImpl.
// !\description Class implementation file for SUI::CheckMarkImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUICheckMarkImpl.h"

SUI::CheckMarkImpl::CheckMarkImpl(QWidget *parent) :
    BaseWidget(new QLabel(parent), SUI::ObjectType::CheckMark, false)
{

}

QLabel *SUI::CheckMarkImpl::getWidget() const {
    return dynamic_cast<QLabel *>(BaseWidget::getWidget());
}

void SUI::CheckMarkImpl::setDefaultProperties(const SUI::BaseObject::ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Color, "Green");
    setPropertyValues(SUI::ObjectPropertyTypeEnum::Color, QString::fromStdString(ColorEnum::toString(ColorEnum::getColorEnumList(Object::getObjectType()),";")));
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "30");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "30");
}

void SUI::CheckMarkImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID,propertyValue);

    switch (propertyID) {
    case SUI::ObjectPropertyTypeEnum::Color:
        setColor(SUI::ColorEnum::fromString(propertyValue.toStdString()));
        break;

    default:
        break;
    }
}

SUI::ColorEnum::Color SUI::CheckMarkImpl::getColor() const {
    return SUI::ColorEnum::fromString(getPropertyValue(SUI::ObjectPropertyTypeEnum::Color).toStdString());
}

void SUI::CheckMarkImpl::setColor(const SUI::ColorEnum::Color color) {
    if (!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color)) return;
    if (SUI::ColorEnum::fromString(getProperty(SUI::ObjectPropertyTypeEnum::Color)->getValue().toStdString()) != color) {
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Color, QString::fromStdString(ColorEnum::toString(color)));
    }
    QImage file;
    switch (color)
    {
    case SUI::ColorEnum::Green:
        file.load(":/image/greenCheck.png");
        break;
    case SUI::ColorEnum::Red:
        file.load(":/image/redCheck.png");
        break;
    default:
        break;
    }
    getWidget()->setPixmap(QPixmap::fromImage(file));
}

