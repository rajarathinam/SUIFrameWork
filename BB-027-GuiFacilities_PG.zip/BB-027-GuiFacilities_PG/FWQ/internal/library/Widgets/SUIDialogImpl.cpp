//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::DialogImpl.
// !\description Class implementation file for SUI::DialogImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIDialogImpl.h"

#include <QVBoxLayout>
#include <QMessageBox>
#include <QFileInfo>
#include <QScrollArea>
#include <QMouseEvent>
#include <QDesktopWidget>
#include <QPushButton>
#include <QApplication>
#include <QStyle>
#include <QDir>
#include <QFontDatabase>
#include <QDirIterator>
#include <boost/foreach.hpp>

#include <iostream>

#include "SUIDialogSerializer.h"
#include "SUIStyleSheet.h"
#include "FWQxCore/SUIArgumentException.h"
#include "FWQxCore/SUIXmlException.h"
#include "FWQxCore/SUIIOException.h"
#include "FWQxWidgets/SUITabWidget.h"
#include "SUIBaseWidget.h"
#include "FWQxWidgets/SUIMessageBox.h"
#include "FWQxWidgets/SUIFileDialog.h"
#include "FWQxCore/SUIObjectFactory.h"

SUI::DialogImpl::DialogImpl(const QString &uiFileName, const QString & uiID, QWidget *parent) :
    QDialog(parent),
    mID(uiID),
    mFileName(uiFileName),
    curTab(0)
{
    setObjectName(QString::fromUtf8("Dialog"));
    QDirIterator it(":/fonts/Fonts/", QDirIterator::Subdirectories);
    while (it.hasNext())
    {
        QFontDatabase::addApplicationFont(it.next());
    }

    QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);

    sizePolicy.setHorizontalStretch(0);
    sizePolicy.setVerticalStretch(0);
    sizePolicy.setHeightForWidth(QDialog::sizePolicy().hasHeightForWidth());
    setSizePolicy(sizePolicy);

    connect(this, SIGNAL(finished(int)), this, SLOT(onClosed()));
    setWindowFlags(Qt::WindowCloseButtonHint | Qt::WindowMinimizeButtonHint);

    QWidget* widget = QUiLoader::loadQUi(uiFileName, mObjectList, mTabOrder);
    setStyleSheet(QString::fromStdString(SUI::StyleSheet::getInstance()->getStyleSheet()));
    QDialog::setWindowTitle(widget->windowTitle());

    addMessagebox();
    addfileBrowser();

    try
    {
        QDesktopWidget desktop;
        int height = qMin(desktop.availableGeometry().height(), widget->height());
        int width  = qMin(desktop.availableGeometry().width(), widget->width());
        height += 4;
        width += 4;

        QGridLayout *gridLayout = new QGridLayout(this);
        gridLayout->setSpacing(0);
        gridLayout->setContentsMargins(0, 0, 0, 0);

        // Does not fit to the screen. Add scrollbars
        QScrollArea *scrollArea = new QScrollArea(this);
        scrollArea->setWidget(widget);
        scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);

        gridLayout->addWidget(scrollArea);

        QDialog::setGeometry(0, 0, width, height);
        setMaximumHeight(height);
        setMaximumWidth(width);

        QList<QPushButton *> buttonList = findChildren<QPushButton *>();
        BOOST_FOREACH(QPushButton * pb, buttonList)
        {
            pb->setDefault(false);
            pb->setAutoDefault(false);
        }

        QList<QWidget *> lneList = findChildren<QWidget *>();
        BOOST_FOREACH(QWidget * pb, lneList)
            pb->installEventFilter(this);

    }
    catch (SUI::ArgumentException *re)
    {
        std::cerr << "Argument Exception: " << re->getExceptionMessage() << std::endl;
        exit(1);
    }
    catch (SUI::XmlException *re)
    {
        std::cerr << "XML Exception: " << re->getExceptionMessage() << std::endl;
        exit(1);
    }
    catch (SUI::IOException *re)
    {
        std::cerr << "IO Exception: " << re->getExceptionMessage() << std::endl;
        exit(1);
    }
    catch (SUI::Exception *re)
    {
        std::cerr << "General: " << re->getExceptionMessage() << std::endl;
        exit(1);
    }
    move(QApplication::desktop()->screenGeometry().center()  - rect().center());
}

SUI::DialogImpl::~DialogImpl() {
    order.clear();
    mDialogMap.clear();
    BOOST_FOREACH (SUI::Object *obj, mObjectList.getObjectList()) {
        BaseObject *object = SUI::ObjectFactory::getInstance()->toBaseObject(obj);
        SUI::Widget *widget = mObjectList.getObject<SUI::Widget>(object->getId());
        BaseWidget *baseWidget = SUI::ObjectFactory::getInstance()->toBaseWidget(widget);
        delete baseWidget;
        baseWidget = NULL;
     }
}

void SUI::DialogImpl::close() {
    QDialog::close();
}

void SUI::DialogImpl::show() {
    QDialog::show();
}

void SUI::DialogImpl::quit() {
    QApplication::quit();
}

void SUI::DialogImpl::setWindowTitle(const std::string &windowName) {
    QDialog::setWindowTitle(QString::fromStdString(windowName));
}

std::string SUI::DialogImpl::getWindowTitle() const {
    return windowTitle().toStdString();
}

std::string SUI::DialogImpl::getFileName() const {
    return mFileName.toStdString();
}

QList<SUI::Dialog *> SUI::DialogImpl::getPopupScreens() const {
    return mDialogMap.values();
}

void SUI::DialogImpl::setEnabled(bool enabled)  {
    QDialog::setEnabled(enabled);
}

bool SUI::DialogImpl::isEnabled() const  {
    return QDialog::isEnabled();
}

void SUI::DialogImpl::setFocus() {
    QDialog::setFocus();
}

void SUI::DialogImpl::clearFocus() {
    QDialog::clearFocus();
}

bool SUI::DialogImpl::hasFocus() const {
    return QDialog::hasFocus();
}

void SUI::DialogImpl::setModal(bool modal) {
   QDialog::setModal(modal);
}

void SUI::DialogImpl::setId(const std::string &id) {
    mID = QString::fromStdString(id);
}

std::string SUI::DialogImpl::getId() const {
    return mID.toStdString();
}

void SUI::DialogImpl::setContextMenuItems(const std::list<std::string> &) {

}

std::list<std::string> SUI::DialogImpl::getContextMenuItems() const {
    std::list<std::string> items;
    return items;
}

void SUI::DialogImpl::setToolTip(const std::string &toolTip) {
    QDialog::setToolTip(QString::fromStdString(toolTip));
}

void SUI::DialogImpl::setGeometry(int x, int y, int w, int h) {
    QDialog::setGeometry(x, y, w, h);
}

void SUI::DialogImpl::setGeometry(const SUI::Rect rect) {
    QDialog::setGeometry(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight());
}

SUI::Rect SUI::DialogImpl::getGeometry() const {
    return SUI::Rect( QDialog::x(),
                     QDialog::y(),
                     QDialog::width(),
                     QDialog::height());

}

void SUI::DialogImpl::onClosed() {
    emit sendClosed(mID);
}

void SUI::DialogImpl::onChildClosed(QString id) {
    if (mDialogMap.contains(id)) mDialogMap.remove(id);
}

void SUI::DialogImpl::setVisible(bool visible) {
    QDialog::setVisible(visible);
    if (!visibilityChanged.empty()) {
        visibilityChanged(visible);
    }
}

bool SUI::DialogImpl::isVisible() const {
    return QDialog::isVisible();
}

void SUI::DialogImpl::keyPressEvent(QKeyEvent *event) {
    switch (event->key())
    {
    case Qt::Key_Escape:
    case Qt::Key_Enter:
    case Qt::Key_Return:
        return;
        break;

    default:
        QDialog::keyPressEvent(event);
        break;
    }
}

bool SUI::DialogImpl::eventFilter(QObject *obj, QEvent *event) {
    if (event->type() == QEvent::KeyPress) {

        SUI::TabWidget *tab = mObjectList.getObject<SUI::TabWidget>("tbw1");
        if (tab != NULL) {
            if (curTab != tab->getCurrentIndex() || order.isEmpty() || mObjectList.getTabReOrder()) {
               if(mObjectList.getTabReOrder()){
                    mObjectList.setTabReOrder(false);
                    mTabOrder.clear();
                    BOOST_FOREACH (std::string id, mObjectList.getTabOrderList()) {
                        SUI::Widget *widget = mObjectList.getObject<SUI::Widget>(id);
                        BaseWidget *baseWidget = SUI::ObjectFactory::getInstance()->toBaseWidget(widget);
                        mTabOrder.addTabOrder(baseWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::TabOrder).toInt(), baseWidget->getWidget());
                     }
                }
                QMultiMap<int, QWidget *> newMap;
                order.clear();
                QMapIterator<QWidget *, int> it(mTabOrder.getTabOrder());
                while (it.hasNext()) {
                    it.next();
                    newMap.insert(it.value(), it.key()); //swap value and key
                }
                QMapIterator<int, QWidget *> i(newMap);
                while (i.hasNext()) {
                    i.next();
                    if (tab->getCurrentIndex() != tab->getTabIndexOfWidget(i.value()->objectName().toStdString())) continue;
                    order.insert(i.key(), i.value());
                }
                curTab = tab->getCurrentIndex();
            }
        }
        else {
            if (order.isEmpty() || mObjectList.getTabReOrder()) {
                if(mObjectList.getTabReOrder()) {
                    mObjectList.setTabReOrder(false);
                    mTabOrder.clear();
                    BOOST_FOREACH (std::string id, mObjectList.getTabOrderList()) {
                        SUI::Widget *widget = mObjectList.getObject<SUI::Widget>(id);
                        BaseWidget *baseWidget = SUI::ObjectFactory::getInstance()->toBaseWidget(widget);
                        mTabOrder.addTabOrder(baseWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::TabOrder).toInt(), baseWidget->getWidget());
                    }
                }
                QMultiMap<int, QWidget *> newMap;
                QMapIterator<QWidget *, int>  itTabOrd(mTabOrder.getTabOrder());
                while (itTabOrd.hasNext()) {
                    itTabOrd.next();
                    newMap.insert(itTabOrd.value(), itTabOrd.key()); //swap value and key
                }
                QMapIterator<int, QWidget *> itNewmap(newMap);
                while (itNewmap.hasNext()) {
                    itNewmap.next();
                    order.insert(itNewmap.key(), itNewmap.value());
                }
            }
        }

        QWidget *wid = QApplication::focusWidget();
        QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
        if (keyEvent->key() == Qt::Key_Backtab) {
            int inCur = order.indexOf(wid);
            if (inCur > 0) {
                for (int i = inCur - 1; i != -1; i--) {
                    if (order[i]->isVisible() && order[i]->isEnabled()) {
                        order[i]->setFocus();
                        return true;
                    }
                }
            }
            for (int i = order.count() - 1; i != 0; i--) {
                if (order[i]->isVisible() && order[i]->isEnabled()) {
                    order[i]->setFocus();
                    return true;
                }
            }
            return true;
        }
        else  if (keyEvent->key() == Qt::Key_Tab) {
            int inCur = order.indexOf(wid);
            if (inCur > -1) {
                for (int i = inCur + 1; i != order.count(); i++) {
                    if (order[i]->isVisible() && order[i]->isEnabled()) {
                        order[i]->setFocus();
                        return true;
                    }
                }
            }
            for (int i = 0; i != order.count(); i++) {
                if (order[i]->isVisible() && order[i]->isEnabled()) {
                    order[i]->setFocus();
                    return true;
                }
            }
            return true;
        }
        else
            return QObject::eventFilter(obj, event);

        return true;
    }
    else
        // standard event processing
        return QObject::eventFilter(obj, event);

}

void SUI::DialogImpl::closeEvent(QCloseEvent *event) {
    // send callback before the close event, give the user time to setCloseable(false) if needed.
    if (!SUI::ICloseable::aboutToClose.empty()) SUI::ICloseable::aboutToClose();

    // if closeable is true,then close and send the closed callback
    if (isCloseable()) {
       QDialog::closeEvent(event);
       if (!closed.empty()) {
           closed();
       }
    }
    // if not ignore the event
    else {
        event->ignore();
    }
}


void SUI::DialogImpl::addMessagebox() {
    if (mObjectList.doesMessageBoxExist()) return;
    MessageBox *messageBox = SUI::ObjectFactory::getInstance()->createWidget_<MessageBox>(this);
    BaseWidget  *baseWidget = SUI::ObjectFactory::getInstance()->toBaseWidget(messageBox);
    baseWidget->setObjectContext(SUI::BaseWidget::Gui);
    baseWidget->setId("msgBox");
    mObjectList.addObject(messageBox->getId(), messageBox);
    baseWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::Visible, "false");
    baseWidget->setVisible(false);
    baseWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, "800");
    baseWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, "400");
}

void SUI::DialogImpl::addfileBrowser() {
    if (mObjectList.doesFileBrowserExist()) return;
    Widget *fileBrowser = SUI::ObjectFactory::getInstance()->createWidget_<FileDialog>(this);
    SUI::BaseWidget *widget = SUI::ObjectFactory::getInstance()->toBaseWidget(fileBrowser);
    widget->setObjectContext(SUI::BaseObject::Gui);
    SUI::ObjectFactory::getInstance()->toBaseObject(fileBrowser)->setId("fbrDialog");
    mObjectList.addObject(fileBrowser->getId(), fileBrowser);
    widget->setPropertyValue(SUI::ObjectPropertyTypeEnum::Visible, "false");
    widget->setVisible(false);
    widget->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, "400");
    widget->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, "200");
}

SUI::ObjectList *SUI::DialogImpl::getObjectList() {
    return &mObjectList;
}

void SUI::DialogImpl::contextMenu(const std::string &widgetID, const std::string &menuOption) {
    if(!contextMenuClicked.empty()) contextMenuClicked(widgetID,menuOption);
}

