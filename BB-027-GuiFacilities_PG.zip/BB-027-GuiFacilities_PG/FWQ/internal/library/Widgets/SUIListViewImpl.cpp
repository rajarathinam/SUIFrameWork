//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::ListViewImpl.
// !\description Class implementation file for SUI::ListViewImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIListViewImpl.h"

#include <QStyle>
#include <QApplication>
#include <QListWidget>
#include <QMouseEvent>
#include <QStringListModel>
#include <QAbstractItemView>
#include <QSortFilterProxyModel>

#include "SUIStyleSheet.h"

//sorting string functions courtesy of:
/* -*- mode: c; c-file-style: "k&r" -*-

  strnatcmp.c -- Perform 'natural order' comparisons of strings in C.
  Copyright (C) 2000, 2004 by Martin Pool <mbp sourcefrog net>

  This software is provided 'as-is', without any express or implied
  warranty.  In no event will the authors be held liable for any damages
  arising from the use of this software.

  Permission is granted to anyone to use this software for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, subject to the following restrictions:

  1. The origin of this software must not be misrepresented; you must not
     claim that you wrote the original software. If you use this software
     in a product, an acknowledgment in the product documentation would be
     appreciated but is not required.
  2. Altered source versions must be plainly marked as such, and must not be
     misrepresented as being the original software.
  3. This notice may not be removed or altered from any source distribution.
*/
#include <ctype.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>

//#include "strnatcmp.h"
typedef char nat_char;

/* These are defined as macros to make it easier to adapt this code to
 * different characters types or comparison functions. */
static inline int
nat_isdigit(nat_char a)
{
    return isdigit((unsigned char) a);
}

static inline int
nat_isspace(nat_char a)
{
    return isspace((unsigned char) a);
}

static inline nat_char
nat_toupper(nat_char a)
{
    return toupper((unsigned char) a);
}

static int
compare_right(nat_char const *a, nat_char const *b)
{
    int bias = 0;

    /* The longest run of digits wins.  That aside, the greatest
    value wins, but we can't know that it will until we've scanned
    both numbers to know that they have the same magnitude, so we
    remember it in BIAS. */
    for (;; a++, b++)
    {
        if (!nat_isdigit(*a)  &&  !nat_isdigit(*b))
        {
            return bias;
        }
        else if (!nat_isdigit(*a))
        {
            return -1;
        }
        else if (!nat_isdigit(*b))
        {
            return +1;
        }
        else if (*a < *b)
        {
            if (bias == false)
            {
                bias = -1;
            }
        }
        else if (*a > *b)
        {
            if (bias == false)
            {
                bias = +1;
            }
        }
        else if ((*a == false)  && (*b == false))
        {
            return bias;
        }
    }
    return 0;
}

static int
compare_left(nat_char const *a, nat_char const *b)
{
    /* Compare two left-aligned numbers: the first to have a
        different value wins. */
    for (;; a++, b++)
    {
        if ((nat_isdigit(*a)) == false  && (nat_isdigit(*b) == false))
        {
            return 0;
        }
        else if (nat_isdigit(*a) == false)
        {
            return -1;
        }
        else if (nat_isdigit(*b) == false)
        {
            return +1;
        }
        else if (*a < *b)
        {
            return -1;
        }
        else if (*a > *b)
        {
            return +1;
        }
    }

    return 0;
}

static int strnatcmp0(nat_char const *a, nat_char const *b, int fold_case)
{
    int ai, bi;

    int fractional, result;

    assert(a && b);
    ai = bi = 0;
    while (1)
    {
        nat_char ca, cb;
        ca = a[ai];
        cb = b[bi];

        /* skip over leading spaces or zeros */
        while (nat_isspace(ca))
        {
            ca = a[++ai];
        }

        while (nat_isspace(cb))
        {
            cb = b[++bi];
        }

        /* process run of digits */
        if (nat_isdigit(ca)  &&  nat_isdigit(cb))
        {
            fractional = (ca == '0' || cb == '0');

            if (fractional)
            {
                if ((result = compare_left(a + ai, b + bi)) != 0)
                {
                    return result;
                }
            }
            else
            {
                if ((result = compare_right(a + ai, b + bi)) != 0)
                {
                    return result;
                }
            }
        }

        if ((ca == false) && (cb == false))
        {
            /* The strings compare the same.  Perhaps the caller
                  will want to call strcmp to break the tie. */
            return 0;
        }

        if (fold_case)
        {
            ca = nat_toupper(ca);
            cb = nat_toupper(cb);
        }

        if (ca < cb)
        {
            return -1;
        }
        else if (ca > cb)
        {
            return +1;
        }

        ++ai;
        ++bi;
    }
}

int strnatcmp(nat_char const *a, nat_char const *b)
{
    return strnatcmp0(a, b, 0);
}

/* Compare, recognizing numeric string and ignoring case. */
int strnatcasecmp(nat_char const *a, nat_char const *b)
{
    return strnatcmp0(a, b, 1);
}
// end of strnatcmp.c


SUI::ListViewImpl::ListViewImpl(QWidget *parent):
    BaseWidget(new QListWidget(parent), SUI::ObjectType::ListView, false),
    mItems(new QStringListModel()),
    mFilteredItems(new QStringListModel()),
    mSelectionModel(new QItemSelectionModel(getWidget()->model())),
    mSortOrder(NoSort),
    mCaseSensFilter(true)
{
    exposeWidthProperty();
    exposeHeightProperty();

    ListViewImpl::getWidget()->setSelectionModel(mSelectionModel);
    ListViewImpl::getWidget()->setSelectionBehavior(QAbstractItemView::SelectRows);
    ListViewImpl::getWidget()->setSelectionMode(QAbstractItemView::ExtendedSelection);
    ListViewImpl::getWidget()->setSelectionRectVisible(true);
    ListViewImpl::getWidget()->setEditTriggers(QAbstractItemView::NoEditTriggers);

    connect(ListViewImpl::getWidget()->selectionModel(), SIGNAL(selectionChanged(const QItemSelection &, const QItemSelection &)), this, SLOT(handleSelected(const QItemSelection &, const QItemSelection &)));
}

SUI::ListViewImpl::~ListViewImpl()
{
    delete mSelectionModel;
    delete mItems;
    delete mFilteredItems;
}

QListWidget *SUI::ListViewImpl::getWidget() const {
    return qobject_cast<QListWidget *>(BaseWidget::getWidget());
}

void SUI::ListViewImpl::setDefaultProperties(const ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);

    switch (context)
    {
    case EditorSelector:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "600");
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "200");
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, QString::fromStdString(SUI::ObjectType::toString(Object::getObjectType())));
        addItems(std::list<std::string>{"Item 1","Item 2"});
        break;

    case EditorForm:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "400");
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "200");
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, "TBD");
        removeAllItems();
        setPropertyReadonly(SUI::ObjectPropertyTypeEnum::RowCount,false);
        setPropertyValue(SUI::ObjectPropertyTypeEnum::RowCount,  QString::number(mItems->rowCount()));
        setPropertyReadonly(SUI::ObjectPropertyTypeEnum::RowCount);
        break;

    default:
        break;
    }
}

void SUI::ListViewImpl::handleClicked(QModelIndex &) {
    if (!clicked.empty()) clicked();
}

void SUI::ListViewImpl::handleSelected(const QItemSelection &, const QItemSelection &) {
    QModelIndexList selIndexModel = mSelectionModel->selectedIndexes();
    mSelectedItems.clear();

    QList<int> lint;
    for (int i = 0; i < selIndexModel.count(); ++i) //populate lint
        lint.append(selIndexModel[i].row());

    for (int i = 0; i <= lint.size() - 1; ++i)
        mSelectedItems.append(mFilteredItems->stringList().at(lint[i]));

    if (!selectionChanged.empty()) selectionChanged();
}

void SUI::ListViewImpl::addItems(const std::list<std::string> &itemStdlist) {
    QStringList itemQlist;
    foreach(std::string item, itemStdlist)
        itemQlist.append(QString::fromStdString(item));

    if (itemQlist.isEmpty() == false)
    {
        foreach(const QString & str, itemQlist)
        {
            if (str.isEmpty() == false)
            {
                if ((mItems->stringList().contains(str)) == false) //Avoid duplicated items
                {
                    mItems->insertRow(mItems->rowCount());
                    mItems->setData(mItems->index(mItems->rowCount() - 1), str);
                }
            }
        }
        setPropertyValue(SUI::ObjectPropertyTypeEnum::RowCount, QString::number(mItems->rowCount()));
        updateWidget();
    }
}

void SUI::ListViewImpl::removeAllItems()
{
    for (int i = mItems->rowCount(); i >= 0; --i)
    {
        mItems->removeRow(i);
    }
    mSelectionModel->clearSelection();
    mItems->stringList().clear();
    updateWidget();
}

void SUI::ListViewImpl::setText(const std::string &value)
{
    if (getObjectContext() != BaseWidget::Gui)
        removeAllItems();

    addItems(formatStdString(value)); //update model
}

std::string SUI::ListViewImpl::getText() const
{
    return mItems->stringList().join(";").toStdString();
}

void SUI::ListViewImpl::clearText()
{
    clearItems();
}

std::list<std::string> SUI::ListViewImpl::getSelectedItems() const
{
    std::list<std::string> itemList;
    foreach(QString item, mSelectedItems)
    {
        itemList.push_back(item.toStdString());
    }
    return itemList;
}

void SUI::ListViewImpl::clearItems()
{
    removeAllItems();
    setPropertyValue(SUI::ObjectPropertyTypeEnum::RowCount,  QString::number(mItems->rowCount()));
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, mItems->stringList().join(";"));
}

QString SUI::ListViewImpl::getAllColumnItems(int) const
{
    QStringList itemList;
    foreach(std::string item, getItems())
    {
        itemList.append(QString::fromStdString(item));
    }
    return itemList.join(";");
}

std::list<std::string> SUI::ListViewImpl::getItems() const//getAll()
{
    std::list<std::string>  itemList;
    foreach(QString item, mFilteredItems->stringList())
    {
        itemList.push_back(item.toStdString());
    }
    return itemList;
}

void SUI::ListViewImpl::removeItems(const std::list<std::string> &itemlist)
{
    foreach(std::string item, itemlist)
    {
        QString str = QString::fromStdString(item);
        if ((str.isEmpty() == false) && (mItems->stringList().contains(str) == true)) {
            mItems->removeRow(mItems->stringList().indexOf(str));
        }
    }
    updateWidget();
}

std::list<std::string> SUI::ListViewImpl::formatStdString(std::string inStr)
{
    std::list<std::string>  stdList;
    if (inStr.size())
    {
        size_t  pos = inStr.find('\n');
        while (pos != std::string::npos)
        {
            inStr.replace(pos, 1, ";");
            pos = inStr.find('\n');
        }
        size_t startpos = pos = 0;
        pos = inStr.find(';', pos);
        while (pos != std::string::npos)
        {
            if (startpos != pos)
            {
                stdList.push_back(inStr.substr(startpos, pos - startpos));
            }
            if (pos < (inStr.size() - 1))
            {
                startpos = ++pos;
                pos = inStr.find(';', pos);
            }
            else
            {
                startpos = pos = std::string::npos;
            }
        }
        if (startpos != std::string::npos)
        {
            stdList.push_back(inStr.substr(startpos, inStr.size() - startpos));
        }
    }
    return stdList;
}

void SUI::ListViewImpl::handleSelectionChanged() {
    if (!selectionChanged.empty()) selectionChanged();
}

//Due to sorting requirement and the lack hereof in QT 4.8 we update QListWidget in this function.
//Here we can implement and select a specific sorting algorithm
void SUI::ListViewImpl::updateWidget()
{
    int indexer = 0;
    getWidget()->clear();

    applyFilter(mItems);

    QStringList lst = mFilteredItems->stringList();
    mNewList.clear();

    //sort as set in property
    //todo: implement natural sorting algorithm
    switch (mSortOrder)
    {
    default:
    case NoSort:
        //how to restore original input?
        break;
    case Descending:
        mFilteredItems->sort(0, Qt::DescendingOrder);
        break;
    case Ascending:
        mFilteredItems->sort(0, Qt::AscendingOrder);
        break;
    case Nat_Asc:
        mStringList = new char *[lst.size()]; //list to sort
        indexer = 0;                           //indexer
        foreach(QString str, lst)
        {
            mByteArray.append(new QByteArray(str.toUtf8()));
            mStringList[indexer] = mByteArray.at(indexer)->data();
            indexer++;
        }
        qsort(mStringList, lst.size(), sizeof mStringList[0], NaturalAscending);
        indexer = 0;
        foreach(QString str, lst)
        {
            mNewList.append(QString::fromUtf8(mStringList[indexer++]));
        }

        mFilteredItems->setStringList(mNewList);

        //cleanup
        delete[] mStringList;
        qDeleteAll(mByteArray.begin(), mByteArray.end());
        mByteArray.clear();
        break;
    case Nat_Desc:
        mStringList = new char *[lst.size()]; //list to sort
        indexer = 0;                           //indexer
        foreach(QString str, lst)
        {
            mByteArray.append(new QByteArray(str.toUtf8()));
            mStringList[indexer] = mByteArray.at(indexer)->data();
            indexer++;
        }
        qsort(mStringList, lst.size(), sizeof mStringList[0], NaturalDescending);
        indexer = 0;
        foreach(QString str, lst)
        {
            mNewList.append(QString::fromUtf8(mStringList[indexer++]));
        }

        mFilteredItems->setStringList(mNewList);

        //cleanup
        delete[] mStringList;
        qDeleteAll(mByteArray.begin(), mByteArray.end());
        mByteArray.clear();
        break;
    case Nat_Desc_Case:
        mStringList = new char *[lst.size()]; //list to sort
        indexer = 0;                           //indexer
        foreach(QString str, lst)
        {
            mByteArray.append(new QByteArray(str.toUtf8()));
            mStringList[indexer] = mByteArray.at(indexer)->data();
            indexer++;
        }
        qsort(mStringList, lst.size(), sizeof mStringList[0], NaturalDescendingCaseSensitive);
        indexer = 0;
        foreach(QString str, lst)
        {
            mNewList.append(QString::fromUtf8(mStringList[indexer++]));
        }

        mFilteredItems->setStringList(mNewList);

        //cleanup
        delete[] mStringList;
        qDeleteAll(mByteArray.begin(), mByteArray.end());
        mByteArray.clear();
        break;
    case Nat_Asc_Case:
        mStringList = new char *[lst.size()]; //list to sort
        indexer = 0;                        //indexer
        foreach(QString str, lst)
        {
            mByteArray.append(new QByteArray(str.toUtf8()));
            mStringList[indexer] = mByteArray.at(indexer)->data();
            indexer++;
        }
        qsort(mStringList, lst.size(), sizeof mStringList[0], NaturalAscendingCaseSensitive);
        indexer = 0;
        foreach(QString str, lst)
        {
            mNewList.append(QString::fromUtf8(mStringList[indexer++]));
        }
        mFilteredItems->setStringList(mNewList);

        //cleanup
        delete[] mStringList;
        qDeleteAll(mByteArray.begin(), mByteArray.end());
        mByteArray.clear();
        break;
    }
    getWidget()->addItems(mFilteredItems->stringList());
}

void SUI::ListViewImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID, propertyValue);

    switch (propertyID) {
    case SUI::ObjectPropertyTypeEnum::FilterString:
        mFilter = propertyValue;
        updateWidget();
        break;

    case SUI::ObjectPropertyTypeEnum::SelectBehaviour:
        if (propertyValue == "Single")
        {
            getWidget()->setSelectionBehavior(QAbstractItemView::SelectItems);
            getWidget()->setSelectionMode(QAbstractItemView::SingleSelection);
            getWidget()->setSelectionRectVisible(false);
        }
        else
        {
            getWidget()->setSelectionBehavior(QAbstractItemView::SelectRows);
            getWidget()->setSelectionMode(QAbstractItemView::ExtendedSelection);
            getWidget()->setSelectionRectVisible(true);
        }
        break;

    case SUI::ObjectPropertyTypeEnum::SortingOrder:
    {
        SortOrder CurrentOrder = mSortOrder;
        if (propertyValue == "Descending")
            mSortOrder = Descending;
        else if (propertyValue == "Ascending")
            mSortOrder = Ascending;
        else if (propertyValue == "Natural_Descending")
            mSortOrder = Nat_Desc;
        else if (propertyValue == "Natural_Ascending")
            mSortOrder = Nat_Asc;
        else if (propertyValue == "Natural_Descending_Case_Sensitive")
            mSortOrder = Nat_Desc_Case;
        else if (propertyValue == "Natural_Ascending_Case_Sensitive")
            mSortOrder = Nat_Asc_Case;
        else //Default NoSort
        {
            mSortOrder = NoSort;
            propertyValue = "NoSort";
        }

        if (CurrentOrder != mSortOrder)
        {
            updateWidget();
        }
    }
    case SUI::ObjectPropertyTypeEnum::Bold:
        setBold((propertyValue.compare("true", Qt::CaseInsensitive) == 0));
        break;
    case SUI::ObjectPropertyTypeEnum::Text:
        setText(propertyValue.toStdString());
        break;
    default:
        break;
    }
}

void SUI::ListViewImpl::setSortOrder(ListViewImpl::SortOrder sOrd)
{
    mSortOrder = sOrd;
}

void SUI::ListViewImpl::setFilter(const std::string &filter, bool on, int /*columnNo*/, bool casesensitive)
{
    QString text = QString::fromStdString(filter);
    if (on == false)
    {
        text = "";
    }
    mCaseSensFilter = casesensitive;
    setPropertyValue(SUI::ObjectPropertyTypeEnum::FilterString, text);
}

void SUI::ListViewImpl::applyFilter(QStringListModel *items)
{
    //reinitialise mFilteredItems
    for (int i = mFilteredItems->rowCount(); i >= 0; --i)
    {
        mFilteredItems->removeRow(i);
    }
    mFilteredItems->stringList().clear();

    foreach(QString item, items->stringList())
    {
        if (item.contains(mFilter, (mCaseSensFilter) ?
                            Qt::CaseSensitive : Qt::CaseInsensitive))
        {
            //add to filtered list
            mFilteredItems->insertRow(mFilteredItems->rowCount());
            mFilteredItems->setData(mFilteredItems->index(mFilteredItems->rowCount() - 1),
                                     item);
        }
    }
}

int SUI::ListViewImpl::NaturalAscending(const void *s1, const void *s2)
{
    char const *ps1 = *(char const **)s1, *ps2 = *(char const **)s2;
    return (strnatcmp(ps1, ps2));
}

int SUI::ListViewImpl::NaturalDescending(const void *s1, const void *s2)
{
    char const *ps1 = *(char const **)s1, *ps2 = *(char const **)s2;
    return (-1 * strnatcmp(ps1, ps2));
}

int SUI::ListViewImpl::NaturalAscendingCaseSensitive(const void *s1, const void *s2)
{
    char const *ps1 = *(char const **)s1, *ps2 = *(char const **)s2;
    return (strnatcasecmp(ps1, ps2));
}

void SUI::ListViewImpl::selectItem(const int row, const int /*col*/)
{
    getWidget()->setCurrentRow(row);
}

void SUI::ListViewImpl::selectItem(const std::string) {
}

void SUI::ListViewImpl::setBold(bool bold) {
    getWidget()->setProperty("SUIFont", bold ? "bold" : "");
    getWidget()->style()->polish(getWidget());
}

bool SUI::ListViewImpl::isBold() const {
    return getWidget()->property("SUIFont").toString() == "bold";
}

int SUI::ListViewImpl::NaturalDescendingCaseSensitive(const void *s1, const void *s2)
{
    char const *ps1 = *(char const **)s1, *ps2 = *(char const **)s2;
    return (-1 * strnatcasecmp(ps1, ps2));
}
