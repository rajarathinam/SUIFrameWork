//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::SplitterImpl.
// !\description Class implementation file for SUI::SplitterImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUISplitterImpl.h"

#include <QVBoxLayout>

SUI::SplitterImpl::SplitterImpl(QWidget *parent) :
    BaseWidget(new QSplitter(parent), SUI::ObjectType::Splitter, true)
{
    initialize();
}

SUI::SplitterImpl::~SplitterImpl() {
    mSplitterWidgets.clear();
}

void SUI::SplitterImpl::initialize() {
    mOrientation = ORIENT_VERTICAL;
    SplitterImpl::getWidget()->setFrameShape(QFrame::NoFrame);
}

void SUI::SplitterImpl::setDefaultProperties(const SUI::BaseObject::ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);
    SplitterImpl::getWidget()->setOrientation(Qt::Vertical);
}

void SUI::SplitterImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID, propertyValue);
    if (propertyID == SUI::ObjectPropertyTypeEnum::Orientation) {
        mOrientation = propertyValue.toLower() == "horizontal" ? ORIENT_HORIZONTAL : ORIENT_VERTICAL;
        setOrientation(mOrientation);
    }
}

QSplitter *SUI::SplitterImpl::getWidget() const {
    return dynamic_cast<QSplitter *>(BaseWidget::getWidget());
}

void SUI::SplitterImpl::addSplitterWidget(const BaseWidget *rticwidget) {
    mSplitterWidgets.insert(mSplitterWidgets.count(), const_cast<BaseWidget *>(rticwidget));
    getWidget()->updateGeometry();
}

void SUI::SplitterImpl::removeSplitterWidget(const BaseWidget *rticwidget) {
    for (int i = 0; i < mSplitterWidgets.count(); ++i) {
        if (mSplitterWidgets[i] == rticwidget) {
            mSplitterWidgets.remove(i);
            break;
        }
    }
}

void SUI::SplitterImpl::switchSplitterWidgets(const BaseWidget *oldWidget, const BaseWidget *newWidget) {
    for (int i = 0; i < mSplitterWidgets.count(); ++i) {
        if (mSplitterWidgets[i] == oldWidget) {
            mSplitterWidgets[i] = const_cast<BaseWidget *>(newWidget);
        }
    }
}

const SUI::BaseWidget *SUI::SplitterImpl::at(const int ind) const {
    return mSplitterWidgets.contains(ind) ? mSplitterWidgets[ind] : NULL;
}

void SUI::SplitterImpl::setOrientation(SplitterImpl::ORIENTATION orientation) {
    mOrientation = orientation;
    getWidget()->setOrientation(orientation == SplitterImpl::ORIENT_VERTICAL? Qt::Vertical: Qt::Horizontal);
}

int SUI::SplitterImpl::count() const {
    return mSplitterWidgets.size();
}

void SUI::SplitterImpl::setSizes(QList<int> &sizelist) {
    getWidget()->setSizes(sizelist);
}
