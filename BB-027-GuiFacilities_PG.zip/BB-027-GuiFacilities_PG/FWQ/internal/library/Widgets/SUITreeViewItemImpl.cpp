//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::TreeViewItemImpl.
// !\description Class implementation file for SUI::TreeViewItemImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUITreeViewImpl.h"
#include "SUITreeViewItemImpl.h"

#include <QStyle>

SUI::TreeViewItemImpl::TreeViewItemImpl(QWidget *parent) :
    BaseWidget(new CustomLabel(parent), SUI::ObjectType::TreeViewItem, false),
    mTreeView(dynamic_cast<TreeViewImpl *>(parent))
{
    connect(TreeViewItemImpl::getWidget(), SIGNAL(select()), this, SLOT(selectRow()));
}

void SUI::TreeViewItemImpl::setTreeviewParent(const TreeViewImpl *treeParent) {
    mTreeView = const_cast<TreeViewImpl *>(treeParent);
}

void SUI::TreeViewItemImpl::setDefaultProperties(const SUI::BaseObject::ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "30");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "200");

    switch (context)
    {
    case EditorSelector:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, QString::fromStdString(SUI::ObjectType::toString(Object::getObjectType())));
        break;

    case EditorForm:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, "TBD");
        break;

    default:
        break;
    }
}

void SUI::TreeViewItemImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID, propertyValue);

    switch (propertyID) {
    case SUI::ObjectPropertyTypeEnum::Bold:
        setBold((propertyValue.compare("true", Qt::CaseInsensitive) == 0));
        break;

    case SUI::ObjectPropertyTypeEnum::Text:
        setText(propertyValue.toStdString());
        break;

    default:
        break;
    }
}

CustomLabel *SUI::TreeViewItemImpl::getWidget() const {
    return dynamic_cast<CustomLabel *>(BaseWidget::getWidget());
}

void SUI::TreeViewItemImpl::setText(const std::string &value) {
    getWidget()->setText(QString::fromStdString(value));
    if (mTreeView != NULL) {
        QString strID = QString::fromStdString(Widget::getId());
        QStandardItem *thisItem = dynamic_cast<TreeViewImpl *>(mTreeView)->getStandardItem(strID);
        if (thisItem != NULL) thisItem->setText(QString::fromStdString(value));
    }
}

std::string SUI::TreeViewItemImpl::getText() const {
    QString retStr;
    if (mTreeView != NULL) {
        QStandardItem *thisItem = dynamic_cast<TreeViewImpl *>(mTreeView)->getStandardItem(QString::fromStdString(Widget::getId()));
        if (thisItem != NULL) retStr = thisItem->text();
    }
    return retStr.toStdString();
}

void SUI::TreeViewItemImpl::clearText() {
    getWidget()->clear();
    if (mTreeView != NULL) {
        QStandardItem *thisItem = dynamic_cast<TreeViewImpl *>(mTreeView)->getStandardItem(QString::fromStdString(Widget::getId()));
        if (thisItem != NULL) thisItem->setText("");
    }
}

void SUI::TreeViewItemImpl::setBold(bool bold) {
    QFont   lblFont =  getWidget()->font();
    lblFont.setBold(bold);
    getWidget()->setFont(lblFont);
    if (mTreeView != NULL) {
        QStandardItem *thisItem = dynamic_cast<TreeViewImpl *>(mTreeView)->getStandardItem(QString::fromStdString(Widget::getId()));
        if (thisItem != NULL) {
            lblFont = thisItem->font();
            lblFont.setBold(bold);
            thisItem->setFont(lblFont);
        }
    }
}

bool SUI::TreeViewItemImpl::isBold() const {
    return getWidget()->font().bold();
}

void SUI::TreeViewItemImpl::selectRow() {
    dynamic_cast<TreeViewImpl *>(parent())->selectRow(QString::fromStdString(Widget::getId()));
}
