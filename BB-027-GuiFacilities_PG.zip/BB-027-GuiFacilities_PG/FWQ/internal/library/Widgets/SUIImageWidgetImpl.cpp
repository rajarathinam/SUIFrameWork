//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::ImageWidgetImpl.
// !\description Class implementation file for SUI::ImageWidgetImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIImageWidgetImpl.h"
#include "FWQxCore/SUIResourcePath.h"

#include <QLabel>
#include <QBuffer>

SUI::ImageWidgetImpl::ImageWidgetImpl(QWidget *parent) :
    BaseWidget(new QLabel(parent), SUI::ObjectType::ImageWidget, false)
{
}

QLabel *SUI::ImageWidgetImpl::getWidget() const {
    return dynamic_cast<QLabel*>(BaseWidget::getWidget());
}

void SUI::ImageWidgetImpl::setDefaultProperties(const SUI::BaseObject::ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);
}

void SUI::ImageWidgetImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID, propertyValue);

    switch (propertyID) {
    case SUI::ObjectPropertyTypeEnum::ImageData:
        setImage(propertyValue.toStdString());
        break;

    default:
        break;
    }
}

void SUI::ImageWidgetImpl::setGeometry() {
    BaseWidget::setGeometry();
    setImage(getPropertyValue(SUI::ObjectPropertyTypeEnum::ImageData).toStdString());
}

void SUI::ImageWidgetImpl::setImage(const std::string &fileName) {
    getWidget()->setPixmap(QPixmap::fromImage(QImage(QString::fromStdString(SUI::ResourcePath::getResourceFile(fileName)))));
}

void SUI::ImageWidgetImpl::setImage(unsigned char *data, int width, int height, ImageEnum::Format format) {
    getWidget()->setPixmap(QPixmap::fromImage(QImage(data,width,height,(QImage::Format)format)));
}
