//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::TreeViewImpl.
// !\description Class implementation file for SUI::TreeViewImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUITreeViewImpl.h"

#include "FWQxCore/SUIObjectFactory.h"

#include <string>
#include <boost/foreach.hpp>

#include "FWQxCore/SUIArgumentException.h"
#include <iostream>

SUI::TreeViewImpl::TreeViewImpl(QWidget *parent , SUI::ObjectList *widgetList):
    BaseWidget(new QTreeView(parent), SUI::ObjectType::TreeView, false),
    mStandardModel(new QStandardItemModel()),
    mCurrentItem(NULL),
    mWidgetList(widgetList),
    mSortOrder(SUI::SortOrderEnum::Descending)
{
    TreeViewImpl::getWidget()->setModel(mStandardModel);
    exposeWidthProperty();
    exposeHeightProperty();
    connect(TreeViewImpl::getWidget()->selectionModel(), SIGNAL(selectionChanged(QItemSelection, QItemSelection)),this, SLOT(handleSelectionChanged()));
    mHeader = new TreeViewHeader(TreeViewImpl::getWidget());
    connect(mHeader, SIGNAL(collapseClicked()), this, SLOT(onCollapseClicked()));
    connect(mHeader, SIGNAL(expandClicked()), this, SLOT(onExpandClicked()));
    TreeViewImpl::getWidget()->setHeader(mHeader);
}

void SUI::TreeViewImpl::appendRow(QString text, QString parentID, QString currentID) {
    if (mMap.contains(currentID)) {
        mCurrentItem = mMap.value(currentID);
    }
    else {
        QStandardItem *parentItem = NULL;
        mCurrentItem = new QStandardItem(text);
        mMap.insert(currentID, mCurrentItem);
        if (mMap.contains(parentID)) {
            parentItem = mMap.value(parentID);
        }
        if (parentItem != NULL) {
            parentItem->appendRow(mCurrentItem);
        }
        else {
            mStandardModel->appendRow(mCurrentItem);
        }
    }
    TreeViewItem *newItem = new TreeViewItemImpl(dynamic_cast<QWidget *>(this));

    newItem->setText(text.toStdString());
    newItem->setVisible(false);
    getWidget()->expandAll();
}

SUI::TreeViewImpl::~TreeViewImpl()
{
    for (int i = 0; i < mStandardModel->rowCount(); ++i) {
        for (int j = 0; j < mStandardModel->columnCount(); ++j) {
            delete mStandardModel->item(i, j);
        }
    }
    if (mStandardModel != NULL) delete mStandardModel;
}

void SUI::TreeViewImpl::setDefaultProperties(const SUI::BaseObject::ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);
    setPropertyValues(ObjectPropertyTypeEnum::SortingOrder,"NoSort;Ascending;Descending");

    switch (context)
    {
    case EditorSelector:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Height,"200");
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "600");
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, QString::fromStdString(SUI::ObjectType::toString(Object::getObjectType())));
        setPropertyValue(SUI::ObjectPropertyTypeEnum::DisableHeader, "true");
        break;

    case EditorForm:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, "TBD");
        break;

    default:
        break;
    }
}

QTreeView *SUI::TreeViewImpl::getWidget() const {
    return dynamic_cast<QTreeView *>(BaseWidget::getWidget());
}

void SUI::TreeViewImpl::setText(const std::string &value) {
    QStringList hList;
    hList.append(QString::fromStdString(value));
    mStandardModel->setHorizontalHeaderLabels(hList);
}

std::string SUI::TreeViewImpl::getText() const {
    return mStandardModel->horizontalHeaderItem(0)->text().toStdString();
}

void SUI::TreeViewImpl::clearText() {
    setText("");
}

void SUI::TreeViewImpl::setBold(bool bold) {
    QFont   lblFont = mStandardModel->horizontalHeaderItem(0)->font();
    lblFont.setBold(bold);
    mStandardModel->horizontalHeaderItem(0)->setFont(lblFont);

}

bool SUI::TreeViewImpl::isBold() const {
    return mStandardModel->horizontalHeaderItem(0)->font().bold();
}

void SUI::TreeViewImpl::setTitle(const std::string &title) {
    setText(title);
}

std::string SUI::TreeViewImpl::getTitle() const {
    return getText();
}

QString SUI::TreeViewImpl::addNewTreeItem(TreeViewItemImpl *item) {
    TreeViewItem *i = item;
    QString currentID = QString::fromStdString(i->getId());
    item->setPropertyReadonly(SUI::ObjectPropertyTypeEnum::XPos);
    item->setPropertyReadonly(SUI::ObjectPropertyTypeEnum::YPos);
    item->setPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable, "false");
    item->setPropertyValue(SUI::ObjectPropertyTypeEnum::Sizeable, "false");
    item->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, "0");
    item->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, "0");
    mCurrentItem = new QStandardItem(item->getPropertyValue(SUI::ObjectPropertyTypeEnum::Text));
    mStandardModel->appendRow(mCurrentItem);
    if (!mMap.contains(currentID))
    {
        mMap.insert(currentID, mCurrentItem);
    }
    item->setParent(this);
    item->setTreeviewParent(this);
    item->setText(item->getPropertyValue(SUI::ObjectPropertyTypeEnum::Text).toStdString());
    return currentID;
}

QString SUI::TreeViewImpl::addNewTreeItemToItem(TreeViewItemImpl *item, QString parent) {
    QStandardItem *parentItem = mMap.value(parent);
    item->setPropertyReadonly(SUI::ObjectPropertyTypeEnum::XPos);
    item->setPropertyReadonly(SUI::ObjectPropertyTypeEnum::YPos);
    item->setPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable, "false");
    item->setPropertyValue(SUI::ObjectPropertyTypeEnum::Sizeable, "false");
    item->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, "0");
    item->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, "0");
    QStandardItem *newItem = new QStandardItem(item->getPropertyValue(SUI::ObjectPropertyTypeEnum::Text));
    parentItem->appendRow(newItem);
    TreeViewItem *i = item;
    mMap.insert(QString::fromStdString(i->getId()), newItem);
    item->setText(item->getPropertyValue(SUI::ObjectPropertyTypeEnum::Text).toStdString());
    item->setParent(this);
    item->setTreeviewParent(this);
     getWidget()->expandAll();
    return QString::fromStdString(i->getId());
}

void SUI::TreeViewImpl::addTreeItem(const std::string &text, std::string &newID, const std::string &parentID) {
    QString localText = QString::fromStdString(text);
    QString localNewID = QString::fromStdString(newID);
    QString localParentID = QString::fromStdString(parentID);
    BaseWidget *widgetItem = SUI::ObjectFactory::getInstance()->toBaseWidget(SUI::ObjectFactory::getInstance()->createWidget_<TreeViewItem>());

    widgetItem->setPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable, "false");
    widgetItem->setPropertyValue(SUI::ObjectPropertyTypeEnum::Sizeable, "false");
    widgetItem->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, "0");
    widgetItem->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, "0");
    widgetItem->setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, localText);
    widgetItem->setPropertyReadonly(SUI::ObjectPropertyTypeEnum::XPos);
    widgetItem->setPropertyReadonly(SUI::ObjectPropertyTypeEnum::YPos);

    if (localNewID.left(3) != "tri") localNewID.prepend("tri");
    int seqNr = 0;
    QString tstID = localNewID;
    while (mMap.contains(tstID))
    {
        ++seqNr;
        tstID = QString("%1-%2").arg(localNewID).arg(seqNr);
    }
    localNewID = tstID;
    widgetItem->setPropertyValue(SUI::ObjectPropertyTypeEnum::ID, localNewID);
    newID = localNewID.toStdString();

    QStandardItem *newItem = new QStandardItem(localText);
    if (mMap.contains(localParentID))
    {
        QStandardItem *parentItem = mMap.value(localParentID);
        parentItem->appendRow(newItem);
    }
    else
    {
        mStandardModel->appendRow(newItem);
    }
    mMap.insert(QString::fromStdString(widgetItem->getId()), newItem);
    widgetItem->setParent(this);
    dynamic_cast<TreeViewItemImpl *>(widgetItem)->setTreeviewParent(this);
    getWidget()->expandAll();
    if (mWidgetList != NULL)
    {
        mWidgetList->addObject(widgetItem->getId(), SUI::ObjectFactory::getInstance()->toObject(widgetItem));
    }
}

void SUI::TreeViewImpl::clearItems() {
    mStandardModel->removeColumns(0, 3);
     getWidget()->reset();
}

void SUI::TreeViewImpl::renameItem(QString oldID, QString newID) {
    if (mMap.contains(oldID))
    {
        mMap.insert(newID, mMap.value(oldID));
        mMap.remove(oldID);
        if (mWidgetList != NULL)
        {
            TreeViewItem* treeItem = mWidgetList->getObject<SUI::TreeViewItem>(oldID.toStdString());
            mWidgetList->removeObject(oldID.toStdString());
            mWidgetList->addObject(newID.toStdString(), treeItem);
        }
    }
}

void SUI::TreeViewImpl::updateText(QString oldID, QString newID) {
    if (mMap.contains(oldID))
    {
        QStandardItem *item = mMap.value(oldID);
        item->setText(newID);
    }
}

void SUI::TreeViewImpl::selectRow(QString widgetID) {
    if (mMap.contains(widgetID))
    {
         getWidget()->setCurrentIndex(mStandardModel->indexFromItem(mMap.value(widgetID)));
    }
}

void SUI::TreeViewImpl::addItems(const std::list<std::string> &) { 
}


void SUI::TreeViewImpl::removeItems(const std::list<std::string> &itemList) {
    BOOST_FOREACH ( std::string itemStr, itemList) {
        QString widgetId = QString::fromStdString(itemStr);
        QStandardItem *item = NULL;
        if (mMap.contains(widgetId)) item = mMap.value(widgetId);
        else {
           throw new SUI::ArgumentException(std::string("Widget ").append(widgetId.toStdString()).append(" doesn't exist."));
        }

        QStandardItem *parentItem = item->parent();
        int i = mStandardModel->indexFromItem(item).row();
        if (parentItem != NULL) {
            parentItem->removeRow(i);
            if (parentItem->child(i) == item) {
               throw new SUI::ArgumentException(std::string("Widget ").append(widgetId.toStdString()).append(" isn't deleted."));
            }
        }
        else {
            mStandardModel->removeRow(i);
            if (mStandardModel->item(i) == item) {
               throw new SUI::ArgumentException(std::string("Widget ").append(widgetId.toStdString()).append(" isn't deleted."));
            }
        }
        mMap.remove(widgetId);
        if (mWidgetList != NULL) mWidgetList->removeObject(widgetId.toStdString());
    }
}

bool SUI::TreeViewImpl::isLeafNode(const std::string &itemID) {
    bool bRet = true;
    if (mMap.contains(QString::fromStdString(itemID))) {
        QStandardItem   *item = mMap.value(QString::fromStdString(itemID));
        if (item->child(0) != NULL) {
            bRet = false;
        }
    }
    else {
        bRet = false;
    }
    return bRet;
}

QStandardItem *SUI::TreeViewImpl::getStandardItem(const QString &itemID) {
    QStandardItem   *item = NULL;
    if (mMap.contains(itemID)) item = mMap.value(itemID);
    return item;
}

void SUI::TreeViewImpl::sort(SortOrderEnum::SortOrder order) {
    Qt::SortOrder   qtSortOrder;
    switch (order)
    {
    case SortOrderEnum::Unsorted:
         getWidget()->setSortingEnabled(false);
         getWidget()->expandAll();
        break;
    case SortOrderEnum::Descending:
        qtSortOrder = Qt::DescendingOrder;
         getWidget()->setSortingEnabled(true);
         getWidget()->sortByColumn(0, qtSortOrder);
        break;
    case SortOrderEnum::Ascending:
        qtSortOrder = Qt::AscendingOrder;
         getWidget()->setSortingEnabled(true);
         getWidget()->sortByColumn(0, qtSortOrder);
        break;
    }
}

void SUI::TreeViewImpl::disableHeader(bool disableHeader) {
    getWidget()->setHeaderHidden(disableHeader);
}

void SUI::TreeViewImpl::handleSelectionChanged() {
    if (!selectionChanged.empty()) selectionChanged();
}

void SUI::TreeViewImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID, propertyValue);

    switch (propertyID) {
    case SUI::ObjectPropertyTypeEnum::Bold:
        setBold((propertyValue.compare("true", Qt::CaseInsensitive) == 0));
        break;

    case SUI::ObjectPropertyTypeEnum::Text:
        setText(propertyValue.toStdString());
        break;

    case SUI::ObjectPropertyTypeEnum::DisableHeader:
        disableHeader(propertyValue.toLower() == "true");
        break;

    case SUI::ObjectPropertyTypeEnum::SortingOrder:
        if (propertyValue == "Descending") mSortOrder = SortOrderEnum::Descending;
        else if (propertyValue == "Ascending") mSortOrder = SortOrderEnum::Ascending;
        else if (propertyValue == "NoSort") mSortOrder = SortOrderEnum::Unsorted;
        sort(mSortOrder);
        break;

    case SUI::ObjectPropertyTypeEnum::Width:
        mHeader->setWidth(propertyValue.toInt());
        break;

    default:
        break;
    }

}

void SUI::TreeViewImpl::selectItem(const int row, const int/*col*/) {
    QModelIndex index = dynamic_cast<QTreeView *>(BaseWidget::getWidget())->model()->index(row, 0);
     getWidget()->setCurrentIndex(index);
}

void SUI::TreeViewImpl::selectItem(const std::string idstr) {
    QString strID = QString::fromStdString(idstr);
    selectRow(strID);
}

/*****************************************************************************\
 *  FUNCTION    :   GetSelectedItems
 *  PARAMETERS  :   N.A.
 *  RETURN      :   QString
 *
 *  This function returns a list of strings of the ID's of selected items
\*****************************************************************************/
std::list<std::string> SUI::TreeViewImpl::getSelectedItems() const {
    std::list<std::string>  textList;    
    QModelIndexList selection =  getWidget()->selectionModel()->selectedRows();

    if (selection.count() != 0)
    {
        QModelIndex modelInd =  getWidget()->currentIndex();
        QStandardItem   *item = mStandardModel->itemFromIndex(modelInd);
        QString strID = mMap.key(item);
        std::string text;
        text = strID.toStdString();
        textList.push_back(text);
    }
    return textList;
}

std::list<std::string> SUI::TreeViewImpl::getItems() const {
    std::list<std::string> items;
    QList<QLabel *> widgets =  getWidget()->findChildren<QLabel *>();
    BOOST_FOREACH(QLabel * item, widgets) {
        items.push_back(item->text().toStdString());
    }
    return items;
}

void SUI::TreeViewImpl::onCollapseClicked() {
     getWidget()->collapse(getWidget()->currentIndex());
}

void SUI::TreeViewImpl::onExpandClicked() {
     getWidget()->expand(getWidget()->currentIndex());
}
