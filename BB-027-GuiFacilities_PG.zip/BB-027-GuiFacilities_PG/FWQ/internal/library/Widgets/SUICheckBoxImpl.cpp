//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::CheckBoxImpl.
// !\description Class implementation file for SUI::CheckBoxImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUICheckBoxImpl.h"

#include <QStyle>
#include <QVariant>

SUI::CheckBoxImpl::CheckBoxImpl(QWidget *parent) :
    BaseWidget(new QCheckBox(parent), SUI::ObjectType::CheckBox, false)
{
    exposeWidthProperty();

    connect(CheckBoxImpl::getWidget(), SIGNAL(toggled(bool)), this, SLOT(handleCheckedChanged(bool)));
}

void SUI::CheckBoxImpl::setDefaultProperties(const ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);

    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "30");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "200");

    setChecked(getPropertyValue(SUI::ObjectPropertyTypeEnum::Checked).toLower() == "true");

    switch (context)
    {
    case EditorSelector:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, QString::fromStdString(SUI::ObjectType::toString(Object::getObjectType())));
        break;

    case EditorForm:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, "TBD");
        break;

    default:
        break;
    }
}

QCheckBox *SUI::CheckBoxImpl::getWidget() const {
    return dynamic_cast<QCheckBox *>(BaseWidget::getWidget());
}

void SUI::CheckBoxImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID,propertyValue);

    switch (propertyID) {
    case SUI::ObjectPropertyTypeEnum::Bold:
        setBold((propertyValue.compare("true", Qt::CaseInsensitive) == 0));
        break;

    case SUI::ObjectPropertyTypeEnum::Text:
        setText(propertyValue.toStdString());
        break;

    case SUI::ObjectPropertyTypeEnum::Checked:
        setChecked((propertyValue.compare("true", Qt::CaseInsensitive) == 0));
        getWidget()->update();
        break;

    default:
        break;
    }
}

void SUI::CheckBoxImpl::handleCheckedChanged(bool newState) {
    if (!checkStateChanged.empty()) checkStateChanged(newState);
}

void SUI::CheckBoxImpl::setChecked(bool checked) {
    QCheckBox *cb = getWidget();
    if (cb->isChecked() != checked) {
        cb->setChecked(checked);
    }
}

bool SUI::CheckBoxImpl::isChecked() const {
    return getWidget()->isChecked();
}

void SUI::CheckBoxImpl::setText(const std::string &value) {
    QCheckBox *checkBox = getWidget();
    QString text = QString::fromStdString(value);
    if (checkBox->text() == text) return;
    checkBox->setText(text);
}

std::string SUI::CheckBoxImpl::getText() const {
    return getWidget()->text().toStdString();
}

void SUI::CheckBoxImpl::clearText() {
    getWidget()->setText("");
}

void SUI::CheckBoxImpl::setBold(bool bold) {
    getWidget()->setProperty("SUIFont", QVariant::fromValue<QString>(bold ? "bold" : ""));
    getWidget()->style()->polish(getWidget());
}

bool SUI::CheckBoxImpl::isBold() const {
    return getWidget()->property("SUIFont").toString() == "bold";
}
