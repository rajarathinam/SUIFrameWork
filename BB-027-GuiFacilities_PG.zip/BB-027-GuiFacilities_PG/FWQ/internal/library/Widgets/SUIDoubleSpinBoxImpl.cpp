//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::DoubleSpinBoxImpl.
// !\description Class implementation file for SUI::DoubleSpinBoxImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|



#include "SUIDoubleSpinBoxImpl.h"

#include <QStyle>

#include <float.h>

SUI::DoubleSpinBoxImpl::DoubleSpinBoxImpl(QWidget *parent) :
    BaseWidget(new CustomDoubleSpinBox(parent), SUI::ObjectType::DoubleSpinBox, false)
{
    connect(DoubleSpinBoxImpl::getWidget(), SIGNAL(valueChanged(double)), this, SLOT(handleValueChanged()));
    exposeWidthProperty();
}

void SUI::DoubleSpinBoxImpl::handleValueChanged() {
    if (!valueChanged.empty()) valueChanged();
}

void SUI::DoubleSpinBoxImpl::setDefaultProperties(const SUI::BaseObject::ObjectContext &context) {
    BaseWidget::setDefaultProperties(context);
    setPropertyValues(ObjectPropertyTypeEnum::StepSize, QString("0,01:%1").arg(INT_MAX));
    setPropertyValue(ObjectPropertyTypeEnum::StepSize, "1");
    setPropertyValues(ObjectPropertyTypeEnum::MinValue, QString("%1:%2").arg(INT_MIN).arg(INT_MAX));
    setPropertyValue(ObjectPropertyTypeEnum::MinValue, "0");
    setPropertyValues(ObjectPropertyTypeEnum::MaxValue, QString("%1:%2").arg(INT_MIN).arg(INT_MAX));
    setPropertyValue(ObjectPropertyTypeEnum::MaxValue, "500");
    setPropertyValues(ObjectPropertyTypeEnum::Precision,QString("0:%1").arg(DBL_MAX_10_EXP + DBL_DIG));
    setPropertyValue(ObjectPropertyTypeEnum::Precision,"2");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "30");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "200");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, "0.00");

    switch (context)
    {
    case EditorSelector:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, QString::fromStdString(SUI::ObjectType::toString(Object::getObjectType())));
        break;

    case EditorForm:
        setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, "0.00");
        break;

    default:
        break;
    }
}

CustomDoubleSpinBox *SUI::DoubleSpinBoxImpl::getWidget() const {
    return dynamic_cast<CustomDoubleSpinBox *>(BaseWidget::getWidget());
}

void SUI::DoubleSpinBoxImpl::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    BaseWidget::setPropertyValue(propertyID, propertyValue);
    switch (propertyID) {

    case SUI::ObjectPropertyTypeEnum::StepSize:
        setStepSize(propertyValue.toDouble());
        break;

    case SUI::ObjectPropertyTypeEnum::MaxValue:
        setMaxValue(propertyValue.toDouble());
        break;

    case SUI::ObjectPropertyTypeEnum::MinValue:
        setMinValue(propertyValue.toDouble());
        break;

    case SUI::ObjectPropertyTypeEnum::Precision:
        setPrecision(propertyValue.toInt());
        break;

    case SUI::ObjectPropertyTypeEnum::StepsizeToFactor:
        getWidget()->setStepSizeValueToFactor(propertyValue.toLower() == "true");
        break;

    case SUI::ObjectPropertyTypeEnum::Alignment:
        if (propertyValue.toLower() == "right") {
            setAlignment(AlignmentEnum::Right);
        }
        else if (propertyValue.toLower() == "center") {
            setAlignment(AlignmentEnum::HCenter);
        }
        else {
            setAlignment(AlignmentEnum::Left);
        }
        break;

    case SUI::ObjectPropertyTypeEnum::Bold:
        setBold((propertyValue.compare("true", Qt::CaseInsensitive) == 0));
        break;

    case SUI::ObjectPropertyTypeEnum::Text:
    {
        bool ok = false;
        double result = propertyValue.toDouble(&ok);
        if (ok) getWidget()->setValue(result);
        break;
    }
    default:
        break;

    }
}

QString SUI::DoubleSpinBoxImpl::getPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID) const {
    QString propertyValue = BaseWidget::getPropertyValue(propertyID);
    if (propertyID == SUI::ObjectPropertyTypeEnum::StepsizeToFactor) {
        getWidget()->setStepSizeValueToFactor((propertyValue.toUpper() == "TRUE") ? true : false);
    }
    return propertyValue;
}

void SUI::DoubleSpinBoxImpl::setMode(ErrorModeEnum::ErrorMode mode) {
    mCurrentMode = mode;
    if (mode == ErrorModeEnum::Error) {
        getWidget()->setProperty("BGColorSet", "error");
    }
    else {
        getWidget()->setProperty("BGColorSet", "");
    }
    getWidget()->style()->polish(getWidget());
}

double SUI::DoubleSpinBoxImpl::getValue() const {
    return getWidget()->value();
}

int SUI::DoubleSpinBoxImpl::getPrecision() const {
    return getWidget()->decimals();
}

void SUI::DoubleSpinBoxImpl::setValue(const double val) {
    getWidget()->setValue(val);
}

void SUI::DoubleSpinBoxImpl::setMinValue(const double val) {
    getWidget()->setMinimum(val);
}

double SUI::DoubleSpinBoxImpl::getMinValue() const {
    return getWidget()->minimum();
}

void SUI::DoubleSpinBoxImpl::setMaxValue(const double val) {
    getWidget()->setMaximum(val);
}

double SUI::DoubleSpinBoxImpl::getMaxValue() const {
    return getWidget()->maximum();
}

void SUI::DoubleSpinBoxImpl::setStepSize(const double val) {
    getWidget()->setSingleStep(val);
}

double SUI::DoubleSpinBoxImpl::getStepSize() const {
    return getWidget()->singleStep();
}

void SUI::DoubleSpinBoxImpl::setPrecision(const int val) {
    getWidget()->setDecimals(val);
}

void SUI::DoubleSpinBoxImpl::setStepSizeValueToFactor(const bool on) {
    getWidget()->setStepSizeValueToFactor(on);
}


void SUI::DoubleSpinBoxImpl::setBold(bool bold) {
    getWidget()->setProperty("SUIFont", QVariant::fromValue<QString>(bold ? "bold" : ""));
    getWidget()->style()->polish(getWidget());
}

void SUI::DoubleSpinBoxImpl::setAlignment(AlignmentEnum::Alignment align) {
    Qt::Alignment   qtAlign;
    switch (align)
    {
    case AlignmentEnum::Right:
        qtAlign = Qt::AlignRight;
        break;
    case AlignmentEnum::Left:
        qtAlign = Qt::AlignLeft;
        break;
    default:
        qtAlign = Qt::AlignCenter;
        break;
    }

    getWidget()->setAlignment(qtAlign);
}

SUI::AlignmentEnum::Alignment SUI::DoubleSpinBoxImpl::getAlignment() const {
    switch (getWidget()->alignment())
    {
    case Qt::AlignRight: return SUI::AlignmentEnum::Right;
    case Qt::AlignLeft: return SUI::AlignmentEnum::Left;
    default: return SUI::AlignmentEnum::HCenter;
    }
    return SUI::AlignmentEnum::HCenter;
}
