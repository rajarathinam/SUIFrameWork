//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::StyleSheet.
// !\description Class implementation file for SUI::StyleSheet.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIStyleSheet.h"
#include "FWQxCore/SUIIOException.h"

#include <QFile>
#include <QTextStream>

const std::string SUI::StyleSheet::ADT_STYLESHEETNAME="ADT";
const std::string SUI::StyleSheet::ONEGUI_STYLESHEETNAME="SourceGUI";
const std::string SUI::StyleSheet::ADT_STYLESHEETPATH=":/stylesheets/StyleSheets/ADT.css";
const std::string SUI::StyleSheet::ONEGUI_STYLESHEETPATH=":/stylesheets/StyleSheets/SourceGui.css";
std::string SUI::StyleSheet::m_styleSheetPath = ":/stylesheets/StyleSheets/ADT.css";
std::string SUI::StyleSheet::m_styleSheetName = SUI::StyleSheet::ADT_STYLESHEETNAME;

std::map<SUI::ObjectType::Type,const SUI::StyleSheet::StaticStyleSheetClassList> SUI::StyleSheet::m_styleSheetClassByObjectType =
{
    {SUI::ObjectType::Button,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::Label,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::LineEdit,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::CheckBox,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::RadioButton,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::GroupBox,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::CheckGroupBox,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::TabWidget,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::TabPage,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::ButtonBar,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::TableWidget,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::TableWidgetItem,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::SpinBox,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::DoubleSpinBox,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::DropDown,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::LEDWidget,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::CheckMark,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::ColorDrop,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::ColorCrossDrop,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::TextArea,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::ProgressBar,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::GraphicsView,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::MessageBox,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::PlotWidget,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::Splitter,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::FileDialog,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::UserControl,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::ListView,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::ControlWidget,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::StateWidget,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::ScienceSpinBox,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::QuestionMark,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::BusyIndicator,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::ImageWidget,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::TreeView,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::TreeViewItem,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::LineWidget,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::SvgWidget,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::DateTimeEdit,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::FormEditor,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::WidgetPage,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::Dialog,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})},
    {SUI::ObjectType::Container,SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"})}
};

SUI::StyleSheet *SUI::StyleSheet::getInstance(){
    static SUI::StyleSheet instance;
    return(&instance);
}

std::string SUI::StyleSheet::getStyleSheet() const {
    return m_styleSheet;
}

void SUI::StyleSheet::setStyleSheet(const std::string &styleSheet) {
    if (styleSheet == SUI::StyleSheet::ONEGUI_STYLESHEETNAME) {
        m_styleSheetPath = ONEGUI_STYLESHEETPATH;
    }
    else{
        m_styleSheetPath = ADT_STYLESHEETPATH;
    }
    m_styleSheetName = styleSheet;
    m_styleSheet = readStyleSheet();
}

std::string SUI::StyleSheet::getStyleSheetName() const {
    return m_styleSheetName;
}

SUI::StyleSheet::StaticStyleSheetClassList SUI::StyleSheet::getStyleSheetClassByObjectType(const SUI::ObjectType::Type &ObjectType) {
    std::map<SUI::ObjectType::Type,const StaticStyleSheetClassList>::const_iterator it = m_styleSheetClassByObjectType.find(ObjectType);
    return it != m_styleSheetClassByObjectType.end() ? it->second : SUI::StyleSheet::StaticStyleSheetClassList({"Default","Style1"});
}

std::string SUI::StyleSheet::readStyleSheet() {
    QFile stylesheetFile(QString::fromStdString(m_styleSheetPath));
    QString stylesheet;

    if (stylesheetFile.open(QIODevice::ReadOnly)) {
        QTextStream in(&stylesheetFile);
        while (!in.atEnd()) {
            stylesheet.append(in.readLine());
        }
        stylesheetFile.close();
    }
    else {
        throw new SUI::IOException(stylesheetFile.errorString().toStdString());
    }
    return stylesheet.toStdString();
}

SUI::StyleSheet::StyleSheet() :
    m_styleSheet(readStyleSheet())
{
}
