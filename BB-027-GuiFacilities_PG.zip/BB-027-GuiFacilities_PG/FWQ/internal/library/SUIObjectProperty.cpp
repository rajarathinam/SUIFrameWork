//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::ObjectProperty.
// !\description This class contains all data of one property.
//               A special case is the IndexedValue property. This property
//               holds values for a different number of instances of that
//               property. E.g. the width of each column in a Table Widget.
//               The number of columns vary and changes when columns are
//               inserted or removed. The format of an IndexedValue is
//               "index,value;". E.g. for a Table Widget with 4 columns, the
//               ColumnWidths property has an initial value of "0,100;1,100;2,
//               100;3,100;". In this example, al 4 columns have a width of 100.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|



#include "SUIObjectProperty.h"

#include "SUIBaseObject.h"

namespace SUI {

using std::cout;
using std::vector;
using std::map;

int SUI::ObjectProperty::maxHeight = 2160;  // "4K UHD"
int SUI::ObjectProperty::maxWidth = 3840;   // "4K UHD"

ObjectProperty::ObjectProperty(
        ObjectPropertyTypeEnum::Type widgetPropertyType,
        QString description_t,
        ObjectPropertyDataType type_t,
        QString values_t,
        QString defaultValue_t,
        bool readOnly_t,
        bool visible_t,
        QString displayName_t) :

    objectPropertyType(widgetPropertyType),
    description(description_t),
    type(type_t),
    values(values_t),
    defaultValue(defaultValue_t),
    value(defaultValue_t),
    readOnly(readOnly_t),
    visible(visible_t),
    minValue(0.0),
    maxValue(5000.0),
    mCurrentIndex(0),
    displayName(displayName_t)
{
    restrictMaxValueByName();
    defineValueRangeByValues(":");
}

ObjectProperty::ObjectProperty(const ObjectProperty &copy) :
    objectPropertyType(copy.objectPropertyType),
    description(copy.description),
    type(copy.type),
    values(copy.values),
    defaultValue(copy.defaultValue),
    value(copy.value),
    readOnly(copy.readOnly),
    visible(copy.visible),
    minValue(copy.minValue),
    maxValue(copy.maxValue),
    mCurrentIndex(copy.maxValue),
    displayName(copy.displayName)
{
}

ObjectProperty &ObjectProperty::operator=(const ObjectProperty &copy)
{
    if(&copy != this)
    {
        objectPropertyType = copy.objectPropertyType;
        description = copy.description;
        type = copy.type;
        values = copy.values;
        defaultValue = copy.defaultValue;
        value = copy.value;
        readOnly = copy.readOnly;
        visible = copy.visible;
        minValue = copy.minValue;
        maxValue = copy.maxValue;
        displayName = copy.displayName;
    }
    return *this;
}

ObjectPropertyTypeEnum::Type ObjectProperty::getObjectPropertyType() const {
    return objectPropertyType;
}

QString ObjectProperty::getDisplayName() const {
    if (displayName.isEmpty()) {
        return QString::fromStdString(ObjectPropertyTypeEnum::toString(objectPropertyType));
    }
    return displayName;
}

QString ObjectProperty::getDescription() const {
    QString desc = description;
    if (!defaultValue.isEmpty()) desc = desc.append(" The default value is %1.").arg(defaultValue);
    if (!values.isEmpty()) desc = desc.append(" The possible values are %1.").arg(values);
    return desc;
}

ObjectProperty::ObjectPropertyDataType ObjectProperty::getType() const {
    return type;
}

QString ObjectProperty::getDefaultValue() const {
    return defaultValue;
}

void ObjectProperty::setValue(const QString &val) {
    value = val;
}

QString ObjectProperty::getValue() const {
    return value;
}

void ObjectProperty::setReadOnly(bool ro) {
    readOnly = ro;
}

bool ObjectProperty::isReadOnly() const {
    return readOnly;
}

void ObjectProperty::setVisible(bool enable) {
    visible = enable;
}

void ObjectProperty::setHidden() {
    setVisible(false);
}

bool ObjectProperty::isVisible() const {
    return visible;
}

void ObjectProperty::setValues(const QString& vals) {
    values = vals;
}

QString ObjectProperty::getValues() const {
    return values;
}

void ObjectProperty::setMinValue(double val) {
    minValue = val;
}

void ObjectProperty::setMaxValue(double val) {
    maxValue = val;
}

double ObjectProperty::getMinValue() const {
    return minValue;
}

double ObjectProperty::getMaxValue() const {
    return maxValue;
}

void ObjectProperty::setCurrentIndex(int val) {
    mCurrentIndex = val;
}

int ObjectProperty::getCurrentIndex() const {
    return mCurrentIndex;
}

void ObjectProperty::restrictMaxValueByName() {
    if (objectPropertyType == ObjectPropertyTypeEnum::Height) maxValue = 2160;  //4K UHD
    else if (objectPropertyType == ObjectPropertyTypeEnum::Width) maxValue = 3840;  //4K UHD
}

/*!
 * \brief defineValueRangeByValues
 * \param values
 * \param separator
 * precondition: the range of values must have been defined with the smallest value on the left
 *    and the biggest on the right and defined by a seperator like: "100:300"
 *
 */
void ObjectProperty::defineValueRangeByValues(const QString &separator) {
    int indColon = values.indexOf(separator);
    if (indColon >= 0) {
        if (values.right(indColon + 1).length() > 0) {
            maxValue = values.right(values.length() - (indColon + 1)).toDouble();
        }
        if (values.left(indColon).length() > 0) {
            minValue = values.left(indColon).toDouble();
        }
    }
}

void ObjectProperty::setPropertyTypes(BaseObject *object) {
    typedef const vector<ObjectPropertyTypeEnum::Type> ConstTypeVector;
    vector<ObjectPropertyTypeEnum::Type> types;

    // BaseObject properties
    ConstTypeVector baseObjectTypes = getBaseObjectPropertyTypes();
    types.insert(types.end(),baseObjectTypes.begin(),baseObjectTypes.end());

    // BaseWidget properties
    ConstTypeVector widgetPropTypes = getBaseWidgetPropertyTypes();
    types.insert(types.end(),widgetPropTypes.begin(),widgetPropTypes.end());

    // Specific ObjectType properties
    ConstTypeVector specificTypes = getObjectPropertyTypes(object->getObjectType());
    types.insert(types.end(),specificTypes.begin(),specificTypes.end());

    // copy the default properties
    for (unsigned int n = 0, t = types.size(); n < t; n++) {
        object->addProperty(new ObjectProperty(getDefaultObjectProperty(types[n])));
    }
}

const vector<ObjectPropertyTypeEnum::Type> ObjectProperty::getObjectPropertyTypes(ObjectType::Type type) {
    map<ObjectType::Type,const StaticObjectPropertyTypes>::const_iterator it = objectPropertyTypes.find(type);
    return it != objectPropertyTypes.end() ? it->second : StaticObjectPropertyTypes();
}

const ObjectProperty ObjectProperty::getDefaultObjectProperty(ObjectPropertyTypeEnum::Type type) {
    map<ObjectPropertyTypeEnum::Type,const ObjectProperty>::const_iterator it = defaultObjectPropertyTypes.find(type);
    return it != defaultObjectPropertyTypes.end() ? it->second : getDefaultObjectProperty(ObjectPropertyTypeEnum::Invalid);
}

const std::vector<ObjectPropertyTypeEnum::Type> ObjectProperty::getBaseObjectPropertyTypes() {
    return std::vector<ObjectPropertyTypeEnum::Type>({
        ObjectPropertyTypeEnum::ObjectType,
        ObjectPropertyTypeEnum::Visible,
        ObjectPropertyTypeEnum::ID,
        ObjectPropertyTypeEnum::ToolTipEnable,
        ObjectPropertyTypeEnum::ToolTip,
        ObjectPropertyTypeEnum::StyleSheetClass
    });
}
const std::vector<ObjectPropertyTypeEnum::Type> ObjectProperty::getBaseGraphicsItemPropertyTypes() {
    return std::vector<ObjectPropertyTypeEnum::Type>();
}

const std::vector<ObjectPropertyTypeEnum::Type> ObjectProperty::getBaseWidgetPropertyTypes() {
    return std::vector<ObjectPropertyTypeEnum::Type>({
        ObjectPropertyTypeEnum::SUIObjectFactory,
        ObjectPropertyTypeEnum::MenuItem,
        ObjectPropertyTypeEnum::XPos,
        ObjectPropertyTypeEnum::YPos,
        ObjectPropertyTypeEnum::Height,
        ObjectPropertyTypeEnum::Width,
        ObjectPropertyTypeEnum::Enable,
        ObjectPropertyTypeEnum::Moveable,
        ObjectPropertyTypeEnum::Sizeable,
        ObjectPropertyTypeEnum::Menu
    });
}

const map<ObjectType::Type,const ObjectProperty::StaticObjectPropertyTypes> ObjectProperty::objectPropertyTypes = {
    {ObjectType::None,ObjectProperty::StaticObjectPropertyTypes()},

    {ObjectType::Button,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Text,
         ObjectPropertyTypeEnum::ImageData,
         ObjectPropertyTypeEnum::ImageDataPressed,
         ObjectPropertyTypeEnum::Menu,
         ObjectPropertyTypeEnum::Bold,
         ObjectPropertyTypeEnum::TabOrder,
         ObjectPropertyTypeEnum::Alignment
     }},

    {ObjectType::Label,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Menu,
         ObjectPropertyTypeEnum::Color,
         ObjectPropertyTypeEnum::BGColor,
         ObjectPropertyTypeEnum::Text,
         ObjectPropertyTypeEnum::Bold,
         ObjectPropertyTypeEnum::FontSize,
         ObjectPropertyTypeEnum::PropScientific,
         ObjectPropertyTypeEnum::Alignment
     }},

    {ObjectType::LineEdit,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Menu,
         ObjectPropertyTypeEnum::Color,
         ObjectPropertyTypeEnum::BGColor,
         ObjectPropertyTypeEnum::Text,
         ObjectPropertyTypeEnum::Alignment,
         ObjectPropertyTypeEnum::TabOrder,
         ObjectPropertyTypeEnum::RegularExpression,
         ObjectPropertyTypeEnum::RegExpTip,
         ObjectPropertyTypeEnum::Bold,
         ObjectPropertyTypeEnum::PlaceHolderText
     }},

    {ObjectType::CheckBox,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Text,
         ObjectPropertyTypeEnum::Menu,
         ObjectPropertyTypeEnum::Checked,
         ObjectPropertyTypeEnum::Bold,
         ObjectPropertyTypeEnum::TabOrder
     }},

    {ObjectType::RadioButton,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Text,
         ObjectPropertyTypeEnum::Menu,
         ObjectPropertyTypeEnum::Checked,
         ObjectPropertyTypeEnum::Bold,
         ObjectPropertyTypeEnum::TabOrder
     }},

    {ObjectType::GroupBox,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Text,
         ObjectPropertyTypeEnum::Bold,         
         ObjectPropertyTypeEnum::Hover,
         ObjectPropertyTypeEnum::BGColor,
         ObjectPropertyTypeEnum::HoverBGColor
     }},

    {ObjectType::CheckGroupBox,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Text,
         ObjectPropertyTypeEnum::Checked,
         ObjectPropertyTypeEnum::Bold,
         ObjectPropertyTypeEnum::TabOrder,
         ObjectPropertyTypeEnum::BGColor
     }},

    {ObjectType::TabWidget,
     ObjectProperty::StaticObjectPropertyTypes{
        ObjectPropertyTypeEnum::CurrentTabPage
     }},

    {ObjectType::TabPage,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Text,
         ObjectPropertyTypeEnum::ImageData,
         ObjectPropertyTypeEnum::Menu
     }},

    {ObjectType::ButtonBar,
     ObjectProperty::StaticObjectPropertyTypes{
     }},

    {ObjectType::TableWidget,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::ColumnCount,
         ObjectPropertyTypeEnum::RowCount,
         ObjectPropertyTypeEnum::ColumnWidths,
         ObjectPropertyTypeEnum::ListViewMode,
         ObjectPropertyTypeEnum::TabOrder,
         ObjectPropertyTypeEnum::MultipleRowSelection,
         ObjectPropertyTypeEnum::BorderOn,
         ObjectPropertyTypeEnum::BorderWidth,
         ObjectPropertyTypeEnum::HeadersOn,
         ObjectPropertyTypeEnum::HorizontalHeaderTags,
         ObjectPropertyTypeEnum::VerticalHeaderTags,
         ObjectPropertyTypeEnum::RowHeights,
     }},

    {ObjectType::TableWidgetItem,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Text,
         ObjectPropertyTypeEnum::Bold,
         ObjectPropertyTypeEnum::BorderOn,
         ObjectPropertyTypeEnum::BorderWidth,
         ObjectPropertyTypeEnum::CellName,
         ObjectPropertyTypeEnum::Alignment,
         ObjectPropertyTypeEnum::FontSize,
         ObjectPropertyTypeEnum::Color
     }},

    {ObjectType::SpinBox,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Text,
         ObjectPropertyTypeEnum::Alignment,
         ObjectPropertyTypeEnum::StepSize,
         ObjectPropertyTypeEnum::MinValue,
         ObjectPropertyTypeEnum::MaxValue,
         ObjectPropertyTypeEnum::Menu,
         ObjectPropertyTypeEnum::TabOrder,
         ObjectPropertyTypeEnum::StepsizeToFactor,
         ObjectPropertyTypeEnum::Bold
     }},

    {ObjectType::DoubleSpinBox,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Text,
         ObjectPropertyTypeEnum::Alignment,
         ObjectPropertyTypeEnum::StepSize,
         ObjectPropertyTypeEnum::MinValue,
         ObjectPropertyTypeEnum::MaxValue,
         ObjectPropertyTypeEnum::Menu,
         ObjectPropertyTypeEnum::Precision,
         ObjectPropertyTypeEnum::TabOrder,
         ObjectPropertyTypeEnum::StepsizeToFactor,
         ObjectPropertyTypeEnum::Bold
     }},

    {ObjectType::DropDown,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Text,
         ObjectPropertyTypeEnum::Menu,
         ObjectPropertyTypeEnum::Color,
         ObjectPropertyTypeEnum::BGColor,
         ObjectPropertyTypeEnum::TabOrder,
         ObjectPropertyTypeEnum::Bold
     }},

    {ObjectType::LEDWidget,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Menu,
         ObjectPropertyTypeEnum::Color
     }},

    {ObjectType::CheckMark,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Menu,
         ObjectPropertyTypeEnum::Color
     }},

    {ObjectType::ColorDrop,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Menu,
         ObjectPropertyTypeEnum::Color,
         ObjectPropertyTypeEnum::TabOrder
     }},

    {ObjectType::ColorCrossDrop,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Menu,
         ObjectPropertyTypeEnum::Color
     }},

    {ObjectType::TextArea,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Menu,
         ObjectPropertyTypeEnum::Color,
         ObjectPropertyTypeEnum::Text,
         ObjectPropertyTypeEnum::AutoScroll,
         ObjectPropertyTypeEnum::ReadOnly,
         ObjectPropertyTypeEnum::TabOrder,
         ObjectPropertyTypeEnum::Bold,
         ObjectPropertyTypeEnum::Alignment
    }},

    {ObjectType::ProgressBar,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Menu,
         ObjectPropertyTypeEnum::Text,
         ObjectPropertyTypeEnum::Bold,
         ObjectPropertyTypeEnum::Color,
         ObjectPropertyTypeEnum::Orientation,
         ObjectPropertyTypeEnum::Percentage,
         ObjectPropertyTypeEnum::MinValue,
         ObjectPropertyTypeEnum::MaxValue
     }},

    {ObjectType::GraphicsView,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Menu,
         ObjectPropertyTypeEnum::ImageData,
         ObjectPropertyTypeEnum::ScrollBars,
         ObjectPropertyTypeEnum::AutoFitBG,
         ObjectPropertyTypeEnum::ZoomStyle,
         ObjectPropertyTypeEnum::ScrollZoom,
         ObjectPropertyTypeEnum::BorderOn
     }},

    {ObjectType::MessageBox,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Text,
         ObjectPropertyTypeEnum::Bold
     }},

    {ObjectType::PlotWidget,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Menu,
         ObjectPropertyTypeEnum::Text,
         ObjectPropertyTypeEnum::Hover,
         ObjectPropertyTypeEnum::Zoom,
         ObjectPropertyTypeEnum::xAxisScale,
         ObjectPropertyTypeEnum::Color,
         ObjectPropertyTypeEnum::BGColor
     }},

    {ObjectType::Splitter,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Orientation
     }},

    {ObjectType::ScrollBar,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Orientation,
         ObjectPropertyTypeEnum::MaxValue,
         ObjectPropertyTypeEnum::MinValue,
         ObjectPropertyTypeEnum::StepSize,
     }},

    {ObjectType::DateTimeEdit, ObjectProperty::StaticObjectPropertyTypes{}},

    {ObjectType::FileDialog, ObjectProperty::StaticObjectPropertyTypes{}},

    {ObjectType::GraphicsPixmapItem, ObjectProperty::StaticObjectPropertyTypes{}},

    {ObjectType::GraphicsTextItem,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Color
     }},

    {ObjectType::GraphicsRectItem,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Color
     }},

    {ObjectType::GraphicsLineItem,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Color
     }},

    {ObjectType::GraphicsEllipseItem,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Color
     }},

    {ObjectType::GraphicsCrosshairItem,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Color
     }},

    {ObjectType::UserControl,
     ObjectProperty::StaticObjectPropertyTypes{
        ObjectPropertyTypeEnum::UserControl,
        ObjectPropertyTypeEnum::FileName
     }},

    {ObjectType::ListView,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Text,
         ObjectPropertyTypeEnum::RowCount,
         ObjectPropertyTypeEnum::SortingOrder,
         ObjectPropertyTypeEnum::SelectBehaviour,
         ObjectPropertyTypeEnum::FilterString,
         ObjectPropertyTypeEnum::Text,
         ObjectPropertyTypeEnum::Bold,
         ObjectPropertyTypeEnum::TabOrder,
         ObjectPropertyTypeEnum::Menu
     }},

    {ObjectType::ControlWidget,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::ControlType,
         ObjectPropertyTypeEnum::ControlState,
         ObjectPropertyTypeEnum::Menu
     }},

    {ObjectType::StateWidget,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::StateList,
         ObjectPropertyTypeEnum::ImageList,
         ObjectPropertyTypeEnum::DefaultState,
         ObjectPropertyTypeEnum::Menu
     }},

    {ObjectType::ScienceSpinBox,
     ObjectProperty::StaticObjectPropertyTypes{         
         ObjectPropertyTypeEnum::Text,
         ObjectPropertyTypeEnum::Alignment,
         ObjectPropertyTypeEnum::StepSize,
         ObjectPropertyTypeEnum::MaxValue,
         ObjectPropertyTypeEnum::MinValue,
         ObjectPropertyTypeEnum::Precision,
         ObjectPropertyTypeEnum::Menu,
         ObjectPropertyTypeEnum::TabOrder,
         ObjectPropertyTypeEnum::StepsizeToFactor,
         ObjectPropertyTypeEnum::Bold
     }},

    {ObjectType::QuestionMark,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Text,
         ObjectPropertyTypeEnum::TabOrder,
         ObjectPropertyTypeEnum::HelpFile
     }},

    {ObjectType::BusyIndicator,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::BusyIndicatorImage
     }},

    {ObjectType::ImageWidget, ObjectProperty::StaticObjectPropertyTypes{}},

    {ObjectType::TreeView,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Text,
         ObjectPropertyTypeEnum::DisableHeader,
         ObjectPropertyTypeEnum::SortingOrder,
         ObjectPropertyTypeEnum::Menu
     }},

    {ObjectType::TreeViewItem,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Text
     }},

    {ObjectType::LineWidget, ObjectProperty::StaticObjectPropertyTypes{}},

    {ObjectType::SvgWidget,
     ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Menu,
         ObjectPropertyTypeEnum::SvgImage,
         ObjectPropertyTypeEnum::SvgFilename
     }},

    {ObjectType::FormEditor, ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::SUIVersion,
         ObjectPropertyTypeEnum::SUICoreVersion,
         ObjectPropertyTypeEnum::SUIEditorVersion,
         ObjectPropertyTypeEnum::SUIObjectFactory,
         ObjectPropertyTypeEnum::SUIName,
         ObjectPropertyTypeEnum::SUIDescription,
         ObjectPropertyTypeEnum::HasRightButtonBar,
         ObjectPropertyTypeEnum::HasBottomButtonBar,
         ObjectPropertyTypeEnum::HasStatusBar,
         ObjectPropertyTypeEnum::Namespace,
         ObjectPropertyTypeEnum::ClassName
     }},

    {ObjectType::WidgetPage, ObjectProperty::StaticObjectPropertyTypes{}},

    {ObjectType::Container, ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::TabOrder
     }},

    {ObjectType::WebView, ObjectProperty::StaticObjectPropertyTypes{
         ObjectPropertyTypeEnum::Url,
         ObjectPropertyTypeEnum::Html,
         ObjectPropertyTypeEnum::ZoomFactor
     }},

    {ObjectType::Dialog, ObjectProperty::StaticObjectPropertyTypes{}}
};

const map<ObjectPropertyTypeEnum::Type,const ObjectProperty> ObjectProperty::defaultObjectPropertyTypes = createDefaultObjectPropertyTypes();

const std::map<ObjectPropertyTypeEnum::Type, const ObjectProperty> ObjectProperty::createDefaultObjectPropertyTypes() {
    typedef ObjectPropertyTypeEnum E; // for the sake of readability
    typedef ObjectProperty T; // for the sake of readability
    return map<ObjectPropertyTypeEnum::Type, const ObjectProperty> {

        // IndexedValue
        {E::ColumnWidths,T(E::ColumnWidths,"The width of all columns",IndexedValue,"","")},
        {E::RowHeights,T(E::RowHeights,"The Height of all rows",IndexedValue,"","")},

        // File
        {E::HelpFile,T(E::HelpFile,"The help text file.",File,"","")},
        {E::ImageData,T(E::ImageData,"The filename of the image.",File,"","")},
        {E::ImageDataPressed,T(E::ImageDataPressed,"The filename of the image when the button is pressed.",File,"","")},
        {E::SvgImage,T(E::SvgImage,"The svg image file.",File,"","")},

        // Bool
        {E::HasBottomButtonBar,T(E::HasBottomButtonBar,"If true the there is a bottom buttonbar.",Bool,"","false",true,false)},
        {E::HasRightButtonBar,T(E::HasRightButtonBar,"If true the there is a right buttonbar.",Bool,"","false",true,false)},
        {E::HasStatusBar,T(E::HasStatusBar,"If true the there is a statusbar.",Bool,"","false",true,false,"")},
        {E::Visible,T(E::Visible,"If true the object is visible.",Bool,"","true")},
        {E::Enable,T(E::Enable,"If true the object is enabled.",Bool,"","true")},
        {E::Moveable,T(E::Moveable,"If true the object is moveable.",Bool,"","true")},
        {E::Sizeable,T(E::Sizeable,"If true the object is resizeable, if false the size is fixed.",Bool,"","true")},
        {E::Checked,T(E::Checked,"The checkstate.",Bool,"","false")},
        {E::Bold,T(E::Bold,"Set the text bold or not.",Bool,"","false")},
        {E::ListViewMode,T(E::ListViewMode,"Set TableWidget in ListView mode",Bool,"","false")},
        {E::MultipleRowSelection,T(E::MultipleRowSelection,"Enable selection of multiple items",Bool,"","false")},
        {E::BorderOn,T(E::BorderOn,"Set the border around the Widget on or off",Bool,"","true")},
        {E::HeadersOn,T(E::HeadersOn,"Defines if headers are displayed or not",Bool,"","false")},
        {E::AutoScroll,T(E::AutoScroll,"If true the content will be scrolled automatically.",Bool,"","true")},
        {E::ReadOnly,T(E::ReadOnly,"If true then the property is read only.",Bool,"","false")},
        {E::StepsizeToFactor,T(E::StepsizeToFactor,"The stepsize is multiplied by factor when enabled.",Bool,"","false")},
        {E::ToolTipEnable,T(E::ToolTipEnable,"Enables or disables tooltips.",Bool,"","true")},
        {E::ScrollBars,T(E::ScrollBars,"If true the scrollbars are visible.",Bool,"","true")},
        {E::ScrollZoom,T(E::ScrollZoom,"If true zooming can be done by scrolling.",Bool,"","true")},
        {E::DisableHeader,T(E::DisableHeader,"If true the headers are disabled.",Bool,"","")},
        {E::PropScientific,T(E::PropScientific,"Use scientific notation.",Bool,"","false")},
        {E::Hover,T(E::Hover,"Enable hover events.",Bool,"","false",false,true)},
        {E::Zoom,T(E::Zoom,"Enable zooming. Default is false.",Bool,"","false")},
        {E::Percentage,T(E::Percentage,"Disable the progressbar.",Bool,"","true")},

        // DropDown
        {E::Alignment,T(E::Alignment,"The alignment of the object.",DropDown,"Left;Center;Right","Left")},
        {E::BGColor,T(E::BGColor,"The background color.",DropDown,"","")},
        {E::HoverBGColor,T(E::HoverBGColor,"The background color while hover.",DropDown,"","")},
        {E::CellAlignment,T(E::CellAlignment,"The alignment of the object in a cell.",DropDown, "Stretch;Left;Center;Right","Stretch")},
        {E::Color,T(E::Color,"The color.",DropDown,"","")},
        {E::ControlType,T(E::ControlType,"The control type.",DropDown,"","")},
        {E::ControlState,T(E::ControlState,"The control state.",DropDown,"","")},
        {E::DefaultState,T(E::DefaultState,"The default state in the user interface.",DropDown,"","")},
        {E::Orientation,T(E::Orientation,"The orientation of the object. Values are horizontal or vertical. Default value is horizontal.",DropDown,"Horizontal;Vertical","Horizontal")},
        {E::SortingOrder,T(E::SortingOrder,"The sort order.",DropDown,"NoSort;Descending;Ascending;Natural_Ascending;Natural_Descending;Natural_Ascending_Case_Sensitive;Natural_Descending_Case_Sensitive", "NoSort")},
        {E::xAxisScale,T(E::xAxisScale,"The x-axis scale type.",DropDown,"Normal;Date;Time;TimeSmall;DateTime;CustomTime", "Normal")},
        {E::AutoFitBG,T(E::AutoFitBG,"If true the background will autofit the contents.",DropDown,"Stretched;Cropped;Padding", "Padding")},
        {E::ZoomStyle,T(E::ZoomStyle,"The zoomstyle.",DropDown,"None;Panning;Area Selection", "Panning")},
        {E::FontSize,T(E::FontSize,"The size of the font.",DropDown,"Big;Normal;Small", "Normal")},
        {E::SelectBehaviour,T(E::SelectBehaviour,"The selection behaviour.",DropDown,"Multiple;Single","Multiple")},
        {E::BusyIndicatorImage,T(E::BusyIndicatorImage,"The BusyIndicator Image.",DropDown,"RotatingWheel;RollingDots", "RotatingWheel")},
        {E::StyleSheetClass,T(E::StyleSheetClass,"The StyleSheeet class.",DropDown,"","")},
        {E::SUIStyleSheet,T(E::SUIStyleSheet,"The stylesheet of the user interface.", DropDown, "ADT;SourceGUI","Default", true, false)},

        // String
        {E::SUIVersion,T(E::SUIVersion,"The version.",String,"",QString("%1.%2.%3").arg(SUI_MAJOR).arg(SUI_MINOR).arg(SUI_REVISION), true, false)},
        {E::SUICoreVersion,T(E::SUICoreVersion,"The core version.",String,"",QString("%1.%2.%3").arg(SUI_MAJOR).arg(SUI_MINOR).arg(SUI_REVISION), true, false)},
        {E::SUIEditorVersion,T(E::SUIEditorVersion,"The editor version.",String,"",QString("%1.%2.%3").arg(SUI_EDITOR_MAJOR).arg(SUI_EDITOR_MINOR).arg(SUI_REVISION), true, false)},
        {E::SUIObjectFactory,T(E::SUIObjectFactory,"SUIObjectFactory",String,"","Object factory", true, false)},
        {E::SUIName,T(E::SUIName,"The name of the user interface.",String,"","System User Interface (SUI)", false, false)},
        {E::SUIDescription,T(E::SUIDescription,"The description of the user interface.",String,"","SUI", false, false)},
        {E::CellName,T(E::CellName,"The Name of the object in a cell.",String, "","")},
        {E::FileName,T(E::FileName,"The File Name of User Control.",String, "","")},
        {E::TabOrder,T(E::TabOrder,"Position in the tab order queue.",String,"","")},
        {E::ID,T(E::ID,"The unique identifier of the object.",String,"","")},
        {E::ToolTip,T(E::ToolTip,"The tooltip text.",String,"","")},
        {E::UserControl,T(E::UserControl,"The name of the parent UserControl.",String,"","")},
        {E::Menu,T(E::Menu,"Context menuitems stringList.",String,"","")},
        {E::Text,T(E::Text,"The text.",String,"","TBD")},
        {E::HorizontalHeaderTags,T(E::HorizontalHeaderTags,"The tags of the horizontal headers",String,"","")},
        {E::VerticalHeaderTags,T(E::VerticalHeaderTags,"The tags of the vertical headers",String,"","")},
        {E::StateList,T(E::StateList,"The list of supported states.",String,"","",false)},
        {E::ImageList,T(E::ImageList,"The list of supported images.",String,"","",false)},
        {E::RegularExpression,T(E::RegularExpression,"The regular expression.",String,"",".*")},
        {E::RegExpTip,T(E::RegExpTip,"The display tip in the line edit.",String,"","")},
        {E::FilterString,T(E::FilterString,"The string used to filter the list.",String,"","")},
        {E::SvgFilename,T(E::SvgFilename,"The svg image filename.",String,"","")},
        {E::PlaceHolderText,T(E::PlaceHolderText,"Place Holder Text",String,"","")},
        {E::Url,T(E::Url,"URL",String,"","")},
        {E::Html,T(E::Html,"Html",String,"","")},
        {E::Namespace,T(E::Namespace,"The namespace of generated files",String,"","NMSP")},
        {E::ClassName,T(E::ClassName,"The classname of generated files",String,"","CLNA")},

        // Number
        {E::XPos,T(E::XPos,"The x-coordinate of the object.",Number,"","0")},
        {E::YPos,T(E::YPos,"The y-coordinate of the object.",Number,"","0")},
        {E::Height,T(E::Height,"The height of the object.",Number,"","0")},
        {E::Width,T(E::Width,"The width of the object.",Number,"","0")},
        {E::Precision,T(E::Precision,"The amount of digits after the comma.",Number,"","0")},
        {E::RowCount,T(E::RowCount,"The number of rows.",Number,"","0",true)},
        {E::ColumnCount,T(E::ColumnCount,"The number of columns.",Number,"","0",true)},
        {E::CurrentTabPage,T(E::CurrentTabPage,"The currently selected Tab Page.",Number,"","1")},
        {E::BorderWidth,T(E::BorderWidth,"The width of the border.",Number,"","3")},
        {E::MinValue,T(E::MinValue,"The minimum value",Number,"","0")},
        {E::MaxValue,T(E::MaxValue,"The maximum value.",Number,"","100")},
        {E::StepSize,T(E::StepSize,"The value with wich the actual value is incremented/decremented.",Number,"","1")},

        // Double
        {E::ZoomFactor,T(E::ZoomFactor,"Zoom Factor.",Double,"","1")},

        // Enum
        {E::ObjectType,T(E::ObjectType,"The type of the object.",Enum,"","None")},

        // unknown/unused
        {E::MenuItem,T(E::MenuItem,"MenuItem",String,"","")},

        {E::Invalid,T(E::Invalid,"Invalid",String,"","")}
    };
}

}
