//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::GUIViewerWidgetController.
// !\description Class implementation file for SUI::GUIViewerWidgetController.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUIQUiLoader.h"

#include <iostream>
#include <exception>

#include <QTimer>
#include <QSplitter>
#include <QTextEdit>
#include <QFileInfo>
#include <QMessageBox>
#include <QDir>
#include <boost/foreach.hpp>

#include "SUIStyleSheet.h"
#include "FWQxCore/SUIArgumentException.h"
#include "SUITabWidgetImpl.h"
#include "SUITabPageImpl.h"
#include "SUITableWidgetImpl.h"
#include "SUISplitterImpl.h"
#include "SUITreeViewImpl.h"
#include "SUIDialogSerializer.h"
#include "FWQxCore/SUIXmlException.h"
#include "FWQxCore/SUIIOException.h"
#include "SUIDialogImpl.h"

using namespace std;

GUIViewerWidgetController::GUIViewerWidgetController():
    mWidget(NULL)
{
}

GUIViewerWidgetController::~GUIViewerWidgetController() {
    if (mWidget != NULL)  {
        qDeleteAll(mUserControls);
        qDeleteAll(mChildren);
        delete mWidget;
        mWidget = NULL;
    }
}

void GUIViewerWidgetController::writeWidgetProperty(SUI::ObjectPropertyTypeEnum::Type key, const QString &value) {
    setPropertyValue(key, value);
}

void GUIViewerWidgetController::writeInclude(const QString &include, const QString &uiFilename) {
    setInclude(include,uiFilename);
}

GUIDefinitionVisitor &GUIViewerWidgetController::openChildWidget() {
    GUIViewerWidgetController *childWidget = new GUIViewerWidgetController();
    mChildren.append(childWidget);
    return *childWidget;
}

void GUIViewerWidgetController::closeChildWidget() {

}

SUI::BaseWidget *GUIViewerWidgetController::addToWidget(QWidget *parent, SUI::ObjectList &widgetList,
                                                        TabOrder &tabOrder, QList<GUIViewerWidgetController *> *uctrlList , const QString &uctrlID) {

    using namespace SUI;

    mWidget = NULL;
    ObjectType::Type widgetType = ObjectType::fromString(getPropertyValue(ObjectPropertyTypeEnum::ObjectType).toStdString());;

    mWidget = SUI::ObjectFactory::getInstance()->createWidget(widgetType, parent, &widgetList);
    if (mWidget == NULL) {
        std::cerr << "ArgumentException: " << std::string("Unsupported widget ").append(ObjectType::toString(widgetType)).append(" encountered.") << std::endl;
        exit(1);
    }
    mWidget->setObjectContext(BaseWidget::Gui);

    BOOST_FOREACH (ObjectPropertyTypeEnum::Type propertyID, getPropertyTypes()) {
        if (propertyID == ObjectPropertyTypeEnum::CellAlignment) mWidget->addCellProperties();
        mWidget->setPropertyValue(propertyID, getPropertyValue(propertyID));
    }

    if (uctrlID.isEmpty() == false && uctrlList == NULL) {
        //  This is a UserControl child and it's ID should be renamed
        mWidget->setPropertyValue(ObjectPropertyTypeEnum::ID, QString("%1:%2").arg(uctrlID).arg(QString::fromStdString(mWidget->getId())));
    }
    widgetList.addObject(mWidget->getId(), SUI::ObjectFactory::getInstance()->toObject(mWidget));

    int x = getPropertyValue(ObjectPropertyTypeEnum::XPos).toInt();
    int y = getPropertyValue(ObjectPropertyTypeEnum::YPos).toInt();
    int height = getPropertyValue(ObjectPropertyTypeEnum::Height).toInt();
    int width = getPropertyValue(ObjectPropertyTypeEnum::Width).toInt();
    mWidget->getWidget()->setGeometry(x, y, width, height);

    if (mWidget->getObjectType() == ObjectType::TabWidget) {
        TabWidgetImpl *tabWidget = dynamic_cast<TabWidgetImpl *>(mWidget);
        BOOST_FOREACH (GUIViewerWidgetController * childWidget,  mChildren) {
            if (ObjectType::fromString(childWidget->getPropertyValue(ObjectPropertyTypeEnum::ObjectType).toStdString()) == ObjectType::TabPage) {
                BaseWidget *child = childWidget->addToWidget(mWidget->getWidget(), widgetList, tabOrder, uctrlList, uctrlID);
                QString tabName = childWidget->getPropertyValue(ObjectPropertyTypeEnum::Text);
                TabPageImpl *tabPage = dynamic_cast<TabPageImpl *>(child);
                tabPage->setTabText(tabName.toStdString());
                tabWidget->addNewTab(tabPage);
                tabPage->setPropertyValue(ObjectPropertyTypeEnum::ImageData, childWidget->getPropertyValue(ObjectPropertyTypeEnum::ImageData));
            }
        }
    }

    BOOST_FOREACH (GUIViewerWidgetController * childWidget, mChildren) {
        if (ObjectType::fromString(childWidget->getPropertyValue(ObjectPropertyTypeEnum::ObjectType).toStdString()) == ObjectType::TabPage) continue;

        BaseWidget *child = childWidget->addToWidget(mWidget->getWidget(), widgetList, tabOrder, uctrlList, uctrlID);
        if (child == NULL) continue;
        if (mWidget->getObjectType() == ObjectType::TableWidget) {
            TableWidgetImpl *tableWidget = dynamic_cast<TableWidgetImpl *>(mWidget);
            if (tableWidget->startReading(
                                    getPropertyValue(ObjectPropertyTypeEnum::RowCount).toInt(),
                                    getPropertyValue(ObjectPropertyTypeEnum::ColumnCount).toInt())) {
                tableWidget->addNewTableWidgetItem(dynamic_cast<Widget *>(SUI::ObjectFactory::getInstance()->toObject(child)));
            }
        }
        else if (mWidget->getObjectType() == ObjectType::Splitter) {
            dynamic_cast<SplitterImpl *>(mWidget)->addSplitterWidget(child);

            if (child->getObjectType() == ObjectType::TextArea) {
                child->getWidget()->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
                dynamic_cast<QTextEdit *>(child->getWidget())->setSizeIncrement(1, 1);
                child->getWidget()->setMinimumHeight(child->getPropertyValue(ObjectPropertyTypeEnum::Height).toInt());
                dynamic_cast<QSplitter *>(mWidget->getWidget())->insertWidget(1, child->getWidget());
            }
            else {
                dynamic_cast<QSplitter *>(mWidget->getWidget())->insertWidget(0, child->getWidget());
            }
        }
        else if (mWidget->getObjectType() == ObjectType::TreeView) {
            child->setVisible(false);
            dynamic_cast<TreeViewImpl *>(mWidget)->addNewTreeItem(dynamic_cast<TreeViewItemImpl *>(child));
            BOOST_FOREACH (GUIViewerWidgetController * pChild, childWidget->mChildren)
                addTreeChild(pChild, mWidget);
        }
    }

    if (mWidget->getObjectType() == ObjectType::StateWidget) {
        mWidget->setPropertyValue(ObjectPropertyTypeEnum::DefaultState, getPropertyValue(ObjectPropertyTypeEnum::DefaultState));
    }
    else if (mWidget->getObjectType() == ObjectType::TableWidget) {
        TableWidgetImpl *tableWidget = dynamic_cast<TableWidgetImpl *>(mWidget);
        tableWidget->setPropertyValue(ObjectPropertyTypeEnum::RowHeights,tableWidget->getPropertyValue(ObjectPropertyTypeEnum::RowHeights));
        tableWidget->setPropertyValue(ObjectPropertyTypeEnum::ColumnWidths,tableWidget->getPropertyValue(ObjectPropertyTypeEnum::ColumnWidths));
        tableWidget->stopReading();
    }
    else if (mWidget->getObjectType() == ObjectType::Splitter) {
        dynamic_cast<QSplitter *>(mWidget->getWidget())->setCollapsible(1, false);
        QList<int>  list;
        list << (getPropertyValue(ObjectPropertyTypeEnum::Height).toInt()) << 1;
        dynamic_cast<QSplitter *>(mWidget->getWidget())->setSizes(list);
    }
    else if (mWidget->getObjectType() == ObjectType::UserControl) {
        if (uctrlList != NULL) {
            //  Retrieve the contents of this UserControl from it's definition from the UserControl-Definition list.
            BOOST_FOREACH (GUIViewerWidgetController * vwUCtrl, *uctrlList) {
                if (vwUCtrl->getPropertyValue(ObjectPropertyTypeEnum::ID) == mWidget->getPropertyValue(ObjectPropertyTypeEnum::UserControl)) {
                    BOOST_FOREACH (GUIViewerWidgetController * ucChild, vwUCtrl->mChildren) {
                        ucChild->addToWidget(mWidget->getWidget(), widgetList, tabOrder, NULL, QString::fromStdString(mWidget->getId()));
                    }
                }
            }
        }
    }

    try
    {
        if (getPropertyTypes().contains(ObjectPropertyTypeEnum::TabOrder)) {
            if (getPropertyValue(ObjectPropertyTypeEnum::TabOrder) != "") { //not all widgets have TabOrder property
                tabOrder.addTabOrder(getPropertyValue(ObjectPropertyTypeEnum::TabOrder).toInt(), mWidget->getWidget());
                widgetList.addTabOrder(mWidget->getId());
                mWidget->getWidget()->setFocusPolicy(Qt::StrongFocus);
            }
            else {
                mWidget->getWidget()->setFocusPolicy(Qt::ClickFocus);
            }
        }
        else {
            mWidget->getWidget()->setFocusPolicy(Qt::ClickFocus);
        }
    }
    catch (ArgumentException *re)
    {
        std::cerr << "ArgumentException: " << re->getExceptionMessage() << std::endl;
        exit(1);
    }
    catch (Exception *re)
    {
        std::cerr << "Exception: " << re->getExceptionMessage() << std::endl;
        exit(1);
    }

    if (mWidget->getWidget()->parent() == NULL) mWidget->getWidget()->setParent(parent);

    return mWidget;
}


void GUIViewerWidgetController::addTreeChild(GUIViewerWidgetController *childWidget, SUI::BaseWidget *pDragAndDropWidget) {
    SUI::TreeViewImpl *treeViewImpl = dynamic_cast<SUI::TreeViewImpl *>(pDragAndDropWidget);
    SUI::TreeViewItemImpl *treeViewItemImpl = dynamic_cast<SUI::TreeViewItemImpl *>(childWidget->mWidget);

    treeViewImpl->addNewTreeItemToItem(treeViewItemImpl, childWidget->mWidget->getWidget()->parent()->objectName());

    BOOST_FOREACH (GUIViewerWidgetController * pChild, childWidget->mChildren)
        addTreeChild(pChild, pDragAndDropWidget);

}

void GUIViewerWidgetController::addUserControl(GUIViewerWidgetController *usercontrol)
{
    mUserControls.append(usercontrol);
}

QList<GUIViewerWidgetController *> GUIViewerWidgetController::getUserControls()
{
    return mUserControls;
}

QMap<QWidget *, int > TabOrder::getTabOrder() const {
    return tabOrder;
}

void TabOrder::addTabOrder(const int order,  QWidget *widget) {
    tabOrder.insert(widget, order);
}

QMap<QWidget *, int> TabOrder::getTabs() const {
    return tabs;
}

void TabOrder::setTabs(QWidget *widget, const int order) {
    tabs.insert(widget, order);
}

void TabOrder::clear() {
    tabOrder.clear();
}

QWidget *SUI::QUiLoader::loadQUi(const QString uiFilename, SUI::ObjectList &objectList, TabOrder &tabOrder)
{
    if (uiFilename == "") throw new SUI::ArgumentException("Argument 'uiFilename' is empty");
    QFileInfo fInfo(uiFilename);
    if (uiFilename.left(1) != ":" && !fInfo.exists()) {
        throw new SUI::IOException(std::string("Unable to open file ").append(uiFilename.toStdString()).append(". File doesn't exist"));
    }
    SUI::DialogSerializer mySerializer("SUI", SUI::DialogSerializer::Read);
    GUIViewerWidgetController *mainWidget = new GUIViewerWidgetController();

    try
    {
        mySerializer.openFile(uiFilename);
        mySerializer.acceptVisitor(*mainWidget);
    }
    catch (SUI::XmlException *re)
    {
        throw (re);
    }
    catch (SUI::IOException *re)
    {
        throw (re);
    }
    catch (SUI::Exception *re)
    {
        throw (re);
    }
    mySerializer.closeFile();

    SUI::StyleSheet::getInstance()->setStyleSheet(mainWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::SUIStyleSheet).toStdString());

    //  Load the used UserControl's.
    BOOST_FOREACH (const QString &newFileName, mainWidget->getIncludes().values()) {
        try
        {
            const QString filePath = QFileInfo(uiFilename).absolutePath();
            const QString fullFileName =  QString("%1%2%3").arg(filePath).arg(QDir::separator()).arg(newFileName);
            mainWidget->addUserControl(readInclude(fullFileName));
        }
        catch (SUI::XmlException *re)
        {
            mySerializer.closeFile();
            throw (new SUI::XmlException(re->getExceptionMessage()));
        }
        catch (SUI::IOException *re)
        {
            throw (new SUI::IOException(re->getExceptionMessage()));
        }
    }

    QList<GUIViewerWidgetController *> uCtrlList = mainWidget->getUserControls();
    
    QWidget* widget = new QWidget();
    BOOST_FOREACH (GUIViewerWidgetController * childWidget, mainWidget->getUserChildren())
        childWidget->addToWidget(widget, objectList, tabOrder, &uCtrlList, QString::null);

    widget->resize(
                mainWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt(),
                mainWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt());
    
    widget->setWindowTitle(mainWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::SUIName));

    delete mainWidget;
    mainWidget = NULL;
    return widget;
}

/*****************************************************************************\
 *  FUNCTION    :   ReadInclude
 *  PARAMETERS  :   const QString &uiFilename
 *  RETURN      :   bool
 *
 *  This function reads the file containing a UserControl and adds this
 *  UserControl to the mUCtrlList, which will later be used by the
 *  rticGUIViewerWidget::addToWidget() function.
\*****************************************************************************/
GUIViewerWidgetController *SUI::QUiLoader::readInclude(const QString &uiFilename) {
    QFileInfo fInfo(uiFilename);
    if (!fInfo.exists()) {
        QString uctrlName;
        int ind = uiFilename.indexOf("UCT-");
        if (ind != -1) {
            ind += 4;
            uctrlName = uiFilename.mid(ind, uiFilename.length() - 4);
        }
        else {
            uctrlName = QString("Unknown UserControl Name");
        }
        QMessageBox::critical(NULL, "Error", QString("The file %1, containing UserControl %2 does not exist.\n").arg(uiFilename).arg(uctrlName));
        return NULL;
    }
    SUI::DialogSerializer mySerializer("UserControl", SUI::DialogSerializer::Read);
    GUIViewerWidgetController *vwUCtrl = new GUIViewerWidgetController();

    try
    {
        mySerializer.openFile(uiFilename);
        mySerializer.acceptVisitor(*vwUCtrl);
    }
    catch (SUI::XmlException *re)
    {
        throw (re);
    }
    catch (SUI::IOException *re)
    {
        mySerializer.closeFile();
        throw (re);
    }
    mySerializer.closeFile();

    return vwUCtrl;
}

QList<GUIViewerWidgetController *> GUIViewerWidgetController::getUserChildren()
{
    return mChildren;
}
