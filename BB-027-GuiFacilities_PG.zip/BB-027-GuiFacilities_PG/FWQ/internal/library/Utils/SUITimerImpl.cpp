//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::TimerImpl.
// !\description Class implementation file for SUI::TimerImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUITimerImpl.h"

SUI::TimerImpl::TimerImpl(QObject *parent) :
    QTimer(parent), Timer()
{
    connect(this,SIGNAL(timeout()),this,SLOT(onTimeout()));
}

bool SUI::TimerImpl::isActive() const {
    return QTimer::isActive();
}

int SUI::TimerImpl::interval() const {
    return QTimer::interval();
}

void SUI::TimerImpl::setInterval(int msec) {
    QTimer::setInterval(msec);
}

bool SUI::TimerImpl::isSingleShot() const {
    return QTimer::isSingleShot();
}

void SUI::TimerImpl::setSingleShot(bool singleShot) {
    QTimer::setSingleShot(singleShot);
}

int SUI::TimerImpl::getTimerId() const {
    return QTimer::timerId();
}

void SUI::TimerImpl::start(int msec) {
    QTimer::start(msec);
}

void SUI::TimerImpl::start() {
    QTimer::start();
}

void SUI::TimerImpl::stop() {
    QTimer::stop();
}

void SUI::TimerImpl::onTimeout() {
    if (!SUI::Timer::timeout.empty()) SUI::Timer::timeout();
}
