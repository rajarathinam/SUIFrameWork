//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::DateImpl.
// !\description Class implementation file for SUI::DateImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|



#include "SUIDateImpl.h"

SUI::DateImpl::DateImpl() :
    QDate(),
    Date()
{
}

void SUI::DateImpl::addDays(int ndays) {
    QDate d = QDate::addDays(ndays);
    setDate(d.year(),d.month(),d.day());
}

void SUI::DateImpl::addMonths(int nmonths) {
    QDate d = QDate::addMonths(nmonths);
    setDate(d.year(),d.month(),d.day());
}

void SUI::DateImpl::addYears(int nyears) {
    QDate d = QDate::addYears(nyears);
    setDate(d.year(),d.month(),d.day());
}

int SUI::DateImpl::getDay() const {
    return QDate::day();
}

int SUI::DateImpl::getDayOfWeek() const {
    return QDate::dayOfWeek();
}

int SUI::DateImpl::getDayOfYear() const {
    return QDate::dayOfYear();
}

int SUI::DateImpl::getDaysInMonth() const {
    return QDate::daysInMonth();
}

int SUI::DateImpl::getDaysInYear() const {
    return QDate::daysInYear();
}

int SUI::DateImpl::getDaysTo(const SUI::Date *d) const {
    return QDate::daysTo(*dynamic_cast<QDate*>(dynamic_cast<DateImpl*>(const_cast<Date*>(d))));
}

void SUI::DateImpl::getDate(int *year, int *month, int *day) {
    QDate::getDate(year,month,day);
}

bool SUI::DateImpl::isNull() const {
    return QDate::isNull();
}

bool SUI::DateImpl::isValid() const {
    return QDate::isValid();
}

int SUI::DateImpl::getMonth() const {
    return QDate::month();
}

bool SUI::DateImpl::setDate(int year, int month, int day) {
    return QDate::setDate(year,month,day);
}

int SUI::DateImpl::toJulianDay() const {
    return QDate::toJulianDay();
}

std::string SUI::DateImpl::toString(const std::string &format) const {
    return QDate::toString(QString::fromStdString(format)).toStdString();
}

std::string SUI::DateImpl::toString(DateTimeEnum::DateFormat format) const {
    return QDate::toString((Qt::DateFormat)format).toStdString();
}

int SUI::DateImpl::getWeekNumber(int *yearNumber) const {
    return QDate::weekNumber(yearNumber);
}

int SUI::DateImpl::getYear() const {
    return QDate::year();
}

bool SUI::DateImpl::operator!=(const boost::shared_ptr<SUI::Date> &d) const {
    return *dynamic_cast<const QDate*>(this) != *boost::dynamic_pointer_cast<QDate>(d);
}

bool SUI::DateImpl::operator<(const boost::shared_ptr<SUI::Date> &d) const {
    return *dynamic_cast<const QDate*>(this) < *boost::dynamic_pointer_cast<QDate>(d);
}

bool SUI::DateImpl::operator<=(const boost::shared_ptr<SUI::Date> &d) const {
    return *dynamic_cast<const QDate*>(this) <= *boost::dynamic_pointer_cast<QDate>(d);
}

bool SUI::DateImpl::operator==(const boost::shared_ptr<SUI::Date> &d) const {
    return *dynamic_cast<const QDate*>(this) == *boost::dynamic_pointer_cast<QDate>(d);
}

bool SUI::DateImpl::operator>(const boost::shared_ptr<SUI::Date> &d) const {
    return *dynamic_cast<const QDate*>(this) > *boost::dynamic_pointer_cast<QDate>(d);
}

bool SUI::DateImpl::operator>=(const boost::shared_ptr<SUI::Date> &d) const {
    return *dynamic_cast<const QDate*>(this) >= *boost::dynamic_pointer_cast<QDate>(d);
}
