//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::LegacyXMLConverter.
// !\description Class implementation file for SUI::LegacyXMLConverter.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUILegacyXMLConverter.h"

#include <QFile>
#include <QRegExp>
#include <QTextStream>
#include <QStringList>
#include <QDir>
#include <boost/foreach.hpp>

#include <FWQxCore/SUIIOException.h>
#include <FWQxCore/SUIObjectType.h>
#include <SUIObjectPropertyTypeEnum.h>
#include <QFileInfo>

#include <iostream>

#define SUI_LEGACY_MAJOR 2

SUI::replacementString SUI::LegacyXMLConverter::createReplacementString(QString oldName, QString newName)
{
    SUI::replacementString repString;
    repString.oldName = oldName;
    repString.newName = newName;
    return repString;
}

const std::vector<SUI::replacementString> SUI::LegacyXMLConverter::getReplacementStrings() {
    std::vector<replacementString> repStrings;
    repStrings.push_back(createReplacementString("ADTGui","SUI"));
    repStrings.push_back(createReplacementString("<adtgui>", "<sui>"));
    repStrings.push_back(createReplacementString("rticWidgetFactoryDemo", "ObjectFactory"));
    repStrings.push_back(createReplacementString("RticWidgetFactoryDemo", "ObjectFactory"));
    repStrings.push_back(createReplacementString("ADTDescription", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::SUIDescription))));
    repStrings.push_back(createReplacementString("ADTVersion", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::SUIVersion))));
    repStrings.push_back(createReplacementString("ADTName", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::SUIName))));
    repStrings.push_back(createReplacementString("rticCoreVersion", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::SUICoreVersion))));
    repStrings.push_back(createReplacementString("rticGUIEditorVersion", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::SUIEditorVersion))));
    repStrings.push_back(createReplacementString("rticWidgetFactory", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::SUIObjectFactory))));
    repStrings.push_back(createReplacementString("ID", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::ID))));
    repStrings.push_back(createReplacementString("X-Pos", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::XPos))));
    repStrings.push_back(createReplacementString("Y-Pos", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::YPos))));
    repStrings.push_back(createReplacementString("Height", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::Height))));
    repStrings.push_back(createReplacementString("Width", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::Width))));
    repStrings.push_back(createReplacementString("WidgetType", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::ObjectType))));
    repStrings.push_back(createReplacementString("Visible", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::Visible))));
    repStrings.push_back(createReplacementString("Enable", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::Enable))));
    repStrings.push_back(createReplacementString("Moveable", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::Moveable))));
    repStrings.push_back(createReplacementString("Sizeable", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::Sizeable))));
    repStrings.push_back(createReplacementString("HasBottomButtonBar", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::HasBottomButtonBar))));
    repStrings.push_back(createReplacementString("HasRightButtonBar", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::HasRightButtonBar))));
    repStrings.push_back(createReplacementString("HasStatusBar", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::HasStatusBar))));
    repStrings.push_back(createReplacementString("UserControl", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::UserControl))));
    repStrings.push_back(createReplacementString("ToolTipEnable", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::ToolTipEnable))));
    repStrings.push_back(createReplacementString("ToolTip", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::ToolTip))));
    repStrings.push_back(createReplacementString("Text", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::Text))));
    repStrings.push_back(createReplacementString("CurrentTabPage", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::CurrentTabPage))));
    repStrings.push_back(createReplacementString("StepSize", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::StepSize))));
    repStrings.push_back(createReplacementString("ColumnCount", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::ColumnCount))));
    repStrings.push_back(createReplacementString("RowCount", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::RowCount))));
    repStrings.push_back(createReplacementString("ColumnWidths", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::ColumnWidths))));
    repStrings.push_back(createReplacementString("CellAlignment", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::CellAlignment))));
    repStrings.push_back(createReplacementString("MaxValue", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::MaxValue))));
    repStrings.push_back(createReplacementString("MinValue", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::MinValue))));
    repStrings.push_back(createReplacementString("Color", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::Color))));
    repStrings.push_back(createReplacementString("BGColor", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::BGColor))));
    repStrings.push_back(createReplacementString("ImageData", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::ImageData))));
    repStrings.push_back(createReplacementString("ImageDataPressed", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::ImageDataPressed))));
    repStrings.push_back(createReplacementString("Precision", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::Precision))));
    repStrings.push_back(createReplacementString("AutoScroll", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::AutoScroll))));
    repStrings.push_back(createReplacementString("ReadOnly", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::ReadOnly))));
    repStrings.push_back(createReplacementString("Alignment", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::Alignment))));
    repStrings.push_back(createReplacementString("Orientation", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::Orientation))));
    repStrings.push_back(createReplacementString("UserControl", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::UserControl))));
    repStrings.push_back(createReplacementString("TabOrder", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::TabOrder))));
    repStrings.push_back(createReplacementString("ControlType", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::ControlType))));
    repStrings.push_back(createReplacementString("ControlState", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::ControlState))));
    repStrings.push_back(createReplacementString("StateList", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::StateList))));
    repStrings.push_back(createReplacementString("ImageList", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::ImageList))));
    repStrings.push_back(createReplacementString("DefaultState", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::DefaultState))));
    repStrings.push_back(createReplacementString("Menu", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::Menu))));
    repStrings.push_back(createReplacementString("MenuItem", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::MenuItem))));
    repStrings.push_back(createReplacementString("HelpFile", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::HelpFile))));
    repStrings.push_back(createReplacementString("Checked", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::Checked))));
    repStrings.push_back(createReplacementString("SortingOrder", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::SortingOrder))));
    repStrings.push_back(createReplacementString("SelectBehaviour", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::SelectBehaviour))));
    repStrings.push_back(createReplacementString("StepsizeToFactor", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::StepsizeToFactor))));
    repStrings.push_back(createReplacementString("RegularExpression", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::RegularExpression))));
    repStrings.push_back(createReplacementString("RegExpTip", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::RegExpTip))));
    repStrings.push_back(createReplacementString("ScrollBars", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::ScrollBars))));
    repStrings.push_back(createReplacementString("FilterString", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::FilterString))));
    repStrings.push_back(createReplacementString("FontSize", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::FontSize))));
    repStrings.push_back(createReplacementString("AutoFitBG", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::AutoFitBG))));
    repStrings.push_back(createReplacementString("ZoomStyle", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::ZoomStyle))));
    repStrings.push_back(createReplacementString("ScrollZoom", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::ScrollZoom))));
    repStrings.push_back(createReplacementString("Bold", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::Bold))));
    repStrings.push_back(createReplacementString("ListViewMode", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::ListViewMode))));
    repStrings.push_back(createReplacementString("BorderWidth", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::BorderWidth))));
    repStrings.push_back(createReplacementString("BorderOn", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::BorderOn))));
    repStrings.push_back(createReplacementString("Percentage", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::Percentage))));
    repStrings.push_back(createReplacementString("DisableHeader", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::DisableHeader))));
    repStrings.push_back(createReplacementString("MultipleRowSelection", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::MultipleRowSelection))));
    repStrings.push_back(createReplacementString("PropScientific", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::PropScientific))));
    repStrings.push_back(createReplacementString("Hover", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::Hover))));
    repStrings.push_back(createReplacementString("HeadersOn", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::HeadersOn))));
    repStrings.push_back(createReplacementString("HorizonHeaderTags", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::HorizontalHeaderTags))));
    repStrings.push_back(createReplacementString("VerticalHeaderTags", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::VerticalHeaderTags))));
    repStrings.push_back(createReplacementString("Zoom", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::Zoom))));
    repStrings.push_back(createReplacementString("xAxisScale", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::xAxisScale))));
    repStrings.push_back(createReplacementString("SvgImage", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::SvgImage))));
    repStrings.push_back(createReplacementString("SvgFilename", QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::SvgFilename))));

    repStrings.push_back(createReplacementString("RticUserControl", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::UserControl))));
    repStrings.push_back(createReplacementString("RticTabWidget", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::TabWidget))));
    repStrings.push_back(createReplacementString("RticTabPage", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::TabPage))));
    repStrings.push_back(createReplacementString("RticLabel", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::Label))));
    repStrings.push_back(createReplacementString("RticButton", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::Button))));
    repStrings.push_back(createReplacementString("RticCheckBox", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::CheckBox))));
    repStrings.push_back(createReplacementString("RticGroupBox", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::GroupBox))));
    repStrings.push_back(createReplacementString("RticRadioButton", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::RadioButton))));
    repStrings.push_back(createReplacementString("RticCheckGroupBox", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::CheckGroupBox))));
    repStrings.push_back(createReplacementString("RticLineEdit", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::LineEdit))));
    repStrings.push_back(createReplacementString("RticQuestionMark", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::QuestionMark))));
    repStrings.push_back(createReplacementString("RticColorCrossDrop", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::ColorCrossDrop))));
    repStrings.push_back(createReplacementString("RticColorDrop", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::ColorDrop))));
    repStrings.push_back(createReplacementString("RticCheckMark", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::CheckMark))));
    repStrings.push_back(createReplacementString("RticControlWidget", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::ControlWidget))));
    repStrings.push_back(createReplacementString("RticDoubleSpinBox", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::DoubleSpinBox))));
    repStrings.push_back(createReplacementString("RticScienceSpinBox", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::ScienceSpinBox))));
    repStrings.push_back(createReplacementString("RticLED", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::LEDWidget))));
    repStrings.push_back(createReplacementString("RticDropDown", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::DropDown))));
    repStrings.push_back(createReplacementString("ImageViewerWidget", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::GraphicsView))));
    repStrings.push_back(createReplacementString("RticImageViewerWidget", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::GraphicsView))));
    repStrings.push_back(createReplacementString("RticImageViewer", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::GraphicsView))));
    repStrings.push_back(createReplacementString("RticImage", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::ImageWidget))));
    repStrings.push_back(createReplacementString("RticListView", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::ListView))));
    repStrings.push_back(createReplacementString("RticPlotWidget", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::PlotWidget))));
    repStrings.push_back(createReplacementString("RticProgressBar", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::ProgressBar))));
    repStrings.push_back(createReplacementString("RticTableWidget", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::TableWidget))));
    repStrings.push_back(createReplacementString("RticTableWidgetItem", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::TableWidgetItem))));
    repStrings.push_back(createReplacementString("RticTextArea", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::TextArea))));
    repStrings.push_back(createReplacementString("RticSpinBox", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::SpinBox))));
    repStrings.push_back(createReplacementString("RticSplitter", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::Splitter))));
    repStrings.push_back(createReplacementString("RticStateWidget", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::StateWidget))));
    repStrings.push_back(createReplacementString("RticBusyIndicator", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::BusyIndicator))));
    repStrings.push_back(createReplacementString("RticTreeView", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::TreeView))));
    repStrings.push_back(createReplacementString("RticTreeItem", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::TreeViewItem))));
    repStrings.push_back(createReplacementString("RticSvgWidget", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::SvgWidget))));
    repStrings.push_back(createReplacementString("RticButtonBar", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::ButtonBar))));
    repStrings.push_back(createReplacementString("RticMessageBox", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::MessageBox))));
    repStrings.push_back(createReplacementString("RticFileBrowser", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::FileDialog))));
    repStrings.push_back(createReplacementString("RticGraphicsPixmap", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::GraphicsPixmapItem))));
    repStrings.push_back(createReplacementString("RticGraphicsText", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::GraphicsTextItem))));
    repStrings.push_back(createReplacementString("RticGraphicsRect", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::GraphicsRectItem))));
    repStrings.push_back(createReplacementString("RticGraphicsLine", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::GraphicsEllipseItem))));
    repStrings.push_back(createReplacementString("RticGraphicsCrossHair", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::GraphicsCrosshairItem))));
    repStrings.push_back(createReplacementString("RticWidgetPage", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::WidgetPage))));
    repStrings.push_back(createReplacementString("RticLineWidget", QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::LineWidget))));

    return repStrings;
}

void SUI::LegacyXMLConverter::convertLegacyXmlFile(const QString &fileName, const QString &newFileName) {

    // read the old file
    QString fileContent = readFile(fileName);

    // do the conversion
    fileContent = doConversion(fileContent);

    // update the version
    fileContent = updateVersionInfoPrivate(fileContent);
    
    // Do the same for user controls
    QStringList fileContentList = fileContent.split("\n");
    BOOST_FOREACH (QString line, fileContentList) {
        if (line.contains("<property Include-") == false) continue;
        std::cout << "Converting user controls ..." << std::endl;

        const QString includeFileName = line.split("=").at(1).split("\"").at(1);
        QString userControlFileName = includeFileName;

        if (fileName == newFileName) { // if the input file is the same as the output file, overwrite
            userControlFileName = QFileInfo(newFileName).absolutePath().append(QDir::separator()).append(userControlFileName);
            std::cout << "Overwriting user control: " << userControlFileName.toStdString() << std::endl;
            convertLegacyXmlFile(userControlFileName,userControlFileName);
        }
        else {
            // else create a filename with the new filename
            QString s1 = QFileInfo(newFileName).absolutePath(); // the path
            QString s2 = includeFileName.mid(0,includeFileName.length()-4); // the filename without extension .xml
            QString s3 = QFileInfo(newFileName).fileName().mid(0,QFileInfo(newFileName).fileName().length()-4); // the appended part without extension .xml
            QString newUserControlFileName = QString("%1/%2-%3.xml").arg(s1,s2,s3);

            //create a temp usercontrol
            QFile uctFile(newUserControlFileName);
            uctFile.open(QIODevice::WriteOnly | QIODevice::Text);
            if(!uctFile.isOpen()) {
                throw new SUI::IOException(std::string("Unable to open file ").append(newUserControlFileName.toStdString()));
            }
            uctFile.close();

            // do the conversion
            std::cout << "Making temp user control from: " << userControlFileName.toStdString() << " to " << newUserControlFileName.toStdString() << std::endl;
            convertLegacyXmlFile(userControlFileName,newUserControlFileName);

            // and replace the old filename with the new one in the parent xml
            fileContent.replace(includeFileName,QFileInfo(newUserControlFileName).fileName());
        }
    }
    
    // write to the new file
    writeFile(newFileName,fileContent);
}

bool SUI::LegacyXMLConverter::isLegacy(const QString &xmlFileName) {
    SUI::VersionInfo version = getVersionInfo(xmlFileName);
    //MajorVersion less than 2.0 are legacy files
    return (version.majorVersion() < SUI_LEGACY_MAJOR);
}

void SUI::LegacyXMLConverter::updateVersionInfo(const QString &xmlFileName) {
    QString fileContent = readFile(xmlFileName);
    writeFile(xmlFileName,updateVersionInfoPrivate(fileContent));
}

SUI::VersionInfo SUI::LegacyXMLConverter::getVersionInfo(const QString &xmlFileName) {
    int major = 0;
    int minor = 0;

    QString fileContent = readFile(xmlFileName);

    QRegExp regExp("((ADTVersion|SUIVersion)+(?::(ADTVersion|SUIVersion)+)?)=(\"[^\"]+\"|'[^\']+')");
    if(regExp.indexIn(fileContent)!= -1){
        QRegExp reg("([0-9]).([0-9])");
        if(reg.indexIn(regExp.cap(0)) != -1) {
            if(reg.captureCount() == 2){
                major = reg.cap(1).toInt();
                minor = reg.cap(2).toInt();
            }
        }
    }
    return VersionInfo(major, minor, 0);
}

QString SUI::LegacyXMLConverter::updateVersionInfoPrivate(QString &fileContent) {
    QStringList fileContentList = fileContent.split("\n");
    QString str("    <property %1=\"%2\"/>");
    QString version = str.arg("SUIVersion").arg(QString("%1.%2").arg(QString::number(SUI_MAJOR),QString::number(SUI_MINOR)));
    QString coreVersion = str.arg("SUICoreVersion").arg(QString("%1.%2.%3").arg(QString::number(SUI_MAJOR),QString::number(SUI_MINOR),QString::number(SUI_REVISION)));
    QString editorVersion = str.arg("SUIEditorVersion").arg(QString("%1.%2.%3").arg(QString::number(SUI_EDITOR_MAJOR),QString::number(SUI_EDITOR_MINOR),QString::number(SUI_REVISION)));

    BOOST_FOREACH (const QString &line, fileContentList) {
        if (line.contains(QRegExp("<property (SUIVersion|SUICoreVersion|SUIEditorVersion)=")) == true) {
            fileContentList.removeOne(line);
        }
    }

    for(int i = 0,t = fileContentList.size(); i < t; i++) {
        if (!fileContentList.at(i).startsWith("<SUI>") && !fileContentList.at(i).startsWith("<UserControl>")) continue;
        fileContentList.insert(i+1,version);
        fileContentList.insert(i+2,coreVersion);
        fileContentList.insert(i+3,editorVersion);
        break;
    }
    return fileContentList.join("\n");
}

QString SUI::LegacyXMLConverter::doConversion(QString content) {
    const std::vector<SUI::replacementString> oldNewMap = getReplacementStrings();

    for(std::vector<SUI::replacementString>::const_iterator it = oldNewMap.begin(); it != oldNewMap.end(); ++it) {
        content = content.replace((*it).oldName,(*it).newName);
    }

    return content;
}


QString SUI::LegacyXMLConverter::readFile(const QString &fileName) {
    QString fileContent;
    if (!QFileInfo(fileName).exists()) {
        throw new SUI::IOException(std::string(" Unable to open file ").append(fileName.toStdString()).append(". File does not exist."));
    }
    else {
        QFile file(fileName);
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            throw new SUI::IOException(std::string(" Unable to open file ").append(fileName.toStdString()).append(" for reading. Error: ").append(file.errorString().toStdString()));
        }
        QTextStream fileStream(&file);
        fileContent = fileStream.readAll();
        file.close();
    }

    return fileContent;
}

void SUI::LegacyXMLConverter::writeFile(const QString &fileName, const QString &fileContent) {
    if (!QFileInfo(fileName).exists()) {
        throw new SUI::IOException(std::string(" Unable to open file ").append(fileName.toStdString()).append(". File does not exist."));
    }
    else {
        QFile file(fileName);
        if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
            throw new SUI::IOException(std::string(" Unable to open file ").append(fileName.toStdString()).append(" for writing. Error: ").append(file.errorString().toStdString()));
        }
        QTextStream fileStream(&file);
        fileStream << fileContent << endl;
        file.close();
    }
}
