//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::ObjectPropertyTypeEnum.
// !\description Class implementation file for SUI::ObjectPropertyTypeEnum.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIObjectPropertyTypeEnum.h"

namespace SUI {

using std::cout;
using std::string;
using std::map;
using std::pair;

const map<ObjectPropertyTypeEnum::Type,const string> ObjectPropertyTypeEnum::typeStringMap = {
    {ObjectPropertyTypeEnum::ID,"ID"},
    {ObjectPropertyTypeEnum::XPos,"XPos"},
    {ObjectPropertyTypeEnum::YPos,"YPos"},
    {ObjectPropertyTypeEnum::Height,"Height"},
    {ObjectPropertyTypeEnum::Width,"Width"},
    {ObjectPropertyTypeEnum::ObjectType,"ObjectType"},
    {ObjectPropertyTypeEnum::Text,"Text"},
    {ObjectPropertyTypeEnum::Visible,"Visible"},
    {ObjectPropertyTypeEnum::Enable,"Enable"},
    {ObjectPropertyTypeEnum::Moveable,"Moveable"},
    {ObjectPropertyTypeEnum::Sizeable,"Sizeable"},
    {ObjectPropertyTypeEnum::CurrentTabPage,"CurrentTabPage"},
    {ObjectPropertyTypeEnum::SUIVersion,"SUIVersion"},
    {ObjectPropertyTypeEnum::SUIName,"SUIName"},
    {ObjectPropertyTypeEnum::SUIDescription,"SUIDescription"},
    {ObjectPropertyTypeEnum::HasBottomButtonBar,"HasBottomButtonBar"},
    {ObjectPropertyTypeEnum::HasRightButtonBar,"HasRightButtonBar"},
    {ObjectPropertyTypeEnum::HasStatusBar,"HasStatusBar"},
    {ObjectPropertyTypeEnum::StepSize,"StepSize"},
    {ObjectPropertyTypeEnum::ColumnCount,"ColumnCount"},
    {ObjectPropertyTypeEnum::RowCount,"RowCount"},
    {ObjectPropertyTypeEnum::ColumnWidths,"ColumnWidths"},
    {ObjectPropertyTypeEnum::CellAlignment,"CellAlignment"},
    {ObjectPropertyTypeEnum::MaxValue,"MaxValue"},
    {ObjectPropertyTypeEnum::MinValue,"MinValue"},
    {ObjectPropertyTypeEnum::Color,"Color"},
    {ObjectPropertyTypeEnum::BGColor,"BGColor"},
    {ObjectPropertyTypeEnum::ImageData,"ImageData"},
    {ObjectPropertyTypeEnum::ImageDataPressed,"ImageDataPressed"},
    {ObjectPropertyTypeEnum::Precision,"Precision"},
    {ObjectPropertyTypeEnum::AutoScroll,"AutoScroll"},
    {ObjectPropertyTypeEnum::ReadOnly,"ReadOnly"},
    {ObjectPropertyTypeEnum::Alignment,"Alignment"},
    {ObjectPropertyTypeEnum::Orientation,"Orientation"},
    {ObjectPropertyTypeEnum::UserControl,"UserControl"},
    {ObjectPropertyTypeEnum::TabOrder,"TabOrder"},
    {ObjectPropertyTypeEnum::ControlType,"ControlType"},
    {ObjectPropertyTypeEnum::ControlState,"ControlState"},
    {ObjectPropertyTypeEnum::StateList,"StateList"},
    {ObjectPropertyTypeEnum::ImageList,"ImageList"},
    {ObjectPropertyTypeEnum::DefaultState,"DefaultState"},
    {ObjectPropertyTypeEnum::Menu,"Menu"},
    {ObjectPropertyTypeEnum::MenuItem,"MenuItem"},
    {ObjectPropertyTypeEnum::HelpFile,"HelpFile"},
    {ObjectPropertyTypeEnum::Checked,"Checked"},
    {ObjectPropertyTypeEnum::SortingOrder,"SortingOrder"},
    {ObjectPropertyTypeEnum::SelectBehaviour,"SelectBehaviour"},
    {ObjectPropertyTypeEnum::StepsizeToFactor,"StepsizeToFactor"},
    {ObjectPropertyTypeEnum::RegularExpression,"RegularExpression"},
    {ObjectPropertyTypeEnum::RegExpTip,"RegExpTip"},
    {ObjectPropertyTypeEnum::ScrollBars,"ScrollBars"},
    {ObjectPropertyTypeEnum::FilterString,"FilterString"},
    {ObjectPropertyTypeEnum::FontSize,"FontSize"},
    {ObjectPropertyTypeEnum::AutoFitBG,"AutoFitBG"},
    {ObjectPropertyTypeEnum::ZoomStyle,"ZoomStyle"},
    {ObjectPropertyTypeEnum::ScrollZoom,"ScrollZoom"},
    {ObjectPropertyTypeEnum::Bold,"Bold"},
    {ObjectPropertyTypeEnum::ListViewMode,"ListViewMode"},
    {ObjectPropertyTypeEnum::BorderWidth,"BorderWidth"},
    {ObjectPropertyTypeEnum::BorderOn,"BorderOn"},
    {ObjectPropertyTypeEnum::Percentage,"Percentage"},
    {ObjectPropertyTypeEnum::ToolTipEnable,"ToolTipEnable"},
    {ObjectPropertyTypeEnum::ToolTip,"ToolTip"},
    {ObjectPropertyTypeEnum::DisableHeader,"DisableHeader"},
    {ObjectPropertyTypeEnum::MultipleRowSelection,"MultipleRowSelection"},
    {ObjectPropertyTypeEnum::PropScientific,"PropScientific"},
    {ObjectPropertyTypeEnum::Hover,"Hover"},
    {ObjectPropertyTypeEnum::HeadersOn,"HeadersOn"},
    {ObjectPropertyTypeEnum::HorizontalHeaderTags,"HorizonHeaderTags"},
    {ObjectPropertyTypeEnum::VerticalHeaderTags,"VerticalHeaderTags"},
    {ObjectPropertyTypeEnum::Zoom,"Zoom"},
    {ObjectPropertyTypeEnum::xAxisScale,"xAxisScale"},
    {ObjectPropertyTypeEnum::SvgImage,"SvgImage"},
    {ObjectPropertyTypeEnum::SvgFilename, "SvgFilename"},
    {ObjectPropertyTypeEnum::SUICoreVersion, "SUICoreVersion"},
    {ObjectPropertyTypeEnum::SUIEditorVersion, "SUIEditorVersion"},
    {ObjectPropertyTypeEnum::SUIObjectFactory, "SUIObjectFactory"},
    {ObjectPropertyTypeEnum::SUIStyleSheet, "SUIStylesheet"},
    {ObjectPropertyTypeEnum::CellName, "CellName"},
    {ObjectPropertyTypeEnum::FileName, "FileName"},
    {ObjectPropertyTypeEnum::StyleSheetClass, "StyleSheetClass"},
    {ObjectPropertyTypeEnum::BusyIndicatorImage, "BusyIndicatorImage"},
    {ObjectPropertyTypeEnum::HoverBGColor, "HoverBGColor"},
    {ObjectPropertyTypeEnum::PlaceHolderText,"PlaceHolderText"},
    {ObjectPropertyTypeEnum::Url, "Url"},
    {ObjectPropertyTypeEnum::Html, "Html"},
    {ObjectPropertyTypeEnum::ZoomFactor, "ZoomFactor"},
    {ObjectPropertyTypeEnum::RowHeights, "RowHeights"},
    {ObjectPropertyTypeEnum::Namespace, "Namespace"},
    {ObjectPropertyTypeEnum::ClassName, "ClassName"},
    {ObjectPropertyTypeEnum::Invalid, "Invalid"}
};



const map<const string,ObjectPropertyTypeEnum::Type> ObjectPropertyTypeEnum::stringTypeMap = ObjectPropertyTypeEnum::createStringTypeMap();

string ObjectPropertyTypeEnum::toString(ObjectPropertyTypeEnum::Type type) {
    map<Type,const string>::const_iterator it = typeStringMap.find(type);
    return it != typeStringMap.end() ? it->second : "Invalid";
}

ObjectPropertyTypeEnum::Type ObjectPropertyTypeEnum::fromString(const string &type) {
    map<const string, Type>::const_iterator it = stringTypeMap.find(type);
    return it != stringTypeMap.end() ? it->second : ObjectPropertyTypeEnum::Invalid;
}

const map<const string, ObjectPropertyTypeEnum::Type> ObjectPropertyTypeEnum::createStringTypeMap() {
    map<const string, Type> newMap;
    for (map<Type,const string>::const_iterator it = typeStringMap.begin(); it != typeStringMap.end(); ++it) {
        newMap.insert(pair<const string, Type>(it->second,it->first));
    }
    return newMap;
}

}
