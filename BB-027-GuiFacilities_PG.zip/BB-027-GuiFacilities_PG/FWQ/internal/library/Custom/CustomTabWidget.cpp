//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for CustomTabWidget.
// !\description Class implementation file for CustomTabWidget.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "CustomTabWidget.h"

CustomTabWidget::CustomTabWidget(QWidget *parent) :
    QTabWidget(parent)
{
    tabBar()->setExpanding(false);
    setAttribute(Qt::WA_TranslucentBackground);    
}

QTabBar *CustomTabWidget::getTabBar() {
    return tabBar();
}

int CustomTabWidget::getTabIndex(const QPoint &event) {
    return tabBar()->tabAt(event);
}
