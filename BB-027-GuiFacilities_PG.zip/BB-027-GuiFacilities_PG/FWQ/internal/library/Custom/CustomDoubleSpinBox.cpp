//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for CustomDoubleSpinBox.
// !\description Class implementation file for CustomDoubleSpinBox.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include <QDebug>
#include <math.h>
#include "CustomDoubleSpinBox.h"

CustomDoubleSpinBox::CustomDoubleSpinBox(QWidget *parent) :
    QDoubleSpinBox(parent),
    mValueIsFactor(false)
{
}

/*****************************************************************************\
 *  FUNCTION    :   stepBy
 *  PARAMETERS  :   int steps
 *  RETURN      :   void
 *
 *  This is a virtual function from QDoubleSpinBox. It is overridden because of
 *  if mValueIsFactor is set to true, the stepsize id used as a factor to
 *  multiply the current value with.
\*****************************************************************************/
void CustomDoubleSpinBox::stepBy(int steps)
{
    if (mValueIsFactor)
    {
        int     dDecimals = QDoubleSpinBox::decimals();
        double  dCurVal = QDoubleSpinBox::value();
        double  dNewVal;
        double  dLimit = pow(10, -dDecimals);

        if (steps > 0)
        {
            if (dCurVal >= dLimit)
            {
                dNewVal = dCurVal * (double)QDoubleSpinBox::singleStep();
            }
            else if (dCurVal < -dLimit)
            {
                dNewVal = dCurVal / (double)QDoubleSpinBox::singleStep();
            }
            else if (dCurVal == 0.00000)
            {
                dNewVal = dLimit;
            }
            else
            {
                dNewVal = 0.0;
            }
        }
        else
        {
            if (dCurVal > dLimit)
            {
                dNewVal = dCurVal / (double)QDoubleSpinBox::singleStep();
            }
            else if (dCurVal <= -dLimit)
            {
                dNewVal = dCurVal * (double)QDoubleSpinBox::singleStep();
            }
            else if (dCurVal == 0.00000)
            {
                dNewVal = -dLimit;
            }
            else
            {
                dNewVal = 0.0;
            }
        }
        QDoubleSpinBox::setValue(dNewVal);
    }
    else
    {
        QDoubleSpinBox::stepBy(steps);
    }
}

void CustomDoubleSpinBox::setStepSizeValueToFactor(const bool on) { mValueIsFactor = on; }
