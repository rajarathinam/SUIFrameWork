//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for CustomGraphicsSvgItem.
// !\description Class implementation file for CustomGraphicsSvgItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "CustomGraphicsSvgItem.h"

#include <QTextStream>
#include <QFile>
#include <QSvgRenderer>
#include <QDir>
#include <QGraphicsSceneMouseEvent>
#include <boost/foreach.hpp>

#include "FWQxCore/SUIXmlException.h"
#include "FWQxCore/SUIIOException.h"
#include "FWQxCore/SUIResourcePath.h"

CustomGraphicsSvgItem::CustomGraphicsSvgItem(QGraphicsItem *parent):
    QGraphicsSvgItem(parent),
    mRenderer(new QSvgRenderer(QLatin1String(":/image/SvgImage.svg"))),
    melidelength(0)
{
    mScale = QSizeF(1,1);
    QGraphicsSvgItem::setSharedRenderer(mRenderer);
}

void CustomGraphicsSvgItem::setImage(const std::string &image) {
    QFile svgFile(QString::fromStdString(SUI::ResourcePath::getResourceFile(image)));
    if(!svgFile.open(QFile::ReadOnly | QFile::Text)) {
       throw new SUI::IOException(std::string("Unable to open file ").append(image).append(" for Reading."));
    }
    if(mSvgDomDocument.setContent(&svgFile, true) == false) {
       throw new SUI::XmlException(std::string("Failed to parse SVG File"));
    }
    svgFile.close();
    if(mRenderer != NULL) mRenderer->deleteLater();
    mRenderer = new QSvgRenderer(QString::fromStdString(image));
    mRenderer->load(QString::fromStdString(image));
    QGraphicsSvgItem::setSharedRenderer(mRenderer);
    double widthDef = static_cast<double>(mRenderer->defaultSize().width());
    double widthView = static_cast<double>(mRenderer->viewBoxF().width());
    double heightDef = static_cast<double>(mRenderer->defaultSize().height());
    double heightView = static_cast<double>(mRenderer->viewBoxF().height());
    qreal x = static_cast<qreal>(widthDef/widthView);
    qreal y = static_cast<qreal>(heightDef/heightView);
    mScale = QSizeF(x, y);
    QGraphicsSvgItem::update();
    parseSvgImage();
    mapSvgTextElements();
}

void CustomGraphicsSvgItem::setElementId(const std::string &id){
    QGraphicsSvgItem::setElementId(QString::fromStdString(id));
}

std::string CustomGraphicsSvgItem::elementId(){
    return QGraphicsSvgItem::elementId().toStdString();
}

std::list<std::string> CustomGraphicsSvgItem::getElementIdList() {
    std::list<std::string>  itemList;
    BOOST_FOREACH (QString item, mDomNodeForElement.keys()) {
        itemList.push_back(item.toStdString());
    }
    return itemList;
}

void CustomGraphicsSvgItem::setElementColor(const std::string &id, const SUI::ColorEnum::Color color) {
    if(!QGraphicsSvgItem::renderer()->elementExists(QString::fromStdString(id))) return;
    QDomNode node = mDomNodeForElement.value(QString::fromStdString(id));
    QDomElement element = node.toElement();

    if(element.hasAttribute("fill") == true ) {
        element.setAttribute("fill", QString::fromStdString(SUI::ColorEnum::toString(color)));
    }
    else if(element.hasAttribute("class") && element.isText()) {
        element.setAttribute("fill",QString::fromStdString(SUI::ColorEnum::toString(color)));
    }
    else if(element.hasAttribute("style")) {
        QString value = element.attribute("style");

        QStringList styleList = value.split(";");
        QStringList newStyleList;
        BOOST_FOREACH (QString style, styleList)
        {
            QStringList propertyVal = style.split(":");
            QString prop = propertyVal.first().trimmed();
            QString newVal = propertyVal.at(1).trimmed();
            if(prop == "fill") {
                newVal = QString::fromStdString(SUI::ColorEnum::toString(color));
            }
            newStyleList.append(prop + ":" + newVal);
        }
        element.setAttribute("style", newStyleList.join(";"));
    }
    else if(element.hasChildNodes()) {
        for(QDomNode n = element.firstChild(); !n.isNull(); n = n.nextSibling())
        {
            QDomElement childElement = n.toElement();
            if(childElement.hasAttribute("fill")) {
                childElement.setAttribute("fill", QString::fromStdString(SUI::ColorEnum::toString(color)));
            }
            else if(childElement.hasAttribute("class")) {
                childElement.setAttribute("fill", QString::fromStdString(SUI::ColorEnum::toString(color)));
            }
            else if(childElement.hasAttribute("style")) {
                QString value = childElement.attribute("style");

                QStringList styleList = value.split(";");
                QStringList newStyleList;
                BOOST_FOREACH (QString style, styleList)
                {
                    QStringList propertyVal = style.split(":");
                    QString prop = propertyVal.first().trimmed();
                    QString newVal = propertyVal.at(1).trimmed();
                    if(prop == "fill") newVal = QString::fromStdString(SUI::ColorEnum::toString(color));
                    newStyleList.append(prop + ":" + newVal);
                }
                childElement.setAttribute("style", newStyleList.join(";"));
            }
        }
    }
    mRenderer->load(mSvgDomDocument.toByteArray());
}

void CustomGraphicsSvgItem::setElementBorderColor(const std::string &id, const SUI::ColorEnum::Color borderColor) {
    if(!QGraphicsSvgItem::renderer()->elementExists(QString::fromStdString(id))) return;
    QDomNode node = mDomNodeForElement.value(QString::fromStdString(id));
    QDomElement element = node.toElement();
    if(element.hasAttribute("stroke")) {
        element.setAttribute("stroke", QString::fromStdString(SUI::ColorEnum::toString(borderColor)));
    }
    else if(element.hasAttribute("class")) {
        element.setAttribute("stroke",QString::fromStdString(SUI::ColorEnum::toString(borderColor)));
    }
    else if(element.hasAttribute("style")) {
        QString value = element.attribute("style");

        QStringList styleList = value.split(";");
        QStringList newStyleList;
        BOOST_FOREACH (QString style, styleList) {
            QStringList propertyVal = style.split(":");
            QString prop = propertyVal.first().trimmed();
            QString newVal = propertyVal.at(1).trimmed();
            if(prop == "stroke") {
                newVal = QString::fromStdString(SUI::ColorEnum::toString(borderColor));
            }
            newStyleList.append(prop + ":" + newVal);
        }
        element.setAttribute("style", newStyleList.join(";"));
    }
    else if(element.hasChildNodes()) {
        for(QDomNode n = element.firstChild(); !n.isNull(); n = n.nextSibling())
        {
            QDomElement childElement = n.toElement();
            if(childElement.hasAttribute("stroke")) {
                childElement.setAttribute("stroke",QString::fromStdString(SUI::ColorEnum::toString(borderColor)));
            }
            else if(childElement.hasAttribute("class")) {
                childElement.setAttribute("stroke", QString::fromStdString(SUI::ColorEnum::toString(borderColor)));
            }
            else if(childElement.hasAttribute("style")) {
                QString value = childElement.attribute("style");

                QStringList styleList = value.split(";");
                QStringList newStyleList;
                BOOST_FOREACH (QString style, styleList)
                {
                    QStringList propertyVal = style.split(":");
                    QString prop = propertyVal.first().trimmed();
                    QString newVal = propertyVal.at(1).trimmed();
                    if(prop == "stroke") {
                        newVal = QString::fromStdString(SUI::ColorEnum::toString(borderColor));
                    }
                    newStyleList.append(prop + ":" + newVal);
                }
                childElement.setAttribute("style", newStyleList.join(";"));
            }
        }
    }
    mRenderer->load(mSvgDomDocument.toByteArray());
}

void CustomGraphicsSvgItem::setElementText(const std::string &id, const std::string &text) {
    if(!QGraphicsSvgItem::renderer()->elementExists(QString::fromStdString(id))) return;

    mMapIdTexts.remove(QString::fromStdString(id));
    mMapIdTexts.insert(QString::fromStdString(id), QString::fromStdString(text));

    QString qtext = QString::fromStdString(text);
    if(qtext.size() > melidelength){
       qtext.right(melidelength).append(QChar(0x2026)) ;
    }

    QDomNode node = mDomNodeForElement.value(QString::fromStdString(id));
    QDomNodeList elements = node.toElement().elementsByTagName("text");
    if(elements.size() == 0) {
        QDomElement textElement = mSvgDomDocument.createElement("text");
        QDomText domtext = mSvgDomDocument.createTextNode(qtext);

        node.toElement().appendChild(textElement);
        textElement.appendChild(domtext);
    }
    else {
        for (int i = 0; i < elements.item(0).childNodes().count(); i++)
        {
            if(elements.item(0).childNodes().item(i).isText()) {
                QDomText t = elements.item(0).childNodes().item(i).toText();
                t.setData(qtext);
                break;
            }
        }
    }
    mRenderer->load(mSvgDomDocument.toByteArray());
}

std::string CustomGraphicsSvgItem::getElementText(const std::string &idvalue) {
    if(!QGraphicsSvgItem::renderer()->elementExists(QString::fromStdString(idvalue))) return "";

    std::string text = mMapIdTexts.value(QString::fromStdString(idvalue)).toStdString();
    return text.empty() ? "": text;
}

void CustomGraphicsSvgItem::elideText(int maxwidth) {
    if(maxwidth > 0){
        melidelength = maxwidth;
        BOOST_FOREACH (QString id, mMapIdTexts.keys()) {
            QString text = mMapIdTexts.value(id);
            if(!text.isEmpty() && text.length()>melidelength){
                QDomNode node = mDomNodeForElement.value(id);
                QDomNodeList elements = node.toElement().elementsByTagName("text");
                for (int i = 0; i < elements.item(0).childNodes().count(); i++)
                {
                    if(elements.item(0).childNodes().item(i).isText()) {
                        QDomText t = elements.item(0).childNodes().item(i).toText();
                        t.setData(text.left(melidelength).append(QChar(0x2026)));
                        break;
                    }
                }
            }
        }
        mRenderer->load(mSvgDomDocument.toByteArray());
    }
}

void CustomGraphicsSvgItem::resetElideText() {
    melidelength = 0;
    BOOST_FOREACH (QString id, mMapIdTexts.keys()) {
        QString text = mMapIdTexts.value(id);
        if(!text.isEmpty() && text.length()>melidelength){
            QDomNode node = mDomNodeForElement.value(id);
            QDomNodeList elements = node.toElement().elementsByTagName("text");
            for (int i = 0; i < elements.item(0).childNodes().count(); i++)
            {
                if(elements.item(0).childNodes().item(i).isText()) {
                    QDomText t = elements.item(0).childNodes().item(i).toText();
                    t.setData(mMapIdTexts.value(id));

                    break;
                }
            }
        }
    }
    mRenderer->load(mSvgDomDocument.toByteArray());
}

void CustomGraphicsSvgItem::setElementBorderWidth(const std::string &id, const int borderWidth) {
    if(!QGraphicsSvgItem::renderer()->elementExists(QString::fromStdString(id))) return;

    QDomNode node = mDomNodeForElement.value(QString::fromStdString(id));
    QDomElement element = node.toElement();
    if(element.tagName() != "text"){
        if(element.hasAttribute("stroke-width") == true) {
            element.setAttribute("stroke-width", borderWidth);
        }
        else if(element.hasAttribute("class") == true) {
            element.setAttribute("stroke-width", borderWidth);
        }
    }
    if(element.hasChildNodes()) {
        for(QDomNode n = element.firstChild(); !n.isNull(); n = n.nextSibling())
        {
            QDomElement childElement = n.toElement();
            if(childElement.tagName() != "text"){
                if(childElement.hasAttribute("stroke-width") == true) {
                    childElement.setAttribute("stroke-width",borderWidth);
                }
                else if(childElement.hasAttribute("class") == true) {
                    childElement.setAttribute("stroke-width", borderWidth);
                }
            }
        }
    }
    mRenderer->load(mSvgDomDocument.toByteArray());
}

void CustomGraphicsSvgItem::setElementTextColor(const std::string &id, const SUI::ColorEnum::Color color) {
    if( QGraphicsSvgItem::renderer()->elementExists(QString::fromStdString(id)) == false ) return;
    QDomNode node = mDomNodeForElement.value(QString::fromStdString(id));
    QDomNodeList elements = node.toElement().elementsByTagName("text");
    QDomElement element = elements.item(0).toElement();

    if(elements.size() == 0) {
        QDomElement textElement = mSvgDomDocument.createElement("text");
        QDomAttr textColorAttr = mSvgDomDocument.createAttribute("fill");

        node.toElement().appendChild(textElement);
        textElement.appendChild(textColorAttr);
    }
    else if(element.hasAttribute("fill")){
        element.setAttribute("fill", QString::fromStdString(SUI::ColorEnum::toString(color)));
    }
    else if(element.hasAttribute("class")){
        element.setAttribute("fill", QString::fromStdString(SUI::ColorEnum::toString(color)));
    }
    else {
        for (int i = 0; i < elements.item(0).childNodes().count(); i++)
        {
            QDomElement childElement = elements.item(0).childNodes().item(i).toElement();
            if(childElement.hasAttribute("fill")) {
                childElement.setAttribute("fill", QString::fromStdString(SUI::ColorEnum::toString(color)));
            }
            else if(childElement.hasAttribute("class")) {
                childElement.setAttribute("fill", QString::fromStdString(SUI::ColorEnum::toString(color)));
            }
        }
    }
    mRenderer->load(mSvgDomDocument.toByteArray());
}

void CustomGraphicsSvgItem::setElementToolTip(const std::string &id, const std::string &tipText) {
    if(!QGraphicsSvgItem::renderer()->elementExists(QString::fromStdString(id))) return;

    QDomNode node = mDomNodeForElement.value(QString::fromStdString(id));
    QDomNodeList elements = node.toElement().elementsByTagName("title");
    if(elements.size() == 0) {
        QDomElement titleElement = mSvgDomDocument.createElement("title");
        QDomText domtext = mSvgDomDocument.createTextNode(QString::fromStdString(tipText));

        node.toElement().appendChild(titleElement);
        titleElement.appendChild(domtext);
    }
    else {
        for (int i = 0; i < elements.item(0).childNodes().count(); i++)
        {
            if(elements.item(0).childNodes().item(i).isText()) {
                QDomText t = elements.item(0).childNodes().item(i).toText();
                t.setData(QString::fromStdString(tipText));

                break;
            }
        }
    }
    mRenderer->load(mSvgDomDocument.toByteArray());
}

std::string CustomGraphicsSvgItem::getElementToolTip(const std::string &idvalue)
{
    if(!QGraphicsSvgItem::renderer()->elementExists(QString::fromStdString(idvalue))) return "";
    QDomNode node = mDomNodeForElement.value(QString::fromStdString(idvalue));
    if(node.isNull()) return "";

    QDomText tooltip;
    QDomNodeList elements = node.toElement().elementsByTagName("title");
    if(elements.size() > 0) {
        for (int i = 0; i < elements.item(0).childNodes().count(); i++)
        {
            if(elements.item(0).childNodes().item(i).isText()) {
                tooltip = elements.item(0).childNodes().item(i).toText();
                break;
            }
        }
    }
    return tooltip.data().isEmpty() ? "": tooltip.data().toStdString();
}

void CustomGraphicsSvgItem::mouseDoubleClickEvent(QGraphicsSceneMouseEvent *event) {
    if (event->button() == Qt::LeftButton) {
        for(auto it = mIdToFunctypeMap.begin(); it != mIdToFunctypeMap.end(); it++)
        {
            QTransform transform(QGraphicsSvgItem::renderer()->matrixForElement(QString::fromStdString(it->first)));
            transform.scale(mScale.width(), mScale.height());
            QRectF elementRect = transform.mapRect(QGraphicsSvgItem::renderer()->boundsOnElement(QString::fromStdString(it->first))) ;
            QPolygonF sceneRectf = QGraphicsSvgItem::mapToScene(elementRect);

            if(sceneRectf.boundingRect().contains(event->scenePos().x(),event->scenePos().y())) {
                if(!it->second.empty()) it->second(it->first);
                break;
            }
        }
        event->accept();
    }
}

void CustomGraphicsSvgItem::recursiveParseSvgImage(QDomNode node) {
    while(!node.isNull())
    {
        if(node.isElement()) {
            QDomElement element = node.toElement();
            if(element.hasAttribute("id")) {
                QDomNamedNodeMap attributeMap = node.attributes();
                if(QGraphicsSvgItem::renderer()->elementExists(attributeMap.namedItem("id").nodeValue())) {
                    mDomNodeForElement.insert(attributeMap.namedItem("id").nodeValue(), node);
                }
            }
            if(element.hasChildNodes()) recursiveParseSvgImage(node.firstChild());
        }
        node = node.nextSibling();
    }
}

void CustomGraphicsSvgItem::parseSvgImage() {
    mDomNodeForElement.clear();
    QDomNode node = mSvgDomDocument.documentElement().firstChild();
    while(!node.isNull())
    {
        if(node.isElement()) {
            QDomElement element = node.toElement();
            if(element.hasAttribute("id")) {
                QDomNamedNodeMap attributeMap = node.attributes();
                if(QGraphicsSvgItem::renderer()->elementExists(attributeMap.namedItem("id").nodeValue())) {
                    mDomNodeForElement.insert(attributeMap.namedItem("id").nodeValue(), node);
                }
            }
            if(element.hasChildNodes()) recursiveParseSvgImage(node.firstChild());
        }
        node = node.nextSibling();
    }
}

void CustomGraphicsSvgItem::mapSvgTextElements() {
    BOOST_FOREACH (QString item, mDomNodeForElement.keys()) {
        QDomNode node = mDomNodeForElement.value(item);
        QDomText text;
        QDomNodeList elements = node.toElement().elementsByTagName("text");
        if(elements.size() > 0) {
            for (int i = 0; i < elements.item(0).childNodes().count(); i++)
            {
                if(elements.item(0).childNodes().item(i).isText()) {
                    text = elements.item(0).childNodes().item(i).toText();
                    break;
                }
            }
        }
        mMapIdTexts.insert(item, text.data().isEmpty() ? "": text.data());
    }
}

bool CustomGraphicsSvgItem::sceneEvent(QEvent *event) {
    if (event->type() == QEvent::GraphicsSceneHelp) {
        QGraphicsSceneHelpEvent *sceneEvent = static_cast< QGraphicsSceneHelpEvent*>(event);
        QList<QString> idlist = mDomNodeForElement.keys();
        for (int i = 0; i < idlist.size(); ++i) {
            QTransform transform(QGraphicsSvgItem::renderer()->matrixForElement(idlist.at(i)));
            transform.scale(mScale.width(), mScale.height());
            QRectF elementRect = transform.mapRect(QGraphicsSvgItem::renderer()->boundsOnElement(idlist.at(i))) ;
            QPolygonF sceneRectf = QGraphicsSvgItem::mapToScene(elementRect);
            if(sceneRectf.boundingRect().contains(QGraphicsSvgItem::mapToScene(sceneEvent->scenePos()))) {
                this->setToolTip(QString::fromStdString(this->getElementToolTip(idlist.at(i).toStdString())));
                break;
            }
        }
    }
    return QGraphicsItem::sceneEvent(event);
}

void CustomGraphicsSvgItem::setPosition(double x, double y) {
    QGraphicsSvgItem::setPos(x, y);
    QGraphicsSvgItem::update();
}

void CustomGraphicsSvgItem::setX(double x) {
    QGraphicsSvgItem::setX(x);
    QGraphicsSvgItem::update();
}

void CustomGraphicsSvgItem::setY(double y) {
    QGraphicsSvgItem::setY(y);
    QGraphicsSvgItem::update();
}

QRectF CustomGraphicsSvgItem::boundingRect() const {
    return QGraphicsSvgItem::boundingRect();
}

void CustomGraphicsSvgItem::setVisible(bool visible) {
    QGraphicsSvgItem::setVisible(visible);
    QGraphicsSvgItem::update();
}

bool CustomGraphicsSvgItem::isVisible() const {
    return QGraphicsSvgItem::isVisible();
}

void CustomGraphicsSvgItem::setElementDoubleClickEvent(const std::string &idvalue, CustomGraphicsSvgItem::function_type func) {
  if(!QGraphicsSvgItem::renderer()->elementExists(QString::fromStdString(idvalue))) return;
  auto it = mIdToFunctypeMap.find(idvalue);
  if(it != mIdToFunctypeMap.end()) mIdToFunctypeMap.erase(it);
  mIdToFunctypeMap.insert(std::pair<std::string, CustomGraphicsSvgItem::function_type>(idvalue, func));
}
