//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for CustomSortFilterProxy.
// !\description Class implementation file for CustomSortFilterProxy.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "CustomSortFilterProxy.h"
#include <boost/foreach.hpp>

namespace SUI {

CustomSortFilterProxy::CustomSortFilterProxy(QObject *parent) :
    QSortFilterProxyModel(parent)
{
    setDynamicSortFilter(true);
}

void CustomSortFilterProxy::setColumnFilterFixedString(int column, const QString &fixedString, Qt::CaseSensitivity caseSensitivity) {
    if (columnPatterns.contains(column)) {
        columnPatterns.remove(column);
    }

    if (fixedString != "") {
        FilterParameters filter;
        filter.caseSensitivity = caseSensitivity;
        filter.filterText = fixedString;
        columnPatterns.insert(column,filter);
    }
    invalidate();
}


bool CustomSortFilterProxy::lessThan(const QModelIndex &left, const QModelIndex &right) const {
    QString leftItem = sourceModel()->data(left).toString();
    QString rightItem = sourceModel()->data(right).toString();
    return leftItem < rightItem;
}

bool CustomSortFilterProxy::filterAcceptsRow(int sourceRow, const QModelIndex &sourceParent) const {
    bool result = (columnPatterns.count() == 0) ? true : false;
    BOOST_FOREACH (qint32 column, columnPatterns.keys()) {
        QModelIndex index = sourceModel()->index(sourceRow,column,sourceParent);
        FilterParameters filter = columnPatterns.value(column);
        if (index.data(Qt::DisplayRole).toString().contains(filter.filterText, filter.caseSensitivity) == true) {
            result = true;
        }
    }
    return result;
}

QVariant CustomSortFilterProxy::headerData(int section, Qt::Orientation orientation, int role) const
{
    if (role != Qt::DisplayRole) return QVariant();
    if (orientation == Qt::Horizontal) return QSortFilterProxyModel::headerData(section, orientation, role);
    return section + 1;
}
}
