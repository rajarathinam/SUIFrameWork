//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for CustomTableItemDelegate.
// !\description Class implementation file for CustomTableItemDelegate.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "CustomTableItemDelegate.h"
#include "FWQxCore/SUIObjectType.h"
#include "CustomTableItemModel.h"
#include "SUIStyleSheet.h"
#include <QPainter>
#include <QTableView>
#include <QStyleOption>

const QString SUI::CustomTableItemDelegate::ADT_TABLEHOVER_COLOR="#becbde";
const QString SUI::CustomTableItemDelegate::ONEGUI_TABLEHOVER_COLOR="#93accd";
const std::string SUI::CustomTableItemDelegate::ADT_STYLESHEETNAME="ADT";

SUI::CustomTableItemDelegate::CustomTableItemDelegate(QObject *parent) :
    QStyledItemDelegate(parent)
{
    Q_ASSERT(parent);
}

void SUI::CustomTableItemDelegate::setHoverBehavior(const SUI::CustomTableItemDelegate::HoverBehavior behavior) {
    hoverBehavior = behavior;
}

void SUI::CustomTableItemDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const {
    if (!painter->isActive()) return QStyledItemDelegate::paint(painter, option, index);
    QStyleOptionViewItem viewOption(option);
    initStyleOption(&viewOption, index);

    if ((option.state & QStyle::State_MouseOver) == QStyle::State_MouseOver) {
        if ((option.state & QStyle::State_Selected) == QStyle::State_Selected) {
            viewOption.state &= ~QStyle::State_MouseOver;
       } else {
            if (hoverBehavior == HoverRows) {
                const QWidget *widget = static_cast<const QStyleOptionViewItemV3 *>(&option)->widget;
                const QTableView *view = qobject_cast<const QTableView *>(widget);
                QColor color;
                color.setNamedColor(SUI::StyleSheet::getInstance()->getStyleSheetName() == SUI::CustomTableItemDelegate::ADT_STYLESHEETNAME ?
                                        CustomTableItemDelegate::ADT_TABLEHOVER_COLOR : CustomTableItemDelegate::ONEGUI_TABLEHOVER_COLOR);
                QBrush brush(color);
                for (int i = 0; i < index.model()->columnCount(); ++i) {
                    QModelIndex idx = index.model()->index(index.row(), i);
                    QStyleOptionViewItem opt(viewOption);
                    initStyleOption(&opt, idx);
                    int x = view->columnViewportPosition(idx.column());
                    int y = view->rowViewportPosition(idx.row());
                    int itemWidth = view->columnWidth(idx.column());
                    int itemHeight = view->rowHeight(idx.row());
                    opt.rect = QRect(x, y, itemWidth, itemHeight);
                    painter->fillRect(opt.rect,brush);
                    //Check added to invalidate the boldness of text
                    if(index.column() > i) {
                        QStyledItemDelegate::paint(painter, opt, idx);
                    }
                }
            }
        }
    }

    ObjectType::Type objectType = (ObjectType::Type)index.data(CustomTableItemModel::ObjectTypeRole).toInt();
    if (objectType == ObjectType::TableWidgetItem) {
        bool borderOn = index.data(CustomTableItemModel::BorderOnRole).toBool();
        if (borderOn) {
            painter->save();

            // get the borderwidth
            qreal borderWidth = (qreal) index.data(CustomTableItemModel::BorderWidthRole).toInt();

            // set the pen
            QPen pen = painter->pen();
            pen.setWidth(static_cast<int>(borderWidth));    // TODO? Use setWidthF() ?
            painter->setPen(pen);

            // paint the rounded rect
            QRectF rect(option.rect);
            rect.setWidth(rect.width()-2.0+borderWidth/2.0);
            rect.setHeight(rect.height()-2.0+borderWidth/2.0);
            rect.setX(rect.x()+1.0+borderWidth/4.0);
            rect.setY(rect.y()+1.0+borderWidth/4.0);
            QPainterPath paintPath;
            paintPath.addRect(rect);
            painter->drawPath(paintPath);

            painter->restore();
        }
    }
    QStyledItemDelegate::paint(painter, option, index);
}
