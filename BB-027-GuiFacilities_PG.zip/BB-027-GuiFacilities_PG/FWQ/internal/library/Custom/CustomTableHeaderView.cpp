//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::CustomTableHeaderView.
// !\description Header file for class SUI::CustomTableHeaderView.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "CustomTableHeaderView.h"

#include <QPainter>

SUI::CustomTableHeaderView::CustomTableHeaderView(Qt::Orientation orientation, QWidget *parent) :
    QHeaderView(orientation, parent), privateData(new CustomTableHeaderViewPrivateData())

{
    QPalette p = palette();
    p.setColor(QPalette::Button,Qt::white);
    setPalette(p);

    connect(this, SIGNAL(sectionResized(int, int, int)), this, SLOT(onSectionResized(int)));
}

SUI::CustomTableHeaderView::~CustomTableHeaderView()
{
    delete privateData;
}

QStyleOptionHeader SUI::CustomTableHeaderView::styleOptionForCell(int logicalInd) const {

    QStyleOptionHeader opt;
    initStyleOption(&opt);
    if (window()->isActiveWindow()) opt.state |= QStyle::State_Active;
    opt.textAlignment = Qt::AlignCenter;
    opt.iconAlignment = Qt::AlignVCenter;
    opt.section = logicalInd;

    int visual = visualIndex(logicalInd);
    if (count() == 1) opt.position = QStyleOptionHeader::OnlyOneSection;
    else {
        if (visual == 0) {
            opt.position = QStyleOptionHeader::Beginning;
        }
        else {
            opt.position=(visual==(count()-1) ? QStyleOptionHeader::End : QStyleOptionHeader::Middle);
        }
    }

//    if(clickable()) {
//        if (logicalIndex == d->hover)
//            state |= QStyle::State_MouseOver;
//        if (logicalIndex == d->pressed) {
//            state |= QStyle::State_Sunken;
//        }
//        else {
//            if(highlightSections() && selectionModel()) {
//                if(orientation()==Qt::Horizontal) {
//                    if(selectionModel()->columnIntersectsSelection(logicalInd, rootIndex()))
//                        opt.state |= QStyle::State_On;
//                    if(selectionModel()->isColumnSelected(logicalInd, rootIndex()))
//                        opt.state |= QStyle::State_Sunken;
//                }
//                else {
//                    if(selectionModel()->rowIntersectsSelection(logicalInd, rootIndex()))
//                        opt.state |= QStyle::State_On;
//                    if(selectionModel()->isRowSelected(logicalInd, rootIndex()))
//                        opt.state |= QStyle::State_Sunken;
//                }
//            }
//        }
//    }

    if(selectionModel() != NULL) {
        bool previousSelected=false;
        if(orientation() == Qt::Horizontal) {
            previousSelected = selectionModel()->isColumnSelected(logicalIndex(visual - 1), rootIndex());
        }
        else {
            previousSelected = selectionModel()->isRowSelected(logicalIndex(visual - 1), rootIndex());
        }
        bool nextSelected=false;

        if(orientation() == Qt::Horizontal) {
            nextSelected = selectionModel()->isColumnSelected(logicalIndex(visual + 1), rootIndex());
        }
        else {
            nextSelected = selectionModel()->isRowSelected(logicalIndex(visual + 1), rootIndex());
        }
        if (previousSelected && nextSelected) {
            opt.selectedPosition = QStyleOptionHeader::NextAndPreviousAreSelected;
        }
        else {
            if (previousSelected) {
                opt.selectedPosition = QStyleOptionHeader::PreviousIsSelected;
            }
            else {
                if (nextSelected) {
                    opt.selectedPosition = QStyleOptionHeader::NextIsSelected;
                }
                else {
                    opt.selectedPosition = QStyleOptionHeader::NotAdjacent;
                }
            }
        }
    }
    return opt;
}

QSize SUI::CustomTableHeaderView::sectionSizeFromContents(int logicalIndex) const {
    if(privateData->CustomTableHeaderViewPrivateData::getHeaderModel() != NULL) {
        QModelIndex curLeafIndex(privateData->leafIndex(logicalIndex));
        if(curLeafIndex.isValid()) {
            QStyleOptionHeader styleOption(styleOptionForCell(logicalIndex));
            QSize s(privateData->cellSize(curLeafIndex, this, styleOption));
            curLeafIndex=curLeafIndex.parent();
            while(curLeafIndex.isValid()    ) {
                if(orientation() == Qt::Horizontal) {
                    s.rheight()+=privateData->cellSize(curLeafIndex, this, styleOption).height();
                }
                else {
                    s.rwidth()+=privateData->cellSize(curLeafIndex, this, styleOption).width();
                }
                curLeafIndex=curLeafIndex.parent();
            }
            return s;
        }
    }
    return QHeaderView::sectionSizeFromContents(logicalIndex);
}

void SUI::CustomTableHeaderView::paintSection(QPainter *painter, const QRect &rect, int logicalIndex) const {
    if (rect.isValid()) {
        QModelIndex leafIndex(privateData->leafIndex(logicalIndex));
        if(leafIndex.isValid()) {
            if(orientation() == Qt::Horizontal) {
                privateData->paintHorizontalSection(painter, rect, logicalIndex, this, styleOptionForCell(logicalIndex), leafIndex);
            }
            else {
                privateData->paintVerticalSection(painter, rect, logicalIndex, this, styleOptionForCell(logicalIndex), leafIndex);
            }
            return;
        }
    }
    QHeaderView::paintSection(painter, rect, logicalIndex);
}

void SUI::CustomTableHeaderView::onSectionResized(int logicalIndex) {
    if(isSectionHidden(logicalIndex)) return;

    QModelIndex leafIndex(privateData->leafIndex(logicalIndex));
    if(leafIndex.isValid()) {
        QModelIndexList leafsList(privateData->leafs(privateData->findRootIndex(leafIndex)));
        for(int n=leafsList.indexOf(leafIndex); n>0; --n) {
            --logicalIndex;
            int w = viewport()->width();
            int h = viewport()->height();
            int pos = sectionViewportPosition(logicalIndex);
            QRect r(pos, 0, w - pos, h);
            if(orientation() == Qt::Horizontal) {
                if (isRightToLeft()) {
                    r.setRect(0, 0, pos + sectionSize(logicalIndex), h);
                }
            }
            else {
                r.setRect(0, pos, w, h - pos);
            }
            viewport()->update(r.normalized());
        }
    }
}

void SUI::CustomTableHeaderView::CustomTableHeaderViewPrivateData::setForegroundBrush(QStyleOptionHeader &opt, const QModelIndex &index) const {

    QVariant foregroundBrush = index.data(Qt::ForegroundRole);
    if (qVariantCanConvert<QBrush>(foregroundBrush)) {
        opt.palette.setBrush(QPalette::ButtonText, qvariant_cast<QBrush>(foregroundBrush));
    }
}

void SUI::CustomTableHeaderView::CustomTableHeaderViewPrivateData::setBackgroundBrush(QStyleOptionHeader &opt, const QModelIndex &index) const {
    QVariant backgroundBrush = index.data(Qt::BackgroundRole);
    if (qVariantCanConvert<QBrush>(backgroundBrush)) {
        opt.palette.setBrush(QPalette::Button, qvariant_cast<QBrush>(backgroundBrush));
        opt.palette.setBrush(QPalette::Window, qvariant_cast<QBrush>(backgroundBrush));
    }
}

QSize SUI::CustomTableHeaderView::CustomTableHeaderViewPrivateData::cellSize(const QModelIndex &leafIndex, const QHeaderView *hv, QStyleOptionHeader styleOptions) const {
    QSize res;
    QVariant variant(leafIndex.data(Qt::SizeHintRole));
    if (variant.isValid()) {
        res=qvariant_cast<QSize>(variant);
    }
    QFont fnt(hv->font());
    QVariant var(leafIndex.data(Qt::FontRole));
    if (var.isValid() && qVariantCanConvert<QFont>(var)) {
        fnt = qvariant_cast<QFont>(var);
    }
    fnt.setBold(true);
    QFontMetrics fm(fnt);
    QSize size(fm.size(0, leafIndex.data(Qt::DisplayRole).toString()));
    if(leafIndex.data(Qt::UserRole).isValid()) {
        size.transpose();
    }
    QSize decorationsSize(hv->style()->sizeFromContents(QStyle::CT_HeaderSection, &styleOptions, QSize(), hv));
    QSize emptyTextSize(fm.size(0, ""));
    return res.expandedTo(size+decorationsSize-emptyTextSize);
}

int SUI::CustomTableHeaderView::CustomTableHeaderViewPrivateData::currentCellWidth(const QModelIndex &searchedIndex, const QModelIndex &leafIndex, int sectionIndex, const QHeaderView *hv) const {
    QModelIndexList leafsList(leafs(searchedIndex));
    if(leafsList.empty()) {
        return hv->sectionSize(sectionIndex);
    }
    int width=0;
    int firstLeafSectionIndex=sectionIndex-leafsList.indexOf(leafIndex);
    for(int i=0; i<leafsList.size(); ++i) {
        width+=hv->sectionSize(firstLeafSectionIndex+i);
    }
    return width;
}

int SUI::CustomTableHeaderView::CustomTableHeaderViewPrivateData::currentCellLeft(const QModelIndex &searchedIndex, const QModelIndex &leafIndex, int sectionIndex, int left, const QHeaderView *hv) const {
    QModelIndexList leafsList(leafs(searchedIndex));
    if(!leafsList.empty()) {
        int n=leafsList.indexOf(leafIndex);
        int firstLeafSectionIndex=sectionIndex-n;
        --n;
        for(; n>=0; --n) {
            left-=hv->sectionSize(firstLeafSectionIndex+n);
        }
    }
    return left;
}

int SUI::CustomTableHeaderView::CustomTableHeaderViewPrivateData::paintHorizontalCell(QPainter *painter, const QHeaderView *hv, const QModelIndex &cellIndex, const QModelIndex &leafIndex, int logicalLeafIndex, const QStyleOptionHeader &styleOptions, const QRect &sectionRect, int top) const {

    QStyleOptionHeader uniopt(styleOptions);
    setForegroundBrush(uniopt, cellIndex);
    setBackgroundBrush(uniopt, cellIndex);

    int height=cellSize(cellIndex, hv, uniopt).height();
    if(cellIndex==leafIndex) {
        height=sectionRect.height()-top;
    }
    int left=currentCellLeft(cellIndex, leafIndex, logicalLeafIndex, sectionRect.left(), hv);
    int width=currentCellWidth(cellIndex, leafIndex, logicalLeafIndex, hv);

    QRect r(left, top, width, height);

    uniopt.text = cellIndex.data(Qt::DisplayRole).toString();
    painter->save();
    uniopt.rect = r;
    if(cellIndex.data(Qt::UserRole).isValid()) {
        hv->style()->drawControl(QStyle::CE_HeaderSection, &uniopt, painter, hv);
        QMatrix m;
        double counterClockwise = -90.0;
        m.rotate(counterClockwise);
        painter->setWorldMatrix(m, true);
        QRect new_r(0, 0,  r.height(), r.width());
        new_r.moveCenter(QPoint(-r.center().y(), r.center().x()));
        uniopt.rect = new_r;
        hv->style()->drawControl(QStyle::CE_HeaderLabel, &uniopt, painter, hv);
    }
    else {
        hv->style()->drawControl(QStyle::CE_Header, &uniopt, painter, hv);
    }
    painter->restore();

    return top+height;
}

void SUI::CustomTableHeaderView::CustomTableHeaderViewPrivateData::paintHorizontalSection(QPainter *painter, const QRect &sectionRect, int logicalLeafIndex, const QHeaderView *hv, const QStyleOptionHeader &styleOptions, const QModelIndex &leafIndex) const {

    QPointF oldBO(painter->brushOrigin());
    int top=sectionRect.y();
    QModelIndexList indexes(parentIndexes(leafIndex));
    for(int i=0; i<indexes.size(); ++i) {
        QStyleOptionHeader realStyleOptions(styleOptions);
        if(i<indexes.size()-1 && (realStyleOptions.state.testFlag(QStyle::State_Sunken) || realStyleOptions.state.testFlag(QStyle::State_On))) {
            QStyle::State t(QStyle::State_Sunken | QStyle::State_On);
            realStyleOptions.state&=(~t);
        }
        top=paintHorizontalCell(painter,hv,indexes[i],leafIndex,logicalLeafIndex,realStyleOptions,sectionRect,top);
    }
    painter->setBrushOrigin(oldBO);
}

int SUI::CustomTableHeaderView::CustomTableHeaderViewPrivateData::paintVerticalCell(QPainter *painter, const QHeaderView *hv, const QModelIndex &cellIndex, const QModelIndex &leafIndex, int logicalLeafIndex, const QStyleOptionHeader &styleOptions, const QRect &sectionRect, int left) const {

    QStyleOptionHeader uniopt(styleOptions);
    setForegroundBrush(uniopt, cellIndex);
    setBackgroundBrush(uniopt, cellIndex);
    int width=cellSize(cellIndex, hv, uniopt).width();
    if(cellIndex==leafIndex) {
        width=sectionRect.width()-left;
    }
    int top=currentCellLeft(cellIndex, leafIndex, logicalLeafIndex, sectionRect.top(), hv);
    int height=currentCellWidth(cellIndex, leafIndex, logicalLeafIndex, hv);

    QRect r(left, top, width, height);

    uniopt.text = cellIndex.data(Qt::DisplayRole).toString();
    painter->save();
    uniopt.rect = r;

    if(cellIndex.data(Qt::UserRole).isValid()) {
        hv->style()->drawControl(QStyle::CE_HeaderSection, &uniopt, painter, hv);

        QMatrix m;
        m.rotate(static_cast<qreal>(-90));
        painter->setWorldMatrix(m, true);

        QRect new_r(0, 0,  r.height(), r.width());
        new_r.moveCenter(QPoint(-r.center().y(), r.center().x()));
        uniopt.rect = new_r;

        hv->style()->drawControl(QStyle::CE_HeaderLabel, &uniopt, painter, hv);
    }
    else {
        hv->style()->drawControl(QStyle::CE_Header, &uniopt, painter, hv);
    }

    painter->restore();
    return left+width;
}

void SUI::CustomTableHeaderView::CustomTableHeaderViewPrivateData::paintVerticalSection(QPainter *painter, const QRect &sectionRect, int logicalLeafIndex, const QHeaderView *hv, const QStyleOptionHeader &styleOptions, const QModelIndex &leafIndex) const {

    QPointF oldBO(painter->brushOrigin());
    int left=sectionRect.x();
    QModelIndexList indexes(parentIndexes(leafIndex));
    for(int i=0; i<indexes.size(); ++i) {
        QStyleOptionHeader realStyleOptions(styleOptions);
        if(i<indexes.size()-1 && (realStyleOptions.state.testFlag(QStyle::State_Sunken) || realStyleOptions.state.testFlag(QStyle::State_On))) {

            QStyle::State t(QStyle::State_Sunken | QStyle::State_On);
            realStyleOptions.state&=(~t);
        }
        left=paintVerticalCell(painter,hv,indexes[i],leafIndex,logicalLeafIndex,realStyleOptions,sectionRect,left);

    }
    painter->setBrushOrigin(oldBO);
}

void SUI::CustomTableHeaderView::setModel(QAbstractItemModel* model) {
    privateData->setModel(orientation(), model);
    QHeaderView::setModel(model);
    if (model != NULL) {
        int cnt=(orientation()==Qt::Horizontal ? model->columnCount() : model->rowCount());
        if(cnt > 0) {
            initializeSections(0, cnt-1);
        }
    }
}


void SUI::CustomTableHeaderView::CustomTableHeaderViewPrivateData::setModel(Qt::Orientation orientation, QAbstractItemModel *model) {
    headerModel = QPointer<QAbstractItemModel>();
    if (model != NULL) {
        QVariant object = model->data(QModelIndex(),orientation == Qt::Vertical ? VerticalHeader : HorizontalHeader);
        if (object.isValid()) {
            headerModel = qobject_cast<QAbstractItemModel*>(object.value<QObject*>());
        }
    }
}

QModelIndex SUI::CustomTableHeaderView::CustomTableHeaderViewPrivateData::findRootIndex(QModelIndex &index) const {
    while (index.parent().isValid()) {
        index = index.parent();
    }
    return index;
}

QModelIndexList SUI::CustomTableHeaderView::CustomTableHeaderViewPrivateData::parentIndexes(QModelIndex index) const {
    QModelIndexList list;
    while (index.isValid()) {
        list.prepend(index);
        index=index.parent();
    }
    return list;
}

QModelIndex SUI::CustomTableHeaderView::CustomTableHeaderViewPrivateData::findLeaf(const QModelIndex &currentIndex, int sectionIndex, int &currentLeafIndex) {
    if (currentIndex.isValid()) {
        int children = currentIndex.model()->columnCount(currentIndex);
        if(children > 0) {
            for(int i=0; i < children; ++i) {
                QModelIndex res(findLeaf(currentIndex.child(0, i), sectionIndex, currentLeafIndex));
                if(res.isValid()) {
                    return res;
                }
            }
        }
        else {
            currentLeafIndex++;
            if(currentLeafIndex == sectionIndex) {
                return currentIndex;
            }
        }
    }
    return QModelIndex();
}

QModelIndex SUI::CustomTableHeaderView::CustomTableHeaderViewPrivateData::leafIndex(int sectionIndex) {
    if(headerModel != NULL) {
        int curentLeafIndex=-1;
        for(int i=0; i<headerModel->columnCount(); ++i) {
            QModelIndex res(findLeaf(headerModel->index(0, i), sectionIndex, curentLeafIndex));
            if(res.isValid()) {
                return res;
            }
        }
    }
    return QModelIndex();
}

QModelIndexList SUI::CustomTableHeaderView::CustomTableHeaderViewPrivateData::searchLeafs(const QModelIndex &curentIndex) const {
    QModelIndexList res;
    if(curentIndex.isValid()) {
        int childCount=curentIndex.model()->columnCount(curentIndex);
        if(childCount != 0) {
            for(int i=0; i<childCount; ++i) {
                res+=searchLeafs(curentIndex.child(0, i));
            }
        }
        else {
            res.push_back(curentIndex);
        }
    }
    return res;
}

QModelIndexList SUI::CustomTableHeaderView::CustomTableHeaderViewPrivateData::leafs(const QModelIndex &searchedIndex) const {
    QModelIndexList list;
    if (searchedIndex.isValid()) {
        int children = searchedIndex.model()->columnCount(searchedIndex);
        for (int n = 0; n < children; n++) {
            list.append(searchLeafs(searchedIndex.child(0,n)));
        }
    }
    return list;
}

QPointer<QAbstractItemModel>& SUI::CustomTableHeaderView::CustomTableHeaderViewPrivateData::getHeaderModel()
{
    return headerModel;
}
