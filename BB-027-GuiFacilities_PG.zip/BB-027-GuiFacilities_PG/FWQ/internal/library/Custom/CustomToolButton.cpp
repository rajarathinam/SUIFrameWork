//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for CustomToolButton.
// !\description Class implementation file for CustomToolButton.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|



#include "CustomToolButton.h"

#include <QMouseEvent>

CustomToolButton::CustomToolButton(QWidget *parent) :
    QToolButton(parent)
{
}

void CustomToolButton::mousePressEvent(QMouseEvent *event) {
    QToolButton::mousePressEvent(event);
    emit mousePressed();
}

void CustomToolButton::mouseReleaseEvent(QMouseEvent *event) {
    QToolButton::mouseReleaseEvent(event);
    emit mouseReleased();
}
