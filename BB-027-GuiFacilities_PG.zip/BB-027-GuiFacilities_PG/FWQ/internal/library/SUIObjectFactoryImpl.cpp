//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::ObjectFactoryImpl.
// !\description Class implementation file for SUI::ObjectFactoryImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUIObjectFactoryImpl.h"
#include "SUIDialogImpl.h"
#include "SUILabelImpl.h"
#include "SUILineEditImpl.h"
#include "SUIRadioButtonImpl.h"
#include "SUITabWidgetImpl.h"
#include "SUITabPageImpl.h"
#include "SUIButtonImpl.h"
#include "SUICheckBoxImpl.h"
#include "SUIGroupBoxImpl.h"
#include "SUICheckGroupBoxImpl.h"
#include "SUIButtonBarImpl.h"
#include "SUITableWidgetImpl.h"
#include "SUITableWidgetItemImpl.h"
#include "SUISpinBoxImpl.h"
#include "SUIDoubleSpinBoxImpl.h"
#include "SUIDropDownImpl.h"
#include "SUICheckMarkImpl.h"
#include "SUILEDWidgetImpl.h"
#include "SUIColorDropImpl.h"
#include "SUIColorCrossDropImpl.h"
#include "SUITextAreaImpl.h"
#include "SUIProgressBarImpl.h"
#include "SUIGraphicsViewImpl.h"
#include "SUIMessageBoxImpl.h"
#include "SUISplitterImpl.h"
#include "SUIFileDialogImpl.h"
#include "SUIUserControlImpl.h"
#include "SUIPlotWidgetImpl.h"
#include "SUIListViewImpl.h"
#include "SUIControlWidgetImpl.h"
#include "SUIStateWidgetImpl.h"
#include "SUIScienceSpinBoxImpl.h"
#include "SUIQuestionMarkImpl.h"
#include "SUIBusyIndicatorImpl.h"
#include "SUIImageWidgetImpl.h"
#include "SUITreeViewImpl.h"
#include "SUITreeViewItemImpl.h"
#include "SUILineWidgetImpl.h"
#include "SUISvgWidgetImpl.h"
#include "SUIWidgetPageImpl.h"
#include "SUIContainerImpl.h"
#include "SUIScrollBarImpl.h"
#include "SUIDateTimeEditImpl.h"
#include "SUIApplicationImpl.h"
#include "SUIWebViewImpl.h"

#include <assert.h>

SUI::ObjectFactoryImpl::ObjectFactoryImpl()
{
}

SUI::ObjectFactoryImpl::~ObjectFactoryImpl()
{
}

SUI::BaseWidget *SUI::ObjectFactoryImpl::createWidget(ObjectType::Type widgetType, QWidget *parent, ObjectList *widgetList) {

    switch (widgetType)
    {
    case ObjectType::Button:            return new ButtonImpl(parent);
    case ObjectType::Label:             return new LabelImpl(parent);
    case ObjectType::LineEdit:          return new LineEditImpl(parent);
    case ObjectType::CheckBox:          return new CheckBoxImpl(parent);
    case ObjectType::RadioButton:       return new RadioButtonImpl(parent);
    case ObjectType::GroupBox:          return new GroupBoxImpl(parent);
    case ObjectType::CheckGroupBox:     return new CheckGroupBoxImpl(parent);
    case ObjectType::TabWidget:         return new TabWidgetImpl(parent);
    case ObjectType::TabPage:           return new TabPageImpl(parent);
    case ObjectType::ButtonBar:         return new ButtonBarImpl(parent);
    case ObjectType::TableWidget:       return new TableWidgetImpl(parent, widgetList);
    case ObjectType::TableWidgetItem:   return new TableWidgetItemImpl(parent);
    case ObjectType::SpinBox:           return new SpinBoxImpl(parent);
    case ObjectType::DoubleSpinBox:     return new DoubleSpinBoxImpl(parent);
    case ObjectType::DropDown:          return new DropDownImpl(parent);
    case ObjectType::LEDWidget:         return new LEDWidgetImpl(parent);
    case ObjectType::CheckMark:         return new CheckMarkImpl(parent);
    case ObjectType::ColorDrop:         return new ColorDropImpl(parent);
    case ObjectType::ColorCrossDrop:    return new ColorCrossDropImpl(parent);
    case ObjectType::TextArea:          return new TextAreaImpl(parent);
    case ObjectType::FileDialog:        return new FileDialogImpl(parent);
    case ObjectType::ProgressBar:       return new ProgressBarImpl(parent);
    case ObjectType::GraphicsView:      return new GraphicsViewImpl(parent);
    case ObjectType::MessageBox:        return new MessageBoxImpl(parent);
    case ObjectType::Splitter:          return new SplitterImpl(parent);
    case ObjectType::PlotWidget:        return new PlotWidgetImpl(parent);
    case ObjectType::UserControl:       return new UserControlImpl(parent);
    case ObjectType::ListView:          return new ListViewImpl(parent);
    case ObjectType::ControlWidget:     return new ControlWidgetImpl(parent);
    case ObjectType::StateWidget:       return new StateWidgetImpl(parent);
    case ObjectType::ScienceSpinBox:    return new ScienceSpinBoxImpl(parent);
    case ObjectType::QuestionMark:      return new QuestionMarkImpl(parent);
    case ObjectType::BusyIndicator:     return new BusyIndicatorImpl(parent);
    case ObjectType::ImageWidget:       return new ImageWidgetImpl(parent);
    case ObjectType::TreeView:          return new TreeViewImpl(parent, widgetList);
    case ObjectType::TreeViewItem:      return new TreeViewItemImpl(parent);
    case ObjectType::LineWidget:        return new LineWidgetImpl(parent);
    case ObjectType::SvgWidget:         return new SvgWidgetImpl(parent);
    case ObjectType::WidgetPage:        return new WidgetPageImpl(parent);
    case ObjectType::Container:         return new ContainerImpl(parent);
    case ObjectType::ScrollBar:         return new ScrollBarImpl(parent);
    case ObjectType::DateTimeEdit:      return new DateTimeEditImpl(parent);
    case ObjectType::WebView:           return new WebViewImpl(parent);

    default: return NULL;
    }
}

SUI::Widget *SUI::ObjectFactoryImpl::toWidget(SUI::BaseObject *object) {
    return dynamic_cast<SUI::Widget *>(baseObjectToObject(object));
}


SUI::Object *SUI::ObjectFactoryImpl::toObject(SUI::BaseObject *object) {
    return baseObjectToObject(object);
}

SUI::BaseObject *SUI::ObjectFactoryImpl::toBaseObject(SUI::Object *object) {
    return objectToBaseObject(object);
}

SUI::BaseObject *SUI::ObjectFactoryImpl::toBaseObject(const SUI::Object *object) {
   return toBaseObject(const_cast<Object*>(object));
}

SUI::BaseWidget *SUI::ObjectFactoryImpl::toBaseWidget(SUI::Widget *object) {
    return dynamic_cast<BaseWidget*>(objectToBaseObject(object));
}

SUI::BaseWidget *SUI::ObjectFactoryImpl::toBaseWidget(const SUI::Widget *object) {
   return toBaseWidget(const_cast<Widget*>(object));
}

SUI::Object *SUI::ObjectFactoryImpl::baseObjectToObject(SUI::BaseObject *object) {
    if (object == NULL) return NULL;
    switch (object->getObjectType())
    {
        case ObjectType::Button:            return dynamic_cast<ButtonImpl *>(object);
        case ObjectType::Label:             return dynamic_cast<LabelImpl *>(object);
        case ObjectType::LineEdit:          return dynamic_cast<LineEditImpl *>(object);
        case ObjectType::CheckBox:          return dynamic_cast<CheckBoxImpl *>(object);
        case ObjectType::RadioButton:       return dynamic_cast<RadioButtonImpl *>(object);
        case ObjectType::GroupBox:          return dynamic_cast<GroupBoxImpl *>(object);
        case ObjectType::CheckGroupBox:     return dynamic_cast<CheckGroupBoxImpl *>(object);
        case ObjectType::TabWidget:         return dynamic_cast<TabWidgetImpl *>(object);
        case ObjectType::TabPage:           return dynamic_cast<TabPageImpl *>(object);
        case ObjectType::ButtonBar:         return dynamic_cast<ButtonBarImpl *>(object);
        case ObjectType::TableWidget:       return dynamic_cast<TableWidgetImpl *>(object);
        case ObjectType::TableWidgetItem:   return dynamic_cast<TableWidgetItemImpl *>(object);
        case ObjectType::SpinBox:           return dynamic_cast<SpinBoxImpl *>(object);
        case ObjectType::DoubleSpinBox:     return dynamic_cast<DoubleSpinBoxImpl *>(object);
        case ObjectType::DropDown:          return dynamic_cast<DropDownImpl *>(object);
        case ObjectType::LEDWidget:         return dynamic_cast<LEDWidgetImpl *>(object);
        case ObjectType::CheckMark:         return dynamic_cast<CheckMarkImpl *>(object);
        case ObjectType::ColorDrop:         return dynamic_cast<ColorDropImpl *>(object);
        case ObjectType::ColorCrossDrop:    return dynamic_cast<ColorCrossDropImpl *>(object);
        case ObjectType::TextArea:          return dynamic_cast<TextAreaImpl *>(object);
        case ObjectType::FileDialog:        return dynamic_cast<FileDialogImpl *>(object);
        case ObjectType::ProgressBar:       return dynamic_cast<ProgressBarImpl *>(object);
        case ObjectType::GraphicsView:      return dynamic_cast<GraphicsViewImpl *>(object);
        case ObjectType::MessageBox:        return dynamic_cast<MessageBoxImpl *>(object);
        case ObjectType::Splitter:          return dynamic_cast<SplitterImpl *>(object);
        case ObjectType::PlotWidget:        return dynamic_cast<PlotWidgetImpl *>(object);
        case ObjectType::UserControl:       return dynamic_cast<UserControlImpl *>(object);
        case ObjectType::ListView:          return dynamic_cast<ListViewImpl *>(object);
        case ObjectType::ControlWidget:     return dynamic_cast<ControlWidgetImpl *>(object);
        case ObjectType::StateWidget:       return dynamic_cast<StateWidgetImpl *>(object);
        case ObjectType::ScienceSpinBox:    return dynamic_cast<ScienceSpinBoxImpl *>(object);
        case ObjectType::QuestionMark:      return dynamic_cast<QuestionMarkImpl *>(object);
        case ObjectType::BusyIndicator:     return dynamic_cast<BusyIndicatorImpl *>(object);
        case ObjectType::ImageWidget:       return dynamic_cast<ImageWidgetImpl *>(object);
        case ObjectType::TreeView:          return dynamic_cast<TreeViewImpl *>(object);
        case ObjectType::TreeViewItem:      return dynamic_cast<TreeViewItemImpl *>(object);
        case ObjectType::LineWidget:        return dynamic_cast<LineWidgetImpl *>(object);
        case ObjectType::SvgWidget:         return dynamic_cast<SvgWidgetImpl *>(object);
        case ObjectType::WidgetPage:        return dynamic_cast<WidgetPageImpl *>(object);
        case ObjectType::Container:         return dynamic_cast<ContainerImpl *>(object);
        case ObjectType::ScrollBar:         return dynamic_cast<ScrollBarImpl *>(object);
        case ObjectType::DateTimeEdit:      return dynamic_cast<DateTimeEditImpl *>(object);
        case ObjectType::WebView:           return dynamic_cast<WebViewImpl *>(object);

        default: return NULL;
    }
}

SUI::BaseObject *SUI::ObjectFactoryImpl::objectToBaseObject(SUI::Object *object) {
    if (object == NULL) return NULL;
    switch (object->getObjectType())
    {
    case ObjectType::Button:            return dynamic_cast<ButtonImpl *>(object);
    case ObjectType::Label:             return dynamic_cast<LabelImpl *>(object);
    case ObjectType::LineEdit:          return dynamic_cast<LineEditImpl *>(object);
    case ObjectType::CheckBox:          return dynamic_cast<CheckBoxImpl *>(object);
    case ObjectType::RadioButton:       return dynamic_cast<RadioButtonImpl *>(object);
    case ObjectType::GroupBox:          return dynamic_cast<GroupBoxImpl *>(object);
    case ObjectType::CheckGroupBox:     return dynamic_cast<CheckGroupBoxImpl *>(object);
    case ObjectType::TabWidget:         return dynamic_cast<TabWidgetImpl *>(object);
    case ObjectType::TabPage:           return dynamic_cast<TabPageImpl *>(object);
    case ObjectType::ButtonBar:         return dynamic_cast<ButtonBarImpl *>(object);
    case ObjectType::TableWidget:       return dynamic_cast<TableWidgetImpl *>(object);
    case ObjectType::TableWidgetItem:   return dynamic_cast<TableWidgetItemImpl *>(object);
    case ObjectType::SpinBox:           return dynamic_cast<SpinBoxImpl *>(object);
    case ObjectType::DoubleSpinBox:     return dynamic_cast<DoubleSpinBoxImpl *>(object);
    case ObjectType::DropDown:          return dynamic_cast<DropDownImpl *>(object);
    case ObjectType::LEDWidget:         return dynamic_cast<LEDWidgetImpl *>(object);
    case ObjectType::CheckMark:         return dynamic_cast<CheckMarkImpl *>(object);
    case ObjectType::ColorDrop:         return dynamic_cast<ColorDropImpl *>(object);
    case ObjectType::ColorCrossDrop:    return dynamic_cast<ColorCrossDropImpl *>(object);
    case ObjectType::TextArea:          return dynamic_cast<TextAreaImpl *>(object);
    case ObjectType::FileDialog:        return dynamic_cast<FileDialogImpl *>(object);
    case ObjectType::ProgressBar:       return dynamic_cast<ProgressBarImpl *>(object);
    case ObjectType::GraphicsView:      return dynamic_cast<GraphicsViewImpl *>(object);
    case ObjectType::MessageBox:        return dynamic_cast<MessageBoxImpl *>(object);
    case ObjectType::Splitter:          return dynamic_cast<SplitterImpl *>(object);
    case ObjectType::PlotWidget:        return dynamic_cast<PlotWidgetImpl *>(object);
    case ObjectType::UserControl:       return dynamic_cast<UserControlImpl *>(object);
    case ObjectType::ListView:          return dynamic_cast<ListViewImpl *>(object);
    case ObjectType::ControlWidget:     return dynamic_cast<ControlWidgetImpl *>(object);
    case ObjectType::StateWidget:       return dynamic_cast<StateWidgetImpl *>(object);
    case ObjectType::ScienceSpinBox:    return dynamic_cast<ScienceSpinBoxImpl *>(object);
    case ObjectType::QuestionMark:      return dynamic_cast<QuestionMarkImpl *>(object);
    case ObjectType::BusyIndicator:     return dynamic_cast<BusyIndicatorImpl *>(object);
    case ObjectType::ImageWidget:       return dynamic_cast<ImageWidgetImpl *>(object);
    case ObjectType::TreeView:          return dynamic_cast<TreeViewImpl *>(object);
    case ObjectType::TreeViewItem:      return dynamic_cast<TreeViewItemImpl *>(object);
    case ObjectType::LineWidget:        return dynamic_cast<LineWidgetImpl *>(object);
    case ObjectType::SvgWidget:         return dynamic_cast<SvgWidgetImpl *>(object);
    case ObjectType::WidgetPage:        return dynamic_cast<WidgetPageImpl *>(object);
    case ObjectType::Container:         return dynamic_cast<ContainerImpl *>(object);
    case ObjectType::ScrollBar:         return dynamic_cast<ScrollBarImpl *>(object);
    case ObjectType::DateTimeEdit:      return dynamic_cast<DateTimeEditImpl *>(object);
    case ObjectType::WebView:           return dynamic_cast<WebViewImpl *>(object);

    default: return NULL;
    }
}

SUI::Widget *SUI::ObjectFactoryImpl::createButton(QWidget *parent) { return new ButtonImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createLabel(QWidget *parent) { return new LabelImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createLineEdit(QWidget *parent) { return new LineEditImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createRadioButton(QWidget *parent) { return new RadioButtonImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createTabWidget(QWidget *parent) { return new TabWidgetImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createTabPage(QWidget *parent) { return new TabPageImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createCheckBox(QWidget *parent) { return new CheckBoxImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createGroupBox(QWidget *parent) { return new GroupBoxImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createCheckGroupBox(QWidget *parent) { return new CheckGroupBoxImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createButtonBar(QWidget *parent) { return new ButtonBarImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createTableWidget(QWidget *parent) { return new TableWidgetImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createTableWidgetItem(QWidget *parent) { return new TableWidgetItemImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createSpinBox(QWidget *parent) { return new SpinBoxImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createDoubleSpinBox(QWidget *parent) { return new DoubleSpinBoxImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createDropDown(QWidget *parent) { return new DropDownImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createCheckMark(QWidget *parent) { return new CheckMarkImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createLEDWidget(QWidget *parent) { return new LEDWidgetImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createColorDrop(QWidget *parent) { return new ColorDropImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createColorCrossDrop(QWidget *parent) { return new ColorCrossDropImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createTextArea(QWidget *parent) { return new TextAreaImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createProgressBar(QWidget *parent) { return new ProgressBarImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createImageViewer(QWidget *parent) { return new GraphicsViewImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createMessageBox(QWidget *parent) { return new MessageBoxImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createSplitter(QWidget *parent) { return new SplitterImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createFileDialog(QWidget *parent) { return new FileDialogImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createUserControl(QWidget *parent) { return new UserControlImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createPlotWidget(QWidget *parent) { return new PlotWidgetImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createListView(QWidget *parent) { return new ListViewImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createControlWidget(QWidget *parent) { return new ControlWidgetImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createStateWidget(QWidget *parent) { return new StateWidgetImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createScienceSpinBox(QWidget *parent) { return new ScienceSpinBoxImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createQuestionMark(QWidget *parent) { return new QuestionMarkImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createBusyIndicator(QWidget *parent) { return new BusyIndicatorImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createImageWidget(QWidget *parent) { return new ImageWidgetImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createTreeView(QWidget *parent) { return new TreeViewImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createTreeViewItem(QWidget *parent) { return new TreeViewItemImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createLineWidget(QWidget *parent) { return new LineWidgetImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createSvgWidget(QWidget *parent) { return new SvgWidgetImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createWidgetPage(QWidget *parent) { return new WidgetPageImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createContainer(QWidget *parent) { return new ContainerImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createScrollBar(QWidget *parent) { return new ScrollBarImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createDateTimeEdit(QWidget *parent) { return new DateTimeEditImpl(parent); }
SUI::Widget *SUI::ObjectFactoryImpl::createWebView(QWidget *parent) { return new WebViewImpl(parent); }

