//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ObjectPropertyTypeEnum.
// !\description Header file for class SUI::ObjectPropertyTypeEnum.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIOBJECTPROPERTYTYPEENUM_H
#define SUIOBJECTPROPERTYTYPEENUM_H

#include <map>
#include <string>
#include <iostream>
#include <vector>

#include "FWQxCore/SUIObjectType.h"

#include <QVariant>

namespace SUI {

class ObjectPropertyTypeEnum
{
public:
    typedef enum {
        ID,
        XPos,
        YPos,
        Height,
        Width,
        ObjectType,
        Visible,
        Enable,
        Moveable,
        Sizeable,
        CurrentTabPage,
        SUIVersion,
        SUIName,
        SUIDescription,
        HasBottomButtonBar,
        HasRightButtonBar,
        HasStatusBar,
        StepSize,
        ColumnCount,
        RowCount,
        ColumnWidths,
        CellAlignment,
        MaxValue,
        MinValue,
        Color,
        BGColor,
        ImageData,
        ImageDataPressed,
        Precision,
        AutoScroll,
        ReadOnly,
        Text,
        Alignment,
        Orientation,
        UserControl,
        TabOrder,
        ControlType,
        ControlState,
        StateList,
        ImageList,
        DefaultState,
        Menu,
        MenuItem,
        HelpFile,
        Checked,
        SortingOrder,
        SelectBehaviour,
        StepsizeToFactor,
        RegularExpression,
        RegExpTip,
        ScrollBars,
        FilterString,
        FontSize,
        AutoFitBG,
        ZoomStyle,
        ScrollZoom,
        Bold,
        ListViewMode,
        BorderWidth,
        BorderOn,
        Percentage,
        ToolTipEnable,
        ToolTip,
        DisableHeader,
        MultipleRowSelection,
        PropScientific,
        Hover,
        HeadersOn,
        HorizontalHeaderTags,
        VerticalHeaderTags,
        Zoom,
        xAxisScale,
        SvgImage,
        SvgFilename,
        SUICoreVersion,
        SUIEditorVersion,
        SUIObjectFactory,
        SUIStyleSheet,
        CellName,
        FileName,
        StyleSheetClass,
        BusyIndicatorImage,
        HoverBGColor,
        PlaceHolderText,
        Url,
        Html,
        ZoomFactor,
        RowHeights,
        Namespace,
        ClassName,
        Invalid
    }Type; // be sure to keep option Invalid as the last one.

    static std::string toString(Type type);

    static Type fromString(const std::string &type);

private:
    static const std::map<Type, const std::string> typeStringMap;
    static const std::map<const std::string, Type> stringTypeMap;

    static const std::map<const std::string, Type> createStringTypeMap();


};
}

#endif // SUIOBJECTPROPERTYTYPEENUM_H
