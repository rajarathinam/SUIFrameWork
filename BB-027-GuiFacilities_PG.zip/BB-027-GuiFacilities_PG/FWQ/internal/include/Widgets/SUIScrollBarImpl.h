//-----------------------------------------------------------------------------|
//                                                                             |
//                            C++ Header File                                  |
//                                                                             |
//-----------------------------------------------------------------------------|
//
// Ident        : SUIScrollBarImpl.h
// Author       : Jan-Pieter Diender
// Description  : Header file for class SUI::ScrollBarImpl.
//
// ! \file        SUIProgressBarImpl.h
// ! \brief       Header file for class SUI::ScrollBarImpl.
//
//-----------------------------------------------------------------------------|
//                                                                             |
//        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
//                           All rights reserved                               |
//                                                                             |
//-----------------------------------------------------------------------------|

#ifndef SUISCROLLBARIMPL_H
#define SUISCROLLBARIMPL_H

#include "FWQxWidgets/SUIScrollBar.h"
#include "SUIBaseWidget.h"

#include <QScrollBar>


namespace SUI
{

/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The ScrollBarImpl class
 */
class ScrollBarImpl: public BaseWidget, public ScrollBar
{
    Q_OBJECT

public:
    explicit ScrollBarImpl(QWidget *parent = NULL);
    virtual ~ScrollBarImpl();

    virtual void setDefaultProperties(const ObjectContext &context);
    virtual QScrollBar *getWidget() const;

    virtual void setPropertyValue(ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

    virtual OrientationEnum::Orientation getOrientation() const;
    virtual void setOrientation(OrientationEnum::Orientation orientation);

    virtual void setValue(const int thumbPosition);
    virtual int getValue() const;

    virtual void setMinValue(const int val);
    virtual int getMinValue() const;
    virtual void setMaxValue(const int val);
    virtual int getMaxValue() const;

    virtual void setStepSize(const int val);
    virtual int getStepSize() const;

    virtual void setPageStep(const int val);
    virtual int getPageStep() const;

    virtual void setStepSizeValueToFactor(const bool on);

protected:
    virtual bool eventFilter(QObject *obj, QEvent *event);

private:
    void updateTooltip();
    QString getDefaultTooltip() const;

private slots:
    void onValueChanged();
    void onSliderPressed();
    void onSliderReleased();

private:
    OrientationEnum::Orientation mOrientation;
    bool mCreateDefaultTooltip;
    bool mDragging;

    ScrollBarImpl();
    ScrollBarImpl(const ScrollBarImpl& rhs);
    ScrollBarImpl &operator=(const ScrollBarImpl &rhs);
};

} // namespace SUI

#endif // SUISCROLLBARIMPL_H
