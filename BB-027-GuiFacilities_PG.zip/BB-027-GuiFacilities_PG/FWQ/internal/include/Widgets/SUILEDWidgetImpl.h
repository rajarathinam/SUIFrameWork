//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::LEDWidgetImpl.
// !\description Header file for class SUI::LEDWidgetImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUILEDWIDGETIMPL_H
#define SUILEDWIDGETIMPL_H

#include <QLabel>

#include "FWQxWidgets/SUILEDWidget.h"

#include "SUIBaseWidget.h"

namespace SUI {
class SUI_DEPRECATED LEDWidgetImpl : public BaseWidget, public LEDWidget
{
    Q_OBJECT
public:
    explicit LEDWidgetImpl(QWidget *parent = NULL);
    virtual ~LEDWidgetImpl() {}

    virtual QLabel *getWidget() const;
    virtual void setDefaultProperties(const ObjectContext &context);
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

    virtual SUI::ColorEnum::Color getColor() const;
    virtual void setColor(const SUI::ColorEnum::Color color);

private:
    LEDWidgetImpl(const LEDWidgetImpl &rhs);
    LEDWidgetImpl &operator=(const LEDWidgetImpl &rhs);

};
}

#endif // SUILEDWIDGETIMPL_H
