//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::CheckBoxImpl.
// !\description Header file for class SUI::CheckBoxImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUICHECKBOXIMPL_H
#define SUICHECKBOXIMPL_H

#include <QCheckBox>

#include "FWQxWidgets/SUICheckBox.h"
#include "SUIBaseWidget.h"

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The CheckBox class
 */
class CheckBoxImpl: public BaseWidget, public CheckBox
{
    Q_OBJECT

public:
    explicit CheckBoxImpl(QWidget *parent = NULL);

    virtual void setDefaultProperties(const ObjectContext &context);
    virtual QCheckBox *getWidget() const;

    virtual void setPropertyValue(ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

    virtual void setChecked(bool checked);
    virtual bool isChecked() const;

    virtual void setText(const std::string &value);
    virtual std::string getText() const;
    virtual void clearText();
    virtual void setBold(bool bold);
    virtual bool isBold() const;

private slots:
    void handleCheckedChanged(bool newState);

private:
    CheckBoxImpl(const CheckBoxImpl &rhs);
    CheckBoxImpl &operator=(const CheckBoxImpl &rhs);

};
}

#endif // SUICHECKBOXIMPL_H
