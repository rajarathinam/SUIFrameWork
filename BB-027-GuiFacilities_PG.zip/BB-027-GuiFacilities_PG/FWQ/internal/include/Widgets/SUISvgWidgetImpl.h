//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::SvgWidgetImpl.
// !\description Header file for class SUI::SvgWidgetImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUISVGWIDGETIMPL_H
#define SUISVGWIDGETIMPL_H

#include <QFileInfo>
#include <QDomDocument>
#include <QSvgWidget>
#include <QMessageBox>
#include <QSvgRenderer>
#include <QSvgGenerator>
#include <QPainter>

#include "SUIBaseWidget.h"
#include "FWQxWidgets/SUISvgWidget.h"
#include "FWQxCore/SUIXmlException.h"

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The SvgWidget class
 */
class SUI_DEPRECATED SvgWidgetImpl : public BaseWidget, public SvgWidget
{
    Q_OBJECT

public:

    explicit SvgWidgetImpl(QWidget *parent = NULL);
    virtual ~SvgWidgetImpl();

    virtual QSvgWidget *getWidget() const;

    virtual void setDefaultProperties(const ObjectContext &context);
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

    virtual std::list<std::string> getElementIdList(void);
    virtual void setImage(const std::string &value);

    virtual void setElementColor(const std::string idvalue, const SUI::ColorEnum::Color color);
    virtual void setElementBorderColor(const std::string idvalue, const SUI::ColorEnum::Color borderColor);
    virtual void setElementText(const std::string idvalue, const std::string text);
    void setElementBorderWidth(const std::string idvalue, const int borderWidth);
    void setElementTextColor(const std::string idvalue, const SUI::ColorEnum::Color color);
    void setElementToolTip(const std::string idvalue, const std::string tipText);
    std::string getElementToolTip(const std::string idvalue);

protected:
    virtual bool event(QEvent *event);

private:
    void recursiveParseSvgImage(QDomNode node);
    void parseSvgImage(void);

    QStringList mIdTaglist;
    QDomDocument mSvgDomDocument;
    QHash<QString, QDomNode> mDomNodeForElement;

    SvgWidgetImpl(const SvgWidgetImpl &rhs);
    SvgWidgetImpl &operator=(const SvgWidgetImpl &rhs);
};
}

#endif // SUISVGWIDGETIMPL_H
