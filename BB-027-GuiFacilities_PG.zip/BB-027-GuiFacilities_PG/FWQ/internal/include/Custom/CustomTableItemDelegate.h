//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class CustomTableItemDelegate.
// !\description Header file for class CustomTableItemDelegate.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef CUSTOMTABLEITEMDELEGATE_H
#define CUSTOMTABLEITEMDELEGATE_H

#include <QStyledItemDelegate>

class QWidget;

namespace SUI {

class CustomTableItemDelegate : public QStyledItemDelegate
{
    Q_OBJECT
public:
    explicit CustomTableItemDelegate(QObject *parent);
    enum HoverBehavior {
           HoverItems,
           HoverRows,
           HoverColumns
       };
    void setHoverBehavior(const HoverBehavior behavior);

protected:
    virtual void paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const;

private:
    static const QString ADT_TABLEHOVER_COLOR;
    static const QString ONEGUI_TABLEHOVER_COLOR;
    static const std::string ADT_STYLESHEETNAME;
    HoverBehavior hoverBehavior;
};

}
#endif // CUSTOMTABLEITEMDELEGATE_H
