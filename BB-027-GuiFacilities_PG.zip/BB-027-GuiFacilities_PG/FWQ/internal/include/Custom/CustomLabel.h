//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class CustomLabel.
// !\description Header file for class CustomLabel.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef CUSTOMLABEL_H
#define CUSTOMLABEL_H

#include <QLabel>

class CustomLabel : public QLabel
{
    Q_OBJECT
public:
    explicit CustomLabel(QWidget *parent = NULL);

    virtual bool setHighlightText(const QString &searchText, const QColor &color);

protected:
    virtual void mousePressEvent(QMouseEvent *event);
    virtual void hideEvent(QHideEvent *event);
    virtual void showEvent(QShowEvent *event);
    virtual void paintEvent(QPaintEvent *event);

signals:
    void select();

    void visibilityChanged(bool isVisible);
private :

    QString mSearchString;
    QString mHighlightBeginString;
    QColor mHighlightColor;
    bool mDoHighlight;
};

#endif // CUSTOMLABEL_H
