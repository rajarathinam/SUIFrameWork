//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class CustomDoubleSpinBox.
// !\description Header file for class CustomDoubleSpinBox.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef CUSTOMDOUBLESPINBOX_H
#define CUSTOMDOUBLESPINBOX_H

#include <QDoubleSpinBox>

class CustomDoubleSpinBox : public QDoubleSpinBox
{
    Q_OBJECT
public:
    explicit CustomDoubleSpinBox(QWidget *parent = NULL);

    virtual void stepBy(int steps);
    void setStepSizeValueToFactor(const bool on);

private:
    bool mValueIsFactor;

    CustomDoubleSpinBox();
    CustomDoubleSpinBox(const CustomDoubleSpinBox &rhs);
    CustomDoubleSpinBox &operator=(const CustomDoubleSpinBox &rhs);
};

#endif // CUSTOMDOUBLESPINBOX_H
