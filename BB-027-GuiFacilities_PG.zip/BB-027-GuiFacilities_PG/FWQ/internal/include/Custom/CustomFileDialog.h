//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class CustomFileDialog.
// !\description Header file for class CustomFileDialog.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef CUSTOMFILEDIALOG_H
#define CUSTOMFILEDIALOG_H

#include <QFileDialog>

class QWidget;

class CustomFileDialog : public QFileDialog //to access events
{
    Q_OBJECT
public:
    explicit CustomFileDialog(QWidget *parent = NULL);

protected:
    virtual void changeEvent(QEvent *e);

    // there is no workable mouse press event for QFileDialog object;
    // it only works on the dialog and not the different items on the dialog
    // how to access the listView items of QFileDialog?
    virtual void mousePressEvent(QMouseEvent *e);


};

#endif // CUSTOMFILEDIALOG_H
