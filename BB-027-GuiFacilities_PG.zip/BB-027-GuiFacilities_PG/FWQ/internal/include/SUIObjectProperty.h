//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ObjectProperty.
// !\description Header file for class SUI::ObjectProperty.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIOBJECTPROPERTY_H
#define SUIOBJECTPROPERTY_H

#include "SUIObjectPropertyTypeEnum.h"

#include <QString>

namespace SUI {

class BaseObject;

class ObjectProperty
{
public:
    typedef enum
    {
        String,
        Enum,
        Number,
        Science,
        Double,
        File,
        Bool,
        DropDown,
        IndexedValue
    } ObjectPropertyDataType;


    ObjectProperty(SUI::ObjectPropertyTypeEnum::Type objectPropertyType,
            QString description_t,
            ObjectPropertyDataType type_t,
            QString values_t,
            QString defaultValue_t,
            bool readOnly_t = false,
            bool visible_t = true,
            QString displayName_t = "");

    ObjectProperty(const ObjectProperty &copy);
    ObjectProperty& operator=(const ObjectProperty &copy);

    SUI::ObjectPropertyTypeEnum::Type getObjectPropertyType() const;

    QString getDisplayName() const;
    QString getDescription() const;

    ObjectPropertyDataType getType() const;
    QString getDefaultValue() const;

    void setValue(const QString &value);
    QString getValue() const;

    void setReadOnly(bool ro = true);
    bool isReadOnly() const;

    void setVisible(bool enable = true);
    void setHidden();
    bool isVisible() const;

    void setValues(const QString &values);
    QString getValues() const;

    void setMinValue(double val);
    double getMinValue() const;

    void setMaxValue(double val);
    double getMaxValue() const;

    void setCurrentIndex(int val);
    int getCurrentIndex() const;

    static int maxHeight; // 2160 "4K UHD"
    static int maxWidth; // 3840 "4K UHD"

    static void setPropertyTypes(BaseObject *object);
    static const std::vector<ObjectPropertyTypeEnum::Type> getObjectPropertyTypes(ObjectType::Type type);
    static const ObjectProperty getDefaultObjectProperty(ObjectPropertyTypeEnum::Type type);

    static const std::vector<ObjectPropertyTypeEnum::Type> getBaseObjectPropertyTypes();
    static const std::vector<ObjectPropertyTypeEnum::Type> getBaseWidgetPropertyTypes();    
    static const std::vector<ObjectPropertyTypeEnum::Type> getBaseGraphicsItemPropertyTypes();

private:
    void restrictMaxValueByName();
    void defineValueRangeByValues(const QString &separator);

private:
    SUI::ObjectPropertyTypeEnum::Type objectPropertyType;

    QString description;

    ObjectPropertyDataType type;

    QString values;
    QString defaultValue;
    QString value;

    bool readOnly;
    bool visible;

    double minValue;
    double maxValue;
    int mCurrentIndex;

    QString displayName;

    typedef std::vector<ObjectPropertyTypeEnum::Type> StaticObjectPropertyTypes;
    static const std::map<ObjectType::Type, const StaticObjectPropertyTypes> objectPropertyTypes;
    static const std::map<ObjectPropertyTypeEnum::Type, const ObjectProperty> defaultObjectPropertyTypes;

    static const std::map<ObjectPropertyTypeEnum::Type, const ObjectProperty> createDefaultObjectPropertyTypes();

};
}

#endif // SUIOBJECTPROPERTY_H
