//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::StyleSheet.
// !\description Header file for class SUI::StyleSheet.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUISTYLESHEET_H
#define SUISTYLESHEET_H

#include "FWQxCore/SUIObjectType.h"
#include <string>
#include <list>

namespace SUI {

class StyleSheet
{
public:

    static SUI::StyleSheet *getInstance();

    std::string getStyleSheet() const;
    std::string getStyleSheetName() const;
    void setStyleSheet(const std::string &styleSheet);

    std::list<std::string> getStyleSheetClassByObjectType(const ObjectType::Type &ObjectType = SUI::ObjectType::None);

private:
    static const std::string ADT_STYLESHEETNAME;
    static const std::string ONEGUI_STYLESHEETNAME;
    static const std::string ADT_STYLESHEETPATH;
    static const std::string ONEGUI_STYLESHEETPATH;

    std::string m_styleSheet;
    static std::string m_styleSheetPath;
    static std::string m_styleSheetName;

    static std::string readStyleSheet();
    typedef std::list<std::string> StaticStyleSheetClassList;
    static std::map<SUI::ObjectType::Type,const StaticStyleSheetClassList> m_styleSheetClassByObjectType;

    StyleSheet();
    StyleSheet(const StyleSheet&);
    StyleSheet &operator=(const StyleSheet &);
};

} // namespace SUI

#endif // SUI_STYLESHEET_H
