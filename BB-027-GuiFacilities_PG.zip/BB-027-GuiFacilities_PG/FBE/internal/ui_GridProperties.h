/********************************************************************************
** Form generated from reading UI file 'GridProperties.ui'
**
** Created: Wed Jan 17 21:09:12 2018
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GRIDPROPERTIES_H
#define UI_GRIDPROPERTIES_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QSpinBox>

QT_BEGIN_NAMESPACE

class Ui_GridProperties
{
public:
    QPushButton *mOkPB;
    QPushButton *mCancelPB;
    QLabel *label;
    QLabel *label_2;
    QSpinBox *mXGridSB;
    QSpinBox *mYGridSB;
    QCheckBox *mXSnapCB;
    QCheckBox *mYSnapCB;
    QCheckBox *mGridActiveCB;

    void setupUi(QDialog *GridProperties)
    {
        if (GridProperties->objectName().isEmpty())
            GridProperties->setObjectName(QString::fromUtf8("GridProperties"));
        GridProperties->resize(222, 160);
        mOkPB = new QPushButton(GridProperties);
        mOkPB->setObjectName(QString::fromUtf8("mOkPB"));
        mOkPB->setGeometry(QRect(120, 120, 81, 22));
        mCancelPB = new QPushButton(GridProperties);
        mCancelPB->setObjectName(QString::fromUtf8("mCancelPB"));
        mCancelPB->setGeometry(QRect(20, 120, 81, 22));
        label = new QLabel(GridProperties);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 50, 40, 20));
        label_2 = new QLabel(GridProperties);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(20, 80, 40, 20));
        mXGridSB = new QSpinBox(GridProperties);
        mXGridSB->setObjectName(QString::fromUtf8("mXGridSB"));
        mXGridSB->setGeometry(QRect(80, 50, 48, 23));
        mXGridSB->setMinimum(3);
        mXGridSB->setMaximum(100);
        mYGridSB = new QSpinBox(GridProperties);
        mYGridSB->setObjectName(QString::fromUtf8("mYGridSB"));
        mYGridSB->setGeometry(QRect(80, 80, 48, 23));
        mYGridSB->setMinimum(3);
        mYGridSB->setMaximum(100);
        mXSnapCB = new QCheckBox(GridProperties);
        mXSnapCB->setObjectName(QString::fromUtf8("mXSnapCB"));
        mXSnapCB->setGeometry(QRect(150, 50, 71, 20));
        mYSnapCB = new QCheckBox(GridProperties);
        mYSnapCB->setObjectName(QString::fromUtf8("mYSnapCB"));
        mYSnapCB->setGeometry(QRect(150, 80, 71, 20));
        mGridActiveCB = new QCheckBox(GridProperties);
        mGridActiveCB->setObjectName(QString::fromUtf8("mGridActiveCB"));
        mGridActiveCB->setGeometry(QRect(20, 20, 181, 20));

        retranslateUi(GridProperties);

        QMetaObject::connectSlotsByName(GridProperties);
    } // setupUi

    void retranslateUi(QDialog *GridProperties)
    {
        GridProperties->setWindowTitle(QApplication::translate("GridProperties", "Dialog", 0, QApplication::UnicodeUTF8));
        mOkPB->setText(QApplication::translate("GridProperties", "Ok", 0, QApplication::UnicodeUTF8));
        mCancelPB->setText(QApplication::translate("GridProperties", "Cancel", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("GridProperties", "X Grid:", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("GridProperties", "Y Grid:", 0, QApplication::UnicodeUTF8));
        mXSnapCB->setText(QApplication::translate("GridProperties", "Snap", 0, QApplication::UnicodeUTF8));
        mYSnapCB->setText(QApplication::translate("GridProperties", "Snap", 0, QApplication::UnicodeUTF8));
        mGridActiveCB->setText(QApplication::translate("GridProperties", "Grid Active", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class GridProperties: public Ui_GridProperties {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GRIDPROPERTIES_H
