/********************************************************************************
** Form generated from reading UI file 'Itemwidgetdialog.ui'
**
** Created: Wed Jan 17 21:09:12 2018
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ITEMWIDGETDIALOG_H
#define UI_ITEMWIDGETDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QComboBox>
#include <QtGui/QDialog>
#include <QtGui/QGroupBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QRadioButton>
#include <QtGui/QSpinBox>

QT_BEGIN_NAMESPACE

class Ui_Itemwidgetdialog
{
public:
    QGroupBox *mChoiceGB;
    QRadioButton *mRowsRB;
    QRadioButton *mColumnsRB;
    QRadioButton *mSingleCellRB;
    QLabel *mSelectionLB;
    QSpinBox *mStartSB;
    QLabel *mStartLB;
    QSpinBox *mEndSB;
    QLabel *mEndLB;
    QComboBox *mWidgetTypeCB;
    QLabel *mSelectTypeLB;
    QPushButton *mOkPB;
    QPushButton *mCancelPB;
    QCheckBox *mBorderOnCB;

    void setupUi(QDialog *Itemwidgetdialog)
    {
        if (Itemwidgetdialog->objectName().isEmpty())
            Itemwidgetdialog->setObjectName(QString::fromUtf8("Itemwidgetdialog"));
        Itemwidgetdialog->resize(364, 264);
        mChoiceGB = new QGroupBox(Itemwidgetdialog);
        mChoiceGB->setObjectName(QString::fromUtf8("mChoiceGB"));
        mChoiceGB->setGeometry(QRect(20, 20, 320, 70));
        mRowsRB = new QRadioButton(mChoiceGB);
        mRowsRB->setObjectName(QString::fromUtf8("mRowsRB"));
        mRowsRB->setGeometry(QRect(10, 30, 91, 22));
        mColumnsRB = new QRadioButton(mChoiceGB);
        mColumnsRB->setObjectName(QString::fromUtf8("mColumnsRB"));
        mColumnsRB->setGeometry(QRect(110, 30, 91, 22));
        mSingleCellRB = new QRadioButton(mChoiceGB);
        mSingleCellRB->setObjectName(QString::fromUtf8("mSingleCellRB"));
        mSingleCellRB->setGeometry(QRect(210, 30, 101, 22));
        mSelectionLB = new QLabel(Itemwidgetdialog);
        mSelectionLB->setObjectName(QString::fromUtf8("mSelectionLB"));
        mSelectionLB->setGeometry(QRect(20, 100, 140, 20));
        mStartSB = new QSpinBox(Itemwidgetdialog);
        mStartSB->setObjectName(QString::fromUtf8("mStartSB"));
        mStartSB->setGeometry(QRect(80, 130, 49, 27));
        mStartLB = new QLabel(Itemwidgetdialog);
        mStartLB->setObjectName(QString::fromUtf8("mStartLB"));
        mStartLB->setGeometry(QRect(20, 130, 62, 20));
        mEndSB = new QSpinBox(Itemwidgetdialog);
        mEndSB->setObjectName(QString::fromUtf8("mEndSB"));
        mEndSB->setGeometry(QRect(80, 170, 49, 27));
        mEndLB = new QLabel(Itemwidgetdialog);
        mEndLB->setObjectName(QString::fromUtf8("mEndLB"));
        mEndLB->setGeometry(QRect(20, 170, 62, 20));
        mWidgetTypeCB = new QComboBox(Itemwidgetdialog);
        mWidgetTypeCB->setObjectName(QString::fromUtf8("mWidgetTypeCB"));
        mWidgetTypeCB->setGeometry(QRect(140, 130, 200, 27));
        mSelectTypeLB = new QLabel(Itemwidgetdialog);
        mSelectTypeLB->setObjectName(QString::fromUtf8("mSelectTypeLB"));
        mSelectTypeLB->setGeometry(QRect(150, 100, 130, 20));
        mOkPB = new QPushButton(Itemwidgetdialog);
        mOkPB->setObjectName(QString::fromUtf8("mOkPB"));
        mOkPB->setGeometry(QRect(250, 220, 93, 27));
        mCancelPB = new QPushButton(Itemwidgetdialog);
        mCancelPB->setObjectName(QString::fromUtf8("mCancelPB"));
        mCancelPB->setGeometry(QRect(140, 220, 93, 27));
        mBorderOnCB = new QCheckBox(Itemwidgetdialog);
        mBorderOnCB->setObjectName(QString::fromUtf8("mBorderOnCB"));
        mBorderOnCB->setGeometry(QRect(150, 170, 201, 20));

        retranslateUi(Itemwidgetdialog);

        QMetaObject::connectSlotsByName(Itemwidgetdialog);
    } // setupUi

    void retranslateUi(QDialog *Itemwidgetdialog)
    {
        Itemwidgetdialog->setWindowTitle(QApplication::translate("Itemwidgetdialog", "Dialog", 0, QApplication::UnicodeUTF8));
        mChoiceGB->setTitle(QApplication::translate("Itemwidgetdialog", "Set items for", 0, QApplication::UnicodeUTF8));
        mRowsRB->setText(QApplication::translate("Itemwidgetdialog", "Rows", 0, QApplication::UnicodeUTF8));
        mColumnsRB->setText(QApplication::translate("Itemwidgetdialog", "Columns", 0, QApplication::UnicodeUTF8));
        mSingleCellRB->setText(QApplication::translate("Itemwidgetdialog", "Single Cell", 0, QApplication::UnicodeUTF8));
        mSelectionLB->setText(QApplication::translate("Itemwidgetdialog", "Select Rows", 0, QApplication::UnicodeUTF8));
        mStartLB->setText(QApplication::translate("Itemwidgetdialog", "Start:", 0, QApplication::UnicodeUTF8));
        mEndLB->setText(QApplication::translate("Itemwidgetdialog", "End:", 0, QApplication::UnicodeUTF8));
        mSelectTypeLB->setText(QApplication::translate("Itemwidgetdialog", "Select Widget Type", 0, QApplication::UnicodeUTF8));
        mOkPB->setText(QApplication::translate("Itemwidgetdialog", "Ok", 0, QApplication::UnicodeUTF8));
        mCancelPB->setText(QApplication::translate("Itemwidgetdialog", "Cancel", 0, QApplication::UnicodeUTF8));
        mBorderOnCB->setText(QApplication::translate("Itemwidgetdialog", "Set border line on", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Itemwidgetdialog: public Ui_Itemwidgetdialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ITEMWIDGETDIALOG_H
