/********************************************************************************
** Form generated from reading UI file 'headertreewidgetdialog.ui'
**
** Created: Wed Jan 17 21:09:12 2018
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HEADERTREEWIDGETDIALOG_H
#define UI_HEADERTREEWIDGETDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QPushButton>
#include <QtGui/QTreeWidget>

QT_BEGIN_NAMESPACE

class Ui_headerTreeWidgetDialog
{
public:
    QTreeWidget *treeWidget;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;

    void setupUi(QDialog *headerTreeWidgetDialog)
    {
        if (headerTreeWidgetDialog->objectName().isEmpty())
            headerTreeWidgetDialog->setObjectName(QString::fromUtf8("headerTreeWidgetDialog"));
        headerTreeWidgetDialog->resize(400, 300);
        treeWidget = new QTreeWidget(headerTreeWidgetDialog);
        QTreeWidgetItem *__qtreewidgetitem = new QTreeWidgetItem();
        __qtreewidgetitem->setText(0, QString::fromUtf8("1"));
        treeWidget->setHeaderItem(__qtreewidgetitem);
        treeWidget->setObjectName(QString::fromUtf8("treeWidget"));
        treeWidget->setGeometry(QRect(10, 10, 381, 241));
        pushButton = new QPushButton(headerTreeWidgetDialog);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(10, 270, 51, 22));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/image/arrow.png"), QSize(), QIcon::Normal, QIcon::On);
        pushButton->setIcon(icon);
        pushButton_2 = new QPushButton(headerTreeWidgetDialog);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(130, 270, 51, 22));
        pushButton_3 = new QPushButton(headerTreeWidgetDialog);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(70, 270, 51, 22));
        pushButton_4 = new QPushButton(headerTreeWidgetDialog);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(310, 270, 81, 22));

        retranslateUi(headerTreeWidgetDialog);

        QMetaObject::connectSlotsByName(headerTreeWidgetDialog);
    } // setupUi

    void retranslateUi(QDialog *headerTreeWidgetDialog)
    {
        headerTreeWidgetDialog->setWindowTitle(QApplication::translate("headerTreeWidgetDialog", "Dialog", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QString());
        pushButton_2->setText(QApplication::translate("headerTreeWidgetDialog", "-", 0, QApplication::UnicodeUTF8));
        pushButton_3->setText(QApplication::translate("headerTreeWidgetDialog", "+", 0, QApplication::UnicodeUTF8));
        pushButton_4->setText(QApplication::translate("headerTreeWidgetDialog", "OK", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class headerTreeWidgetDialog: public Ui_headerTreeWidgetDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HEADERTREEWIDGETDIALOG_H
