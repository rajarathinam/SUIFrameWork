/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created: Wed Jan 17 21:09:12 2018
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QGridLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QScrollArea>
#include <QtGui/QSplitter>
#include <QtGui/QStatusBar>
#include <QtGui/QTreeView>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>
#include <usercontrolselector.h>
#include "formeditor.h"
#include "propertieseditor.h"
#include "widgetselector.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *action_Open;
    QAction *action_Save;
    QAction *action_Quit;
    QAction *actionForm_Properties;
    QAction *action_Copy;
    QAction *action_Paste;
    QAction *actionAdd_Standard_Button_area;
    QAction *action_New;
    QAction *actionSave_As;
    QAction *actionImport_UserControl;
    QAction *actionTo_Forground;
    QAction *actionTo_Background;
    QAction *actionForward;
    QAction *actionBackward;
    QAction *actionEdit_Items;
    QAction *actionClear_Items;
    QAction *actionAddTabPage;
    QAction *actionNext_Page;
    QAction *actionPrev_Page;
    QAction *actionRename_Tab_Page;
    QAction *actionMoveNextAct;
    QAction *actionMovePrevAct;
    QAction *actionDeleteAct;
    QAction *actionAdd_States;
    QAction *recentFilesMenu;
    QAction *actionPreview;
    QAction *actionTreewidget_edit;
    QAction *actionCollapseAll;
    QAction *actionExpandAll;
    QAction *action_Undo;
    QAction *action_Redo;
    QAction *actionShow_Undo_Buffer;
    QAction *actionGrid_Enabled;
    QAction *actionGrid_Options;
    QAction *actionGenerate_MOC_Files;
    QAction *actionGenerate_CPP;
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QSplitter *splitter_3;
    QSplitter *splitter;
    QWidget *widget_2;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_2;
    QScrollArea *scrollArea_2;
    WidgetSelector *widgetSelector;
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QScrollArea *scrollArea_3;
    UserControlSelector *usercontrolSelector;
    QScrollArea *scrollArea;
    FormEditor *frmFormEditor;
    QSplitter *splitter_2;
    QTreeView *m_ObjectTV;
    PropertiesEditor *m_PropertyTW;
    QMenuBar *menubar;
    QMenu *menu_File;
    QMenu *menu_Edit;
    QMenu *menuTools;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1019, 504);
        MainWindow->setMinimumSize(QSize(1000, 500));
        MainWindow->setMaximumSize(QSize(16777215, 16777215));
        action_Open = new QAction(MainWindow);
        action_Open->setObjectName(QString::fromUtf8("action_Open"));
        action_Save = new QAction(MainWindow);
        action_Save->setObjectName(QString::fromUtf8("action_Save"));
        action_Quit = new QAction(MainWindow);
        action_Quit->setObjectName(QString::fromUtf8("action_Quit"));
        actionForm_Properties = new QAction(MainWindow);
        actionForm_Properties->setObjectName(QString::fromUtf8("actionForm_Properties"));
        action_Copy = new QAction(MainWindow);
        action_Copy->setObjectName(QString::fromUtf8("action_Copy"));
        action_Copy->setEnabled(true);
        action_Paste = new QAction(MainWindow);
        action_Paste->setObjectName(QString::fromUtf8("action_Paste"));
        actionAdd_Standard_Button_area = new QAction(MainWindow);
        actionAdd_Standard_Button_area->setObjectName(QString::fromUtf8("actionAdd_Standard_Button_area"));
        action_New = new QAction(MainWindow);
        action_New->setObjectName(QString::fromUtf8("action_New"));
        actionSave_As = new QAction(MainWindow);
        actionSave_As->setObjectName(QString::fromUtf8("actionSave_As"));
        actionImport_UserControl = new QAction(MainWindow);
        actionImport_UserControl->setObjectName(QString::fromUtf8("actionImport_UserControl"));
        actionTo_Forground = new QAction(MainWindow);
        actionTo_Forground->setObjectName(QString::fromUtf8("actionTo_Forground"));
        actionTo_Background = new QAction(MainWindow);
        actionTo_Background->setObjectName(QString::fromUtf8("actionTo_Background"));
        actionForward = new QAction(MainWindow);
        actionForward->setObjectName(QString::fromUtf8("actionForward"));
        actionBackward = new QAction(MainWindow);
        actionBackward->setObjectName(QString::fromUtf8("actionBackward"));
        actionEdit_Items = new QAction(MainWindow);
        actionEdit_Items->setObjectName(QString::fromUtf8("actionEdit_Items"));
        actionClear_Items = new QAction(MainWindow);
        actionClear_Items->setObjectName(QString::fromUtf8("actionClear_Items"));
        actionAddTabPage = new QAction(MainWindow);
        actionAddTabPage->setObjectName(QString::fromUtf8("actionAddTabPage"));
        actionNext_Page = new QAction(MainWindow);
        actionNext_Page->setObjectName(QString::fromUtf8("actionNext_Page"));
        actionPrev_Page = new QAction(MainWindow);
        actionPrev_Page->setObjectName(QString::fromUtf8("actionPrev_Page"));
        actionRename_Tab_Page = new QAction(MainWindow);
        actionRename_Tab_Page->setObjectName(QString::fromUtf8("actionRename_Tab_Page"));
        actionMoveNextAct = new QAction(MainWindow);
        actionMoveNextAct->setObjectName(QString::fromUtf8("actionMoveNextAct"));
        actionMovePrevAct = new QAction(MainWindow);
        actionMovePrevAct->setObjectName(QString::fromUtf8("actionMovePrevAct"));
        actionDeleteAct = new QAction(MainWindow);
        actionDeleteAct->setObjectName(QString::fromUtf8("actionDeleteAct"));
        actionAdd_States = new QAction(MainWindow);
        actionAdd_States->setObjectName(QString::fromUtf8("actionAdd_States"));
        recentFilesMenu = new QAction(MainWindow);
        recentFilesMenu->setObjectName(QString::fromUtf8("recentFilesMenu"));
        actionPreview = new QAction(MainWindow);
        actionPreview->setObjectName(QString::fromUtf8("actionPreview"));
        actionTreewidget_edit = new QAction(MainWindow);
        actionTreewidget_edit->setObjectName(QString::fromUtf8("actionTreewidget_edit"));
        actionCollapseAll = new QAction(MainWindow);
        actionCollapseAll->setObjectName(QString::fromUtf8("actionCollapseAll"));
        actionExpandAll = new QAction(MainWindow);
        actionExpandAll->setObjectName(QString::fromUtf8("actionExpandAll"));
        action_Undo = new QAction(MainWindow);
        action_Undo->setObjectName(QString::fromUtf8("action_Undo"));
        action_Redo = new QAction(MainWindow);
        action_Redo->setObjectName(QString::fromUtf8("action_Redo"));
        actionShow_Undo_Buffer = new QAction(MainWindow);
        actionShow_Undo_Buffer->setObjectName(QString::fromUtf8("actionShow_Undo_Buffer"));
        actionGrid_Enabled = new QAction(MainWindow);
        actionGrid_Enabled->setObjectName(QString::fromUtf8("actionGrid_Enabled"));
        actionGrid_Enabled->setCheckable(true);
        actionGrid_Options = new QAction(MainWindow);
        actionGrid_Options->setObjectName(QString::fromUtf8("actionGrid_Options"));
        actionGenerate_MOC_Files = new QAction(MainWindow);
        actionGenerate_MOC_Files->setObjectName(QString::fromUtf8("actionGenerate_MOC_Files"));
        actionGenerate_CPP = new QAction(MainWindow);
        actionGenerate_CPP->setObjectName(QString::fromUtf8("actionGenerate_CPP"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        splitter_3 = new QSplitter(centralwidget);
        splitter_3->setObjectName(QString::fromUtf8("splitter_3"));
        splitter_3->setOrientation(Qt::Horizontal);
        splitter = new QSplitter(splitter_3);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Vertical);
        widget_2 = new QWidget(splitter);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(20);
        sizePolicy.setHeightForWidth(widget_2->sizePolicy().hasHeightForWidth());
        widget_2->setSizePolicy(sizePolicy);
        verticalLayout_2 = new QVBoxLayout(widget_2);
        verticalLayout_2->setSpacing(0);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(widget_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setMinimumSize(QSize(0, 20));
        label_2->setMaximumSize(QSize(16777215, 20));

        verticalLayout_2->addWidget(label_2);

        scrollArea_2 = new QScrollArea(widget_2);
        scrollArea_2->setObjectName(QString::fromUtf8("scrollArea_2"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(2);
        sizePolicy1.setHeightForWidth(scrollArea_2->sizePolicy().hasHeightForWidth());
        scrollArea_2->setSizePolicy(sizePolicy1);
        scrollArea_2->setMinimumSize(QSize(240, 120));
        scrollArea_2->setWidgetResizable(true);
        widgetSelector = new WidgetSelector();
        widgetSelector->setObjectName(QString::fromUtf8("widgetSelector"));
        widgetSelector->setEnabled(true);
        widgetSelector->setGeometry(QRect(0, 0, 238, 331));
        widgetSelector->setMinimumSize(QSize(140, 0));
        widgetSelector->setAutoFillBackground(true);
        scrollArea_2->setWidget(widgetSelector);

        verticalLayout_2->addWidget(scrollArea_2);

        splitter->addWidget(widget_2);
        widget = new QWidget(splitter);
        widget->setObjectName(QString::fromUtf8("widget"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(1);
        sizePolicy2.setHeightForWidth(widget->sizePolicy().hasHeightForWidth());
        widget->setSizePolicy(sizePolicy2);
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setSpacing(0);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMinimumSize(QSize(0, 20));
        label->setMaximumSize(QSize(16777215, 20));

        verticalLayout->addWidget(label);

        scrollArea_3 = new QScrollArea(widget);
        scrollArea_3->setObjectName(QString::fromUtf8("scrollArea_3"));
        QSizePolicy sizePolicy3(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(50);
        sizePolicy3.setHeightForWidth(scrollArea_3->sizePolicy().hasHeightForWidth());
        scrollArea_3->setSizePolicy(sizePolicy3);
        scrollArea_3->setMinimumSize(QSize(240, 60));
        scrollArea_3->setWidgetResizable(true);
        usercontrolSelector = new UserControlSelector();
        usercontrolSelector->setObjectName(QString::fromUtf8("usercontrolSelector"));
        usercontrolSelector->setGeometry(QRect(0, 0, 220, 400));
        sizePolicy2.setHeightForWidth(usercontrolSelector->sizePolicy().hasHeightForWidth());
        usercontrolSelector->setSizePolicy(sizePolicy2);
        usercontrolSelector->setMinimumSize(QSize(140, 400));
        usercontrolSelector->setAutoFillBackground(true);
        scrollArea_3->setWidget(usercontrolSelector);

        verticalLayout->addWidget(scrollArea_3);

        splitter->addWidget(widget);
        splitter_3->addWidget(splitter);
        scrollArea = new QScrollArea(splitter_3);
        scrollArea->setObjectName(QString::fromUtf8("scrollArea"));
        QSizePolicy sizePolicy4(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy4.setHorizontalStretch(10);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(scrollArea->sizePolicy().hasHeightForWidth());
        scrollArea->setSizePolicy(sizePolicy4);
        scrollArea->setMinimumSize(QSize(320, 0));
        scrollArea->setWidgetResizable(true);
        frmFormEditor = new FormEditor();
        frmFormEditor->setObjectName(QString::fromUtf8("frmFormEditor"));
        frmFormEditor->setEnabled(true);
        frmFormEditor->setGeometry(QRect(0, 0, 318, 437));
        QSizePolicy sizePolicy5(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy5.setHorizontalStretch(0);
        sizePolicy5.setVerticalStretch(0);
        sizePolicy5.setHeightForWidth(frmFormEditor->sizePolicy().hasHeightForWidth());
        frmFormEditor->setSizePolicy(sizePolicy5);
        frmFormEditor->setMinimumSize(QSize(0, 0));
        frmFormEditor->setBaseSize(QSize(500, 0));
        scrollArea->setWidget(frmFormEditor);
        splitter_3->addWidget(scrollArea);
        splitter_2 = new QSplitter(splitter_3);
        splitter_2->setObjectName(QString::fromUtf8("splitter_2"));
        QSizePolicy sizePolicy6(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy6.setHorizontalStretch(1);
        sizePolicy6.setVerticalStretch(0);
        sizePolicy6.setHeightForWidth(splitter_2->sizePolicy().hasHeightForWidth());
        splitter_2->setSizePolicy(sizePolicy6);
        splitter_2->setMinimumSize(QSize(160, 0));
        splitter_2->setOrientation(Qt::Vertical);
        m_ObjectTV = new QTreeView(splitter_2);
        m_ObjectTV->setObjectName(QString::fromUtf8("m_ObjectTV"));
        splitter_2->addWidget(m_ObjectTV);
        m_PropertyTW = new PropertiesEditor(splitter_2);
        m_PropertyTW->setObjectName(QString::fromUtf8("m_PropertyTW"));
        sizePolicy5.setHeightForWidth(m_PropertyTW->sizePolicy().hasHeightForWidth());
        m_PropertyTW->setSizePolicy(sizePolicy5);
        m_PropertyTW->setAutoFillBackground(true);
        m_PropertyTW->setProperty("alternatingRowColors", QVariant(true));
        splitter_2->addWidget(m_PropertyTW);
        splitter_3->addWidget(splitter_2);

        gridLayout->addWidget(splitter_3, 0, 0, 1, 1);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1019, 25));
        menu_File = new QMenu(menubar);
        menu_File->setObjectName(QString::fromUtf8("menu_File"));
        menu_Edit = new QMenu(menubar);
        menu_Edit->setObjectName(QString::fromUtf8("menu_Edit"));
        menuTools = new QMenu(menubar);
        menuTools->setObjectName(QString::fromUtf8("menuTools"));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        menubar->addAction(menu_File->menuAction());
        menubar->addAction(menu_Edit->menuAction());
        menubar->addAction(menuTools->menuAction());
        menu_File->addAction(action_New);
        menu_File->addAction(action_Open);
        menu_File->addAction(action_Save);
        menu_File->addAction(actionSave_As);
        menu_File->addAction(actionGenerate_MOC_Files);
        menu_File->addAction(actionGenerate_CPP);
        menu_File->addAction(actionImport_UserControl);
        menu_File->addAction(action_Quit);
        menu_Edit->addAction(action_Undo);
        menu_Edit->addAction(action_Redo);
        menu_Edit->addAction(actionForm_Properties);
        menu_Edit->addAction(action_Copy);
        menu_Edit->addAction(action_Paste);
        menu_Edit->addSeparator();
        menu_Edit->addAction(actionTo_Forground);
        menu_Edit->addAction(actionTo_Background);
        menu_Edit->addAction(actionForward);
        menu_Edit->addAction(actionBackward);
        menu_Edit->addSeparator();
        menu_Edit->addAction(actionAdd_Standard_Button_area);
        menu_Edit->addAction(actionShow_Undo_Buffer);
        menuTools->addAction(actionPreview);
        menuTools->addAction(actionGrid_Enabled);
        menuTools->addAction(actionGrid_Options);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Rtic Editor", 0, QApplication::UnicodeUTF8));
        action_Open->setText(QApplication::translate("MainWindow", "&Open", 0, QApplication::UnicodeUTF8));
        action_Save->setText(QApplication::translate("MainWindow", "&Save", 0, QApplication::UnicodeUTF8));
        action_Quit->setText(QApplication::translate("MainWindow", "&Quit", 0, QApplication::UnicodeUTF8));
        actionForm_Properties->setText(QApplication::translate("MainWindow", "&Form Properties", 0, QApplication::UnicodeUTF8));
        action_Copy->setText(QApplication::translate("MainWindow", "&Copy", 0, QApplication::UnicodeUTF8));
        action_Paste->setText(QApplication::translate("MainWindow", "&Paste", 0, QApplication::UnicodeUTF8));
        actionAdd_Standard_Button_area->setText(QApplication::translate("MainWindow", "Add Standard Button area", 0, QApplication::UnicodeUTF8));
        action_New->setText(QApplication::translate("MainWindow", "&New", 0, QApplication::UnicodeUTF8));
        actionSave_As->setText(QApplication::translate("MainWindow", "Save &As", 0, QApplication::UnicodeUTF8));
        actionImport_UserControl->setText(QApplication::translate("MainWindow", "&Import UserControl", 0, QApplication::UnicodeUTF8));
        actionTo_Forground->setText(QApplication::translate("MainWindow", "Move to front", 0, QApplication::UnicodeUTF8));
        actionTo_Background->setText(QApplication::translate("MainWindow", "Move to back", 0, QApplication::UnicodeUTF8));
        actionForward->setText(QApplication::translate("MainWindow", "Move forward", 0, QApplication::UnicodeUTF8));
        actionBackward->setText(QApplication::translate("MainWindow", "Move backward", 0, QApplication::UnicodeUTF8));
        actionEdit_Items->setText(QApplication::translate("MainWindow", "Edit Items", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        actionEdit_Items->setToolTip(QApplication::translate("MainWindow", "Edit Items", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        actionClear_Items->setText(QApplication::translate("MainWindow", "Clear Items", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        actionClear_Items->setToolTip(QApplication::translate("MainWindow", "Clear Items", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        actionAddTabPage->setText(QApplication::translate("MainWindow", "Add Tab Page", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        actionAddTabPage->setToolTip(QApplication::translate("MainWindow", "addTabPageAct", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        actionNext_Page->setText(QApplication::translate("MainWindow", "Goto next Page", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        actionNext_Page->setToolTip(QApplication::translate("MainWindow", "Goto next Page", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        actionPrev_Page->setText(QApplication::translate("MainWindow", "Goto Previous Page", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        actionPrev_Page->setToolTip(QApplication::translate("MainWindow", "Goto Previous Page", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        actionRename_Tab_Page->setText(QApplication::translate("MainWindow", "Rename Tab Page", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        actionRename_Tab_Page->setToolTip(QApplication::translate("MainWindow", "rename Tab Page", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        actionMoveNextAct->setText(QApplication::translate("MainWindow", "Move Next Page", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        actionMoveNextAct->setToolTip(QApplication::translate("MainWindow", "Move Next Page", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        actionMovePrevAct->setText(QApplication::translate("MainWindow", "Move Previous Page", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        actionMovePrevAct->setToolTip(QApplication::translate("MainWindow", "Move Previous Page", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        actionDeleteAct->setText(QApplication::translate("MainWindow", "Delete Current Tabpage", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        actionDeleteAct->setToolTip(QApplication::translate("MainWindow", "Delete Current Tabpage", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        actionAdd_States->setText(QApplication::translate("MainWindow", "Add States", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        actionAdd_States->setToolTip(QApplication::translate("MainWindow", "Add States", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        recentFilesMenu->setText(QApplication::translate("MainWindow", "recentFilesMenu", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        recentFilesMenu->setToolTip(QApplication::translate("MainWindow", "recent Files Menu", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        actionPreview->setText(QApplication::translate("MainWindow", "Preview", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        actionPreview->setToolTip(QApplication::translate("MainWindow", "Show Preview", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        actionTreewidget_edit->setText(QApplication::translate("MainWindow", "Treewidget edit", 0, QApplication::UnicodeUTF8));
        actionCollapseAll->setText(QApplication::translate("MainWindow", "Collapse All Children", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        actionCollapseAll->setToolTip(QApplication::translate("MainWindow", "Collapse All Children", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        actionExpandAll->setText(QApplication::translate("MainWindow", "Expand All Children", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        actionExpandAll->setToolTip(QApplication::translate("MainWindow", "Expand All Children", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        action_Undo->setText(QApplication::translate("MainWindow", "&Undo", 0, QApplication::UnicodeUTF8));
        action_Redo->setText(QApplication::translate("MainWindow", "&Redo", 0, QApplication::UnicodeUTF8));
        actionShow_Undo_Buffer->setText(QApplication::translate("MainWindow", "Show Undo Buffer", 0, QApplication::UnicodeUTF8));
        actionGrid_Enabled->setText(QApplication::translate("MainWindow", "Grid Enabled", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        actionGrid_Enabled->setToolTip(QApplication::translate("MainWindow", "Enabled / disable grid", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        actionGrid_Options->setText(QApplication::translate("MainWindow", "Grid Options", 0, QApplication::UnicodeUTF8));
        actionGenerate_MOC_Files->setText(QApplication::translate("MainWindow", "Generate MOC C++", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        actionGenerate_MOC_Files->setToolTip(QApplication::translate("MainWindow", "Generate MOC C++ Files", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        actionGenerate_CPP->setText(QApplication::translate("MainWindow", "Generate C++", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        actionGenerate_CPP->setToolTip(QApplication::translate("MainWindow", "Generate C++ Files", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        label_2->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-weight:600;\">Widgets</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-weight:600;\">User controls</span></p></body></html>", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        m_PropertyTW->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        menu_File->setTitle(QApplication::translate("MainWindow", "&File", 0, QApplication::UnicodeUTF8));
        menu_Edit->setTitle(QApplication::translate("MainWindow", "&Edit", 0, QApplication::UnicodeUTF8));
        menuTools->setTitle(QApplication::translate("MainWindow", "Tools", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
