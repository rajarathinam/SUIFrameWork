/********************************************************************************
** Form generated from reading UI file 'tabbarnamedialog.ui'
**
** Created: Wed Jan 17 21:09:12 2018
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TABBARNAMEDIALOG_H
#define UI_TABBARNAMEDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SetNameDialog
{
public:
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QLabel *mEditLB;
    QLineEdit *mTabNameLE;
    QPushButton *mCancelPB;
    QPushButton *mOkPB;

    void setupUi(QDialog *SetNameDialog)
    {
        if (SetNameDialog->objectName().isEmpty())
            SetNameDialog->setObjectName(QString::fromUtf8("SetNameDialog"));
        SetNameDialog->resize(400, 109);
        layoutWidget = new QWidget(SetNameDialog);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(20, 20, 351, 29));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        mEditLB = new QLabel(layoutWidget);
        mEditLB->setObjectName(QString::fromUtf8("mEditLB"));

        horizontalLayout->addWidget(mEditLB);

        mTabNameLE = new QLineEdit(layoutWidget);
        mTabNameLE->setObjectName(QString::fromUtf8("mTabNameLE"));

        horizontalLayout->addWidget(mTabNameLE);

        mCancelPB = new QPushButton(SetNameDialog);
        mCancelPB->setObjectName(QString::fromUtf8("mCancelPB"));
        mCancelPB->setGeometry(QRect(290, 70, 80, 22));
        mOkPB = new QPushButton(SetNameDialog);
        mOkPB->setObjectName(QString::fromUtf8("mOkPB"));
        mOkPB->setGeometry(QRect(190, 70, 80, 22));
        QWidget::setTabOrder(mTabNameLE, mOkPB);
        QWidget::setTabOrder(mOkPB, mCancelPB);

        retranslateUi(SetNameDialog);

        QMetaObject::connectSlotsByName(SetNameDialog);
    } // setupUi

    void retranslateUi(QDialog *SetNameDialog)
    {
        SetNameDialog->setWindowTitle(QString());
        mEditLB->setText(QApplication::translate("SetNameDialog", "<html><head/><body><p>Tab name:</p></body></html>", 0, QApplication::UnicodeUTF8));
        mCancelPB->setText(QApplication::translate("SetNameDialog", "Cancel", 0, QApplication::UnicodeUTF8));
        mOkPB->setText(QApplication::translate("SetNameDialog", "Ok", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class SetNameDialog: public Ui_SetNameDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TABBARNAMEDIALOG_H
