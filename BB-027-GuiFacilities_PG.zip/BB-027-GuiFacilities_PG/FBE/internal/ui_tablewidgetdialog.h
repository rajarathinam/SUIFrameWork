/********************************************************************************
** Form generated from reading UI file 'tablewidgetdialog.ui'
**
** Created: Wed Jan 17 21:09:12 2018
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TABLEWIDGETDIALOG_H
#define UI_TABLEWIDGETDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QSpinBox>

QT_BEGIN_NAMESPACE

class Ui_TableWidgetDialog
{
public:
    QLabel *mPositionLB;
    QLabel *mCountLB;
    QSpinBox *mPositionSP;
    QSpinBox *mCountSP;
    QPushButton *mActionPB;
    QPushButton *mCancelPB;
    QLabel *mCurrentCountLB;

    void setupUi(QDialog *TableWidgetDialog)
    {
        if (TableWidgetDialog->objectName().isEmpty())
            TableWidgetDialog->setObjectName(QString::fromUtf8("TableWidgetDialog"));
        TableWidgetDialog->resize(242, 142);
        mPositionLB = new QLabel(TableWidgetDialog);
        mPositionLB->setObjectName(QString::fromUtf8("mPositionLB"));
        mPositionLB->setGeometry(QRect(20, 30, 60, 20));
        mCountLB = new QLabel(TableWidgetDialog);
        mCountLB->setObjectName(QString::fromUtf8("mCountLB"));
        mCountLB->setGeometry(QRect(20, 60, 60, 20));
        mPositionSP = new QSpinBox(TableWidgetDialog);
        mPositionSP->setObjectName(QString::fromUtf8("mPositionSP"));
        mPositionSP->setGeometry(QRect(160, 30, 60, 27));
        mCountSP = new QSpinBox(TableWidgetDialog);
        mCountSP->setObjectName(QString::fromUtf8("mCountSP"));
        mCountSP->setGeometry(QRect(160, 60, 60, 27));
        mActionPB = new QPushButton(TableWidgetDialog);
        mActionPB->setObjectName(QString::fromUtf8("mActionPB"));
        mActionPB->setGeometry(QRect(130, 100, 93, 27));
        mCancelPB = new QPushButton(TableWidgetDialog);
        mCancelPB->setObjectName(QString::fromUtf8("mCancelPB"));
        mCancelPB->setGeometry(QRect(20, 100, 93, 27));
        mCurrentCountLB = new QLabel(TableWidgetDialog);
        mCurrentCountLB->setObjectName(QString::fromUtf8("mCurrentCountLB"));
        mCurrentCountLB->setGeometry(QRect(90, 60, 40, 20));

        retranslateUi(TableWidgetDialog);

        QMetaObject::connectSlotsByName(TableWidgetDialog);
    } // setupUi

    void retranslateUi(QDialog *TableWidgetDialog)
    {
        TableWidgetDialog->setWindowTitle(QApplication::translate("TableWidgetDialog", "Dialog", 0, QApplication::UnicodeUTF8));
        mPositionLB->setText(QApplication::translate("TableWidgetDialog", "Position:", 0, QApplication::UnicodeUTF8));
        mCountLB->setText(QApplication::translate("TableWidgetDialog", "Count:", 0, QApplication::UnicodeUTF8));
        mActionPB->setText(QApplication::translate("TableWidgetDialog", "Remove", 0, QApplication::UnicodeUTF8));
        mCancelPB->setText(QApplication::translate("TableWidgetDialog", "Cancel", 0, QApplication::UnicodeUTF8));
        mCurrentCountLB->setText(QApplication::translate("TableWidgetDialog", "TextLabel", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class TableWidgetDialog: public Ui_TableWidgetDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TABLEWIDGETDIALOG_H
