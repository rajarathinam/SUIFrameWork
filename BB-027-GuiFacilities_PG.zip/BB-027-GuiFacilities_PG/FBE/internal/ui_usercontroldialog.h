/********************************************************************************
** Form generated from reading UI file 'usercontroldialog.ui'
**
** Created: Wed Jan 17 21:09:12 2018
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_USERCONTROLDIALOG_H
#define UI_USERCONTROLDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QGroupBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_UserControlDialog
{
public:
    QLabel *mUctrlNameLBL;
    QLineEdit *mUserCtrlNameLE;
    QGroupBox *mInstanceGB;
    QLabel *label;
    QLineEdit *mUsrCtrlIdLE;
    QPushButton *mOkPB;
    QPushButton *mCancelPB;

    void setupUi(QDialog *UserControlDialog)
    {
        if (UserControlDialog->objectName().isEmpty())
            UserControlDialog->setObjectName(QString::fromUtf8("UserControlDialog"));
        UserControlDialog->resize(363, 183);
        mUctrlNameLBL = new QLabel(UserControlDialog);
        mUctrlNameLBL->setObjectName(QString::fromUtf8("mUctrlNameLBL"));
        mUctrlNameLBL->setGeometry(QRect(20, 30, 120, 20));
        mUserCtrlNameLE = new QLineEdit(UserControlDialog);
        mUserCtrlNameLE->setObjectName(QString::fromUtf8("mUserCtrlNameLE"));
        mUserCtrlNameLE->setGeometry(QRect(150, 30, 190, 22));
        mInstanceGB = new QGroupBox(UserControlDialog);
        mInstanceGB->setObjectName(QString::fromUtf8("mInstanceGB"));
        mInstanceGB->setGeometry(QRect(20, 60, 320, 70));
        mInstanceGB->setCheckable(true);
        label = new QLabel(mInstanceGB);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 30, 20, 20));
        mUsrCtrlIdLE = new QLineEdit(mInstanceGB);
        mUsrCtrlIdLE->setObjectName(QString::fromUtf8("mUsrCtrlIdLE"));
        mUsrCtrlIdLE->setGeometry(QRect(50, 30, 250, 22));
        mOkPB = new QPushButton(UserControlDialog);
        mOkPB->setObjectName(QString::fromUtf8("mOkPB"));
        mOkPB->setGeometry(QRect(260, 140, 81, 22));
        mCancelPB = new QPushButton(UserControlDialog);
        mCancelPB->setObjectName(QString::fromUtf8("mCancelPB"));
        mCancelPB->setGeometry(QRect(160, 140, 81, 22));

        retranslateUi(UserControlDialog);

        QMetaObject::connectSlotsByName(UserControlDialog);
    } // setupUi

    void retranslateUi(QDialog *UserControlDialog)
    {
        UserControlDialog->setWindowTitle(QApplication::translate("UserControlDialog", "Create new User Control", 0, QApplication::UnicodeUTF8));
        mUctrlNameLBL->setText(QApplication::translate("UserControlDialog", "User Control Name:", 0, QApplication::UnicodeUTF8));
        mInstanceGB->setTitle(QApplication::translate("UserControlDialog", "Make Instance", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("UserControlDialog", "ID:", 0, QApplication::UnicodeUTF8));
        mOkPB->setText(QApplication::translate("UserControlDialog", "Ok", 0, QApplication::UnicodeUTF8));
        mCancelPB->setText(QApplication::translate("UserControlDialog", "Cancel", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class UserControlDialog: public Ui_UserControlDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_USERCONTROLDIALOG_H
