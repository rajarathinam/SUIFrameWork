//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source File                                |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author FBE Auto generated
// !\brief Brief description here
// !\description Description
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2017, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

//----------------------------------------------------------------------------|
//                                 Includes                                   |
//----------------------------------------------------------------------------|
#include "UserClass.h"
#include "UserClass_moc.h"

//----------------------------------------------------------------------------|
//                             Class definition                               |
//----------------------------------------------------------------------------|
NSPC::UserClass::UserClass() :
    sui(new MOC::UserClass)
{
    sui->setupSUI("UserClass.xml");
}

NSPC::UserClass::~UserClass()
{
    delete sui;
}

SUI::Button *NSPC::UserClass::getStartButton() {
    return sui->startButton;
}

SUI::Button *NSPC::UserClass::getStopButton() {
    return sui->stopButton;
}

SUI::Label *NSPC::UserClass::getTimeLabel() {
    return sui->timeLabel;
}

SUI::ProgressBar *NSPC::UserClass::getProgressBar() {
    return sui->progressBar;
}

SUI::Dialog *NSPC::UserClass::getDialog() {
    return sui->dialog;
}
