#include "UserClass.h"
#include "UserController.h"

#include <FWQxCore/SUIApplication.h>
#include <FWQxWidgets/SUIMessageBox.h>
#include <FWQxWidgets/SUIFileDialog.h>
#include <iostream>

int main(int argc, char *argv[]) {

    // instantiate the application
    boost::shared_ptr<SUI::Application> app = SUI::Application::createApplication(argc,argv);

    // instantiate the controller
    UserController controller(new NSPC::UserClass);

    SUI::FileDialog::getOpenFileName(NULL,"DEMO Open my file","/usr/local","/usr/local","*.xml",NULL,SUI::FileDialogOptionEnum::DontResolveSymlinks);
//    SUI::FileDialog::getSaveFileName(NULL,"DEMO Save my file","/","*.xml",NULL,SUI::FileDialogOptionEnum::DontConfirmOverwrite);
//    SUI::FileDialog::getOpenFileNames(NULL,"DEMO Open my file(s)","/","*.xml",NULL,SUI::FileDialogOptionEnum::DontUseNativeDialog);
//    SUI::FileDialog::getExistingDirectory(NULL,"DEMO Get directory","/",(SUI::FileDialogOptionEnum::ShowDirsOnly|SUI::FileDialogOptionEnum::ReadOnly));
//
    SUI::MessageBox::about(NULL,"About","Version 1.0");
    SUI::MessageBox::message(NULL,"DEMO Information MessageBox witout icon","This messagebox has no icon",SUI::StandardButtonEnum::Ok);
//    SUI::StandardButtonEnum::Button critical = SUI::MessageBox::critical(NULL,"Error","DEMO error MessageBox.",(SUI::StandardButtonEnum::Ok|SUI::StandardButtonEnum::Cancel));
//    std::string info(critical == SUI::StandardButtonEnum::Ok ? "Ok" : "Cancel");
//    SUI::MessageBox::information(NULL,"DEMO Information MessageBox",info.append(" was clicked"),SUI::StandardButtonEnum::Ok);
//    SUI::MessageBox::warning(NULL,"Warning","DEMO warning MessageBox.",(SUI::StandardButtonEnum::Apply|SUI::StandardButtonEnum::Cancel));
//    SUI::MessageBox::question(NULL,"Question","DEMO question MessageBox.",SUI::StandardButtonEnum::Yes|SUI::StandardButtonEnum::No);

    std::cout << SUI::MessageBox::custom(NULL,"DEMO Information MessageBox witout icon","This messagebox has no icon",SUI::MessageBoxIconEnum::None,"Ok","") << std::endl;

    //execute the application (main eventloop)
    return app->exec();
}

