#include "SUITreeViewUnitTest.h"
#include "SUIITextUnitTest.h"
#include <QTest>

SUI::TreeViewUnitTest::TreeViewUnitTest(SUI::TreeView *object, QObject *parent) :
    WidgetUnitTest(object, parent),
    object(object)
{
}

SUI::TreeViewUnitTest::~TreeViewUnitTest()
{
    delete object;
}

void SUI::TreeViewUnitTest::callInterfaceTests() {
    // IText UnitTests
    ITextUnitTest iTextUnitTest(object);
    QVERIFY(iTextUnitTest.setText());
    QVERIFY(iTextUnitTest.clearText());
    QVERIFY(iTextUnitTest.setBold());
}

void SUI::TreeViewUnitTest::setTitle() {
    const std::string title = "Unit test";

    object->setTitle(title);
    QCOMPARE(object->getTitle(), title);
}
