#ifndef SUIIORIENTABLEUNITTEST_H
#define SUIIORIENTABLEUNITTEST_H

#include <FWQxCore/SUIOrientationEnum.h>

namespace SUI {

class IOrientable;

class IOrientableUnitTest
{
public:
    explicit IOrientableUnitTest(IOrientable *object);

    bool setOrientation(OrientationEnum::Orientation orientation);

private:
    IOrientable *object;
};

}

#endif // SUIIORIENTABLEUNITTEST_H
