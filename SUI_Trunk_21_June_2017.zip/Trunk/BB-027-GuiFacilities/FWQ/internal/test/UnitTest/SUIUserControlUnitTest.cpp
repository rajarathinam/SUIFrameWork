#include "SUIUserControlUnitTest.h"
#include "SUIIClickableUnitTest.h"

SUI::UserControlUnitTest::UserControlUnitTest(SUI::UserControl *object, QObject *parent) :
    WidgetUnitTest(object, parent),
    object(object)
{
}

SUI::UserControlUnitTest::~UserControlUnitTest()
{
    delete object;
}

void SUI::UserControlUnitTest::callInterfaceTests() {
    //IClickable tests
    IClickableUnitTest iClickable(object);
    iClickable.clickable();

    //TODO IHoverable UnitTest
}
