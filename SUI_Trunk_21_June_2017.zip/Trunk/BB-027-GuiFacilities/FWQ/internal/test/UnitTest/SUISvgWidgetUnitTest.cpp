#include "SUISvgWidgetUnitTest.h"
#include <QTest>

SUI::SvgWidgetUnitTest::SvgWidgetUnitTest(SUI::SvgWidget *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::SvgWidgetUnitTest::~SvgWidgetUnitTest() {
    delete object;
}

