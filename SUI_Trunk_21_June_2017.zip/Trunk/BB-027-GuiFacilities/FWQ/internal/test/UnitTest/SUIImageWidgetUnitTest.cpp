#include "SUIImageWidgetUnitTest.h"
#include <FWQxWidgets/SUIImageWidget.h>
#include <FWQxCore/SUIResourcePath.h>
#include <QTest>
#include <QDir>
#include <QPixmap>

SUI::ImageWidgetUnitTest::ImageWidgetUnitTest(SUI::ImageWidget *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::ImageWidgetUnitTest::~ImageWidgetUnitTest() {
    delete object;
}

void SUI::ImageWidgetUnitTest::setImage() {
    QFETCH(QString, resourcePath);
    QFETCH(QString, filename);

    if(!QDir(resourcePath.toStdString().c_str()).exists()) QDir().mkdir(resourcePath);
    SUI::ResourcePath::getInstance()->setResourcePath(resourcePath.toStdString());

    QPixmap pic(200,200);
    pic.save(QString::fromStdString(SUI::ResourcePath::getResourceFile("/home/adt/test/test.png")));
    object->setImage(filename.toStdString());
}

void SUI::ImageWidgetUnitTest::setImage_data()
{
    QTest::addColumn<QString>("resourcePath");
    QTest::addColumn<QString>("filename");
    QTest::newRow("change1") << QString("/home/adt/test") << QString("test.png");
}
