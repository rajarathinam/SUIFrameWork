#ifndef SUICONTROLWIDGETUNITTEST_H
#define SUICONTROLWIDGETUNITTEST_H

#include "SUIWidgetUnitTest.h"

namespace SUI {

class ControlWidget ;

class ControlWidgetUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    explicit ControlWidgetUnitTest(ControlWidget *object, QObject *parent = 0);
    virtual ~ControlWidgetUnitTest();

protected:
    void callInterfaceTests();

private:
    ControlWidget *object;
};

}

#endif // SUICONTROLWIDGETUNITTEST_H
