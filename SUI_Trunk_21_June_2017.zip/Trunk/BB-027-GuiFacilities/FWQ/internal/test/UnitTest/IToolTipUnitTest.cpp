#include "IToolTipUnitTest.h"

#include <FWQxCore/SUIObjectFactory.h>

#include <SUIBaseWidget.h>
#include <FWQxCore/SUIObjectType.h>

BaseObjectToolTipUnitTest::BaseObjectToolTipUnitTest()
{
}

void BaseObjectToolTipUnitTest::cleanupTestCase()
{
}

void BaseObjectToolTipUnitTest::testSetTitleCase()
{
    QFETCH(QString, title);
    QFETCH(QString, objectType);
    SUI::ObjectType::Type widgetType = SUI::ObjectType::fromString(objectType.toStdString());

    SUI::BaseWidget* widget = SUI::ObjectFactory::getInstance()->createWidget(widgetType);
    widget->setToolTip(title.toStdString());
    QCOMPARE(QString::fromStdString(widget->getToolTip()),title);
}

void BaseObjectToolTipUnitTest::testSetTitleCase_data()
{
    QTest::addColumn<QString>("title");
    QTest::addColumn<QString>("objectType");
    QTest::newRow("CheckGroupBox Tooltip") << QString("Hello world")<< QString("CheckGroupBox");
    QTest::newRow("Radiobutton Tootltip") << QString("Tooltip description")<< QString("RadioButton");
}
