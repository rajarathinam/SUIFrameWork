#include "SUIGraphicsItemUnitTest.h"

#include <QTest>

#include <FWQxGraphicsItems/SUIGraphicsItem.h>

SUI::GraphicsItemUnitTest::GraphicsItemUnitTest(GraphicsItem *object, QObject *parent) :
    ObjectUnitTest(object,parent),
    object(object)
{
}

SUI::GraphicsItemUnitTest::~GraphicsItemUnitTest()
{
}

void SUI::GraphicsItemUnitTest::setPosition() {
    object->setPosition(20,20);
    QVERIFY(object->getX() == 20 && object->getY() == 20);
}

void SUI::GraphicsItemUnitTest::setX() {
    object->setX(20);
    QVERIFY(object->getX());
}

void SUI::GraphicsItemUnitTest::setY() {
    object->setY(20);
    QVERIFY(object->getY());
}

void SUI::GraphicsItemUnitTest::setZValue() {
    object->setZValue(20);
    QVERIFY(object->getZValue());
}

