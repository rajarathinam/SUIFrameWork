#ifndef SUIINUMERICUNITTEST_H
#define SUIINUMERICUNITTEST_H

#include <FWQxCore/SUIINumeric.h>

namespace SUI {

class INumericUnitTest
{
public:
    explicit INumericUnitTest(SUI::INumeric<double> *dObject);
    explicit INumericUnitTest(SUI::INumeric<float> *dObject);
    explicit INumericUnitTest(SUI::INumeric<int> *iObject);
    explicit INumericUnitTest(SUI::INumeric<unsigned> *dObject);

    bool testDouble();
    bool testFloat();
    bool testInteger();
    bool testUnsigned();

private:
    INumeric<double> *dObject;
    INumeric<float> *fObject;
    INumeric<int> *iObject;
    INumeric<unsigned> *uObject;
};

}

#endif // SUIINUMERICUNITTEST_H
