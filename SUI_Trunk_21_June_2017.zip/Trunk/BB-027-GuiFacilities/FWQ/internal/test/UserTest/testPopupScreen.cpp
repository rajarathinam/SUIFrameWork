
#include "testPopupScreen.h"
#include <FWQxCore/SUIUILoader.h>
#include <FWQxCore/SUIObjectList.h>
#include <FWQxWidgets/SUILineEdit.h>
#include <FWQxWidgets/SUITextArea.h>
#include <FWQxWidgets/SUICheckBox.h>
#include <FWQxCore/SUIException.h>

#include <QFileInfo>

testPopupScreen::testPopupScreen( QString aSourceWidgetID, QString aModalID, QString aID, QString aTextID, SUI::Dialog *apGui ) :
    mSourceWidgetID( aSourceWidgetID ),
    mModalID( aModalID ),
    mIdID( aID ),
    mtextID( aTextID),
    mpGui( apGui )
{
}

void testPopupScreen::showPopup()
{
    SUI::TextArea* textArea = mpGui->getObjectList()->getObject<SUI::TextArea>(mSourceWidgetID.toStdString());
    SUI::CheckBox* checkbox = mpGui->getObjectList()->getObject<SUI::CheckBox>(mModalID.toStdString());
    QString defFile = QString::fromStdString( textArea->getText() );
    defFile.replace( "\n", "" );
    QFileInfo* file = new QFileInfo(defFile);
    if (file->exists())
    {
        mPopup = SUI::UILoader::loadUI(defFile.toStdString());
        mPopup->setModal(checkbox->isChecked());
        mPopup->show();
    }else
    {
        textArea->setText("File does not exist");
    }

}

void testPopupScreen::closePopup()
{
    if (mPopup)
    {
        mPopup->close();
    }
}

void testPopupScreen::sendText()
{
    SUI::LineEdit* lineEdit = mpGui->getObjectList()->getObject<SUI::LineEdit>(mtextID.toStdString());
    std::string text = lineEdit->getText();
    mPopup->getObjectList()->getObject<SUI::TextArea>("txaTextWidget")->setText(text);
}
