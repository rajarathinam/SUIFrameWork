#ifndef TESTSTATEWIDGET_H
#define TESTSTATEWIDGET_H

#include <QString>

#include "SUIDialogImpl.h"


#include <SUIStateWidgetImpl.h>



class testStateWidget
{
public:
    enum test { setType, setState, getState, getSupportedStates };
    testStateWidget(QString aSourceWidgetID, QString aTargetWidgetID, SUI::DialogImpl *apGui, test aTest);
    void handleClicked();

private:
    QString mSourceWidgetid;
    QString mTargetWidgetid;
    SUI::DialogImpl  *mpGui;
    test    mTest;
};

#endif // TESTCONTROLWIDGET_H
