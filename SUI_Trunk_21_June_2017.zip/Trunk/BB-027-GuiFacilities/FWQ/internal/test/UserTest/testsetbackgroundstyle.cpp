#include "testsetbackgroundstyle.h"

#include <QImage>

#include <FWQxWidgets/SUIGraphicsView.h>
#include <FWQxGraphicsItems/SUIGraphicsScene.h>
#include <FWQxCore/SUIIText.h>
#include <FWQxWidgets/SUIDropDown.h>

void testSetBackgroundStyle::handleValueChanged()
{
    SUI::DropDown *dropDown = mpGui->getObjectList()->getObject<SUI::DropDown>(mSourceWidgetid.toStdString());
    SUI::GraphicsView    *view = mpGui->getObjectList()->getObject<SUI::GraphicsView>(mTargetWidgetid.toStdString());
    if (dropDown && view) {

        QString text = QString::fromStdString(dropDown->getSelectedItems().front());
        if (text.toLower() == "stretched")
        {
            view->setAspectRatioMode(SUI::AspectRatioEnum::IgnoreAspectRatio);
        }
        else if (text.toLower() == "cropped")
        {
            view->setAspectRatioMode(SUI::AspectRatioEnum::KeepAspectRatioByExpanding);
        }
        else
        {
            view->setAspectRatioMode(SUI::AspectRatioEnum::KeepAspectRatio);
        }
    }
}

testSetBackgroundStyle::testSetBackgroundStyle(QString aSourceWidgetID, QString aTargetWidgetID, SUI::DialogImpl *apGui):
    mTargetWidgetid(aTargetWidgetID),
    mSourceWidgetid(aSourceWidgetID),
    mpGui(apGui)
{
}


testSetBackGndImage::testSetBackGndImage(QString aTargetWidgetID, SUI::DialogImpl *apGui):
    mTargetWidgetid(aTargetWidgetID),
    mpGui(apGui)
{
}

void testSetBackGndImage::handleClicked()
{
    SUI::GraphicsView *view = mpGui->getObjectList()->getObject<SUI::GraphicsView>(mTargetWidgetid.toStdString());
    if(view) {
        QImage img;
        img.load(":/testimages/GraphicsViewBackGnd.jpg");
        view->getGraphicsScene()->setBackgroundImage(img.bits(), img.width(), img.height(), (SUI::ImageEnum::Format)img.format() );
    }
}
