//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class DragModeEnum.
// !\description Header file for class DragModeEnum.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|



#include "FWQxCore/SUIDragModeEnum.h"


SUI::DragModeEnum::Mode SUI::DragModeEnum::fromString(const std::string &mode) {
   DragModeEnum::Mode returnValue = ScrollHandDrag;       
   if (mode == "area selection") {
      returnValue = RubberBandDrag;
   }
   else if (mode == "none"){
      returnValue = None;
   }
   return returnValue;
}

std::string SUI::DragModeEnum::toString(const SUI::DragModeEnum::Mode &style) {
   std::string returnValue = "none";       
   switch (style) {
   case None: returnValue = "none"; break;
   case RubberBandDrag: returnValue = "area selection"; break;
   case ScrollHandDrag: returnValue = "panning"; break;
   default:;
   }
   return returnValue;
}
