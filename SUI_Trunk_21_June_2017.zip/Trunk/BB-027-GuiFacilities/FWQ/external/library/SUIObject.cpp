//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for Object.
// !\description Class implementation file for Object.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "FWQxCore/SUIObject.h"

#include "FWQxCore/SUIObjectFactory.h"
#include "SUIBaseObject.h"

SUI::Object::Object(const SUI::ObjectType::Type &type_t) :
    type(type_t)
{
}

SUI::Object::~Object()
{
}

std::string SUI::Object::getId() const { 
    return SUI::ObjectFactory::getInstance()->toBaseObject(const_cast<Object*>(this))->getId(); 
}

SUI::ObjectType::Type SUI::Object::getObjectType() const {
    return type;
}

void SUI::Object::setVisible(bool visible) { 
    SUI::ObjectFactory::getInstance()->toBaseObject(this)->setVisible(visible); 
    if (!visibilityChanged.empty()) {
        visibilityChanged(visible);   
    }
}

bool SUI::Object::isVisible() const {
    return SUI::ObjectFactory::getInstance()->toBaseObject(this)->isVisible(); 
}
