//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for CircularList.
// !\description Class implementation file for CircularList.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include <QStringList>
#include "CircularList.h"

const QString CircularList::mEmptyString = QString("");

/*****************************************************************************\
 *  FUNCTION    :   CircularList
 *  PARAMETERS  :   n.a.
 *  RETURN      :   n.a.
 *
 *  This is the ctor.
\*****************************************************************************/
CircularList::CircularList() :
    mQueueSize(0),
    mCurrentPoint(0),
    mInQueue(0)
{

}

/*****************************************************************************\
 *  FUNCTION    :   ~CircularList
 *  PARAMETERS  :   n.a.
 *  RETURN      :   n.a.
 *
 *  This is the dtor.
\*****************************************************************************/
CircularList::~CircularList()
{
    clear();
}

/*****************************************************************************\
 *  FUNCTION    :   Init
 *  PARAMETERS  :   int size
 *                      The size of the buffer.
 *  RETURN      :   void
 *
 *  This function prepaires the buffer of undo actions.
\*****************************************************************************/
void CircularList::Init(int size)
{
    mQueueSize = size + 1;  // One extra null item as separator item
    for (int ind = 0; ind < mQueueSize; ++ind)
    {
        mData.append(NULL);
    }
}

/*****************************************************************************\
 *  FUNCTION    :   enqueue
 *  PARAMETERS  :   const UndoInfo *undoinf
 *                      A new UndoInfo instance
 *  RETURN      :   void
 *
 *  This function puts the new UndoInfo instance in the buffer. When the buffer
 *  is full, the first added UndoInfo instance has to be removed from the
 *  buffer, so making room for the next new UndoInfo.
\*****************************************************************************/
void CircularList::enqueue(const UndoInfo *undoinf)
{
    if (mQueueSize > 0)
    {
        mData[mCurrentPoint] = const_cast<UndoInfo *>(undoinf);
        emit sendUndoRedoText(mData[mCurrentPoint]->sStateList.at(0)->sActionText, mEmptyString);
        mCurrentPoint = (mCurrentPoint == mQueueSize - 1) ? 0 : mCurrentPoint + 1;
        if (mData[mCurrentPoint] != NULL)
        {
            emit doDelete(mData[mCurrentPoint]);
        }
        mData[mCurrentPoint] = NULL;
        mInQueue = (mInQueue == mQueueSize) ? mInQueue : mInQueue + 1;
        emit doEnableUndo(true);
    }
}

/*****************************************************************************\
 *  FUNCTION    :   prev
 *  PARAMETERS  :   void
 *  RETURN      :   const UndoInfo *
 *
 *  This function returns the UndoInfo instance before the current point, if
 *  current point does not point to the first item in the buffer. It then sets
 *  the current point one place back.
\*****************************************************************************/
const UndoInfo *CircularList::prev()
{
    if (mQueueSize != 0)
    {
        QString undoTxt;
        QString redoTxt;
        int dPrevPt = mCurrentPoint;
        dPrevPt = (dPrevPt == 0) ? mQueueSize - 1 : dPrevPt - 1;
        if (mData[dPrevPt] != NULL)
        {
            mCurrentPoint = dPrevPt;
            redoTxt = mData[dPrevPt]->sStateList.at(0)->sActionText;
            emit doEnableRedo(true);
        }
        int dEnableTst = dPrevPt;
        dEnableTst = (dEnableTst == 0) ? mQueueSize - 1 : dEnableTst - 1;
        if (mData[dEnableTst] == NULL)
        {
            emit doEnableUndo(false);
        }
        else
        {
            undoTxt = mData[dEnableTst]->sStateList.at(0)->sActionText;
        }
        emit sendUndoRedoText(undoTxt, redoTxt);
        return mData[dPrevPt];
    }
    return NULL;
}

/*****************************************************************************\
 *  FUNCTION    :   next
 *  PARAMETERS  :   void
 *  RETURN      :   const UndoInfo *
 *
 *  This function returns the UndoInfo instance at the current point, if
 *  current point does not point to the next new item in the buffer. It then
 *  sets the current point one place futher.
\*****************************************************************************/
const UndoInfo *CircularList::next()
{
    if (mQueueSize > 0)
    {
        QString undoTxt;
        QString redoTxt;
        int dNextPt = mCurrentPoint;
        if (mData[dNextPt] != NULL)
        {
            mCurrentPoint = (mCurrentPoint == mQueueSize - 1) ? 0 : mCurrentPoint + 1;
            undoTxt = mData[dNextPt]->sStateList.at(0)->sActionText;
            emit doEnableUndo(true);
        }
        if (mData[mCurrentPoint] == NULL)
        {
            emit doEnableRedo(false);
        }
        else
        {
            redoTxt = mData[mCurrentPoint]->sStateList.at(0)->sActionText;
        }
        emit sendUndoRedoText(undoTxt, redoTxt);
        return mData[dNextPt];
    }
    return NULL;
}

/*****************************************************************************\
 *  FUNCTION    :   clear
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This function clears the undo buffer, deleting all UndoInfo instances.
\*****************************************************************************/
void CircularList::clear()
{
    if (mQueueSize > 0)
    {
        int dOrgPtr = mCurrentPoint;
        mCurrentPoint = (mCurrentPoint == 0) ? mQueueSize - 1 : mCurrentPoint - 1;
        while (mData[mCurrentPoint] != NULL)
        {
            emit doDelete(mData[mCurrentPoint]);
            mData[mCurrentPoint] = NULL;
            mCurrentPoint = (mCurrentPoint == 0) ? mQueueSize - 1 : mCurrentPoint - 1;
        }
        mCurrentPoint = dOrgPtr;
        while (mData[mCurrentPoint] != NULL)
        {
            emit doDelete(mData[mCurrentPoint]);
            mData[mCurrentPoint] = NULL;
            mCurrentPoint = (mCurrentPoint == mQueueSize - 1) ? 0 : mCurrentPoint + 1;
        }
        mCurrentPoint = 0;
    }
    emit sendUndoRedoText(mEmptyString, mEmptyString);
    emit doEnableUndo(false);
    emit doEnableRedo(false);
}

void CircularList::setCurrentSaved()
{
    int dPrevPt = mCurrentPoint;
    dPrevPt = (dPrevPt == 0) ? mQueueSize - 1 : dPrevPt - 1;
    if (mData[dPrevPt] != NULL)
    {
        mData[dPrevPt]->sStateList.at(0)->sIsSaved = true;
    }
}

/*****************************************************************************\
 *  FUNCTION    :   printBuffer const
 *  PARAMETERS  :   void
 *  RETURN      :   QList<WidgetState *>
 *
 *  This function returns a list of WidgetState pointers.
\*****************************************************************************/
QList<WidgetState *> CircularList::printBuffer() const
{
    QList<WidgetState *> printList;
    int dIndex = mCurrentPoint;

    while (mData.at(dIndex) != NULL)
    {
        dIndex = (dIndex == mQueueSize - 1) ? 0 : dIndex + 1;
    }


    dIndex = (dIndex == 0) ? mQueueSize - 1 : dIndex - 1;
    while (mData[dIndex] != NULL)
    {
        printList.append(mData.at(dIndex)->sStateList.at(0));
        if (dIndex == mCurrentPoint)
        {
            printList.append(NULL);
        }
        dIndex = (dIndex == 0) ? mQueueSize - 1 : dIndex - 1;
    }
    return printList;
}


