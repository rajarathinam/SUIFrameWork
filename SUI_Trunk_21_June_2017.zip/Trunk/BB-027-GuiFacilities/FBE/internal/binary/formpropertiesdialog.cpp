//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for FormPropertiesDialog.
// !\description Class implementation file for FormPropertiesDialog.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "ui_formpropertiesdialog.h"
#include "formpropertiesdialog.h"

const QList<SUI::ObjectPropertyTypeEnum::Type> FormPropertiesDialog::cmUnusedPropertyList = QList<SUI::ObjectPropertyTypeEnum::Type>({
    SUI::ObjectPropertyTypeEnum::Color,
    SUI::ObjectPropertyTypeEnum::Enable,
    SUI::ObjectPropertyTypeEnum::ID,
    SUI::ObjectPropertyTypeEnum::MaxValue,
    SUI::ObjectPropertyTypeEnum::MinValue,
    SUI::ObjectPropertyTypeEnum::StepSize,
    SUI::ObjectPropertyTypeEnum::Text,
    SUI::ObjectPropertyTypeEnum::Visible,
    SUI::ObjectPropertyTypeEnum::XPos,
    SUI::ObjectPropertyTypeEnum::YPos,
    SUI::ObjectPropertyTypeEnum::UserControl,
    SUI::ObjectPropertyTypeEnum::ObjectType,
    SUI::ObjectPropertyTypeEnum::SUICoreVersion,
    SUI::ObjectPropertyTypeEnum::SUIEditorVersion,
    SUI::ObjectPropertyTypeEnum::SUIObjectFactory,
    SUI::ObjectPropertyTypeEnum::StyleSheetClass
});

FormPropertiesDialog::FormPropertiesDialog(FormEditor *ddwidg, QWidget *parent) :
    QDialog(parent),
    mFormUi(new Ui::Dialog),
    mDDWidg(ddwidg)
{
    mFormUi->setupUi(this);
    mFormUi->mPropertyWidget->clearTable();
    if (mDDWidg) {
        foreach(SUI::ObjectPropertyTypeEnum::Type type, ddwidg->getPropertyList()) {
            if (cmUnusedPropertyList.contains(type)) continue;
            QString typeStr = QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(type));
            SUI::ObjectProperty *property = mDDWidg->getBaseWidget()->getProperty(type);
            if (property)
                mFormUi->mPropertyWidget->addTableRow(mDDWidg->getObjectType(), property, mDDWidg->getBaseWidget()->isPropertyReadonly(type));
        }
        mFormUi->mPropertyWidget->setMaxTableHeight();
        connect(mFormUi->mPropertyWidget, SIGNAL(propertyValueChanged(QString, QString)),this, SLOT(onPropertyChanged(QString, QString)));
    }
    connect(mFormUi->buttonBox, SIGNAL(accepted()), this, SLOT(onOk()));
    connect(mFormUi->buttonBox, SIGNAL(rejected()), this, SLOT(onCancel()));
}

FormPropertiesDialog::~FormPropertiesDialog()
{
    delete mFormUi;
}

/*****************************************************************************\
 *  FUNCTION    :   onOk
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This function sets all properties to the widgets properties
 \****************************************************************************/
void FormPropertiesDialog::onOk() {
    for (int i = 0; i < mFormUi->mPropertyWidget->getTablePointer()->rowCount(); ++i) {
        QTableWidgetItem *key = mFormUi->mPropertyWidget->getTablePointer()->item(i, 0);
        QTableWidgetItem *value = mFormUi->mPropertyWidget->getTablePointer()->item(i, 1);
        if (key && value)
            mDDWidg->setPropertyValue(SUI::ObjectPropertyTypeEnum::fromString(key->text().toStdString()), value->text());

        else if (key && (mTmpPropertyList.contains(key->text())))
            mDDWidg->setPropertyValue(SUI::ObjectPropertyTypeEnum::fromString(key->text().toStdString()), mTmpPropertyList.value(key->text()));
    }
    accept();
}

void FormPropertiesDialog::onCancel() {
    reject();
}

void FormPropertiesDialog::onPropertyChanged(QString key, QString value) {
    mTmpPropertyList.insert(key, value);
}
