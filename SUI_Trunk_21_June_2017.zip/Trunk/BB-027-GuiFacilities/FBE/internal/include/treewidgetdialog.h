//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class treeWidgetDialog.
// !\description Header file for class treeWidgetDialog.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|



#ifndef TREEWIDGETDIALOG_H
#define TREEWIDGETDIALOG_H

#include <QDialog>
#include <QTreeWidgetItem>

#include <SUITreeViewImpl.h>

#include "Model.h"
#include "WidgetController.h"
#include "UndoHandler.h"


namespace Ui
{
class treeWidgetDialog;
}

class treeWidgetDialog : public QDialog
{
    Q_OBJECT

public:
    explicit treeWidgetDialog(WidgetController *treeWidget, QWidget *parent = 0);
    virtual ~treeWidgetDialog();


private slots:
    void    on_pushButton_clicked();
    void    on_pushButton_2_clicked();
    void    on_pushButton_3_clicked();
    void    on_pushButton_4_clicked();

private:
    Ui::treeWidgetDialog    *ui;
    void                    addrow(QTreeWidgetItem *parent);
    void                    getItems(QTreeWidgetItem *item);
    WidgetController        *mTreeWidgetContr;
    WidgetState             *mWidgetState;

    void    addWidgets();
    void    addWidgets(WidgetController *child, QTreeWidgetItem *item);
};

#endif // TREEWIDGETDIALOG_H
