//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class Model.
// !\description Header file for class Model.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef MODEL_H
#define MODEL_H

#include <QString>
#include <QStringList>
#include <QList>
#include <QMap>
#include <QUuid>
#include <QMutex>

#include "WidgetController.h"
#include "WidgetControllerInfo.h"
#include "modelhandler.h"

#include <SUIObjectFactoryImpl.h>


class MainWindow;

class FormEditor;

class Model : public QObject
{
    Q_OBJECT
public:
    static Model *instance();
    static void deleteInstance();

    void setNewSelected(WidgetController *widget);
    void selectNewWidget(const QString &id);
    void addWidget(WidgetController *widget);
    void removeWidget(QUuid uuid);
    QString createNewId(const QString &widgetType);
    bool IDExists(const QString id) const;
    WidgetController *getCurrentWidget() const;
    WidgetController *getCurrentMainTabPage() const;
    WidgetController *getCurrentTopPage() const;
    WidgetController *getWidgetController(const QString id) const;
    void reset();
    bool setCopiedDragAndDropInfo();
    void alignLeft();
    void alignRight();
    void alignTop();
    void alignBottom();
    void layoutHorizontally();
    void layoutVerically();
    void spaceHorizontally();
    void spaceVerically();
    void centerHorizontally();
    void centerVerically();
    bool selectionHasSameParent(const QString parentid = QString()) const;
    WidgetController *retrieveFromStore(const QString &id);
    void removeUsedUserControl(const QString &id);
    void renameUsedUserControl(const QString &oldID, const QString &newID);
    void store(const WidgetController *wcNewWidget);
    void removeUserControl(const WidgetController *wcUCtrl);
    void deselectAll();
    bool acquire(const WidgetController *wcAcq);
    bool release(const WidgetController *wcRel);
    void addToSelectionList(WidgetController *widgctrl);
    void removeFromSelectionList(WidgetController *widgctrl);
    void swapInSelectionList(const WidgetController *wcOld, const WidgetController *wcNew);
    void setTopWidget(const WidgetController *topwidg);
    const FormEditor *getFormEditor() const;
    void removeChildrenFromSelectionList();
    void setDataChanged(bool isChanged = true);

    void setRightButtonBar(const WidgetController *tabwidg);
    void setBottomButtonBar(const WidgetController *tabwidg);
    void setStatusBar(const WidgetController *tabwidg);
    void setCloseButton(const WidgetController *tabwidg);
    void setHelpButton(const WidgetController *tabwidg);
    void setStatusTextArea(const WidgetController *tabwidg);
    ModelHandler *getModelHandler();
    WidgetController *getTopWidget() const;
    WidgetController *getMainTabWidget() const;
    WidgetController *getRightButtonBar() const;
    WidgetController *getBottomButtonBar() const;
    WidgetController *getStatusBar() const;
    WidgetController *getCloseButton() const;
    WidgetController *getHelpButton() const;
    WidgetController *getStatusTextArea() const;
    void setCurrentWidget(const WidgetController *widget);
    bool hasCopiedWidgetList() const;
    bool dataChanged() const;
    void setCtrlPressed(bool pressed);
    void setCtrlReleased();
    bool isCtrlPressed() const;
    bool hasSelectionList() const;
    bool hasSelectedItems() const;
    void addUsedUserControl(const QString &id);
    const QStringList &getUsedUCtrlList() const;
    void setMainWindow(const MainWindow *mw);
    const MainWindow *getMainWindow() const;
    bool isInSelectionList(const WidgetController *wc) const;
    int XGridDistance() const;
    int YGridDistance() const;
    void setXGridDistance(int value);
    void setYGridDistance(int value);
    void useGrid(bool set);
    bool gridActive() const;
    bool xSnap() const;
    bool ySnap() const;
    void setXSnap(bool set);
    void setYSnap(bool set);
    void setFormEditor(WidgetController *formedit);
    WidgetController *formEditor() const;
    const QList<WidgetController *> getUserControlList() const;
    const QList<WidgetController *> &getSelectionList() const;
    const QList<WidgetControllerInfo *> &getCopiedWidgetList() const;
    void callWidgetProcessed();
    void callNewMessage(const QString &msg);
    void callSetWidgetCount(int count);

    static bool horizontalSort(WidgetController *dd1, WidgetController *dd2);
    static bool verticalSort(WidgetController *dd1, WidgetController *dd2);

    WidgetControllerInfo *mWidgetDragged;
    static const int cmOuterMargin = 4;
    static const int cmInnerMargin = 4;
public slots:
    void onFileLoaded();
    void onLoadingFile();

private:
    bool mDataChanged;
    bool mCtrlPressed;
    QUuid mCurrentGUuid;
    QMap<QUuid, WidgetController*> mWidgetMap;

    ModelHandler *mModelHandler;
    QUuid mTopWidgetGUuid;
    QUuid mMainTabGUuid;
    QUuid mRightButtonBarGUuid;
    QUuid mBottomButtonBarGUuid;
    QUuid mStatusBarGUuid;
    QUuid mCloseButtonGUuid;
    QUuid mHelpButtonGUuid;
    QUuid mStatusTextAreaGUuid;
    QList<WidgetControllerInfo*> mCopiedWidgetList;
    QList<WidgetController*> mSelectionList;
    QList<WidgetController*> mTheWidgetStore;
    QStringList mUsedUCtrlList;
    WidgetController *mSemaphore;
    WidgetController *mFormEditor;
    QMutex mMutex;
    MainWindow *mMainWindow;
    int mXGridDistance;
    int mYGridDistance;
    bool mUseGrid;
    bool mXSnap;
    bool mYSnap;

    bool loadingFile;

    static Model *m_pInstance;

    Model();
    Model(const Model &rhs);
    Model &operator=(const Model &rhs);
    virtual ~Model();

signals:
    void widgetProcessed();
    void newMessage(QString msg);
    void setWidgetCount(int);
    void sendDataChanged(bool);
};

#endif  // MODEL_H
