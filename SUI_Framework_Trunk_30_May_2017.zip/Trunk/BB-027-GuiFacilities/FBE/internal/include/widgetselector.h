//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class WidgetSelector.
// !\description Header file for class WidgetSelector.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef WIDGETSELECTOR_H
#define WIDGETSELECTOR_H

#include "WidgetController.h"
#include <FWQxCore/SUIObjectFactory.h>

#include <QGroupBox>
#include <QVBoxLayout>


class WidgetSelector : public WidgetController
{
public:
    explicit WidgetSelector(QWidget *parent = 0);
    virtual ~WidgetSelector();

    void initWidgets();

private:
    static const QList<SUI::ObjectType::Type>    cmAllowedWidgetList;
};

#endif // WIDGETSELECTOR_H
