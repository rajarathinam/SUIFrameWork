//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for Model.
// !\description This class is a singleton class and provides application wide
//                 variables and functions.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include <stddef.h>  // defines NULL
#include <QString>
#include <QMutexLocker>
#include <QApplication>

#include <SUITabWidgetImpl.h>
#include <SUITabPageImpl.h>

#include <SUIBasePageImpl.h>
#include <SUIBaseWidget.h>
#include <FWQxCore/SUIObjectFactory.h>
#include <boost/foreach.hpp>
#include "Model.h"
#include "UndoHandler.h"
#include "mainwindow.h"
#include "FileController.h"
Model *Model::m_pInstance = NULL;

/*****************************************************************************\
 *  FUNCTION    :   Model
 *  PARAMETERS  :   void
 *  RETURN      :   n.a.
 *
 *  This is the constructor
 \****************************************************************************/
Model::Model():
    mWidgetDragged(NULL), mDataChanged(false), mCtrlPressed(false), mCurrentGUuid(0),
    mModelHandler(new ModelHandler()), mTopWidgetGUuid(0), mMainTabGUuid(0), mRightButtonBarGUuid(0),
    mBottomButtonBarGUuid(0), mStatusBarGUuid(0), mCloseButtonGUuid(0), mHelpButtonGUuid(0), mStatusTextAreaGUuid(0),
    mSemaphore(NULL), mFormEditor(NULL), mMainWindow(NULL), mXGridDistance(10), mYGridDistance(10), mUseGrid(false),
    mXSnap(true), mYSnap(true), loadingFile(false)
{
}

/*****************************************************************************\
 *  FUNCTION    :   ~Model
 *  PARAMETERS  :   n.a.
 *  RETURN      :   n.a.
 *
 *  This is the destructor
 \****************************************************************************/
Model::~Model()
{
    if (mModelHandler != NULL)
    {
        mModelHandler->deleteLater();
    }
    BOOST_FOREACH(WidgetControllerInfo * wciChild, mCopiedWidgetList)
    {
        delete wciChild;
        wciChild = NULL;
    }
    mCopiedWidgetList.clear();
    BOOST_FOREACH(WidgetController *wcChild, mTheWidgetStore)
    {
        wcChild->deleteLater();
    }
    mTheWidgetStore.clear();
}

/*****************************************************************************\
 *  FUNCTION    :   Instance
 *  PARAMETERS  :   void
 *  RETURN      :   Model*
 *                      The one and only Model class instance
 *
 *  This function returns a pointer to the instance of this class. If there is
 *  no instance of this class yet, it will instantiate it.
 \****************************************************************************/
//Model *Model::Instance()
//{
//    if (!m_pInstance) // Only allow one instance of class to be generated.
//    {
//        m_pInstance = new Model;
//    }

//    return m_pInstance;
//}

Model *Model::instance() { if ( m_pInstance == NULL ) m_pInstance = new Model; return m_pInstance; }

void Model::deleteInstance()
{
    if ( m_pInstance != NULL )
    {
        delete m_pInstance;
        m_pInstance = NULL;
    }
}

/*****************************************************************************\
 *  FUNCTION    :   addWidget
 *  PARAMETERS  :   WidgetController *widget
 *                      Pointer to the widget that has to be added to the
 *                      DragAndDropWidge Map.
 *  RETURN      :   void
 *
 *  This function adds the pointer to the widget to the mWidgetMap. If mWidgetMap
 *  already contains the GUuid key, it will replace the old value with the new
 *  pointer.
 *  Since the main Tab Widget is always the first (Tab) Widget created, it can
 *  determine what is the Main Tab Widgets GUuid.
 \****************************************************************************/
void Model::addWidget(WidgetController *widget) {
// This check fails
//    if (!mWidgetMap.contains(widget->widgetGUID()) && !loadingFile) {
//        widget->getBaseWidget()->initialize(SUI::BaseObject::EditorForm);
//    }
    mWidgetMap.insert(widget->widgetGUID(), widget);
    setDataChanged(true);
    if (widget->getId() == "wpg1")
    {
        mTopWidgetGUuid = widget->widgetGUID();
    }
    else if ((widget->getObjectType() == SUI::ObjectType::TabWidget) && (mMainTabGUuid == 0) && (mTopWidgetGUuid == 0))
    {
        mTopWidgetGUuid = mMainTabGUuid = widget->widgetGUID();
    }
}

/*****************************************************************************\
 *  FUNCTION    :   removeWidget
 *  PARAMETERS  :   QUuid uuid
 *                      The QUuid of the widget to be removed from mWidgetMap.
 *  RETURN      :   void
 *
 *  This function removes the widget with the specified Guuid from mWidgetMap.
 *  If the mWidgetCopied->getDraggedWidget() is equal the the removed widget,
 *  this mWidgetCopied is deleted and a disablePasteAction SIGNAL is send (by
 *  calling mModelHandler->sendDisablePaste()), to disable a Paste action in
 *  the MainWindow.
 \****************************************************************************/
void Model::removeWidget(QUuid uuid)
{
    for (int ind = 0; ind < mCopiedWidgetList.size(); ++ind)
    {
        if (mCopiedWidgetList.at(ind)->getDraggedWidget() == mWidgetMap.value(uuid))
        {
            delete mCopiedWidgetList[ind];
            mCopiedWidgetList.removeAt(ind);
            break;
        }
    }
    mModelHandler->sendDisablePaste( mCopiedWidgetList.size() == 0 );
    if (mWidgetMap.contains(uuid))
    {
        WidgetController *delWidg = mWidgetMap.value(uuid);
        int ind = mSelectionList.indexOf(delWidg);
        if (ind != -1)
        {
            mSelectionList.removeAt(ind);
        }
    }
    if (uuid == mRightButtonBarGUuid)
    {
        mRightButtonBarGUuid = 0;
    }
    else if (uuid == mBottomButtonBarGUuid)
    {
        mBottomButtonBarGUuid = 0;
    }
    else if (uuid == mStatusBarGUuid)
    {
        mStatusBarGUuid = 0;
    }
    else if (uuid == mCloseButtonGUuid)
    {
        mCloseButtonGUuid = 0;
    }
    else if (uuid == mHelpButtonGUuid)
    {
        mHelpButtonGUuid = 0;
    }
    else if (uuid == mStatusTextAreaGUuid)
    {
        mStatusTextAreaGUuid = 0;
    }
    else if (uuid == mMainTabGUuid)
    {
        mMainTabGUuid = 0;
    }
    else if (uuid == mTopWidgetGUuid)
    {
        mTopWidgetGUuid = 0;
    }
    mWidgetMap.remove(uuid);
    setDataChanged(true);
}

/*****************************************************************************\
 *  FUNCTION    :   SetNewSelected
 *  PARAMETERS  :   WidgetController *widget
 *                      The widget to be selected
 *  RETURN      :   void
 *
 *  This function handles the selection of widgets.
 *  If the Ctrl-button is pressed , the current widget was not selected and this
 *  widget is not the Main-TabWidget or a TabPage, it is added to the SelectionList.
 *  If the current widget was selected and not the Main-TabWidget or a TabPage, it
 *  is removed from the SelectionList. If the previously selected widget was the
 *  Main-TabWidget or a TabPage, it is deselected.
 *
 *  If the Ctrl-button is not pressed, it clears the SelectionList. If this widget
 *  is not the Main-TabWidget or a TabPage, it is added as first element to the
 *  SelectionList.
 *
 *  If the selection of a widget changes, a redraw is generated by a call to
 *  updatePixmap(), so the blue selction rectangles are removed or painted
 *  accordingly. A call to mModelHandler->newWidgetSelection() makes sure that
 *  the Object Treeview and PropertyTable are updated.
 \****************************************************************************/
void Model::setNewSelected(WidgetController *widget)
{
    if ( widget != NULL ) {
        if (!mCtrlPressed && mSelectionList.contains(widget) == false) {
            mSelectionList.clear();

            for (QMap<QUuid, WidgetController *>::iterator it = mWidgetMap.begin(); it != mWidgetMap.end(); ++it) {
                if (!it.value()->isSelected()) continue;
                if (mSelectionList.contains(it.value()) == true) continue;
                it.value()->setSelected(false);
                it.value()->updatePixmap();
            }
        }

        if (mCtrlPressed) {
            widget->setSelected(!widget->isSelected());
        }
        else {
            widget->setSelected(true);
        }

        if (widget->getPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable).toLower() == "false")
        {
            if (widget->isSelected() && mSelectionList.count() > 0)
            {
                widget->setSelected(false);
            }
        }
        else
        {
            if (widget->isSelected())
            {
                if (mSelectionList.contains(widget) == false)
                {
                    mSelectionList.append(widget);
                }
            }
            else
            {
                int ind;
                if ((ind = mSelectionList.indexOf(widget)) != -1)
                {
                    mSelectionList.removeAt(ind);
                }
            }
        }

        widget->updatePixmap();
        if (widget->isSelected() && (widget->getPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable).toLower() == "false"))
        {
            mModelHandler->newWidgetSelection(widget);
            mModelHandler->newWidgetProperties(widget);
            mCurrentGUuid = widget->widgetGUID();
            mModelHandler->sendEnableForwardBackward(false);
            mSelectionList.append(widget);
        }
        else if (mSelectionList.count() == 1)
        {
            mModelHandler->newWidgetSelection(mSelectionList.at(0));
            mModelHandler->newWidgetProperties(mSelectionList.at(0));
            mCurrentGUuid = mSelectionList.at(0)->widgetGUID();
            mModelHandler->sendEnableForwardBackward(true);
        }
        else
        {
            mModelHandler->newWidgetSelection(NULL);
            mModelHandler->newWidgetProperties(widget);
            mCurrentGUuid = 0;
            mModelHandler->sendEnableForwardBackward(false);
        }
    }
    else
    {
        mCurrentGUuid = 0;
        mModelHandler->newWidgetSelection(NULL);
        mModelHandler->sendEnableForwardBackward(false);
    }
}

/*****************************************************************************\
 *  FUNCTION    :   SelectNewWidget
 *  PARAMETERS  :   const QString &id
 *                      The ID of the widget
 *  RETURN      :   void
 *
 *  This function makes sure that if the widget with ID id is a Tab Page, all
 *  other Tab Pages are hidden. It then calls SetSelected() with the found
 *  widget pointer.
 \****************************************************************************/
void Model::selectNewWidget(const QString &id)
{
    for (QMap<QUuid, WidgetController *>::iterator it = mWidgetMap.begin(); it != mWidgetMap.end(); ++it)
    {
        WidgetController *widgetController = *it;
        if (widgetController->getId() == id)
        {
            if (widgetController->getObjectType() == SUI::ObjectType::TabPage)
            {
                WidgetController *parentWidget = widgetController->getParent();
                for (QMap<QUuid, WidgetController *>::iterator s_it = mWidgetMap.begin(); s_it != mWidgetMap.end(); ++s_it)
                {
                    if (((*s_it)->getObjectType() == SUI::ObjectType::TabPage) && parentWidget == (*s_it)->getParent())
                    {
                        (*s_it)->hide();
                    }
                }
                dynamic_cast<SUI::TabWidgetImpl *>(parentWidget->getBaseWidget())->setTabToFront(dynamic_cast<SUI::TabPageImpl *>(widgetController->getBaseWidget()));
                widgetController->getParent()->updatePixmap();
                widgetController->show();
            }
            break;
        }
    }
}

/*****************************************************************************\
 *  FUNCTION    :   createNewId
 *  PARAMETERS  :   const QString &widgetType
 *                      The type of the widget
 *  RETURN      :   QString
 *
 *  This function creates a new ID, with a prefix, based on the widget type.
 \****************************************************************************/
QString Model::createNewId(const QString &widgetType)
{
    QString id;
    int ind = mWidgetMap.size();
    do
    {
        ++ind;
        id = QString("%1%2").arg(widgetType).arg(ind);
    }
    while (IDExists(id));

    return id;
}

/*****************************************************************************\
 *  FUNCTION    :   IDExists const
 *  PARAMETERS  :   const QString id
 *                      The widget id to check
 *  RETURN      :   bool
 *
 *  This function checks if the given id already exists.
 \****************************************************************************/
bool Model::IDExists(const QString id) const
{
    bool    bRet = false;
    QMap<QUuid, WidgetController *>::const_iterator cit;
    for (cit = mWidgetMap.begin(); cit != mWidgetMap.end(); ++cit)
    {
        if (id == (*cit)->getId())
        {
            bRet = true;
            break;
        }
    }
    return bRet;
}


/*****************************************************************************\
 *  FUNCTION    :   selectionHasParent const
 *  PARAMETERS  :   const QString &parentid
 *  RETURN      :   bool
 *
 *  This function checks if all widgets in the SelectionList have the same
 *  parent. When parentid is not empty it checks if all widgets in the
 *  SelectionList have the given parent as their parent.
 \****************************************************************************/
bool Model::selectionHasSameParent(const QString parentid) const
{
    bool    bOk = true;
    QString id = parentid;
    if (mSelectionList.count() == 0)
    {
        return false;
    }
    if (id.isEmpty())
    {
        id = mSelectionList.at(0)->getParent()->getId();
    }
    for (int ind = 0; (ind < mSelectionList.count()) && bOk; ++ind)
    {
        QString tmp = mSelectionList.at(ind)->getParent()->getId();
        if (mSelectionList.at(ind)->getParent()->getId() != id)
        {
            bOk = false;
        }
    }
    return bOk;
}

WidgetController *Model::retrieveFromStore(const QString &id)
{
    for (int ind = 0; ind < mTheWidgetStore.size(); ++ind)
    {
        if (mTheWidgetStore.at(ind)->getId() == id)
        {
            return mTheWidgetStore[ind];
        }
    }
    return NULL;
}

void Model::removeUsedUserControl(const QString &id)
{
    int ind = mUsedUCtrlList.indexOf(id);
    if (ind != -1)
    {
        mUsedUCtrlList.removeAt(ind);
    }
}

void Model::renameUsedUserControl(const QString &oldID, const QString &newID)
{
    int ind = mUsedUCtrlList.indexOf(oldID);
    if (ind != -1)
    {
        mUsedUCtrlList[ind] = newID;
    }

}

void Model::store(const WidgetController *wcNewWidget)
{
    if ( wcNewWidget != NULL )
    {
        QString idStr = wcNewWidget->getId();
        BOOST_FOREACH(WidgetController * wcChild, mTheWidgetStore)
        {
            if (wcChild->getId() == idStr)
            {
                return;
            }
        }
        mTheWidgetStore.append(const_cast<WidgetController*>(wcNewWidget));
    }
}

void Model::removeUserControl(const WidgetController *wcUCtrl)
{
    if ( wcUCtrl != NULL )
    {
        int ind = mTheWidgetStore.indexOf(const_cast<WidgetController *>(wcUCtrl));
        if (ind != -1)
        {
            mTheWidgetStore.removeAt(ind);
        }
    }
}

/*****************************************************************************\
 *  FUNCTION    :   deselectAll
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This function deselects all WidgetController pointers from the Selection
 *  List and removes them from that list.
 \****************************************************************************/
void Model::deselectAll()
{
    BOOST_FOREACH(WidgetController * wcSelected, mSelectionList)
    {
        wcSelected->setSelected(false);
        wcSelected->updatePixmap();
    }
    mSelectionList.clear();
    mCurrentGUuid = 0;
    mModelHandler->newWidgetSelection(NULL);
}

/*****************************************************************************\
 *  FUNCTION    :   acquire
 *  PARAMETERS  :   const WidgetController *wcAcq
 *                      The WidgetController to acquire for
 *  RETURN      :   bool
 *
 *  This function sets a kind of mutex. Since it is important to know which
 *  WidgetController has the 'mutex', we use a pointer to that WidgetController.
 *  This mutex is used by WidgetController::mousePressEvent() and it helps
 *  prefenting the user from clicking to soon on a WidgetController which is
 *  still being drawn.
 *  The QMutexLocker automatically releases the mutex when it is deleted when it
 *  gets out of scope.
 \****************************************************************************/
bool Model::acquire(const WidgetController *wcAcq)
{
    QMutexLocker locker(&mMutex);
    if ( mSemaphore != NULL )
    {
        return false;
    }
    else
    {
        mSemaphore = const_cast<WidgetController *>(wcAcq);
    }
    return true;
}

/*****************************************************************************\
 *  FUNCTION    :   release
 *  PARAMETERS  :   const WidgetController *wcRel
 *                      The WidgetController to release
 *  RETURN      :   bool
 *
 *  This function releases a kind of mutex. Since it is important to know which
 *  WidgetController has acquired the 'mutex', we use a pointer to that
 *  WidgetController.
 *  This mutex is used by WidgetController::mousePressEvent() and it helps
 *  prefenting the user from clicking to soon on a WidgetController which is
 *  still being drawn.
 *  The QMutexLocker automatically releases the mutex when it is deleted when it
 *  gets out of scope.
 \****************************************************************************/
bool Model::release(const WidgetController *wcRel)
{
    QMutexLocker locker(&mMutex);
    if (wcRel == mSemaphore)
    {
        mSemaphore = NULL;
        return true;
    }
    return false;
}

/*****************************************************************************\
 *  FUNCTION    :   addToSelectionList
 *  PARAMETERS  :   WidgetController *widgctrl
 *                      The WidgetController to be appended.
 *  RETURN      :   void
 *
 *  This function appends widgctrl to the selection list.
 \****************************************************************************/
void Model::addToSelectionList(WidgetController *widgctrl)
{
    if ( widgctrl != NULL )
    {
        if (mSelectionList.contains(widgctrl) == false)
        {
            mSelectionList.append(widgctrl);
            if (mSelectionList.count() == 1)
            {
                this->setCurrentWidget(widgctrl);
            }
            else
            {
                this->setCurrentWidget(0);
            }
            widgctrl->setSelected(true);
            widgctrl->updatePixmap();
        }
        else
        {
            int index = mSelectionList.indexOf(widgctrl);
            mSelectionList.removeAt(index);
        }
    }
}

/*****************************************************************************\
 *  FUNCTION    :   removeFromSelectionList
 *  PARAMETERS  :   WidgetController *widgctrl
 *                      The WidgetController to be removed.
 *  RETURN      :   void
 *
 *  This function removes widgctrl from the selection list.
 \****************************************************************************/
void Model::removeFromSelectionList(WidgetController *widgctrl)
{
    if ( widgctrl != NULL )
    {
        int ind;
        if ((ind = mSelectionList.indexOf(widgctrl)) != -1)
        {
            mSelectionList.removeAt(ind);
        }
    }
}

/*****************************************************************************\
 *  FUNCTION    :   swapInSelectionList
 *  PARAMETERS  :   const WidgetController *wcOld
 *                      The WidgetController to be replaced.
 *                  const WidgetController *wcNew
 *                      The new WidgetController
 *  RETURN      :   void
 *
 *  This function replaces the old WidgetController in the Selection List with
 *  the new WidgetController.
\*****************************************************************************/
void Model::swapInSelectionList(const WidgetController *wcOld, const WidgetController *wcNew)
{
    if ( (wcOld != NULL) && (wcNew != NULL) )
    {
        int ind;
        if ((ind = mSelectionList.indexOf(const_cast<WidgetController *>(wcOld))) != -1)
        {
            mSelectionList[ind] = const_cast<WidgetController *>(wcNew);
        }
    }
}

/*****************************************************************************\
 *  FUNCTION    :   setTopWidget
 *  PARAMETERS  :   const WidgetController *topwidg
 *                      The WidgetController to be set as TopWidget
 *  RETURN      :   void
 *
 *  This function sets the TopWidget, being either a TabWidget or WidgetPage.
 \****************************************************************************/
void Model::setTopWidget(const WidgetController *topwidg)
{
    mTopWidgetGUuid = topwidg->widgetGUID();
    if (topwidg->getObjectType() == SUI::ObjectType::TabWidget)
    {
        mMainTabGUuid = mTopWidgetGUuid;
    }
}

/*****************************************************************************\
 *  FUNCTION    :   getFormEditor const
 *  PARAMETERS  :   n.a.
 *  RETURN      :   const WidgetController *
 *
 *  This function returns the pointer to the FormEditor. Since this function
 *  needs the MainWindow declaration (from mainwindow.h), this function can not
 *  be placed in the header file as an inline function, because we can not
 *  include the mainwindow.h there (circular inclusion).
 \****************************************************************************/
const FormEditor *Model::getFormEditor() const
{
    if ( mMainWindow != NULL )
    {
        return mMainWindow->getFormEditor();
    }
    return NULL;
}

/*****************************************************************************\
 *  FUNCTION    :   removeChildrenFromSelectionList
 *  PARAMETERS  :   n.a.
 *  RETURN      :   void
 *
 *  This function removes WidgetControllers from the selection list, if a parent
 *  of that WidgetController is in the selection list as well.
 \****************************************************************************/
void Model::removeChildrenFromSelectionList()
{
    BOOST_FOREACH(WidgetController * wcTmp, mSelectionList)
    {
        WidgetController *wcParent = wcTmp->getParent();
        while ( wcParent != NULL )
        {
            if (mSelectionList.contains(wcParent) ==true)
            {
                removeFromSelectionList(wcTmp);
                break;
            }
            wcParent = wcParent->getParent();
        }
    }
}

/*****************************************************************************\
 *  FUNCTION    :   setDataChanged
 *  PARAMETERS  :   bool isChanged
 *  RETURN      :   void
 *
 *  This function emits a signal to indicate to the MainWindow that the data has
 *  changed.
 \****************************************************************************/
void Model::setDataChanged(bool isChanged)
{
    mDataChanged = isChanged;
    emit sendDataChanged(isChanged);
}

void Model::setRightButtonBar(const WidgetController *tabwidg) { mRightButtonBarGUuid = tabwidg->widgetGUID(); }

void Model::setBottomButtonBar(const WidgetController *tabwidg) { mBottomButtonBarGUuid = tabwidg->widgetGUID(); }

void Model::setStatusBar(const WidgetController *tabwidg) { mStatusBarGUuid = tabwidg->widgetGUID(); }

void Model::setCloseButton(const WidgetController *tabwidg) { mCloseButtonGUuid = tabwidg->widgetGUID(); }

void Model::setHelpButton(const WidgetController *tabwidg) { mHelpButtonGUuid = tabwidg->widgetGUID(); }

void Model::setStatusTextArea(const WidgetController *tabwidg) { mStatusTextAreaGUuid = tabwidg->widgetGUID(); }

ModelHandler *Model::getModelHandler() { return mModelHandler; }

WidgetController *Model::getTopWidget() const { return (mWidgetMap.contains(mTopWidgetGUuid)) ? mWidgetMap[mTopWidgetGUuid] : NULL; }

WidgetController *Model::getMainTabWidget() const { return (mWidgetMap.contains(mMainTabGUuid)) ? mWidgetMap[mMainTabGUuid] : NULL; }

WidgetController *Model::getRightButtonBar() const { return (mWidgetMap.contains(mRightButtonBarGUuid)) ? mWidgetMap[mRightButtonBarGUuid] : NULL; }

WidgetController *Model::getBottomButtonBar() const { return (mWidgetMap.contains(mBottomButtonBarGUuid)) ? mWidgetMap[mBottomButtonBarGUuid] : NULL; }

WidgetController *Model::getStatusBar() const { return (mWidgetMap.contains(mStatusBarGUuid)) ? mWidgetMap[mStatusBarGUuid] : NULL; }

WidgetController *Model::getCloseButton() const { return (mWidgetMap.contains(mCloseButtonGUuid)) ? mWidgetMap[mCloseButtonGUuid] : NULL; }

WidgetController *Model::getHelpButton() const { return (mWidgetMap.contains(mHelpButtonGUuid)) ? mWidgetMap[mHelpButtonGUuid] : NULL; }

WidgetController *Model::getStatusTextArea() const { return (mWidgetMap.contains(mStatusTextAreaGUuid)) ? mWidgetMap[mStatusTextAreaGUuid] : NULL; }

void Model::setCurrentWidget(const WidgetController *widget)
{
    if ( widget != NULL ) mCurrentGUuid = widget->widgetGUID();
    else mCurrentGUuid = 0;
}

bool Model::hasCopiedWidgetList() const { return (mCopiedWidgetList.size() > 0); }

bool Model::dataChanged() const { return mDataChanged; }

void Model::setCtrlPressed(bool pressed) { mCtrlPressed = pressed; }

void Model::setCtrlReleased() { mCtrlPressed = false; }

bool Model::isCtrlPressed() const { return mCtrlPressed; }

bool Model::hasSelectionList() const { return (mSelectionList.count() > 1); }

bool Model::hasSelectedItems() const { return (mSelectionList.count() > 0); }

void Model::addUsedUserControl(const QString &id) { mUsedUCtrlList.append(id); }

const QStringList &Model::getUsedUCtrlList() const { return mUsedUCtrlList; }

void Model::setMainWindow(const MainWindow *mw) { mMainWindow = const_cast<MainWindow *>(mw); }

const MainWindow *Model::getMainWindow() const { return mMainWindow; }

bool Model::isInSelectionList(const WidgetController *wc) const { return mSelectionList.contains(const_cast<WidgetController *>(wc)); }

int Model::XGridDistance() const { return mXGridDistance; }

int Model::YGridDistance() const { return mYGridDistance; }

void Model::setXGridDistance(int value) { mXGridDistance = value; }

void Model::setYGridDistance(int value) { mYGridDistance = value; }

void Model::useGrid(bool set) { mUseGrid = set; }

bool Model::gridActive() const { return mUseGrid; }

bool Model::xSnap() const { return mXSnap; }

bool Model::ySnap() const { return mYSnap; }

void Model::setXSnap(bool set) { mXSnap = set; }

void Model::setYSnap(bool set) { mYSnap = set; }

void Model::setFormEditor(WidgetController *formedit) { mFormEditor = formedit; }

WidgetController *Model::formEditor() const { return mFormEditor; }

/*****************************************************************************\
 *  FUNCTION    :   getUserControlList const
 *  PARAMETERS  :   n.a.
 *  RETURN      :   const QList<WidgetController*>
 *
 *  This function extracts the User Controls from the Widget Store and returns
 *  a QList of pointers to these User Controls.
 \****************************************************************************/
const QList<WidgetController*> Model::getUserControlList() const
{
    QList<WidgetController*>    uctrlList;
    BOOST_FOREACH (WidgetController *wcUCtrl, mTheWidgetStore)
    {
        if (wcUCtrl->getId().left(4) == QString("UCT-"))
        {
            uctrlList.append(wcUCtrl);
        }
    }
    return uctrlList;
}

const QList<WidgetController *> &Model::getSelectionList() const {
    return mSelectionList;
}

const QList<WidgetControllerInfo *> &Model::getCopiedWidgetList() const {
    return mCopiedWidgetList;
}

void Model::callWidgetProcessed() {
    emit this->widgetProcessed();
}

void Model::callNewMessage(const QString &msg) {
    emit newMessage(msg);
}

void Model::callSetWidgetCount(int count) {
    emit this->setWidgetCount(count);
}

bool Model::horizontalSort(WidgetController *dd1, WidgetController *dd2) {
    return (dd1->getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt() < dd2->getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt());
}

bool Model::verticalSort(WidgetController *dd1, WidgetController *dd2) {
    return (dd1->getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt() < dd2->getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt());
}

void Model::onFileLoaded() {
    loadingFile = false;
}

void Model::onLoadingFile() {
    loadingFile = true;
}

/*****************************************************************************\
 *  FUNCTION    :   getCurrentWidget const
 *  PARAMETERS  :   void
 *  RETURN      :   WidgetController*
 *
 *  This function returns the currently selected widget or NULL if no widget is
 *  selected.
 \****************************************************************************/
WidgetController *Model::getCurrentWidget() const {
    return mWidgetMap.contains(mCurrentGUuid) ? mWidgetMap.value(mCurrentGUuid) : NULL;
}

/*****************************************************************************\
 *  FUNCTION    :   getCurrentMainTabPage const
 *  PARAMETERS  :   void
 *  RETURN      :   WidgetController*
 *
 *  This function returns a pointer to the current Tab Page of the Main Tab
 *  Widget or NULL if it does not exist.
 \****************************************************************************/
WidgetController *Model::getCurrentMainTabPage() const
{
    WidgetController    *wcMainTabWidget = getMainTabWidget();
    if ( wcMainTabWidget != NULL )
    {
        SUI::TabWidgetImpl *tabWidget = dynamic_cast<SUI::TabWidgetImpl *>(wcMainTabWidget->getBaseWidget());
        SUI::BaseWidget *curTabPage = dynamic_cast<SUI::BaseWidget*>(SUI::ObjectFactory::getInstance()->toBaseObject(tabWidget->getCurrentTabPage()));
        for (QMap<QUuid, WidgetController *>::const_iterator cit = mWidgetMap.begin(); cit != mWidgetMap.end(); ++cit)
        {
            if (cit.value()->getBaseWidget() == curTabPage)
            {
                return cit.value();
            }
        }
    }
    return NULL;
}

/*****************************************************************************\
 *  FUNCTION    :   getCurrentTopPage const
 *  PARAMETERS  :   void
 *  RETURN      :   WidgetController*
 *
 *  This function returns a pointer to the current Tab Page of the Main Tab
 *  Widget, if it exists. Otherwise a pointer to the TopWidget is returned or
 *  NULL if it does not exist.
 \****************************************************************************/
WidgetController *Model::getCurrentTopPage() const
{
    WidgetController    *wcCurrentPage = getCurrentMainTabPage();
    if ( (wcCurrentPage == NULL) && (mTopWidgetGUuid != 0))
    {
        wcCurrentPage = getTopWidget();
    }
    return wcCurrentPage;
}

/*****************************************************************************\
 *  FUNCTION    :   getWidgetController const
 *  PARAMETERS  :   const QString id
 *  RETURN      :   WidgetController*
 *
 *  This function returns a pointer to the widget with the given id, or NULL
 *  if it does not exist.
 \****************************************************************************/
WidgetController  *Model::getWidgetController(const QString id) const
{
    for (QMap<QUuid, WidgetController *>::const_iterator cit = mWidgetMap.begin(); cit != mWidgetMap.end(); ++cit)
    {
        if (cit.value()->getId() == id)
        {
            return cit.value();
        }
    }
    return NULL;
}

/*****************************************************************************\
 *  FUNCTION    :   setCopiedDragAndDropInfo
 *  PARAMETERS  :   nove
 *  RETURN      :   bool
 *                      true    =   All widgets have the same parent
 *                      false   =   Not all widgets have the same parent
 *
 *  This function clears the current mCopiedWidgetList. Than adds all widgets
 *  from the selection list into the mCopiedWidgetList, if all widgets parent
 *  are the same. If the widgets do not have the same parent, the
 *  mCopiedWidgetList is cleared again and this function returns false
 \****************************************************************************/
bool Model::setCopiedDragAndDropInfo()
{
    bool    bRet = true;
    for (int ind = mCopiedWidgetList.size() - 1; ind >= 0; --ind)
    {
        delete mCopiedWidgetList[ind];
    }
    mCopiedWidgetList.clear();

    WidgetController *wcParent = NULL;
    if (mSelectionList.count() > 0)
    {
        wcParent = mSelectionList.at(0)->getParent();
    }
    WidgetController *wcCurTabPage = this->getCurrentTopPage();
    BOOST_FOREACH(WidgetController * wcChild, mSelectionList)
    {
        if (wcChild->getParent() != wcParent)
        {
            bRet = false;
            break;
        }
        WidgetControllerInfo *DDInfo = new WidgetControllerInfo(wcChild->getParent(), wcChild);
        DDInfo->setTabPageWidget(wcCurTabPage);
        mCopiedWidgetList.append(DDInfo);
    }
    if (!bRet)
    {
        for (int ind = mCopiedWidgetList.size() - 1; ind >= 0; --ind)
        {
            delete mCopiedWidgetList[ind];
        }
        mCopiedWidgetList.clear();
    }
    mModelHandler->sendDisablePaste( mCopiedWidgetList.size() == 0 );
    return bRet;
}

/*****************************************************************************\
 *  FUNCTION    :   reset
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This function is called by MainWindow::onOpen() and resets all (necessary)
 *  variables.
 \****************************************************************************/
void Model::reset()
{
    mWidgetMap.clear();
    mSelectionList.clear();

    //  Remove only the User Controls from the Widget Store
    BOOST_FOREACH (WidgetController *wcUCtrl, mTheWidgetStore)
    {
        if (wcUCtrl->getId().left(4) == QString("UCT-"))
        {
            mTheWidgetStore.removeOne(wcUCtrl);
        }
    }

    mUsedUCtrlList.clear();
    mCurrentGUuid = 0;
    mTopWidgetGUuid = 0;
    mMainTabGUuid = 0;
    mRightButtonBarGUuid = 0;
    mBottomButtonBarGUuid = 0;
    mStatusBarGUuid = 0;
    mCloseButtonGUuid = 0;
    mHelpButtonGUuid = 0;
    mStatusTextAreaGUuid = 0;
    BOOST_FOREACH(WidgetControllerInfo * wciChild, mCopiedWidgetList)
    {
        delete wciChild;
        wciChild = NULL;
    }
    mCopiedWidgetList.clear();
    mModelHandler->sendDisablePaste(true);
    this->setDataChanged(false);
}

/*****************************************************************************\
 *  FUNCTION    :   alignLeft
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This function aligns all widgets in the SelectionList to the left. It takes
 *  the first widget from the SelectionList as reference.
 *  It does not check whether all widgets have the same parent. So the position
 *  of the widgets is determined relative to there parent.
 \****************************************************************************/
void Model::alignLeft()
{
    if (mSelectionList.count() == 0)
    {
        return;
    }
    QList<WidgetState *> wsList;
    QString X_Base = mSelectionList.at(0)->getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos);
    for (QList<WidgetController *>::iterator it = mSelectionList.begin() + 1; it != mSelectionList.end(); ++it)
    {
        if (((*it)->widgetGUID() != mTopWidgetGUuid) && ((*it)->getObjectType() != SUI::ObjectType::TabPage))
        {
            WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo((*it), ACT_MOVE, "Align Left");
            (*it)->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, X_Base);
            UndoHandler::instance()->finishUndoInfo(wsState, (*it));
            wsList.append(wsState);
        }
    }
    if (wsList.count() > 0)
    {
        UndoHandler::instance()->addToUndoGroup(wsList);
    }
}

/*****************************************************************************\
 *  FUNCTION    :   alignRight
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This function aligns all widgets in the SelectionList to the right. It takes
 *  the first widget from the SelectionList as reference.
 *  It does not check whether all widgets have the same parent. So the position
 *  of the widgets is determined relative to there parent.
 \****************************************************************************/
void Model::alignRight()
{
    if (mSelectionList.count() ==0)
    {
        return;
    }
    QList<WidgetState *> wsList;
    int X_Base = mSelectionList.at(0)->getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt() +
                 mSelectionList.at(0)->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt();
    for (QList<WidgetController *>::iterator it = mSelectionList.begin() + 1; it != mSelectionList.end(); ++it)
    {
        if (((*it)->widgetGUID() != mTopWidgetGUuid) && ((*it)->getObjectType() != SUI::ObjectType::TabPage))
        {
            WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo((*it), ACT_MOVE, "Align Right");
            int X_Widg = X_Base - (*it)->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt();
            (*it)->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, QString::number(X_Widg));
            UndoHandler::instance()->finishUndoInfo(wsState, (*it));
            wsList.append(wsState);
        }
    }
    if (wsList.count() > 0)
    {
        UndoHandler::instance()->addToUndoGroup(wsList);
    }
}

/*****************************************************************************\
 *  FUNCTION    :   alignTop
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This function aligns all widgets in the SelectionList to the top. It takes
 *  the first widget from the SelectionList as reference.
 *  It does not check whether all widgets have the same parent. So the position
 *  of the widgets is determined relative to there parent.
 \****************************************************************************/
void Model::alignTop()
{
    if (mSelectionList.count()==0)
    {
        return;
    }
    QList<WidgetState *> wsList;
    QString Y_Base = mSelectionList.at(0)->getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos);
    for (QList<WidgetController *>::iterator it = mSelectionList.begin() + 1; it != mSelectionList.end(); ++it)
    {
        if (((*it)->widgetGUID() != mTopWidgetGUuid) && ((*it)->getObjectType() != SUI::ObjectType::TabPage))
        {
            WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo((*it), ACT_MOVE, "Align Top");
            (*it)->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, Y_Base);
            UndoHandler::instance()->finishUndoInfo(wsState, (*it));
            wsList.append(wsState);
        }
    }
    if (wsList.count())
    {
        UndoHandler::instance()->addToUndoGroup(wsList);
    }
}

/*****************************************************************************\
 *  FUNCTION    :   alignBottom
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This function aligns all widgets in the SelectionList to the bottom. It takes
 *  the first widget from the SelectionList as reference.
 *  It does not check whether all widgets have the same parent. So the position
 *  of the widgets is determined relative to there parent.
 \****************************************************************************/
void Model::alignBottom()
{
    if (!mSelectionList.count())
    {
        return;
    }
    QList<WidgetState *> wsList;
    int Y_Base = mSelectionList.at(0)->getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt() +
                 mSelectionList.at(0)->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt();
    for (QList<WidgetController *>::iterator it = mSelectionList.begin() + 1; it != mSelectionList.end(); ++it)
    {
        if (((*it)->widgetGUID() != mTopWidgetGUuid) && ((*it)->getObjectType() != SUI::ObjectType::TabPage))
        {
            WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo((*it), ACT_MOVE, "Align Bottom");
            int Y_Widg = Y_Base - (*it)->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt();
            (*it)->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, QString::number(Y_Widg));
            UndoHandler::instance()->finishUndoInfo(wsState, (*it));
            wsList.append(wsState);
        }
    }
    if (wsList.count())
    {
        UndoHandler::instance()->addToUndoGroup(wsList);
    }
}

/*****************************************************************************\
 *  FUNCTION    :   layoutHorizontally
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This function first makes a copy of teh SelectionList. It then sorts the
 *  widgets according to their X position. Then it checks if all widgets have
 *  the same parent widget. Otherwise they can not be spaced evenly and an error
 *  message is send. Then the distance between the widgets is calculated and the
 *  widgets are positioned accordingly.
 \****************************************************************************/
void Model::layoutHorizontally()
{
    int                                 widgetSpace = 0;
    int                                 lastWidgetWidth = 0;
    QList<WidgetController *>::iterator it;
    WidgetController                   *refParent = mSelectionList.at(0)->getParent();
    QList<WidgetController *>           tmpSelectList = mSelectionList;

    qSort(tmpSelectList.begin(), tmpSelectList.end(), Model::horizontalSort);
    for (it = tmpSelectList.begin(); it != tmpSelectList.end(); ++it)
    {
        if ((*it)->getParent() != refParent)
        {
            mModelHandler->sendMessage(QApplication::applicationName(), QString("Not all widgets have the same parent widget.\nThey can not be layout horizontally."), 1);
            return;
        }
        lastWidgetWidth = (*it)->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt();
        widgetSpace += lastWidgetWidth;
    }

    int parentWidth = refParent->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt();
    int whiteSpace = parentWidth - widgetSpace;
    int numberOfWidgets = tmpSelectList.count();
    int whiteSpaceSize = whiteSpace / (numberOfWidgets + 1);
    int interval = whiteSpaceSize;
    if (whiteSpace < 0)
    {
        whiteSpaceSize = (parentWidth - lastWidgetWidth) / (numberOfWidgets - 1);
        interval = 0;
    }
    QList<WidgetState *> wsList;
    for (it = tmpSelectList.begin(); it != tmpSelectList.end(); ++it)
    {
        WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo((*it), ACT_MOVE, "Layout Horizontally");
        (*it)->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, QString::number(interval));
        interval += whiteSpaceSize + ((whiteSpace >= 0) ? (*it)->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt() : 0);
        UndoHandler::instance()->finishUndoInfo(wsState, (*it));
        wsList.append(wsState);
    }
    if (wsList.count())
    {
        UndoHandler::instance()->addToUndoGroup(wsList);
    }
}

/*****************************************************************************\
 *  FUNCTION    :   layoutVerically
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This function first makes a copy of teh SelectionList. It then sorts the
 *  widgets according to their Y position. Then it checks if all widgets have
 *  the same parent widget. Otherwise they can not be spaced evenly and an error
 *  message is send. Then the distance between the widgets is calculated and the
 *  widgets are positioned accordingly.
 \****************************************************************************/
void Model::layoutVerically()
{
    int                                 widgetSpace = 0;
    int                                 lastWidgetHeight = 0;
    QList<WidgetController *>::iterator it;
    WidgetController                   *refParent = mSelectionList.at(0)->getParent();
    QList<WidgetController *>           tmpSelectList = mSelectionList;

    qSort(tmpSelectList.begin(), tmpSelectList.end(), Model::verticalSort);
    for (it = tmpSelectList.begin(); it != tmpSelectList.end(); ++it)
    {
        if ((*it)->getParent() != refParent)
        {
            mModelHandler->sendMessage(QApplication::applicationName(), QString("Not all widgets have the same parent widget.\nThey can not be layout vertically."), 1);
            return;
        }
        lastWidgetHeight = (*it)->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt();
        widgetSpace += lastWidgetHeight;
    }

    int parentHeight = refParent->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt();
    int whiteSpace = parentHeight - widgetSpace;
    int numberOfWidgets = tmpSelectList.count();
    int whiteSpaceSize = whiteSpace / (numberOfWidgets + 1);
    int interval = whiteSpaceSize;
    if (whiteSpace < 0)
    {
        whiteSpaceSize = (parentHeight - lastWidgetHeight) / (numberOfWidgets - 1);
        interval = 0;
    }
    QList<WidgetState *> wsList;
    for (it = tmpSelectList.begin(); it != tmpSelectList.end(); ++it)
    {
        WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo((*it), ACT_MOVE, "Layout Vertically");
        (*it)->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, QString::number(interval));
        interval += whiteSpaceSize + ((whiteSpace >= 0) ? (*it)->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt() : 0);
        UndoHandler::instance()->finishUndoInfo(wsState, (*it));
        wsList.append(wsState);
    }
    if (wsList.count())
    {
        UndoHandler::instance()->addToUndoGroup(wsList);
    }
}

/*****************************************************************************\
 *  FUNCTION    :   spaceHorizontally
 *  PARAMETERS  :   none
 *  RETURN      :   void
 *
 *  This function first makes a copy of the SelectionList. It then sorts the
 *  widgets according to their X position. Then it checks if all widgets have
 *  the same parent widget. Otherwise they can not be spaced evenly and an error
 *  message is send. Then the distance between the widgets is calculated and the
 *  widgets are positioned accordingly. The first and last widgets do not move.
 \****************************************************************************/
void Model::spaceHorizontally()
{
    int                                 dUsedSpace = 0;
    int                                 dLastWidth = 0;
    int                                 dLastX = 0;
    WidgetController                    *wcParent = mSelectionList.at(0)->getParent();
    QList<WidgetController *>            tmpSelectList = mSelectionList;
    QList<WidgetController *>::iterator  it;

    qSort(tmpSelectList.begin(), tmpSelectList.end(), Model::horizontalSort);
    for (it = tmpSelectList.begin(); it != tmpSelectList.end(); ++it)
    {
        if ((*it)->getParent() != wcParent)
        {
            mModelHandler->sendMessage(QApplication::applicationName(), QString("Not all widgets have the same parent widget.\nThey can not be spaced horizontally."), 1);
            return;
        }
        dLastWidth = (*it)->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt();
        dLastX = (*it)->getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt();
        dUsedSpace += dLastWidth;
    }
    int dFirstX = tmpSelectList.at(0)->getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt();
    int dWhiteSpace = ((dLastX + dLastWidth) - dFirstX) - dUsedSpace;
    int dNmbWidgets = tmpSelectList.count();
    int dWhiteSpaceSize = dWhiteSpace / (dNmbWidgets - 1);
    int dInterval = dFirstX;
    QList<WidgetState *> wsList;
    for (it = tmpSelectList.begin(); it != tmpSelectList.end(); ++it)
    {
        WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo((*it), ACT_MOVE, "Space Horizontally");
        (*it)->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, QString::number(dInterval));
        dInterval += (*it)->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt() + dWhiteSpaceSize;
        UndoHandler::instance()->finishUndoInfo(wsState, (*it));
        wsList.append(wsState);
    }
    if (wsList.count())
    {
        UndoHandler::instance()->addToUndoGroup(wsList);
    }
}

/*****************************************************************************\
 *  FUNCTION    :   spaceVerically
 *  PARAMETERS  :   none
 *  RETURN      :   void
 *
 *  This function first makes a copy of the SelectionList. It then sorts the
 *  widgets according to their Y position. Then it checks if all widgets have
 *  the same parent widget. Otherwise they can not be spaced evenly and an error
 *  message is send. Then the distance between the widgets is calculated and the
 *  widgets are positioned accordingly. The first and last widgets do not move.
 \****************************************************************************/
void Model::spaceVerically()
{
    int                                 dUsedSpace = 0;
    int                                 dLastHeight = 0;
    int                                 dLastY = 0;
    WidgetController                    *wcParent = mSelectionList.at(0)->getParent();
    QList<WidgetController *>            tmpSelectList = mSelectionList;
    QList<WidgetController *>::iterator it;

    qSort(tmpSelectList.begin(), tmpSelectList.end(), Model::verticalSort);
    for (it = tmpSelectList.begin(); it != tmpSelectList.end(); ++it)
    {
        if ((*it)->getParent() != wcParent)
        {
            mModelHandler->sendMessage(QApplication::applicationName(), QString("Not all widgets have the same parent widget.\nThey can not be spaced vertically."), 1);
            return;
        }
        dLastHeight = (*it)->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt();
        dLastY = (*it)->getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt();
        dUsedSpace += dLastHeight;
    }
    int dFirstY = tmpSelectList.at(0)->getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt();
    int dWhiteSpace = ((dLastY + dLastHeight) - dFirstY) - dUsedSpace;
    int dNmbWidgets = tmpSelectList.count();
    int dWhiteSpaceSize = dWhiteSpace / (dNmbWidgets - 1);
    int dInterval = dFirstY;
    QList<WidgetState *> wsList;
    for (it = tmpSelectList.begin(); it != tmpSelectList.end(); ++it)
    {
        WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo((*it), ACT_MOVE, "Space Vertically");
        (*it)->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, QString::number(dInterval));
        dInterval += (*it)->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt() + dWhiteSpaceSize;
        UndoHandler::instance()->finishUndoInfo(wsState, (*it));
        wsList.append(wsState);
    }
    if (wsList.count())
    {
        UndoHandler::instance()->addToUndoGroup(wsList);
    }
}

void Model::centerHorizontally()
{
    if (mSelectionList.count())
    {
        int parentWidth = mSelectionList.at(0)->getParent()->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt();
        int dX = (parentWidth - mSelectionList.at(0)->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt()) / 2;
        WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo(mSelectionList.at(0), ACT_MOVE, "Center Horizontally");
        mSelectionList.at(0)->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, QString::number(dX));
        UndoHandler::instance()->finishUndoInfo(wsState, mSelectionList.at(0));
        UndoHandler::instance()->addToUndoGroup(wsState);
    }
}

void Model::centerVerically()
{
    if (mSelectionList.count())
    {
        int parentHeight = mSelectionList.at(0)->getParent()->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt();
        int dY = (parentHeight - mSelectionList.at(0)->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt()) / 2;
        WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo(mSelectionList.at(0), ACT_MOVE, "Center Vertically");
        mSelectionList.at(0)->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, QString::number(dY));
        UndoHandler::instance()->finishUndoInfo(wsState, mSelectionList.at(0));
        UndoHandler::instance()->addToUndoGroup(wsState);
    }
}
