//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for headertreewidgetdialog.
// !\description Class implementation file for headertreewidgetdialog.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "headertreewidgetdialog.h"
#include "CustomHeaderTags.h"

#include <QDebug>
#include <QMessageBox>

#include <SUIStyleSheet.h>
#include <FWQxCore/SUIArgumentException.h>
#include <FWQxWidgets/SUIMessageBox.h>
#include <boost/foreach.hpp>

headerTreeWidgetDialog::headerTreeWidgetDialog(WidgetController *tableWidget, QWidget *parent, QString headertags) :
    QDialog(parent),
    ui(new Ui::headerTreeWidgetDialog),
    mTableWidgetContr(tableWidget),
    mHeaderTags(headertags)
{
    ui->setupUi(this);
    ui->treeWidget->setColumnCount(3);
    ui->treeWidget->setColumnHidden(1, true);
    ui->treeWidget->setColumnHidden(2, true);
    addWidgets();
    ui->treeWidget->expandAll();
    mWidgetState = UndoHandler::instance()->getNewUndoInfo(mTableWidgetContr, ACT_COMPLEX, "Change Tablewidget");
    connect(ui->treeWidget, SIGNAL(itemSelectionChanged()), this, SLOT(onSelectionChanged()));
}

headerTreeWidgetDialog::~headerTreeWidgetDialog()
{
    UndoHandler::instance()->finishUndoInfo(mWidgetState, mTableWidgetContr);
    UndoHandler::instance()->addToUndoGroup(mWidgetState);
    delete ui;
}

void headerTreeWidgetDialog::on_pushButton_clicked()
{
    addrow(ui->treeWidget->currentItem());
}

void headerTreeWidgetDialog::on_pushButton_2_clicked()
{
    try
    {
        delete ui->treeWidget->currentItem();
        mTableWidgetContr->updatePixmap();
    }
    catch (SUI::ArgumentException *re)
    {
        SUI::MessageBox::warning(NULL,"ArgumentException",re->getExceptionMessage());
        delete re;
        return;
    }
    catch (SUI::Exception *re)
    {
        SUI::MessageBox::warning(NULL,"Exception",re->getExceptionMessage());
        delete re;
        return;
    }
}

void headerTreeWidgetDialog::on_pushButton_3_clicked()
{
    QTreeWidgetItem *parent = ui->treeWidget->currentItem();
    if (parent == NULL) {
        parent = ui->treeWidget->invisibleRootItem();
    }
    else {
        parent = ui->treeWidget->currentItem()->parent();
    }
    addrow(parent);
}

void headerTreeWidgetDialog::on_pushButton_4_clicked()
{
    try
    {
        mHeaderTagValue.clear();
        getItems(ui->treeWidget->invisibleRootItem());
        SUI::TableWidgetImpl *table = dynamic_cast<SUI::TableWidgetImpl *>(mTableWidgetContr->getBaseWidget());
        if (table->getPropertyValue(SUI::ObjectPropertyTypeEnum::fromString(mHeaderTags.toStdString())) != mHeaderTagValue.join("")) {
            table->setPropertyValue(SUI::ObjectPropertyTypeEnum::fromString(mHeaderTags.toStdString()), mHeaderTagValue.join(""));
            Model::instance()->setDataChanged(true);
        }
        emit accept();
        mTableWidgetContr->updatePixmap();
    }

    catch (SUI::ArgumentException *re)
    {
        SUI::MessageBox::warning(NULL,"ArgumentException",re->getExceptionMessage());
        delete re;
        return;
    }
    catch (SUI::Exception *re)
    {
        SUI::MessageBox::warning(NULL,"Exception",re->getExceptionMessage());
        delete re;
        return;
    }
}

void headerTreeWidgetDialog::addrow(QTreeWidgetItem *parent) {
    QTreeWidgetItem *item;
    if (parent == NULL) {
        parent = ui->treeWidget->invisibleRootItem();
    }
    item = new QTreeWidgetItem(parent);
    item->setFlags(Qt::ItemIsEditable | Qt::ItemIsEnabled | Qt::ItemIsSelectable);
    ui->treeWidget->expandItem(parent);
    ui->treeWidget->editItem(item, 0);
    ui->treeWidget->setCurrentItem(item);
}

void headerTreeWidgetDialog::getItems(QTreeWidgetItem *item)
{
    if (item != ui->treeWidget->invisibleRootItem()) {
        mHeaderTagValue << "<" + item->text(0);
    }
    for (int i = 0; i < item->childCount(); ++i) {
        getItems(item->child(i));
    }
    if (item != ui->treeWidget->invisibleRootItem()) {
        mHeaderTagValue << ">";
    }
}

void headerTreeWidgetDialog::addWidgets() {
    QString headerTagValue = dynamic_cast<SUI::TableWidgetImpl *>(mTableWidgetContr->getBaseWidget())->getPropertyValue(SUI::ObjectPropertyTypeEnum::fromString(mHeaderTags.toStdString()));

    HeaderTags  tmpHeaderTags(QString("root"), headerTagValue);

    BOOST_FOREACH(HeaderTags * child, tmpHeaderTags.getChildren()) {
        QTreeWidgetItem *newItem = ui->treeWidget->invisibleRootItem();
        addWidgets(child , newItem);
    }
}

void headerTreeWidgetDialog::addWidgets(HeaderTags *child, QTreeWidgetItem *item) {
    QTreeWidgetItem *newItem = new QTreeWidgetItem();
    newItem->setText(0, child->getName());
    newItem->setFlags(Qt::ItemIsEditable | Qt::ItemIsEnabled | Qt::ItemIsSelectable);
    item->addChild(newItem);

    BOOST_FOREACH(HeaderTags * child2, child->getChildren()) {
        addWidgets(child2, newItem);
    }
}

void headerTreeWidgetDialog::onSelectionChanged() {
    QList<QTreeWidgetItem*> selectedItems = ui->treeWidget->selectedItems();

    int depth = 0;
    if (selectedItems.count() > 0) {
        QTreeWidgetItem *item = selectedItems.first();
        while(item!=0){
            depth++;
            item = item->parent();
        }
    }

    if ((mHeaderTags == "HorizonHeaderTags" && (depth < 3)) || (mHeaderTags == "VerticalHeaderTags" && (depth < 1))) {
        ui->pushButton->setEnabled(true);
    }
    else {
        ui->pushButton->setEnabled(false);
    }
}
