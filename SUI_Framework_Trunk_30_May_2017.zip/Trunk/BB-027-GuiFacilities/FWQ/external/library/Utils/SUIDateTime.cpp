//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for DateTime.
// !\description Class implementation file for DateTime.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "FWQxUtils/SUIDateTime.h"

#include "SUIDateTimeImpl.h"

SUI::DateTime::~DateTime()
{
}

boost::shared_ptr<SUI::DateTime> SUI::DateTime::createDateTime() {
    return boost::shared_ptr<DateTime>(new DateTimeImpl);
}
