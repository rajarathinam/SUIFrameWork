//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for GraphicsLineItem.
// !\description Class implementation file for GraphicsLineItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "FWQxGraphicsItems/SUIGraphicsLineItem.h"

#include <QGraphicsLineItem>
#include <QColor>
#include <QPointF>
#include <QRectF>
#include <QSize>
#include <QPen>

#include "FWQxCore/SUIObjectFactory.h"

SUI::GraphicsLineItem::GraphicsLineItem(SUI::GraphicsItem *parent) : 
    GraphicsItem(
          SUI::ObjectType::GraphicsLineItem,
          new QGraphicsLineItem(parent ? static_cast<QGraphicsItem*>(ObjectFactory::getImplementation(parent)) : NULL),
          parent),
    penColor(SUI::ColorEnum::Black)
{       
}

SUI::GraphicsLineItem::~GraphicsLineItem()
{
    delete static_cast<QGraphicsLineItem*>(GraphicsItem::getImplementation());
}

SUI::ColorEnum::Color SUI::GraphicsLineItem::getPenColor() const {
   return penColor;
}

void SUI::GraphicsLineItem::setPenColor(const SUI::ColorEnum::Color color) {
   if (!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color)) return;
   penColor = color;
   QGraphicsLineItem *item = static_cast<QGraphicsLineItem*>(GraphicsItem::getImplementation());
   QPen pen = item->pen();
   pen.setColor(QColor(QString::fromStdString(ColorEnum::toString(color))));
   item->setPen(pen);
   
   if (!penColorChanged.empty()) {
      penColorChanged();
   }
}

void SUI::GraphicsLineItem::setPenWidth(int width) {
   QGraphicsLineItem *item = static_cast<QGraphicsLineItem*>(GraphicsItem::getImplementation());
   QPen pen = item->pen();
   pen.setWidth(width > 0 ? ((width < 6) ? width : 5) : 1);
   item->setPen(pen);
}

void SUI::GraphicsLineItem::setCosmetic(bool enabled) {
   QGraphicsLineItem *item = static_cast<QGraphicsLineItem*>(GraphicsItem::getImplementation());
   QPen pen = item->pen();
   pen.setCosmetic(enabled);
   item->setPen(pen);
}

int SUI::GraphicsLineItem::getPenWidth() const {
   return static_cast<QGraphicsLineItem*>(GraphicsItem::getImplementation())->pen().width();
}


void SUI::GraphicsLineItem::setPosition(double x, double y) {
   static_cast<QGraphicsLineItem*>(GraphicsItem::getImplementation())->setPos(x,y);
}

double SUI::GraphicsLineItem::getLength() const {
   return static_cast<QGraphicsLineItem*>(GraphicsItem::getImplementation())->line().length();
}

double SUI::GraphicsLineItem::getAngle() const {
   return static_cast<QGraphicsLineItem*>(GraphicsItem::getImplementation())->line().angle();
}

double SUI::GraphicsLineItem::getAngleTo(SUI::GraphicsLineItem *other) const {
   return static_cast<QGraphicsLineItem*>(GraphicsItem::getImplementation())->line().angleTo(static_cast<QGraphicsLineItem*>(other->GraphicsItem::getImplementation())->line());
}

double SUI::GraphicsLineItem::getBoundingRectWidth() const {
   return static_cast<QGraphicsLineItem*>(GraphicsItem::getImplementation())->boundingRect().width();
}

double SUI::GraphicsLineItem::getBoundingRectHeight() const {
   return static_cast<QGraphicsLineItem*>(GraphicsItem::getImplementation())->boundingRect().height();
}

void SUI::GraphicsLineItem::setP1(double x, double y) {
   QGraphicsLineItem *item = static_cast<QGraphicsLineItem*>(GraphicsItem::getImplementation());
   item->setLine(QLineF(QPointF(x,y),item->line().p2()));
}

void SUI::GraphicsLineItem::setP2(double x, double y) {
   QGraphicsLineItem *item = static_cast<QGraphicsLineItem*>(GraphicsItem::getImplementation());
   item->setLine(QLineF(item->line().p1(),QPointF(x,y)));
}
