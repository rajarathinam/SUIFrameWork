//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for GraphicsRectItem.
// !\description Class implementation file for GraphicsRectItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "FWQxGraphicsItems/SUIGraphicsRectItem.h"

#include <QSize>
#include <QPen>
#include <QGraphicsRectItem>

#include "FWQxCore/SUIColorEnum.h"
#include "FWQxCore/SUIObjectFactory.h"

SUI::GraphicsRectItem::GraphicsRectItem(SUI::GraphicsItem *parent) : 
    GraphicsItem(
          SUI::ObjectType::GraphicsRectItem,
          new QGraphicsRectItem(parent ? static_cast<QGraphicsItem*>(ObjectFactory::getImplementation(parent)) : NULL),
          parent),
    penColor(SUI::ColorEnum::Black)
{      
}

SUI::GraphicsRectItem::~GraphicsRectItem()
{
    delete static_cast<QGraphicsRectItem*>(GraphicsItem::getImplementation());
}

void SUI::GraphicsRectItem::setSize(double width, double height) {
    QGraphicsRectItem *item = static_cast<QGraphicsRectItem*>(GraphicsItem::getImplementation());
    QRectF r = item->rect();
    r.setSize(QSize(width,height));
    item->setRect(r);
}

double SUI::GraphicsRectItem::getWidth() const {
    return static_cast<QGraphicsRectItem*>(GraphicsItem::getImplementation())->rect().width();
}

double SUI::GraphicsRectItem::getHeight() const {
   return static_cast<QGraphicsRectItem*>(GraphicsItem::getImplementation())->rect().height();
}

void SUI::GraphicsRectItem::setPenWidth(int width) {
    QGraphicsRectItem *item = static_cast<QGraphicsRectItem*>(GraphicsItem::getImplementation());
    QPen pen = item->pen();
    pen.setWidth(width < 1 ? 1 : (width < 6 ? width : 5));
    item->setPen(pen);
}

int SUI::GraphicsRectItem::getPenWidth() const {
    return static_cast<QGraphicsRectItem*>(GraphicsItem::getImplementation())->pen().width();
}

SUI::ColorEnum::Color SUI::GraphicsRectItem::getPenColor() const {
    return penColor;
}

void SUI::GraphicsRectItem::setPenColor(const SUI::ColorEnum::Color color) {
    if (ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color)) {
       penColor = color;
       QGraphicsRectItem *item = static_cast<QGraphicsRectItem*>(GraphicsItem::getImplementation());
       QPen pen = item->pen();
       pen.setColor(QColor(QString::fromStdString(ColorEnum::toString(color))));
       item->setPen(pen);
    }
}

SUI::ColorEnum::Color SUI::GraphicsRectItem::getBrushColor() const {
    return getPenColor();
}

void SUI::GraphicsRectItem::setBrushColor(const SUI::ColorEnum::Color color) {
    if (ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color) || color == ColorEnum::Transparent) {
       if (color != ColorEnum::Transparent) {
          setPenColor(color);
       }
       static_cast<QGraphicsRectItem*>(GraphicsItem::getImplementation())->setBrush(color == ColorEnum::Transparent ? Qt::NoBrush : QBrush(QColor(QString::fromStdString(ColorEnum::toString(color)))));
    }
}
