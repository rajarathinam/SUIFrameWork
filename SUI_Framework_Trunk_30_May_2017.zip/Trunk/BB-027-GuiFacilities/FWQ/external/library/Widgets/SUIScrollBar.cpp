//-----------------------------------------------------------------------------|
//                                                                             |
//                            C++ Source File                                  |
//                                                                             |
//-----------------------------------------------------------------------------|
//
// Ident        : SUIScrollBar.cpp
// Author       :
// Description  : Class implementation file for ScrollBar.
//
// ! \file        SUIScrollBar.cpp
// ! \brief       Class implementation file for ScrollBar.
//
//-----------------------------------------------------------------------------|
//                                                                             |
//        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
//                           All rights reserved                               |
//                                                                             |
//-----------------------------------------------------------------------------|

#include "FWQxWidgets/SUIScrollBar.h"

#include "FWQxCore/SUIObjectFactory.h"

SUI::ScrollBar::ScrollBar() :
    Widget(SUI::ObjectType::ScrollBar)
{
}

SUI::ScrollBar::~ScrollBar()
{
}

