//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for StateWidget.
// !\description Class implementation file for StateWidget.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "FWQxWidgets/SUIStateWidget.h"

#include "FWQxCore/SUIObjectFactory.h"

SUI::StateWidget::StateWidget() : 
    Widget(SUI::ObjectType::StateWidget)
{
}

SUI::StateWidget::StateWidget(const SUI::ObjectType::Type &type) : 
    Widget(type)
{
}

SUI::StateWidget::~StateWidget()
{
}
