//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::LineStyleEnum.
// !\description Header file for class SUI::LineStyleEnum.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUILINESTYLEENUM_H
#define SUILINESTYLEENUM_H

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief This enum type is used to describe line styles.
 */
class LineStyleEnum
{
public:
    /*!
     * \brief LineStyle
     * The line style enumeration
     */
    typedef enum
    {
        NoLine,
        Solid,
        Dash,
        Dot,
        DashDot,
        DashDotLine
    } LineStyle;
};
}
#endif // SUILINESTYLEENUM_H
