//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::CheckBox.
// !\description Header file for class SUI::CheckBox.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUICHECKBOX_H
#define SUICHECKBOX_H

#include "FWQxWidgets/SUIWidget.h"
#include "FWQxCore/SUIICheckable.h"
#include "FWQxCore/SUIIText.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 *
 * \brief The CheckBox class
 */
class SUI_SHARED_EXPORT CheckBox : public Widget, public ICheckable, public IText
{
public:
    virtual ~CheckBox();
    
protected:
    CheckBox();
};
}

#endif // SUICHECKBOX_H
