//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::SpinBox.
// !\description Header file for class SUI::SpinBox.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUISPINBOX_H
#define SUISPINBOX_H

#include "FWQxWidgets/SUIWidget.h"
#include "FWQxCore/SUIIText.h"
#include "FWQxCore/SUIINumeric.h"
#include "FWQxCore/SUIIErrorMode.h"
#include "FWQxCore/SUIIAlignable.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief The SpinBox class
 */
class SUI_SHARED_EXPORT SpinBox : public Widget, public INumeric<int>, public IErrorMode, public IAlignable
{
public:
    virtual ~SpinBox();
    
protected:
    SpinBox();
};
}

#endif // SUISPINBOX_H
