//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::GraphicsLineItem.
// !\description Header file for class SUI::GraphicsLineItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUIGRAPHICSLINEITEM_H
#define SUIGRAPHICSLINEITEM_H

#include "FWQxCore/SUIDeprecated.h"

#include "FWQxGraphicsItems/SUIGraphicsItem.h"
#include "FWQxCore/SUIColorEnum.h"

namespace SUI {
/*!
 * \ingroup FWQxGraphicsItems
 *
 * \brief The GraphicsLine class
 */
class SUI_SHARED_EXPORT GraphicsLineItem : public GraphicsItem
{
public:
    virtual ~GraphicsLineItem();

    /*!
     * \brief getPenColor
     * Returns the color of this pen's brush
     * \return
     */
    SUI::ColorEnum::Color getPenColor() const;

    /*!
     * \brief setPenColor
     * Sets the color of this pen's brush to the given color
     * \param color
     */
    void setPenColor(const SUI::ColorEnum::Color color);

    /*!
     * \brief setPenWidth
     * Sets the pen width to the given width in pixels with integer precision
     * \param width
     */
    void setPenWidth(int width);

    /*!
     * \brief getPenWidth
     * Returns the pen width with integer precision
     * \return
     */
    int getPenWidth() const;

    /*!
     * \brief setCosmetic
     * Sets the drawing pen to cosmetic or non-cosmetic.
     * Cosmetic pens have a constant width, so its outline
     * will have the same thickness at different scale factors
     * \param enabled
     */
    void setCosmetic(bool enabled);
    
    /*!
     * \brief getLength
     * Returns the length of the line in degrees
     * \return
     */
    double getLength() const;

    /*!
     * \brief getAngle
     * Returns the angle of the line item in degrees
     * The return value will be in the range of values from 0.0 up to
     * but not including 360.0. The angles are measured counter-clockwise
     * from a point on the x-axis to the right of the origin (x > 0)
     * \return
     */
    double getAngle() const;

    /*!
     * \brief getAngleTo
     * Returns the angle (in positive degrees) from this line to the given line,
     * taking the direction of the lines into account. If the lines do not intersect
     * within their range, it is the intersection point of the extended lines that
     * serves as origin. The returned value represents the number of degrees you need
     * to add to this line to make it have the same angle as the given line,
     * going counter-clockwise.
     * \param line
     * \return
     */
    double getAngleTo(SUI::GraphicsLineItem *line) const;
    
    /*!
     * \brief setP1
     * Sets the starting point of the line to (x,y)
     * \param x
     * \param y
     */
    void setP1(double x, double y);

    /*!
     * \brief setP2
     * Sets the end point of the line item to (x,y)
     * \param x
     * \param y
     */
    void setP2(double x, double y);

    /*!
     * \brief penColorChanged
     * Callback that is triggered when the pen color has been changed
     */
    boost::function<void()> penColorChanged;

    // GraphicsItem overrides
    /*!
     * \brief setPosition
     * Sets the position of the item to (x, y), which is in parent coordinates.
     * For items with no parent, (x, y) is in scene coordinates.
     * The position of the item describes its origin (local coordinate (0, 0))
     * in parent coordinates.
     * \param x
     * \param y
     */
    virtual void setPosition(double x, double y);

    /*!
     * \brief getBoundingRectWidth
     * Returns the width of the line item's bounding rectangle
     * \return
     */
    virtual double getBoundingRectWidth() const;

    /*!
     * \brief getBoundingRectHeight
     * Returns the height of the line item's bounding rectangle
     * \return
     */
    virtual double getBoundingRectHeight() const;
    
private:
    friend class ObjectFactory;
    explicit GraphicsLineItem(SUI::GraphicsItem *parent = NULL);
    GraphicsLineItem(const GraphicsLineItem &copy);
    GraphicsLineItem &operator=(const GraphicsLineItem &copy);

    SUI::ColorEnum::Color penColor;
};
}

#endif // SUIGRAPHICSLINEITEM_H
