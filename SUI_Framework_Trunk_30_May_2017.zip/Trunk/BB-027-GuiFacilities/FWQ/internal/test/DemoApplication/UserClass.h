//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Header File                                |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author FBE Auto generated
// !\brief Brief description here
// !\description Description
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2017, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|
#ifndef USERCLASS_H
#define USERCLASS_H

//----------------------------------------------------------------------------|
//                                 Forward declaration                        |
//----------------------------------------------------------------------------|
namespace SUI {
class UserClass;
class Button;
class ProgressBar;
class Dialog;
class Label;

} //namespace SUI

namespace NSPC {
namespace MOC {
    class UserClass;
} //namespace MOC
//----------------------------------------------------------------------------|
//                                 Class declaration                          |
//----------------------------------------------------------------------------|
class UserClass
{

public:
    explicit UserClass();
    ~UserClass();

    SUI::Button *getStartButton();
    SUI::Button *getStopButton();
    SUI::Label *getTimeLabel();
    SUI::ProgressBar *getProgressBar();

    SUI::Dialog *getDialog();

private:
    MOC::UserClass *sui;
};
} //namespace NSPC
#endif // USERCLASS_H
