#ifndef LINEEDITUNITTEST_H
#define LINEEDITUNITTEST_H

#include "SUIWidgetUnitTest.h"

namespace SUI {

class LineEdit;

class LineEditUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    explicit LineEditUnitTest(LineEdit *object, QObject *parent = 0);
    virtual ~LineEditUnitTest();

protected:
    void callInterfaceTests();

private slots:
    void setPlaceHolderText();
    void setPlaceHolderText_data();

private:
    LineEdit *object;
};

}
#endif // LINEEDITUNITTEST_H
