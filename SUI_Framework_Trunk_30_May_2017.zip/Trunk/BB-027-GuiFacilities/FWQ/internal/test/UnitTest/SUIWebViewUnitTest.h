#ifndef SUIWEBVIEWUNITTEST_H
#define SUIWEBVIEWUNITTEST_H

#include "SUIWidgetUnitTest.h"
#include <FWQxWidgets/SUIWebView.h>

namespace SUI {

class WebView;

class WebViewUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    explicit WebViewUnitTest(SUI::WebView *object, QObject *parent = 0);
    virtual ~WebViewUnitTest();

private slots:
    void setUrl();
    void setHtml();
    void setZoomFactor();

private:
    WebView *object;
};

}

#endif // SUIWEBVIEWUNITTEST_H
