#ifndef SUILISTVIEWUNITTEST_H
#define SUILISTVIEWUNITTEST_H

#include "SUIWidgetUnitTest.h"


namespace SUI {

class ListView;

class ListViewUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    explicit ListViewUnitTest(ListView *object, QObject *parent = 0);
    virtual ~ListViewUnitTest();

protected:
    void callInterfaceTests();

private:
    ListView *object;
};

}
#endif // SUILISTVIEWUNITTEST_H
