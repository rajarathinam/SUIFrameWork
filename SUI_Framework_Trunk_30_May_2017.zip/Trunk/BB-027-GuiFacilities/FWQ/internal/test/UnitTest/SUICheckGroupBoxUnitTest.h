#ifndef SUICHECKGROUPBOXUNITTEST_H
#define SUICHECKGROUPBOXUNITTEST_H

#include "SUIWidgetUnitTest.h"

namespace SUI {

class CheckGroupBox;

class CheckGroupBoxUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    explicit CheckGroupBoxUnitTest(CheckGroupBox *object, QObject *parent = 0);
    virtual ~CheckGroupBoxUnitTest();

protected:
    void callInterfaceTests();

private:
    CheckGroupBox *object;
};

}
#endif // SUICHECKGROUPBOXUNITTEST_H
