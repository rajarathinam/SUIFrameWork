#include"SUICheckMarkUnitTest.h"

#include <FWQxWidgets/SUICheckMark.h>
#include <QTest>
#include"SUIIColorableUnitTest.h"


SUI::CheckMarkUnitTest::CheckMarkUnitTest(SUI::CheckMark *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::CheckMarkUnitTest::~CheckMarkUnitTest() {
    delete object;
}

void SUI::CheckMarkUnitTest::callInterfaceTests() {
    //IColorable tests
    IColorableUnitTest iColorableUnitTest(object);
    //valid colors
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Red));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Green));
    //invalid colors
    QCOMPARE(iColorableUnitTest.setColor(SUI::ColorEnum::White), false);
    QCOMPARE(iColorableUnitTest.setColor(SUI::ColorEnum::Gray), false);
    QCOMPARE(iColorableUnitTest.setColor(SUI::ColorEnum::Yellow), false);
    QCOMPARE(iColorableUnitTest.setColor(SUI::ColorEnum::Black), false);
    QCOMPARE(iColorableUnitTest.setColor(SUI::ColorEnum::Blue), false);
    QCOMPARE(iColorableUnitTest.setColor(SUI::ColorEnum::Blue), false);
    QCOMPARE(iColorableUnitTest.setColor(SUI::ColorEnum::Orange), false);
    QCOMPARE(iColorableUnitTest.setColor(SUI::ColorEnum::Transparent), false);
    QCOMPARE(iColorableUnitTest.setColor(SUI::ColorEnum::Standard), false);
}

