#include "SUIWidgetPageUnitTest.h"
#include <QTest>

SUI::WidgetPageUnitTest::WidgetPageUnitTest(SUI::WidgetPage *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::WidgetPageUnitTest::~WidgetPageUnitTest() {
    delete object;
}
