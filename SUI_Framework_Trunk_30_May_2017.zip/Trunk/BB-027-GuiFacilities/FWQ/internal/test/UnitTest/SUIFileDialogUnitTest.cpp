#include "SUIFileDialogUnitTest.h"
#include "SUIIClickableUnitTest.h"

SUI::FileDialogUnitTest::FileDialogUnitTest(SUI::FileDialog *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::FileDialogUnitTest::~FileDialogUnitTest() {
    delete object;
}

void SUI::FileDialogUnitTest::callInterfaceTests() {
    //IClickable tests
    IClickableUnitTest iClickable(object);
    iClickable.clickable();
}
