#ifndef ITOOLTIPUNITTEST_H
#define ITOOLTIPUNITTEST_H

#include <QObject>
#include <QTest>

class BaseObjectToolTipUnitTest : public QObject
{
    Q_OBJECT
public:
    BaseObjectToolTipUnitTest();
private Q_SLOTS:
    void cleanupTestCase();
    void testSetTitleCase();
    void testSetTitleCase_data();
};

#endif // ITOOLTIPUNITTEST_H
