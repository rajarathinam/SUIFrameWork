#include "SUIDateTimeEditUnitTest.h"
#include "SUIIClickableUnitTest.h"

SUI::DateTimeEditUnitTest::DateTimeEditUnitTest(SUI::DateTimeEdit *object, QObject *parent) :
    WidgetUnitTest(object, parent),
    object(object)
{
}

SUI::DateTimeEditUnitTest::~DateTimeEditUnitTest() {
    delete object;
}

void SUI::DateTimeEditUnitTest::callInterfaceTests() {
    //IClickable tests
    IClickableUnitTest iClickable(object);
    iClickable.clickable();
}
