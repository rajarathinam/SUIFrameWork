#ifndef SUIDOUBLESPINBOXUNITTEST_H
#define SUIDOUBLESPINBOXUNITTEST_H

#include "SUIWidgetUnitTest.h"

namespace SUI {

class DoubleSpinBox;

class DoubleSpinBoxUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    explicit DoubleSpinBoxUnitTest(DoubleSpinBox *object, QObject *parent = 0);
    virtual ~DoubleSpinBoxUnitTest();

protected:
    void callInterfaceTests();

private:
    DoubleSpinBox *object;
};

}

#endif // SUIDOUBLESPINBOXUNITTEST_H
