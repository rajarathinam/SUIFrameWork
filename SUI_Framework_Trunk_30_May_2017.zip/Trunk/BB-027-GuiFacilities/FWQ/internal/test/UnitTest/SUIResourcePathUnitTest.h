#ifndef SUIRESOURCEPATHUNITTEST_H
#define SUIRESOURCEPATHUNITTEST_H

#include <FWQxCore/SUIResourcePath.h>

#include <QObject>
namespace SUI {
class ResourcePath;
class ResourcePathUnitTest : public QObject
{
    Q_OBJECT

public:
    ResourcePathUnitTest();

private Q_SLOTS:
    void setResourcePath();
    void setResourcePath_data();

    void getResourceFile();
    void getResourceFile_data();
private:
    ResourcePath *object;
};

}

#endif //SUIRESOURCEPATHUNITTEST_H
