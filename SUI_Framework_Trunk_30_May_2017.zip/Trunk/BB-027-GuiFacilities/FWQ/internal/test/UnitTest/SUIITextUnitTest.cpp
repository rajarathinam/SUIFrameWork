#include "SUIITextUnitTest.h"

#include <QTest>

#include <FWQxCore/SUIIText.h>

SUI::ITextUnitTest::ITextUnitTest(SUI::IText *object) :
    object(object)
{
    Q_ASSERT(object);
}

bool SUI::ITextUnitTest::setText() {
    object->setText("test");
    return QString::fromStdString(object->getText()) == "test";
}

bool SUI::ITextUnitTest::clearText() {
    object->setText("test");
    object->clearText();
    return QString::fromStdString(object->getText()) == "";
}

bool SUI::ITextUnitTest::setBold() {
    object->setBold(true);
    bool bold = object->isBold();

    object->setBold(false);
    bool notBold = object->isBold();

    return bold && !notBold;
}
