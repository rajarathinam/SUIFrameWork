#ifndef GRAPHICSITEMUNITTEST_H
#define GRAPHICSITEMUNITTEST_H

#include "SUIObjectUnitTest.h"

namespace SUI {

class GraphicsItem;

class GraphicsItemUnitTest : public ObjectUnitTest
{
    Q_OBJECT

public:
    GraphicsItemUnitTest(GraphicsItem *object, QObject *parent);
    virtual ~GraphicsItemUnitTest();

private slots:
    void setPosition();
    void setX();
    void setY();
    void setZValue();

private:
    GraphicsItem *object;
};

}
#endif // GRAPHICSITEMUNITTEST_H
