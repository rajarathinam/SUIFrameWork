#include "SUIIErrorModeUnitTest.h"
#include <FWQxCore/SUIIErrorMode.h>
#include <FWQxCore/SUIErrorModeEnum.h>

#include <QTest>

SUI::IErrorModeUnitTest::IErrorModeUnitTest(SUI::IErrorMode *object) :
    object(object)
{
    Q_ASSERT(object);
}

bool SUI::IErrorModeUnitTest::setErrorMode()
{
    // Not yet possible to check the actual value after setting the error mode.
    // External interface will be extended soon to verify this.
    // For now, check if there's no segfault.
    object->setMode(ErrorModeEnum::Error);
    object->setMode(ErrorModeEnum::None);
    object->setMode(ErrorModeEnum::Ok);
    object->setMode(ErrorModeEnum::Warning);
    return true;
}
