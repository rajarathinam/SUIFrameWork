#include "SUIListViewUnitTest.h"
#include <FWQxWidgets/SUIListView.h>
#include <QTest>
#include "SUIITextUnitTest.h"
#include "SUIIClickableUnitTest.h"

SUI::ListViewUnitTest::ListViewUnitTest(SUI::ListView *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::ListViewUnitTest::~ListViewUnitTest() {
    delete object;
}

void SUI::ListViewUnitTest::callInterfaceTests() {
    // IText UnitTests
    ITextUnitTest iTextUnitTest(object);
    QVERIFY(iTextUnitTest.setText());
    QVERIFY(iTextUnitTest.clearText());
    QVERIFY(iTextUnitTest.setBold());

    //IClickable tests
    IClickableUnitTest iClickable(object);
    iClickable.clickable();

    //TO DO StringList tests
    //TO DO IFilterable tests

}
