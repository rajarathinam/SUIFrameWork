#ifndef SUITABWIDGETUNITTEST_H
#define SUITABWIDGETUNITTEST_H

#include "SUIWidgetUnitTest.h"

namespace SUI {

class TabWidget;

class TabWidgetUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    explicit TabWidgetUnitTest(SUI::TabWidget *object, QObject *parent = 0);
    virtual ~TabWidgetUnitTest();
private slots:

    void testInterfaceFunctions();

private:
    TabWidget *object;
};

}
#endif // SUITABWIDGETUNITTEST_H
