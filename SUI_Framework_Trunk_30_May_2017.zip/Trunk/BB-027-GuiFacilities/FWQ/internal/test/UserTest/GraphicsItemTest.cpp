#include "GraphicsItemTest.h"

#include <QImage>

#include <FWQxCore/SUIObjectFactory.h>
#include <FWQxWidgets/SUIDialog.h>
#include <FWQxCore/SUIObjectList.h>

#include <FWQxWidgets/SUIColorCrossDrop.h>
#include <FWQxWidgets/SUIDropDown.h>
#include <FWQxWidgets/SUISpinBox.h>
#include <FWQxWidgets/SUICheckBox.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUILineEdit.h>

#include <FWQxWidgets/SUIGraphicsView.h>
#include <FWQxGraphicsItems/SUIGraphicsScene.h>
#include <FWQxGraphicsItems/SUIGraphicsCrosshairItem.h>
#include <FWQxGraphicsItems/SUIGraphicsEllipseItem.h>
#include <FWQxGraphicsItems/SUIGraphicsLineItem.h>
#include <FWQxGraphicsItems/SUIGraphicsPixmapItem.h>
#include <FWQxGraphicsItems/SUIGraphicsRectItem.h>
#include <FWQxGraphicsItems/SUIGraphicsTextItem.h>
#include <FWQxGraphicsItems/SUIGraphicsSvgItem.h>

#include <boost/bind.hpp>

#include <assert.h>
#include <QDebug>

GraphicsItemTest::GraphicsItemTest(SUI::Dialog *dialog) :
    dialog(dialog),
    graphicsView(dialog->getObjectList()->getObject<SUI::GraphicsView>("imv395")),
    itemSelector(dialog->getObjectList()->getObject<SUI::DropDown>("ddb357")),
    colorSelector(dialog->getObjectList()->getObject<SUI::ColorCrossDrop>("ccd367")),
    penWidthSpinBox(dialog->getObjectList()->getObject<SUI::SpinBox>("isb577")),
    fillItemCheckBox(dialog->getObjectList()->getObject<SUI::CheckBox>("cbx907")),
    visibilityCheckBox(dialog->getObjectList()->getObject<SUI::CheckBox>("cbx545")),
    xSpinBox(dialog->getObjectList()->getObject<SUI::SpinBox>("isb359")),
    ySpinBox(dialog->getObjectList()->getObject<SUI::SpinBox>("isb360")),
    widthSpinBox(dialog->getObjectList()->getObject<SUI::SpinBox>("isb363")),
    heightSpinBox(dialog->getObjectList()->getObject<SUI::SpinBox>("isb365")),
    setPixmapButton(dialog->getObjectList()->getObject<SUI::Button>("btn369")),
    addItemButton(dialog->getObjectList()->getObject<SUI::Button>("btn356")),
    removeItemButton(dialog->getObjectList()->getObject<SUI::Button>("btn368")),
    xLineEdit(dialog->getObjectList()->getObject<SUI::LineEdit>("lne536")),
    yLineEdit(dialog->getObjectList()->getObject<SUI::LineEdit>("lne538")),
    widthLineEdit(dialog->getObjectList()->getObject<SUI::LineEdit>("lne537")),
    heightLineEdit(dialog->getObjectList()->getObject<SUI::LineEdit>("lne539")),
    textLineEdit(dialog->getObjectList()->getObject<SUI::LineEdit>("lne370"))
{
    assert(dialog);
    assert(graphicsView);
    assert(itemSelector);
    assert(colorSelector);
    assert(penWidthSpinBox);
    assert(fillItemCheckBox);
    assert(visibilityCheckBox);
    assert(widthSpinBox);
    assert(heightSpinBox);
    assert(xSpinBox);
    assert(ySpinBox);
    assert(setPixmapButton);
    assert(addItemButton);
    assert(removeItemButton);
    assert(xLineEdit);
    assert(yLineEdit);
    assert(widthLineEdit);
    assert(heightLineEdit);

    itemSelector->currentIndexChanged = boost::bind(&GraphicsItemTest::onCurrentItemChanged,this,_1);
    penWidthSpinBox->valueChanged = boost::bind(&GraphicsItemTest::onItemPenWidthChanged,this);
    fillItemCheckBox->checkStateChanged = boost::bind(&GraphicsItemTest::onFillItemChanged ,this, _1);
    visibilityCheckBox->checkStateChanged = boost::bind(&GraphicsItemTest::onItemVisibilityChanged,this,_1);
    xSpinBox->valueChanged = boost::bind(&GraphicsItemTest::onItemPositionChanged, this);
    ySpinBox->valueChanged = boost::bind(&GraphicsItemTest::onItemPositionChanged, this);
    widthSpinBox->valueChanged = boost::bind(&GraphicsItemTest::onItemSizeChanged , this);
    heightSpinBox->valueChanged = boost::bind(&GraphicsItemTest::onItemSizeChanged , this);
    setPixmapButton->clicked = boost::bind(&GraphicsItemTest::onSetPixmapClicked, this);
    addItemButton->clicked = boost::bind(&GraphicsItemTest::onAddItemClicked, this);
    removeItemButton->clicked = boost::bind(&GraphicsItemTest::onRemoveItemClicked, this);

    //set default values
    penWidthSpinBox->setValue(1);
    widthSpinBox->setValue(50);
    heightSpinBox->setValue(50);
    visibilityCheckBox->setChecked(true);
    //set default values
    widthSpinBox->setEnabled(false);
    heightSpinBox->setEnabled(false);
}

GraphicsItemTest::~GraphicsItemTest() {
}

void GraphicsItemTest::onCurrentItemChanged(int /*index*/) {
    std::list<std::string> items = itemSelector->getSelectedItems();
    if(items.size() != 1)   return;        // TODO: Log some error?
    std::string currentItem = *items.begin();

    SUI::ObjectType::Type graphicsItemType = SUI::ObjectType::fromString(currentItem);

    widthSpinBox->setEnabled(true);
    heightSpinBox->setEnabled(true);
    //TODO make controls visible or not depending on the item type selected
    switch(graphicsItemType) {
    case SUI::ObjectType::GraphicsLineItem:
        widthSpinBox->setEnabled(false);
        heightSpinBox->setEnabled(false);
        break;
    case SUI::ObjectType::GraphicsRectItem: break;
    case SUI::ObjectType::GraphicsCrosshairItem: break;
    case SUI::ObjectType::GraphicsPixmapItem: break;
    case SUI::ObjectType::GraphicsTextItem:
        heightSpinBox->setEnabled(false);
        break;
    case SUI::ObjectType::GraphicsEllipseItem: break;
    case SUI::ObjectType::GraphicsSvgItem: break;
    default: break;
    }
    onGeoRequested();
}

void GraphicsItemTest::onItemPositionChanged() {
    std::list<std::string> items = itemSelector->getSelectedItems();
    if(items.size() != 1)   return;        // TODO: Log some error?
    std::string currentItem = *items.begin();

    SUI::GraphicsItem  *graphicsItem = dialog->getObjectList()->getObject<SUI::GraphicsItem>(currentItem);
    if (!graphicsItem) return;

    graphicsItem->setPosition(xSpinBox->getValue(),ySpinBox->getValue());
    onGeoRequested();
}

void GraphicsItemTest::onItemVisibilityChanged(bool checked) {
    std::list<std::string> items = itemSelector->getSelectedItems();
    if(items.size() != 1)   return;        // TODO: Log some error?
    std::string currentItem = *items.begin();

    SUI::GraphicsItem *graphicsItem = dialog->getObjectList()->getObject<SUI::GraphicsItem>(currentItem);
    if (!graphicsItem) return;

    graphicsItem->setVisible(checked);
}

void GraphicsItemTest::onFillItemChanged(bool checked) {
    SUI::ColorEnum::Color color = colorSelector->getColor();

    std::list<std::string> items = itemSelector->getSelectedItems();
    if(items.size() != 1)   return;        // TODO: Log some error?
    std::string currentItem = *items.begin();

    SUI::GraphicsItem *graphicsItem = dialog->getObjectList()->getObject<SUI::GraphicsItem>(currentItem);
    if (!graphicsItem) return;

    if (dynamic_cast<SUI::GraphicsPixmapItem*>(graphicsItem)) return;
    if (dynamic_cast<SUI::GraphicsCrosshairItem*>(graphicsItem)) return;
    if (dynamic_cast<SUI::GraphicsLineItem*>(graphicsItem)) return;

    SUI::GraphicsEllipseItem *graphicsEllipseItem = dynamic_cast<SUI::GraphicsEllipseItem*>(graphicsItem);
    if (graphicsEllipseItem) return graphicsEllipseItem->setBrushColor(checked ? color : SUI::ColorEnum::Transparent);

    SUI::GraphicsRectItem *graphicsRectItem = dynamic_cast<SUI::GraphicsRectItem*>(graphicsItem);
    if (graphicsRectItem) return graphicsRectItem->setBrushColor(checked ? color : SUI::ColorEnum::Transparent);

    SUI::GraphicsTextItem *graphicsTextItem = dynamic_cast<SUI::GraphicsTextItem*>(graphicsItem);
    if (graphicsTextItem) return graphicsTextItem->setBrushColor(checked ? color : SUI::ColorEnum::Transparent);
}

void GraphicsItemTest::onItemSizeChanged() {
    std::list<std::string> items = itemSelector->getSelectedItems();
    if(items.size() != 1)   return;        // TODO: Log some error?
    std::string currentItem = *items.begin();

    SUI::GraphicsItem  *graphicsItem = dialog->getObjectList()->getObject<SUI::GraphicsItem>(currentItem);
    if (!graphicsItem) return;

//    onGeoRequested();

    SUI::GraphicsPixmapItem *graphicsPixmapItem = dynamic_cast<SUI::GraphicsPixmapItem*>(graphicsItem);
    if (graphicsPixmapItem)
    {
        graphicsPixmapItem->scale(widthSpinBox->getValue(),heightSpinBox->getValue());
        return onGeoRequested();
    }

    SUI::GraphicsCrosshairItem *graphicsCrosshairItem = dynamic_cast<SUI::GraphicsCrosshairItem*>(graphicsItem);
    if (graphicsCrosshairItem)
    {
        graphicsCrosshairItem->setSize(widthSpinBox->getValue(),heightSpinBox->getValue());
        return onGeoRequested();
    }

    SUI::GraphicsEllipseItem *graphicsEllipseItem = dynamic_cast<SUI::GraphicsEllipseItem*>(graphicsItem);
    if (graphicsEllipseItem)
    {
        graphicsEllipseItem->setSize(widthSpinBox->getValue(),heightSpinBox->getValue());
        return onGeoRequested();
    }

    SUI::GraphicsLineItem *graphicsLineItem = dynamic_cast<SUI::GraphicsLineItem*>(graphicsItem);
    if (graphicsLineItem)
    {
        return onGeoRequested();
    }

    SUI::GraphicsRectItem *graphicsRectItem = dynamic_cast<SUI::GraphicsRectItem*>(graphicsItem);
    if (graphicsRectItem)
    {
        graphicsRectItem->setSize(widthSpinBox->getValue(),heightSpinBox->getValue());
        return onGeoRequested();
    }

    SUI::GraphicsTextItem *graphicsTextItem = dynamic_cast<SUI::GraphicsTextItem*>(graphicsItem);
    if (graphicsTextItem) 
    {
        graphicsTextItem->setFontSize(widthSpinBox->getValue());
        return onGeoRequested();
    }

    SUI::GraphicsSvgItem *graphicsSvgItem = dynamic_cast<SUI::GraphicsSvgItem*>(graphicsItem);
    if (graphicsSvgItem) 
    {
        graphicsSvgItem->scale(widthSpinBox->getValue(), heightSpinBox->getValue());
        return onGeoRequested();
    }
}

void GraphicsItemTest::onItemPenWidthChanged() {
    std::list<std::string> items = itemSelector->getSelectedItems();
    if(items.size() != 1)   return;        // TODO: Log some error?
    std::string currentItem = *items.begin();

    SUI::GraphicsItem  *graphicsItem = dialog->getObjectList()->getObject<SUI::GraphicsItem>(currentItem);
    if (!graphicsItem) return;

    if (dynamic_cast<SUI::GraphicsPixmapItem*>(graphicsItem)) return;

    SUI::GraphicsCrosshairItem *graphicsCrosshairItem = dynamic_cast<SUI::GraphicsCrosshairItem*>(graphicsItem);
    if (graphicsCrosshairItem) return graphicsCrosshairItem->setPenWidth(penWidthSpinBox->getValue());

    SUI::GraphicsEllipseItem *graphicsEllipseItem = dynamic_cast<SUI::GraphicsEllipseItem*>(graphicsItem);
    if (graphicsEllipseItem) return graphicsEllipseItem->setPenWidth(penWidthSpinBox->getValue());

    SUI::GraphicsLineItem *graphicsLineItem = dynamic_cast<SUI::GraphicsLineItem*>(graphicsItem);
    if (graphicsLineItem) return graphicsLineItem->setPenWidth(penWidthSpinBox->getValue());

    SUI::GraphicsRectItem *graphicsRectItem = dynamic_cast<SUI::GraphicsRectItem*>(graphicsItem);
    if (graphicsRectItem) return graphicsRectItem->setPenWidth(penWidthSpinBox->getValue());

    SUI::GraphicsTextItem *graphicsTextItem = dynamic_cast<SUI::GraphicsTextItem*>(graphicsItem);
    if (graphicsTextItem) return graphicsTextItem->setPenWidth(penWidthSpinBox->getValue());
}

void GraphicsItemTest::onSetPixmapClicked() {
    std::list<std::string> items = itemSelector->getSelectedItems();
    if(items.size() != 1)   return;        // TODO: Log some error?
    std::string currentItem = *items.begin();

    SUI::GraphicsItem  *graphicsItem = dialog->getObjectList()->getObject<SUI::GraphicsItem>(currentItem);
    if (!graphicsItem) return;

    SUI::GraphicsPixmapItem *graphicsPixmapItem = dynamic_cast<SUI::GraphicsPixmapItem*>(graphicsItem);
    if (!graphicsPixmapItem) return;

    QImage img;
    img.load(":/testimages/100x100blocked(20x20).png");

    graphicsPixmapItem->setImage(img.bits(),img.width(),img.height(),(SUI::ImageEnum::Format)img.format());
}

#include <SUIDialogImpl.h> //REMOVEME, use Dialog
#include <SUIBaseObject.h> //FIXME base should not be used

void GraphicsItemTest::onAddItemClicked() {
    //SUI::BaseObject *baseObject = NULL;
    SUI::GraphicsItem *graphicsItem = NULL;

    std::list<std::string> items = itemSelector->getSelectedItems();
    if(items.size() != 1)   return;        // TODO: Log some error?
    std::string currentItem = *items.begin();

    SUI::ObjectType::Type graphicsItemType = SUI::ObjectType::fromString(currentItem);
    assert(graphicsItemType != SUI::ObjectType::None);

    int x = xSpinBox->getValue();
    int y = ySpinBox->getValue();
    int width = widthSpinBox->getValue();
    int height = heightSpinBox->getValue();
    SUI::ColorEnum::Color color = colorSelector->getColor();
    int penwidth = penWidthSpinBox->getValue();

    switch (graphicsItemType)
    {
    case SUI::ObjectType::GraphicsLineItem:
    {
        SUI::GraphicsLineItem *graphicsLineItem = SUI::ObjectFactory::getInstance()->createGraphicsItem<SUI::GraphicsLineItem>();
        graphicsLineItem->setPenColor(color);
        graphicsLineItem->setPosition(x, y);
        graphicsLineItem->setP1(x,y);
        graphicsLineItem->setP2(width,height);
        graphicsLineItem->setPenWidth(penwidth);
        graphicsItem = graphicsLineItem;
        break;
    }
    case SUI::ObjectType::GraphicsPixmapItem:
    {
        SUI::GraphicsPixmapItem *graphicsPixmapItem = SUI::ObjectFactory::getInstance()->createGraphicsItem<SUI::GraphicsPixmapItem>();
        graphicsPixmapItem->setPosition(x, y);
        graphicsPixmapItem->setX(x);
        graphicsPixmapItem->setY(y);
        graphicsItem = graphicsPixmapItem;

        break;
    }
    case SUI::ObjectType::GraphicsTextItem:
    {
        SUI::GraphicsTextItem *graphicsTextItem = SUI::ObjectFactory::getInstance()->createGraphicsItem<SUI::GraphicsTextItem>();
        graphicsTextItem->setPenColor(color);
        graphicsTextItem->setPosition(x, y);
        graphicsTextItem->setFontSize(30);
        graphicsTextItem->setText(textLineEdit->getText());
        graphicsItem = graphicsTextItem;

        break;
    }
    case SUI::ObjectType::GraphicsRectItem:
    {
        SUI::GraphicsRectItem *graphicsRectItem = SUI::ObjectFactory::getInstance()->createGraphicsItem<SUI::GraphicsRectItem>();
        graphicsRectItem->setPenColor(color);
        graphicsRectItem->setPosition(x, y);
        graphicsRectItem->setSize(width,height);
        graphicsRectItem->setPenWidth(penwidth);

        graphicsItem = graphicsRectItem;

        break;
    }
    case SUI::ObjectType::GraphicsEllipseItem:
    {
        SUI::GraphicsEllipseItem *graphicsEllipseItem = SUI::ObjectFactory::getInstance()->createGraphicsItem<SUI::GraphicsEllipseItem>();
        graphicsEllipseItem->setPenColor(color);
        graphicsEllipseItem->setPosition(x, y);
        graphicsEllipseItem->setSize(width,height);
        graphicsEllipseItem->setPenWidth(penwidth);
        graphicsItem = graphicsEllipseItem;

        break;
    }
    case SUI::ObjectType::GraphicsCrosshairItem:
    {
        SUI::GraphicsCrosshairItem *graphicsCrosshairItem = SUI::ObjectFactory::getInstance()->createGraphicsItem<SUI::GraphicsCrosshairItem>();
        graphicsCrosshairItem->setPenColor(color);
        graphicsCrosshairItem->setPosition(x, y);
        graphicsCrosshairItem->setSize(width,height);
        graphicsItem = graphicsCrosshairItem;

        break;
    }
    case SUI::ObjectType::GraphicsSvgItem:
    {
        SUI::GraphicsSvgItem *graphicsSvgItem = SUI::ObjectFactory::getInstance()->createGraphicsItem<SUI::GraphicsSvgItem>();
        graphicsSvgItem->setPosition(x, y);
        graphicsItem = graphicsSvgItem;

        break;
    }
    default:
        return;
    }
    items = itemSelector->getSelectedItems();
    if(items.size() != 1)   return;        // TODO: Log some error?
    currentItem = *items.begin();

    graphicsItem->setId(currentItem);

    graphicsItem->setVisible(true);

    dialog->getObjectList()->addObject(graphicsItem->getId(), graphicsItem);
    graphicsView->getGraphicsScene()->addItem(graphicsItem);

    // Update GEO coordinates
    onGeoRequested();
}

void GraphicsItemTest::onRemoveItemClicked() {
    std::list<std::string> items = itemSelector->getSelectedItems();
    if(items.size() != 1)   return;        // TODO: Log some error?
    std::string currentItem = *items.begin();

    SUI::Object *graphicsItem = dialog->getObjectList()->getObject<SUI::Object>(currentItem);
    graphicsView->getGraphicsScene()->removeItem(dynamic_cast<SUI::GraphicsItem *>(graphicsItem));
}

void GraphicsItemTest::onGeoRequested() {
    std::list<std::string> items = itemSelector->getSelectedItems();
    if(items.size() != 1)   return;        // TODO: Log some error?
    std::string currentItem = *items.begin();

    SUI::GraphicsItem *graphicsItem = dialog->getObjectList()->getObject<SUI::GraphicsItem>(currentItem);
    if (!graphicsItem) return;

    SUI::ObjectType::Type graphicsItemType = SUI::ObjectType::fromString(currentItem);
    xLineEdit->setText(QString::number(graphicsItem->getX()).toStdString());
    yLineEdit->setText(QString::number(graphicsItem->getY()).toStdString());
    widthLineEdit->setText(QString::number((double)(graphicsItem->getBoundingRectWidth())).toStdString());
    heightLineEdit->setText(QString::number(graphicsItem->getBoundingRectHeight()).toStdString());

    switch(graphicsItemType) {
    case SUI::ObjectType::GraphicsLineItem:
        widthLineEdit->setText("0");
        heightLineEdit->setText("0");
        break;
    case SUI::ObjectType::GraphicsRectItem: break;
    case SUI::ObjectType::GraphicsCrosshairItem: break;
    case SUI::ObjectType::GraphicsPixmapItem: break;
    case SUI::ObjectType::GraphicsTextItem: {
        widthLineEdit->setText("0");
        heightLineEdit->setText("0");
        break;
    }
    case SUI::ObjectType::GraphicsEllipseItem: break;
    case SUI::ObjectType::GraphicsSvgItem: break;
    default: break;
    }
}
