#ifndef TESTSETPRECISION_H
#define TESTSETPRECISION_H

#include "SUIDialogImpl.h"

class testSetPrecision
{
public:
    testSetPrecision(QString aSourceWidgetID, QString aTargetWidgetID , SUI::DialogImpl *apGui);

    void    handleValueChanged();

private:
    QString mSourceWidgetid;
    QString mTargetWidgetid;
    SUI::DialogImpl  *mpGui;
};

#endif // TESTSETPRECISION_H
