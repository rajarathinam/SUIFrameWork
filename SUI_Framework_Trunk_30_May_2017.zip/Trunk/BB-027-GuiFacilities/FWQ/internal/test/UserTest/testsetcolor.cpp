#include "testsetcolor.h"

#include <FWQxCore/SUIIText.h>
#include <FWQxCore/SUIIColorable.h>
#include <FWQxWidgets/SUIDropDown.h>

void testSetColor::handleClicked()
{
    SUI::DropDown     *widgetText = mpGui->getObjectList()->getObject<SUI::DropDown>(mTargetWidgetid.toStdString());
    SUI::IColorable    *widgetColor = mpGui->getObjectList()->getObject<SUI::IColorable>(mSourceWidgetid.toStdString());
    if (widgetText && widgetColor)
    {
        std::string text = widgetText->getSelectedItems().front();
        if (text == "Blue")
        {
            widgetColor->setColor(SUI::ColorEnum::Blue);
        }
        else if (text == "Green")
        {
            widgetColor->setColor(SUI::ColorEnum::Green);
        }
        else if (text == "Red")
        {
            widgetColor->setColor(SUI::ColorEnum::Red);
        }
        else if (text == "White")
        {
            widgetColor->setColor(SUI::ColorEnum::White);
        }
        else if (text == "Gray")
        {
            widgetColor->setColor(SUI::ColorEnum::Gray);
        }
        else if (text == "Yellow")
        {
            widgetColor->setColor(SUI::ColorEnum::Yellow);
        }
        else if (text == "Standard")
        {
            widgetColor->setColor(SUI::ColorEnum::Standard);
        }
        else
        {
            widgetColor->setColor(SUI::ColorEnum::Black);
        }
    }
}

void testSetColor::handleValueChanged()
{
    SUI::IColorable    *widgetColor = mpGui->getObjectList()->getObject<SUI::IColorable>(mSourceWidgetid.toStdString());
    SUI::IText     *widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mTargetWidgetid.toStdString());
    if (widgetText && widgetColor)
    {
        std::string text = SUI::ColorEnum::toString(widgetColor->getColor());
        widgetText->setText(text);
    }
}

testSetColor::testSetColor(QString aSourceWidgetID, QString aTargetWidgetID, SUI::DialogImpl *apGui) :
    mTargetWidgetid(aTargetWidgetID),
    mSourceWidgetid(aSourceWidgetID),
    mpGui(apGui)
{
}
