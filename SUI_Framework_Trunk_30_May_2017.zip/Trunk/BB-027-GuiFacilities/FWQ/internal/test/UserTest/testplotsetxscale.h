#ifndef TESTPLOTSETXSCALE_H
#define TESTPLOTSETXSCALE_H

#include <SUIDialogImpl.h>



class testPlotSetXScale
{
public:
    testPlotSetXScale(QString pltWidgetID, QString xMinID, QString xMaxID, SUI::DialogImpl *apGui);

    void    handleClicked();

private:
    QString mPlotWidgetID;
    QString mScaleXMinID;
    QString mScaleXMaxID;

    SUI::DialogImpl  *mpGui;
};

#endif // TESTPLOTSETXSCALE_H
