#ifndef TESTBROWSERTITLE_H
#define TESTBROWSERTITLE_H

#include <QString>



namespace SUI {
class DialogImpl;
}

class testBrowserTitle
{
    QString mTargetWidgetid;
    QString mSourceWidgetid;
    SUI::DialogImpl  *mpGui;

public:
    testBrowserTitle(QString aSourceWidgetID, QString aTargetWidgetID , SUI::DialogImpl *apGui);
    void handleClicked();
};

#endif // TESTBROWSERTITLE_H
