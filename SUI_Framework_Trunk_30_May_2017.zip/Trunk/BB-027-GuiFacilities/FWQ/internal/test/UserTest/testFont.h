#ifndef TESTFONT_H
#define TESTFONT_H

#include <QString>



namespace SUI {
class DialogImpl;
}

class testFontSize
{
private:
    QString mSourceWidgetid;
    QString mTargetWidgetid;
    QString mDropDownText;
    SUI::DialogImpl  *mpGui;

public:
    testFontSize(QString aTargetWidgetID, QString aDropDownText, SUI::DialogImpl *apGui);
    void    handleClicked();
};

#endif // TESTFONT_H
