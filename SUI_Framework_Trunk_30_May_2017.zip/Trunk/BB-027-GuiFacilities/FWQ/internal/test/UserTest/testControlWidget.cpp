#include "testControlWidget.h"

#include <FWQxCore/SUIIText.h>
#include <FWQxWidgets/SUIDropDown.h>

testControlWidget::testControlWidget(QString aSourceWidgetID, QString aTargetWidgetID, SUI::DialogImpl *apGui, test aTest):
    mSourceWidgetid(aSourceWidgetID),
    mTargetWidgetid(aTargetWidgetID),
    mpGui(apGui),
    mTest(aTest)
{

}

void testControlWidget::handleClicked()
{
    SUI::ControlWidget *ctrWidget;
    SUI::IText *textWidget;
    SUI::DropDown *dropDownWidget;
    std::string text;

    switch (mTest)
    {
    case setType:
    {
        ctrWidget = mpGui->getObjectList()->getObject<SUI::ControlWidget>(mTargetWidgetid.toStdString());
        dropDownWidget = mpGui->getObjectList()->getObject<SUI::DropDown>(mSourceWidgetid.toStdString());
        std::list<std::string> selectedItems = dropDownWidget->getSelectedItems();
        ctrWidget->setType(selectedItems.front());
        break;
    }
    case getSupportedStates:
    {
        ctrWidget = mpGui->getObjectList()->getObject<SUI::ControlWidget>(mSourceWidgetid.toStdString());
        dropDownWidget= mpGui->getObjectList()->getObject<SUI::DropDown>(mTargetWidgetid.toStdString());
        std::list<std::string> states = ctrWidget->getSupportedStates();
        for(std::list<std::string>::const_iterator iterator = states.begin(); iterator != states.end(); ++iterator)
        {
            if(text.empty())
            {
                // Don't add ';' at the beginning
                text = *iterator;
            }
            else
            {
                text += ";" + *iterator;
            }

        }
        dropDownWidget->clearItems();
        dropDownWidget->addItems(states);
        break;
    }
    case getState:
    {
        ctrWidget = mpGui->getObjectList()->getObject<SUI::ControlWidget>(mSourceWidgetid.toStdString());
        textWidget= mpGui->getObjectList()->getObject<SUI::IText>(mTargetWidgetid.toStdString());
        text = ctrWidget->getState();
        textWidget->setText(text);
        break;
    }
    case setState:
    {
        ctrWidget = mpGui->getObjectList()->getObject<SUI::ControlWidget>(mTargetWidgetid.toStdString());
        dropDownWidget = mpGui->getObjectList()->getObject<SUI::DropDown>(mSourceWidgetid.toStdString());
        std::list<std::string> selectedItems = dropDownWidget->getSelectedItems();
        ctrWidget->setState(selectedItems.front());
        break;
    }
    default:
        break;
    }
}
