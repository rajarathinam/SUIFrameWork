#include "testTableWidgetItemTextCopy.h"

#include <FWQxCore/SUIIText.h>
#include <FWQxCore/SUIINumeric.h>
#include <FWQxWidgets/SUITableWidget.h>
#include <FWQxWidgets/SUITableWidgetItem.h>
#include <FWQxCore/SUIICheckable.h>
#include <SUIDialogImpl.h>

testTableWidgetItemTextCopy::testTableWidgetItemTextCopy(QString targetwidgetID, QString srcwidgetID, QString rowindwidgetID, QString colindwidgetID, SUI::DialogImpl *apGui) :
    mTargetWidgetid(targetwidgetID),
    mSourceWidgetid(srcwidgetID),
    mRowSpinBoxID(rowindwidgetID),
    mColSpinBoxID(colindwidgetID),
    mpGui(apGui)
{
}

void testTableWidgetItemTextCopy::handleClicked()
{
    SUI::INumeric<int>  *widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<int>>(mRowSpinBoxID.toStdString());
    if (widgetNum)
    {
        int         rowInd = widgetNum->getValue();
        widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<int>>(mColSpinBoxID.toStdString());
        if (widgetNum)
        {
            int         colInd = widgetNum->getValue();
            QString     itemID = QString("twi-%1:%2-%3").arg(mTargetWidgetid).arg(rowInd+1).arg(colInd+1);
            SUI::IText *widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mSourceWidgetid.toStdString());
            SUI::TableWidget *tablewidget = mpGui->getObjectList()->getObject<SUI::TableWidget>(mTargetWidgetid.toStdString());
            if (widgetText)
            {
                std::string text = widgetText->getText();
                widgetText = mpGui->getObjectList()->getObject<SUI::IText>(itemID.toStdString());
                if (widgetText)
                {
                    tablewidget->setItemText(rowInd,colInd,text);
                }
            }
        }
    }
}

void testTableWidgetItemTextCopy::handleSelectionChanged()
{
    SUI::TableWidget *table = mpGui->getObjectList()->getObject<SUI::TableWidget>(mSourceWidgetid.toStdString());
    if (!table) return;
    QStringList itemList;
    foreach(std::string item, table->getSelectedItems())
        itemList.append(QString::fromStdString(item));

    QStringList tItemText;
    foreach (QString tableItem, itemList) {
        SUI::TableWidgetItem *tItem = mpGui->getObjectList()->getObject<SUI::TableWidgetItem>(tableItem.toStdString());
        if(!tItem) return;
        tItemText.append(QString::fromStdString(tItem->getText()));
    }
    SUI::IText *textWidget = mpGui->getObjectList()->getObject<SUI::IText>(mTargetWidgetid.toStdString());
    if (textWidget)
        textWidget->setText(tItemText.join(";").toStdString());
}

void testTableWidgetItemTextCopy::setListViewMode(bool on) {
    SUI::TableWidget *widget = mpGui->getObjectList()->getObject<SUI::TableWidget>(mTargetWidgetid.toStdString());
    widget->setListViewMode(on);
}

void testTableWidgetItemTextCopy::handleCheckedChanged(bool checked) {
    SUI::TableWidget *widget = mpGui->getObjectList()->getObject<SUI::TableWidget>(mTargetWidgetid.toStdString());
    if (!widget) return;
    widget->setListViewMode(checked);
}



testTableWidgetTextFilter::testTableWidgetTextFilter(QString  targetwidgetID, QString srcwidgetID, QString caseWidgetID, QString columnNrID, SUI::DialogImpl *apGui) :
    mTargetWidgetid(targetwidgetID),
    mSourceWidgetid(srcwidgetID),
    mCaseWidgetID(caseWidgetID),
    mColumnNrWidgetid(columnNrID),
    mpGui(apGui)
{
}

void testTableWidgetTextFilter::handleCheckedChanged(bool checked)
{
    SUI::INumeric<int>  *widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<int>>(mColumnNrWidgetid.toStdString());
    if (widgetNum)
    {
        int     colNr = widgetNum->getValue();
        SUI::IText *widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mSourceWidgetid.toStdString());
        if (widgetText)
        {
            std::string filterText = widgetText->getText();
            SUI::ICheckable  *widget = mpGui->getObjectList()->getObject<SUI::ICheckable>(mCaseWidgetID.toStdString());
            if (widget)
            {
                bool    caseSens = widget->isChecked();
                SUI::IFilterable   *tableWidget = mpGui->getObjectList()->getObject<SUI::IFilterable>(mTargetWidgetid.toStdString());
                if (tableWidget)
                {
                    tableWidget->setFilter(filterText, checked, colNr, caseSens);
                }
            }
        }
    }
}



testTableWidgetAddRowData::testTableWidgetAddRowData(QString tawID, QString lneID, QString isbID, SUI::DialogImpl *apGui) :
    mTawID(tawID),
    mLneID(lneID),
    mIsbID(isbID),
    mpGui(apGui)
{
}

void testTableWidgetAddRowData::handleClicked() {
    SUI::TableWidget *tableWidget = mpGui->getObjectList()->getObject<SUI::TableWidget>(mTawID.toStdString());
    SUI::INumeric<int> *numWidget = mpGui->getObjectList()->getObject<SUI::INumeric<int>>(mIsbID.toStdString());
    SUI::IText *textWidget = mpGui->getObjectList()->getObject<SUI::IText>(mLneID.toStdString());
    if (tableWidget && numWidget && textWidget) {
        QStringList textList = QString::fromStdString(textWidget->getText()).split(";");
        std::list<std::string> stdTextList;
        foreach(const QString &s , textList) {
            stdTextList.push_back(s.toStdString());
        }

        tableWidget->addData(numWidget->getValue(), stdTextList);
    }
}


testTableWidgetSetWidgetItemName::testTableWidgetSetWidgetItemName(QString tableID, QString rowID, QString colID, QString cellName, SUI::DialogImpl *apGui) :
    mTableID(tableID),
    mIsbRow(rowID),
    mIsbCol(colID),
    mLneCellname(cellName),
    mpGui(apGui)
{
}

void testTableWidgetSetWidgetItemName::handleClicked()
{
    SUI::TableWidget *table = mpGui->getObjectList()->getObject<SUI::TableWidget>(mTableID.toStdString());
    SUI::INumeric<int> *row = mpGui->getObjectList()->getObject<SUI::INumeric<int>>(mIsbRow.toStdString());
    SUI::INumeric<int> *col = mpGui->getObjectList()->getObject<SUI::INumeric<int>>(mIsbCol.toStdString());
    SUI::IText *cellname = mpGui->getObjectList()->getObject<SUI::IText>(mLneCellname.toStdString());
   if(table && row && col && cellname){
       table->setWidgetItemName(row->getValue(), col->getValue(), cellname->getText());
   }

}


testTableWidgetGetWidgetItemByName::testTableWidgetGetWidgetItemByName(QString tableID, QString cellName,QString widget ,SUI::DialogImpl *apGui) :
    mTableID(tableID),
    mCellname(cellName),
    mWidgetID(widget),
    mpGui(apGui)
{

}

void testTableWidgetGetWidgetItemByName::handleClicked()
{
    SUI::TableWidget *table = mpGui->getObjectList()->getObject<SUI::TableWidget>(mTableID.toStdString());
    SUI::IText *cellname = mpGui->getObjectList()->getObject<SUI::IText>(mCellname.toStdString());
    SUI::IText *widget = mpGui->getObjectList()->getObject<SUI::IText>(mWidgetID.toStdString());
    if(table && cellname && widget) {
       widget->clearText();
       SUI::Widget *widgetRet = table->getWidgetItemByName(cellname->getText());
       if(widgetRet)widget->setText(widgetRet->getId());
       else widget->setText("Invalid CellName");
    }
}
