//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class WidgetControllerInfo.
// !\description Header file for class WidgetControllerInfo.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef WIDGETCONTROLLERINFO_H
#define WIDGETCONTROLLERINFO_H

#include "rticWidgetDefinition.h"

class WidgetControllerInfo
{
public:
    WidgetControllerInfo(WidgetController *parent, WidgetController *dragged);
    WidgetController *getParentWidget() const;
    WidgetController *getDraggedWidget() const;
    WidgetController *getTabPageWidget() const;
    void setTabPageWidget(const WidgetController *tpw);
    void setDraggedWidget(WidgetController *wcDragged);

private:
    WidgetController *mParent;
    WidgetController *mDragged;
    WidgetController *mTabPage;
};

#endif // DRAGANDDROPINFO_H
