//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class WidgetController.
// !\description Header file for class WidgetController.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef WIDGETCONTROLLER_H
#define WIDGETCONTROLLER_H

#include <QTreeWidgetItem>
#include <QLabel>
#include <QUuid>
#include <SUIGUIDefinitionVisitor.h>

#include <SUIBaseWidget.h>

#include "CircularList.h"

#define STATECOLUMN 0
#define STATEIMAGECOLUMN 1

class WidgetController: public QLabel
{
    Q_OBJECT
public:
    typedef enum
    {
        WidgetSelectorMode, // This is the widget selector in the editor
        RootWidgetMode, // This is the root widget i.e. the main form that is edited
        ParentWidgetMode, // This Widget can embed child widgets
        SingleWidgetMode // This Widget is stand alone. It cannot embed children and cannot provide new Widgets
    } WidgetControllerModeEnum;

    typedef QList<WidgetController *> WidgetControllerList;

    typedef struct ITEMCHANGEDSTRUCT
    {
        bool bTypeChanged;
        bool bBorderOnChanged;
        int chcdef;
        int dStart;
        int dEnd;
        QString sWidgetType;
        QString sFileName;
    } ChangedItemProperties;

    enum startPositions {topleft, left, bottomleft, bottom, bottomright, right, topright, top, smove} startPositions;

    WidgetController(QWidget *parent, WidgetControllerModeEnum mode);
    WidgetController(QWidget *parent, WidgetControllerModeEnum mode, SUI::BaseWidget *baseWidget);
    virtual ~WidgetController();

    virtual void acceptVisitor(GUIDefinitionVisitor &visitor, bool bSkipUCtrl = false) const;
    void updatePixmap();
    WidgetController *addTabPage(const QString tabname);
    void tabWidgetResized() const;
    void addSplitterWidget(const WidgetController *widgcontr);
    void setSelected(bool selected);
    QString getId() const;
    void handlePasteAction();
    void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);
    WidgetController *getCurrentDaDTabpage() const;
    void insertRows(int position, int count);
    void insertColumns(int position, int count);
    void removeRows(int position, int count);
    void removeColumns(int position, int count);
    SUI::ObjectType::Type getObjectType() const;
    QString getIndexedValue(QString key, QString val) const;
    void removeChild(WidgetController *childWidget);
    void renameChildren(const QString &topid);
    void removeFromModel();
    void setChildrenPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);
    void setChildrenWidgetMode(const WidgetControllerModeEnum mode);
    void setChildrenPropertyReadOnly() const;
    bool splitUserControl();
    WidgetController *searchForUserControl();
    int getTableWidgetItemRowNr() const;
    int getTableWidgetItemColumnNr() const;
    void toForground(const WidgetController *wcChild);
    void toBackground(const WidgetController *wcChild);
    void forward(const WidgetController *wcChild);
    void backward(const WidgetController *wcChild);
    void redraw();
    void showProperTabPages() const;
    QSet<SUI::ObjectPropertyTypeEnum::Type> getPropertyList() const;
    QString getPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID) const;
    bool isChildOfThis(const WidgetController *wcCtrl) const;
    WidgetControllerList getParentList() const;
    void setPixmapSize();
    QStringList &getIDList(QStringList &idList) const;

    void setChangedItem(ChangedItemProperties &cp) { mChangedProperties = cp; }
    SUI::BaseWidget *getBaseWidget() const { return mSUIBaseWidget; }
    void setBaseWidget(SUI::BaseWidget *b) { mSUIBaseWidget = b; }
    bool isSelected() const { return mIsSelected; }
    QUuid widgetGUID() const { return mGUID; }
    bool isWidgetSelector() const { return (mMode == WidgetSelectorMode); }
    void setWidgetMode(const WidgetControllerModeEnum mode) { mMode = mode; }
    const WidgetControllerList *getChildren() const { return &mChildren; }
    void setId(QString id) { getBaseWidget()->setId(id.toStdString()); }
    WidgetController *getParent() const { return mParent; }
    void setParent(WidgetController *parent) { mParent = parent; }
    bool supportsChildren() const { return getBaseWidget()->childrenSupported(); }

    void addChild(WidgetController *childWidget) { mChildren.append(childWidget); }
    void insertChild(int pos, WidgetController *childWidget) { mChildren.insert(pos, childWidget); }
    void removeChildat(int pos) { mChildren.removeAt(pos); }
    const QList<WidgetController *> &childList() const { return mChildren; }
    void clearChildList() { mChildren.clear(); }
    QPoint &getStartPoint() { return mStartPoint; }
    void tabReorder();
    void addToTaborder();
    void onCustomContextItemMenu(QString selectedAct);

    void updateTableCell(int row, int col, SUI::ObjectType::Type WidgetType, SUI::AlignmentEnum::Alignment alignment);

    void insertTreeItem(QTreeWidgetItem *Item);

    QPoint snapToGrid(QPoint &point);
    void removeWidgetFromTable(int row, int column);

    bool isInitializedInEditor() const;
    void setInitializedInEditor(bool value);

public slots:
    void renameTableWidgetItems();

protected:
    WidgetControllerList mChildren;

    virtual void dragEnterEvent(QDragEnterEvent *event);
    virtual void dropEvent(QDropEvent *event);
    virtual void mousePressEvent(QMouseEvent *event);
    virtual void mouseMoveEvent(QMouseEvent *event);
    virtual void mouseReleaseEvent(QMouseEvent *event);
    virtual void paintEvent(QPaintEvent *paintEvent);
    virtual void keyPressEvent(QKeyEvent *ke);
    virtual void keyReleaseEvent(QKeyEvent *ke);

    void addProperty(SUI::ObjectProperty *property);

private:
    bool mIsSelected;
    WidgetControllerModeEnum mMode;
    Qt::DropAction mDropAction;
    SUI::BaseWidget *mSUIBaseWidget;
    QUuid mGUID;
    WidgetController *mParent;
    ChangedItemProperties mChangedProperties;
    int							mButtomResizeBound;
    enum startPositions			mStartPos;
    QRect mRubberBandrect;
    bool mRubberBandShown;
    WidgetState *mUndoState;
    QPoint mStartPoint;
    bool initializedInEditor;

    void init(WidgetControllerModeEnum mode);
    void drawSelected();
    void fillTableWidget();
    void clearTableWidget();
    void sortTableWidgetChildren();

    WidgetController();
    WidgetController(const WidgetController &rhs);
    WidgetController &operator=(const WidgetController &rhs);

    bool isChildOfDDWidget(const WidgetController *ddw, QPoint &dropPoint) const;
    void addToTaborder2(WidgetController *ctrl);
    QRect updateRubberBandRegion();
    void removeChildren(QStringList idList);
    bool hasUCtrlParent();
    void performDrag(QPoint point, WidgetController *curWidg = NULL);
    QPixmap makeFramePixmap(QPoint point, WidgetController *curWidg);
    void setCellWidget(int row, int column, WidgetDefinition *widgetDefinition);
    void setCellUserControlWidget(int row, int column, WidgetDefinition *widgetDefinition);
};

bool tableWidgetItemLessThan(const WidgetController *wc1, const WidgetController *wc2);


#endif // WIDGETCONTROLLER_H
