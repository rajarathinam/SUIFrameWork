//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class headerTreeWidgetDialog.
// !\description Header file for class headerTreeWidgetDialog.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|



#ifndef HEADERTREEWIDGETDIALOG_H
#define HEADERTREEWIDGETDIALOG_H

#include <QDialog>
#include <QTreeWidgetItem>

#include <SUITableWidgetImpl.h>

#include "Model.h"
#include "WidgetController.h"
#include "UndoHandler.h"


#include "ui_headertreewidgetdialog.h"

class HeaderTags;

namespace Ui
{
class headerTreeWidgetDialog;
}

class headerTreeWidgetDialog  : public QDialog
{
    Q_OBJECT

public:
    explicit headerTreeWidgetDialog(WidgetController *tableWidget, QWidget *parent = 0, QString headertags=0);
    virtual ~headerTreeWidgetDialog();


private slots:
    void    on_pushButton_clicked();
    void    on_pushButton_2_clicked();
    void    on_pushButton_3_clicked();
    void    on_pushButton_4_clicked();
    void    onSelectionChanged();

private:
    Ui::headerTreeWidgetDialog    *ui;
    WidgetController        *mTableWidgetContr;
    WidgetState             *mWidgetState;
    QString					 mHeaderTags;
    QStringList			     mHeaderTagValue;

    void                    addrow(QTreeWidgetItem *parent);
    void                    getItems(QTreeWidgetItem *item);

    void    addWidgets();
    void    addWidgets(HeaderTags *child, QTreeWidgetItem *item);

};

#endif // HEADERTREEWIDGETDIALOG_H
