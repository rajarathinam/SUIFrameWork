//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::LoggerSignalHandler.
// !\description Header file for class SUI::LoggerSignalHandler.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUILOGGERSIGNALHANDLER_H
#define SUILOGGERSIGNALHANDLER_H

#include "SUISharedExport.h"

#include <QObject>

namespace SUI {
/*!
 *  CLASS   :   RticLoggerSignalHandler
 *
 *  The Logger class needs to send logevent signals. But since that class is not a QObject subclass,
 *  it doesn't understand SIGNALS. Therefore this signalhandler class is used, which is a QObject
 *  subclass and therefore does understand SIGNALS.
 */
class LoggerSignalHandler : public QObject
{
    Q_OBJECT

public:
    explicit LoggerSignalHandler(QObject *parent = NULL);

    void sendLogEvent(QString logmsg, int level);

signals:
    void newLogEvent(QString, int);
};
}

#endif // SUILOGGERSIGNALHANDLER_H
