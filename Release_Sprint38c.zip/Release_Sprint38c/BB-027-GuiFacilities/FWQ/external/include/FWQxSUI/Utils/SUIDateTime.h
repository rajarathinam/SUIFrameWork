//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::DateTime.
// !\description Header file for class SUI::DateTime.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIDATETIME_H
#define SUIDATETIME_H

#include "SUISharedExport.h"
#include "SUIDateTimeEnum.h"

#include <string>

#include <boost/shared_ptr.hpp>

namespace SUI {
class Time;
class Date;

/*!
 * \ingroup FWQxUtils
 *
 * \brief The DateTime class
 */
class SUI_SHARED_EXPORT DateTime
{
public:
    virtual ~DateTime();

    /*!
     * \brief addDays
     * Adds ndays days to the datetime of this object
     * ndays can be positive or negative
     * \param ndays
     */
    virtual void addDays(int ndays) = 0;

    /*!
     * \brief addMSecs
     * Adds msecs milliseconds to the datetime of this object
     * msecs can be positive or negative
     * \param msecs
     */
    virtual void addMSecs(int64_t msecs) = 0;

    /*!
     * \brief addMonths
     * Adds nmonths months to the datetime of this object
     * nmonths can be positive or negative
     * \param nmonths
     */
    virtual void addMonths(int nmonths) = 0;

    /*!
     * \brief addSecs
     * Adds s seconds to the datetime of this object
     * s can be positive or negative
     * \param s
     */
    virtual void addSecs(int s) = 0;

    /*!
     * \brief addYears
     * Adds nyears years to the datetime of this object
     * nyears can be positive or negative
     * \param nyears
     */
    virtual void addYears(int nyears) = 0;

    /*!
     * \brief daysTo
     * Returns the number of days from this datetime to the other datetime.
     * If the other datetime is earlier than this datetime, the value returned
     * is negative.
     * \param other
     * \return
     */
    virtual int daysTo(const boost::shared_ptr<SUI::DateTime> &other) const = 0;

    /*!
     * \brief isNull
     * Returns true if both the date and the time are null; otherwise returns false.
     * A null datetime is invalid.
     * \return
     */
    virtual bool isNull() const = 0;

    /*!
     * \brief isValid
     * Returns true if both the date and the time are valid; otherwise returns false.
     * \return
     */
    virtual bool isValid() const = 0;

    /*!
     * \brief getMsecsTo
     * Returns the number of milliseconds from this datetime to the other datetime.
     * If the other datetime is earlier than this datetime, the value returned is negative.
     * \param other
     * \return
     */
    virtual int64_t getMsecsTo(const boost::shared_ptr<SUI::DateTime> &other) const = 0;

    /*!
     * \brief getSecsTo
     * Returns the number of seconds from this datetime to the other datetime.
     * If the other datetime is earlier than this datetime, the value returned is negative.
     * \param other
     * \return
     */
    virtual int getSecsTo(const boost::shared_ptr<SUI::DateTime> &other) const = 0;

    /*!
     * \brief setDate
     * Sets the date part of this datetime to date. If no time is set, it is set to midnight.
     * \param date
     */
    virtual void setDate(const boost::shared_ptr<SUI::Date> &date) = 0;

    /*!
     * \brief setMSecsSinceEpoch
     * Sets the date and time given the number of milliseconds,msecs,
     * that have passed since 1970-01-01T00:00:00.000, Coordinated Universal Time
     * \param msecs
     */
    virtual void setMSecsSinceEpoch(int64_t msecs) = 0;

    /*!
     * \brief setTime
     * Sets the time part of this datetime to time.
     * \param time
     */
    virtual void setTime(const boost::shared_ptr<SUI::Time> &time) = 0;

    /*!
     * \brief setTimeSpec
     * Sets the time specification used in this datetime to spec.
     * See DateTimeEnum::TimeSpec
     * \param spec
     */
    virtual void setTimeSpec(DateTimeEnum::TimeSpec spec) = 0;

    /*!
     * \brief setTime_t
     * Sets the date and time given the number of seconds that have
     * passed since 1970-01-01T00:00:00, Coordinated Universal Time
     * \param seconds
     */
    virtual void setTime_t(uint seconds) = 0;

    /*!
     * \brief getTime
     * Returns the time part of the datetime.
     * \return
     */
    virtual boost::shared_ptr<Time> getTime() const = 0;

    /*!
     * \brief getTimeSpec
     * Returns the time specification of the datetime.
     * \return
     */
    virtual DateTimeEnum::TimeSpec getTimeSpec() const = 0;

    /*!
     * \brief toMSecsSinceEpoch
     * Returns the datetime as the number of milliseconds that
     * have passed since 1970-01-01T00:00:00.000, Coordinated Universal Time
     * \return
     */
    virtual int64_t toMSecsSinceEpoch() const = 0;

    /*!
     * \brief toString
     * Returns the datetime as a string. The format parameter determines the format of the result string.
     * Examples of format are 'dd.MM.yyyy', 'ddd MMMM d yy', 'h:m:s ap', 'hh:mm:ss:zzz'
     * \param format
     * \return
     */
    virtual std::string toString(const std::string &format) const = 0;

    /*!
     * \brief toString
     * Returns the datetime as a string in the format given. See DateTimeEnum::DateFormat.
     * Default is DateTimeEnum::TextDate
     * \param format
     * \return
     */
    virtual std::string toString(DateTimeEnum::DateFormat format = DateTimeEnum::TextDate) const = 0;

    /*!
     * \brief toTime_t
     * Returns the datetime as the number of seconds that have passed since 1970-01-01T00:00:00,
     * Coordinated Universal Time
     * \return
     */
    virtual uint toTime_t() const = 0;

    /*!
     * \brief operator !=
     * Returns true if this datetime is different from the other datetime; otherwise returns false.
     * Two datetimes are different if either the date, the time, or the time zone components are different.
     * \param other
     * \return
     */
    virtual bool operator!=(const boost::shared_ptr<DateTime> &other) const = 0;

    /*!
     * \brief operator <
     * Returns true if this datetime is earlier than the other datetime; otherwise returns false.
     * \param other
     * \return
     */
    virtual bool operator<(const boost::shared_ptr<DateTime> &other) const = 0;

    /*!
     * \brief operator <=
     * Returns true if this datetime is earlier than or equal to the other datetime; otherwise returns false.
     * \param other
     * \return
     */
    virtual bool operator<=(const boost::shared_ptr<DateTime> &other) const = 0;

    /*!
     * \brief operator ==
     * Returns true if this datetime is equal to the other datetime; otherwise returns false.
     * \param other
     * \return
     */
    virtual bool operator==(const boost::shared_ptr<DateTime> &other) const = 0;

    /*!
     * \brief operator >
     * Returns true if this datetime is later than the other datetime; otherwise returns false.
     * \param other
     * \return
     */
    virtual bool operator>(const boost::shared_ptr<DateTime> &other) const = 0;

    /*!
     * \brief operator >=
     * Returns true if this datetime is later than or equal to the other datetime; otherwise returns false.
     * \param other
     * \return
     */
    virtual bool operator>=(const boost::shared_ptr<DateTime> &other) const = 0;

    /*!
     * \brief createDateTime
     * Creates the date time object
     * \return
     */
    static boost::shared_ptr<DateTime> createDateTime();
};

} // namespace SUI

#endif // SUI_SUIDATETIME_H
