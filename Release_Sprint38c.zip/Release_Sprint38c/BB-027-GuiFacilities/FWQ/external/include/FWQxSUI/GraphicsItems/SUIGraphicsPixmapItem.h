//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::GraphicsPixmapItem.
// !\description Header file for class SUI::GraphicsPixmapItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIGRAPHICSPIXMAPITEM_H
#define SUIGRAPHICSPIXMAPITEM_H

#include "SUIGraphicsItem.h"
#include "SUIIImage.h"

namespace SUI {
/*!
 * \ingroup FWQxGraphicsItems
 *
 * \brief The GraphicsPixmap class
 */
class SUI_SHARED_EXPORT GraphicsPixmapItem : public GraphicsItem, public IImage
{
public:
    virtual ~GraphicsPixmapItem();

    /*!
     * \brief scale
     * Scales the pixmap item to a rectangle with the given width and
     * height according to the given aspect Ratio mode and transformation mode.
     * \param width
     * \param height
     * \param aspectRatioMode
     * \param transformationMode
     */
    void scale(int width, int height, const ImageEnum::AspectRatioMode &aspectRatioMode = ImageEnum::IgnoreAspectRatio, const ImageEnum::TransformationMode &transformationMode = ImageEnum::SmoothTransformation);

    /*!
     * \brief setImage
     * Constructs a pixmap from the file with the given fileName. If the file
     * does not exist or is of an unknown format, the pixmap becomes a null pixmap
     * \param fileName
     */
    virtual void setImage(const std::string &fileName);

    /*!
     * \brief setImage
     * Constructs an image with the given width, height and format, that uses an existing
     * memory buffer, data. The width and height must be specified in pixels, data must be
     * 32-bit aligned, and each scanline of data in the image must also be 32-bit aligned.
     * The buffer must remain valid throughout the life of the QImage. The image does not
     * delete the buffer at destruction
     * \param data
     * \param width
     * \param height
     * \param format
     */
    virtual void setImage(unsigned char *data , int width, int height, SUI::ImageEnum::Format format);

private:
    void *image;
    void *scaledImage;

    friend class ObjectFactory;
    explicit GraphicsPixmapItem(SUI::GraphicsItem *parent = NULL);
    GraphicsPixmapItem(const GraphicsPixmapItem &copy);
    GraphicsPixmapItem &operator=(const GraphicsPixmapItem &copy);
};
}

#endif // SUIGRAPHICSPIXMAPITEM_H
