//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ICheckable.
// !\description Header file for class SUI::ICheckable.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIICHECKABLE_H
#define SUIICHECKABLE_H

#include <boost/function.hpp>

namespace SUI {

/*!
 * \ingroup FWQxCore
 *
 * \brief Generic Interface class for the purpose of the checkable widgets
 */
class ICheckable
{
public:
    virtual ~ICheckable() {}

    /*!
     * \brief setChecked
     * Sets the "checked" value of a checkable widget like a checkbox or radio button.
     * \param checked The checked state.
     */
    virtual void setChecked(bool checked) = 0;

    /*!
     * \brief checkStateChanged
     * Callback function that is called when the checked state changed.
     */
    boost::function<void(bool)> checkStateChanged;

    /*!
     * \brief isChecked
     * Gets the "checked" value of a checkable widget like a checkbox or radio button.
     * \return The checked state
     */
    virtual bool isChecked() const = 0;
};
}

#endif // SUIICHECKED_H
