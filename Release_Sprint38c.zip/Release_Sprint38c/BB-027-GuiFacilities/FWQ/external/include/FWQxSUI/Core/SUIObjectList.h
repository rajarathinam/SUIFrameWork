//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ObjectList.
// !\description Header file for class SUI::ObjectList.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIOBJECTLIST_H
#define SUIOBJECTLIST_H

#include "SUISharedExport.h"
#include "SUIDeprecated.h"

#include <SUIErrorModeEnum.h>

#include <map>
#include <vector>

#include <SUIObject.h>

namespace SUI {

/*!
 * \ingroup FWQxCore
 *
 * \brief The ObjectList class
 */
class SUI_SHARED_EXPORT ObjectList
{
public:
    virtual ~ObjectList() {}

    /*!
     * \brief getObject
     * Returns the object, associated with the give ID
     * \param id - The id of the Object to be retrieved
     * \remarks This method returns NULL if no object exist with the given ID
     * \return
     */
    template<class T>
    T *getObject(const std::string &id)
    { T *t = dynamic_cast<T *>(getObjectPrivate(id)); /*assert(t);*/ return t; }

    /*!
     * \brief addObject
     * Add an Object to the widgetlist.
     * \param id
     * \param object
     * \exception ArgumentException
     * \remarks This function throws an ArgumentException exception when the Object id has already been loaded.
     */
    void addObject(const std::string &id, Object *object);

    /*!
     * \brief removeObject
     * Removes a Object from the list
     * \param std::string id - The id of the Object to be removed.
     */
    void removeObject(std::string id);

    /*!
     * \brief clear
     * clears the list of objects
     */
    void clear();

    /*!
     * \brief (Deprecated) doesMessageBoxExist
     * \return bool
     */
    SUI_DEPRECATED bool doesMessageBoxExist();

    /*!
     * \brief (Deprecated) doesFileBrowserExist
     * \return bool
     */
    SUI_DEPRECATED bool doesFileBrowserExist();

    /*!
     * \brief idExists
     * Checks whether the supplied id exists in the object list
     * \param id
     * \return
     */
    bool idExists(const std::string &id) const;


    /*!
     * \brief getObjectList
     * Retrieves a vector list of current objects
     * \return
     */
    std::vector<Object *> getObjectList() const;

private:
    Object *getObjectPrivate(std::string id);

    std::map<std::string, Object *> objects;

};
}

#endif // SUIWIDGETLIST_H
