//-----------------------------------------------------------------------------|
//                                                                             |
//                            C++ Header File                                  |
//                                                                             |
//-----------------------------------------------------------------------------|
//
// !\author      Jonathan Cruz
// !\brief       External event generic class.
//
//-----------------------------------------------------------------------------|
//                                                                             |
//                Copyright (c) 2016, ASML Netherlands B.V.                    |
//                           All rights reserved                               |
//                                                                             |
//-----------------------------------------------------------------------------|
#ifndef SUIEXTERNALEVENT_H
#define SUIEXTERNALEVENT_H
//-----------------------------------------------------------------------------|
//                             Includes                                        |
//-----------------------------------------------------------------------------|
#include <boost/function.hpp>

#include <SUIAbstractExternalEvent.h>

namespace SUI {
//-----------------------------------------------------------------------------|
//                             Class declaration                               |
//-----------------------------------------------------------------------------|

//#ifdef CXX11
//template<typename ...Args>
//class ExternalEvent : public SUI::ExternalEvent
//{
//public:
//    explicit ExternalEvent(const boost::function<void(Args...)> &cb, Args... args) : func(cb), args(args) {}
//    virtual ~ExternalEvent() {}
//
//    virtual void emitEvent() { func(args...); }
//private:
//    boost::function<void(Args...)> func;
//    Args args;
//};
//#else

template<
typename T1 = void, typename T2 = void, typename T3 = void, typename T4 = void, typename T5 = void,
typename T6 = void, typename T7 = void, typename TN = void> class ExternalEvent;

template<>
class ExternalEvent<void, void, void, void, void, void, void, void> : public SUI::AbstractExternalEvent
{
public:
    explicit ExternalEvent(const boost::function<void()> &cb) :
        func(cb) {}
    virtual ~ExternalEvent() {}

    virtual void emitEvent()
    { func(); }
private:
    boost::function<void()> func;
};

template<typename A>
class ExternalEvent<A, void, void, void, void, void, void, void> : public SUI::AbstractExternalEvent
{
public:
    explicit ExternalEvent(const boost::function<void(A)> &cb, const A &pa) :
        func(cb), a(pa) {}
    virtual ~ExternalEvent() {}

    virtual void emitEvent()
    { func(a); }
private:
    boost::function<void(A)> func;
    A a;
};

template<typename A,typename B>
class ExternalEvent<A, B, void, void, void, void, void, void> : public SUI::AbstractExternalEvent
{
public:
    explicit ExternalEvent(const boost::function<void(A,B)> &cb, const A &pa, const B &pb) :
        func(cb), a(pa), b(pb) {}
    virtual ~ExternalEvent() {}

    virtual void emitEvent()
    { func(a,b); }
private:
    boost::function<void(A,B)> func;
    A a; B b;
};

template<typename A,typename B,typename C>
class ExternalEvent<A, B, C, void, void, void, void, void> : public SUI::AbstractExternalEvent
{
public:
    explicit ExternalEvent(const boost::function<void(A,B,C)> &cb, const A &pa, const B &pb, const C &pc) :
        func(cb), a(pa), b(pb), c(pc) {}
    virtual ~ExternalEvent() {}

    virtual void emitEvent()
    { func(a,b,c); }
private:
    boost::function<void(A,B,C)> func;
    A a; B b; C c;
};

template<typename A,typename B,typename C,typename D>
class ExternalEvent<A, B, C, D, void, void, void, void> : public SUI::AbstractExternalEvent
{
public:
    explicit ExternalEvent(const boost::function<void(A,B,C,D)> &cb, const A &pa, const B &pb, const C &pc, const D &pd) :
        func(cb), a(pa), b(pb), c(pc), d(pd) {}
    virtual ~ExternalEvent() {}

    virtual void emitEvent()
    { func(a,b,c,d); }
private:
    boost::function<void(A,B,C,D)> func;
    A a; B b; C c; D d;
};

template<typename A,typename B,typename C,typename D,typename E>
class ExternalEvent<A, B, C, D, E, void, void, void> : public SUI::AbstractExternalEvent
{
public:
    explicit ExternalEvent(const boost::function<void(A,B,C,D,E)> &cb, const A &pa, const B &pb, const C &pc, const D &pd, const E &pe) :
        func(cb), a(pa), b(pb), c(pc), d(pd), e(pe) {}
    virtual ~ExternalEvent() {}

    virtual void emitEvent()
    { func(a,b,c,d,e); }
private:
    boost::function<void(A,B,C,D,E)> func;
    A a; B b; C c; D d; E e;
};

template<typename A,typename B,typename C,typename D,typename E,typename F>
class ExternalEvent<A, B, C, D, E, F, void, void> : public SUI::AbstractExternalEvent
{
public:
    explicit ExternalEvent(const boost::function<void(A,B,C,D,E,F)> &cb, const A &pa, const B &pb, const C &pc, const D &pd, const E &pe, const F &pf) :
        func(cb), a(pa), b(pb), c(pc), d(pd), e(pe), f(pf) {}
    virtual ~ExternalEvent() {}

    virtual void emitEvent()
    { func(a,b,c,d,e,f); }
private:
    boost::function<void(A,B,C,D,E,F)> func;
    A a; B b; C c; D d; E e; F f;
};

template<typename A,typename B,typename C,typename D,typename E,typename F,typename G>
class ExternalEvent<A, B, C, D, E, F, G, void> : public SUI::AbstractExternalEvent
{
public:
    explicit ExternalEvent(const boost::function<void(A,B,C,D,E,F,G)> &cb, const A &pa, const B &pb, const C &pc, const D &pd, const E &pe, const F &pf, const G &pg) :
        func(cb), a(pa), b(pb), c(pc), d(pd), e(pe), f(pf), g(pg) {}
    virtual ~ExternalEvent() {}

    virtual void emitEvent()
    { func(a,b,c,d,e,f,g); }
private:
    boost::function<void(A,B,C,D,E,F,G)> func;
    A a; B b; C c; D d; E e; F f; G g;
};

//#endif

}
#endif // SUIEXTERNALEVENT_H
