//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for ExternalEventHandler.
// !\description Class implementation file for ExternalEventHandler.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUIAbstractExternalEvent.h"
#include "SUIExternalEventHandler.h"
#include "SUIExternalEventHandlerImpl.h"

#include <qobjectdefs.h>
#include <QApplication>

SUI::ExternalEventHandler::ExternalEventHandler()
{
}

bool SUI::ExternalEventHandler::raiseEvent(SUI::AbstractExternalEvent *event) {
    static SUI::ExternalEventHandlerImpl impl;
    impl.moveToThread(QApplication::instance()->thread());
    return QMetaObject::invokeMethod(&impl, "emitEvent", Qt::QueuedConnection, Q_ARG(SUI::AbstractExternalEvent*,event));
}
