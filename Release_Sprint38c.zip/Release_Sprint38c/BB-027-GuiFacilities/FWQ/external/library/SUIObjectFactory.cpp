//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for ObjectFactory.
// !\description Class implementation file for ObjectFactory.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIObjectFactory.h"

#include <cstdlib>
#include <memory>
#include <cxxabi.h>

#include "SUIObjectFactoryImpl.h"

#include "SUIButton.h"
#include "SUILabel.h"
#include "SUILineEdit.h"
#include "SUIRadioButton.h"
#include "SUITabWidget.h"
#include "SUITabPage.h"
#include "SUICheckBox.h"
#include "SUIGroupBox.h"
#include "SUICheckGroupBox.h"
#include "SUIButtonBar.h"
#include "SUITableWidget.h"
#include "SUITableWidgetItem.h"
#include "SUISpinBox.h"
#include "SUIDoubleSpinBox.h"
#include "SUIDropDown.h"
#include "SUICheckMark.h"
#include "SUILEDWidget.h"
#include "SUIColorDrop.h"
#include "SUIColorCrossDrop.h"
#include "SUITextArea.h"
#include "SUIProgressBar.h"
#include "SUIGraphicsView.h"
#include "SUIMessageBox.h"
#include "SUISplitter.h"
#include "SUIFileDialog.h"
#include "SUIUserControl.h"
#include "SUIPlotWidget.h"
#include "SUIListView.h"
#include "SUIControlWidget.h"
#include "SUIStateWidget.h"
#include "SUIScienceSpinBox.h"
#include "SUIQuestionMark.h"
#include "SUIBusyIndicator.h"
#include "SUIImageWidget.h"
#include "SUITreeView.h"
#include "SUITreeViewItem.h"
#include "SUILineWidget.h"
#include "SUISvgWidget.h"
#include "SUIScrollBar.h"
#include "SUIDateTimeEdit.h"
#include "SUIWebView.h"

#include "SUIGraphicsPixmapItem.h"
#include "SUIGraphicsTextItem.h"
#include "SUIGraphicsRectItem.h"
#include "SUIGraphicsLineItem.h"
#include "SUIGraphicsEllipseItem.h"
#include "SUIGraphicsCrosshairItem.h"
#include "SUIGraphicsSvgItem.h"

#include "SUIPlotCurveItem.h"

const SUI::VersionInfo SUI::ObjectFactory::version = SUI::VersionInfo(0,0,0);
const std::string SUI::ObjectFactory::name = "SUI Object factory";
const std::string SUI::ObjectFactory::description = "Constructs Object derived classes.";

const std::map<const std::type_info*,SUI::ObjectFactory::createWidgetFunction> SUI::ObjectFactory::widgetTypeMap = {
    {&typeid(SUI::Button), &SUI::ObjectFactory::createButton},
    {&typeid(SUI::Label), &SUI::ObjectFactory::createLabel},
    {&typeid(SUI::LineEdit), &SUI::ObjectFactory::createLineEdit},
    {&typeid(SUI::RadioButton), &SUI::ObjectFactory::createRadioButton},
    {&typeid(SUI::TabWidget), &SUI::ObjectFactory::createTabWidget},
    {&typeid(SUI::TabPage), &SUI::ObjectFactory::createTabPage},
    {&typeid(SUI::CheckBox), &SUI::ObjectFactory::createCheckBox},
    {&typeid(SUI::GroupBox), &SUI::ObjectFactory::createGroupBox},
    {&typeid(SUI::CheckGroupBox), &SUI::ObjectFactory::createCheckGroupBox},
    {&typeid(SUI::ButtonBar), &SUI::ObjectFactory::createButtonBar},
    {&typeid(SUI::TableWidget), &SUI::ObjectFactory::createTableWidget},
    {&typeid(SUI::TableWidgetItem), &SUI::ObjectFactory::createTableWidgetItem},
    {&typeid(SUI::SpinBox), &SUI::ObjectFactory::createSpinBox},
    {&typeid(SUI::DoubleSpinBox), &SUI::ObjectFactory::createDoubleSpinBox},
    {&typeid(SUI::DropDown), &SUI::ObjectFactory::createDropDown},
    {&typeid(SUI::CheckMark), &SUI::ObjectFactory::createCheckMark},
    {&typeid(SUI::LEDWidget), &SUI::ObjectFactory::createLEDWidget},
    {&typeid(SUI::ColorDrop), &SUI::ObjectFactory::createColorDrop},
    {&typeid(SUI::ColorCrossDrop), &SUI::ObjectFactory::createColorCrossDrop},
    {&typeid(SUI::TextArea), &SUI::ObjectFactory::createTextArea},
    {&typeid(SUI::ProgressBar), &SUI::ObjectFactory::createProgressBar},
    {&typeid(SUI::GraphicsView), &SUI::ObjectFactory::createImageViewer},
    {&typeid(SUI::MessageBox), &SUI::ObjectFactory::createMessageBox},
    {&typeid(SUI::Splitter), &SUI::ObjectFactory::createSplitter},
    {&typeid(SUI::FileDialog), &SUI::ObjectFactory::createFileDialog},
    {&typeid(SUI::UserControl), &SUI::ObjectFactory::createUserControl},
    {&typeid(SUI::PlotWidget), &SUI::ObjectFactory::createPlotWidget},
    {&typeid(SUI::ListView), &SUI::ObjectFactory::createListView},
    {&typeid(SUI::ControlWidget), &SUI::ObjectFactory::createControlWidget},
    {&typeid(SUI::StateWidget), &SUI::ObjectFactory::createStateWidget},
    {&typeid(SUI::ScienceSpinBox), &SUI::ObjectFactory::createScienceSpinBox},
    {&typeid(SUI::QuestionMark), &SUI::ObjectFactory::createQuestionMark},
    {&typeid(SUI::BusyIndicator), &SUI::ObjectFactory::createBusyIndicator},
    {&typeid(SUI::ImageWidget), &SUI::ObjectFactory::createImageWidget},
    {&typeid(SUI::TreeView), &SUI::ObjectFactory::createTreeView},
    {&typeid(SUI::TreeViewItem), &SUI::ObjectFactory::createTreeViewItem},
    {&typeid(SUI::LineWidget), &SUI::ObjectFactory::createLineWidget},
    {&typeid(SUI::SvgWidget), &SUI::ObjectFactory::createSvgWidget},
    {&typeid(SUI::ScrollBar), &SUI::ObjectFactory::createScrollBar},
    {&typeid(SUI::DateTimeEdit), &SUI::ObjectFactory::createDateTimeEdit},
    {&typeid(SUI::WebView), &SUI::ObjectFactory::createWebView}
};


SUI::ObjectFactory::~ObjectFactory()
{
}

SUI::ObjectFactory *SUI::ObjectFactory::getInstance() {
    static ObjectFactoryImpl instance;
    return &instance;
}

std::string SUI::ObjectFactory::getName() const {
    return name;
}

std::string SUI::ObjectFactory::getDescription() const {
    return description;
}

std::string SUI::ObjectFactory::getVersion() const {
    return version.toString();
}

bool SUI::ObjectFactory::isWidget(const std::type_info &typeInfo) const
{ return widgetTypeMap.find(&typeInfo) != widgetTypeMap.end(); }

std::string SUI::ObjectFactory::Demangler::operator()(const char *name) {
   int status = -4;
   p = abi::__cxa_demangle(name,NULL,NULL,&status);
   return std::string(status == 0 ? p : name);       
}

SUI::ObjectFactory::Demangler::~Demangler() {
   std::free(p); 
}

void *SUI::ObjectFactory::getImplementation(GraphicsItem *item) {
    return item ? item->implementation : NULL;
}

void *SUI::ObjectFactory::getPlotImplementation(SUI::PlotItem *item) {
    return item ? item->implementation : NULL;
}
