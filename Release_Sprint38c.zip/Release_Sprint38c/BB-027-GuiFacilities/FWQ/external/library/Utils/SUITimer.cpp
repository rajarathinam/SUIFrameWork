//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for Timer.
// !\description Class implementation file for Timer.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUITimer.h"

#include "SUITimerImpl.h"

SUI::Timer::~Timer()
{
}

boost::shared_ptr<SUI::Timer> SUI::Timer::createTimer() {
    return boost::shared_ptr<Timer>(new TimerImpl);
}

