//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class ImageEnum.
// !\description Header file for class ImageEnum.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUIImageEnum.h"

std::string SUI::ImageEnum::getFileExtension(FileType fileType) {
    switch (fileType)
    {
    case ImageEnum::JPG:    return ".jpg";
    case ImageEnum::TIFF:   return ".tiff";
    case ImageEnum::BMP:    return ".bmp";
    case ImageEnum::PNG:    return ".png";
    default: return ""; // is never called
    }
}
