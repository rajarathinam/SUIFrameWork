//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for TableWidgetItem.
// !\description Class implementation file for TableWidgetItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUITableWidgetItem.h"

#include "SUIObjectFactory.h"

SUI::TableWidgetItem::TableWidgetItem() : 
    Widget(SUI::ObjectType::TableWidgetItem)
{
}

SUI::TableWidgetItem::~TableWidgetItem()
{
}
