//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for ControlWidget.
// !\description Class implementation file for ControlWidget.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIControlWidget.h"

#include "SUIObjectFactory.h"

SUI::ControlWidget::ControlWidget() : 
    StateWidget(SUI::ObjectType::fromString(SUI::ObjectFactory::getClassName<ControlWidget>()))
{
}

SUI::ControlWidget::~ControlWidget()
{
}
