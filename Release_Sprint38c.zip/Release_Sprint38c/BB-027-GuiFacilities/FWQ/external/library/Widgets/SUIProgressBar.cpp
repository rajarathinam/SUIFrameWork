//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for ProgressBar.
// !\description Class implementation file for ProgressBar.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIProgressBar.h"

#include "SUIObjectFactory.h"

SUI::ProgressBar::ProgressBar() : 
    Widget(SUI::ObjectType::ProgressBar)
{
}

SUI::ProgressBar::~ProgressBar()
{
}
