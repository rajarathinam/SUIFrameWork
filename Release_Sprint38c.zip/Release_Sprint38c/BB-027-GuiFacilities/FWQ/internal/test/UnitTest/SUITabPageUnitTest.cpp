#include "SUITabPageUnitTest.h"

SUI::TabPageUnitTest::TabPageUnitTest(SUI::TabPage *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::TabPageUnitTest::~TabPageUnitTest() {
    delete object;
}

