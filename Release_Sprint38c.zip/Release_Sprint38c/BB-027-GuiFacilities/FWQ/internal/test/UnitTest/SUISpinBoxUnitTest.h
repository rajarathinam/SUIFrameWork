#ifndef SUISPINBOXUNITTEST_H
#define SUISPINBOXUNITTEST_H

#include "SUIWidgetUnitTest.h"
#include "SUISpinBox.h"

namespace SUI {

class SpinBox;

class SpinBoxUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    SpinBoxUnitTest(SUI::SpinBox *object, QObject *parent = 0);
    virtual ~SpinBoxUnitTest();

protected:
    void callInterfaceTests();

private:
    SpinBox *object;
};

}
#endif // SUISPINBOXUNITTEST_H
