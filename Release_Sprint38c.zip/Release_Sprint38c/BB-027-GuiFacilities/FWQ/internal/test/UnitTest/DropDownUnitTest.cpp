#include "DropDownUnitTest.h"

#include <memory>
#include <boost/assign/list_of.hpp>

#include <QSignalSpy>
#include <QDebug>

#include <SUIArgumentException.h>

DropDownUnitTest::DropDownUnitTest():
    mDropDownWidg(new SUI::DropDownImpl(NULL)),
    mIDropDownWidg(dynamic_cast<SUI::DropDown *>(mDropDownWidg)),
    mIDropDownWidg_Status(dynamic_cast<SUI::Widget *>(mDropDownWidg)),
    mIDropDownWidg_Color(dynamic_cast<SUI::IColorable *>(mDropDownWidg)),
    mIDropDownWidg_BGColor(dynamic_cast<SUI::IBGColorable *>(mDropDownWidg)),
    mIDropDownWidg_Items(dynamic_cast<SUI::StringList *>(mDropDownWidg)),
    mIDropDownWidg_ErrorMode(dynamic_cast<SUI::IErrorMode *>(mDropDownWidg))
{}

void DropDownUnitTest::initTestCase()
{
    std::list<std::string>  itemStdLst = boost::assign::list_of( "Test1" ) ( "Test2" ) ( "Test3" );
    mDropDownWidg->addItems(itemStdLst);
}

void DropDownUnitTest::cleanupTestCase()
{
    delete mDropDownWidg;
}

void DropDownUnitTest::testVisibilityCase2()
{
    QFETCH(bool, value1);
    mIDropDownWidg->setVisible(value1);
    QCOMPARE(dynamic_cast<QComboBox *>(mDropDownWidg->getWidget())->isVisible(), value1);
}

void DropDownUnitTest::testVisibilityCase2_data()
{
    QTest::addColumn<bool>("value1");
    QTest::newRow("First change") << true;
    QTest::newRow("Second change") << false;
}

void DropDownUnitTest::testEnabledCase2()
{
    QFETCH(bool, value1);
    mIDropDownWidg->setEnabled(value1);
    QCOMPARE(dynamic_cast<QComboBox *>(mDropDownWidg->getWidget())->isEnabled(), value1);
}

void DropDownUnitTest::testEnabledCase2_data()
{
    QTest::addColumn<bool>("value1");
    QTest::newRow("First change") << true;
    QTest::newRow("Second change") << false;
}

void DropDownUnitTest::testGetTextCase1()
{
    QFETCH(QString, value1);
    std::list<std::string> items = mDropDownWidg->getItems();
    QCOMPARE((int)items.size(), 3);
    QCOMPARE(QString::fromStdString(*items.begin()), value1);
}

void DropDownUnitTest::testGetTextCase1_data()
{
    QTest::addColumn<QString>("value1");
    QTest::newRow("GetText") << QString("Test1");
}

void DropDownUnitTest::testGetSelectedItemsCase1()
{
    QFETCH(QString, value1);
    QStringList itemList;
    foreach(std::string item, mDropDownWidg->getSelectedItems())
    {
        itemList.append(QString::fromStdString(item));
    }
    QCOMPARE(itemList.join(";"), value1);
}

void DropDownUnitTest::testGetSelectedItemsCase1_data()
{
    QTest::addColumn<QString>("value1");
    QTest::newRow("GetText") << QString("Test1");
}

void DropDownUnitTest::testSetTextCase2()
{
    QFETCH(QString, value1);
    std::list<std::string>  items = boost::assign::list_of( value1.toStdString() );
    mDropDownWidg->addItems(items);
    QCOMPARE(dynamic_cast<QComboBox *>(mDropDownWidg->getWidget())->itemText(dynamic_cast<QComboBox *>(mDropDownWidg->getWidget())->findText(value1)), value1);
}

void DropDownUnitTest::testSetTextCase2_data()
{
    QTest::addColumn<QString>("value1");
    QTest::newRow("First change") << QString("Piet");
}

void DropDownUnitTest::testClearTextCase2()
{
    QFETCH(QString, NewText);
    mDropDownWidg->clearItems();
    QCOMPARE((int)(mDropDownWidg->getItems().size()), 0);
}

void DropDownUnitTest::testClearTextCase2_data()
{
    QTest::addColumn<QString>("NewText");
    QTest::newRow("First change") << QString("");
}

void DropDownUnitTest::testAddItemsCase1()
{
    QFETCH(QString, NewText);
    QStringList itemList = NewText.split(";");
    std::list<std::string>  itemStdLst;
    foreach(QString item, itemList)
    {
        itemStdLst.push_back(item.toStdString());
    }
    mDropDownWidg->addItems(itemStdLst);
    itemList.clear();
    foreach(std::string item, mDropDownWidg->getItems())
    {
        itemList.append(QString::fromStdString(item));
    }
    QCOMPARE(itemList.join(";"), NewText);
}

void DropDownUnitTest::testAddItemsCase1_data()
{
    QTest::addColumn<QString>("NewText");
    QTest::newRow("Add Items") << QString("Test1;Test2;Test3");
}

// OBSOLETE
//void DropDownUnitTest::testSetModeCase1()
//{
//    QFETCH(bool, NewBool);
//    QFETCH(QString, NewText);
//    if (NewBool)
//    {
//        mDropDownWidg->setMode(SUI::ErrorModeEnum::Error);
//    }
//    else
//    {
//        mDropDownWidg->setMode(SUI::ErrorModeEnum::None);
//    }
//    QTEST(mDropDownWidg->getWidget()->palette().color(QPalette::Window).name(), "NewText");
//}

//void DropDownUnitTest::testSetModeCase1_data()
//{
//    QTest::addColumn<bool>("NewBool");
//    QTest::addColumn<QString>("NewText");
//    QTest::newRow("Set ErrorMode") << true << QString("#ff0000");
//    QTest::newRow("Set ErrorMode") << false << QString("#d3e2f7");;
//}

void DropDownUnitTest::testHandleChangeCase1()
{
    QFETCH(QString, newText);
    QFETCH(int, newInt);
    QSignalSpy spy(mDropDownWidg->getWidget(), SIGNAL(currentIndexChanged(QString)));
    mDropDownWidg->selectItem(newInt);
    QFETCH(bool, willSignal );
    if( willSignal )
    {
      QCOMPARE(spy.count(), 1);
    }
    else
      QCOMPARE(spy.count(), 0);
}

void DropDownUnitTest::testHandleChangeCase1_data()
{
    QTest::addColumn<QString>("newText");
    QTest::addColumn<int>("newInt");
    QTest::addColumn<bool>( "willSignal" );
    QTest::newRow("Handle change") << QString("newTest") <<int(2) << true;
}

void DropDownUnitTest::testSelectItemCase1()
{
    QFETCH(QString, NewText);
    QFETCH(int, NewInt);
    mDropDownWidg->selectItem(NewInt);
    std::list<std::string> items = mDropDownWidg->getSelectedItems();
    std::string selected = *items.begin();
    QCOMPARE(QString::fromStdString(selected), NewText);
}

void DropDownUnitTest::testSelectItemCase1_data()
{
    QTest::addColumn<QString>("NewText");
    QTest::addColumn<int>("NewInt");
    QTest::newRow("Selected Item") << QString("Test3") << int(2);
}

void DropDownUnitTest::testGetColorsCase1()
{
    QFETCH(QString, NewText);
    std::string text = SUI::ColorEnum::toString(SUI::ColorEnum::getColorEnumList(SUI::ObjectType::DropDown),";");
    QCOMPARE(QString::fromStdString(text.substr(0,text.size())), NewText);
}

void DropDownUnitTest::testGetColorsCase1_data()
{
    QTest::addColumn<QString>("NewText");
    QTest::newRow("Colors") << QString("standard;red;green;blue;gray;yellow");
}

void DropDownUnitTest::testColorCase1()
{
    QFETCH(QString, NewText);
    mDropDownWidg->setColor(SUI::ColorEnum::fromString(NewText.toStdString()));
    QCOMPARE(QString::fromStdString(SUI::ColorEnum::toString(mDropDownWidg->getColor())), NewText);
}

void DropDownUnitTest::testColorCase1_data()
{
    QTest::addColumn<QString>("NewText");
    QTest::newRow("Set Color Green") << QString("green");
    QTest::newRow("Set Color Black") << QString("standard");
}

void DropDownUnitTest::testBGColorCase1()
{
    QFETCH(QString, NewText);
    mDropDownWidg->setBGColor(SUI::ColorEnum::fromString(NewText.toStdString()));
    QCOMPARE(QString::fromStdString(SUI::ColorEnum::toString(mDropDownWidg->getBGColor())), NewText);
}

void DropDownUnitTest::testBGColorCase1_data()
{
    QTest::addColumn<QString>("NewText");
    QTest::newRow("Set Color Green") << QString("green");
    QTest::newRow("Set Color Black") << QString("standard");
}

void DropDownUnitTest::testSetBoldCase1()
{
    QFETCH(bool, NewBool);
    QFETCH(QString, NewText);
    mDropDownWidg->setBold(NewBool);
    QCOMPARE(mDropDownWidg->getWidget()->property("SUIFont").toString(), NewText);
}

void DropDownUnitTest::testSetBoldCase1_data()
{
    QTest::addColumn<bool>("NewBool");
    QTest::addColumn<QString>("NewText");
    QTest::newRow("First change") << true << QString("bold");
    QTest::newRow("Second change") << false << QString("");
}

void DropDownUnitTest::testWidthCase1()
{
    QFETCH(QString, NewText);
    mDropDownWidg->setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, NewText);
    QCOMPARE(mDropDownWidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width), NewText);
}

void DropDownUnitTest::testWidthCase1_data()
{
    QTest::addColumn<QString>("NewText");
    QTest::newRow("Set Width item") << QString("200");
}

void DropDownUnitTest::testWidthCase2()
{
    QFETCH(QString, NewText);
    mDropDownWidg->setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, NewText);
    QCOMPARE(QString::number(mDropDownWidg->getWidget()->width()), NewText);
}

void DropDownUnitTest::testWidthCase2_data()
{
    QTest::addColumn<QString>("NewText");
    QTest::newRow("Set Width item") << QString("150");
}

void DropDownUnitTest::testClearItemsCase2()
{
    QFETCH(QString, NewText);
    mDropDownWidg->clearItems();
    QCOMPARE(mDropDownWidg->getAllColumnItems(0), NewText);
}

void DropDownUnitTest::testClearItemsCase2_data()
{
    QTest::addColumn<QString>("NewText");
    QTest::newRow("Clear Items") << QString("");
}

void DropDownUnitTest::testRemoveItemCase1()
{
    QFETCH(QString, RemoveText);
    try
    {
        std::list<std::string> itemList;
        foreach(QString item, RemoveText.split(";"))
        {
            itemList.push_back(item.toStdString());
        }
        mDropDownWidg->removeItems(itemList);
    }
    catch (SUI::ArgumentException *re)
    {
        qDebug() << "Item not deleted";
        delete re;
    }
    QStringList itemStrLst;
    foreach(std::string item, mDropDownWidg->getItems())
    {
        itemStrLst.append(QString::fromStdString(item));
    }
    QString items = itemStrLst.join(";");
    QCOMPARE(bool(items.contains(RemoveText)), false);
}

void DropDownUnitTest::testRemoveItemCase1_data()
{
    QTest::addColumn<QString>("RemoveText");
    QTest::newRow("First item") << QString("Test1;Test3");
    QTest::newRow("Last item") << QString("Piet");
}

void DropDownUnitTest::testVisibilityCase1()
{
    QFETCH(bool, value1);
    mIDropDownWidg_Status->setVisible(value1);
    QCOMPARE(mIDropDownWidg_Status->isVisible(), value1);
}

void DropDownUnitTest::testVisibilityCase1_data()
{
    QTest::addColumn<bool>("value1");
    QTest::newRow("First change") << true;
    QTest::newRow("Second change") << false;
}

void DropDownUnitTest::testEnabledCase1()
{
    QFETCH(bool, value1);
    mIDropDownWidg_Status->setEnabled(value1);
    QCOMPARE(mIDropDownWidg_Status->isEnabled(), value1);
}

void DropDownUnitTest::testEnabledCase1_data()
{
    QTest::addColumn<bool>("value1");
    QTest::newRow("First change") << true;
    QTest::newRow("Second change") << false;
}

void DropDownUnitTest::testGetSelectedItemsCase2()
{
    QFETCH(QString, value1);
    QStringList itemList;
    foreach(std::string item, mIDropDownWidg->getSelectedItems())
    {
        itemList.append(QString::fromStdString(item));
    }
    QCOMPARE(itemList.join(";"), value1);
}

void DropDownUnitTest::testGetSelectedItemsCase2_data()
{
    QTest::addColumn<QString>("value1");
    QTest::newRow("GetText") << QString("Test3");
}

void DropDownUnitTest::testRemoveItemCase2()
{
    QFETCH(QString, RemoveText);
    try
    {
        std::list<std::string> itemList;
        foreach(QString item, RemoveText.split(";"))
        {
            itemList.push_back(item.toStdString());
        }
        mIDropDownWidg->removeItems(itemList);
    }
    catch (SUI::ArgumentException *)
    {
        qDebug() << "Item not deleted";
    }
    QStringList itemStrLst;
    foreach(std::string item, mIDropDownWidg->getItems())
    {
        itemStrLst.append(QString::fromStdString(item));
    }
    QString items = itemStrLst.join(";");
    QCOMPARE(bool(items.contains(RemoveText)), false);
}

void DropDownUnitTest::testRemoveItemCase2_data()
{
    QTest::addColumn<QString>("RemoveText");
    QTest::newRow("First item") << QString("Test1");
    QTest::newRow("Second item & Last") << QString("Test3");
}

void DropDownUnitTest::testAddItemsCase2()
{
    QFETCH(QString, NewText);
    std::list<std::string>  itemStdList;
    foreach(QString item, NewText.split(";"))
    {
        itemStdList.push_back(item.toStdString());
    }
    mIDropDownWidg->clearItems();
    mIDropDownWidg->addItems(itemStdList);
    QStringList itemList;
    foreach(std::string item, mIDropDownWidg->getItems())
    {
        itemList.append(QString::fromStdString(item));
    }
    QCOMPARE(itemList.join(";"), NewText);
}

void DropDownUnitTest::testAddItemsCase2_data()
{
    QTest::addColumn<QString>("NewText");
    QTest::newRow("Add Items") << QString("Test1;Test2;Test3");
}

void DropDownUnitTest::testGetColorsCase2()
{
    QFETCH(QString, NewText);
    std::string text;
    std::list<SUI::ColorEnum::Color>  colorList = SUI::ColorEnum::getColorEnumList(SUI::ObjectType::DropDown);
    foreach (SUI::ColorEnum::Color color, colorList)
    {
        text.append(SUI::ColorEnum::toString(color));
        text.append(";");
    }
    text = text.erase(text.size()-1);

    QCOMPARE(QString::fromStdString(text.substr(0,text.size())), NewText);
}

void DropDownUnitTest::testGetColorsCase2_data()
{
    QTest::addColumn<QString>("NewText");
    QTest::newRow("Colors") << QString("standard;red;green;blue;gray;yellow");
}

void DropDownUnitTest::testColorCase2()
{
    QFETCH(QString, NewText);
    mIDropDownWidg_Color->setColor(SUI::ColorEnum::fromString(NewText.toStdString()));
    QCOMPARE(QString::fromStdString(SUI::ColorEnum::toString(mIDropDownWidg_Color->getColor())), NewText);
}

void DropDownUnitTest::testColorCase2_data()
{
    QTest::addColumn<QString>("NewText");
    QTest::newRow("Set Color Green") << QString("green");
    QTest::newRow("Set Color Black") << QString("standard");
}

void DropDownUnitTest::testBGColorCase2()
{
    QFETCH(QString, NewText);
    mIDropDownWidg_BGColor->setBGColor(SUI::ColorEnum::fromString(NewText.toStdString()));
    QCOMPARE(QString::fromStdString(SUI::ColorEnum::toString(mIDropDownWidg_BGColor->getBGColor())), NewText);
}

void DropDownUnitTest::testBGColorCase2_data()
{
    QTest::addColumn<QString>("NewText");
    QTest::newRow("Set Color Green") << QString("green");
    QTest::newRow("Set Color Black") << QString("standard");
}

void DropDownUnitTest::testClearItemsCase1()
{
    QFETCH(QString, NewText);
    mIDropDownWidg_Items->clearItems();
    QStringList itemList;
    foreach(std::string item, mIDropDownWidg_Items->getItems())
    {
        itemList.append(QString::fromStdString(item));
    }
    QCOMPARE(itemList.join(";"), NewText);
}

void DropDownUnitTest::testClearItemsCase1_data()
{
    QTest::addColumn<QString>("NewText");
    QTest::newRow("Clear Items") << QString("");
}

//void DropDownUnitTest::testSetModeCase2()
//{
//    QFETCH(bool, NewBool);
//    QFETCH(QString, NewText);
//    QString color;
//    if (NewBool)
//    {
//        mIDropDownWidg_ErrorMode->setMode(SUI::ErrorModeEnum::Error);
//    }
//    else
//    {
//        mIDropDownWidg_ErrorMode->setMode(SUI::ErrorModeEnum::None);
//    }
//    color = dynamic_cast<QComboBox *>(mDropDownWidg->getWidget())->palette().color(QPalette::Window).name();
//    QCOMPARE(color, NewText);
//}

//void DropDownUnitTest::testSetModeCase2_data()
//{
//    QTest::addColumn<bool>("NewBool");
//    QTest::addColumn<QString>("NewText");
//    QTest::newRow("Set ErrorMode") << true << QString("#ff0000");
//    QTest::newRow("Set ErrorMode") << false << QString("#d3e2f7");;
//}
