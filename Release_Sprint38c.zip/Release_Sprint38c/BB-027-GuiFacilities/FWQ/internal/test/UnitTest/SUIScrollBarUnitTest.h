#ifndef SUISCROLLBARUNITTEST_H
#define SUISCROLLBARUNITTEST_H

#include "SUIWidgetUnitTest.h"
#include "SUIScrollBar.h"

namespace SUI {

class ScrollBar;

class ScrollBarUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    ScrollBarUnitTest(SUI::ScrollBar *object, QObject *parent = 0);
    virtual ~ScrollBarUnitTest();

private:
    ScrollBar *object;
};

}


#endif // SUISCROLLBARUNITTEST_H
