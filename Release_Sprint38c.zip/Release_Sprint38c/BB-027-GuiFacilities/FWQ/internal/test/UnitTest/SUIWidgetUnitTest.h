#ifndef SUIWIDGETUNITTEST_H
#define SUIWIDGETUNITTEST_H

#include "SUIObjectUnitTest.h"

namespace SUI {

class Widget;

class WidgetUnitTest : public ObjectUnitTest
{
    Q_OBJECT
public:
     WidgetUnitTest(Widget *object, QObject *parent);
    virtual ~WidgetUnitTest();

private slots:
    void setEnabled();
    void setFocus();
    void clearFocus();
    void setContextMenuItems();
    void contextMenuClicked();
    void setStyleSheetClass();

    void setGeometry();
    void setGeometry_data();

private:
    void onContextMenuClicked(const std::string &s,const std::string &s2);

    Widget *object;
};

}
#endif // SUIWIDGETUNITTEST_H
