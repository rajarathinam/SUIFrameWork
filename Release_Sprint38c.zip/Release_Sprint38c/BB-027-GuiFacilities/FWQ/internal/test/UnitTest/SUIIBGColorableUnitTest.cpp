#include "SUIIBGColorableUnitTest.h"

#include <QTest>

#include <SUIIBGColorable.h>

SUI::IBGColorableUnitTest::IBGColorableUnitTest(SUI::IBGColorable *object) :
    object(object)
{
    Q_ASSERT(object);
}

bool SUI::IBGColorableUnitTest::setBackgroundColor(SUI::ColorEnum::Color color) {
    object->setBGColor(color);
    return (object->getBGColor() == color);
}

bool SUI::IBGColorableUnitTest::setBackgroundColor() {
    object->setBGColor(SUI::ColorEnum::Green);
    return (object->getBGColor() == ColorEnum::Green);
}
