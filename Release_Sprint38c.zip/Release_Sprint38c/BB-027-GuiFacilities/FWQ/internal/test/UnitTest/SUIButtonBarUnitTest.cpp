#include "SUIButtonBarUnitTest.h"
#include <QTest>


SUI::ButtonBarUnitTest::ButtonBarUnitTest(SUI::ButtonBar *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{

}


SUI::ButtonBarUnitTest::~ButtonBarUnitTest() {
    delete object;
}
