#include "SUITextAreaUnitTest.h"
#include "SUIIErrorModeUnitTest.h"

#include <QTest>

SUI::TextAreaUnitTest::TextAreaUnitTest(SUI::TextArea *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::TextAreaUnitTest::~TextAreaUnitTest() {
    delete object;
}

void SUI::TextAreaUnitTest::callInterfaceTests() {
    //IErrorMode
    IErrorModeUnitTest iErrorModeUnitTest(object);
    QVERIFY(iErrorModeUnitTest.setErrorMode());
}
