#include "TreeViewUnitTest.h"

#include <SUIException.h>

TreeViewUnitTest::TreeViewUnitTest() :
    mTreeWidg(new SUI::TreeViewImpl(NULL)),
    mITreeWidg(dynamic_cast<SUI::TreeView *>(mTreeWidg)),
    mITreeWidg_Status(dynamic_cast<SUI::Widget *>(mTreeWidg)),
    mITreeWidg_Text(dynamic_cast<SUI::IText *>(mTreeWidg))
{}

void TreeViewUnitTest::initTestCase()
{
    mTreeWidg->setId("trvTest");
}

void TreeViewUnitTest::cleanupTestCase()
{
    delete mTreeWidg;
}

void TreeViewUnitTest::testVisibilityCase2()
{
    QFETCH(bool, value1);

    mITreeWidg->setVisible(value1);

    QCOMPARE(dynamic_cast<QTreeView *>(mTreeWidg->getWidget())->isVisible(), value1);
}

void TreeViewUnitTest::testVisibilityCase2_data()
{
    QTest::addColumn<bool>("value1");
    QTest::newRow("First change") << true ;
    QTest::newRow("Second change") << false ;
}

void TreeViewUnitTest::testEnabledCase2()
{
    QFETCH(bool, value1);

    mITreeWidg->setEnabled(value1);

    QCOMPARE(dynamic_cast<QTreeView *>(mTreeWidg->getWidget())->isEnabled(), value1);
}

void TreeViewUnitTest::testEnabledCase2_data()
{
    QTest::addColumn<bool>("value1");
    QTest::newRow("First change") << true ;
    QTest::newRow("Second change") << false ;
}

void TreeViewUnitTest::testSetTextCase1()
{
    QFETCH(QString, NewText);

    mITreeWidg_Text->setText(NewText.toStdString());

    QCOMPARE(QString::fromStdString(mITreeWidg_Text->getText()), NewText);
}

void TreeViewUnitTest::testSetTextCase1_data()
{
    QTest::addColumn<QString>("NewText");
    QTest::newRow("First change") << QString("Pietje Pukkel");
}

void TreeViewUnitTest::testClearTextCase1()
{
    QFETCH(QString, NewText);

    mITreeWidg_Text->clearText();

    QCOMPARE(QString::fromStdString(mITreeWidg_Text->getText()), NewText);
}

void TreeViewUnitTest::testClearTextCase1_data()
{
    QTest::addColumn<QString>("NewText");
    QTest::newRow("First change") << QString("");
}

void TreeViewUnitTest::testAddTreeItemCase1()
{
    QFETCH(QString, itemName);
    QString id = itemName;
    std::string idStr = id.toStdString();
    mTreeWidg->addTreeItem(itemName.toStdString(), idStr, "");
}

void TreeViewUnitTest::testAddTreeItemCase1_data()
{
    QTest::addColumn<QString>("itemName");
    QTest::newRow("Add Root Item") << QString("Pietje Pukkel");
}

void TreeViewUnitTest::testAddTreeItemCase2()
{
    QFETCH(QString, itemName);
    QFETCH(QString, parentItemName);
    std::string idStr = itemName.toStdString();
    mTreeWidg->addTreeItem(itemName.toStdString(), idStr, parentItemName.toStdString());
}

void TreeViewUnitTest::testAddTreeItemCase2_data()
{
    QTest::addColumn<QString>("itemName");
    QTest::addColumn<QString>("parentItemName");
    QTest::newRow("Add Sub Item") << QString("Pietje Puk") << QString("triPietje Pukkel");
}

void TreeViewUnitTest::testIsLeafNode()
{
    QFETCH(QString, itemName);
    QFETCH(bool, result);
    QCOMPARE(mITreeWidg->isLeafNode(itemName.toStdString()), result);
}

void TreeViewUnitTest::testIsLeafNode_data()
{
    QTest::addColumn<QString>("itemName");
    QTest::addColumn<bool>("result");
    QTest::newRow("LeafNode") << QString("triPietje Puk") << true;
    QTest::newRow("ParentNode") << QString("triPietje Pukkel") << false;
}

void TreeViewUnitTest::testRemoveTreeItemCase1()
{
    bool removed = true;
    QFETCH(QString, itemName);
    QFETCH(bool, result);
    // try-catch is useless because there won't be an event thrown by the TreeView object
    //try
    //{
        std::list<std::string> itemList;
        itemList.push_back(itemName.toStdString());
        mTreeWidg->removeItems(itemList);
    //}
    //catch (SUI::Exception *re)
    //{
    //    removed = false;
    //    delete re;
    //}
    QCOMPARE(removed, result);
}

void TreeViewUnitTest::testRemoveTreeItemCase1_data()
{
    QTest::addColumn<QString>("itemName");
    QTest::addColumn<bool>("result");
    QTest::newRow("Pass Remove from item") << QString("triPietje Puk") << true;
    QTest::newRow("Pass Remove from root") << QString("triPietje Pukkel") << true;
    //QTest::newRow("Fail remove") << QString("Pietje Pukkel") << false;            // TreeView object does not throw an exception.
                                                                                    // This needs to be tested differently
}

void TreeViewUnitTest::testGetSelectedItemsCase1()
{
    QFETCH(QString, itemName);
    mTreeWidg->selectItem(0,0);
    QStringList itemList;
    foreach(std::string item, mTreeWidg->getSelectedItems())
    {
        itemList.append(QString::fromStdString(item));
    }

    QCOMPARE(itemList.join(";"), itemName);
}

void TreeViewUnitTest::testGetSelectedItemsCase1_data()
{
    QTest::addColumn<QString>("itemName");
    QTest::newRow("Pass Remove from item") << QString("triPietje Pukkel");
}

void TreeViewUnitTest::testSelectItemCase1()
{
    QFETCH(QString, itemName);
    QFETCH(int, index);

    mTreeWidg->selectItem(index);
    QStringList itemList;
    foreach(std::string item, mTreeWidg->getSelectedItems())
    {
        itemList.append(QString::fromStdString(item));
    }
    QCOMPARE(itemList.join(";"), itemName);
}

void TreeViewUnitTest::testSelectItemCase1_data()
{
    QTest::addColumn<QString>("itemName");
    QTest::addColumn<int>("index");
    QTest::newRow("Pass Remove from item") << QString("triPietje Pukkel") << int(0);
}

void TreeViewUnitTest::testVisibilityCase1()
{
    QFETCH(bool, value1);

    mITreeWidg_Status->setVisible(value1);

    QCOMPARE(mITreeWidg_Status->isVisible(), value1);
}

void TreeViewUnitTest::testVisibilityCase1_data()
{
    QTest::addColumn<bool>("value1");
    QTest::newRow("First change") << true ;
    QTest::newRow("Second change") << false ;
}

void TreeViewUnitTest::testEnabledCase1()
{
    QFETCH(bool, value1);

    mITreeWidg_Status->setEnabled(value1);

    QCOMPARE(mITreeWidg_Status->isEnabled(), value1);
}

void TreeViewUnitTest::testEnabledCase1_data()
{
    QTest::addColumn<bool>("value1");
    QTest::newRow("First change") << true ;
    QTest::newRow("Second change") << false ;
}



void TreeViewUnitTest::testIAddTreeItemCase1()
{
    QFETCH(QString, itemName);
    std::string idStr = itemName.toStdString();
    mITreeWidg->addTreeItem(itemName.toStdString(), idStr, "");
}

void TreeViewUnitTest::testIAddTreeItemCase1_data()
{
    QTest::addColumn<QString>("itemName");
    QTest::newRow("Add Root Item") << QString("Pietje Pukkel");
}

void TreeViewUnitTest::testIAddTreeItemCase2()
{
    QFETCH(QString, itemName);
    QFETCH(QString, parentItemName);
    std::string idStr = itemName.toStdString();
    mITreeWidg->addTreeItem(itemName.toStdString(), idStr, parentItemName.toStdString());
}

void TreeViewUnitTest::testIAddTreeItemCase2_data()
{
    QTest::addColumn<QString>("itemName");
    QTest::addColumn<QString>("parentItemName");
    QTest::newRow("Add Sub Item") << QString("Pietje Puk") << QString("Pietje Pukkel");
}

void TreeViewUnitTest::testIRemoveTreeItemCase1()
{
    bool removed = true;
    QFETCH(QString, itemName);
    QFETCH(bool, result);
// try-catch is useless because there won't be an event thrown by the TreeView object
//    try
//    {
        std::list<std::string> itemList;
        itemList.push_back(itemName.toStdString());
        mITreeWidg->removeItems(itemList);
//    }
//    catch (SUI::Exception *re)
//    {
//        removed = false;
//        delete re;
//    }
    QCOMPARE(removed, result);
}

void TreeViewUnitTest::testIRemoveTreeItemCase1_data()
{
    QTest::addColumn<QString>("itemName");
    QTest::addColumn<bool>("result");
    QTest::newRow("Pass Remove from item") << QString("triPietje Puk") << true;
    QTest::newRow("Pass Remove from root") << QString("triPietje Pukkel") << true;
    // QTest::newRow("Fail remove") << QString("Pietje Pukkel") << false;           // TreeView object does not throw an exception.
                                                                                    // This needs to be tested differently
}
