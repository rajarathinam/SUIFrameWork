#include "SUIDoubleSpinBoxUnitTest.h"
#include "SUIDoubleSpinBox.h"
#include "SUIIAlignableUnitTest.h"
#include "SUIIErrorModeUnitTest.h"

#include <QTest>

SUI::DoubleSpinBoxUnitTest::DoubleSpinBoxUnitTest(SUI::DoubleSpinBox *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
    object->setPrecision(3);
}

SUI::DoubleSpinBoxUnitTest::~DoubleSpinBoxUnitTest() {
    delete object;
}

void SUI::DoubleSpinBoxUnitTest::callInterfaceTests() {
    //IAlignable unit test
    IAlignableUnitTest iAlignableUnitTest(object);
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::HCenter));
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Left));
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Right));
    QCOMPARE(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Stretch), false );

    //IErrorMode
    IErrorModeUnitTest iErrorModeUnitTest(object);
    QVERIFY(iErrorModeUnitTest.setErrorMode());
}

void SUI::DoubleSpinBoxUnitTest::setMinValue() {
    QFETCH(double, minValue);
    object->setMinValue(minValue);
    QCOMPARE(object->getMinValue(), minValue);
}

void SUI::DoubleSpinBoxUnitTest::setMinValue_data() {
    QTest::addColumn<double>("minValue");
    QTest::newRow("Test setMinValue 1") << double(-500000.000);
    QTest::newRow("Test setMinValue 2") << double(0.099);
}

void SUI::DoubleSpinBoxUnitTest::setMaxValue() {
    QFETCH(double, maxValue);
    object->setMaxValue(maxValue);
    QCOMPARE(object->getMaxValue(), maxValue);
}

void SUI::DoubleSpinBoxUnitTest::setMaxValue_data() {
    QTest::addColumn<double>("maxValue");
    QTest::newRow("Test setMaxValue 1") << double(100000.00);
    QTest::newRow("Test setMaxValue 2") << double(100000000.00);
}

void SUI::DoubleSpinBoxUnitTest::setStepSize() {
    QFETCH(double, stepsize);
    object->setStepSize(stepsize);
    QCOMPARE(object->getStepSize(), stepsize);
}

void SUI::DoubleSpinBoxUnitTest::setStepSize_data() {
    QTest::addColumn<double>("stepsize");
    QTest::newRow("Test stepsize 1") << double(0.100);
    QTest::newRow("Test stepsize 2") << double(1.01);
}

void SUI::DoubleSpinBoxUnitTest::setValue() {
    QFETCH(double, value);
    object->setValue(value);
    object->setMinValue(-50000);
    QCOMPARE(object->getValue(), value);
}

void SUI::DoubleSpinBoxUnitTest::setValue_data() {
    QTest::addColumn<double>("value");
    QTest::newRow("Test value 1") << double(5.645);
    QTest::newRow("Test value 2") << double(-4.454);
}

void SUI::DoubleSpinBoxUnitTest::setPrecision() {
    QFETCH(int, precision);
    QFETCH(double, value);
    object->setPrecision(precision);
    QCOMPARE(object->getPrecision(), precision);
    object->setValue(value);
    QCOMPARE(object->getValue(), value);
}

void SUI::DoubleSpinBoxUnitTest::setPrecision_data() {
    QTest::addColumn<int>("precision");
    QTest::addColumn<double>("value");
    QTest::newRow("Test precision 1") << int(5) << double(12.12345);
    QTest::newRow("Test precision 2") << int(12) << double(1.01234567891);
}
