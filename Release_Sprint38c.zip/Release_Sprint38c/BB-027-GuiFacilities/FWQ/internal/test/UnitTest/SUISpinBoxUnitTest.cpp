#include "SUISpinBoxUnitTest.h"
#include "SUIIErrorModeUnitTest.h"
#include "SUIIAlignableUnitTest.h"
#include <QTest>

SUI::SpinBoxUnitTest::SpinBoxUnitTest(SUI::SpinBox *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
    Q_ASSERT(object);
}

void SUI::SpinBoxUnitTest::callInterfaceTests() {
    //IAlignable unit test
    IAlignableUnitTest iAlignableUnitTest(object);
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::HCenter));
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Left));
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Right));
    QCOMPARE(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Stretch), false );

    //IErrorMode
    IErrorModeUnitTest iErrorModeUnitTest(object);
    QVERIFY(iErrorModeUnitTest.setErrorMode());
}

SUI::SpinBoxUnitTest::~SpinBoxUnitTest() {
    delete object;
}
