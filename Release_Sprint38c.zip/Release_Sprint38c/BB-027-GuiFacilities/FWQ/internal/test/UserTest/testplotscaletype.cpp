#include "testplotscaletype.h"

#include <SUIIText.h>
#include <SUIPlotWidget.h>
#include <SUIScaleTypeEnum.h>
#include <SUIDialogImpl.h>
#include <SUIDropDown.h>
#include <SUIINumeric.h>

testPlotScaleType::testPlotScaleType(QString pltWidgetID, QString leftscaleddbID, QString rightscaleddbID, SUI::DialogImpl *apGui) :
    mPlotWidgetID(pltWidgetID),
    mLeftScaleID(leftscaleddbID),
    mRightScaleID(rightscaleddbID),
    mpGui(apGui)
{
}

void testPlotScaleType::handleClicked()
{
    SUI::PlotWidget *plotWidget = mpGui->getObjectList()->getObject<SUI::PlotWidget>(mPlotWidgetID.toStdString());
    SUI::DropDown *dropLeftScale = mpGui->getObjectList()->getObject<SUI::DropDown>(mLeftScaleID.toStdString());
    if (plotWidget && dropLeftScale)
    {
        std::string LeftScaleType = dropLeftScale->getSelectedItems().front();
        SUI::DropDown *dropRightScale = mpGui->getObjectList()->getObject<SUI::DropDown>(mRightScaleID.toStdString());
        if (dropRightScale)
        {
            std::string     RightScaleType = dropRightScale->getSelectedItems().front();
            SUI::ScaleTypeEnum::ScaleType Ltype = SUI::ScaleTypeEnum::Linear;
            SUI::ScaleTypeEnum::ScaleType Rtype = SUI::ScaleTypeEnum::Linear;
            if (!LeftScaleType.compare("Log"))
            {
                Ltype = SUI::ScaleTypeEnum::Logarithmic;
            }
            if (!RightScaleType.compare("Log"))
            {
                Rtype = SUI::ScaleTypeEnum::Logarithmic;
            }
            plotWidget->setScaleType(SUI::PlotAxisEnum::yLeft, Ltype);
            plotWidget->setScaleType(SUI::PlotAxisEnum::yRight, Rtype);
        }
    }
}



testPlotScientificScale::testPlotScientificScale(QString plotWidgetID, QString xMinID, QString xMaxID, QString yLeftMinID, QString yLeftMaxID, QString yRightMinID, QString yRightMaxID, SUI::DialogImpl *apGui) :
    mPlotWidgetID(plotWidgetID),
    mScaleXMinID(xMinID),
    mScaleXMaxID(xMaxID),
    mScaleYLeftMinID(yLeftMinID),
    mScaleYLeftMaxID(yLeftMaxID),
    mScaleYRightMinID(yRightMinID),
    mScaleYRightMaxID(yRightMaxID),
    mpGui(apGui)
{

}

void testPlotScientificScale::handleClicked()
{
    SUI::PlotWidget *plotWidget = mpGui->getObjectList()->getObject<SUI::PlotWidget>(mPlotWidgetID.toStdString());
    SUI::INumeric<double> *widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<double>>(mScaleYLeftMinID.toStdString());
    if (plotWidget && widgetNum)
    {
        double xMin = widgetNum->getValue();
        widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<double>>(mScaleYLeftMaxID.toStdString());
        if (widgetNum) {
            double xMax = widgetNum->getValue();
            plotWidget->setYLeftScale(xMin, xMax);
            widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<double>>(mScaleYRightMinID.toStdString());
            if (widgetNum) {
                xMin = widgetNum->getValue();
                widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<double>>(mScaleYRightMaxID.toStdString());
                if (widgetNum) {
                    xMax = widgetNum->getValue();
                    plotWidget->setYRightScale(xMin, xMax);
                    widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<double>>(mScaleXMinID.toStdString());
                    if (plotWidget && widgetNum) {
                        double xMin = widgetNum->getValue();
                        widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<double>>(mScaleXMaxID.toStdString());
                        if (widgetNum) {
                            double xMax = widgetNum->getValue();
                            plotWidget->setXScale(xMin, xMax);
                        }
                    }
                }
            }
        }
    }
}
