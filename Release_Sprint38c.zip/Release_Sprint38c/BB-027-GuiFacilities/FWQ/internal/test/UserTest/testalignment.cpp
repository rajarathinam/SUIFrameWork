#include "testalignment.h"

#include <SUIAlignmentEnum.h>
#include <SUIIText.h>

#include <SUILabel.h>
#include <SUITableWidgetItem.h>
#include <SUILineEdit.h>
#include <SUIButton.h>
#include <SUITextArea.h>
#include <SUIDialogImpl.h>
#include <SUIDropDown.h>

testAlignment::testAlignment(QString aTargetWidgetID, QString aDropDownText, SUI::DialogImpl *apGui) :
    mTargetWidgetid(aTargetWidgetID),
    mDropDownText(aDropDownText),
    mpGui(apGui)
{
}

void testAlignment::handleClicked()
{
    SUI::AlignmentEnum::Alignment mAlign;
    SUI::DropDown *dropdown = mpGui->getObjectList()->getObject<SUI::DropDown>(mDropDownText.toStdString());

    if (dropdown)
    {
        QString text3 = QString::fromStdString(dropdown->getSelectedItems().front());

        if (text3.toLower() == "right")
        {
            mAlign = SUI::AlignmentEnum::Right;
        }
        else if (text3.toLower() == "center")
        {
            mAlign = SUI::AlignmentEnum::HCenter;
        }
        else
        {
            mAlign = SUI::AlignmentEnum::Left;
        }

        if (mTargetWidgetid.left(3) == "lbl")
        {
            SUI::Label *lbl = mpGui->getObjectList()->getObject<SUI::Label>(mTargetWidgetid.toStdString());
            if (lbl)
            {
                lbl->setAlignment(mAlign);
            }
        }
        else if (mTargetWidgetid.left(3) == "lne")
        {
            SUI::LineEdit *lne = mpGui->getObjectList()->getObject<SUI::LineEdit>(mTargetWidgetid.toStdString());
            if (lne)
            {
                lne->setAlignment(mAlign);
            }
        }
        else if (mTargetWidgetid.left(3) == "btn")
        {
            SUI::Button *btn = mpGui->getObjectList()->getObject<SUI::Button>(mTargetWidgetid.toStdString());
            if (btn)
            {
                btn->setAlignment(mAlign);
            }
        }
        else if (mTargetWidgetid.left(3) == "txa")
        {
            SUI::TextArea *txa = mpGui->getObjectList()->getObject<SUI::TextArea>(mTargetWidgetid.toStdString());
            if (txa)
            {
                txa->setAlignment(mAlign);
            }
        }
        else if (mTargetWidgetid.contains("-taw"))
        {
            SUI::TableWidgetItem *taw = mpGui->getObjectList()->getObject<SUI::TableWidgetItem>(mTargetWidgetid.toStdString());
            if (taw)
            {
                taw->setAlignment(mAlign);
            }
        }
    }
}
