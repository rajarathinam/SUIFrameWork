#ifndef TESTPLOTSETRECTANGLE_H
#define TESTPLOTSETRECTANGLE_H

#include <QString>

namespace SUI {
class DialogImpl;
}

class testPlotSetRectangle
{
public:
    testPlotSetRectangle(QString pltWidgetID, QString IdWidgetID, QString XMinID, QString XMaxID, QString LabelID, QString colorWidgetID,
                          QString orientWidgetID, QString ySideWidgetID, SUI::DialogImpl *apGui);

    void handleCheckedChanged(bool checked);

private:
    QString mPlotWidgetID;
    QString mIdWidgetID;
    QString mXMinID;
    QString mXMaxID;
    QString mLabelID;
    QString mColorWidgetID;
    QString mOrientWidgetID;
    QString mYSideWidgetID;

    SUI::DialogImpl  *mpGui;
};

class testPlotSetRangeRectangle
{
public:
    testPlotSetRangeRectangle(QString pltWidgetID, QString nameWidgetID, QString xWidgetID, QString yWidgetID, QString widthWidgetID,
                               QString heightWidgetID, QString colorWidgetID, QString yaxisWidgetID, QString LabelID, SUI::DialogImpl *apGui);

    void    handleCheckedChanged(bool checked);

private:
    QString     mPlotWidgetID;
    QString     mNameWidgetID;
    QString     mXWidgetID;
    QString     mYWidgetID;
    QString     mWidthWidgetID;
    QString     mHeightWidgetID;
    QString     mColorWidgetID;
    QString     mYAxisWidgetID;
    QString 	mLabelID;
    SUI::DialogImpl      *mpGui;
};

#endif // TESTPLOTSETRECTANGLE_H
