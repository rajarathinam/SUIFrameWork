#ifndef TESTLINEEDITVALIDATION_H
#define TESTLINEEDITVALIDATION_H

#include <QString>

namespace SUI {
class DialogImpl;
}

class testLineEditValidation
{
private:
    QString mWidgetid;
    SUI::DialogImpl  *mpGui;

public:
    testLineEditValidation(QString awidgetID, SUI::DialogImpl *apGui);
    void handleCheckedChanged(bool checked);
    void ValidationFailed();
};

#endif // TESTLINEEDITVALIDATION_H
