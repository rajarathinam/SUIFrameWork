#include "testcheckedhandlercopy.h"

#include <SUIIText.h>

testCheckedHandlerCopy::testCheckedHandlerCopy(QString aIDtextChecked, QString aIDtextUnchecked, QString aIDDestination, SUI::DialogImpl *apGui) :
    mIDChecked(aIDtextChecked),
    mIDUnchecked(aIDtextUnchecked),
    mIDDestination(aIDDestination),
    mpGui(apGui)
{
}

void testCheckedHandlerCopy::handleCheckedChanged(bool checked) {
    std::string text;
    if (checked) {
        SUI::IText *widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mIDChecked.toStdString());
        text = widgetText->getText();
    }
    else {
        SUI::IText *widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mIDUnchecked.toStdString());
        text = widgetText->getText();
    }
    SUI::IText *widget = mpGui->getObjectList()->getObject<SUI::IText>(mIDDestination.toStdString());
    widget->setText(text);
}
