#include "GraphicsSceneMouseEventTest.h"

#include <SUILabel.h>
#include <SUIDialogImpl.h>
#include <SUIGraphicsSceneMouseEvent.h>

#include <assert.h>

GraphicsSceneMouseEventTest::GraphicsSceneMouseEventTest(SUI::Dialog *dialog) :
    labelLeftClick(dialog->getObjectList()->getObject<SUI::Label>("lbl398")),
    labelMiddleClick(dialog->getObjectList()->getObject<SUI::Label>("lbl923")),
    labelRightClick(dialog->getObjectList()->getObject<SUI::Label>("lbl924")),
    labelUnknownClick(dialog->getObjectList()->getObject<SUI::Label>("lbl931")),
    labelLeftRelease(dialog->getObjectList()->getObject<SUI::Label>("lbl936")),
    labelMiddleRelease(dialog->getObjectList()->getObject<SUI::Label>("lbl935")),
    labelRightRelease(dialog->getObjectList()->getObject<SUI::Label>("lbl934")),
    labelUnknownRelease(dialog->getObjectList()->getObject<SUI::Label>("lbl933")),
    labelLeftMovePress(dialog->getObjectList()->getObject<SUI::Label>("lbl927")),
    labelMiddleMovePress(dialog->getObjectList()->getObject<SUI::Label>("lbl928")),
    labelRightMovePress(dialog->getObjectList()->getObject<SUI::Label>("lbl929")),
    labelUnknownMovePress(dialog->getObjectList()->getObject<SUI::Label>("lbl932")),
    labelMove(dialog->getObjectList()->getObject<SUI::Label>("lbl930")),
    labelWheel(dialog->getObjectList()->getObject<SUI::Label>("lbl690"))
{
    assert(labelLeftClick);
    assert(labelMiddleClick);
    assert(labelRightClick);
    assert(labelUnknownClick);
    assert(labelLeftRelease);
    assert(labelMiddleRelease);
    assert(labelRightRelease);
    assert(labelUnknownRelease);
    assert(labelLeftMovePress);
    assert(labelMiddleMovePress);
    assert(labelRightMovePress);
    assert(labelUnknownMovePress);
    assert(labelMove);
    assert(labelWheel);
}

void GraphicsSceneMouseEventTest::mouseMoveEvent(const boost::shared_ptr<SUI::GraphicsSceneMouseEvent> &event) {
    QString message("(x: %1, y: %2) \nMousePressMove %3 Button");
    switch (event->getButton())
    {
    case SUI::MouseButton::Left:
        labelLeftMovePress->setText(message.arg(QString::number(event->getScenePosX())).arg(QString::number(event->getScenePosY())).arg("Left").toStdString());
        break;
    case SUI::MouseButton::Right:
        labelRightMovePress->setText(message.arg(QString::number(event->getScenePosX())).arg(QString::number(event->getScenePosY())).arg("Right").toStdString());
        break;
    case SUI::MouseButton::Middle:
        labelMiddleMovePress->setText(message.arg(QString::number(event->getScenePosX())).arg(QString::number(event->getScenePosY())).arg("Middle").toStdString());
        break;
    case SUI::MouseButton::NoButton:
        QString message("(x: %1, y: %2) - Mouse Moved");
        labelMove->setText(message.arg(QString::number(event->getScenePosX())).arg(QString::number(event->getScenePosY())).toStdString());
        break;
    }
}

void GraphicsSceneMouseEventTest::mouseClickEvent(const boost::shared_ptr<SUI::GraphicsSceneMouseEvent> &event) {
    QString message("(x: %1, y: %2) \nMouse Click %3 Button");
    switch (event->getButton())
    {
    case SUI::MouseButton::Left:
        labelLeftClick->setText(message.arg(QString::number(event->getScenePosX())).arg(QString::number(event->getScenePosY())).arg("Left").toStdString());
        break;
    case SUI::MouseButton::Right:
        labelRightClick->setText(message.arg(QString::number(event->getScenePosX())).arg(QString::number(event->getScenePosY())).arg("Right").toStdString());
        break;
    case SUI::MouseButton::Middle:
        labelMiddleClick->setText(message.arg(QString::number(event->getScenePosX())).arg(QString::number(event->getScenePosY())).arg("Middle").toStdString());
        break;
    case SUI::MouseButton::NoButton:
        labelUnknownClick->setText(message.arg(QString::number(event->getScenePosX())).arg(QString::number(event->getScenePosY())).arg("NoButton").toStdString());
        break;
    }
}

void GraphicsSceneMouseEventTest::mouseReleaseEvent(const boost::shared_ptr<SUI::GraphicsSceneMouseEvent> &event) {
    QString message("(x: %1, y: %2) \nMouseRelease %3 Button");
    switch (event->getButton())
    {
    case SUI::MouseButton::Left:
        labelLeftRelease->setText(message.arg(QString::number(event->getScenePosX())).arg(QString::number(event->getScenePosY())).arg("Left").toStdString());
        break;
    case SUI::MouseButton::Right:
        labelRightRelease->setText(message.arg(QString::number(event->getScenePosX())).arg(QString::number(event->getScenePosY())).arg("Right").toStdString());
        break;
    case SUI::MouseButton::Middle:
        labelMiddleRelease->setText(message.arg(QString::number(event->getScenePosX())).arg(QString::number(event->getScenePosY())).arg("Middle").toStdString());
        break;
    case SUI::MouseButton::NoButton:
        labelUnknownRelease->setText(message.arg(QString::number(event->getScenePosX())).arg(QString::number(event->getScenePosY())).arg("NoButton").toStdString());
        break;
    }
}

void GraphicsSceneMouseEventTest::mouseWheelEvent(const boost::shared_ptr<SUI::GraphicsSceneMouseEvent> &event) {
    QString eventDescription("MouseWheel Unknown");
    switch (event->getWheelDirection())
    {
    case SUI::Up: eventDescription = "MouseWheel Up"; break;
    case SUI::Down: eventDescription = "MouseWheel Down"; break;
    default: break;
    }

    QString message = eventDescription.append("(x: %1, y: %2) - %3 Button Pressed");
    switch (event->getButton())
    {
    case SUI::MouseButton::Left:
        labelWheel->setText(message.arg(QString::number(event->getScenePosX())).arg(QString::number(event->getScenePosY())).arg("Left").toStdString());
        break;
    case SUI::MouseButton::Right:
        labelWheel->setText(message.arg(QString::number(event->getScenePosX())).arg(QString::number(event->getScenePosY())).arg("Right").toStdString());
        break;
    case SUI::MouseButton::Middle:
        labelWheel->setText(message.arg(QString::number(event->getScenePosX())).arg(QString::number(event->getScenePosY())).arg("Middle").toStdString());
        break;
    case SUI::MouseButton::NoButton:
        labelWheel->setText(message.arg(QString::number(event->getScenePosX())).arg(QString::number(event->getScenePosY())).arg("NoButton").toStdString());
        break;
    }
}
