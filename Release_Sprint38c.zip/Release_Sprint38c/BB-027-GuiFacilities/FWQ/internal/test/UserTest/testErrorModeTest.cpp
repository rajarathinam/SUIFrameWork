#include "testErrorModeTest.h"

#include <SUIIErrorMode.h>
#include <SUIDialogImpl.h>
#include <SUIDropDown.h>

testErrorMode::testErrorMode(QString aDropdown, QString aWidget, SUI::DialogImpl *apGui) :
    mDropdown(aDropdown),
    mWidgetid(aWidget),
    mpGui(apGui)
{
    std::list<std::string> errorModeList = SUI::ErrorModeEnum::getErrorModeStringList();

    SUI::DropDown *dropdown = mpGui->getObjectList()->getObject<SUI::DropDown>(mDropdown.toStdString());
    dropdown->clearItems();

    dropdown->addItems(errorModeList);
}

void testErrorMode::onSelectionChanged()
{
    SUI::IErrorMode *errorWidget = mpGui->getObjectList()->getObject<SUI::IErrorMode>(mWidgetid.toStdString());
    SUI::DropDown *dropdown = mpGui->getObjectList()->getObject<SUI::DropDown>(mDropdown.toStdString());
    if (errorWidget)
    {
        std::string errorModeText = dropdown->getCurrentText();
        SUI::ErrorModeEnum::ErrorMode errorMode = SUI::ErrorModeEnum::fromString(errorModeText);
        errorWidget->setMode(errorMode);
    }
}

void testErrorMode::onOverViewErrorMode(bool checked)
{
    SUI::IErrorMode *dSpinBox = mpGui->getObjectList()->getObject<SUI::IErrorMode>("dsb606");
    SUI::IErrorMode *iSpinBox = mpGui->getObjectList()->getObject<SUI::IErrorMode>("isb607");
    SUI::IErrorMode *sSpinBox = mpGui->getObjectList()->getObject<SUI::IErrorMode>("ssb608");
    SUI::IErrorMode *textArea = mpGui->getObjectList()->getObject<SUI::IErrorMode>("txa621");
    SUI::IErrorMode *lineEdit = mpGui->getObjectList()->getObject<SUI::IErrorMode>("lne19");
    SUI::IErrorMode *dropDown = mpGui->getObjectList()->getObject<SUI::IErrorMode>("ddb610");

    dSpinBox->setMode(checked ? SUI::ErrorModeEnum::Error : SUI::ErrorModeEnum::Ok);
    iSpinBox->setMode(checked ? SUI::ErrorModeEnum::Error : SUI::ErrorModeEnum::Ok);
    sSpinBox->setMode(checked ? SUI::ErrorModeEnum::Error : SUI::ErrorModeEnum::Ok);
    textArea->setMode(checked ? SUI::ErrorModeEnum::Error : SUI::ErrorModeEnum::Ok);
    lineEdit->setMode(checked ? SUI::ErrorModeEnum::Error : SUI::ErrorModeEnum::Ok);
    dropDown->setMode(checked ? SUI::ErrorModeEnum::Error : SUI::ErrorModeEnum::Ok);
}

