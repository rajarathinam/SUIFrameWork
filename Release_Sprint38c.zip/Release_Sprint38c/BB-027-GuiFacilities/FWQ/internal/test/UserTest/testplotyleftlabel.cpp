#include "testplotyleftlabel.h"

#include <SUIIText.h>
#include <SUIPlotWidget.h>
#include <SUIDialogImpl.h>

testPlotYLeftLabel::testPlotYLeftLabel(QString pltWidgetID, QString YLabelWidgetID, SUI::DialogImpl *apGui) :
    mPlotWidgetID(pltWidgetID),
    mYLabelWidgetID(YLabelWidgetID),
    mpGui(apGui)
{
}

void testPlotYLeftLabel::handleClicked()
{
    SUI::PlotWidget *plotWidget = mpGui->getObjectList()->getObject<SUI::PlotWidget>(mPlotWidgetID.toStdString());
    SUI::IText *widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mYLabelWidgetID.toStdString());
    if (plotWidget && widgetText)
    {
        std::string yLabel = widgetText->getText();
        plotWidget->setYLeftLabel(yLabel);
    }
}
