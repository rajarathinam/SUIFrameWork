#ifndef TESTCHECKEDHANDLERVISIBLE_H
#define TESTCHECKEDHANDLERVISIBLE_H

#include <SUIDialogImpl.h>

class testCheckedHandlerVisible
{
    QString mWidgetID;
    SUI::DialogImpl  *mpGui;
public:

    testCheckedHandlerVisible(QString aWidgetID, SUI::DialogImpl *apGui);
    void handleCheckedChanged(bool checked);
};

#endif // TESTCHECKEDHANDLERVISIBLE_H
