#include "testclickedhandler.h"

#include <SUIIText.h>
#include <SUIUserControl.h>

testClickedhandler::testClickedhandler(QString awidgetID, QString bwidgetID, SUI::DialogImpl *apGui) :
    mWidgetid(awidgetID),
    mLneWidgetid(bwidgetID),
    mpGui(apGui)
{
}

testHoveredhandler::testHoveredhandler(QString awidgetID, QString bwidgetID, SUI::DialogImpl *apGui) :
    mWidgetid(awidgetID),
    mLneWidgetid(bwidgetID),
    mpGui(apGui)
{
}


void  testClickedhandler::handleClicked()
{
    SUI::IText *lneWidget = mpGui->getObjectList()->getObject<SUI::IText>(mLneWidgetid.toStdString());
    if (lneWidget)
    {
        lneWidget->clearText();
        std::string text = mWidgetid.toStdString();
        text.append(" button clicked");
        lneWidget->setText(text);
    }
}

void testClickedhandler::userhandleClicked()
{
    SUI::IText *lneWidget = mpGui->getObjectList()->getObject<SUI::IText>(mLneWidgetid.toStdString());
    if (lneWidget)
    {
        lneWidget->setText("User control clicked");
    }
}

void testHoveredhandler::hoverEntered()
{
    SUI::IText *lneWidget = mpGui->getObjectList()->getObject<SUI::IText>(mLneWidgetid.toStdString());
    if (lneWidget)
    {
        lneWidget->setText("hover Entered");
    }
}
void testHoveredhandler::hoverLeft()
{
    SUI::IText *lneWidget = mpGui->getObjectList()->getObject<SUI::IText>(mLneWidgetid.toStdString());
    if (lneWidget)
    {
        lneWidget->setText("hover Left");
    }
}
