/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxITS_Test.cpp
| Author       : Thijs Jacobs
| Description  : Test application for IGSxITS library
|
| ! \file        IGSxKPI_Test.cpp
| ! \brief       Test application for IGSxITS library
|
|-----------------------------------------------------------------------------|
|                                                                             |
|                Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <iostream>
#include <boost/bind.hpp>

#include <SUIExternalEventHandler.h>
#include <SUIApplication.h>
#include <SUITimer.h>

#include "IGSxLOG.hpp"
#include "IGSxApplication.hpp"
#include "IGSxITS.hpp"

#include <unistd.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
using namespace IGSxITS;

/*----------------------------------------------------------------------------|
|                                     Implementation                                    |
|----------------------------------------------------------------------------*/
class CallbackHandler
{
public:
    CallbackHandler() : m_completed(false) {}
    virtual ~CallbackHandler() {}

    void on_initializeSystemCompleted() {
        std::cout << "Initialize system completed" << std::endl;
        m_completed = true;
    }

    void on_terminateSystemCompleted() {
        std::cout << "Terminate system completed" << std::endl;
        m_completed = true;
    }

    void on_driverStatusChanged(const std::string& driver, const DriverStatus& status) {
        std::cout << "New state of driver " << driver << ": " << DriverState::toString(status.driverState()) << std::endl;
    }

private:
    bool m_completed;
};

int main(int argc, char *argv[])
{
    IGS::LogLevel = IGS::LOG_LEVEL_DEBUG;
    boost::shared_ptr<SUI::Application> app = SUI::Application::createApplication(argc,argv);
    InitTerminate* it = InitTerminate::getInstance();

    // retrieve system functions and drivers
    std::cout << std::endl << "System functions:" << std::endl;
    std::cout << "sysfun name;sysfun description" << std::endl;

    MetaDescriptions sysfuns = it->getSysfuns();
    for (unsigned i = 0; i < sysfuns.size(); i++)
    {
        std::cout << sysfuns[i].name() << ";" << sysfuns[i].description() << std::endl;
    }

    std::cout << std::endl << "Drivers:" << std::endl;
    std::cout << "sysfun name;driver name;driver description;driver state;is executing long action" << std::endl;

    for (unsigned i = 0; i < sysfuns.size(); i++)
    {
        MetaDescriptions drivers = it->getDrivers(sysfuns[i].name());
        for (unsigned j = 0; j < drivers.size(); j++)
        {
            DriverStatus status = it->getDriverStatus(drivers[j].name());
            std::cout << sysfuns[i].name() << ";" << drivers[j].name() << ";" << drivers[j].description() << ";"
                << DriverState::toString(status.driverState()) << ";" << (status.isExecutingLongAction() ? "true" : "false") << std::endl;
        }
    }

    // initialize and terminate the system
    CallbackHandler cbHandler;
    it->subscribeToDriverStatusChanged(boost::bind(&CallbackHandler::on_driverStatusChanged, &cbHandler, _1, _2));

    std::cout << std::endl << "System initialization:" << std::endl;
    it->initializeSystem(boost::bind(&CallbackHandler::on_initializeSystemCompleted, &cbHandler));

    std::cout << std::endl << "System termination:" << std::endl;
    it->terminateSystem(boost::bind(&CallbackHandler::on_terminateSystemCompleted, &cbHandler));

    return app->exec();
}

