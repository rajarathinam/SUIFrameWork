//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for FileController.
// !\description Class implementation file for FileController.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "FileController.h"

#include <QFileInfo>
#include <QTemporaryFile>
#include <QDir>
#include <QString>
#include <QFileDialog>
#include <QTimer>
#include <QApplication>
#include <QAction>
#include <QSettings>
#include <QDateTime>
#include <QMenu>

#include <FWQxCore/SUIUILoader.h>
#include <FWQxWidgets/SUIDialog.h>
#include <FWQxWidgets/SUIMessageBox.h>
#include <SUILegacyXMLConverter.h>
#include <SUIDialogSerializer.h>
#include <SUITabWidgetImpl.h>
#include <FWQxCore/SUIXmlException.h>
#include <FWQxCore/SUIIOException.h>

#include "SUISourceCodeGenerator.h"

#include "UndoHandler.h"
#include "Model.h"
#include "formeditor.h"
#include "usercontrolselector.h"

QString FileController::SUI_FILE_EXTENSION = ".xml";
QString FileController::TEMP_FILE_EXTENSION = ".save";
QString FileController::TEMP_FILE_TEMPLATE = "_tmp_sui_XXXXXX";

QString FileController::MAINWINDOW_TITLE_TEMPLATE = QString("%1 - SUIObject version: %2 - SUIEditor version:%3 - File: %4 [*]");

FileController::FileController() :
    QObject(NULL),
    formEditor(NULL),
    userControlSelector(NULL),
    fileMenu(NULL),
    settings(NULL),
    saveTimerId(-1),
    mBackupTempFile(new QTemporaryFile)
{
    connect(this,SIGNAL(fileSaved()),this,SLOT(onFileLoaded()));
}

void FileController::initialize(FormEditor *editor, UserControlSelector *selector, QMenu *menu, QSettings *qsettings) {
    formEditor = editor;
    userControlSelector = selector;
    fileMenu = menu;
    settings = qsettings;

    // set the recent file actions
    for (int i = 0; i < MaxRecentFiles; i++) {
        recentFileActions[i] = new QAction(this);
        recentFileActions[i]->setVisible(false);
        connect(recentFileActions[i], SIGNAL(triggered()), this, SLOT(onRecentFileActionTriggered()));
    }

    // check for arguments
    QStringList arguments = QApplication::arguments();
    for (int i = 1; i < arguments.count(); i++) {
        if (arguments.at(i).left(2) == "-i") {
            if (arguments.at(i).length() > 2) mFileName = arguments.at(i).right(arguments.at(i).length() - 2);
            else if (arguments.count() >= (i + 1)) mFileName = arguments.at(i + 1);
        }
    }

    //  Look for existing backup files
    QDir tempDir(QDir::tempPath());
    QStringList fileList = tempDir.entryList(QStringList("*_tmp_sui_*.save"), QDir::Files | QDir::Hidden | QDir::NoSymLinks, QDir::Time);
    // if the fileList is not empty, try to restore the backup file
    if (!fileList.isEmpty()) {
        QString backupFileName = fileList.at(0);
        if (!mFileName.isEmpty()) {
            QString findFileName = mFileName;
            findFileName.remove(SUI_FILE_EXTENSION);
            foreach (const QString &file, fileList) {
                if (file.contains(findFileName)) {
                    backupFileName = file;
                    break;
                }
            }
        }
        backupFileName = QString("%1%2%3").arg(QDir::tempPath()).arg(QDir::separator()).arg(backupFileName);
        QString restoreFileName = getBaseName(backupFileName).append(SUI_FILE_EXTENSION);

        QFileInfo restoreFileInfo = QFileInfo(restoreFileName);
        QString msg;
        SUI::StandardButtonEnum::Button defaultButton = SUI::StandardButtonEnum::Yes;
        if (backupFileName.contains("_tmp_sui_")) {
            msg = QString("A backup file '%1' was found. Do you want to restore this file?").arg(backupFileName);
        }
        else {
            if (!restoreFileInfo.exists()) {
                msg = QString("A backup file for '%1' was found. Do you want to restore this file?").arg(restoreFileName);
            }
            else {
                QFileInfo backupFileInfo = QFileInfo(backupFileName);
                if (restoreFileInfo.lastModified() > backupFileInfo.lastModified()) {
                    msg = QString("A backup file for '%1' was found, but the backup file is older than the original file.\n"
                                  "Do you want to restore this backup file?\n"
                                  "Restoring the backup file will override the original file!").arg(restoreFileName);
                    defaultButton = SUI::StandardButtonEnum::No;
                }
                else {
                    msg = QString("A backup file for '%1' was found and is newer than the original file.\nDo you want to restore this file?")
                            .arg(restoreFileName);
                }
            }
        }

        int answer = SUI::MessageBox::warning(NULL, QApplication::applicationName().toStdString(), msg.toStdString(), SUI::StandardButtonEnum::Yes | SUI::StandardButtonEnum::No, defaultButton);
        switch (answer) {
        case SUI::StandardButtonEnum::Yes:
            if (restoreFileName == "backup.xml") {
                if (!mFileName.isEmpty()) {
                    QFile::remove(mFileName);
                }
                mFileName = restoreFileName;
                save(mFileName);
            }
            else {
                mFileName = restoreFileName;
            }
            if (restoreFileInfo.exists()) {
                QFile::remove(restoreFileName);
            }
            QFile::rename(backupFileName, mFileName);
            openFile(mFileName);
            mFileName = "";
            break;
        default:
            answer = SUI::MessageBox::question(NULL, QApplication::applicationName().toStdString(), tr("Do you want to remove this backup file '%1' ?").arg(backupFileName).toStdString(),
                                           SUI::StandardButtonEnum::Yes | SUI::StandardButtonEnum::No, SUI::StandardButtonEnum::No);
            if (answer == SUI::StandardButtonEnum::Yes) {
                QFile::remove(backupFileName);
            }
            break;
        }
    }

    saveTimerId = QObject::startTimer(SaveTimerInterval);
    UndoHandler::instance()->block(false);

}

FileController::~FileController()
{
    for (int i = 0; i < MaxRecentFiles; i++) {
        recentFileActions[i]->deleteLater();
    }

    if (mBackupTempFile) {
        mBackupTempFile->deleteLater();
    }
}

FileController *FileController::instance() {
    static FileController mInstance;
    return &mInstance;
}

void FileController::generateSourceCode(const QString &fileName) {
    SUI::Dialog *dialog = SUI::UILoader::loadUI(fileName.toStdString());
    SUI::SourceCodeGenerator::dialogToSource(fileName,dialog);
    delete dialog;
    dialog = NULL;
}

void FileController::importUserControl(const QString &fileName) {
    if (SUI::LegacyXMLConverter::isLegacy(fileName)) {
        SUI::LegacyXMLConverter::convertLegacyXmlFile(fileName, fileName);
    }
    formEditor->readInclude(fileName);
}

void FileController::resetBackupFile(const QString &fileName) {
    deleteBackupFile();

    QString tempFileTemplate = getBaseName(fileName).append(TEMP_FILE_TEMPLATE).append(TEMP_FILE_EXTENSION);

    if (!tempFileTemplate.contains(QDir::tempPath())) {
        tempFileTemplate = tempFileTemplate.prepend(QDir::separator()).prepend(QDir::tempPath());
    }
    mBackupTempFile->setFileTemplate(tempFileTemplate);
    mBackupTempFile->setAutoRemove(false);

    if (!mBackupTempFile->open()) {
        SUI::MessageBox::critical(NULL,"Error",std::string("Could not open tempfile: ").append(mBackupTempFile->fileName().toStdString()).append(" - ").append(tempFileTemplate.toStdString()));
    }
    assert(mBackupTempFile->exists());
}

void FileController::deleteBackupFile() {
    if (mBackupTempFile->exists()) {
        if (mBackupTempFile->isOpen()) {
            mBackupTempFile->close();
        }
        mBackupTempFile->setAutoRemove(true);
        mBackupTempFile->deleteLater();
        mBackupTempFile = new QTemporaryFile();
    }
}

QString FileController::getBaseName(QString fileName) {
    fileName = QFileInfo(fileName).baseName();
    if (fileName.contains("_tmp_sui_")) {
        QRegExp fileNameRegex("([^*]+)(_tmp_sui_*)");
        fileNameRegex.indexIn(fileName);
        fileName = fileNameRegex.capturedTexts().at(1);
        fileName = fileName.split(QDir::separator()).last();
    }
    return fileName;
}

void FileController::openFile(QString fileName) {
    if (SUI::LegacyXMLConverter::isLegacy(fileName)) {
        SUI::LegacyXMLConverter::convertLegacyXmlFile(fileName, fileName);
        emit statusMessage(QString("File %1 was converted to the new format").arg(fileName),5000);
    }

    UndoHandler::instance()->clearBuffer();
    foreach(WidgetController * wcChild, formEditor->childList()) {
        wcChild->close();
        wcChild->deleteLater();
    }
    formEditor->clearChildList();
    formEditor->reset();
    Model::instance()->reset();
    userControlSelector->clear();
    userControlSelector->init();

    emit loadProperties(NULL);
    loadFile(fileName);
}

void FileController::save(QString fileName) {

    if (fileName.isEmpty()) {
        saveAs();
    }
    else {
        SUI::DialogSerializer mySerializer("SUI", SUI::DialogSerializer::Write);
        try
        {
            mySerializer.openFile(fileName);
            formEditor->acceptVisitor(mySerializer);
            mySerializer.closeFile();
            if (fileName == mFileName) {
                if (!mFileName.isEmpty()) {
                    QFileInfo fi(mFileName);
                    if (!mFileName.contains("_tmp_sui_")) {
                        emit changeWindowTitle(
                                    QString(MAINWINDOW_TITLE_TEMPLATE)
                                    .arg(QApplication::applicationName())
                                    .arg(QString::fromStdString(FormEditor::getVersion().toString()))
                                    .arg(QString::fromStdString(FormEditor::getEditorVersion().toString()))
                                    .arg(fi.fileName()));
                    }
                    generateSourceCode(fileName);
                }
                UndoHandler::instance()->setCurrentSaved();
                emit fileSaved();
            }
        }
        catch (SUI::XmlException *re)
        {
            SUI::MessageBox::warning(NULL,"XmlException", re->getExceptionMessage());
        }
        catch (SUI::IOException *re)
        {
            SUI::MessageBox::warning(NULL,"IOException", re->getExceptionMessage());
        }
    }
    if (!fileName.contains("_tmp_sui_")) {
        Model::instance()->setDataChanged(false);
    }
}

void FileController::saveAs() {
    QString filename = QFileDialog::getSaveFileName(formEditor, tr("Save XML file"), "", tr("XML Files (*.xml)"));
    if (!filename.isEmpty()) {
        if (filename.right(4) != SUI_FILE_EXTENSION) filename.append(SUI_FILE_EXTENSION);
        mFileName = filename;
        save(mFileName);
    }
}

void FileController::setCurrentFile(const QString &fileName) {
    QString curFile = fileName;
    formEditor->parentWidget()->setWindowFilePath(curFile);

    if(!fileName.contains(QDir::tempPath(), Qt::CaseInsensitive)) {
        QStringList files = settings->value("recentFileList").toStringList();
        files.removeAll(fileName);
        files.prepend(fileName);
        while (files.size() > MaxRecentFiles) {
            files.removeLast();
        }
        settings->setValue("recentFileList", files);
    }
    updateRecentFileActions();
}

void FileController::loadFile(QString filename) {
    QObject::killTimer(saveTimerId);

    emit startWidgetProcess(0);

    QString message;
    int dWidgetCount = 0;
    if (filename.isEmpty()) return;

    if (!filename.contains("_tmp_sui_")) mFileName = filename;

    SUI::DialogSerializer mySerializer("SUI", SUI::DialogSerializer::Read);

    message = QString("Reading file %1").arg(mFileName);
    Model::instance()->callNewMessage(message);

    // Remove all current widgets
    QList<WidgetController *> children = formEditor->childList();
    formEditor->clearChildList();
    foreach(WidgetController * child, children) {
        child->close();
        child->deleteLater();
    }
    userControlSelector->clear();
    userControlSelector->init();
    QApplication::processEvents();

    WidgetDefinition mainWidget;

    // Stop rebuilding the Object TreeView for every new Widget being read from the input file.
    emit disableShowProperties(__FUNCTION__);
    try
    {
        mySerializer.openFile(mFileName);
        mySerializer.acceptVisitor(mainWidget);
        dWidgetCount = mySerializer.getWidgetCount();
        Model::instance()->callSetWidgetCount(dWidgetCount);
    }
    catch (SUI::XmlException *re)
    {
        SUI::MessageBox::warning(NULL,"XmlException", re->getExceptionMessage());
        return;
    }
    catch (SUI::IOException *re)
    {
        SUI::MessageBox::warning(NULL,"IOException", re->getExceptionMessage());
        return;
    }
    mySerializer.closeFile();

    Model::instance()->reset();
    formEditor->setPropertyValue(SUI::ObjectPropertyTypeEnum::HasRightButtonBar, "false");
    formEditor->setPropertyValue(SUI::ObjectPropertyTypeEnum::HasBottomButtonBar, "false");
    formEditor->setPropertyValue(SUI::ObjectPropertyTypeEnum::HasStatusBar, "false");

    if (!mainWidget.getPropertyTypes().contains(SUI::ObjectPropertyTypeEnum::SUIDescription)) {
        emit fillObjectTree();
        emit loadProperties(NULL);
        SUI::MessageBox::warning(NULL,"Wrong File Format", "The file doesn't have the right format");
        return;
    }

    //  Read all necessary UserControl Files
    message = QString("Reading UserControls");
    Model::instance()->callNewMessage(message);

    foreach(const QString &include, mainWidget.getIncludes().keys()) {
        const QString fName = mainWidget.getIncludes().value(include);
        const QString fullFileName =  QString("%1%2%3").arg(QFileInfo(filename).absolutePath()).arg(QDir::separator()).arg(fName);
        formEditor->setInclude(include,fName);
        formEditor->readInclude(fullFileName);
    }

    message = QString("Processing all widgets ...");
    Model::instance()->callNewMessage(message);

    // Set the form size as read from the XML file
    formEditor->setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, mainWidget.getPropertyValue(SUI::ObjectPropertyTypeEnum::Width));
    formEditor->setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, mainWidget.getPropertyValue(SUI::ObjectPropertyTypeEnum::Height));
    formEditor->setPropertyValue(SUI::ObjectPropertyTypeEnum::SUIStyleSheet, mainWidget.getPropertyValue(SUI::ObjectPropertyTypeEnum::SUIStyleSheet));

    foreach(WidgetDefinition * childWidget, mainWidget.mChildren) {
        WidgetController *wcChild = childWidget->addToWidget(formEditor, false);
        if (!wcChild) {
            SUI::MessageBox::critical(NULL,QApplication::applicationName().toStdString(), tr("Error processing ui file %1").arg(mFileName).toStdString());
            emit finishWidgetProcess();
            return;
        }
        QString id = wcChild->getId();
        if (id == "rbbStatus") {
            Model::instance()->setStatusBar(wcChild);
            formEditor->setPropertyValue(SUI::ObjectPropertyTypeEnum::HasStatusBar, "true");
        }
        else if (id == "rbbBottom") {
            Model::instance()->setBottomButtonBar(wcChild);
            formEditor->setPropertyValue(SUI::ObjectPropertyTypeEnum::HasBottomButtonBar, "true");
        }
        else if (id == "rbbRight") {
            Model::instance()->setRightButtonBar(wcChild);
            formEditor->setPropertyValue(SUI::ObjectPropertyTypeEnum::HasRightButtonBar, "true");
        }
        else if (id == "splFormStatus") {
            if (Model::instance()->getWidgetController("txaStatus")) {
                Model::instance()->setStatusTextArea(Model::instance()->getWidgetController("txaStatus"));
            }
            formEditor->setPropertyValue(SUI::ObjectPropertyTypeEnum::HasStatusBar, "true");
        }
    }

    emit finishWidgetProcess();

    message = QString("Initializing ...");
    Model::instance()->callNewMessage(message);
    formEditor->setGeometry(
                formEditor->pos().x(),
                formEditor->pos().y(),
                formEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt(),
                formEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt());

    formEditor->setFixedSize(
                formEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt(),
                formEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt());

    userControlSelector->initUserControls();

    // The tabwidget must be painted and the first tab must be shown
    WidgetController *tabWidg = Model::instance()->getMainTabWidget();
    if (tabWidg)
    {
        tabWidg->setPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable, "false");
        tabWidg->setPropertyValue(SUI::ObjectPropertyTypeEnum::Sizeable, "false");
        dynamic_cast<SUI::TabWidgetImpl *>(tabWidg->getBaseWidget())->setCurrentTabPage(tabWidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::CurrentTabPage).toInt());
        tabWidg->updatePixmap();
    }
    WidgetController *topPage = Model::instance()->getCurrentTopPage();
    WidgetController *topTab = topPage->getParent();
    Model::instance()->selectNewWidget(topPage->getId());
    Model::instance()->setNewSelected(topTab);

    if (Model::instance()->getWidgetController("btnClose")) {
        Model::instance()->setCloseButton(Model::instance()->getWidgetController("btnClose"));
    }
    if (Model::instance()->getWidgetController("btnHelp")) {
        Model::instance()->setHelpButton(Model::instance()->getWidgetController("btnHelp"));
    }
    if (Model::instance()->getWidgetController("splFormStatus")) {
        Model::instance()->selectNewWidget("splFormStatus");
        Model::instance()->setNewSelected(Model::instance()->getWidgetController("splFormStatus"));
    }

    // Build the Object TreeView now all Widgets have been added, deselect all widgets and enable the fillObjectTree SLOT again.
    message = QString("Building object tree ...");
    Model::instance()->callNewMessage(message);
    emit fillObjectTree();
    Model::instance()->setNewSelected(Model::instance()->getTopWidget());
    emit enableShowProperties(__FUNCTION__);

    QFileInfo fi(mFileName);
    if (!mFileName.contains("_tmp_sui_")) {
        emit changeWindowTitle(
                    QString(MAINWINDOW_TITLE_TEMPLATE)
                    .arg(QApplication::applicationName())
                    .arg(QString::fromStdString(FormEditor::getVersion().toString()))
                    .arg(QString::fromStdString(FormEditor::getEditorVersion().toString()))
                    .arg(fi.fileName()));
    }
    if (!Model::instance()->getBottomButtonBar()) emit enableStandardButtonArea(false);

    Model::instance()->getCurrentTopPage()->addToTaborder();
    formEditor->setGridPixmap();

    setCurrentFile(mFileName);
    resetBackupFile(mFileName);
    resetRecentFilesMenu();

    emit statusMessage("Ready ...", 2000);

    if (!mFileName.contains("_tmp_sui_")) {
        Model::instance()->setDataChanged(false);
        emit changeWindowTitle(
                    QString(MAINWINDOW_TITLE_TEMPLATE)
                    .arg(QApplication::applicationName())
                    .arg(QString::fromStdString(FormEditor::getVersion().toString()))
                    .arg(QString::fromStdString(FormEditor::getEditorVersion().toString()))
                    .arg(filename));
    }

    // dirty fix, Model::instance()->setDataChanged(true) is called after this function while it should be false.
    // idealy this should be removed along with the onFileLoaded slot because Model::instance()->setDataChanged(false) is called a couple of lines before this line

    QTimer::singleShot(200,this,SLOT(onFileLoaded()));
}

void FileController::updateRecentFileActions() {
    QStringList files = settings->value("recentFileList").toStringList();
    int numRecentFiles = qMin(files.size(), (int)MaxRecentFiles);
    int nrValidFiles = 0;

    for (int i = 0; i < numRecentFiles; ++i) {
        // Check for exising files. If not exitsing (probably a temp file) don't add to recent file list on UI
        if(QFileInfo(files[i]).exists()) {
            QString text = tr("&%1 %2").arg(nrValidFiles + 1).arg(QFileInfo(files[i]).fileName());
            recentFileActions[i]->setText(text);
            recentFileActions[i]->setData(files[i]);
            recentFileActions[i]->setVisible(true);
            nrValidFiles++;
        }
        else {
            recentFileActions[i]->setVisible(false);
        }
    }
    for (int j = nrValidFiles; j < MaxRecentFiles; ++j) {
        recentFileActions[j]->setVisible(false);
    }
}

void FileController::onRecentFileActionTriggered() {
    UndoHandler::instance()->block(true);
    if (saveDialog()) {
        QAction *action = qobject_cast<QAction *>(sender());
        if (action) {
            openFile(action->data().toString());
        }
    }
    UndoHandler::instance()->block(false);
}

void FileController::onFileLoaded() {
    Model::instance()->setDataChanged(false);
    setDataChanged(false);
    deleteBackupFile();
    saveTimerId = QObject::startTimer(SaveTimerInterval);
}

bool FileController::saveDialog() {
    bool returnValue = true;
    QObject::killTimer(saveTimerId);

    if (Model::instance()->dataChanged()) {
        SUI::StandardButtonEnum::Button resBtn =
                SUI::MessageBox::question(
                    NULL,
                    QApplication::applicationName().toStdString(),
                    tr("Do you want to save your changes?\n").toStdString(),
                    SUI::StandardButtonEnum::Cancel | SUI::StandardButtonEnum::No | SUI::StandardButtonEnum::Yes,
                    SUI::StandardButtonEnum::Yes);
        switch (resBtn)
        {
        case SUI::StandardButtonEnum::Yes:
            save(mFileName);
            break;
        case SUI::StandardButtonEnum::No:
            deleteBackupFile();
            break;
        default:
            returnValue = false;
            break;
        }
    }
    saveTimerId = QObject::startTimer(SaveTimerInterval);
    return returnValue;
}

void FileController::resetRecentFilesMenu() {
    fileMenu->addSeparator();
    for (int i = 0; i < MaxRecentFiles; i++) fileMenu->addAction(recentFileActions[i]);

    fileMenu->addSeparator();
    updateRecentFileActions();
}

void FileController::clearFileName() {
    mFileName.clear();
}

QString FileController::getFileName() {
    return mFileName;
}

QString FileController::getBackupTempFileName() {
    return !mBackupTempFile ? "" : mBackupTempFile->fileName();
}

void FileController::setDataChanged(bool changed) {
    if (changed) dataChanged = true;   // only react if change is true
}

void FileController::timerEvent(QTimerEvent *) {
    if (dataChanged) {
        dataChanged = false;
        emit statusMessage(tr("Saving backup file ..."), 2000);

        if (!mBackupTempFile->exists()) {
            resetBackupFile();
        }
        save(mBackupTempFile->fileName());
    }
}

