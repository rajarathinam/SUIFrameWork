//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for UserControlSelector.
// !\description Class implementation file for UserControlSelector.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include <QImage>
#include <QApplication>

#include <SUIImageWidgetImpl.h>
#include <FWQxWidgets/SUILineWidget.h>

#include <SUIStyleSheet.h>
#include <SUILineWidgetImpl.h>
#include <FWQxCore/SUIObjectFactory.h>

#include "Model.h"
#include "usercontrolselector.h"

UserControlSelector::UserControlSelector(QWidget *parent) :
    WidgetController(parent, WidgetController::WidgetSelectorMode),
    mUCtrlLayout(NULL)
{
    this->setStyleSheet("background-color: white");
    this->setWidgetMode(WidgetController::WidgetSelectorMode);
}

UserControlSelector::~UserControlSelector()
{
    if (mUCtrlLayout)
    {
        mUCtrlLayout->deleteLater();
    }
}

/*****************************************************************************\
 *  FUNCTION    :   InitUserControls
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This function fills the User Control Selector with User Controls. Because
 *  these User Controls are shown as thumbnails, they are 'transformed' into
 *  QImages, which are being scaled. These thumbnails have the same ID as the
 *  User Controls in Models UserControlList, so when being dragged from the
 *  selector, the original UserControl is easily retrieved from that list.
 \****************************************************************************/
void UserControlSelector::initUserControls()
{
    //  Clear the selector
    if (mUCtrlLayout)
    {
        clear();
    }
    else
    {
        mUCtrlLayout = new QVBoxLayout(this);
        mUCtrlLayout->setGeometry(QRect(0, 0, 391, 590));
        this->setGeometry(QRect(0, 0, 391, 590));
        QPalette    wPal;
        wPal.setColor(QPalette::Background, Qt::white);
        this->setPalette(wPal);
        this->show();
    }
    mSeparatorList.clear();
    //  Fill the selector with UserControls from Model::mUserControlList
    int dTotal = (Model::instance()->getUserControlList().count()) - 1;
    int dInd = 0;
    foreach(WidgetController *child, Model::instance()->getUserControlList())
    {
        int     imgHeight = 40;
        int     imgWidth = 200;
        QPixmap pixmap = QPixmap::grabWidget(child).scaled(imgWidth, imgHeight, Qt::KeepAspectRatio, Qt::SmoothTransformation);

        WidgetDefinition    wcInfo;
        wcInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::ObjectType, QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::ImageWidget)));
        wcInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, QString::number(pixmap.height()));
        wcInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, QString::number(pixmap.width()));
        wcInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::ID, child->getId());
        wcInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::Sizeable, "false");

        WidgetController *thbCtrl = wcInfo.addToWidget(this, false);
        thbCtrl->getBaseWidget()->getWidget()->setStyleSheet(QString::fromStdString(SUI::StyleSheet::getInstance()->getStyleSheet()));
        thbCtrl->getBaseWidget()->initialize(SUI::BaseWidget::EditorSelector);
        thbCtrl->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        thbCtrl->setChildrenWidgetMode(WidgetController::WidgetSelectorMode);
        dynamic_cast<QLabel *>(thbCtrl->getBaseWidget()->getWidget())->setPixmap(pixmap);
        thbCtrl->setPixmapSize();
        thbCtrl->updatePixmap();
        QHBoxLayout *WidgetLayout = new QHBoxLayout;
        WidgetLayout->addWidget(thbCtrl);
        WidgetLayout->addStretch();
        WidgetLayout->addWidget(new QLabel(child->getId().right(child->getId().length() - 4)));
        mUCtrlLayout->addLayout(WidgetLayout);
        if (dInd++ < dTotal)
        {
            SUI::BaseWidget *lineWidget = dynamic_cast<SUI::BaseWidget*>(SUI::ObjectFactory::getInstance()->toBaseObject(SUI::ObjectFactory::getInstance()->createWidget_<SUI::LineWidget>()));
            lineWidget->initialize(SUI::BaseWidget::EditorSelector);
            WidgetController    *wcLine = new WidgetController(this, WidgetController::SingleWidgetMode, dynamic_cast<SUI::BaseWidget*>(lineWidget));
            wcLine->setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "4");
            wcLine->setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "260");
            wcLine->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
            wcLine->setId("WidgetSelector");
            mUCtrlLayout->addWidget(wcLine);
            mSeparatorList.append(wcLine);
        }
    }
    this->removeFromModel();
    mUCtrlLayout->setSizeConstraint(QLayout::SetMinimumSize);

    QSpacerItem *spacer = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Expanding);
    mUCtrlLayout->addItem(spacer);
    this->setLayout(mUCtrlLayout);
}

void UserControlSelector::init()
{
    this->setStyleSheet("background-color: white");
    this->setWidgetMode(WidgetController::WidgetSelectorMode);
}

void UserControlSelector::clear()
{
    QLayoutItem *item;
    while (mUCtrlLayout && (item = mUCtrlLayout->takeAt(0)))
    {
        QSpacerItem *spacer = NULL;
        if ((spacer = item->spacerItem()))
        {
            delete spacer;
            spacer = NULL;
        }
    }
    foreach(WidgetController * child, mChildren)
    {
        mUCtrlLayout->removeWidget(child);
        child->close();
        child->deleteLater();
        removeChild(child);
    }
    foreach(WidgetController * separator, mSeparatorList)
    {
        mUCtrlLayout->removeWidget(separator);
        separator->deleteLater();
    }
    mSeparatorList.clear();

    QApplication::sendPostedEvents();
    QApplication::processEvents();
}
