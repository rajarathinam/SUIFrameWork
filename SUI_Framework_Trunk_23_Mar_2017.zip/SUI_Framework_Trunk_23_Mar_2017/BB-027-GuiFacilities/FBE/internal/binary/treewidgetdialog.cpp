//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for treeWidgetDialog.
// !\description Class implementation file for treeWidgetDialog.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "treewidgetdialog.h"
#include "ui_treewidgetdialog.h"

#include <QDebug>
#include <QMessageBox>
#include <FWQxCore/SUIArgumentException.h>

#include <SUIStyleSheet.h>

treeWidgetDialog::treeWidgetDialog(WidgetController *treeWidget, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::treeWidgetDialog),
    mTreeWidgetContr(treeWidget)
{
    ui->setupUi(this);
    ui->treeWidget->setColumnCount(3);
    ui->treeWidget->setColumnHidden(1, true);
    ui->treeWidget->setColumnHidden(2, true);
    addWidgets();
    ui->treeWidget->expandAll();
    mWidgetState = UndoHandler::instance()->getNewUndoInfo(mTreeWidgetContr, ACT_COMPLEX, "Change Treewidget");
}

treeWidgetDialog::~treeWidgetDialog()
{
    UndoHandler::instance()->finishUndoInfo(mWidgetState, mTreeWidgetContr);
    UndoHandler::instance()->addToUndoGroup(mWidgetState);
    delete ui;
}

void treeWidgetDialog::on_pushButton_clicked()
{
    addrow(ui->treeWidget->currentItem());
}

void treeWidgetDialog::addrow(QTreeWidgetItem *parent)
{
    QTreeWidgetItem *item;
    if (!parent)
    {
        parent = ui->treeWidget->invisibleRootItem();
    }
    item = new QTreeWidgetItem(parent);
    item->setFlags(Qt::ItemIsEditable | Qt::ItemIsEnabled | Qt::ItemIsSelectable);
    ui->treeWidget->expandItem(parent);
    ui->treeWidget->editItem(item, 0);
    ui->treeWidget->setCurrentItem(item);
}

void treeWidgetDialog::on_pushButton_2_clicked()
{
    try
    {
        if (ui->treeWidget->currentItem()->text(2) != "")
        {
            WidgetController *wdgtcontr = Model::instance()->getWidgetController(ui->treeWidget->currentItem()->text(2));
            QStringList list;
            std::list<std::string>  itemList;
            itemList.push_back(ui->treeWidget->currentItem()->text(2).toStdString());
            dynamic_cast<SUI::TreeViewImpl *>(mTreeWidgetContr->getBaseWidget())->removeItems(itemList);
            wdgtcontr->removeFromModel();
            wdgtcontr->getParent()->removeChild(wdgtcontr);
            wdgtcontr->deleteLater();
            wdgtcontr = NULL;
        }
        delete ui->treeWidget->currentItem();
        mTreeWidgetContr->updatePixmap();
    }
    catch (SUI::ArgumentException *re)
    {
        QMessageBox msgbox;
        msgbox.setIcon(QMessageBox::Warning);
        msgbox.setStyleSheet(QString::fromStdString(SUI::StyleSheet::getInstance()->getStyleSheet()));
        msgbox.setWindowTitle("ArgumentException");
        msgbox.setText(QString::fromStdString(re->getExceptionMessage()));
        msgbox.exec();
        delete re;
        return;
    }
    catch (SUI::Exception *re)
    {
        QMessageBox msgbox;
        msgbox.setIcon(QMessageBox::Warning);
        msgbox.setStyleSheet(QString::fromStdString(SUI::StyleSheet::getInstance()->getStyleSheet()));
        msgbox.setWindowTitle("Exception");
        msgbox.setText(QString::fromStdString(re->getExceptionMessage()));
        msgbox.exec();
        delete re;
        return;
    }
}

void treeWidgetDialog::on_pushButton_3_clicked()
{
    QTreeWidgetItem *parent = ui->treeWidget->currentItem();
    if (!parent)
    {
        parent = ui->treeWidget->invisibleRootItem();
    }
    else
    {
        parent = ui->treeWidget->currentItem()->parent();
    }
    addrow(parent);
}

void treeWidgetDialog::on_pushButton_4_clicked()
{
    dynamic_cast<SUI::TreeViewImpl *>(mTreeWidgetContr->getBaseWidget())->clearItems();
    getItems(ui->treeWidget->invisibleRootItem());
    emit accept();
    mTreeWidgetContr->updatePixmap();
}

void treeWidgetDialog::getItems(QTreeWidgetItem *item)
{
    if (item != ui->treeWidget->invisibleRootItem())
    {
        mTreeWidgetContr->insertTreeItem(item);
    }
    for (int i = 0; i < item->childCount(); ++i)
    {
        getItems(item->child(i));
    }
}

void treeWidgetDialog::addWidgets()
{
    foreach(WidgetController * child, *(mTreeWidgetContr->getChildren()))
    {
        QTreeWidgetItem *newItem = ui->treeWidget->invisibleRootItem();
        addWidgets(child , newItem);
    }
}

void treeWidgetDialog::addWidgets(WidgetController *child, QTreeWidgetItem *item)
{
    QTreeWidgetItem *newItem = new QTreeWidgetItem();
    newItem->setText(0, child->getPropertyValue(SUI::ObjectPropertyTypeEnum::Text));
    newItem->setText(2, child->getId());
    newItem->setFlags(Qt::ItemIsEditable | Qt::ItemIsEnabled | Qt::ItemIsSelectable);
    item->addChild(newItem);

    foreach(WidgetController * child2, *(child->getChildren()))
    {
        addWidgets(child2, newItem);
    }
}

