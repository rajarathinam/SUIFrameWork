#ifndef SUIINUMERICUNITTEST_H
#define SUIINUMERICUNITTEST_H

#include <FWQxCore/SUIINumeric.h>

namespace SUI {

class INumericUnitTest
{
public:
    INumericUnitTest(SUI::INumeric<double> *dObject);
    INumericUnitTest(SUI::INumeric<float> *dObject);
    INumericUnitTest(SUI::INumeric<int> *iObject);
    INumericUnitTest(SUI::INumeric<unsigned> *dObject);

    bool testDouble();
    bool testFloat();
    bool testInteger();
    bool testUnsigned();

private:
    INumeric<double> *dObject;
    INumeric<float> *fObject;
    INumeric<int> *iObject;
    INumeric<unsigned> *uObject;
};

}

#endif // SUIINUMERICUNITTEST_H
