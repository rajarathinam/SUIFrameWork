#ifndef SUIIMAGEWIDGETUNITTEST_H
#define SUIIMAGEWIDGETUNITTEST_H

#include "SUIWidgetUnitTest.h"


namespace SUI {

class ImageWidget;

class ImageWidgetUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    ImageWidgetUnitTest(ImageWidget *object, QObject *parent = 0);
    virtual ~ImageWidgetUnitTest();

private Q_SLOTS:
    void setImage();
    void setImage_data();

private:
    ImageWidget *object;
};

}

#endif // SUIIMAGEWIDGETUNITTEST_H
