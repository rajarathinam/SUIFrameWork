#ifndef SUIIVIEWABLEUNITTEST_H
#define SUIIVIEWABLEUNITTEST_H

#include <QObject>

namespace SUI {

class IViewable;

class IViewableUnitTest : public QObject
{
    Q_OBJECT
public:
    IViewableUnitTest(IViewable *object, QObject *parent = 0);
    virtual ~IViewableUnitTest();

private slots:
    void setVisible();
    void show();
    void hide();
    void visibilityChanged();

private:
    void onVisibilityChanged(bool visible);
    bool mVisible;

    IViewable *object;

};

}
#endif // SUIIVIEWABLEUNITTEST_H
