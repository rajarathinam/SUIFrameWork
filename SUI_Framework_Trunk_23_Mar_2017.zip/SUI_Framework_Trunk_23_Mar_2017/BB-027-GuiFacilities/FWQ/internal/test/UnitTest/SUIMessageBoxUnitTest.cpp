#include "SUIMessageBoxUnitTest.h"
#include <FWQxWidgets/SUIMessageBox.h>
#include <QTest>
#include "SUIITextUnitTest.h"
#include "SUIIClickableUnitTest.h"

SUI::MessageBoxUnitTest::MessageBoxUnitTest(SUI::MessageBox *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::MessageBoxUnitTest::~MessageBoxUnitTest() {
    delete object;
}

void SUI::MessageBoxUnitTest::callInterfaceTests() {
    // IText UnitTests
    ITextUnitTest iTextUnitTest(object);
    QVERIFY(iTextUnitTest.setText());
    QVERIFY(iTextUnitTest.clearText());
    QVERIFY(iTextUnitTest.setBold());

    //IClickable tests
    IClickableUnitTest iClickable(object);
    iClickable.clickable();
}
