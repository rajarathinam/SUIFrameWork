#include <FWQxWidgets/SUIDropDown.h>
#include "SUIDropDownUnitTest.h"
#include "SUIIColorableUnitTest.h"
#include "SUIIBGColorableUnitTest.h"
#include "SUIIErrorModeUnitTest.h"
#include <QTest>

SUI::DropDownUnitTest::DropDownUnitTest(SUI::DropDown *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::DropDownUnitTest::~DropDownUnitTest() {
    delete object;
}

void SUI::DropDownUnitTest::callInterfaceTests() {
    //IColorable tests
    //valid colors
    IColorableUnitTest iColorableUnitTest(object);
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Standard));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Green));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Red));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Gray));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Blue));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Yellow));
    //test invalid colors
    QVERIFY(!iColorableUnitTest.setColor(SUI::ColorEnum::Black));
    QVERIFY(!iColorableUnitTest.setColor(SUI::ColorEnum::White));
    QVERIFY(!iColorableUnitTest.setColor(SUI::ColorEnum::Orange));
    QVERIFY(!iColorableUnitTest.setColor(SUI::ColorEnum::Transparent));

    //IBGColorable tests
    IBGColorableUnitTest iBGColorableUnitTest(object);
    //valid colors
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Standard));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Red));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Green));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Blue));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Gray));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Yellow));
    //test invalid colors
    QCOMPARE(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::White), false);

    //TO DO StringList

    //IErrorMode unit test
    IErrorModeUnitTest iErrorModeUnitTest(object);
    QVERIFY(iErrorModeUnitTest.setErrorMode());
}
