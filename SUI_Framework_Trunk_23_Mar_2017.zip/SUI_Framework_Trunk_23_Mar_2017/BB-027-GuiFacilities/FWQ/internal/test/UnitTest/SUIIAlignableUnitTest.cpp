#include "SUIIAlignableUnitTest.h"

#include <QtGlobal>
#include <QTest>

#include <FWQxCore/SUIIAlignable.h>

SUI::IAlignableUnitTest::IAlignableUnitTest(IAlignable *object) :
    object(object)
{
    Q_ASSERT(object);
}

bool SUI::IAlignableUnitTest::setAlignment(SUI::AlignmentEnum::Alignment align) {
    object->setAlignment(align);
    return (object->getAlignment() == align);
}

