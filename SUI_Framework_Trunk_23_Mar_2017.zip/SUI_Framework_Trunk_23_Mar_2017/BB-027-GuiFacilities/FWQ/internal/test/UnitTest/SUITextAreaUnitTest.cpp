#include "SUITextAreaUnitTest.h"
#include "SUIITextUnitTest.h"
#include "SUIIColorableUnitTest.h"
#include "SUIIAlignableUnitTest.h"
#include "SUIIErrorModeUnitTest.h"
#include <QTest>

SUI::TextAreaUnitTest::TextAreaUnitTest(SUI::TextArea *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::TextAreaUnitTest::~TextAreaUnitTest() {
    delete object;
}

void SUI::TextAreaUnitTest::callInterfaceTests() {
    //IText tests
    ITextUnitTest iTextUnitTest(object);
    // TextArea uses markup so the default setText interface test will fail
    //QVERIFY(iTextUnitTest.setText());
    QVERIFY(iTextUnitTest.clearText());
    QVERIFY(iTextUnitTest.setBold());

    //IColorable tests
    IColorableUnitTest iColorableUnitTest(object);
    // Valid colors
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Standard));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Black));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Green));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Red));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Gray));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Blue));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Yellow));
    // Invalid colors
    QVERIFY(!iColorableUnitTest.setColor(SUI::ColorEnum::White));
    QVERIFY(!iColorableUnitTest.setColor(SUI::ColorEnum::Orange));
    QVERIFY(!iColorableUnitTest.setColor(SUI::ColorEnum::Transparent));

    //IAlignable tests
    IAlignableUnitTest iAlignableUnitTest(object);
    // Valid alignment
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::HCenter));
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Left));
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Right));
    // Invalid alignment
    QVERIFY(!iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Stretch));

    //IErrorMode unit test
    IErrorModeUnitTest iErrorModeUnitTest(object);
    QVERIFY(iErrorModeUnitTest.setErrorMode());
}

void SUI::TextAreaUnitTest::setText() {
    const std::string text = "test";
    const std::string retText = "test\n";

    object->setText(text);
    QCOMPARE(object->getText(), retText);
}

void SUI::TextAreaUnitTest::setAutoScroll() {
    object->setAutoScroll(false);
    QVERIFY(!object->getAutoScroll());

    object->setAutoScroll(true);
    QVERIFY(object->getAutoScroll());
}

void SUI::TextAreaUnitTest::setReadOnly() {
    object->setReadonly(true);
    QVERIFY(object->getReadonly());

    object->setReadonly(false);
    QVERIFY(!object->getReadonly());
}
