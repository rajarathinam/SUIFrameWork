#ifndef SUICLICKABLEUNITTEST_H
#define SUICLICKABLEUNITTEST_H

namespace SUI {

class IClickable;

class IClickableUnitTest
{
public:
    IClickableUnitTest(IClickable *object);

    void clickable();
    void onClick();

private:
    IClickable *obj;

};

}
#endif // SUICLICKABLEUNITTEST_H
