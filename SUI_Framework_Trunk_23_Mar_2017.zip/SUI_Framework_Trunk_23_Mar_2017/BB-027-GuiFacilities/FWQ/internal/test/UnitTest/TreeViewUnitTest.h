#ifndef TREEVIEWUNITTEST_H
#define TREEVIEWUNITTEST_H

#include <QTest>
#include <QString>

#include <FWQxCore/SUIObjectList.h>
#include <SUIBaseWidget.h>
#include <SUITreeViewImpl.h>

class TreeViewUnitTest : public QObject
{
    Q_OBJECT

public:
    TreeViewUnitTest();

private Q_SLOTS:
    void initTestCase();
    void cleanupTestCase();

    /// Unit testen
    // IWidgetStatus setVisible
    void testVisibilityCase2();
    void testVisibilityCase2_data();

    // IWidgetStatus Enabled
    void testEnabledCase2();
    void testEnabledCase2_data();

    // Add Item to the root
    void testAddTreeItemCase1();
    void testAddTreeItemCase1_data();

    // Add Item to a item
    void testAddTreeItemCase2();
    void testAddTreeItemCase2_data();

    // Is leaf node
    void testIsLeafNode();
    void testIsLeafNode_data();

    // getSelectedItems
    void testGetSelectedItemsCase1();
    void testGetSelectedItemsCase1_data();

    // selectItem
    void testSelectItemCase1();
    void testSelectItemCase1_data();

    // remove Item from item & root
    void testRemoveTreeItemCase1();
    void testRemoveTreeItemCase1_data();

    /// Interface Unit Testen
    // IWidgetStatus Visibility
    void testVisibilityCase1();
    void testVisibilityCase1_data();

    // IWidgetStatus Enabled
    void testEnabledCase1();
    void testEnabledCase1_data();

    // IWidgetText SetText
    void testSetTextCase1();
    void testSetTextCase1_data();

    // IWidgetText ClearText
    void testClearTextCase1();
    void testClearTextCase1_data();

    // Add Item to the root
    void testIAddTreeItemCase1();
    void testIAddTreeItemCase1_data();

    // Add Item to a item
    void testIAddTreeItemCase2();
    void testIAddTreeItemCase2_data();

    // remove Item from item & root
    void testIRemoveTreeItemCase1();
    void testIRemoveTreeItemCase1_data();

private:
    SUI::TreeViewImpl *mTreeWidg;
    SUI::TreeView *mITreeWidg;
    SUI::Widget *mITreeWidg_Status;
    SUI::IText *mITreeWidg_Text;
};

#endif // TREEVIEWUNITTEST_H
