#ifndef SUISCIENCESPINBOXUNITTEST_H
#define SUISCIENCESPINBOXUNITTEST_H

#include "SUIWidgetUnitTest.h"

namespace SUI {

class ScienceSpinBox;

class ScienceSpinBoxUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    ScienceSpinBoxUnitTest(SUI::ScienceSpinBox *object , QObject *parent = 0);
    ~ScienceSpinBoxUnitTest();

protected:
    void callInterfaceTests();

private:
    ScienceSpinBox *object;
};
}
#endif // SUISCIENCESPINBOXUNITTEST_H
