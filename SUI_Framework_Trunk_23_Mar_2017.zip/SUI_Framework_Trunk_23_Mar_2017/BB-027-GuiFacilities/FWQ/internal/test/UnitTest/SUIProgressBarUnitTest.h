#ifndef SUIPROGRESSBARUNITTEST_H
#define SUIPROGRESSBARUNITTEST_H

#include "SUIWidgetUnitTest.h"
#include <FWQxWidgets/SUIProgressBar.h>

namespace SUI {

class ProgressBar;

class ProgressBarUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    ProgressBarUnitTest(SUI::ProgressBar *object, QObject *parent = 0);
    virtual ~ProgressBarUnitTest();

private slots:
    void setText();
    void clearText();
    void setValue();
    void startTimedProgress();
    void disablePercentage();

protected:
    void callInterfaceTests();

private:
    ProgressBar *object;
};

}

#endif // SUIPROGRESSBARUNITTEST_H
