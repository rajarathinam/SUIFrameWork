#ifndef SUIDIALOGUNITTEST_H
#define SUIDIALOGUNITTEST_H

#include "SUIWidgetUnitTest.h"
#include <FWQxWidgets/SUIDialog.h>
#include <QObject>
namespace SUI {

class Dialog;

class DialogUnitTest : public ObjectUnitTest
{
    Q_OBJECT

public:
    DialogUnitTest(Dialog *object, QObject *parent = 0);
    virtual ~DialogUnitTest();

private:
    Dialog *object;
};

}
#endif // SUIDIALOGUNITTEST_H
