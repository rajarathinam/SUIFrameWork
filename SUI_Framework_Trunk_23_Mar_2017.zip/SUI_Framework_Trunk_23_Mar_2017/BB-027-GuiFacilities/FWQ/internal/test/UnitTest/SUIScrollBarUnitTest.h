#ifndef SUISCROLLBARUNITTEST_H
#define SUISCROLLBARUNITTEST_H

#include "SUIWidgetUnitTest.h"
#include <FWQxWidgets/SUIScrollBar.h>

namespace SUI {

class ScrollBar;

class ScrollBarUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    ScrollBarUnitTest(SUI::ScrollBar *object, QObject *parent = 0);
    virtual ~ScrollBarUnitTest();

private slots:
    //INumeric
    void setPageStep();
    void valueChanged();
    void onChange();

protected:
    void callInterfaceTests();

private:
    ScrollBar *object;
};

}


#endif // SUISCROLLBARUNITTEST_H
