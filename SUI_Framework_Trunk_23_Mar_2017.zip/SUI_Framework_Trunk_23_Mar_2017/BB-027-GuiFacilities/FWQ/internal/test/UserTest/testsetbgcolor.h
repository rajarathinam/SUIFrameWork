#ifndef TESTSETBGCOLOR_H
#define TESTSETBGCOLOR_H

#include <SUIDialogImpl.h>



class testSetBGColor
{
private:
    QString mTargetWidgetid;
    QString mSourceWidgetid;
    SUI::DialogImpl  *mpGui;

public:
    void handleClicked();
    void handleValueChanged();
    testSetBGColor(QString aSourceWidgetID, QString aTargetWidgetID , SUI::DialogImpl *apGui);
};



class testCheckHover
{
    QString mWidgetID;
    QString mColorDropID;
    SUI::DialogImpl  *mpGui;
public:

    testCheckHover(QString aWidgetID, QString aColorDropID,SUI::DialogImpl *apGui);
    void handleCheckedChanged(bool checked);
};

#endif // TESTSETBGCOLOR_H
