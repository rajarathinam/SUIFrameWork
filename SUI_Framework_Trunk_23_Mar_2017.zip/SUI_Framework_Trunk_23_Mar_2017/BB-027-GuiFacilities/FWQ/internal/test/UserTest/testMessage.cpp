#include "testMessage.h"


#include <FWQxCore/SUIIText.h>
#include <FWQxCore/SUIIViewable.h>
#include <FWQxWidgets/SUIMessageBox.h>
#include <FWQxWidgets/SUIDropDown.h>

#include <sstream>

testMessage::testMessage(QString aSourceWidgetID, QString aTargetWidgetID, SUI::DialogImpl *apGui, testMessage::Act aAction):
    mTargetWidgetid(aTargetWidgetID),
    mSourceWidgetid(aSourceWidgetID),
    mpGui(apGui),
    mAction(aAction)
{
}


void testMessage::handleClicked()
{
    std::string text;
    SUI::MessageBox     *msgbox = NULL;
    SUI::IText          *widgetText;
    SUI::IViewable      *widgetShow = NULL;
    SUI::DropDown       *dropDown = NULL;
    switch (mAction)
    {
    case testMessage::MSG_SHOW:
        widgetShow = mpGui->getObjectList()->getObject<SUI::IViewable>(mSourceWidgetid.toStdString());
        if (widgetShow)
        {
            widgetShow->show();
        }
        break;
    case testMessage::MSG_BTNTEXT:
        widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mSourceWidgetid.toStdString());
        if (widgetText)
        {
            std::stringstream stream(widgetText->getText());
            std::list<std::string> btnText;
            std::string split;
            while(getline(stream, split, ';'))
            {
                btnText.push_back(split);
            }

            msgbox = mpGui->getObjectList()->getObject<SUI::MessageBox>(mTargetWidgetid.toStdString());
            if (msgbox)
            {
                msgbox->setButtonText(btnText);
            }
        }
        break;
    case testMessage::MSG_CALLBACK:
        msgbox = mpGui->getObjectList()->getObject<SUI::MessageBox>(mSourceWidgetid.toStdString());
        widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mTargetWidgetid.toStdString());
        if (msgbox && widgetText)
        {
            widgetText->setText(msgbox->handleButtonRetour());
        }
        break;
    case testMessage::MSG_SETDEFAULT:
        widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mSourceWidgetid.toStdString());
        msgbox = mpGui->getObjectList()->getObject<SUI::MessageBox>(mTargetWidgetid.toStdString());
        if (msgbox && widgetText)
        {
            text = widgetText->getText();
            msgbox->setDefaultButton(text);
        }
        break;
    case testMessage::MSG_TITLETEXT:
        widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mSourceWidgetid.toStdString());
        msgbox = mpGui->getObjectList()->getObject<SUI::MessageBox>(mTargetWidgetid.toStdString());
        if (msgbox && widgetText)
        {
            text = widgetText->getText();
            msgbox->setTitle(text);
        }
        break;
    case testMessage::MSG_SETICON:
        dropDown = mpGui->getObjectList()->getObject<SUI::DropDown>(mSourceWidgetid.toStdString());
        msgbox = mpGui->getObjectList()->getObject<SUI::MessageBox>(mTargetWidgetid.toStdString());
        if (msgbox && dropDown)
        {
            text = dropDown->getSelectedItems().front();
            int num = QString::fromStdString(text).left(1).toInt();
            switch (num)
            {
            case 1:
                msgbox->setIcon(SUI::MessageBoxIconEnum::Information);
                break;
            case 2:
                msgbox->setIcon(SUI::MessageBoxIconEnum::Warning);
                break;
            case 3:
                msgbox->setIcon(SUI::MessageBoxIconEnum::Critical);
                break;
            case 4:
                msgbox->setIcon(SUI::MessageBoxIconEnum::Question);
                break;
            default:
                msgbox->setIcon(SUI::MessageBoxIconEnum::None);
                break;
            }
        }
        break;
    }
}
