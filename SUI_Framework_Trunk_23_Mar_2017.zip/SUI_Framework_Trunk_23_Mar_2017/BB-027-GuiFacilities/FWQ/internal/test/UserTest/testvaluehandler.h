#ifndef TESTVALUEHANDLER_H
#define TESTVALUEHANDLER_H

#include "SUIDialogImpl.h"

class testValueHandler
{
    QString mWidgetID;
    SUI::DialogImpl  *mpGui;
public:
    testValueHandler(QString aWidgetID, SUI::DialogImpl *apGui);
};

#endif // TESTVALUEHANDLER_H
