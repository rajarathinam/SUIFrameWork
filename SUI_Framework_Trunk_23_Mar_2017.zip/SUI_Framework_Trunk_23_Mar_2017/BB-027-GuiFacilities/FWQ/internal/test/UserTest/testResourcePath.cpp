#include "testResourcePath.h"

#include <FWQxCore/SUIResourcePath.h>
#include <FWQxWidgets/SUILineEdit.h>
#include <FWQxWidgets/SUILabel.h>
#include <QDir>

testResourcePath::testResourcePath(QString aleResourcePath, QString alaResourcePath, SUI::DialogImpl *apGui) :
    leResourcePath(aleResourcePath),
    laResourcePath(alaResourcePath),
    mpGui(apGui)
{
    SUI::Label *la = mpGui->getObjectList()->getObject<SUI::Label>(laResourcePath.toStdString());
    if(la != NULL ){
        la->setText(SUI::ResourcePath::getResourcePath());
    }
    SUI::LineEdit *le = mpGui->getObjectList()->getObject<SUI::LineEdit>(leResourcePath.toStdString());
    if(le != NULL){
        le->clearText();
    }
}

void testResourcePath::onSetRPClicked() {
    SUI::LineEdit *le = mpGui->getObjectList()->getObject<SUI::LineEdit>(leResourcePath.toStdString());
    if(le != NULL){
        SUI::ResourcePath::getInstance()->setResourcePath(le->getText());
    }
   SUI::Label *la = mpGui->getObjectList()->getObject<SUI::Label>(laResourcePath.toStdString());
   if(la != NULL){
       la->setText(SUI::ResourcePath::getResourcePath());
   }
}

