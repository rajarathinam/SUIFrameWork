#include "testsetvalueasfactor.h"

#include <FWQxCore/SUIINumeric.h>
#include <SUIDialogImpl.h>

testSetValueAsFactor::testSetValueAsFactor(QString aWidgetID, SUI::DialogImpl *apGui) :
    mWidgetID(aWidgetID),
    mpGui(apGui)
{
}

void testSetValueAsFactor::handleCheckedChanged(bool checked)
{
    SUI::INumeric<int>  *widgetNumInt = mpGui->getObjectList()->getObject<SUI::INumeric<int>>(mWidgetID.toStdString());
    if (widgetNumInt) {
        widgetNumInt->setStepSizeValueToFactor(checked);
        return;
    }
    SUI::INumeric<double> *widgetNumDouble = mpGui->getObjectList()->getObject<SUI::INumeric<double>>(mWidgetID.toStdString());
    if (widgetNumDouble) {
        widgetNumDouble->setStepSizeValueToFactor(checked);
        return;
    }

}
