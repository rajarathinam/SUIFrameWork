#ifndef TESTSTEPSIZEINTVALUEHANDLER_H
#define TESTSTEPSIZEINTVALUEHANDLER_H


#include "SUIDialogImpl.h"

class testStepsizeIntValueHandler
{
public:
    testStepsizeIntValueHandler(QString aSourceWidgetID, QString aTargetWidgetID , SUI::DialogImpl *apGui);

    void    handleValueChanged();

private:
    QString mSourceWidgetid;
    QString mTargetWidgetid;
    SUI::DialogImpl  *mpGui;
};

#endif // TESTSTEPSIZEINTVALUEHANDLER_H
