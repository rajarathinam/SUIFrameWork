//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class FontSizeEnum.
// !\description Header file for class FontSizeEnum.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|



#include "FWQxCore/SUIFontSizeEnum.h"

const std::map<SUI::FontSizeEnum::FontSize,const std::string> SUI::FontSizeEnum::fontSizeStringMap = {
    {SUI::FontSizeEnum::Big,"Big"},
    {SUI::FontSizeEnum::Normal,"Normal"},
    {SUI::FontSizeEnum::Small,"Small"},
    {SUI::FontSizeEnum::Uninitialized,"Uninitialized"}
};

const std::map<const std::string, SUI::FontSizeEnum::FontSize> SUI::FontSizeEnum::stringFontSizeMap =
        SUI::FontSizeEnum::createStringFontSizeMap();

std::string SUI::FontSizeEnum::toString(const SUI::FontSizeEnum::FontSize &size) {
    return fontSizeStringMap.find(size)->second;
}

SUI::FontSizeEnum::FontSize SUI::FontSizeEnum::fromString(const std::string &size) {
    std::map<const std::string,FontSize>::const_iterator it = stringFontSizeMap.find(size);
    return it != stringFontSizeMap.end() ? it->second : SUI::FontSizeEnum::Uninitialized;
}

const std::map<const std::string, SUI::FontSizeEnum::FontSize> SUI::FontSizeEnum::createStringFontSizeMap() {
    std::map<const std::string, FontSize> map;
    for (std::map<FontSize,const std::string>::const_iterator it = fontSizeStringMap.begin(); it != fontSizeStringMap.end(); ++it) {
        map.insert(std::pair<const std::string, FontSize>(it->second,it->first));
    }
    return map;

}
