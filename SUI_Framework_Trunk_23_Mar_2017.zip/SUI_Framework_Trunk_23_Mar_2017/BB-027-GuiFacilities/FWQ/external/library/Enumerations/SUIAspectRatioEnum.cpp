//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class AspectRatioEnum.
// !\description Header file for class AspectRatioEnum.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "FWQxCore/SUIAspectRatioEnum.h"

SUI::AspectRatioEnum::Mode SUI::AspectRatioEnum::fromString(const std::string &style) {
   Mode returnValue;
   if (style == "padding") {
      returnValue = KeepAspectRatio;
   }
   else if (style == "cropped") {
      returnValue = KeepAspectRatioByExpanding;
   }
   else {
      returnValue = IgnoreAspectRatio;
   }
   return returnValue;
}

std::string SUI::AspectRatioEnum::toString(const Mode &style) {
   std::string returnValue = "padded";
   switch (style) {
   case KeepAspectRatioByExpanding: returnValue = "cropped"; break;
   case KeepAspectRatio: returnValue = "padding"; break;
   case IgnoreAspectRatio: returnValue = "stretched"; break;
   default:;
   }
   return returnValue;
}
