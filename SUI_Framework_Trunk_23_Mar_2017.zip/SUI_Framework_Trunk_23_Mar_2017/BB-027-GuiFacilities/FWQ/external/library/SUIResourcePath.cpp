//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::ResourcePath.
// !\description Class implementation file for SUI::ResourcePath.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "FWQxCore/SUIResourcePath.h"
#include "FWQxCore/SUIArgumentException.h"

#include <QDir>
#include <QFileInfo>

namespace {
    char resourcePath[1024] = "";
}

SUI::ResourcePath::ResourcePath()
{
}

SUI::ResourcePath *SUI::ResourcePath::getInstance() {
   static SUI::ResourcePath instance;
   return &instance;
}

void SUI::ResourcePath::setResourcePath(const std::string &path) {
    if(!QDir(path.c_str()).exists() || path.size() > 1023) throw new SUI::ArgumentException("Argument path is invalid");
    strncpy(resourcePath, path.c_str(), path.size());
}

std::string SUI::ResourcePath::getResourcePath() {
    return std::string(resourcePath);
}

std::string SUI::ResourcePath::getResourceFile(const std::string &filename) {
    QString qfilename = QString::fromStdString(filename);
    QString qResourcePath = QString::fromAscii(resourcePath);
    //check if filename is absolute filename and exisits
    if((((qfilename.indexOf(QDir::separator()) == 0)  || (qfilename.left(1) == ":" )) &&  QFileInfo(qfilename).exists()) ) {
        return filename;
    }
    //check if resourcePath is empty
    if(qResourcePath.isEmpty()) {
        return filename;
    }

    //compute absolute resourcePath + filename
    QString absfilename;
    if(qResourcePath.lastIndexOf(QDir::separator())  == qResourcePath.size() - 1) {
        absfilename =  qResourcePath + qfilename;
    } else {
        absfilename =  qResourcePath + QDir::separator() + qfilename;
    }
    //check if absolute resourcePath + filename, exists
    if(QFileInfo(absfilename).exists()) {
        return absfilename.toStdString();
    }

    return filename;
}
