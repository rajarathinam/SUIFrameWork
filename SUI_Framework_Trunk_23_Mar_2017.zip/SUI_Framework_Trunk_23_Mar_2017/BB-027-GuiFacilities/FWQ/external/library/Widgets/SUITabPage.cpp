//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for TabPage.
// !\description Class implementation file for TabPage.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "FWQxWidgets/SUITabPage.h"

#include "FWQxCore/SUIObjectFactory.h"

SUI::TabPage::TabPage() : 
    Widget(SUI::ObjectType::TabPage) 
{       
}

SUI::TabPage::~TabPage()
{       
}
