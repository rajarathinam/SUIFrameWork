//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for GraphicsSvgItem.
// !\description Class implementation file for GraphicsSvgItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "FWQxGraphicsItems/SUIGraphicsSvgItem.h"

#include <boost/bind.hpp>

#include "FWQxCore/SUIObjectFactory.h"

#include "CustomGraphicsSvgItem.h"

SUI::GraphicsSvgItem::GraphicsSvgItem(SUI::GraphicsItem *parent) : 
    GraphicsItem(
          SUI::ObjectType::GraphicsSvgItem,
          new CustomGraphicsSvgItem(parent ? static_cast<QGraphicsItem*>(ObjectFactory::getImplementation(parent)) : NULL),
          parent) 
{
}

SUI::GraphicsSvgItem::~GraphicsSvgItem() {
    delete static_cast<CustomGraphicsSvgItem*>(GraphicsItem::getImplementation());
}

void SUI::GraphicsSvgItem::setImage(const std::string &image) {
    static_cast<CustomGraphicsSvgItem*>(GraphicsItem::getImplementation())->setImage(image);
}

void SUI::GraphicsSvgItem::setImage(unsigned char *data, int width, int height, ImageEnum::Format format) {
   Q_UNUSED(data); Q_UNUSED(width); Q_UNUSED(height); Q_UNUSED(format);
}

void SUI::GraphicsSvgItem::setElementId(const std::string &id){
    static_cast<CustomGraphicsSvgItem*>(GraphicsItem::getImplementation())->setElementId(id);
}

std::string SUI::GraphicsSvgItem::elementId(){
    return static_cast<CustomGraphicsSvgItem*>(GraphicsItem::getImplementation())->elementId();
}

void SUI::GraphicsSvgItem::scale(int width, int height) {
   static_cast<CustomGraphicsSvgItem*>(GraphicsItem::getImplementation())->scale(width,height);
}

std::list<std::string> SUI::GraphicsSvgItem::getElementIdList() {
    return static_cast<CustomGraphicsSvgItem*>(GraphicsItem::getImplementation())->getElementIdList();
}

void SUI::GraphicsSvgItem::setElementColor(const std::string id, const SUI::ColorEnum::Color color) {
   if (!SUI::ColorEnum::exists(SUI::ColorEnum::getColorEnumList(SUI::Object::getObjectType()),color)) return;
   static_cast<CustomGraphicsSvgItem*>(GraphicsItem::getImplementation())->setElementColor(id,color);
   static_cast<CustomGraphicsSvgItem*>(GraphicsItem::getImplementation())->update();
}

void SUI::GraphicsSvgItem::setElementBorderColor(const std::string id, const SUI::ColorEnum::Color borderColor) {
   if(!SUI::ColorEnum::exists(SUI::ColorEnum::getColorEnumList(SUI::Object::getObjectType()),borderColor)) return;
   static_cast<CustomGraphicsSvgItem*>(GraphicsItem::getImplementation())->setElementBorderColor(id,borderColor);
   static_cast<CustomGraphicsSvgItem*>(GraphicsItem::getImplementation())->update();
}

void SUI::GraphicsSvgItem::setElementText(const std::string id, const std::string text) {
    static_cast<CustomGraphicsSvgItem*>(GraphicsItem::getImplementation())->setElementText(id,text);
    static_cast<CustomGraphicsSvgItem*>(GraphicsItem::getImplementation())->update();
}

std::string SUI::GraphicsSvgItem::getElementText(const std::string idvalue) {
    return static_cast<CustomGraphicsSvgItem*>(GraphicsItem::getImplementation())->getElementText(idvalue);
}

void SUI::GraphicsSvgItem::elideText(int maxwidth) {
    static_cast<CustomGraphicsSvgItem*>(GraphicsItem::getImplementation())->elideText(maxwidth);
    static_cast<CustomGraphicsSvgItem*>(GraphicsItem::getImplementation())->update();
}

void SUI::GraphicsSvgItem::resetElideText() {
   static_cast<CustomGraphicsSvgItem*>(GraphicsItem::getImplementation())->resetElideText();
   static_cast<CustomGraphicsSvgItem*>(GraphicsItem::getImplementation())->update();
}

void SUI::GraphicsSvgItem::setElementBorderWidth(const std::string id, const int borderWidth) {
    static_cast<CustomGraphicsSvgItem*>(GraphicsItem::getImplementation())->setElementBorderWidth(id,borderWidth);
    static_cast<CustomGraphicsSvgItem*>(GraphicsItem::getImplementation())->update();
}

void SUI::GraphicsSvgItem::setElementTextColor(const std::string id, const SUI::ColorEnum::Color color) {
   if(!SUI::ColorEnum::exists(SUI::ColorEnum::getColorEnumList(SUI::Object::getObjectType()),color)) return;
   static_cast<CustomGraphicsSvgItem*>(GraphicsItem::getImplementation())->setElementTextColor(id,color);
   static_cast<CustomGraphicsSvgItem*>(GraphicsItem::getImplementation())->update();
}

void SUI::GraphicsSvgItem::setElementToolTip(const std::string id, const std::string tipText) {
   static_cast<CustomGraphicsSvgItem*>(GraphicsItem::getImplementation())->setElementToolTip(id,tipText);
   static_cast<CustomGraphicsSvgItem*>(GraphicsItem::getImplementation())->update();
}

void SUI::GraphicsSvgItem::setElementToDoublClickEvent(const std::string idvalue, SUI::GraphicsSvgItem::function_type func) {
    static_cast<CustomGraphicsSvgItem*>(GraphicsItem::getImplementation())->setElementDoubleClickEvent(idvalue, func);
}
