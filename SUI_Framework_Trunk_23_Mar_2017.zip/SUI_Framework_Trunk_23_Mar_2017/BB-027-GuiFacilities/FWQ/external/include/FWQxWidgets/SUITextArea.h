//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::TextArea.
// !\description Header file for class SUI::TextArea.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUITEXTAREA_H
#define SUITEXTAREA_H

#include "FWQxWidgets/SUIWidget.h"
#include "FWQxCore/SUIIErrorMode.h"
#include "FWQxCore/SUIIText.h"
#include "FWQxCore/SUIIColorable.h"
#include "FWQxCore/SUIIAlignable.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief Specific Interface for the TextArea Widget
 */
class SUI_SHARED_EXPORT TextArea : public Widget, public IText, public IColorable, public IErrorMode, public IAlignable
{
public:
    virtual ~TextArea();

    /*!
     * \brief setAutoScroll
     * This function sets the scroll feature of a textarea on or off
     * \param scroll - Sets the scroll feature of a textarea on or off
     */
    virtual void setAutoScroll(bool scroll) = 0;

    /*!
     * \brief getAutoScroll
     * Returns true if the autoscroll feature of a textarea is enable. False if not
     * \return - The scroll feature of a textarea
     */
    virtual bool getAutoScroll() const = 0;

    /*!
     * \brief setReadonly
     * Set the widgets read-only mode
     * \param readOnly Set the read-only mode.
     */
    virtual void setReadonly(bool readOnly) = 0;

    /*!
    * \brief getReadonly
    * Returns true if the textarea widget is in read-only mode
    * \return the read-only mode.
    */
    virtual bool getReadonly() const = 0;

protected:
    TextArea();
};
}

#endif // SUITEXTAREA_H
