//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::PlotItem.
// !\description Header file for class SUI::PlotItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUIPLOTITEM_H
#define SUIPLOTITEM_H

#include "FWQxCore/SUIPlotAxisEnum.h"
#include "FWQxCore/SUIObject.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief Class for defining custom RGB colors for a plot item
 */
class SUI_SHARED_EXPORT PlotItemCustomColor {

public:
    PlotItemCustomColor(const int red, const int green, const int blue, const int alpha = 255);
    int getRed() const;
    int getGreen() const;
    int getBlue() const;
    int getAlpha() const;
    void setRed(const int value);
    void setGreen(const int value);
    void setBlue(const int value);
    void setAlpha(const int value);
    bool operator==(const PlotItemCustomColor &color) const;
private:
    int mRed;
    int mGreen;
    int mBlue;
    int mAlpha;
};

/*!
 * \ingroup FWQxWidgets
 *
 * \brief Base class for items on the plot widget
 */
class PlotWidget;
class SUI_SHARED_EXPORT PlotItem : public Object
{
public:
    virtual ~PlotItem();
    /*!
     * \brief attach
     * Attach the item to a plot.
     * \param plot - SUI::PlotWidget
     * \note Call to replot on Plot widget is required to see the changes
     */
    virtual void attach(PlotWidget *plot) = 0;

    /*!
     * \brief detach
     * This method detaches a PlotItem from any Plot it has been associated with.
     * \note Call to replot on Plot widget is required to see the changes
     */
    virtual void detach() = 0;

    /*!
     * \brief setTitle
     * Set a new Title for the item
     * \param title - std::string
     * \note Call to replot on Plot widget is required to see the changes
     */
    virtual void setTitle(const std::string &title) = 0;

    /*!
     * \brief getTitle
     * Returns Title of the item
     * \return std::string
     */
    virtual std::string getTitle() const = 0;

    /*!
     * \brief getZ
     * Returns the Z value
     * \return double
     */
    virtual double getZ() const = 0;

    /*!
     * \brief setZ
     * Set the Z value.Plot items are painted in increasing z-order.
     * \param z
     * \note Call to replot on Plot widget is required to see the changes
     */
    virtual void setZ(double z) = 0;

    /*!
     * \brief show
     * Show the plot item
     * \note Call to replot on Plot widget is required to see the changes
     */
    virtual void show() = 0;

    /*!
     * \brief hide
     * Hide the plot item
     * \note Call to replot on Plot widget is required to see the changes
     */
    virtual void hide() = 0;

    /*!
     * \brief setAxes
     * Set X and Y axis. The item will painted according to the coordinates of its Axes.
     * \param xAxis - X Axis(PlotAxisEnum::PlotAxis)
     * \param yAxis - Y Axis(PlotAxisEnum::PlotAxis)
     * \note Call to replot on Plot widget is required to see the changes
     */
    virtual void setAxes(PlotAxisEnum::PlotAxis xAxis, PlotAxisEnum::PlotAxis yAxis) = 0;

    /*!
     * \brief setXAxis
     * Set the X Axis.The item will painted according to the coordinates its Axes.
     * \param xAxis - X Axis(PlotAxisEnum::PlotAxis)
     * \note Call to replot on Plot widget is required to see the changes
     */
    virtual void setXAxis(PlotAxisEnum::PlotAxis xAxis) = 0;

    /*!
     * \brief getXAxis
     * Returns the X Axis.
     * \return PlotAxisEnum::PlotAxis
     */
    virtual PlotAxisEnum::PlotAxis getXAxis() const = 0;

    /*!
     * \brief setYAxis
     * Set the Y Axis.The item will painted according to the coordinates its Axes.
     * \param yAxis - Y Axis(PlotAxisEnum::PlotAxis)
     * \note Call to replot on Plot widget is required to see the changes
     */
    virtual void setYAxis(PlotAxisEnum::PlotAxis axis) = 0;

    /*!
     * \brief getYAxis
     * Returns the Y Axis.
     * \return PlotAxisEnum::PlotAxis
     */
    virtual PlotAxisEnum::PlotAxis getYAxis() const = 0;

    /*!
     * \brief setCustomPenColor
     * Sets the (custom) RGB color of the pen
     * \param color
     */
    virtual void setCustomPenColor( const SUI::PlotItemCustomColor color) = 0;

    /*!
     * \brief getCustomPenColor
     * Returns the pen's RGB color
     * \return
     */
    virtual SUI::PlotItemCustomColor getCustomPenColor() const = 0;

    //Interface functions
    virtual void setEnabled(bool value);
    virtual bool isEnabled() const;
    virtual std::string getId() const;
    virtual void setId(const std::string &value);
    virtual void setVisible(bool on) = 0;
    virtual bool isVisible () const = 0;

protected:
    PlotItem(const SUI::ObjectType::Type &type, void *implementation = NULL);
    friend class ObjectFactory;
    void* getImplementation() const;
    void setImplementation(void*);
    int toQwtAxis(SUI::PlotAxisEnum::PlotAxis axis) const;
    SUI::PlotAxisEnum::PlotAxis toSuiAxisEnum(int axis) const;

private:
    std::string id;
    bool enabled;
    void *implementation;
};
} // namespace SUI

#endif //SUISUIPLOTITEM_H
