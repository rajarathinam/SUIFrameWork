#!/bin/bash
#
#-------------------------------------------------------------------------------
#   runCppLint.sh
#   
#   A script to run the static code checker Cpp lint
#-------------------------------------------------------------------------------

#Go to the current directory
cd "${0%/*}"

# Variables
CPPLINT_PATH=$(pwd)/../cpplint/cpplint.py
WORKING_DIRECTORY=$(pwd)/../../BB-027-GuiFacilities/
EXPORT_PATH=$(pwd)/../../cpplint_report.txt
FILTER=-whitespace,-build/header_guard
FILETYPES=h,hpp,cpp

# Functions
function print_message(){
      echo "******************************"
      echo "**** $1"
      echo "******************************"
}

# script
if [ "$1" == "help" ] || [ "$1" == "?" ]; then
      echo "******************************"
      echo "**** HELP"
      echo "****"
      echo "**** help: Displays this help documentation."
      echo "******************************"
      exit
fi

print_message "Starting analysis"

$CPPLINT_PATH --counting=detailed --filter=$FILTER --extensions=$FILETYPES \
    $( find $WORKING_DIRECTORY -name \*.hpp -or -name \*.cpp -or -name \*.h) \
    2>$EXPORT_PATH

grep -e "Category" $EXPORT_PATH

ERRORS_TOTAL=$(grep -e "Total error" $EXPORT_PATH)
ERRORS_TOTAL=${ERRORS_TOTAL##* }

if [ "$ERRORS_TOTAL" == "0" ]; then
      print_message "analysis success!"
      exit 0
else
      print_message "analysis failed, $ERRORS_TOTAL messages found!"
      exit 1
fi

