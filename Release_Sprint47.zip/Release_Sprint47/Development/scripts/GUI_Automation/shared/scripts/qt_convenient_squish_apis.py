# -*- coding: utf-8 -*-

import logger
import squish
import __builtin__

import native_squish_apis

GENERAL_TIMEOUT_VALUE = 2


def click_button(object_name='', time_out=GENERAL_TIMEOUT_VALUE):
    """
    This function is a wrapper for Squish's 'clickButton' Qt convenient API.
    This function comes handy while trying click an object using it's symbolic
    name. Will not help in clicking object using it's reference
    """
    # Check if object_name is blank
    if object_name == '':
        raise Exception("qt_convenient_squish_apis.click_button(): "
                        "object name (symbolic name) cannot be empty")

    try:
        # Wait for the object and get the object reference
        btn_obj_reference = native_squish_apis.wait_for_object(object_name,
                                                               time_out)
        # Click on the obtained object reference
        squish.clickButton(btn_obj_reference)
        # Write a squish log message
        logger.write_log("'" + str(object_name) + "' object clicked.")

    except LookupError:
        # Write a failure message to the squish log
        raise Exception("qt_convenient_squish_apis.click_button(): '"
                        + str(object_name) + "' object not found on the "
                        "screen")

    except Exception as arguments_list:
        # Write a failure message to the squish log
        raise Exception("qt_convenient_squish_apis.click_button(): "
                        + str(arguments_list.message))


def set_window_state(window_object='', set_state_to='',
                     time_out=GENERAL_TIMEOUT_VALUE):
    """
    This is a wrapper for Squish's 'setWindowState' Qt convenient
    API
    """
    # Check if mandatory arguments are passed
    if window_object == '' or set_state_to == '':
        raise Exception("qt_convenient_squish_apis.set_window_state(): "
                        "Both the parameters are mandatory")

    try:
        # Declare a dictionary to hold different states of the window
        window_states_dictionary = {
                            'FullScreen': squish.WindowState.Fullscreen,
                            'Maximize': squish.WindowState.Maximize,
                            'Minimize': squish.WindowState.Minimize,
                            'Normal': squish.WindowState.Normal}
        # Wait for the object and get the object reference
        window_obj_reference = native_squish_apis.wait_for_object(
                                        window_object, time_out)
        # Set the window status to required state
        squish.setWindowState(window_obj_reference,
                              window_states_dictionary[set_state_to])
        # Write a squish log message
        logger.write_log("'" + str(window_object) + "' window state set to '"
                         + str(set_state_to) + "' state")

    except LookupError:
        # Write a failure message to the squish log
        raise Exception("qt_convenient_squish_apis.set_window_state(): '"
                        + str(window_object) + "' object not found on the "
                        "screen")

    except Exception as arguments_list:
        # Write a failure message to the squish log
        raise Exception("qt_convenient_squish_apis.set_window_state(): "
                        + str(arguments_list.message))


def scroll_up_or_down(scroll_obj='', up_or_down='', scroll_by_step=False,
                      full=False):
    """
    This is a wrapper for Squish's 'scrollTo' Qt convenient API.
    And additional functionalities are also added with it to suit
    framework requirements
    """
    # Raise exception if required arguments are not passed
    if up_or_down == '' or scroll_obj == '':
        raise Exception("qt_convenient_squish_apis.scroll_up_or_down(): "
                        "Insufficient arguments")
    try:
        # If the passed scroll object does not object exist, write log
        # and return
        if not native_squish_apis.object_exists(scroll_obj,
                                                GENERAL_TIMEOUT_VALUE):
            logger.write_log("'" + str(scroll_obj) + "' scroll object does "
                             "not exist in the screen")
            return False
        
        # Variable to track if scrolled fully
        end_of_scroll = False
        # Get the scroll object reference
        scroll_obj_ref = native_squish_apis.wait_for_object(scroll_obj,
                                                        GENERAL_TIMEOUT_VALUE)
        # Get the current position of the scroll-bar slider
        current_pos = __builtin__.int(scroll_obj_ref.value)
        # Get the 'pageStep' property value of the scroll-bar object
        page_step = __builtin__.int(scroll_obj_ref.pageStep)
        # Get the 'singleStep' property value of the scroll-bar object
        single_step = __builtin__.int(scroll_obj_ref.singleStep)
        # Get the minimum range value of the scroll-bar object
        min_value = __builtin__.int(scroll_obj_ref.minimum)
        # Get the maximum range value of the scroll-bar object
        max_value = __builtin__.int(scroll_obj_ref.maximum)

        # If user wants to scroll by step, assign scroll-bar's single step
        # value to 'step'
        if scroll_by_step == True:
            step = single_step
            value = 'step'
        # If user wants to scroll by step, assign scroll-bar's page step
        # value to 'step'
        elif scroll_by_step == False:
            step = page_step
            value = 'page'
        else:
            raise Exception("'" + str(scroll_by_step) + "' is an invalid "
                            "argument. Please boolean either True or boolean"
                            " False only.")

        if up_or_down.upper() == 'DOWN':
            # If user wants to scroll down fully, set the new position value
            # to maximum range value of the scroll-bar object
            if full == True:
                to_pos = max_value
            # If current position of the scroll-bar is equal to maximum
            # range value of the scroll-bar, it's end of scroll-bar
            elif current_pos == max_value:
                end_of_scroll = True
            # If the sum of current position value and page step value of the
            # scroll-bar is less than or equal to maximum range value of the 
            # scroll-bar, use the sum as new position value
            elif current_pos + step <= max_value:
                to_pos = current_pos + step
            # If the sum of current position value and page step value of the
            # scroll-bar is greater than maximum range value of the scroll-bar
            # use the max range value as new position value
            elif current_pos + step > max_value:
                to_pos = max_value
        
        elif up_or_down.upper() == 'UP':
            # If user wants to scroll up fully, set the new position value
            # to minimum range value of the scroll-bar object
            if full == True:
                to_pos = min_value
            # If current position of the scroll-bar is equal to minimum
            # range value of the scroll-bar, it's end of scroll-bar
            elif current_pos == min_value:
                end_of_scroll = True
            # If the difference of current position value and page step value
            # of the scroll-bar is greater than or equal to min range value of
            # the scroll-bar, use the difference as new position value
            elif current_pos - step >= min_value:
                to_pos = current_pos - step
            # If the difference of current position value and page step value
            # of the scroll-bar is less than min range value of the scroll-bar
            # use the min range value as new position value
            elif current_pos - step < min_value:
                to_pos = min_value

        else:
            raise Exception("'" + str(up_or_down) + "' is not a valid "
                            "argument. Please pass 'Down' or 'Up' only")
        
        # Call Squish's Qt convenient API 'scrollTo' if end of scroll has not
        # reached
        if end_of_scroll == False: 
            squish.scrollTo(':' + scroll_obj, to_pos)
        else:
            logger.write_log("'" + str(scroll_obj) + "' is scrolled '"
                             + str(up_or_down) + "' fully")
            return not end_of_scroll
        
        # Write a log message based on if request was for full scroll or not
        if full == False:
            logger.write_log("'" + str(scroll_obj) + "' object is scrolled '"
                             + str(up_or_down) + "' by one " + str(value))
        else:
            logger.write_log("'" + str(scroll_obj) + "' object is scrolled '"
                             + str(up_or_down) + "' fully")
            
        return not end_of_scroll
        
    except Exception as run_time_args:
        raise Exception("qt_convenient_squish_apis.scroll_up_or_down(): "
                        + str(run_time_args.message))


def mouse_click(object='', time_out=GENERAL_TIMEOUT_VALUE):
    """
    This function is a wrapper for Squish's 'mouseClick' Qt convenient API.
    This function comes handy while trying to click an object using it's
    reference.
    """
    try:
        # Wait for the object and get the object reference
        obj_reference = native_squish_apis.wait_for_object(object, time_out)
        # Call Squish's QT 'mouseClick' API
        squish.mouseClick(obj_reference)

    except Exception as runtime_args:
        raise Exception("qt_convenient_squish_apis.mouse_click(): "
                        + str(runtime_args.message))


def drag_and_drop(source_obj='', target_obj='', target_x_coord=0,
                  target_y_coord=0):
    """
    This function is wrapper function for Squish's 'dragAndDrop' Qt
    convenient API.
    """
    # Import general module within this function scope
    import general
    
    # Check if the object to be dragged is not blank
    if source_obj == '':
        raise Exception("qt_convenient_squish_apis.drag_and_drop(): "
                        "Object to be dragged should not be blank")
    
    try:
        # Get the reference of the object to be dragged
        source_obj_ref = native_squish_apis.wait_for_object(source_obj, 2)
        
        # Check if the object on to which the source object to be dragged is
        # not passed
        if target_obj == '':
            # Get editor form object reference
            target_obj_ref = general.get_children_of_type(
                                    'FBE_MainWindow_SubContainer_EditorForm',
                                    'WidgetController', 1)[0]
        else:
            # Get target object reference
            target_obj_ref = native_squish_apis.wait_for_object(target_obj, 2)
        
        if target_x_coord == 0 and target_y_coord == 0:
            # Get target object's x and y coordinates
            target_obj_x_coord = __builtin__.int(target_obj_ref.x)
            target_obj_y_coord = __builtin__.int(target_obj_ref.y)
            # Get target object's height and width and divide it by 4
            # to get target x and y coordinates
            target_x_coord = ((__builtin__.int(target_obj_ref.height) / 4) +
                              target_obj_x_coord)
            target_y_coord = ((__builtin__.int(target_obj_ref.width) / 4) +
                              target_obj_y_coord)
        
        # Call 'dragAndDrop' squish API
        squish.dragAndDrop(source_obj_ref, 7, 7, target_obj_ref,
                           target_x_coord, target_y_coord,
                           squish.Qt.CopyAction)
        
    except Exception as run_time_args:
        raise Exception('qt_convenient_squish_apis.drag_and_drop(): '
                        + str(run_time_args.message))
    


def type(obj_name='', key_board_input=''):
    """
    This function is a wrapper for Squish's 'type' Qt convenient API.
    This function is used to type the specified text or keyboard input
    (as if the user had used the keyboard) into the passed object.
    """
    # Raise exception if obj_name or key_board_input is blank
    if(obj_name == '' or key_board_input == ''):
        raise Exception("qt_convenient_squish_apis.type(): Object name on "
                        "which keyboard input needs to be given should not "
                        " be blank.")

    try:
        # Wait for the object and get the object reference
        obj_ref = native_squish_apis.wait_for_object(obj_name,
                                                     GENERAL_TIMEOUT_VALUE)
        # Call 'type' Squish API
        squish.type(obj_ref, key_board_input)

    except Exception as type_runtime_args:
        raise Exception("qt_convenient_squish_apis.type(): "
                        + str(type_runtime_args.message))


def double_click(obj_name, x_coord=0, y_coord=0,
                 time_out=GENERAL_TIMEOUT_VALUE):
    """
    This function is a wrapper for Squish's 'doubleClick' Qt convenient API.
    This function double-clicks the mouse on the objectOrName widget at
    position x and y (in the objectOrName widget's coordinates) using the
    specified button and the modifierState modifier.
    """
    try:
        # Wait for the object and get the object reference
        obj_reference = native_squish_apis.wait_for_object(obj_name,
                                                           time_out)

        # If x and y coordinates are not passed, get the mid-point of the
        # object and consider the same for double clicking
        if x_coord == 0:
            obj_width = __builtin__.int(obj_reference.width)
            x_coord = obj_width / 2
        if y_coord == 0:
            obj_height = __builtin__.int(obj_reference.height)
            y_coord = obj_height / 2

        # Call 'doubleClick' Squish's Qt convenient API
        squish.doubleClick(obj_reference, x_coord, y_coord,
                           squish.Qt.NoModifier,
                           squish.MouseButton.LeftButton)

    except Exception as runtime_args:
        raise Exception("qt_convenient_squish_apis.double_click(): "
                        + str(runtime_args.args))


def send_event(event_name, object_Name='', time_out=GENERAL_TIMEOUT_VALUE):
    """
    This function is a wrapper for 'sendEvent' Squish's Qt 
    convenient API.
    """
    try:
        # Wait for the object and get the object reference
        obj_reference = native_squish_apis.wait_for_object(object_Name,
                                                           time_out)
        # Call Squish's QT 'sendEvent' API
        squish.sendEvent(event_name, obj_reference)

    except Exception as runtime_args:
        raise Exception("qt_convenient_squish_apis.send_event(): "
                        + str(runtime_args.args))


def double_click_item(object_name='', item_text='', x_coord=0, y_coord=0):
    """
    This function is a wrapper for 'doubleClickItem' Squish's Qt 
    convenient API.
    """
    try:
        # Get the reference of the object
        obj_ref = native_squish_apis.wait_for_object(object_name)
        # Call 'doubleClickItem' Squish API
        squish.doubleClickItem(obj_ref, item_text, x_coord, y_coord,
                               squish.Qt.NoModifier,
                               squish.MouseButton.LeftButton)
        
    except Exception as dci_runtime_args:
        raise Exception("qt_convenient_squish_apis.double_click_item(): "
                        + str(dci_runtime_args.message))


def click_item(object_name='', item_identifier='', x_coord=0, y_coord=0):
    """
    This function is a wrapper for 'clickItem' Squish's Qt 
    convenient API.
    """
    try:
        # Get the reference of the object
        obj_ref = native_squish_apis.wait_for_object(object_name)
        # Call 'clickItem' Squish API
        squish.clickItem(obj_ref, item_identifier, x_coord, y_coord,
                         squish.Qt.NoModifier, squish.MouseButton.LeftButton)
        
    except Exception as ci_runtime_args:
        raise Exception("qt_convenient_squish_apis.click_item(): "
                        + str(ci_runtime_args))


def activate_item(container_obj='', item_text=''):
    """
    This function is a wrapper for 'activateItem' Squish's Qt 
    convenient API.
    """
    try:
        # Get the reference of the object
        obj_ref = native_squish_apis.wait_for_object(container_obj)
        # Call 'activateItem' Squish API
        squish.activateItem(obj_ref, item_text)
        
    except Exception as ai_runtime_args:
        raise Exception('qt_convenient_squish_apis.activate_item(): '
                        + str(ai_runtime_args.message))


def open_context_menu(object_name='', x_coord=0, y_coord=0, item_identifier=''):
    """
    This function is a wrapper for 'clickItem' Squish's Qt 
    convenient API.
    """
    try:
        item_identifier = 0
        # Call 'clickItem' Squish API
        squish.openContextMenu(native_squish_apis.wait_for_object(object_name),
                               x_coord, y_coord, item_identifier)

    except Exception as ci_runtime_args:
        raise Exception("qt_convenient_squish_apis.click_item(): "
                        + str(ci_runtime_args))
#===============================Revision History==============================
# Modified By       Modified On     Modification Reason
# Vasanth S N       30-May-2017     Initial creation of the module with
#                                   'click_button' and 'set_window_state' APIs
# Vasanth S N       12-Jun-2017     1. Added 'scroll_up_or_down' API
#                                   2. Updated 'click_button' API logic to
#                                      get the object reference
#                                   3. Replaced squish.waitForObject with
#                                      native_squish_apis.wait_for_object API
# Girish Nair       23-Jun-2017     Implemented PEP8 coding guidelines
#					29-Jun-2017		1. Added 'type_object_value' API
#									2. Added 'send_event' API
#									3. Added 'click_on_item' API
# Girish Nair       28-Jul-2017     Added method open_context_menu()
#=============================================================================