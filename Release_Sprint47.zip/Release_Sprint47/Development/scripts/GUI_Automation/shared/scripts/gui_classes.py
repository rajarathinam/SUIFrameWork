# -*- coding: utf-8 -*-

import squishinfo
import os

GUI_ROOT_FOLDER = "GUI_Automation"


class CommonProperties():
    """
    This class holds and initiates the property objects, present under 
    'Properties' column in editor form, which are common across all 
    widgets.
    """
    def __init__(self):
        self.xpos = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' type='QSpinBox' unnamed='1' visible='1'}"
        self.ypos = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='2' type='QSpinBox' unnamed='1' visible='1'}"
        self.width = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='3' type='QSpinBox' unnamed='1' visible='1'}"
        self.visible = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' type='QComboBox' unnamed='1' visible='1'}"
        self.stylesheetclass = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='2' type='QComboBox' unnamed='1' visible='1'}"
        self.enable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='3' type='QComboBox' unnamed='1' visible='1'}"
        self.moveable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='4' type='QComboBox' unnamed='1' visible='1'}"
        self.sizeable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='5' type='QComboBox' unnamed='1' visible='1'}"
        self.tooltipenable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='8' type='QComboBox' unnamed='1' visible='1'}"
        self.id = "type='QModelIndex'"
        self.menu = "type='QModelIndex'"
        self.menuitem = "type='QModelIndex'"
        self.tooltip = "type='QModelIndex'"


class BusyIndicator(CommonProperties):
    """
    This class holds and initiates the property objects, present under 
    'Properties' column in editor form, for 'BusyIndicator' widget.
    It inherits 'CommonProperties' super class attributes.
    """
    def __init__(self):
        CommonProperties.__init__(self)
        self.widgettype = "CustomLabel"
        self.treeviewname = "bic"
        self.enable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='2' type='QComboBox' unnamed='1' visible='1'}"
        self.moveable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='3' type='QComboBox' unnamed='1' visible='1'}"
        self.sizeable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='4' type='QComboBox' unnamed='1' visible='1'}"
        self.tooltipenable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='5' type='QComboBox' unnamed='1' visible='1'}"
        self.stylesheetclass = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QComboBox' unnamed='1' visible='1'}"
        self.busyindicatorimage = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='7' type='QComboBox' unnamed='1' visible='1'}"
        self.properties_map = {'xpos': 'x',
                               'ypos': 'y',
                               'width': 'width',
                               'visible': 'visible',
                               'enable': 'enabled',
                               'tooltip': 'toolTip',
                               'id': 'objectName'
                               }


class Button(CommonProperties):
    """
    This class holds and initiates the property objects, present under 
    'Properties' column in editor form, for 'Button' widget.
    It inherits 'CommonProperties' super class attributes.
    """
    def __init__(self):
        CommonProperties.__init__(self)
        self.widgettype = "CustomPushButton"
        self.treeviewname = "btn"
        self.bold = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QComboBox' unnamed='1' visible='1'}"
        self.tooltipenable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='7' type='QComboBox' unnamed='1' visible='1'}"
        self.alignment = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='8' type='QComboBox' unnamed='1' visible='1'}"
        self.imagedata = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' text='Select File' type='QPushButton' unnamed='1' visible='1'}"
        self.imagedatapressed = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='2' text='Select File' type='QPushButton' unnamed='1' visible='1'}"
        self.cellalignment = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='7' type='QComboBox' unnamed='1' visible='1'}"
        self.text = "type='QModelIndex'"
        self.taborder = "type='QModelIndex'"
        self.properties_map = {'xpos': 'x',
                               'ypos': 'y',
                               'width': 'width',
                               'visible': 'visible',
                               'enable': 'enabled',
                               'tooltip': 'toolTip',
                               'id': 'objectName',
                               'text': 'text',
                               'bold': 'font.bold',
                               'alignment': 'alignment'
                               }


class CheckBox(CommonProperties):
    """
    This class holds and initiates the property objects, present under 
    'Properties' column in editor form, for 'CheckBox' widget.
    It inherits 'CommonProperties' super class attributes.
    """
    def __init__(self):
        CommonProperties.__init__(self)
        self.widgettype = "QCheckBox"
        self.treeviewname = "cbx"
        self.checked = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='4' type='QComboBox' unnamed='1' visible='1'}"
        self.moveable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='5' type='QComboBox' unnamed='1' visible='1'}"
        self.sizeable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QComboBox' unnamed='1' visible='1'}"
        self.bold = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='7' type='QComboBox' unnamed='1' visible='1'}"
        self.text = "type='QModelIndex'"
        self.taborder = "type='QModelIndex'"
        self.properties_map = {'xpos': 'x',
                               'ypos': 'y',
                               'width': 'width',
                               'visible': 'visible',
                               'enable': 'enabled',
                               'tooltip': 'toolTip',
                               'id': 'objectName',
                               'text': 'text',
                               'bold': 'font.bold',
                               'checked': 'checked'
                               }


class CheckGroupBox(CommonProperties):
    """
    This class holds and initiates the property objects, present under 
    'Properties' column in editor form, for 'CheckGroupBox' widget.
    It inherits 'CommonProperties' super class attributes.
    """
    def __init__(self):
        CommonProperties.__init__(self)
        self.widgettype = "QGroupBox"
        self.treeviewname = "cgb"
        self.height = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='3' type='QSpinBox' unnamed='1' visible='1'}"
        self.width = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='4' type='QSpinBox' unnamed='1' visible='1'}"
        self.checked = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='4' type='QComboBox' unnamed='1' visible='1'}"
        self.moveable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='5' type='QComboBox' unnamed='1' visible='1'}"
        self.sizeable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QComboBox' unnamed='1' visible='1'}"
        self.bold = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='7' type='QComboBox' unnamed='1' visible='1'}"
        self.bgcolor = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='9' type='QComboBox' unnamed='1' visible='1'}"
        self.text = "type='QModelIndex'"
        self.taborder = "type='QModelIndex'"
        self.properties_map = {'xpos': 'x',
                               'ypos': 'y',
                               'width': 'width',
                               'visible': 'visible',
                               'enable': 'enabled',
                               'tooltip': 'toolTip',
                               'id': 'objectName',
                               'height': 'height',
                               'checked': 'checked',
                               'text': 'title',
                               'bold': 'font.bold',
                               'bgcolor': 'BGColor',
                               'alignment': 'alignment'
                               }


class ColorDrop(CommonProperties):
    """
    This class holds and initiates the property objects, present under 
    'Properties' column in editor form, for 'ColorDrop' widget.
    It inherits 'CommonProperties' super class attributes.
    """
    def __init__(self):
        CommonProperties.__init__(self)
        self.widgettype = "QComboBox"
        self.treeviewname = "cdb"
        self.color = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QComboBox' unnamed='1' visible='1'}"
        self.tooltipenable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='7' type='QComboBox' unnamed='1' visible='1'}"
        self.taborder = "type='QModelIndex'"
        self.properties_map = {'xpos': 'x',
                               'ypos': 'y',
                               'width': 'width',
                               'visible': 'visible',
                               'enable': 'enabled',
                               'tooltip': 'toolTip',
                               'id': 'objectName',
                               'color': 'currentText'
                               }


class DropDown(CommonProperties):
    """
    This class holds and initiates the property objects, present under 
    'Properties' column in editor form, for 'DropDown' widget.
    It inherits 'CommonProperties' super class attributes.
    """
    def __init__(self):
        CommonProperties.__init__(self)
        self.widgettype = "QComboBox"
        self.treeviewname = "ddb"
        self.bold = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QComboBox' unnamed='1' visible='1'}"
        self.color = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='7' type='QComboBox' unnamed='1' visible='1'}"
        self.bgcolor = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='9' type='QComboBox' unnamed='1' visible='1'}"
        self.text = "type='QModelIndex'"
        self.taborder = "type='QModelIndex'"
        self.properties_map = {'xpos': 'x',
                               'ypos': 'y',
                               'width': 'width',
                               'visible': 'visible',
                               'enable': 'enabled',
                               'tooltip': 'toolTip',
                               'id': 'objectName',
                               'text': 'currentText',
                               'bgcolor': 'BGColor',
                               'bold': 'font.bold'
                               }


class GroupBox(CommonProperties):
    """
    This class holds and initiates the property objects, present under 
    'Properties' column in editor form, for 'GroupBox' widget.
    It inherits 'CommonProperties' super class attributes.
    """
    def __init__(self):
        CommonProperties.__init__(self)
        self.widgettype = "QGroupBox"
        self.treeviewname = "gbx"
        self.height = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='3' type='QSpinBox' unnamed='1' visible='1'}"
        self.width = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='4' type='QSpinBox' unnamed='1' visible='1'}"
        self.hoverbgcolor = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='5' type='QComboBox' unnamed='1' visible='1'}"
        self.sizeable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QComboBox' unnamed='1' visible='1'}"
        self.bold = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='7' type='QComboBox' unnamed='1' visible='1'}"
        self.bgcolor = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='9' type='QComboBox' unnamed='1' visible='1'}"
        self.hover = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='10' type='QComboBox' unnamed='1' visible='1'}"
        self.text = "type='QModelIndex'"
        self.properties_map = {'xpos': 'x',
                               'ypos': 'y',
                               'width': 'width',
                               'height': 'height',
                               'visible': 'visible',
                               'enable': 'enabled',
                               'tooltip': 'toolTip',
                               'id': 'objectName',
                               'text': 'title',
                               'bold': 'font.bold',
                               'bgcolor': 'BGColor'
                               }


class GraphicsView(CommonProperties):
    """
    This class holds and initiates the property objects, present under 
    'Properties' column in editor form, for 'GraphicsView' widget.
    It inherits 'CommonProperties' super class attributes.
    """
    def __init__(self):
        CommonProperties.__init__(self)
        self.widgettype = "CustomGraphicsView"
        self.treeviewname = "imv"
        self.height = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='3' type='QSpinBox' unnamed='1' visible='1'}"
        self.width = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='4' type='QSpinBox' unnamed='1' visible='1'}"
        self.scrollbars = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QComboBox' unnamed='1' visible='1'}"
        self.autofitbg = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='7' type='QComboBox' unnamed='1' visible='1'}"
        self.zoomstyle = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='8' type='QComboBox' unnamed='1' visible='1'}"
        self.scrollzoom = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='9' type='QComboBox' unnamed='1' visible='1'}"
        self.borderon = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='10' type='QComboBox' unnamed='1' visible='1'}"
        self.tooltipenable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='11' type='QComboBox' unnamed='1' visible='1'}"
        self.properties_map = {'xpos': 'x',
                               'ypos': 'y',
                               'width': 'width',
                               'height': 'height',
                               'visible': 'visible',
                               'enable': 'enabled',
                               'tooltip': 'toolTip',
                               'id': 'objectName'
                               }


class Label(CommonProperties):
    """
    This class holds and initiates the property objects, present under 
    'Properties' column in editor form, for 'Label' widget.
    It inherits 'CommonProperties' super class attributes.
    """
    def __init__(self):
        CommonProperties.__init__(self)
        self.widgettype = "QLabel"
        self.treeviewname = "lbl"
        self.fontsize = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QComboBox' unnamed='1' visible='1'}"
        self.bold = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='7' type='QComboBox' unnamed='1' visible='1'}"
        self.color = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='8' type='QComboBox' unnamed='1' visible='1'}"
        self.tooltipenable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='9' type='QComboBox' unnamed='1' visible='1'}"
        self.bgcolor = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='10' type='QComboBox' unnamed='1' visible='1'}"
        self.propscientific = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='11' type='QComboBox' unnamed='1' visible='1'}"
        self.alignment = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='12' type='QComboBox' unnamed='1' visible='1'}"
        self.text = "type='QModelIndex'"
        self.properties_map = {'xpos': 'x',
                               'ypos': 'y',
                               'width': 'width',
                               'visible': 'visible',
                               'enable': 'enabled',
                               'tooltip': 'toolTip',
                               'id': 'objectName',
                               'text': 'text',
                               'bold': 'font.bold',
                               'fontsize': 'font.pointSize',
                               'bgcolor': 'BGColor',
                               'alignment': 'alignment',
                               'color': 'color'
                               }


class LineEdit(CommonProperties):
    """
    This class holds and initiates the property objects, present under 
    'Properties' column in editor form, for 'LineEdit' widget.
    It inherits 'CommonProperties' super class attributes.
    """
    def __init__(self):
        CommonProperties.__init__(self)
        self.widgettype = "QLineEdit"
        self.treeviewname = "lne"
        self.bold = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QComboBox' unnamed='1' visible='1'}"
        self.color = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='7' type='QComboBox' unnamed='1' visible='1'}"
        self.bgcolor = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='9' type='QComboBox' unnamed='1' visible='1'}"
        self.alignment = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='10' type='QComboBox' unnamed='1' visible='1'}"
        self.placeholdertext = "type='QModelIndex'"
        self.regularexpression = "type='QModelIndex'"
        self.regexptip = "type='QModelIndex'"
        self.text = "type='QModelIndex'"
        self.taborder = "type='QModelIndex'"
        self.properties_map = {'xpos': 'x',
                               'ypos': 'y',
                               'width': 'width',
                               'visible': 'visible',
                               'enable': 'enabled',
                               'tooltip': 'toolTip',
                               'id': 'objectName',
                               'text': 'text',
                               'bold': 'font.bold',
                               'bgcolor': 'BGColor',
                               'color': 'color',
                               'alignment': 'alignment',
                               'placeholder': 'placeholderText'
                               }


class ListView(CommonProperties):
    """
    This class holds and initiates the property objects, present under 
    'Properties' column in editor form, for 'ListView' widget.
    It inherits 'CommonProperties' super class attributes.
    """
    def __init__(self):
        CommonProperties.__init__(self)
        self.widgettype = "QListWidget"
        self.treeviewname = "lsv"
        self.height = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='3' type='QSpinBox' unnamed='1' visible='1'}"
        self.width = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='4' type='QSpinBox' unnamed='1' visible='1'}"
        self.rowcount = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='5' type='QSpinBox' unnamed='1' visible='1'}"
        self.sortingorder = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='5' type='QComboBox' unnamed='1' visible='1'}"
        self.sizeable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QComboBox' unnamed='1' visible='1'}"
        self.selectbehavior = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='7' type='QComboBox' unnamed='1' visible='1'}"
        self.bold = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='8' type='QComboBox' unnamed='1' visible='1'}"
        self.tooltipenable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='9' type='QComboBox' unnamed='1' visible='1'}"
        self.filterstring = "type='QModelIndex'"
        self.text = "type='QModelIndex'"
        self.taborder = "type='QModelIndex'"
        self.properties_map = {'xpos': 'x',
                               'ypos': 'y',
                               'width': 'width',
                               'height': 'height',
                               'visible': 'visible',
                               'enable': 'enabled',
                               'tooltip': 'toolTip',
                               'id': 'objectName',
                               'bold': 'font.bold'
                               }


class PlotWidget(CommonProperties):
    """
    This class holds and initiates the property objects, present under 
    'Properties' column in editor form, for 'PlotWidget' widget.
    It inherits 'CommonProperties' super class attributes.
    """
    def __init__(self):
        CommonProperties.__init__(self)
        self.widgettype = "QwtPlot"
        self.treeviewname = "plw"
        self.height = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='3' type='QSpinBox' unnamed='1' visible='1'}"
        self.width = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='4' type='QSpinBox' unnamed='1' visible='1'}"
        self.color = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QComboBox' unnamed='1' visible='1'}"
        self.tooltipenable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='7' type='QComboBox' unnamed='1' visible='1'}"
        self.bgcolor = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='8' type='QComboBox' unnamed='1' visible='1'}"
        self.hover = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='9' type='QComboBox' unnamed='1' visible='1'}"
        self.zoom = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='10' type='QComboBox' unnamed='1' visible='1'}"
        self.xaxisscale = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='11' type='QComboBox' unnamed='1' visible='1'}"
        self.properties_map = {'xpos': 'x',
                               'ypos': 'y',
                               'width': 'width',
                               'height': 'height',
                               'visible': 'visible',
                               'enable': 'enabled',
                               'tooltip': 'toolTip',
                               'id': 'objectName',
                               'color': 'color',
                               'bgcolor': 'BGColor'
                               }


class ProgressBar(CommonProperties):
    """
    This class holds and initiates the property objects, present under 
    'Properties' column in editor form, for 'ProgressBar' widget.
    It inherits 'CommonProperties' super class attributes.
    """
    def __init__(self):
        CommonProperties.__init__(self)
        self.widgettype = "QProgressBar"
        self.treeviewname = "pgb"
        self.height = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='3' type='QSpinBox' unnamed='1' visible='1'}"
        self.width = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='4' type='QSpinBox' unnamed='1' visible='1'}"
        self.maxvalue = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='5' type='QSpinBox' unnamed='1' visible='1'}"
        self.minvalue = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QSpinBox' unnamed='1' visible='1'}"
        self.bold = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QComboBox' unnamed='1' visible='1'}"
        self.percentage = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='7' type='QComboBox' unnamed='1' visible='1'}"
        self.color = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='8' type='QComboBox' unnamed='1' visible='1'}"
        self.tooltipenable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='9' type='QComboBox' unnamed='1' visible='1'}"
        self.orientation = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='10' type='QComboBox' unnamed='1' visible='1'}"
        self.text = "type='QModelIndex'"
        self.properties_map = {'xpos': 'x',
                               'ypos': 'y',
                               'width': 'width',
                               'height': 'height',
                               'visible': 'visible',
                               'enable': 'enabled',
                               'tooltip': 'toolTip',
                               'id': 'objectName',
                               'maxvalue': 'maximum',
                               'minvalue': 'minimum',
                               'color': 'color',
                               'text': 'value',
                               'orientation': 'orientation'
                               }


class QuestionMark(CommonProperties):
    """
    This class holds and initiates the property objects, present under 
    'Properties' column in editor form, for 'QuestionMark' widget.
    It inherits 'CommonProperties' super class attributes.
    """
    def __init__(self):
        CommonProperties.__init__(self)
        self.widgettype = "CustomToolButton"
        self.treeviewname = "qmk"
        self.helpfile = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' text='Select File' type='QPushButton' unnamed='1' visible='1'}"
        self.tooltipenable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QComboBox' unnamed='1' visible='1'}"
        self.text = "type='QModelIndex'"
        self.taborder = "type='QModelIndex'"
        self.properties_map = {'xpos': 'x',
                               'ypos': 'y',
                               'width': 'width',
                               'visible': 'visible',
                               'enable': 'enabled',
                               'tooltip': 'toolTip',
                               'id': 'objectName'
                               }


class RadioButton(CommonProperties):
    """
    This class holds and initiates the property objects, present under 
    'Properties' column in editor form, for 'RadioButton' widget.
    It inherits 'CommonProperties' super class attributes.
    """
    def __init__(self):
        CommonProperties.__init__(self)
        self.widgettype = "QRadioButton"
        self.treeviewname = "rbn"
        self.checked = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='4' type='QComboBox' unnamed='1' visible='1'}"
        self.moveable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='5' type='QComboBox' unnamed='1' visible='1'}"
        self.sizeable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QComboBox' unnamed='1' visible='1'}"
        self.bold = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='7' type='QComboBox' unnamed='1' visible='1'}"
        self.text = "type='QModelIndex'"
        self.taborder = "type='QModelIndex'"
        self.properties_map = {'xpos': 'x',
                               'ypos': 'y',
                               'width': 'width',
                               'visible': 'visible',
                               'enable': 'enabled',
                               'tooltip': 'toolTip',
                               'id': 'objectName',
                               'bold': 'font.bold',
                               'checked': 'checked'
                               }


class SpinBox(CommonProperties):
    """
    This class holds and initiates the property objects, present under 
    'Properties' column in editor form, for 'SpinBox' widget.
    It inherits 'CommonProperties' super class attributes.
    """
    def __init__(self):
        CommonProperties.__init__(self)
        self.widgettype = "QSpinBox"
        self.treeviewname = "isb"
        self.stepsizetofactor = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QComboBox' unnamed='1' visible='1'}"
        self.bold = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='7' type='QComboBox' unnamed='1' visible='1'}"
        self.alignment = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='9' type='QComboBox' unnamed='1' visible='1'}"
        self.setitemtype = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='10' type='QComboBox' unnamed='1' visible='1'}"
        self.stepsize = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='4' type='QSpinBox' unnamed='1' visible='1'}"
        self.maxvalue = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='5' type='QSpinBox' unnamed='1' visible='1'}"
        self.minvalue = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QSpinBox' unnamed='1' visible='1'}"
        self.text = "type='QModelIndex'"
        self.taborder = "type='QModelIndex'"
        self.properties_map = {'xpos': 'x',
                               'ypos': 'y',
                               'width': 'width',
                               'visible': 'visible',
                               'enable': 'enabled',
                               'tooltip': 'toolTip',
                               'id': 'objectName',
                               'stepsize': 'singleStep',
                               'bold': 'font.bold',
                               'maxvalue': 'maximum',
                               'minvalue': 'minimum',
                               'alignment': 'alignment'
                               }


class StateWidget(CommonProperties):
    """
    This class holds and initiates the property objects, present under 
    'Properties' column in editor form, for 'StateWidget' widget.
    It inherits 'CommonProperties' super class attributes.
    """
    def __init__(self):
        CommonProperties.__init__(self)
        self.widgettype = "QLabel"
        self.treeviewname = "stt"
        self.defaultstate = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' type='QComboBox' unnamed='1' visible='1'}"
        self.visible = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='2' type='QComboBox' unnamed='1' visible='1'}"
        self.stylesheetclass = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='3' type='QComboBox' unnamed='1' visible='1'}"
        self.enable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='4' type='QComboBox' unnamed='1' visible='1'}"
        self.checked = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='5' type='QComboBox' unnamed='1' visible='1'}"
        self.moveable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QComboBox' unnamed='1' visible='1'}"
        self.sizeable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='7' type='QComboBox' unnamed='1' visible='1'}"
        self.addstate = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' text='Add states' type='QPushButton' unnamed='1' visible='1'}"
        self.statelist = "type='QModelIndex'"
        self.imagelist = "type='QModelIndex'"
        self.properties_map = {'xpos': 'x',
                               'ypos': 'y',
                               'width': 'width',
                               'visible': 'visible',
                               'enable': 'enabled',
                               'tooltip': 'toolTip',
                               'id': 'objectName'
                               }


class TableWidget(CommonProperties):
    """
    This class holds and initiates the property objects, present under 
    'Properties' column in editor form, for 'TableWidget' widget.
    It inherits 'CommonProperties' super class attributes.
    """
    def __init__(self):
        CommonProperties.__init__(self)
        self.widgettype = "QTableView"
        self.treeviewname = "taw"
        self.height = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='3' type='QSpinBox' unnamed='1' visible='1'}"
        self.width = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='4' type='QSpinBox' unnamed='1' visible='1'}"
        self.rowheights = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='5' type='QSpinBox' unnamed='1' visible='1'}"
        self.columncount = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QSpinBox' unnamed='1' visible='1'}"
        self.rowcount = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='7' type='QSpinBox' unnamed='1' visible='1'}"
        self.propertynamecolumnwidths = "{columnIndex='0' container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' rowIndex='16' type='QSpinBox' unnamed='1' visible='1'}"
        self.columnwidths = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='10' type='QSpinBox' unnamed='1' visible='1'}"
        self.borderwidth = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='9' type='QSpinBox' unnamed='1' visible='1'}"
        self.listviewmode = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QComboBox' unnamed='1' visible='1'}"
        self.borderon = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='7' type='QComboBox' unnamed='1' visible='1'}"
        self.multiplerowselection = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='9' type='QComboBox' unnamed='1' visible='1'}"
        self.headerson = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='10' type='QComboBox' unnamed='1' visible='1'}"
        self.setitemtype = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' text='Set Item Type' type='QPushButton' unnamed='1' visible='1'}"
        self.sethorizonatlheader = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' text='Set Horizontal Header' type='QPushButton' unnamed='1' visible='1'}"
        self.setverticalheader = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' text='Set Vertical Header' type='QPushButton' unnamed='1' visible='1'}"
        self.text = "{column='1' container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' row='19' type='QModelIndex'}"
        self.taborder = "type='QModelIndex'"
        self.properties_map = {'xpos': 'x',
                               'ypos': 'y',
                               'width': 'width',
                               'height': 'height',
                               'visible': 'visible',
                               'enable': 'enabled',
                               'tooltip': 'toolTip',
                               'id': 'objectName'
                               }


class TabWidget(CommonProperties):
    """
    This class holds and initiates the property objects, present under 
    'Properties' column in editor form, for 'TabWidget' widget.
    It inherits 'CommonProperties' super class attributes.
    """
    def __init__(self):
        CommonProperties.__init__(self)
        self.widgettype = "CustomTabWidget"
        self.treeviewname = "tbw"
        self.height = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='3' type='QSpinBox' unnamed='1' visible='1'}"
        self.width = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='4' type='QSpinBox' unnamed='1' visible='1'}"
        self.currentabpage = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='5' type='QSpinBox' unnamed='1' visible='1'}"
        self.enable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='2' type='QComboBox' unnamed='1' visible='1'}"
        self.moveable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='3' type='QComboBox' unnamed='1' visible='1'}"
        self.sizeable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='4' type='QComboBox' unnamed='1' visible='1'}"
        self.tooltipenable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='5' type='QComboBox' unnamed='1' visible='1'}"
        self.stylesheetclass = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QComboBox' unnamed='1' visible='1'}"
        self.properties_map = {'xpos': 'x',
                               'ypos': 'y',
                               'width': 'width',
                               'height': 'height',
                               'visible': 'visible',
                               'enable': 'enabled',
                               'tooltip': 'toolTip',
                               'id': 'objectName'
                               }


class TextArea(CommonProperties):
    """
    This class holds and initiates the property objects, present under 
    'Properties' column in editor form, for 'TextArea' widget.
    It inherits 'CommonProperties' super class attributes.
    """
    def __init__(self):
        CommonProperties.__init__(self)
        self.widgettype = "QTextEdit"
        self.treeviewname = "txa"
        self.height = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='3' type='QSpinBox' unnamed='1' visible='1'}"
        self.width = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='4' type='QSpinBox' unnamed='1' visible='1'}"
        self.bold = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QComboBox' unnamed='1' visible='1'}"
        self.color = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='7' type='QComboBox' unnamed='1' visible='1'}"
        self.autoscroll = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='9' type='QComboBox' unnamed='1' visible='1'}"
        self.readonly = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='10' type='QComboBox' unnamed='1' visible='1'}"
        self.alignment = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='11' type='QComboBox' unnamed='1' visible='1'}"
        self.text = "type='QModelIndex'"
        self.taborder = "type='QModelIndex'"
        self.properties_map = {'xpos': 'x',
                               'ypos': 'y',
                               'width': 'width',
                               'height': 'height',
                               'visible': 'visible',
                               'enable': 'enabled',
                               'tooltip': 'toolTip',
                               'id': 'objectName',
                               'bold': 'font.bold',
                               'color': 'color',
                               'text': 'plainText',
                               'alignment': 'html'
                               }


class TreeView(CommonProperties):
    """
    This class holds and initiates the property objects, present under 
    'Properties' column in editor form, for 'TreeView' widget.
    It inherits 'CommonProperties' super class attributes.
    """
    def __init__(self):
        CommonProperties.__init__(self)
        self.widgettype = "QTreeView"
        self.treeviewname = "trv"
        self.height = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='3' type='QSpinBox' unnamed='1' visible='1'}"
        self.width = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='4' type='QSpinBox' unnamed='1' visible='1'}"
        self.sortingorder = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='5' type='QComboBox' unnamed='1' visible='1'}"
        self.sizeable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QComboBox' unnamed='1' visible='1'}"
        self.tooltipenable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='7' type='QComboBox' unnamed='1' visible='1'}"
        self.disableheader = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='8' type='QComboBox' unnamed='1' visible='1'}"
        self.treevwidgetedit = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' text='Treewidget Edit' type='QPushButton' unnamed='1' visible='1'}"
        self.text = "type='QModelIndex'"


class SvgWidget(CommonProperties):
    """
    This class holds and initiates the property objects, present under 
    'Properties' column in editor form, for 'SvgWidget' widget.
    It inherits 'CommonProperties' super class attributes.
    """
    def __init__(self):
        CommonProperties.__init__(self)
        self.widgettype = "QSvgWidget"
        self.treeviewname = "svg"
        self.height = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='3' type='QSpinBox' unnamed='1' visible='1'}"
        self.width = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='4' type='QSpinBox' unnamed='1' visible='1'}"
        self.tooltipenable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QComboBox' unnamed='1' visible='1'}"
        self.svgimage = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' text='Select File' type='QPushButton' unnamed='1' visible='1'}"
        self.svgfilename = "type='QModelIndex'"


class Container(CommonProperties):
    """
    This class holds and initiates the property objects, present under 
    'Properties' column in editor form, for 'Container' widget.
    It inherits 'CommonProperties' super class attributes.
    """
    def __init__(self):
        CommonProperties.__init__(self)
        self.widgettype = "QScrollArea"
        self.treeviewname = "cnt"
        self.height = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='3' type='QSpinBox' unnamed='1' visible='1'}"
        self.width = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='4' type='QSpinBox' unnamed='1' visible='1'}"
        self.enable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='2' type='QComboBox' unnamed='1' visible='1'}"
        self.moveable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='3' type='QComboBox' unnamed='1' visible='1'}"
        self.sizeable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='4' type='QComboBox' unnamed='1' visible='1'}"
        self.tooltipenable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='5' type='QComboBox' unnamed='1' visible='1'}"
        self.stylesheetclass = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QComboBox' unnamed='1' visible='1'}"
        self.taborder = "type='QModelIndex'"


class ScrollBar(CommonProperties):
    """
    This class holds and initiates the property objects, present under 
    'Properties' column in editor form, for 'ScrollBar' widget.
    It inherits 'CommonProperties' super class attributes.
    """
    def __init__(self):
        CommonProperties.__init__(self)
        self.widgettype = "QScrollBar"
        self.treeviewname = "scb"
        self.height = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='3' type='QSpinBox' unnamed='1' visible='1'}"
        self.width = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='4' type='QSpinBox' unnamed='1' visible='1'}"
        self.stepsize = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='5' type='QSpinBox' unnamed='1' visible='1'}"
        self.maxvalue = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QSpinBox' unnamed='1' visible='1'}"
        self.minvalue = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='7' type='QSpinBox' unnamed='1' visible='1'}"
        self.tooltipenable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QComboBox' unnamed='1' visible='1'}"
        self.orientation = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='7' type='QComboBox' unnamed='1' visible='1'}"


class DateTimeEdit(CommonProperties):
    """
    This class holds and initiates the property objects, present under 
    'Properties' column in editor form, for 'DateTimeEdit' widget.
    It inherits 'CommonProperties' super class attributes.
    """
    def __init__(self):
        CommonProperties.__init__(self)
        self.widgettype = "QDateTimeEdit"
        self.treeviewname = "dte"
        self.height = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='3' type='QSpinBox' unnamed='1' visible='1'}"
        self.width = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='4' type='QSpinBox' unnamed='1' visible='1'}"
        self.enable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='2' type='QComboBox' unnamed='1' visible='1'}"
        self.moveable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='3' type='QComboBox' unnamed='1' visible='1'}"
        self.sizeable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='4' type='QComboBox' unnamed='1' visible='1'}"
        self.tooltipenable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='5' type='QComboBox' unnamed='1' visible='1'}"
        self.stylesheetclass = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QComboBox' unnamed='1' visible='1'}"


class WebView(CommonProperties):
    """
    This class holds and initiates the property objects, present under 
    'Properties' column in editor form, for 'WebView' widget.
    It inherits 'CommonProperties' super class attributes.
    """
    def __init__(self):
        CommonProperties.__init__(self)
        self.widgettype = "HTML_Object"
        self.treeviewname = "wvw"
        self.height = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='3' type='QSpinBox' unnamed='1' visible='1'}"
        self.width = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='4' type='QSpinBox' unnamed='1' visible='1'}"
        self.zoomfactor = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='5' type='QSpinBox' unnamed='1' visible='1'}"
        self.tooltipenable = "{container=':FBE_MainWindow_PropertiesDisplayWindowWithScroll' occurrence='6' type='QComboBox' unnamed='1' visible='1'}"
        self.url = "type='QModelIndex'"
        self.html = "type='QModelIndex'"


class FormProperties(CommonProperties):
    """
    This class holds and initiates the property objects, present under
    'From Properties' window in FBE application.
    """
    def __init__(self):
        CommonProperties.__init__(self)
        self.height = "{container=':FBE_FormPropertiesPopup_PropertiesDisplayAreaWithScroll' occurrence='1' type='QSpinBox' unnamed='1' visible='1'}"
        self.width = "{container=':FBE_FormPropertiesPopup_PropertiesDisplayAreaWithScroll' occurrence='2' type='QSpinBox' unnamed='1' visible='1'}"

        self.suistylesheet = "{container=':FBE_FormPropertiesPopup_PropertiesDisplayAreaWithScroll' type='QComboBox' unnamed='1' visible='1'}"
        self.moveable = "{container=':FBE_FormPropertiesPopup_PropertiesDisplayAreaWithScroll' occurrence='2' type='QComboBox' unnamed='1' visible='1'}"
        self.sizeable = "{container=':FBE_FormPropertiesPopup_PropertiesDisplayAreaWithScroll' occurrence='3' type='QComboBox' unnamed='1' visible='1'}"
        self.hasbottombuttonbar = "{container=':FBE_FormPropertiesPopup_PropertiesDisplayAreaWithScroll' occurrence='4' type='QComboBox' unnamed='1' visible='1'}"
        self.hasbottomrightbuttonbar = "{container=':FBE_FormPropertiesPopup_PropertiesDisplayAreaWithScroll' occurrence='5' type='QComboBox' unnamed='1' visible='1'}"
        self.hasstatusbar = "{container=':FBE_FormPropertiesPopup_PropertiesDisplayAreaWithScroll' occurrence='6' type='QComboBox' unnamed='1' visible='1'}"
        self.tooltipenable = "{container=':FBE_FormPropertiesPopup_PropertiesDisplayAreaWithScroll' occurrence='7' type='QComboBox' unnamed='1' visible='1'}"

        self.menu = "{column='1' container=':FBE_FormPropertiesPopup_PropertiesDisplayAreaWithScroll' row='3' type='QModelIndex'}"
        self.menuitem = "{column='1' container=':FBE_FormPropertiesPopup_PropertiesDisplayAreaWithScroll' row='4' type='QModelIndex'}"
        self.suiversion = "{column='1' container=':FBE_FormPropertiesPopup_PropertiesDisplayAreaWithScroll' row='7' type='QModelIndex'}"
        self.suiname = "{column='1' container=':FBE_FormPropertiesPopup_PropertiesDisplayAreaWithScroll' row='8' type='QModelIndex'}"
        self.suidescription = "{column='1' container=':FBE_FormPropertiesPopup_PropertiesDisplayAreaWithScroll' row='9' type='QModelIndex'}"
        self.namespace = "{column='1' container=':FBE_FormPropertiesPopup_PropertiesDisplayAreaWithScroll' row='12' type='QModelIndex'}"
        self.classname = "{column='1' container=':FBE_FormPropertiesPopup_PropertiesDisplayAreaWithScroll' row='13' type='QModelIndex'}"
        self.tooltip = "{column='1' container=':FBE_FormPropertiesPopup_PropertiesDisplayAreaWithScroll' row='16' type='QModelIndex'}"


class GetPath():
    """
    This Class is used to get the path of the user provided folder name.
    Ex. GetPathInstance.get_path(testdata), will return the complete testdata
    path of currently running test case.
    "/home/adt/GUI_Automation/shared/testdata/FBE/
                        Table_Widget/FBE_Table_Widget_TC_132.tsv"
    """
    def __init__(self):
        try:
            self.shared = "/shared/"
            current_folder_name = ""
            list_of_folder_names_removed = []
            test_case_path = squishinfo.testCase.encode("utf-8")
            test_case_path_folders = test_case_path.split("/")
            while (GUI_ROOT_FOLDER != current_folder_name):
                current_folder_name = test_case_path_folders.pop()
                list_of_folder_names_removed.append(current_folder_name)
            root_folder_name = list_of_folder_names_removed.pop()
            test_case_path_folders.append(root_folder_name)
            self.root_path = '/'.join(test_case_path_folders)
            self.list_of_items = list_of_folder_names_removed[::-1]
            self.test_case_path = '/'.join(self.list_of_items)
        except Exception as run_time_args:
            raise Exception("Exception from GetPath()", run_time_args.message)

    def get_path(self, required_path):
        try:
            self.value = required_path
            # if the required_path value is none and raise an exception.
            if self.value == None:
                raise Exception("Required arguments are not provided...")
            # check if the required_path is set to testcase
            elif(self.value == "testcase"):
                complete_path = self.root_path + '/' + self.test_case_path
            # check if the required_path is set to images
            elif(self.value == "images"):
                complete_path = self.root_path + self.shared + "images/"
            # check if the required_path is set to scripts
            elif(self.value == "scripts"):
                complete_path = self.root_path + self.shared + "scripts/"
            # check if the required_path is set to root path
            elif(self.value == "root"):
                complete_path = self.root_path
            # call the private method
            self.__get_appropriate_folder_names()
            # check if the required_path is set to testdata
            if(self.value == "testdata"):
                complete_path = self.root_path + self.shared + "testdata/" + self.test_case_path
            # check if the required_path is set to test_results
            elif(self.value == "test_results"):
                complete_path = self.root_path + self.shared + "test_results/" + self.test_case_path
            # check if the required_path is set to verification_point
            elif(self.value == "verification_point"):
                complete_path = self.root_path + self.shared + "verification_point/" + self.test_case_path
            # check if the complete_path actually exists in the system and return it if true
            # or raise an exception if not.
            if(os.path.exists(complete_path)):
                return complete_path
            else:
                raise Exception("Path not found")
        except Exception as run_time_args:
            raise Exception("Exception from gui_classes.GetPath()", run_time_args.message)

    def __get_appropriate_folder_names(self):
        try:
            test_script_name = self.list_of_items.pop(-1)
            test_suite_name = self.list_of_items.pop(-1)
            test_suite_name = test_suite_name.replace("suite_", "")
            test_script_name = test_script_name.replace("tst_", "")
            self.list_of_items.append(test_suite_name)
            self.list_of_items.append(test_script_name)
            self.test_case_path = '/'.join(self.list_of_items)
        except Exception as run_time_args:
            raise Exception("Exception from GetPath()", run_time_args.message)


class GetName(GetPath):
    """
    This Class is used to get the Name of the user provided folder name.
    Ex. GetNameInstance.get_name(suite), will return the name of the current
        test suite.
    """
    def __init__(self):
        try:
            GetPath.__init__(self)
        except Exception as run_time_args:
            raise Exception("Exception from gui_classes.GetPath()", run_time_args.message)

    def get_name(self, required_folder_name):
        try:
            self.value = required_folder_name
            # if the required_folder_name value is none and raise an exception.
            if self.value == None:
                raise Exception("Required arguments are not provided...")
            # check if the required_folder_name is set to testcase
            if(self.value == "testcase"):
                return self.list_of_items.pop(-1)
            # check if the required_folder_name is set to suite
            elif(self.value == "suite"):
                return self.list_of_items.pop(-2)
            # check if the required_folder_name is set to application
            elif(self.value == "application"):
                return self.list_of_items.pop(-3)
        except Exception as run_time_args:
            raise Exception("Exception from gui_classes.GetName()", run_time_args.message)
