import test
import squish
import test
from collections import deque
import general
import logger
import os
import native_squish_apis
import qt_convenient_squish_apis

#dictionary to hold property name and value
property_dict = {}
#dictionary to hold all property name and value
all_widget_properties = {}
#dictionary to hold current property name and value
widget_properties = {}
#variable to check the menu item is opened or not
menu_item_opened = False
#max timeout value
MAX_TIME_OUT = 1


def go_to_menu_item(menu_bar_object_name, click_button_object, iDepth=5,
                    time_out=MAX_TIME_OUT):
    """Method is used to click on a particular menu item"""
    try:
        #verify the object of property exists
        if(native_squish_apis.object_exists(menu_bar_object_name)):
            #get the latest object properties of the given object
            latest_property_object = native_squish_apis.wait_for_object(
                                            menu_bar_object_name)
            #perform the mouse click operation on the menu bar object
            qt_convenient_squish_apis.mouse_click(latest_property_object)
            #method to get children object of a particular type
            children_object = general.get_children_of_type(
                        latest_property_object, "QAction", iDepth)
            #loop over the children objects
            for child_item in children_object:
                #find the exact match for the tool tip value
                if click_button_object in str(child_item.toolTip):
                    #get the latest object properties of the given object
                    child_item_value = native_squish_apis.wait_for_object(
                                            child_item)
                    #give the time for squish to wait for the next command
                    squish.snooze(time_out)
                    #perform the mouse click operation on the menu bar object
                    qt_convenient_squish_apis.mouse_click(child_item_value)
                    logger.write_log("Clicked on.. " + click_button_object)
                    #give the time for squish to wait for the next command
                    squish.snooze(time_out)
                    break
    except Exception as run_time_args:
        raise Exception("general.go_to_menu_item(): "
                        + str(run_time_args.message))


def verify_objects_in_preview(form_object, form_type, widget_object,
                              widget_type, tree_view_element,
                              verify_property=True, close_preview_window=True,
                              time_out=MAX_TIME_OUT):
    """Method to go to Preview and verify the current property/properties of
    all the widget object seen in the preview"""
    try:
        #give the time for squish to wait for the next command
        squish.snooze(time_out)
        #variable to hold status of the previewed widgets
        preview_widgets = False
        #call the global property_dict to get the latest property
        #to be verified
        global property_dict
        #method to get children object of a particular type and use
        #builtin deque function to arrange the value in a queue
        form_widgets = deque(general.get_children_of_type(form_object,
                                                form_type, depth=10))
        #loop through the existing form widgets on the form
        for form_widget_object in form_widgets:
            #get the x coordinate of the current widget
            x_coordinate = form_widget_object.x
            #get the y coordinate of the current widget
            y_coordinate = form_widget_object.y
            #open the preview and verify if it is opened
            if(open_preview()):
                #method to get children object of a particular type and use
                #builtin deque function to arrange the value in a queue
                preview_widget_objects = deque(general.get_children_of_type(
                                    widget_object, widget_type, 5))
                #loop through the existing preview widgets in the preview
                for preview_widget in preview_widget_objects:
                    #get the x coordinate of the current widget
                    current_x_coordinate = preview_widget.x
                    #get the y coordinate of the current widget
                    current_y_coordinate = preview_widget.y
                    # compare the x and y coordinates of current widget in the
                    # preview with the x and y coordinate of current widget in
                    # the form.
                    if((x_coordinate == current_x_coordinate) &
                       (y_coordinate == current_y_coordinate)):
                        #set the preview_widgets to True if the above
                        #statement if True
                        preview_widgets = True
                        #validate if the tree_view_element is set to none
                        if not tree_view_element == None:
                            #verify the properties provided by the user are
                            #True or False for a specific tree_view_element
                            preview_widgets = _verify_widget_property(
                                tree_view_element, verify_property,
                                preview_widgets, property_dict, preview_widget)
                        else:
                            #verify the properties provided by the user are
                            #True or False
                            preview_widgets = _verify_all_widget_property(
                                verify_property, preview_widgets,
                                property_dict, preview_widget)
                        break
                    else:
                        #set the preview_widgets to False if the x and
                        # y coordinates does not match
                        preview_widgets = False
        #verify if the preview window has to be closed or not
        if(close_preview_window):
            #close the preview window
            close_preview()
        #return the preview_widgets result to test script
        return preview_widgets
    except Exception as run_time_args:
        raise Exception("general.verify_objects_in_preview(): "
                        + str(run_time_args.message))


def verify_object_property_in_preview(form_object, form_type, widget_object,
                              widget_type, tree_view_element,
                              property_name, property_value,
                              close_preview_window=True,
                              time_out=MAX_TIME_OUT):
    """Method to go to Preview and verify the current property of
    a the widget object seen in the preview"""
    try:
        #give the time for squish to wait for the next command
        squish.snooze(time_out)
        # declare a variable to hold the status of the verification
        preview_widgets = False
        #method to get children object of a particular type and use
        #builtin deque function to arrange the value in a queue
        form_widgets = deque(general.get_children_of_type(form_object,
                                                form_type, depth=10))
        #loop through the existing form widgets on the form
        for form_widget_object in form_widgets:
            #get the x coordinate of the current widget
            x_coordinate = form_widget_object.x
            #get the y coordinate of the current widget
            y_coordinate = form_widget_object.y
            #open the preview and verify if it is opened
            if(open_preview()):
                #method to get children object of a particular type and use
                #builtin deque function to arrange the value in a queue
                preview_widget_objects = deque(general.get_children_of_type(
                                    widget_object, widget_type, 5))
                #loop through the existing preview widgets in the preview
                for preview_widget in preview_widget_objects:
                    #get the x coordinate of the current widget
                    current_x_coordinate = preview_widget.x
                    #get the y coordinate of the current widget
                    current_y_coordinate = preview_widget.y
                    # compare the x and y coordinates of current widget in the
                    # preview with the x and y coordinate of current widget in
                    # the form.
                    if((x_coordinate == current_x_coordinate) &
                       (y_coordinate == current_y_coordinate)):
                        # verify if the "objectName" of the current
                        # preview_widget is equal to the tree_view_element name
                        # provided
                        if (preview_widget.objectName == tree_view_element):
                            #verify the properties provided by the user are
                            #True or False for a specific tree_view_element
                            preview_widgets = _verify_widget_property_value(
                                tree_view_element, property_name,
                                property_value, preview_widget)
                            break
                        else:
                            # when the tree_view_element is not equal to
                            # "objectName" the do the following
                            logger.write_log(str.format("""Indented Tree view
                            element not found in Preview.py"""))
                            continue
                    else:
                        #set the preview_widgets to False if the x and
                        # y coordinates does not match
                        preview_widgets = False
        #verify if the preview window has to be closed or not
        if(close_preview_window):
            #close the preview window
            close_preview()
        #return the preview_widgets result to test script
        return preview_widgets
    except Exception as run_time_args:
        raise Exception("general.verify_object_property_in_preview(): "
                        + str(run_time_args.message))


def open_preview(time_out=MAX_TIME_OUT):
    try:
        #give the time for squish to wait for the next command
        squish.snooze(time_out)
        #call the global item menu_item_opened to get the latest status
        global menu_item_opened
        #check the latest status of the menu_item_opened
        if not menu_item_opened:
            #method to open the Preview from the menu bar
            go_to_menu_item("FBE_MainWindow_Button_ToolsMenu", "Preview")
            #set the menu_item_opened to true once opened
            menu_item_opened = True
        #verify for the Preview window object
        if(native_squish_apis.object_exists("FBE_Preview_Screen_UI")):
            return True
        else:
            return False
    except Exception as run_time_args:
        raise Exception("general.select_push_button(): "
                        + str(run_time_args.message))


def _verify_widget_property(tree_view_element, verify_property,
                            preview_widgets, property_dict, preview_widget):
    try:
        # call the global all_widget_properties which stores the properties set
        # for more than one widgets in the preview which are to be verified.
        global all_widget_properties
        # declare an empty dictionary to hold the current property to be
        # verified.
        current_property = {}
        #verify that verify_property and preview_widgets are True to proceed
        if ((preview_widgets) & (verify_property)):
            # verify if the "objectName" of the current preview_widget is
            # equal to the tree_view_element name provided
            if (preview_widget.objectName == tree_view_element):
                # add an element with Key : current_property_name and
                # Value : current_property_value to current_property
                current_property[properties.current_property_name] = (
                                            properties.current_property_value)
                # add an element with Key : tree_view_element and
                # Value : current_property to property_dict
                property_dict[tree_view_element] = current_property
                # add an element with Key : tree_view_element and
                # Value : current_property to all_widget_properties
                all_widget_properties[tree_view_element] = current_property
                # loop through the property_dict items(Key, Value)
                for diValue in property_dict.values():
                    # loop through the diValue items(Key, Value)
                    for stKey, stValue in diValue.items():
                        # verify the verify_current_property for current widget
                        # is True or False
                        if (verify_current_property(preview_widget, stKey,
                                                    stValue)):
                            # set preview_widgets to True
                            preview_widgets = True
                        else:
                            # set preview_widgets to False
                            preview_widgets = False
            # when the tree_view_element is not equal to "objectName" the
            # do the following
            else:
                # update the property_dict with new preview_widget name and
                # value
                property_dict[str(preview_widget.objectName)] = preview_widget
                # clear the property_dict dictionary
                property_dict.clear()
        return preview_widgets
    except Exception as run_time_args:
        raise Exception("general._verify_widget_property(): "
                        + str(run_time_args.message))


def _verify_all_widget_property(verify_property,
                            preview_widgets, property_dict, preview_widget):
    try:
        item_verified = False
        global all_widget_properties
        stKeyItem = ""
        if ((preview_widgets) & (verify_property)):
            for stKeyItem, diValue in all_widget_properties.items():
                logger.write_log(str.format("""Checking properties of {0}
                                        """, stKeyItem))
                for stKey, stValue in diValue.items():
                    logger.write_log(str.format("""Verifying Property Key {0}
                        with Property Value {1}""", stKey, stValue))
                    if (verify_current_property(preview_widget, stKey,
                                                    stValue)):
                        item_verified = True
                    else:
                        item_verified = False
                        break
                if(item_verified):
                    logger.write_log(str.format("""All properties of {0}
                                are successfully verified""", stKeyItem))
                    preview_widgets = item_verified
                    break
                else:
                    preview_widgets = item_verified
                    logger.write_log(str.format(""""Property {0} with value {1}
                    is not verified""", stKey, stValue))
        else:
            logger.write_log("No property to verify...")
        all_widget_properties.pop(stKeyItem)
        return preview_widgets

    except Exception as run_time_args:
        raise Exception("general._verify_all_widget_property(): "
                        + str(run_time_args.message))


def close_preview():
    """Method to close the Preview by click on the 'close' button."""
    try:
        #call the global item menu_item_opened to get the latest status
        global menu_item_opened
#         #perform the mouse click operation on the menu bar object
#         qt_convenient_squish_apis.mouse_click(
#             native_squish_apis.wait_for_object("Dialog.Example SUI_QWidget"),
#                                     758, 1, 0, squish.MouseButton.LeftButton)
#         #perform the mouse click operation on the menu bar object
#         qt_convenient_squish_apis.mouse_click(
#             native_squish_apis.wait_for_object(
#                         "qt_tabwidget_stackedwidget.tbp2_QFrame"),
#                         260, 378, 0, squish.MouseButton.LeftButton)
        #method to send an event to the application
        qt_convenient_squish_apis.send_event("QCloseEvent",
                                             "FBE_Preview_Screen")
        #set the menu_item_opened to false once the Preview is closed
        menu_item_opened = False
    except Exception as run_time_args:
        raise Exception("general.close_preview(): "
                        + str(run_time_args.message))


def verify_with_vp(name_of_vp):
    """Method to compare images. Comparison of the testdata folder VP and the
    current image of the object on the screen."""
    try:
        #get the extension for the verification point
        name_of_vp = _get_image_extension(name_of_vp)
        #get the complete path of the verification point
        complete_vp_path = general.get_verification_data_file()
        #get the test case name
        test_case_name = general.get_test_case_name()
        #check if the name_of_vp is not empty
        if(name_of_vp == None):
            #get the complete path of the verification point with textcase name
            complete_vp_path = complete_vp_path + "/" + test_case_name
        else:
            #get the complete path of the verification point with VP name
            complete_vp_path = (
                    complete_vp_path + "/" + test_case_name + "_" + name_of_vp)
        #check if the complete_vp_path exists before proceeding
        if(os.path.exists(complete_vp_path)):
            #method to verify with the VP provide
            if(test.vp(complete_vp_path)):
                return True
            else:
                return False
        else:
            raise Exception(str.format("{0} path not found", complete_vp_path))
    except Exception as run_time_args:
        raise Exception("general.verify_with_vp(): "
                        + str(run_time_args.message))


def _get_image_extension(name_of_vp):
    """
    private method to get the extension of VP provided
    """
    try:
        finished_removing_extension = []
        if not name_of_vp == None:
            for item in name_of_vp:
                if not item == ".":
                    finished_removing_extension.append(item)
                else:
                    break
            name_of_vp = ''.join(finished_removing_extension)
        else:
            raise Exception("Name of vp is not provided...")
        return name_of_vp
    except Exception as run_time_args:
        raise Exception("general._get_image_extension(): "
                        + str(run_time_args.message))


def click_on_widget_object(widget_object, time_out=MAX_TIME_OUT):
    """
    Method to click on a widget object.
    """
    try:
        #determine the widget object exists before proceeding
        if(native_squish_apis.object_exists(widget_object)):
            #method to click an item
            qt_convenient_squish_apis.click_on_item(widget_object)
            #give the time for squish to wait for the next command
            squish.snooze(time_out)
        else:
            raise(str.format("{0} object not found...", widget_object))
    except Exception as run_time_args:
        raise Exception("general.click_on_widget_object(): "
                        + str(run_time_args.message))


def verify_current_property(property_object, property_name, property_value,
                            time_out=MAX_TIME_OUT, latest_available=False):
    """
    Method to verify property and set the user defined property value as per
    the property name
    """
    try:
        if not latest_available:
            #get the latest_property_values for the property object
            latest_property_values = native_squish_apis.wait_for_object(
                                                        property_object)
        else:
            latest_property_values = property_object
        #check if the property_name is "Bold"
        if(property_name == "Bold"):
            #get the intended property "font" of the property_name
            value_of_current_object = latest_property_values.font
            #format the intended property of the property_name according to
            #string and convert all to lower case
            value_of_current_object = str(value_of_current_object.bold).lower()
            #convert to string and to lower case
            property_value = str(property_value).lower()
            #verify both are equal or not
            if(value_of_current_object == property_value):
                return True
            else:
                return False
        #check if the property_name is "Text"
        if(property_name == "Text"):
            #get the intended property "text" of the property_name
            value_of_current_object = latest_property_values.text
            #verify both are equal or not
            if(value_of_current_object == property_value):
                return True
            else:
                return False
        #check if the property_name is "ImageData"
        if(property_name == "ImageData"):
            #method verify with the VP name provided
            if(verify_with_vp(property_value)):
                return True
            else:
                return False
        #check if the property_name is "ImageDataPressed"
        if(property_name == "ImageDataPressed"):
            #method verify with the VP name provided
            if(verify_with_vp(property_value)):
                #mouse press on the middle of the objectOrName object
                native_squish_apis.mouse_press(property_object)
                #give the time for squish to wait for the next command
                squish.snooze(time_out)
                #release the specified mouse button
                native_squish_apis.mouse_release(
                            mouse_button="left_button")
                #method verify with the VP name provided
                if(verify_with_vp(property_value)):
                    return True
                else:
                    return False
            else:
                return False
        #check if the property_name is "Width"
        if(property_name == "Width"):
            #get the intended property "width" of the property_name
            value_of_current_object = latest_property_values.width
            #format the intended property of the property_name according to
            #string and convert all to lower case
            value_of_current_object = str(value_of_current_object).lower()
            #verify both are equal or not
            if(property_value == value_of_current_object):
                return True
            else:
                return False
        #check if the property_name is "Checked"
        if(property_name == "Checked"):
            #get the intended property "checked" of the property_name
            value_of_current_object = str(
                        latest_property_values.checked).lower()
            #format the intended property of the property_name according to
            #string and convert all to lower case
            property_value = str(property_value).lower()
            #verify both are equal or not
            if(value_of_current_object == property_value):
                return True
            else:
                return False
        #check if the property_name is "BGColor"
        if(property_name == "BGColor"):
            #get the intended property "color" of the property_name
            value_of_current_object = latest_property_values.backgroundColor()
            # set the color name from hex code
            if not (value_of_current_object.red == 0):
                value_of_current_object = "red"
            elif not (value_of_current_object.blue == 0):
                value_of_current_object = "blue"
            elif not (value_of_current_object.green == 0):
                value_of_current_object = "green"
            # verify the property is same as set
            if(value_of_current_object == property_value):
                return True
            else:
                return False
        #check if the property_name is "Orientation"
        if(property_name == "Orientation"):
            #get the intended property "orientation" of the property_name
            value_of_current_object = latest_property_values.orientation
            # check if it is horizontal
            if(property_value.lower() == "horizontal"):
                property_value = 1
            # check if it is vertical
            elif(property_value.lower() == "vertical"):
                property_value = 2
            if(value_of_current_object == property_value):
                return True
            else:
                return False
        #check if the property_name is "Height"
        if(property_name == "Height"):
            #get the intended property "height" of the property_name
            value_of_current_object = latest_property_values.height
            #convert the value_of_current_object to lower case
            value_of_current_object = str(value_of_current_object).lower()
            #compare the set value and expected value
            if(property_value == value_of_current_object):
                return True
            else:
                return False
        #check if the property_name is "BGColor"
        if(property_name == "BGColor"):
            #get the intended property "color" of the property_name
            value_of_current_object = latest_property_values.backgroundColor()
            # set the color name from hex code
            if not (value_of_current_object.red == 0):
                value_of_current_object = "red"
            elif not (value_of_current_object.blue == 0):
                value_of_current_object = "blue"
            elif not (value_of_current_object.green == 0):
                value_of_current_object = "green"
            # verify the property is same as set
            if(value_of_current_object == property_value):
                return True
            else:
                return False
        #check if the property_name is "Percentage"
        if(property_name == "Percentage"):
            #get the intended property "visible" of the property_name
            value_of_current_object = latest_property_values.textVisible
            #convert to string and lower case
            value_of_current_object = str(value_of_current_object).lower()
            #convert to string and lower case
            property_value = str(property_value).lower()
            # verify the property is same as set
            if(value_of_current_object == property_value):
                return True
            else:
                return False
        #check if the property_name is "objectName"
        if(property_name == "objectName"):
            #get the intended property "visible" of the property_name
            value_of_current_object = latest_property_values.objectName
            #convert to string and lower case
            value_of_current_object = str(value_of_current_object).lower()
            #convert to string and lower case
            property_value = str(property_value).lower()
            # verify the property is same as set
            if(value_of_current_object == property_value):
                return True
            else:
                return False
        #check if the property_name is "cellalignment"
        if(property_name == "cellalignment"):
            #get the intended property "visible" of the property_name
            value_of_current_object = latest_property_values.geometry
            #convert to string and lower case
            value_of_current_object_x = str(value_of_current_object.x).lower()
            #convert to string and lower case
            value_of_current_object_y = str(value_of_current_object.y).lower()
            #convert to string and lower case
            property_value = str(property_value).lower()
            #combine the x and y coordinates to form a string for comparison
            value_of_current_object = str.format("{0},{1}",
                                                value_of_current_object_x,
                                                value_of_current_object_y)
            # verify the property is same as set
            if(value_of_current_object == property_value):
                return True
            else:
                return False
    except Exception as run_time_args:
        raise Exception("general.verify_current_property(): "
                        + str(run_time_args.message))

#===============================Revision History==============================
# Modified By       Modified On      Modification Reason
# Girish Nair        01-May-2017     Created and implemented methods.
# Girish Nair        05-Jul-2017     1. All comments fixed.
#                                    2. Modified all methods.
# Girish Nair        05-Jul-2017     Added new properties - BGColor, Height,
#									 ImageData, and Orientation
#=============================================================================
