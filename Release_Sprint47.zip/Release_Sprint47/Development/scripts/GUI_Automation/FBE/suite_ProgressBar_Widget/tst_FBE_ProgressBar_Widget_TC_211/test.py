 # -*- coding: utf-8 -*-

"""
Aim of the script  : Verify if the color of the Progress Bar can be set in the editor
Reference document : TAR-TPS-001-TPS_ADT_FBE_ITV_FWQ_Sprint 45
Test case ID       : TC211
"""

import general


def main():
    try:
        # Step 1:Start the FBE application
        general.launch_application('FBE', write_result=True)

        # Step 2:Place a ProgressBar widget on the form.
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_ProgressBar',
                                    widget_name='ProgressBar Widget',
                                    target_name='Editor Form')
        # Step 3 & 4:Verify if the Progress Bar has a property Color.Change the property Color
        #  to green and verify if the Progress Bar’ filling is green
        general.update_property_value_in_editor(widget_name='ProgressBar', property_name='Color',
                                    value_to_be_set='green', write_result=True)
        
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='ProgressBar', widget_id='pgb29', expected_prop_value={'Color':'green'},
                    write_result=True)
        #Step 5:Place a Progress Bar on the form
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_ProgressBar',
                                    widget_name='ProgressBar Widget',
                                    target_name='Editor Form',target_x_coord=350,
                                    target_y_coord=350)
        
        #Step 6:Change the property Color to red and verify if the Progress Bar’ filling is red
        general.update_property_value_in_editor(widget_name='ProgressBar', property_name='Color',
                                    value_to_be_set='red', write_result=True)
        
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='ProgressBar', widget_id='pgb30', expected_prop_value={'Color':'red'},
                    write_result=True)
        
        # Step 7:Save the file as test_PGBColor.xml and Close application FBE
        general.save_file_in_editor(file_name='test_PGBColor.xml',
              directory_path='/home/adt/ADT/ASML-ADT/Trunk/targets/bin/')
        # Step 8:Close and relaunch FBE
        general.quit_application(app_name='FBE', file_name='',
                directory_path='/home/adt/ADT/ASML-ADT/Trunk/targets/bin/')
        general.launch_application('FBE', write_result=True)
        
        # Step 8: Open the file test_PGBColor.xml and preview
        general.open_file_in_editor(file_name='test_PGBColor.xml',
              directory_path='/home/adt/ADT/ASML-ADT/Trunk/targets/bin/')
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='ProgressBar', widget_id='pgb29', expected_prop_value={'Color':'green'},
                    write_result=True)
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='ProgressBar', widget_id='pgb30', expected_prop_value={'Color':'red'},
                    write_result=True)
        #Quit application
        general.quit_application(app_name='FBE', file_name='',
                directory_path='/home/adt/ADT/ASML-ADT/Trunk/targets/bin/')       
    except Exception as runtime_args:
        raise Exception(str(runtime_args.message))
