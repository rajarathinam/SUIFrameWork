# -*- coding: utf-8 -*-

"""
Aim of the script  : Verify that widgets can be added to the currently selected
                     Tab page.
Reference document : TAR-TPS-001-TPS_ADT_FBE_ITV_FWQ_Sprint_45.docx
Test case ID       : TC6
"""

import general
import qt_convenient_squish_apis
import native_squish_apis
import logger

app_name = "FBE"


def _pre_condition():
    #Open the editor by running ./FBE
    general.launch_application(app_name, write_result=False)


def main():
    try:
        #call the test script pre-requisites
        _pre_condition()
        # Step 1: Select the main Tab widget in the Form Editor by
        # clicking on it with the mouse.
        general.select_item_in_widget_tree_view("tbw1")
        # delete the tab page by using the 'Delete' button from the
        # keyboard Mouse click on the passed widget
        qt_convenient_squish_apis.mouse_click(
                                    "FBE_MainWindow_EditFormDisplayWindow")
        # Delete the widget by pressing 'Delete' key
        qt_convenient_squish_apis.type(
                            "FBE_MainWindow_EditFormDisplayWindow", '<Delete>')
        # Step 1: Select the main Tab widget in the Form Editor by
        # clicking on it with the mouse.
        general.select_item_in_widget_tree_view("wpg1", True)
        # Go to Preview screen
        general.go_to_menu_item('Tools', 'Preview')
        # verify the preview screen contains the widget page object
        if not (native_squish_apis.object_exists(
                            "FBE_PreviewWindow_Container_PreviewWidgetPage")):
                logger.write_to_result("Fail",
                            str.format("""Verify the Default Tab Page can
                                be deleted and is replaced by WidgetPage.
                                """), str.format("""Verify the Default Tab Page
                                is deleted and is replaced by WidgetPage."""),
                                str.format("""Default Tab Page
                                is deleted but it is not replaced with
                                WidgetPage"""))
        general.close_preview()
        # Step 6:Verify if table widget can be added to editor form by
                # dragging and dropping
        general.verify_widget_drag_and_drop(
                            'FBE_MainWindow_WidgetIcon_Button',
                            tab_obj='FBE_MainWindow_DefaultWidgetPage_WPG1',
                            widget_name='Button',
                            target_name='Editor Form')
        # Go to Preview screen
        general.go_to_menu_item('Tools', 'Preview')
        # Wait for preview window to appear
                # native_squish_apis.wait_for_object
                # ('FBE_PreviewWindow_Screen', 5)
                # Get 'QFrame' children from stacked widgets parent object
        qwidget_children = general.get_children_of_type(
                            'FBE_PreviewWindow_Container_PreviewWidgetPage',
                            'CustomPushButton', 1)
        # Loop through each 'QFrame' child (tab object) to get the
                # required
                # child. From obtained child, extract all children (widget
                # objects)
        for qwidget_child in qwidget_children:
            if str(qwidget_child.objectName) == "btn28":
                logger.write_to_result("Pass",
                                str.format("""Verify if widget can be
                                placed on the WidgetPage.
                                """), str.format("""Verify if widget can be
                                placed on the WidgetPage."""),
                                str.format("""Widget can be placed on the
                                WidgetPage"""))
            else:
                logger.write_to_result("Fail",
                                str.format("""Verify if widget can be
                                placed on the WidgetPage.
                                """), str.format("""Verify if widget can be
                                placed on the WidgetPage."""),
                                str.format("""Widget cannot be placed on the
                                WidgetPage"""))
        general.close_preview()
        editor_child = general.get_children_of_type(
                                    'FBE_MainWindow_SubContainer_EditorForm',
                                    'WidgetController', 1)[0]
        # Mouse click on the passed widget
        qt_convenient_squish_apis.mouse_click(editor_child)
        # Delete the widget by pressing 'Delete' key
        qt_convenient_squish_apis.type(editor_child, '<Delete>')
        # Step 1: Select the main Tab widget in the Form Editor by
        # clicking on it with the mouse.
        general.select_item_in_widget_tree_view("wpg1")
        # delete the tab page by using the 'Delete' button from the
        # keyboard Mouse click on the passed widget
        qt_convenient_squish_apis.mouse_click(
                                    "FBE_MainWindow_SubContainer_EditorForm")
        # Delete the widget by pressing 'Delete' key
        qt_convenient_squish_apis.type(
                            "FBE_MainWindow_SubContainer_EditorForm",
                            '<Delete>')
        # Step 1: Select the main Tab widget in the Form Editor by
        # clicking on it with the mouse.
        general.select_item_in_widget_tree_view("wpg1", True)
        # Step 2:Click on the Edit item in the menu and select Form
        # Properties
        general.go_to_menu_item("Edit", "Form Properties")
        # Step3: Change the height and/or the width property and click
        # OK
        general.update_property_value_in_form_properties("FormProperties",
                                "width", "500", True)
        # declare a dictionary to hold the property name and property
        # value.
        expected_prop_dictionary = {}
        # update the dictionary with property_name and property_value
        expected_prop_dictionary["width"] = "500"
        # close the Form Properties window
        general.close_pop_up("FBE_FormPropertiesPopup_Button_Ok",
                                         True)
        # verify the properties of the form are set as expected in
                    # preview
        if not (general.verify_properties_of_preview_window(
                                expected_prop_dictionary)):
            logger.write_to_result('Pass', str.format("""Verify if the
                                    WidgetPage cannot be resized"""),
                                    str.format("""Verify if the
                                    WidgetPage cannot be resized"""),
                                    str.format("""The WidgetPage cannot be
                                    resized by changing the Height & Width in
                                    the Form properties."""))
        # close the preview
        general.close_preview()
        # call the post condition for the script
        _post_condition()

    except Exception as runtime_args:
        raise Exception(str(runtime_args.message))


def _post_condition():
    # quit the FBE application
    general.quit_application(app_name)

#===========================Revision History===================================
#Modifier       Modified On                 Modification Reason
#Girish Nair    22/08/2017                  New script created
#==============================================================================
