"""
Aim of the Script     : Verify that the GUI Editor has implemented proper drag
                        and drop behavior. New widgets shall be drag and
                        dropped from the Widget Selector on the form in the
                        Form Editor.
Reference Document    : TAR-TPS-001-TPS_ADT_FBE_ITV_FWQ_Sprint 43
Test case ID          : TC3
"""
import general
import logger

#declare a static variable to contain the application name to be tested.
app_name = "FBE"


def _pre_condition():
        # Start the FBE application
        general.launch_application(app_name, write_result=True)


def main():
    try:
        #Execute the pre-condition
        _pre_condition()
        # Step 2:Verify if TextArea widget is displayed in widget selector list
        general.verify_widget_in_widgets_selector(
                                    'FBE_MainWindow_WidgetIcon_Button',
                                    "Button", 2)

        # Step 3:Verify if TextArea widget can be added to editor form by
        # dragging and dropping
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_Button',
                                    widget_name='Button',
                                    target_name='Editor Form')
        general.verify_properties_in_preview(tab_obj_id='tbp2',
                                widget_name='Button', widget_id='btn29',
                                expected_prop_value={}, write_result=True)
        # dragging and dropping
        try:
            general.verify_widget_drag_and_drop(
                            'FBE_MainWindow_DisplayWindowFormEditorWidget',
                                    widget_name='Button',
                                    target_name='Editor Form',
                                    target_x_coord=350,
                                    target_y_coord=350)
        except Exception as drag_drop_exception:
            if "could not be dragged and dropped onto" in drag_drop_exception.message:
                general.verify_properties_in_preview(tab_obj_id='tbp2',
                                widget_name='Button', widget_id='btn29',
                                expected_prop_value={}, write_result=True)
        # Step 5:Verify if Button widget can be removed from editor by dragging
        # and dropping it back in widget selector panel
        editor_child = general.get_children_of_type(
                                    'FBE_MainWindow_SubContainer_EditorForm',
                                    'WidgetController', 1)[0]
        widget_to_drag = general.get_children_of_type(editor_child,
                                                      'WidgetController')[0]
        general.verify_widget_drag_and_drop(widget_to_drag,
                            'FBE_MainWindow_WidgetsDisplayWindowWithScroll',
                            widget_name='Button',
                            target_name='Widget Selector')
    except Exception as e:
        logger.failed(str.format("Exception : {0}", e))
    finally:
        #call the post condition for the test script.
        posCondition()


def posCondition():
    general.quit_application(app_name)

#===========================Revision History===================================
#Modifier       Modified On                 Modification Reason
#Girish Nair    13/07/2017                  Applied new coding standards
#==============================================================================
