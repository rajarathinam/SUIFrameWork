# -*- coding: utf-8 -*-

"""
Aim of the script  : Verify that the properties of the form can be changed with
                     the Form Property dialog box
Reference document : TAR-TPS-001-TPS_ADT_FBE_ITV_FWQ_Sprint_45.docx
Test case ID       : TC5
"""

import general

app_name = "FBE"


def _pre_condition():
    pass


def main():
    try:
        #call the test script pre-requisites
        _pre_condition()
        # Step 1: Open the editor by running ./FBE
        general.launch_application(app_name, write_result=False)
        #declare an iterator object
        iterator = 0
        # set the widget name
        widget_name = "FormProperties"
        # declare a dictionary to hold the property name and property
        # value.
        expected_prop_dictionary = {}
        # get the test data set from the corresponding test script data file.
        data_set = testData.dataset(general.get_path("testdata") +
                            "/Changing_Few_Form_properties_TC_5.tsv")
        for row in data_set:
            property_name = testData.field(row,
                                                    "property_name")
            property_value = testData.field(row,
                                                    "property_value")
            if iterator <= 1:
                if(iterator == 0):
                    # Step 2:Click on the Edit item in the menu and select Form
                    # Properties
					general.go_to_menu_item("Edit", "Form Properties")
                # Step3: Change the height and/or the width property and click
                # OK
                general.update_property_value_in_form_properties(widget_name,
                                property_name, property_value, True)
                # update the dictionary with property_name and property_value
                expected_prop_dictionary[property_name] = property_value
                if(iterator == 1):
                    # close the Form Properties window
                    general.close_pop_up("FBE_FormProperties_Window_Btn_OK",
                                         True)
                    # verify the properties of the form are set as expected in
                    # preview
                    general.verify_properties_of_preview_window(
                                expected_prop_dictionary, True)
                    # close the preview
                    general.close_preview()
            if(iterator == 2):
                # clear the current dictionary
                expected_prop_dictionary.clear()
                # Step 2:Click on the Edit item in the menu and select Form
                # Properties
                general.go_to_menu_item("Edit", "Form Properties")
                # verify the property of SUIVersion
                general.verify_properties("FormProperties",
                                                 property_name, property_value)
            if(iterator >= 3 and iterator <= 4):
                # Step3: Change the SUIDescription and SUIName property and click
                # OK
                general.update_property_value_in_form_properties(widget_name,
                                property_name, property_value, True)
                # verify the properties of SUIDescription and SUIName property
                # are set as expected in
                general.verify_properties("FormProperties",
                                                 property_name, property_value)
            if(iterator >= 5 and iterator <= 7):
                # Step3: Try to change the HasBottomButtonBar, HasRightButtonBar,
				# HasStatusBar property and click Ok and check it should not get
                # updated.
                general.update_property_value_in_form_properties(widget_name,
                                property_name, property_value, True)
                # verify the properties of HasBottomButtonBar, HasRightButtonBar,
				# HasStatusBar are set to false.
                general.verify_properties("FormProperties",
                                                 property_name, property_value)
            iterator += 1
        # call the post condition for the script
        _post_condition()

    except Exception as runtime_args:
        raise Exception(str(runtime_args.message))


def _post_condition():
    # close the Form Properties window
    general.close_pop_up("FBE_FormProperties_Window_Btn_OK",
                                         True)
    # quit the FBE application
    general.quit_application(app_name)
#===========================Revision History===================================
#Modifier       Modified On                 Modification Reason
#Girish Nair    26/07/2017                  New script created
#Girish Nair    27/07/2017                  Added preview of objects
#==============================================================================
