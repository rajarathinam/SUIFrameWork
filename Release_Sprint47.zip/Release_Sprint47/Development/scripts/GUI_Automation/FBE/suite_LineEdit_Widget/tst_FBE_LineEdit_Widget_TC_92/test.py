"""
Aim of the Script     : VERIFY IF THE LINE EDIT WIDGET SUPPORTS INPUT
                        VALIDATION
Reference Document    : TAR-TPS-001-TPS_ADT_FBE_ITV_FWQ_Sprint 47
Test case ID          : TC092
"""
import general
APP_NAME = "FBE"


def main():
    try:
        # Step 1:Start the FBE application
        general.launch_application('FBE', write_result=True)

        # Step 2:Place a LineEdit widget on the form. Set Checked to true
        general.verify_widget_drag_and_drop(
            'FBE_MainWindow_WidgetIcon_LineEdit',
             widget_name='LineEdit',
             target_name='Editor Form',
             target_x_coord=120,
             target_y_coord=120)

        # step 3: Set the property RegularExpression to ^([0-9]|[1-9][0-9])$ to
        #support numbers from 0 to 99
        general.update_property_value_in_editor(widget_name='LineEdit',
            property_name='RegularExpression',
            value_to_be_set='^([0-9]|[1-9][0-9])$',
            write_result=True)

        # step 4: Set the RegExpTip to ‘Numbers 0 to 99’ to set the tool tip
        general.update_property_value_in_editor(widget_name='LineEdit',
            property_name='RegExpTip',
            value_to_be_set='0 to 99',
            write_result=True)

        # Step 5:Place another line edit on the form
        general.verify_widget_drag_and_drop(
            'FBE_MainWindow_WidgetIcon_LineEdit',
             widget_name='LineEdit',
             target_name='Editor Form',
             target_x_coord=200,
             target_y_coord=200)

        # step 6: Set the property Regular Expression
        #^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$, to test for most
        #e-mail addresses
        general.update_property_value_in_editor(widget_name='LineEdit',
           property_name='RegularExpression',
           value_to_be_set='^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$',
           write_result=True)

        # step 7: Set the RegExpTip to ‘E-mail address’ to set the tool tip
        general.update_property_value_in_editor(widget_name='LineEdit',
            property_name='ToolTip',
            value_to_be_set='Test',
            write_result=True)

        general.update_property_value_in_editor(widget_name='LineEdit',
            property_name='RegExpTip',
            value_to_be_set='E-mail address',
            write_result=True)

        # Step 8:Save the file as testRegEx.xml
        general.save_file_in_editor(file_name='testRegEx.xml')

        # Step 9:Close and relaunch FBE
        general.quit_application(app_name='FBE', file_name='')
        general.launch_application('FBE', write_result=True)

        # Step 10:Open the file testRegEx.xml and preview
        general.open_file_in_editor(file_name='testRegEx.xml')

        # Step 11:Verify if 3 line edit are shown: 1 aligned left, 1 aligned
        #right, 1 centered
        general.verify_properties_in_preview(tab_obj_id='tbp2',
                    widget_name='LineEdit', widget_id='lne30',
                    expected_prop_value={'ToolTip':
                    'Test'}, write_result=True)

        _post_condition()

    except Exception as runtime_args:
        raise Exception(str(runtime_args.message))


def _post_condition():
    general.quit_application(APP_NAME)

#===========================Revision History===================================
#Modifier       Modified On                 Modification Reason
#Saisivaprasad    22/08/2017                  Applied new coding standards
#==============================================================================
