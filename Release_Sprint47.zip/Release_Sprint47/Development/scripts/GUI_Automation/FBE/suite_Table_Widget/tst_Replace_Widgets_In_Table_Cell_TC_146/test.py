# -*- coding: utf-8 -*-

"""
Aim of the script  : Verify that widgets in cells can be replaced
Reference document : TAR-TPS-001-TPS_ADT_FBE_ITV_FWQ_Sprint 45.docx
Test case ID       : TC146
"""

import general
import logger
app_name = "FBE"


def _pre_condition():
    #Open the editor by running ./FBE
    general.launch_application(app_name, write_result=False)


def main():
    try:
        # Call the test script pre-requisites
        _pre_condition()
        # Step 1:Verify if table widget can be added to editor form by
        # dragging and dropping
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_TableWidget',
                                    widget_name='Table Widget',
                                    target_name='Editor Form')
        data_set = testData.dataset(general.get_path("testdata") +
                            "/Replace_Widgets_In_Table_Cell_TC_146.tsv")
        expected_properties = []
        # Declare an iterator variable
        iterator = 0
        for row in data_set:
            property_name = testData.field(row, 'property_name')
            property_value = testData.field(row, 'property_value')
            context_menu_item = testData.field(row, 'context_menu_item')
            tree_view_widget_name = testData.field(row,
                                                   'tree_view_widget_name')
            if(iterator <= 1):
                #Step6 : Right click on the added Table Widget, select Insert
                #        Rows
                #Step8 : Right click on the added Table Widget, select Insert
                #        Columns
                general.update_and_verify_table_entries(tree_view_widget_name,
                                             context_menu_item, property_name,
                                             property_value, write_result=True)
                general.verify_table_entries_in_preview(tree_view_widget_name,
                         'objectName', tab_name='tbp2',
                         write_result=True)
        general.update_property_value_in_editor(widget_name="TableWidget",
                                        property_name="setitemtype",
                                        value_to_be_set="Set Item Type",
                                        write_result=True)
        general.set_table_item(widget_name="SpinBox",
                               table_entity="SingleCell",
                               start='1', end='1')
        spinbox_widget_list_in_table_tree_view = general.verify_table_item_tree_view_names(
                                             widget_id='taw29',
                                             widget_name="SpinBox",
                                             table_entity="SingleCell",
                                             write_result=True)
        general.verify_table_item_obj_in_preview(widget_name="SpinBox",
                table_cell_name_list=spinbox_widget_list_in_table_tree_view,
                write_result=True)
        data_set = testData.dataset(general.get_path("testdata") +
                            "/SpinBox_Expected_Properties_TC_146.tsv")
        for row in data_set:
            expected_properties.append(testData.field(row,
                                                'Expected_Properties'))
        for spinbox_widget in spinbox_widget_list_in_table_tree_view:
            general.select_item_in_widget_tree_view(spinbox_widget)
            general.verify_properties_in_editor(expected_properties)
        expected_properties = []
        general.select_item_in_widget_tree_view(tree_view_widget_name)
        general.update_property_value_in_editor(widget_name="TableWidget",
                                        property_name="setitemtype",
                                        value_to_be_set="Set Item Type",
                                        write_result=True)
        general.set_table_item(widget_name="DropDown", table_entity="Rows",
                               start='1', end='1')
        dropdown_widget_list_in_table_tree_view = general.verify_table_item_tree_view_names(
                                             widget_id='taw29',
                                             widget_name="DropDown",
                                             table_entity="Rows",
                                             no_of_row_column='2',
                                             write_result=True)
        try:
            general.verify_table_item_obj_in_preview(widget_name="SpinBox",
                table_cell_name_list=spinbox_widget_list_in_table_tree_view,
                write_result=True)
        except Exception as function_exception:
            if (str(spinbox_widget_list_in_table_tree_view[0]) in str(
                                                function_exception.message)):
                logger.write_to_result("Pass", str.format("""The widgets in
                        column 1 are replaced by new widgets. Objects name
                        should change to widgetID-taw[num]:r-c where r
                        represents the row and c represents column"""),
                        str.format("""The widgets in
                        column 1 are replaced by line widgets. Objects name
                        should change to lne-taw[num]:r-1 where r
                        represents the row"""),
                        str.format("""As expected the item in the
                        table block 1-1 {0} is updated with {1}""",
                        str(spinbox_widget_list_in_table_tree_view[0]),
                        str.format(
                            dropdown_widget_list_in_table_tree_view[0])))
            else:
                logger.write_to_result("Pass", str.format("""The widgets in
                        column 1 are replaced by new widgets. Objects name
                        should change to widgetID-taw[num]:r-c where r
                        represents the row and c represents column"""),
                        str.format("""The widgets in
                        column 1 are replaced by line widgets. Objects name
                        should change to lne-taw[num]:r-1 where r
                        represents the row"""),
                        str.format("""The item in the
                        table block 1-1 {0} is not updated with {1}""",
                        str(spinbox_widget_list_in_table_tree_view[0]),
                        str.format(
                        dropdown_widget_list_in_table_tree_view[0])))
            general.verify_table_item_obj_in_preview(widget_name="DropDown",
                table_cell_name_list=dropdown_widget_list_in_table_tree_view,
                write_result=True)

        data_set = testData.dataset(general.get_path("testdata") +
                            "/DropDown_Expected_Properties_TC_146.tsv")
        for row in data_set:
            expected_properties.append(testData.field(row,
                                                'Expected_Properties'))
        for dropbox_widget in dropdown_widget_list_in_table_tree_view:
            general.select_item_in_widget_tree_view(dropbox_widget)
            general.verify_properties_in_editor(expected_properties)
        expected_properties = []
        general.select_item_in_widget_tree_view(tree_view_widget_name)

        general.update_property_value_in_editor(widget_name="TableWidget",
                                        property_name="setitemtype",
                                        value_to_be_set="Set Item Type",
                                        write_result=True)
        general.set_table_item(widget_name="LineEdit", table_entity="Columns",
                               start='1', end='1')
        lineedit_widget_list_in_table_tree_view = general.verify_table_item_tree_view_names(
                                             widget_id='taw29',
                                             widget_name="LineEdit",
                                             table_entity="Columns",
                                             no_of_row_column='3',
                                             write_result=True)
        general.verify_table_item_obj_in_preview(widget_name="LineEdit",
                table_cell_name_list=lineedit_widget_list_in_table_tree_view,
                write_result=True)
        try:
            general.verify_table_item_obj_in_preview(widget_name="DropDown",
                table_cell_name_list=dropdown_widget_list_in_table_tree_view,
                write_result=True)
        except Exception as function_exception:
            if (str(dropdown_widget_list_in_table_tree_view[0]) in str(
                                                function_exception.message)):
                logger.write_to_result("Pass", str.format("""The widgets in
                        column 1 are replaced by new widgets. Objects name
                        should change to widgetID-taw[num]:r-c where r
                        represents the row and c represents column"""),
                        str.format("""The widgets in
                        column 1 are replaced by line widgets. Objects name
                        should change to lne-taw[num]:r-1 where r
                        represents the row"""),
                        str.format("""As expected the item in the
                        table block 1-1 {0} is updated with {1}""",
                        str(dropdown_widget_list_in_table_tree_view[0]),
                        str.format(
                            lineedit_widget_list_in_table_tree_view[0])))
            else:
                logger.write_to_result("Pass", str.format("""The widgets in
                        column 1 are replaced by new widgets. Objects name
                        should change to widgetID-taw[num]:r-c where r
                        represents the row and c represents column"""),
                        str.format("""The widgets in
                        column 1 are replaced by line widgets. Objects name
                        should change to lne-taw[num]:r-1 where r
                        represents the row"""),
                        str.format("""The item in the
                        table block 1-1 {0} is not updated with {1}""",
                        str(dropdown_widget_list_in_table_tree_view[0]),
                        str.format(
                        lineedit_widget_list_in_table_tree_view[0])))
            general.verify_table_item_obj_in_preview(widget_name="LineEdit",
                table_cell_name_list=lineedit_widget_list_in_table_tree_view,
                write_result=True)

        data_set = testData.dataset(general.get_path("testdata") +
                            "/LineEdit_Expected_Properties_TC_146.tsv")
        for row in data_set:
            expected_properties.append(testData.field(row,
                                                'Expected_Properties'))
        for lineedit_widget in lineedit_widget_list_in_table_tree_view:
            general.select_item_in_widget_tree_view(lineedit_widget)
            general.verify_properties_in_editor(expected_properties)
        _post_condition()

    except Exception as runtime_args:
        raise Exception(str(runtime_args.message))


def _post_condition():
    # quit the FBE application
    general.quit_application(app_name)

#===========================Revision History===================================
#Modifier       Modified On                 Modification Reason
#Girish Nair    09/08/2017                  New script created
#==============================================================================
