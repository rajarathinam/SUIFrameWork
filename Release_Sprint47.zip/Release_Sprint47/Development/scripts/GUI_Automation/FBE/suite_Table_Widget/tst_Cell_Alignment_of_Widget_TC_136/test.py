# -*- coding: utf-8 -*-

"""
Aim of the script  : Verify if the alignment of a widget in a cell can be set
                     in the editor
Reference document : TAR-TPS-001-TPS_ADT_FBE_ITV_FWQ_Sprint 45.docx
Test case ID       : TC136
"""

import general
import native_squish_apis
app_name = "FBE"


def _pre_condition():
    #Open the editor by running ./FBE
    general.launch_application(app_name, write_result=False)


def main():
    try:
        # Call the test script pre-requisites
        _pre_condition()
        # Step 1:Verify if table widget can be added to editor form by
        # dragging and dropping
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_TableWidget',
                                    widget_name='Table Widget',
                                    target_name='Editor Form')
        data_set = testData.dataset(general.get_path("testdata") +
                            "/Cell_Alignment_of_Widget_TC_136.tsv")
        # Declare an iterator variable
        iterator = 0
        for row in data_set:
            property_name = testData.field(row, 'property_name')
            property_value = testData.field(row, 'property_value')
            context_menu_item = testData.field(row, 'context_menu_item')
            tree_view_widget_name = testData.field(row,
                                                   'tree_view_widget_name')
            if(iterator <= 1):
                #Step6 : Right click on the added Table Widget, select Insert
                #        Rows
                #Step8 : Right click on the added Table Widget, select Insert
                #        Columns
                general.update_and_verify_table_entries(tree_view_widget_name,
                                             context_menu_item, property_name,
                                             property_value, write_result=True)
                general.verify_table_entries_in_preview(tree_view_widget_name,
                         'objectName', tab_name='tbp2',
                         write_result=True)
        general.update_property_value_in_editor(widget_name="TableWidget",
                                        property_name="setitemtype",
                                        value_to_be_set="Set Item Type",
                                        write_result=True)
        general.set_table_item(widget_name="Button", table_entity="SingleCell",
                               start='1', end='1')
        button_widget_list_in_table_tree_view = general.verify_table_item_tree_view_names(
                                             widget_id='taw29',
                                             widget_name="Button",
                                             table_entity="SingleCell",
                                             write_result=True)
        button_widget_list_in_table_preview = general.verify_table_item_obj_in_preview(
                    widget_name="Button",
                    table_cell_name_list=button_widget_list_in_table_tree_view,
                    write_result=True)
        general.select_item_in_widget_tree_view(
                                    button_widget_list_in_table_tree_view[0])
        general.update_property_value_in_editor(widget_name="Button",
                                        property_name="cellalignment",
                                        value_to_be_set="Left",
                                        write_result=True)
        general.go_to_preview_screen(tab_obj_id='tbp2')
        general.verify_table_entries_in_preview(tree_view_widget_name,
                         'cellalignment', tab_name='tbp2',
                         expected_prop_value=['0,4'],
                         qt_widget_children=button_widget_list_in_table_preview,
                         write_result=True)
        general.select_item_in_widget_tree_view(
                                    button_widget_list_in_table_tree_view[0])
        general.update_property_value_in_editor(widget_name="Button",
                                        property_name="cellalignment",
                                        value_to_be_set="Center",
                                        write_result=True)
        general.go_to_preview_screen(tab_obj_id='tbp2')
        general.verify_table_entries_in_preview(tree_view_widget_name,
                         'cellalignment', tab_name='tbp2',
                         expected_prop_value=['28,4'],
                         qt_widget_children=button_widget_list_in_table_preview,
                         write_result=True)
        general.select_item_in_widget_tree_view(
                                    button_widget_list_in_table_tree_view[0])
        general.update_property_value_in_editor(widget_name="Button",
                                        property_name="cellalignment",
                                        value_to_be_set="Right",
                                        write_result=True)
        general.go_to_preview_screen(tab_obj_id='tbp2')
        general.verify_table_entries_in_preview(tree_view_widget_name,
                         'cellalignment', tab_name='tbp2',
                         expected_prop_value=['56,4'],
                         qt_widget_children=button_widget_list_in_table_preview,
                         write_result=True)
        general.select_item_in_widget_tree_view(
                                    button_widget_list_in_table_tree_view[0])
        general.update_property_value_in_editor(widget_name="Button",
                                        property_name="cellalignment",
                                        value_to_be_set="Stretch",
                                        write_result=True)
        general.go_to_preview_screen(tab_obj_id='tbp2')
        general.verify_table_entries_in_preview(tree_view_widget_name,
                         'cellalignment', tab_name='tbp2',
                         expected_prop_value=['0,0'],
                         qt_widget_children=button_widget_list_in_table_preview,
                         write_result=True)
        _post_condition()

    except Exception as runtime_args:
        raise Exception(str(runtime_args.message))


def _post_condition():
    # quit the FBE application
    general.quit_application(app_name)

#===========================Revision History===================================
#Modifier       Modified On                 Modification Reason
#Girish Nair    09/08/2017                  New script created
#==============================================================================
