# -*- coding: utf-8 -*-

"""
Aim of the script  : VERIFY THE COLOR INTERFACE IN THE EDITOR
Reference document : TAR-TPS-001-TPS_ADT_FBE_ITV_FWQ_Sprint 47
Test case ID       : TC0128
"""

import general


def main():
    try:
        # Step 1:Start the FBE application
        general.launch_application('FBE', write_result=True)

        # Step 2:Add DropDown to the form
        general.verify_widget_drag_and_drop(
                                    'FBE_MainWindow_WidgetIcon_DropDown',
                                    widget_name='DropDown Widget',
                                    target_name='Editor Form')

        # Step 3 & 4:Verify if the properties Color and BGColor are available.Set the color of the DropDown to Red
        general.update_property_value_in_editor(widget_name='DropDown', property_name='BGColor',
                                    value_to_be_set='red', write_result=True)
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='DropDown', widget_id='ddb29', expected_prop_value={'BGColor':'red'},
                    write_result=True)
        # Step 5:Set the BGColor of the DropDown to green
        general.update_property_value_in_editor(widget_name='DropDown', property_name='BGColor',
                                    value_to_be_set='green', write_result=True)
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='DropDown', widget_id='ddb29', expected_prop_value={'BGColor':'green'},
                    write_result=True)
        # Step 6:Save the file as testSetColor_DropDown.xml
        general.save_file_in_editor(file_name='testSetColor_DropDown.xml',
              directory_path='/home/adt/ADT/ASML-ADT/Trunk/targets/bin/')
        # Step 7:Close and relaunch FBE
        general.quit_application(app_name='FBE', file_name='',
                directory_path='/home/adt/ADT/ASML-ADT/Trunk/targets/bin/')
        general.launch_application('FBE', write_result=True)
        
        # Step 8:Open the file testddb_FrontSize.xml and preview
        general.open_file_in_editor(file_name='testSetColor_DropDown.xml',
              directory_path='/home/adt/ADT/ASML-ADT/Trunk/targets/bin/')
        # Step 9:Verify is all colors match the colors set in the editor
        general.verify_properties_in_preview(tab_obj_id='tbp2',widget_name='DropDown', widget_id='ddb29', expected_prop_value={'BGColor':'green'},
                    write_result=True)       
    except Exception as runtime_args:
        raise Exception(str(runtime_args.message))

#===========================Revision History===================================
#Modifier       Modified On                 Modification Reason
#Saisivaprasad   14/07/2017                  Applied new coding standards
#Saisivaprasad    21/08/2017                  Applied new framework methods
#==============================================================================