//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SetNameDialog.
// !\description Header file for class SetNameDialog.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef TABBARNAMEDIALOG_H
#define TABBARNAMEDIALOG_H

#include <QDialog>
#include <QString>

namespace Ui
{
class SetNameDialog;
}

class SetNameDialog : public QDialog
{
    Q_OBJECT

public:
    explicit SetNameDialog(const QString &oldtabname, QWidget *parent = 0);
    virtual ~SetNameDialog();

    void    setEditLabelText(const QString text);
    QString getName() const;

private:
    Ui::SetNameDialog *ui;

};

#endif // TABBARNAMEDIALOG_H
