//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class FormEditor.
// !\description Header file for class FormEditor.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef FORMEDITOR_H
#define FORMEDITOR_H

#include "WidgetController.h"

#include <QGroupBox>

#include <FWQxCore/SUIVersionInfo.h>

class FormEditor : public WidgetController
{
public:
    explicit FormEditor(QWidget *parent = 0);
    virtual ~FormEditor() {}

    void acceptVisitor(GUIDefinitionVisitor &visitor , bool bSkipUCtrl = false);
    void reset();
    void readInclude(const QString &incfile);
    void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);
    void setInclude(const QString &include, const QString &fileName);

    QString getPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID) const;
    void setGridPixmap();

    bool hasRightButtonBar() const;
    bool hasBottomButtonBar() const;
    bool hasStatusBar() const;
    int rightButtonBarWidth() const;
    int bottomButtonBarHeight() const;
    int statusBarHeight() const;

    static SUI::VersionInfo getVersion();
    static SUI::VersionInfo getEditorVersion();

private:
    WidgetController *mBaseWidgetController;
    QMap<QString, QString> mUtcProperties;
    static const int cm_RightButtonBarWidth = 220;
    static const int cm_BottomButtonBarHeight = 50;
    static const int cm_StatusBarHeight = 50;

    static const SUI::VersionInfo suiVersion;
    static const SUI::VersionInfo suiEditorVersion;

};

#endif // FormEditor_H
