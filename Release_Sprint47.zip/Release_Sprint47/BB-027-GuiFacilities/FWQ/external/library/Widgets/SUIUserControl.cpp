//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for UserControl.
// !\description Class implementation file for UserControl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "FWQxWidgets/SUIUserControl.h"

#include "FWQxCore/SUIObjectFactory.h"

SUI::UserControl::UserControl() : 
    Widget(SUI::ObjectType::UserControl)
{
}

SUI::UserControl::~UserControl()
{
}
