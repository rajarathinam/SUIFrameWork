//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::TreeViewItem.
// !\description Header file for class SUI::TreeViewItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|



#ifndef SUITREEVIEWITEM_H
#define SUITREEVIEWITEM_H

#include "FWQxCore/SUIIText.h"
#include "FWQxWidgets/SUIWidget.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief Specific Interface for the TreeItem
 */
class SUI_SHARED_EXPORT TreeViewItem : public Widget, public IText
{
public:
    virtual ~TreeViewItem();
    
protected:
    TreeViewItem();

};
}

#endif // SUITREEVIEWITEM_H
