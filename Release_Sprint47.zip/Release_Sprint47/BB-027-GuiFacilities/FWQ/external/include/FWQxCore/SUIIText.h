//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::IText.
// !\description Header file for class SUI::IText.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIITEXT_H
#define SUIITEXT_H

#include <string>

#include <boost/function.hpp>

namespace SUI {

/*!
 * \ingroup FWQxCore
 *
 * \brief Global Interface class for text elements
 */
class IText
{
public:
    virtual ~IText() {}

    /*!
     * \brief setText
     * Sets the text of a widget. This for example be the text on a button widget.
     * \param value - The text to set.
     */
    virtual void setText(const std::string &value) = 0;

    /*!
     * \brief getText
     * Gets the text of a widget. This for example be the text on a button widget.
     * \return - The text set on the widget
     */
    virtual std::string getText() const = 0;

    /*!
     * \brief clearText
     * Clears the widget's text
     */
    virtual void clearText() = 0;

    /*!
     * \brief setBold
     * Set the text weight to bold (if input equals true)
     * \param bold - Set text bold
     */
    virtual void setBold(bool bold) = 0;

    /*!
     * \brief isBold
     * Returns whether the text of the widget is bold or not
     * \return
     */
    virtual bool isBold() const = 0;

    /*!
     * \brief textChanged
     * Callback function that is called when the text has changed.
     */
    boost::function<void(const std::string&)> textChanged;
};
}

#endif // SUIITEXT_H
