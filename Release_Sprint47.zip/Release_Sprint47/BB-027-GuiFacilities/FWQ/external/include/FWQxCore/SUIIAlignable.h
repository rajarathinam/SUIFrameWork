//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::IAlignable.
// !\description Header file for class SUI::IAlignable.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIIALIGNABLE_H
#define SUIIALIGNABLE_H

#include "FWQxCore/SUIAlignmentEnum.h"

namespace SUI {

/*!
 * \ingroup FWQxCore
 *
 * \brief Generic Interface class for alignment of a widget
 */
class IAlignable
{
public:
    virtual ~IAlignable() {}

    /*!
     * \brief setAlignment
     * Sets the alignment
     * \param align The kind of alignment to set
     */
    virtual void setAlignment(AlignmentEnum::Alignment align) = 0;

    /*!
     * \brief getAlignment
     * Returns the current alignment
     * \return
     */
    virtual AlignmentEnum::Alignment getAlignment() const = 0;
};
}

#endif // IALIGNABLE_H
