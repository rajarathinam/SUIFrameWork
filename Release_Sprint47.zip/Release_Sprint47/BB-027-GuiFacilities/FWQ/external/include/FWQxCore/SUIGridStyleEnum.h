//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::GridStyleEnum.
// !\description Header file for class SUI::GridStyleEnum.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|



#ifndef SUIGRIDSTYLEENUM_H
#define SUIGRIDSTYLEENUM_H

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief This enum type is used to describe grid styles.
 */
class GridStyleEnum
{
public:
    /*!
     * \brief GridStyle
     * The grid style enumeration
     */
    typedef enum
    {
        Off,
        Normal,
        Detail
    } GridStyle;
};
}
#endif // SUIGRIDSTYLEENUM_H
