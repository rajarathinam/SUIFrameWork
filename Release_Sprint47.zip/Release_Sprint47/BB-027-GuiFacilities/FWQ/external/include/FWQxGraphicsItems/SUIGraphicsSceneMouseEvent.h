//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::GraphicsSceneMouseEvent.
// !\description Header file for class SUI::GraphicsSceneMouseEvent.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIGRAPHICSSCENEMOUSEEVENT_H
#define SUIGRAPHICSSCENEMOUSEEVENT_H

#include "FWQxCore/SUISharedExport.h"

#include "FWQxCore/SUIMouseButtonEnum.h"

#include <boost/shared_ptr.hpp>

class CustomGraphicsScene;

namespace SUI {
/*!
 * \ingroup FWQxGraphicsItems
 *
 * \brief The GraphicsSceneMouseEvent class
 */
class SUI_SHARED_EXPORT GraphicsSceneMouseEvent
{
public:

    /*!
     * \brief getPosX
     * Returns the mouse cursor X-position in item coordinates
     * \return
     */
    double getPosX() const;

    /*!
     * \brief getPosY
     * Returns the mouse cursor Y-position in item coordinates
     * \return
     */
    double getPosY() const;

    /*!
     * \brief getScenePosX
     * Returns the mouse cursor X-position in scene coordinates
     * \return
     */
    double getScenePosX() const;

    /*!
     * \brief getScenePosY
     * Returns the mouse cursor Y-position in scene coordinates
     * \return
     */
    double getScenePosY() const;

    /*!
     * \brief getScreenPosX
     * Returns the mouse cursor X-position in screen coordinates
     * \return
     */
    double getScreenPosX() const;

    /*!
     * \brief getScreenPosY
     * Returns the mouse cursor Y-position in screen coordinates
     * \return
     */
    double getScreenPosY() const;

    /*!
     * \brief getLastPosX
     * Returns the last recorded mouse cursor X-position in item coordinates
     * \return
     */
    double getLastPosX() const;

    /*!
     * \brief getLastPosY
     * Returns the last recorded mouse cursor Y-position in item coordinates
     * \return
     */
    double getLastPosY() const;

    /*!
     * \brief getLastScenePosX
     * Returns the last recorded mouse cursor X-position in scene coordinates.
     * The last recorded position is the position of the previous mouse event
     * received by the view that created the event.
     * \return
     */
    double getLastScenePosX() const;

    /*!
     * \brief getLastScenePosY
     * Returns the last recorded mouse cursor Y-position in scene coordinates.
     * The last recorded position is the position of the previous mouse event
     * received by the view that created the event.
     * \return
     */
    double getLastScenePosY() const;

    /*!
     * \brief getLastScreenPosX
     * Returns the last recorded mouse cursor X-position in screen coordinates.
     * The last recorded position is the position of the previous mouse event
     * received by the view that created the event
     * \return
     */
    double getLastScreenPosX() const;

    /*!
     * \brief getLastScreenPosY
     * Returns the last recorded mouse cursor Y-position in screen coordinates.
     * The last recorded position is the position of the previous mouse event
     * received by the view that created the event
     * \return
     */
    double getLastScreenPosY() const;

    /*!
     * \brief getButton
     * Returns the mouse button (if any) that caused the event
     * \return
     */
    SUI::MouseButton getButton() const;

    /*!
     * \brief getWheelDirection
     * Returns the direction in which the mouse wheel was rotated. Up means that
     * the wheel was rotated away from the user. Down means that the wheel was rotated
     * towards the user
     * \return
     */
    SUI::WheelDirection getWheelDirection() const;

private:
    friend class ::CustomGraphicsScene;
    
    explicit GraphicsSceneMouseEvent(
          double posX = 0, 
          double posY = 0, 
          double scenePosX = 0, 
          double scenePosY = 0, 
          double screenPosX = 0, 
          double screenPosY = 0, 
          double lastPosX = 0, 
          double lastPosY = 0, 
          double lastScenePosX = 0, 
          double lastScenePosY = 0, 
          double lastScreenPosX = 0, 
          double lastScreenPosY = 0,
          SUI::MouseButton button = SUI::NoButton, 
          SUI::WheelDirection wheelDirection = SUI::Up);
    
    GraphicsSceneMouseEvent(const GraphicsSceneMouseEvent &copy);
    GraphicsSceneMouseEvent &operator=(const GraphicsSceneMouseEvent &copy);
    
    static boost::shared_ptr<SUI::GraphicsSceneMouseEvent> create(void *qEvent);
    
    double posX;
    double posY;
    double scenePosX;
    double scenePosY;
    double screenPosX;
    double screenPosY;

    double lastPosX;
    double lastPosY;
    double lastScenePosX;
    double lastScenePosY;
    double lastScreenPosX;
    double lastScreenPosY;

    MouseButton button;

    WheelDirection wheelDirection;
};
}

#endif // GRAPHICSSCENEMOUSEEVENT_H
