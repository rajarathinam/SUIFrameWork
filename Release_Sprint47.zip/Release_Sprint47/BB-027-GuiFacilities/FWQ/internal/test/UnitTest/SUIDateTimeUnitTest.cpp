
#include "SUIDateTimeUnitTest.h"
#include <FWQxUtils/SUIDateTime.h>

#include <QTest>

SUI::DateTimeUnitTest::DateTimeUnitTest() :
    dateTime(SUI::DateTime::createDateTime())
{
}

void SUI::DateTimeUnitTest::tesCurrentDateTime() {
    QCOMPARE(QString::fromStdString( dateTime->toString( "hh:mm" )), QDateTime::currentDateTime().toString("hh:mm"));
    QCOMPARE(QString::fromStdString( dateTime->toString( "dd:MM:yyyy" )), QDateTime::currentDateTime().toString("dd:MM:yyyy"));
}
