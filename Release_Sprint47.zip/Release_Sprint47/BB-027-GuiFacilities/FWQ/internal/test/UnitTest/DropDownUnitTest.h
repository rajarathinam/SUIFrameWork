#ifndef DROPDOWNUNITTEST_H
#define DROPDOWNUNITTEST_H

#include <QTest>
#include <QString>
#include <SUIDropDownImpl.h>
#include <FWQxCore/SUIObjectList.h>
#include <SUIBaseWidget.h>

class DropDownUnitTest : public QObject
{
    Q_OBJECT
public:
    DropDownUnitTest();

public slots:

private Q_SLOTS:
    void initTestCase();
    void cleanupTestCase();

///// Unit testen
    // Visibility
    void testVisibilityCase2();
    void testVisibilityCase2_data();

    // Enabled
    void testEnabledCase2();
    void testEnabledCase2_data();

    // GetText
    void testGetTextCase1();
    void testGetTextCase1_data();

    // GetSelectedItems
    void testGetSelectedItemsCase1();
    void testGetSelectedItemsCase1_data();

    // SetText (add item)
    void testSetTextCase2();
    void testSetTextCase2_data();

    // Remove a item from the dropdown
    void testRemoveItemCase1();
    void testRemoveItemCase1_data();

    // ClearText
    void testClearTextCase2();
    void testClearTextCase2_data();

    // Get colors
    void testGetColorsCase1();
    void testGetColorsCase1_data();

    // Color set & get color
    void testColorCase1();
    void testColorCase1_data();

    // Color set & get BackGround color
    void testBGColorCase1();
    void testBGColorCase1_data();

    // Set Bold
    void testSetBoldCase1();
    void testSetBoldCase1_data();

    // Set Width
    void testWidthCase1();
    void testWidthCase1_data();

    // Set Width
    void testWidthCase2();
    void testWidthCase2_data();

    // clearItems + getAllColumnItems
    void testClearItemsCase2();
    void testClearItemsCase2_data();

    // AddItems + GetItems
    void testAddItemsCase1();
    void testAddItemsCase1_data();

    // SetMode background
    void testSetModeCase1();
    void testSetModeCase1_data();

    // HandleChange
    void testHandleChangeCase1();
    void testHandleChangeCase1_data();

    // selectItem
    void testSelectItemCase1();
    void testSelectItemCase1_data();


///// Interface Unit Testen
    // IWidgetStatus Visibility
    void testVisibilityCase1();
    void testVisibilityCase1_data();

    // IWidgetStatus Enabled
    void testEnabledCase1();
    void testEnabledCase1_data();

    // GetSelectedItems
    void testGetSelectedItemsCase2();
    void testGetSelectedItemsCase2_data();

    // Remove a item from the dropdown
    void testRemoveItemCase2();
    void testRemoveItemCase2_data();

    // AddItems
    void testAddItemsCase2();
    void testAddItemsCase2_data();

    // Get colors
    void testGetColorsCase2();
    void testGetColorsCase2_data();

    // Color set & get color
    void testColorCase2();
    void testColorCase2_data();

    // Color set & get BackGround color
    void testBGColorCase2();
    void testBGColorCase2_data();

    // clearItems + GetItems
    void testClearItemsCase1();
    void testClearItemsCase1_data();

    // SetMode background
    void testSetModeCase2();
    void testSetModeCase2_data();

private:
    SUI::DropDownImpl *mDropDownWidg;
    SUI::DropDown *mIDropDownWidg;
    SUI::Widget *mIDropDownWidg_Status;
    SUI::IColorable *mIDropDownWidg_Color;
    SUI::IBGColorable *mIDropDownWidg_BGColor;
    SUI::StringList *mIDropDownWidg_Items;
    SUI::IErrorMode *mIDropDownWidg_ErrorMode;
};

#endif // DROPDOWNUNITTEST_H
