
#ifndef SUIIMAGEWIDGETIMPLUNITTEST_H
#define SUIIMAGEWIDGETIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class ImageWidgetImpl;

class ImageWidgetImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit ImageWidgetImplUnitTest(ImageWidgetImpl *object, QObject *parent = 0);
    virtual ~ImageWidgetImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    ImageWidgetImpl *object;
};

}
#endif // SUIIMAGEWIDGETIMPLUNITTEST_H
