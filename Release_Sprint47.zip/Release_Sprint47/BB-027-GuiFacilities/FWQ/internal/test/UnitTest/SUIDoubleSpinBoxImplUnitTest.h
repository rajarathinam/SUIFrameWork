
#ifndef SUIDOUBLESPINBOXIMPLUNITTEST_H
#define SUIDOUBLESPINBOXIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class DoubleSpinBoxImpl;

class DoubleSpinBoxImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit DoubleSpinBoxImplUnitTest(DoubleSpinBoxImpl *object, QObject *parent = 0);
    virtual ~DoubleSpinBoxImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    DoubleSpinBoxImpl *object;
};

}
#endif // SUIDOUBLESPINBOXIMPLUNITTEST_H
