
#ifndef SUILEDWIDGETIMPLUNITTEST_H
#define SUILEDWIDGETIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class LEDWidgetImpl;

class LEDWidgetImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit LEDWidgetImplUnitTest(LEDWidgetImpl *object, QObject *parent = 0);
    virtual ~LEDWidgetImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    LEDWidgetImpl *object;
};

}
#endif // SUILEDWIDGETIMPLUNITTEST_H
