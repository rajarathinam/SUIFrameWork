#ifndef SUIBUTTONUNITTEST_H
#define SUIBUTTONUNITTEST_H

#include "SUIWidgetUnitTest.h"

namespace SUI {

class Button;

class ButtonUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    explicit ButtonUnitTest(Button *object, QObject *parent = 0);
    virtual ~ButtonUnitTest();

protected:
    void callInterfaceTests();

private:
    Button *object;
};

}
#endif // SUIBUTTONUNITTEST_H
