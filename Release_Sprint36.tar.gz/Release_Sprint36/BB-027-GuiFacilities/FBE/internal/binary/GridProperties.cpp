//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for GridProperties.
// !\description Class implementation file for GridProperties.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "GridProperties.h"
#include "ui_GridProperties.h"

GridProperties::GridProperties(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::GridProperties)
{
    ui->setupUi(this);
    ui->mXGridSB->setValue(Model::instance()->XGridDistance());
    ui->mYGridSB->setValue(Model::instance()->YGridDistance());
    ui->mGridActiveCB->setChecked(Model::instance()->gridActive());
    ui->mXSnapCB->setChecked(Model::instance()->xSnap());
    ui->mYSnapCB->setChecked(Model::instance()->ySnap());
    connect(ui->mOkPB, SIGNAL(clicked()), this, SLOT(onOkClicked()));
    connect(ui->mCancelPB, SIGNAL(clicked()), this, SLOT(reject()));
    connect(ui->mGridActiveCB, SIGNAL(clicked(bool)), this, SLOT(onGridActiveClicked(bool)));
    onGridActiveClicked(ui->mGridActiveCB->isChecked());
}

GridProperties::~GridProperties()
{
    delete ui;
}

void GridProperties::onOkClicked()
{
    Model::instance()->setXGridDistance(ui->mXGridSB->value());
    Model::instance()->setYGridDistance(ui->mYGridSB->value());
    Model::instance()->useGrid(ui->mGridActiveCB->isChecked());
    Model::instance()->setXSnap(ui->mXSnapCB->isChecked());
    Model::instance()->setYSnap(ui->mYSnapCB->isChecked());
    accept();
}

void GridProperties::onGridActiveClicked(bool checked)
{
    ui->mXGridSB->setEnabled(checked);
    ui->mYGridSB->setEnabled(checked);
    ui->mXSnapCB->setEnabled(checked);
    ui->mYSnapCB->setEnabled(checked);
}
