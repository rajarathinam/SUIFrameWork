//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for WidgetSelector.
// !\description Class implementation file for WidgetSelector.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include <QPushButton>
#include <QLabel>
#include <QHBoxLayout>

#include <SUIStyleSheet.h>
#include <SUILineWidget.h>

#include "widgetselector.h"
#include "WidgetController.h"
#include "WidgetControllerInfo.h"
#include "Model.h"

const QList<SUI::ObjectType::Type> WidgetSelector::cmAllowedWidgetList = {
    SUI::ObjectType::BusyIndicator,
    SUI::ObjectType::Button,
    SUI::ObjectType::CheckBox,
    SUI::ObjectType::CheckGroupBox,
    SUI::ObjectType::ColorDrop,
    SUI::ObjectType::DropDown,
    SUI::ObjectType::GroupBox,
    SUI::ObjectType::GraphicsView,
    SUI::ObjectType::Label,
    SUI::ObjectType::LineEdit,
    SUI::ObjectType::ListView,
    SUI::ObjectType::PlotWidget,
    SUI::ObjectType::ProgressBar,
    SUI::ObjectType::QuestionMark,
    SUI::ObjectType::RadioButton,
    SUI::ObjectType::SpinBox,
    SUI::ObjectType::StateWidget,
    SUI::ObjectType::TableWidget,
    SUI::ObjectType::TabWidget,
    SUI::ObjectType::TextArea,
    SUI::ObjectType::TreeView,
    SUI::ObjectType::SvgWidget,
    SUI::ObjectType::Container,
    SUI::ObjectType::ScrollBar
};

WidgetSelector::WidgetSelector(QWidget *parent) :
    WidgetController(parent, WidgetController::WidgetSelectorMode)
{
}

WidgetSelector::~WidgetSelector()
{
    foreach(WidgetController *wcChild, mChildren)
    {
        if (wcChild)
        {
            wcChild->deleteLater();
        }
    }
    mChildren.clear();
}

/*****************************************************************************\
 *  FUNCTION    :   InitWidgets
 *  PARAMETERS  :   IRticWidgetFactory &widgetFactory
 *  RETURN      :   void
 *
 *  This function creates an instance of all widgets. A Pixmap is being made,
 *  the WidgetSelector and the instance is added to TheWidgetStore (in Model).
 *  Because the GroupBoxes and the TabWidget have a transparent background,
 *  which doesn't look good if a Pixmap is been made for the selector, a copy
 *  is being made with a white backgound for the (Check)GroupBox and TabWidget,
 *  with a white background. This works for the GroupBoxes, but for some reason,
 *  not for the TabWidget.
\*****************************************************************************/
void WidgetSelector::initWidgets() {
    using namespace SUI;

    QVBoxLayout *selectorLayout = new QVBoxLayout(this);
    WidgetController *parentWidgetController = new WidgetController(NULL, WidgetController::RootWidgetMode);

    int dTotal = cmAllowedWidgetList.count() - 1;
    int dInd = 0;
    foreach(const ObjectType::Type widgetType, cmAllowedWidgetList)
    {
        BaseWidget *baseWidget = SUI::ObjectFactory::getInstance()->createWidget(widgetType);
        baseWidget->getWidget()->setStyleSheet(QString::fromStdString(StyleSheet::getInstance()->getStyleSheet()));
        baseWidget->initialize(BaseWidget::EditorSelector);

        WidgetController *baseWidgetController = new WidgetController(parentWidgetController, WidgetController::SingleWidgetMode, baseWidget);

        if (widgetType == ObjectType::TabWidget)
        {
            WidgetController *tabPage = baseWidgetController->addTabPage("Tab");
            tabPage->setWidgetMode(WidgetController::WidgetSelectorMode);
            tabPage->updatePixmap();
        }
        baseWidgetController->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        baseWidgetController->setId(QString::fromStdString(ObjectType::toString(widgetType)));

        QPixmap pixmap = QPixmap::grabWidget(baseWidgetController).scaled(90, 30, Qt::KeepAspectRatio, Qt::SmoothTransformation);

        WidgetDefinition baseWidgetControllerDefinition;
        baseWidgetControllerDefinition.setPropertyValue(ObjectPropertyTypeEnum::ObjectType, QString::fromStdString(ObjectType::toString(ObjectType::ImageWidget)));
        baseWidgetControllerDefinition.setPropertyValue(ObjectPropertyTypeEnum::Height, QString::number(pixmap.height()));
        baseWidgetControllerDefinition.setPropertyValue(ObjectPropertyTypeEnum::Width, QString::number(pixmap.width()));
        baseWidgetControllerDefinition.setPropertyValue(ObjectPropertyTypeEnum::ID, QString::fromStdString(ObjectType::toString(widgetType)));
        baseWidgetControllerDefinition.setPropertyValue(ObjectPropertyTypeEnum::Sizeable, "false");

        WidgetController *thbCtrl = baseWidgetControllerDefinition.addToWidget(this, false);
        thbCtrl->getBaseWidget()->initialize(BaseWidget::EditorSelector);

        thbCtrl->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        thbCtrl->setChildrenWidgetMode(WidgetController::WidgetSelectorMode);
        qobject_cast<QLabel *>(thbCtrl->getBaseWidget()->getWidget())->setPixmap(pixmap);
        thbCtrl->setPixmapSize();
        thbCtrl->updatePixmap();

        Model::instance()->store(baseWidgetController);
        parentWidgetController->removeChild(baseWidgetController);

        baseWidgetController->setParent(NULL);
        baseWidgetController->removeFromModel();

        QHBoxLayout *widgetLayout = new QHBoxLayout;
        widgetLayout->addWidget(thbCtrl);
        widgetLayout->addStretch();
        widgetLayout->addWidget(new QLabel(QString::fromStdString(ObjectType::toString(widgetType))));

        selectorLayout->addLayout(widgetLayout);

        if (dInd++ < dTotal)
        {
            LineWidget *line = SUI::ObjectFactory::getInstance()->createWidget_<LineWidget>();
            BaseWidget *lineWidget = SUI::ObjectFactory::getInstance()->toBaseWidget(line);
            lineWidget->initialize(BaseWidget::EditorSelector);

            WidgetController *lineWidgetController = new WidgetController(this, WidgetController::SingleWidgetMode, lineWidget);
            lineWidgetController->setPropertyValue(ObjectPropertyTypeEnum::Height, "4");
            lineWidgetController->setPropertyValue(ObjectPropertyTypeEnum::Width, "200");
            lineWidgetController->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
            lineWidgetController->setId("WidgetSelector");

            selectorLayout->addWidget(lineWidgetController);

            mChildren.append(lineWidgetController);
        }
        baseWidgetController->updatePixmap();
    }
    parentWidgetController->removeFromModel();


    //  Don't delete wcbaseWidget, since that is the parent of all widgets in the WidgetStore.
    selectorLayout->setSizeConstraint(QLayout::SetFixedSize);
    // Add a vertical spacer to take up the remaining available space
    QSpacerItem *spacer = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Expanding);
    selectorLayout->addItem(spacer);
    setLayout(selectorLayout);
    updatePixmap();
}
