//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::Exception.
// !\description Header file for class SUI::Exception.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIEXCEPTION_H
#define SUIEXCEPTION_H

#include <string>

#include <exception>
#include "SUISharedExport.h"

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief The Exception class
 */
class SUI_SHARED_EXPORT Exception : public std::exception
{
public:
    /*!
     * \brief Exception
     * constructs an std::exception with the given msg
     * \param msg
     */
    Exception(const std::string &msg);

    virtual ~Exception() throw();

    /*!
     * \brief getExceptionMessage
     * return Exception Message
     * \return
     */
    std::string getExceptionMessage() const;

    /*!
     * \brief what
     * A pointer to a c-string with content related to the exception.
     * \return
     */
    virtual const char *what() const throw();

private:
    std::string mMessage;

    Exception();
};
}
#endif // SUIEXCEPTIONS_H
