//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::SortOrderEnum.
// !\description Header file for class SUI::SortOrderEnum.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUISORTORDERENUM_H
#define SUISORTORDERENUM_H

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief This enum type is used to describe sort order options.
 */
class SortOrderEnum
{
public:
    /*!
     * \brief SortOrder
     * The sort order enumeration
     */
    typedef enum
    {
        Unsorted,
        Ascending,
        Descending
    } SortOrder;
};
}
#endif // SUISORTORDERENUM_H
