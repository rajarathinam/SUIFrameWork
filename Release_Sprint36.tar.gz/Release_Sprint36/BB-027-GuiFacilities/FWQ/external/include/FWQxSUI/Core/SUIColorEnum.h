//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ColorEnum.
// !\description Header file for class SUI::ColorEnum.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|



#ifndef SUICOLORENUM_H
#define SUICOLORENUM_H

#include <string>
#include <list>
#include <map>
#include <algorithm>

#include "SUIObjectType.h"

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief This enum type is used to describe colors and related operations.
 */
class ColorEnum
{
public:
    /*!
     * \brief Color
     * The Color enumeration
     */
    typedef enum
    {
        Standard,
        Black,
        Green,
        Red,
        Gray,
        Blue,
        White,
        Yellow,
        Orange,
        Transparent
    } Color;

    /*!
     * \brief fromString
     * Convert string to Color
     * \param colorStr: string to be converted
     * \return
     */
    static SUI::ColorEnum::Color fromString(const std::string &colorStr);

    /*!
     * \brief toString
     * Convert Color to string
     * \param color: Color to be converted
     * \return
     */
    static std::string toString(ColorEnum::Color color);

    /*!
     * \brief toStringList
     * Convert a list of Colors to a list of strings
     * \param list: list of Colors
     * \return
     */
    static std::list<std::string> toStringList(const std::list<ColorEnum::Color> &list);

    /*!
     * \brief toString
     * Convert a list of Colors to a separated list of strings
     * \param list: list of Colors
     * \param separator: separator character
     * \return
     */
    static std::string toString(const std::list<ColorEnum::Color> &list, const std::string &separator = ";");

    /*!
     * \brief getColorStringList
     * Returns a list of (color) strings
     * \return
     */
    static std::list<std::string> getColorStringList();

    /*!
     * \brief getColorMap
     * Returns a mapping from Color to string
     * \return
     */
    static std::map<ColorEnum::Color,std::string> getColorMap();

    /*!
     * \brief getColorsString
     * Returns a list of strings
     * \return
     */
    static std::string getColorsString();

    /*!
     * \brief getColorEnumList
     * Returns a list of Colors, specific to an Object type
     * \param objectType: object of which the colors need to be retreived
     * \return
     */
    static const std::list<ColorEnum::Color> getColorEnumList(const ObjectType::Type &objectType = SUI::ObjectType::None);

    /*!
     * \brief exists
     * Determines if a color is available in a list of Colors
     * \param list: list of Colors
     * \param entry: Color that needs to be checked for availability in 'list'
     * \return
     */
    static bool exists(const std::list<ColorEnum::Color> &list, const Color &entry);

private:
    static std::map<ColorEnum::Color,std::string> colorMap;
    static std::list<std::string> colorStringList;
    static std::string colorsString;
    typedef std::list<ColorEnum::Color> StaticColorList;
    static std::map<SUI::ObjectType::Type,const StaticColorList> colorsByObjectType;
};
}
#endif // SUICOLORENUM_H
