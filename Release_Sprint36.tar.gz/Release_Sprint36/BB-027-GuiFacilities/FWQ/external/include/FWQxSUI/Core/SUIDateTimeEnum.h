//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::DateTimeEnum.
// !\description Header file for class SUI::DateTimeEnum.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIDATETIMEENUM_H
#define SUIDATETIMEENUM_H

namespace SUI {

/*!
 * \ingroup FWQxCore
 *
 * \brief This enum type is used to date time formats and time locales.
 */
class DateTimeEnum
{
public:
    /*!
     * \brief DateFormat
     * The date format enumeration
     */
    enum DateFormat {
        TextDate,      // default
        ISODate,       // ISO 8601
        SystemLocaleDate, // deprecated
        LocalDate = SystemLocaleDate, // deprecated
        LocaleDate,     // deprecated
        SystemLocaleShortDate,
        SystemLocaleLongDate,
        DefaultLocaleShortDate,
        DefaultLocaleLongDate
    };

    /*!
     * \brief TimeSpec
     * The time specification enumeration
     */
    enum TimeSpec {
        LocalTime,
        UTC,
        OffsetFromUTC
    };
};

} // namespace SUI

#endif // SUI_SUIDATETIMEENUM_H
