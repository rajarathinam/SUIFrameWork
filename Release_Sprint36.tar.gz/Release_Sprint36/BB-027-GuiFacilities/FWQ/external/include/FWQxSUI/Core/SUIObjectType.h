//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ObjectType.
// !\description Header file for class SUI::ObjectType.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIOBJECTTYPE_H
#define SUIOBJECTTYPE_H

#include <string>
#include <vector>
#include <map>

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief The ObjectType class
 */
class ObjectType
{

public:
    /*!
     * \brief Type
     * The object type enumeration
     */
    typedef enum {
        None,
        Button,
        Label,
        LineEdit,
        CheckBox,
        RadioButton,
        GroupBox,
        CheckGroupBox,
        TabWidget,
        TabPage,
        ButtonBar,
        TableWidget,
        TableWidgetItem,
        SpinBox,
        DoubleSpinBox,
        DropDown,
        LEDWidget,
        CheckMark,
        ColorDrop,
        ColorCrossDrop,
        TextArea,
        ProgressBar,
        GraphicsView,
        MessageBox,
        PlotWidget,
        Splitter,
        FileDialog,
        UserControl,
        ListView,
        ControlWidget,
        StateWidget,
        ScienceSpinBox,
        QuestionMark,
        BusyIndicator,
        ImageWidget,
        TreeView,
        TreeViewItem,
        LineWidget,
        SvgWidget,
        FormEditor,
        WidgetPage,
        Dialog,
        Container,
        GraphicsPixmapItem,
        GraphicsTextItem,
        GraphicsRectItem,
        GraphicsLineItem,
        GraphicsEllipseItem,
        GraphicsCrosshairItem,
        GraphicsSvgItem,
        PlotCurveItem,
        PlotHistogramItem,
        ScrollBar
    } Type;

    /*!
     * \brief toString
     * Converts a Type element to a string
     * \param type
     * \return
     */
    static std::string toString(const Type &type);

    /*!
     * \brief fromString
     * Converts a string to a Type element
     * \param type
     * \return
     */
    static Type fromString(const std::string &type);

    /*!
     * \brief getIdPrefix
     * Returns the prefix of the supplied object type.
     * Each object has its own prefix. For example, a button has prefix "btn"
     * and a progress bar has prefix "pgb"
     * \param type
     * \return
     */
    static std::string getIdPrefix(const Type &type);

private:
    static const std::map<Type,const std::string> objectTypeStringMap;
    static const std::map<const std::string,Type> objectStringTypeMap;
    static const std::map<Type,const std::string> objectIdPrefixes;

    static const std::map<const std::string,Type> createObjectStringTypeMap();
};
}

#endif // SUIOBJECTTYPE_H
