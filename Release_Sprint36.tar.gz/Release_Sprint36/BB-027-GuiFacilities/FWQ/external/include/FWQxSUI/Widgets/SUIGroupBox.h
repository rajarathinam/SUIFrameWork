//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::GroupBox.
// !\description Header file for class SUI::GroupBox.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIGROUPBOX_H
#define SUIGROUPBOX_H

#include "SUIWidget.h"
#include "SUIIText.h"
#include "SUIIBGColorable.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief The GroupBox class
 */
class SUI_SHARED_EXPORT GroupBox : public Widget, public IText, public IBGColorable
{
public:
    virtual ~GroupBox();

    /*!
     * \brief setHover
     * Sets the background color of the groupbox when hovering over it
     * \param hover: Hover is on or off
     * \param color: Background color when hovering
     */
    virtual void setHover(bool hover, SUI::ColorEnum::Color color) = 0;
protected:
    GroupBox();
    GroupBox(const SUI::ObjectType::Type &type);

};
}

#endif // SUIGROUPBOX_H
