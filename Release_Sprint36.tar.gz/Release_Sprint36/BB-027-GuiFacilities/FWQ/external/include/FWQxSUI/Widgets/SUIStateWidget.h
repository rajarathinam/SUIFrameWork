//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::StateWidget.
// !\description Header file for class SUI::StateWidget.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUISTATEWIDGET_H
#define SUISTATEWIDGET_H

#include "SUIWidget.h"

#include <list>

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief Specific Interface for the State Widget
 */
class SUI_SHARED_EXPORT StateWidget : public Widget
{
public:
    virtual ~StateWidget();

    /*!
     * \brief getState
     * Retrieves the state of the widget as a string
     * \return
     */
    virtual std::string getState() const = 0;

    /*!
     * \brief getSupportedStates
     * Retrieve all supported states of the widget as a list of strings
     * \return
     */
    virtual std::list<std::string> getSupportedStates() const = 0;

    /*!
     * \brief setState
     * Sets the new state of the widget. An exception is thrown if the supplied state is
     * not available in the list of supported states. If the list of supported states is
     * empty, the default image will be shown: [no image]
     * \param state - the new state
     */
    virtual void setState(const std::string &state) = 0;
    
protected:
    StateWidget();
    StateWidget(const SUI::ObjectType::Type &type);
};
}

#endif // SUICONTROLWIDGET_H
