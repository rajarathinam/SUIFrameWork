//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::Label.
// !\description Header file for class SUI::Label.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUILABEL_H
#define SUILABEL_H

#include "SUIWidget.h"
#include "SUIIAlignable.h"
#include "SUIIText.h"
#include "SUIIColorable.h"
#include "SUIIBGColorable.h"
#include "SUIFontSizeEnum.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief Specific Interface for the Label Widget
 */
class SUI_SHARED_EXPORT Label : public Widget, public IText, public IAlignable, public IColorable, public IBGColorable
{
public:
    virtual ~Label();

    /*!
     * \brief setFontSize
     * Set the label's font size. Also see FontSizeEnum::FontSize
     * \param fontsize
     */
    virtual void setFontSize(const FontSizeEnum::FontSize &fontsize) = 0;

    /*!
     * \brief
     * Returns the font size (FontSizeEnum::FontSize)
     * \return
     */
    virtual FontSizeEnum::FontSize getFontSize() const = 0;

protected:
    Label();
};
}

#endif // SUILABEL_H
