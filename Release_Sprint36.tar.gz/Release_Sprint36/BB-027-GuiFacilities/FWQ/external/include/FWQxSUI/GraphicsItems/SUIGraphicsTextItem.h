//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::GraphicsTextItem.
// !\description Header file for class SUI::GraphicsTextItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUIGRAPHICSTEXTITEM_H
#define SUIGRAPHICSTEXTITEM_H

#include "SUIGraphicsItem.h"
#include "SUIIText.h"
#include "SUIColorEnum.h"

namespace SUI {
/*!
 * \ingroup FWQxGraphicsItems
 *
 * \brief The GraphicsText class
 */
class SUI_SHARED_EXPORT GraphicsTextItem : public GraphicsItem, public IText
{
public:
    virtual ~GraphicsTextItem();
   
    /*!
     * \brief getPenColor
     * Returns the color of this pen's brush
     * \return
     */
    SUI::ColorEnum::Color getPenColor() const;

    /*!
     * \brief setPenColor
     * Sets the color of this pen's brush to the given color
     * \param color
     */
    void setPenColor(const SUI::ColorEnum::Color color);

    /*!
     * \brief setPenWidth
     * Sets the pen width to the given width in pixels with integer precision
     * \param width
     */
    void setPenWidth(int width);

    /*!
     * \brief getPenWidth
     * Returns the pen width with integer precision
     * \return
     */
    int getPenWidth() const;

    /*!
     * \brief getBrushColor
     * Returns the brush color
     * \return
     */
    SUI::ColorEnum::Color getBrushColor() const;

    /*!
     * \brief setBrushColor
     * Sets the brush color
     * \param color
     */
    void setBrushColor(const SUI::ColorEnum::Color color);

    /*!
     * \brief penColorChanged
     * Callback that is triggered when the pen color changed
     */
    boost::function<void()> penColorChanged;

    /*!
     * \brief brushColorChanged
     * Callback that is triggered when the brush color changed
     */
    boost::function<void()> brushColorChanged;

    // IText
    /*!
     * \brief setText
     * Sets the item's text to value. The text will be displayed as plain text.
     * Newline characters ('\n') as well as line separator characters will cause
     * item to break the text into multiple lines
     * \param value
     */
    virtual void setText(const std::string &value);

    /*!
     * \brief getText
     * Returns the item's text
     * \return
     */
    virtual std::string getText() const;

    /*!
     * \brief clearText
     * Clears the item's text. I.e. set it to an empty string
     */
    virtual void clearText();

    /*!
     * \brief setBold
     * Sets the font's weight to bold (if bool equals true)
     */
    virtual void setBold(bool);

    /*!
     * \brief isBold
     * Returns whether the item's font is set to bold
     * \return
     */
    virtual bool isBold() const;

    /*!
     * \brief setFontSize
     * Sets the item's font size. The size must be 1 or higher
     * \param size
     */
    void setFontSize(int size);

private:
    friend class ObjectFactory;
    GraphicsTextItem(SUI::GraphicsItem *parent = NULL);
    GraphicsTextItem(const GraphicsTextItem &copy);
    GraphicsTextItem &operator=(const GraphicsTextItem &copy);
    
    SUI::ColorEnum::Color penColor;
};
}

#endif // SUIGRAPHICSTEXTITEM_H
