//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::GraphicsView.
// !\description Header file for class SUI::GraphicsView.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIGRAPHICSVIEW_H
#define SUIGRAPHICSVIEW_H

#include "SUIWidget.h"

#include "SUIDragModeEnum.h"
#include "SUIImageEnum.h" 
#include "SUIAspectRatioEnum.h"

namespace SUI {
class GraphicsScene;

/*!
 * \ingroup FWQxGraphicsItems
 *
 * \brief Abstract class for interaction with the graphics overlay of a widget
 */
class SUI_SHARED_EXPORT GraphicsView : public Widget
{
public:
    virtual ~GraphicsView();

    /*!
     * \brief getGraphicsScene
     * Returns a pointer to the GraphicsScene.
     * The GraphicsScene lives in the GraphicsView and the GraphicsItems live in the GraphicsScene.
     * It is possible to have multiple GraphicsScene instances for the same GraphicsView. Each
     * GraphicsView has a GraphicsScene by default, wich is deleted when the GraphicsView is deleted.
     * \return GraphicsScene * - The GraphicsScene pointer
     */
    GraphicsScene *getGraphicsScene();
    
    /*!
     * \brief setGraphicsScene
     * Sets the GraphicsScene. This does not delete the GraphicsScene.
     */
    void setGraphicsScene(GraphicsScene *scene);

    /*!
     * \brief createScreenshot
     * Creates a screenshot of the GraphicView
     * \param fileName the filename to save to
     * \param overlay if true, all the visible GraphicsItems are included in the screenshot
     * \param fileType the type of the file
     * \see SUI::ImageEnum::FileType
     */
    void createScreenshot(const std::string &fileName, bool overLay, ImageEnum::FileType FileType);
    
    /*!
     * \brief setAspectRatioMode
     * The zooming style of the background image of the graphicsView
     * \param style - The type of autofit of the background picture
     * - AspectRatioEnum::Mode::IgnoreAspectRatio - Expand the image to be shown in the entire space, this will ignore the aspect ratio.\n
     * - AspectRatioEnum::Mode::KeepAspectRatioMode - The smallest fit will define the size of the image. The largest side will be chopped off.\n
     * - AspectRatioEnum::Mode::KeepAspectRatio - The part of the image that will not fit will be white. This is the default value;
     * \see AspectRatioEnum::Mode
     */
    void setAspectRatioMode(const AspectRatioEnum::Mode &style);

    /*!
     * \brief setMouseWheelZoomEnabled
     * Turn the mouse scroll zoom on or off
     * \param enabled - true turns mouse scroll zoom on
     */
    void setMouseWheelZoomEnabled(bool enabled);

    /*!
     * \brief setScrollBarsEnabled
     * Sets the scrollbars on or off
     * \param enabled - If true the scrollbars will be visible if needed, if false the scrollbars will never appear.
     */
    void setScrollBarsEnabled(bool enabled);

    /*!
     * \brief setDragMode
     * The drag mode of the graphicsView
     * \param mode - The mouse event handling for zooming\n
     * - DragModeEnum::None - The is no zoom mode.\n
     * - DragModeEnum::ScrollHandDrag - Mousehold & drag will result in moving the scene.\n
     * - DragModeEnum::RubberBandDrag - The selected area will be zoomed at.
     * \see DragModeEnum::Mode
     */
    void setDragMode(const DragModeEnum::Mode &mode);

    /*!
     * \brief zoom
     * Zoom at a point of the graphicsView
     * \param Scale - The zoom factor that will be used. If a negative factor is used it will be transformed into a positive factor e.g.: set factor -1.2 wil be transformed to 0.8
     * \param x - the position that will be centered on the X scale
     * \param y - the position that will be centered on the Y scale
     */
    void zoom(double scale, int x, int y);
    
    /*!
     * \brief setScaleFactor
     * Sets the default scale factor for zooming a graphicsview
     * \param scale - new scale factor to be used for zooming
     */
    void setScaleFactor(double scale);

    /*!
     * \brief getScaleFactor
     * Gets the default scale factor for zooming a graphicsview
     * \return scale factor used for zooming
     */
    double getScaleFactor();

    /*!
     * \brief fitInView
     * Fits the given rectangle in the view
     * \param x - top left x scene coordinate
     * \param y - top left y scene coordinate
     * \param w - the width of the rectangle
     * \param h - the height of the rectangle
     */
    void fitInView(int x, int y, int width, int height);

    /*!
     * \brief getScale
     * Returns the scale of the graphicsView content, i.e. the GraphicsScene.
     * \return double - The scale value
     */
    double getScale() const;

protected:
    friend class ObjectFactory;
    GraphicsView();
    
    GraphicsScene *scene;
};
}

#endif // SUIGRAPHICSVIEW_H
