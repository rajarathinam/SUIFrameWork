//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SpinBox.
// !\description Class implementation file for SpinBox.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUISpinBox.h"

#include "SUIObjectFactory.h"

SUI::SpinBox::SpinBox() : 
    Widget(SUI::ObjectType::SpinBox)
{
}

SUI::SpinBox::~SpinBox()
{
}
