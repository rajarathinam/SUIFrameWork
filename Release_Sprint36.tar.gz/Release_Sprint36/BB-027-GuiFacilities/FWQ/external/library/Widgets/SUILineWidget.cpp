//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for LineWidget.
// !\description Class implementation file for LineWidget.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUILineWidget.h"

#include "SUIObjectFactory.h"

SUI::LineWidget::LineWidget() : 
    Widget(SUI::ObjectType::LineWidget)
{
}

SUI::LineWidget::~LineWidget()
{
}
