//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SvgWidget.
// !\description Class implementation file for SvgWidget.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUISvgWidget.h"

#include "SUIObjectFactory.h"

SUI::SvgWidget::SvgWidget() : 
    Widget(SUI::ObjectType::SvgWidget)
{
}

SUI::SvgWidget::~SvgWidget()
{
}
