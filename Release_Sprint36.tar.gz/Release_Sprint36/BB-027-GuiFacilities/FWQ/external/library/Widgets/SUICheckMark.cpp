//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for CheckMark.
// !\description Class implementation file for CheckMark.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUICheckMark.h"

#include "SUIObjectFactory.h"

SUI::CheckMark::CheckMark() : 
    Widget(SUI::ObjectType::fromString(SUI::ObjectFactory::getClassName<CheckMark>()))
{
}

SUI::CheckMark::~CheckMark()
{
}
