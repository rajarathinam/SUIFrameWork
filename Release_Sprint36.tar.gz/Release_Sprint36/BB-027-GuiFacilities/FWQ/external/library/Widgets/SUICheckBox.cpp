//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for CheckBox.
// !\description Class implementation file for CheckBox.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUICheckBox.h"

#include "SUIObjectFactory.h"

SUI::CheckBox::CheckBox() : 
    Widget(SUI::ObjectType::fromString(SUI::ObjectFactory::getClassName<CheckBox>()))
{
}

SUI::CheckBox::~CheckBox()
{
}
