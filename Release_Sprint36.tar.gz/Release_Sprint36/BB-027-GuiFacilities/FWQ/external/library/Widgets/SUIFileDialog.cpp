//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for FileDialog.
// !\description Class implementation file for FileDialog.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIFileDialog.h"

#include <QWidget>
#include <QFileDialog>

#include "SUIBaseWidget.h"
#include "SUIObjectFactory.h"
#include "SUIStyleSheet.h"
#include "SUIFileDialogImpl.h"

SUI::FileDialog::FileDialog() : 
    Widget(SUI::ObjectType::FileDialog) 
{       
}

SUI::FileDialog::~FileDialog()
{
}
std::string SUI::FileDialog::getExistingDirectory(SUI::Widget *parent, const std::string &caption, const std::string &dir, const std::string &root, FileDialogOptionEnum::Options options) {
    QWidget *qParent = NULL;
    if (parent != NULL) qParent = dynamic_cast<SUI::BaseWidget*>(SUI::ObjectFactory::getInstance()->toBaseObject(parent))->getWidget();
    else {
        qParent = new QWidget;
        qParent->setStyleSheet(QString::fromStdString(SUI::StyleSheet::getInstance()->getStyleSheet()));
    }
    if (root != "") {
        FileDialog *fileDialog = SUI::ObjectFactory::getInstance()->createWidget_<FileDialog>(qParent);
        fileDialog->setAcceptMode(FileDialog::Dir);
        fileDialog->setTitle(caption);
        fileDialog->setRootDirectory(root);
        fileDialog->setDirectory(dir);
        fileDialog->setAcceptButtonText("Select");
        dynamic_cast<FileDialogImpl*>(fileDialog)->getWidget()->exec();
        std::string selectedFiles = fileDialog->getSelectedFiles();
        delete fileDialog;
        fileDialog = NULL;
        return selectedFiles;
    }
    else
        return QFileDialog::getExistingDirectory(qParent,QString::fromStdString(caption),QString::fromStdString(dir),(QFlags<QFileDialog::Option>)options).toStdString();
}

std::string SUI::FileDialog::getOpenFileName(SUI::Widget *parent, const std::string &caption, const std::string &dir, const std::string &root, const std::string &filter, std::string *selectedFilter, FileDialogOptionEnum::Options options) {
    QWidget *qParent = NULL;
    if (parent != NULL) qParent = dynamic_cast<SUI::BaseWidget*>(SUI::ObjectFactory::getInstance()->toBaseObject(parent))->getWidget();
    else {
        qParent = new QWidget;
        qParent->setStyleSheet(QString::fromStdString(SUI::StyleSheet::getInstance()->getStyleSheet()));
    }
    QString qSelectedFilter;
    if (selectedFilter != NULL) qSelectedFilter = QString::fromStdString(*selectedFilter);

    if (root != "") {
        FileDialog *fileDialog = SUI::ObjectFactory::getInstance()->createWidget_<FileDialog>(qParent);
        fileDialog->setAcceptMode(FileDialog::File);
        fileDialog->setTitle(caption);
        fileDialog->setRootDirectory(root);
        fileDialog->setDirectory(dir);
        QStringList f = QString::fromStdString(filter).split(";");
        std::list<std::string> filters;
        foreach (const QString &fi, f) {
            filters.push_back(fi.toStdString());
        }
        fileDialog->setFilter(filters);
        fileDialog->setAcceptButtonText("Open");
        dynamic_cast<FileDialogImpl*>(fileDialog)->getWidget()->exec();
        std::string selectedFiles = fileDialog->getSelectedFiles();
        delete fileDialog;
        fileDialog = NULL;
        return selectedFiles;
    }
    else {
        QString returnValue = QFileDialog::getOpenFileName(qParent,QString::fromStdString(caption),QString::fromStdString(dir),QString::fromStdString(filter),&qSelectedFilter,(QFlags<QFileDialog::Option>)options);
        if (selectedFilter != NULL) {
            selectedFilter->clear();
            selectedFilter->append(qSelectedFilter.toStdString());
        }
        return returnValue.toStdString();
    }
}

std::list<std::string> SUI::FileDialog::getOpenFileNames(SUI::Widget *parent, const std::string &caption, const std::string &dir, const std::string &root, const std::string &filter, std::string *selectedFilter, SUI::FileDialogOptionEnum::Options options) {
    QWidget *qParent = NULL;
    if (parent != NULL) qParent = dynamic_cast<SUI::BaseWidget*>(SUI::ObjectFactory::getInstance()->toBaseObject(parent))->getWidget();
    else {
        qParent = new QWidget;
        qParent->setStyleSheet(QString::fromStdString(SUI::StyleSheet::getInstance()->getStyleSheet()));
    }
    QString qSelectedFilter;
    if (selectedFilter != NULL) qSelectedFilter = QString::fromStdString(*selectedFilter);

    if (root != "") {
        FileDialog *fileDialog = SUI::ObjectFactory::getInstance()->createWidget_<FileDialog>(qParent);
        fileDialog->setAcceptMode(FileDialog::File);
        fileDialog->setTitle(caption);
        fileDialog->setRootDirectory(root);
        fileDialog->setDirectory(dir);
        QStringList f = QString::fromStdString(filter).split(";");
        std::list<std::string> filters;
        foreach (const QString &fi, f) {
            filters.push_back(fi.toStdString());
        }
        fileDialog->setFilter(filters);
        fileDialog->setAcceptButtonText("Open");
        dynamic_cast<FileDialogImpl*>(fileDialog)->getWidget()->exec();
        QStringList saveFileNameList = QString::fromStdString(fileDialog->getSelectedFiles()).split(";");
        if (selectedFilter != NULL) {
            selectedFilter->clear();
            selectedFilter->append(qSelectedFilter.toStdString());
        }
        std::list<std::string> stdSaveFileNameList;
        foreach (const QString &fileName, saveFileNameList)
            stdSaveFileNameList.push_back(fileName.toStdString());
        delete fileDialog;
        fileDialog = NULL;
        return stdSaveFileNameList;
    }
    else {
        QStringList saveFileNameList = QFileDialog::getOpenFileNames(qParent,QString::fromStdString(caption),QString::fromStdString(dir),QString::fromStdString(filter),&qSelectedFilter,(QFlags<QFileDialog::Option>)options);
        if (selectedFilter != NULL) {
            selectedFilter->clear();
            selectedFilter->append(qSelectedFilter.toStdString());
        }
        std::list<std::string> stdSaveFileNameList;
        foreach (const QString &fileName, saveFileNameList)
            stdSaveFileNameList.push_back(fileName.toStdString());
        return stdSaveFileNameList;
    }
}

std::string SUI::FileDialog::getSaveFileName(SUI::Widget *parent, const std::string &caption, const std::string &dir, const std::string &root, const std::string &filter, std::string *selectedFilter, SUI::FileDialogOptionEnum::Options options) {
    QWidget *qParent = NULL;
    if (parent != NULL) qParent = dynamic_cast<SUI::BaseWidget*>(SUI::ObjectFactory::getInstance()->toBaseObject(parent))->getWidget();
    else {
        qParent = new QWidget;
        qParent->setStyleSheet(QString::fromStdString(SUI::StyleSheet::getInstance()->getStyleSheet()));
    }
    QString qSelectedFilter;
    if (selectedFilter != NULL) qSelectedFilter = QString::fromStdString(*selectedFilter);

    if (root != "") {
        FileDialog *fileDialog = SUI::ObjectFactory::getInstance()->createWidget_<FileDialog>(qParent);
        fileDialog->setAcceptMode(FileDialog::Save);
        fileDialog->setTitle(caption);
        fileDialog->setRootDirectory(root);
        fileDialog->setDirectory(dir);
        QStringList f = QString::fromStdString(filter).split(";");
        std::list<std::string> filters;
        foreach (const QString &fi, f) {
            filters.push_back(fi.toStdString());
        }
        fileDialog->setFilter(filters);
        fileDialog->setAcceptButtonText("Save");
        dynamic_cast<FileDialogImpl*>(fileDialog)->getWidget()->exec();
        std::string saveFileNameList = fileDialog->getSelectedFiles();
        if (selectedFilter != NULL) {
            selectedFilter->clear();
            selectedFilter->append(qSelectedFilter.toStdString());
        }
        delete fileDialog;
        fileDialog = NULL;
        return saveFileNameList;
    }
    else {
        QString returnValue = QFileDialog::getSaveFileName(qParent,QString::fromStdString(caption),QString::fromStdString(dir),QString::fromStdString(filter),&qSelectedFilter,(QFlags<QFileDialog::Option>)options);
        if (selectedFilter != NULL) {
            selectedFilter->clear();
            selectedFilter->append(qSelectedFilter.toStdString());
        }
        return returnValue.toStdString();
    }
}
