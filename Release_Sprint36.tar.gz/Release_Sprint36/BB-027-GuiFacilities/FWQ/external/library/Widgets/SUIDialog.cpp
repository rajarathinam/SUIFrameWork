//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for Dialog.
// !\description Class implementation file for Dialog.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIDialog.h"

#include "SUIObjectFactory.h"

SUI::Dialog::Dialog() : 
    Widget(SUI::ObjectType::fromString(SUI::ObjectFactory::getClassName<Dialog>()))
{
}
