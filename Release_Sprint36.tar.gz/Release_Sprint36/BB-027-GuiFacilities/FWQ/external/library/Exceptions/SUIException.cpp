//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for Exception.
// !\description Class implementation file for Exception.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIException.h"

SUI::Exception::Exception(const std::string &msg) :
    mMessage(msg)
{
}

SUI::Exception::~Exception() throw()
{
}

std::string SUI::Exception::getExceptionMessage() const {
    return mMessage;
}

const char *SUI::Exception::what() const throw() {
    return mMessage.c_str();
}
