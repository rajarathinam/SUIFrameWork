//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for GraphicsItem.
// !\description Class implementation file for GraphicsItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIGraphicsItem.h"

#include <QGraphicsItem>
#include <QGraphicsSvgItem>

SUI::GraphicsItem::GraphicsItem(const SUI::ObjectType::Type &type, void *implementation, GraphicsItem *parent) :
    SUI::Object(type),
    implementation(implementation),
    parent(parent)
{
}

SUI::GraphicsItem::~GraphicsItem()
{
}

void SUI::GraphicsItem::setPosition(double x, double y) {
    if(this->getObjectType() == SUI::ObjectType::GraphicsSvgItem)  {
        static_cast<QGraphicsSvgItem*>(implementation)->setPos(x,y);
    }
    else static_cast<QGraphicsItem*>(implementation)->setPos(x,y);
}

void SUI::GraphicsItem::setX(double x) {
    if(this->getObjectType() == SUI::ObjectType::GraphicsSvgItem) {
        static_cast<QGraphicsSvgItem*>(implementation)->setX(x);
    }
    else {
        static_cast<QGraphicsItem*>(implementation)->setX(x);
    }
}

double SUI::GraphicsItem::getX() const {
    return static_cast<QGraphicsItem*>(implementation)->x();
}

void SUI::GraphicsItem::setY(double y) {
    if(this->getObjectType() == SUI::ObjectType::GraphicsSvgItem) {
        static_cast<QGraphicsSvgItem*>(implementation)->setY(y);
    }
    else {
        static_cast<QGraphicsItem*>(implementation)->setY(y);
    }
}

double SUI::GraphicsItem::getY() const {
    return static_cast<QGraphicsItem*>(implementation)->y();
}

double SUI::GraphicsItem::getBoundingRectWidth() const {
    if(this->getObjectType() == SUI::ObjectType::GraphicsSvgItem) {
        return static_cast<QGraphicsSvgItem*>(implementation)->boundingRect().width();
    }
    else {
        return static_cast<QGraphicsItem*>(implementation)->boundingRect().width();
    }
}

double SUI::GraphicsItem::getBoundingRectHeight() const {
    if(this->getObjectType() == SUI::ObjectType::GraphicsSvgItem) {
        return static_cast<QGraphicsSvgItem*>(implementation)->boundingRect().height();
    }
    else {
        return static_cast<QGraphicsItem*>(implementation)->boundingRect().height();
    }
}

void SUI::GraphicsItem::setZValue(double z) {
   static_cast<QGraphicsItem*>(implementation)->setZValue(z);
}

double SUI::GraphicsItem::getZValue() const {
    return static_cast<QGraphicsItem*>(implementation)->zValue();
}

void SUI::GraphicsItem::setVisible(bool visible) {
    if(this->getObjectType() == SUI::ObjectType::GraphicsSvgItem) {
        static_cast<QGraphicsSvgItem*>(implementation)->setVisible(visible);
    }
    else {
        static_cast<QGraphicsItem*>(implementation)->setVisible(visible);
    }
    if (!visibilityChanged.empty()) {
        visibilityChanged(visible);
    }
}

bool SUI::GraphicsItem::isVisible() const {
    if(this->getObjectType() == SUI::ObjectType::GraphicsSvgItem) {
        return static_cast<QGraphicsSvgItem*>(implementation)->isVisible();
    }
    else {
        return static_cast<QGraphicsItem*>(implementation)->isVisible();
    }
}


void SUI::GraphicsItem::setEnabled(bool enabled) {
   static_cast<QGraphicsItem*>(implementation)->setEnabled(enabled);
}

bool SUI::GraphicsItem::isEnabled() const {
    return static_cast<QGraphicsItem*>(implementation)->isEnabled();
}

std::string SUI::GraphicsItem::getId() const {
    return id;
}

void SUI::GraphicsItem::setToolTip(const std::string &toolTip) {
   static_cast<QGraphicsItem*>(implementation)->setToolTip(QString::fromStdString(toolTip));
}

std::string SUI::GraphicsItem::getToolTip() const {
    return static_cast<QGraphicsItem*>(implementation)->toolTip().toStdString();
}

SUI::GraphicsItem *SUI::GraphicsItem::getParent() const {
    return parent;
}

void SUI::GraphicsItem::setMoveable(bool enabled) {
   static_cast<QGraphicsItem*>(implementation)->setFlag(QGraphicsItem::ItemIsMovable,enabled);
}

void SUI::GraphicsItem::setFocusable(bool enabled) {
   static_cast<QGraphicsItem*>(implementation)->setFlag(QGraphicsItem::ItemIsFocusable,enabled);
}

void SUI::GraphicsItem::setSelectable(bool enabled) {
   static_cast<QGraphicsItem*>(implementation)->setFlag(QGraphicsItem::ItemIsSelectable,enabled);
}

void SUI::GraphicsItem::setId(const std::string &value) {
    id = value;  
}
