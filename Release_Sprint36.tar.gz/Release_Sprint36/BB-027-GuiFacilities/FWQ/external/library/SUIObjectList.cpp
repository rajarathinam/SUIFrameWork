//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for ObjectList.
// !\description Class implementation file for ObjectList.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIObjectList.h"

SUI::Object *SUI::ObjectList::getObjectPrivate(std::string id) {
    if (idExists(id)) return objects[id];
    return NULL;
}

void SUI::ObjectList::addObject(const std::string &id, SUI::Object *object) {
    if (idExists(id))removeObject(id);
    objects.insert(std::pair<std::string, Object *>(id, object));
}


void SUI::ObjectList::removeObject(std::string id) {
    if (idExists(id)) {
//        SUI::Object *object = objects[id];
        objects.erase(id);
//        delete object; //FIXME deleting crashes the application,
    }
}

void SUI::ObjectList::clear() {
    objects.clear();
}

bool SUI::ObjectList::doesMessageBoxExist() {
    return idExists("msgBox");
}

bool SUI::ObjectList::doesFileBrowserExist() {
    return idExists("fbrDialog");
}

bool SUI::ObjectList::idExists(const std::string &id) const {
    return objects.find(id) != objects.end();
}

std::vector<SUI::Object *> SUI::ObjectList::getObjectList() const {
    std::vector<SUI::Object *> list;
    for (std::map<std::string,Object*>::const_iterator it = objects.begin(); it != objects.end(); ++it) {
        list.push_back(it->second);
    }
    return list;
}
