//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for PlotCurveItem.
// !\description Class implementation file for PlotCurveItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUIPlotCurveItem.h"
#include "SUIPlotWidgetImpl.h"
#include "SUIObjectFactory.h"

#include <qwt_plot_curve.h>

SUI::PlotCurveItem::PlotCurveItem(const std::string &setName, SUI::PlotAxisEnum::PlotAxis side) :
    PlotItem(
        SUI::ObjectType::PlotCurveItem
        ),
  mColor(SUI::ColorEnum::Black),
  mLineStyle(SUI::LineStyleEnum::Solid)
{
    implementation = new QwtPlotCurve(QString::fromStdString(setName));
    static_cast<QwtPlotCurve*>(implementation)->setYAxis(side);
}

SUI::PlotCurveItem::~PlotCurveItem() {
    delete static_cast<QwtPlotCurve*>(implementation);
    implementation = NULL;
}

void SUI::PlotCurveItem::attach(PlotWidget *plot) {
    if(plot != NULL){
        static_cast<QwtPlotCurve*>(implementation)->attach(dynamic_cast<SUI::PlotWidgetImpl *>(plot)->plot());
    }
}

void SUI::PlotCurveItem::detach() {
    dataPoints.clear();
    static_cast<QwtPlotCurve*>(implementation)->detach();
}

void SUI::PlotCurveItem::setTitle(const std::string &title) {
    static_cast<QwtPlotCurve*>(implementation)->setTitle(QString::fromStdString(title));
}

std::string SUI::PlotCurveItem::getTitle() const {
    return static_cast<QwtPlotCurve*>(implementation)->title().text().toStdString();
}

void SUI::PlotCurveItem::show() {
    static_cast<QwtPlotCurve*>(implementation)->show();
}

void SUI::PlotCurveItem::hide() {
    static_cast<QwtPlotCurve*>(implementation)->hide();
}

void SUI::PlotCurveItem::setVisible(bool visible) {
    static_cast<QwtPlotCurve*>(implementation)->setVisible(visible);
}

bool SUI::PlotCurveItem::isVisible() const {
    return static_cast<QwtPlotCurve*>(implementation)->isVisible();
}

void SUI::PlotCurveItem::setAxes(SUI::PlotAxisEnum::PlotAxis xAxis, SUI::PlotAxisEnum::PlotAxis yAxis) {
    static_cast<QwtPlotCurve*>(implementation)->setAxes(xAxis, yAxis);
}

void SUI::PlotCurveItem::setXAxis(SUI::PlotAxisEnum::PlotAxis xAxis) {
    static_cast<QwtPlotCurve*>(implementation)->setXAxis(xAxis);
}

SUI::PlotAxisEnum::PlotAxis SUI::PlotCurveItem::getXAxis() const {
    return static_cast<SUI::PlotAxisEnum::PlotAxis>(static_cast<QwtPlotCurve*>(implementation)->xAxis());
}

void SUI::PlotCurveItem::setYAxis(SUI::PlotAxisEnum::PlotAxis axis) {
    static_cast<QwtPlotCurve*>(implementation)->setYAxis(axis);
}

SUI::PlotAxisEnum::PlotAxis SUI::PlotCurveItem::getYAxis() const {
    return static_cast<SUI::PlotAxisEnum::PlotAxis>(static_cast<QwtPlotCurve*>(implementation)->yAxis());
}

double SUI::PlotCurveItem::getZ() const {
    return static_cast<QwtPlotCurve*>(implementation)->z();
}

void SUI::PlotCurveItem::setZ(double z) {
    static_cast<QwtPlotCurve*>(implementation)->setZ(z);
}

void SUI::PlotCurveItem::clearSamples() {
    dataPoints.clear();
    static_cast<QwtPlotCurve*>(implementation)->setSamples(0,0,0);
}

void SUI::PlotCurveItem::setColor(const SUI::ColorEnum::Color color) {
    if(mColor == color) return;
    if (ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color) == true) {
        mColor = color;
        static_cast<QwtPlotCurve*>(implementation)->setPen(QColor(QString::fromStdString(SUI::ColorEnum::toString(mColor))));
    }
}

SUI::ColorEnum::Color SUI::PlotCurveItem::getColor() const {
    return mColor;
}

void SUI::PlotCurveItem::setWidth(const int penWidth) {
    QPen pen = static_cast<QwtPlotCurve*>(implementation)->pen();
    pen.setWidth(penWidth);
    static_cast<QwtPlotCurve*>(implementation)->setPen(pen);
}

int SUI::PlotCurveItem::getWidth() const {
    return static_cast<QwtPlotCurve*>(implementation)->pen().width();
}

void SUI::PlotCurveItem::setStyle(const SUI::LineStyleEnum::LineStyle linestyle) {
    if(mLineStyle == linestyle) return;
    mLineStyle = linestyle;
    QPen pen = static_cast<QwtPlotCurve*>(implementation)->pen();
    pen.setStyle(static_cast<Qt::PenStyle>(mLineStyle));
    static_cast<QwtPlotCurve*>(implementation)->setPen(pen);
}

SUI::LineStyleEnum::LineStyle SUI::PlotCurveItem::getStyle() const {
    return mLineStyle;
}

void SUI::PlotCurveItem::setPlotMarker(SUI::MarkerSymbolEnum::MarkerSymbol markerSymbol, SUI::ColorEnum::Color color, int width) {
    QwtSymbol *symbol = new QwtSymbol();
    switch (markerSymbol)
    {
    case SUI::MarkerSymbolEnum::Ellipse: symbol->setStyle(QwtSymbol::Ellipse); break;
    case SUI::MarkerSymbolEnum::Rect: symbol->setStyle(QwtSymbol::Rect);break;
    case SUI::MarkerSymbolEnum::Diamond: symbol->setStyle(QwtSymbol::Diamond); break;
    case SUI::MarkerSymbolEnum::Triangle: symbol->setStyle(QwtSymbol::Triangle); break;
    case SUI::MarkerSymbolEnum::Cross: symbol->setStyle(QwtSymbol::Cross); break;
    case SUI::MarkerSymbolEnum::Star: symbol->setStyle(QwtSymbol::Star1); break;
    default: symbol->setStyle(QwtSymbol::NoSymbol); break;
    }
    symbol->setSize(width);
    symbol->setColor(QColor(QString::fromStdString(SUI::ColorEnum::toString(color))));

    static_cast<QwtPlotCurve*>(implementation)->setSymbol(symbol);
}

void SUI::PlotCurveItem::setSamples(const std::vector<SUI::PlotDataPoint> &values) {
    for (uint i = 0; i < values.size(); i++)
    {
        dataPoints.push_back(values.at(i));
    }
    plotCurve();
}

void SUI::PlotCurveItem::setSample(const SUI::PlotDataPoint &value) {
    dataPoints.push_back(value);
    plotCurve();
}

void SUI::PlotCurveItem::setRawSamples(const double *xData, const double *yData, int size) {
    static_cast<QwtPlotCurve*>(implementation)->setRawSamples(xData, yData, size);
}

void SUI::PlotCurveItem::plotCurve() {
    QVector<QPointF> samples(dataPoints.size());
    for (uint i = 0; i < dataPoints.size(); i++)
    {
        samples[i] = QPointF(static_cast<SUI::PlotDataPoint> (dataPoints.at(i)).getX(),
                             static_cast<SUI::PlotDataPoint> (dataPoints.at(i)).getY());
    }
    static_cast<QwtPlotCurve*>(implementation)->setSamples(samples);
}
