//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for PlotItem.
// !\description Class implementation file for PlotItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUIPlotItem.h"
#include "SUIPlotWidgetImpl.h"

SUI::PlotItem::PlotItem(const SUI::ObjectType::Type &type, void *implementation) :
    SUI::Object(type),
    implementation(implementation)
{
}

std::string SUI::PlotItem::getId() const {
    return id;
}

void SUI::PlotItem::setId(const std::string &value) {
    id = value;
}

SUI::PlotItem::~PlotItem() {
}

void SUI::PlotItem::setEnabled(bool value) {
    enabled = value;
}

bool SUI::PlotItem::isEnabled() const {
    return enabled;
}

