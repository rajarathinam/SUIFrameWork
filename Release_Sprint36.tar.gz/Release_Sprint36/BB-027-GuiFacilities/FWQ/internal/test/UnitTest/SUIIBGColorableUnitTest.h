#ifndef IBGCOLORABLEUNITTEST_H
#define IBGCOLORABLEUNITTEST_H

#include <SUIColorEnum.h>

namespace SUI {

class IBGColorable;

class IBGColorableUnitTest
{
public:
    IBGColorableUnitTest(IBGColorable *object);

    bool setBackgroundColor(SUI::ColorEnum::Color color);
    bool setBackgroundColor();

private:
    IBGColorable *object;
};
}
#endif // IBGCOLORABLEUNITTEST_H
