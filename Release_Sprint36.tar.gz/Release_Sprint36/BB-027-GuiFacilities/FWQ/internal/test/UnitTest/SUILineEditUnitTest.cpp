#include "SUILineEditUnitTest.h"

#include <QTest>

#include "SUILineEdit.h"

#include "SUIITextUnitTest.h"
#include "SUIIAlignableUnitTest.h"
#include "SUIIColorableUnitTest.h"
#include "SUIIBGColorableUnitTest.h"
#include "SUIIErrorMode.h"

SUI::LineEditUnitTest::LineEditUnitTest(SUI::LineEdit *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::LineEditUnitTest::~LineEditUnitTest() {
    delete object;
}

void SUI::LineEditUnitTest::callInterfaceTests() {
    //IText unit test
    ITextUnitTest iTextUnitTest(object);
    QVERIFY(iTextUnitTest.setText());
    QVERIFY(iTextUnitTest.clearText());
    QVERIFY(iTextUnitTest.setBold());

    //IAlignable unit test
    IAlignableUnitTest iAlignableUnitTest(object);
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::HCenter));
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Left));
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Right));
    QCOMPARE(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Stretch), false);

    //IColorable test
    //valid colors
    IColorableUnitTest iColorableUnitTest(object);
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Standard));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Red));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Green));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Blue));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Gray));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Yellow));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Orange));
    //test invalid colors
    QCOMPARE(iColorableUnitTest.setColor(SUI::ColorEnum::White), false);

    //IBGColorable tests
    IBGColorableUnitTest iBGColorableUnitTest(object);
    //valid colors
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Standard));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Red));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Green));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Blue));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Gray));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Yellow));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Orange));
    //test invalid colors
    QCOMPARE(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::White), false);

    //TODO IErrorMode tests

    //TODO Boost callback functions
}

void SUI::LineEditUnitTest::setPlaceHolderText() {
    QFETCH(QString, placeholdertext);
    object->setPlaceHolderText(placeholdertext.toStdString());
    QCOMPARE(QString::fromStdString(object->getPlaceHolderText()), placeholdertext);
}

void SUI::LineEditUnitTest::setPlaceHolderText_data() {
    QTest::addColumn<QString>("placeholdertext");
    QTest::newRow("Test setPlaceholdertext 1") << QString("text");
    QTest::newRow("Test setPlaceholdertext 2") << QString("text1");
}
