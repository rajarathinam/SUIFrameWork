#ifndef SUIGRAPHICSVIEWUNITTEST_H
#define SUIGRAPHICSVIEWUNITTEST_H

#include "SUIWidgetUnitTest.h"
#include "SUIGraphicsView.h"

namespace SUI {

class GraphicsView;

class GraphicsViewUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
     GraphicsViewUnitTest(SUI::GraphicsView *object, QObject *parent = 0);
    virtual ~GraphicsViewUnitTest();

private:
    GraphicsView *object;
};

}
#endif // SUIGRAPHICSVIEWUNITTEST_H
