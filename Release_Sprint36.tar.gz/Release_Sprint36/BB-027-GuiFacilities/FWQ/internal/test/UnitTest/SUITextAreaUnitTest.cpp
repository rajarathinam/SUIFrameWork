
#include "SUITextAreaUnitTest.h"

SUI::TextAreaUnitTest::TextAreaUnitTest(SUI::TextArea *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::TextAreaUnitTest::~TextAreaUnitTest() {
    delete object;
}

