#include"SUIButtonUnitTest.h"
#include <QTest>

#include "SUIButton.h"
#include "SUIITextUnitTest.h"
#include "SUIIAlignableUnitTest.h"

SUI::ButtonUnitTest::ButtonUnitTest(SUI::Button *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::ButtonUnitTest::~ButtonUnitTest() {
    delete object;
}

void SUI::ButtonUnitTest::callInterfaceTests() {
    //IText unit test
    ITextUnitTest iTextUnitTest(object);
    QVERIFY(iTextUnitTest.setText());
    QVERIFY(iTextUnitTest.clearText());
    QVERIFY(iTextUnitTest.setBold());

    //IAlignable unit test
    IAlignableUnitTest iAlignableUnitTest(object);
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::HCenter));
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Left));
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Right));
    QCOMPARE(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Stretch), false);

    //TODO IImage unit test

    //TODO Boost callback IClickable unit test
}
