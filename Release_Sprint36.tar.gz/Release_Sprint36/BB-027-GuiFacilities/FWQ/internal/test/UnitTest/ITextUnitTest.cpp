#include "ITextUnitTest.h"

#include "SUITableWidgetItemImpl.h"

ITextUnitTest::ITextUnitTest():
    button(new SUI::ButtonImpl(NULL)),
    checkbox(new SUI::CheckBoxImpl(NULL)),
    dblspinbox(new SUI::DoubleSpinBoxImpl(NULL)),
    groupbox(new SUI::GroupBoxImpl(NULL)),
    label(new SUI::LabelImpl(NULL)),
    lineedit(new SUI::LineEditImpl(NULL)),
    listview(new SUI::ListViewImpl(NULL)),
    plotwidget(new SUI::PlotWidgetImpl(NULL)),
    progressbar(new SUI::ProgressBarImpl(NULL)),
    questionmark(new SUI::QuestionMarkImpl(NULL)),
    radiobutton(new SUI::RadioButtonImpl(NULL)),
    sciencespinbox(new SUI::ScienceSpinBoxImpl(NULL)),
    spinbox(new SUI::SpinBoxImpl(NULL)),
    tablewidgetitem(new SUI::TableWidgetItemImpl(NULL)),
    textarea(new SUI::TextAreaImpl(NULL)),
    msgbox(new SUI::MessageBoxImpl(NULL)),
    graphicstext(SUI::ObjectFactory::getInstance()->createGraphicsItem<SUI::GraphicsTextItem>(NULL)),
    treeItem(new SUI::TreeViewItemImpl(NULL)),
    //SUI::IText
    ibutton(dynamic_cast<SUI::ButtonImpl *>(button)),
    icheckbox(dynamic_cast<SUI::CheckBoxImpl *>(checkbox)),
    igroupbox(dynamic_cast<SUI::GroupBoxImpl *>(groupbox)),
    ilabel(dynamic_cast<SUI::LabelImpl *>(label)),
    ilineedit(dynamic_cast<SUI::LineEditImpl *>(lineedit)),
    ilistview(dynamic_cast<SUI::ListViewImpl *>(listview)),
    iplotwidget(dynamic_cast<SUI::PlotWidgetImpl *>(plotwidget)),
    iprogressbar(dynamic_cast<SUI::ProgressBarImpl *>(progressbar)),
    iquestionmark(dynamic_cast<SUI::QuestionMarkImpl *>(questionmark)),
    iradiobutton(dynamic_cast<SUI::RadioButtonImpl *>(radiobutton)),
    itablewidgetitem(dynamic_cast<SUI::TableWidgetItemImpl *>(tablewidgetitem)),
    itextarea(dynamic_cast<SUI::TextAreaImpl *>(textarea)),
    imsgbox(dynamic_cast<SUI::MessageBoxImpl *>(msgbox)),
    igraphicstext(dynamic_cast<SUI::GraphicsTextItem *>(graphicstext)),
    itreeItem(dynamic_cast<SUI::TreeViewItemImpl *>(treeItem))
{}

void ITextUnitTest::cleanupTestCase()
{
    delete button;
    delete checkbox;
    delete dblspinbox;
    delete groupbox;
    delete  label;
    delete  lineedit;
    delete  listview;
    delete  plotwidget;
    delete  progressbar;
    delete  questionmark;
    delete  radiobutton;
    delete  sciencespinbox;
    delete  spinbox;
    delete  tablewidgetitem;
    delete  textarea;
    delete  msgbox;
    //delete  graphicstext;
    delete  treeItem;
}

void ITextUnitTest::testSetTextCase1()
{
    QFETCH(QString, NewText);

    ibutton->setText(NewText.toStdString());
    QCOMPARE(QString::fromStdString(ibutton->getText()), NewText);
    icheckbox->setText(NewText.toStdString());
    QCOMPARE(QString::fromStdString(icheckbox->getText()), NewText);
    igroupbox->setText(NewText.toStdString());
    QCOMPARE(QString::fromStdString(igroupbox->getText()), NewText);
    ilabel->setText(NewText.toStdString());
    QCOMPARE(QString::fromStdString(ilabel->getText()), NewText);
    ilineedit->setText(NewText.toStdString());
    QCOMPARE(QString::fromStdString(ilineedit->getText()), NewText);
    ilistview->setText(NewText.toStdString());
    QCOMPARE(QString::fromStdString(ilistview->getText()), NewText);
    iplotwidget->setText(NewText.toStdString());
    QCOMPARE(QString::fromStdString(iplotwidget->getText()), NewText);
    iprogressbar->setText(NewText.toStdString());
    QCOMPARE(QString::fromStdString(iprogressbar->getText()), QString("0"));
    iquestionmark->setText(NewText.toStdString());
    QCOMPARE(QString::fromStdString(iquestionmark->getText()), NewText);
    iradiobutton->setText(NewText.toStdString());
    QCOMPARE(QString::fromStdString(iradiobutton->getText()), NewText);
    itablewidgetitem->setText(NewText.toStdString());
    QCOMPARE(QString::fromStdString(itablewidgetitem->getText()), NewText);
    itextarea->setText(NewText.toStdString());
    QCOMPARE(QString::fromStdString(itextarea->getText()), QString("%1\n").arg(NewText));
    imsgbox->setText(NewText.toStdString());
    QCOMPARE(QString::fromStdString(imsgbox->getText()), NewText);
    igraphicstext->setText(NewText.toStdString());
    QCOMPARE(QString::fromStdString(igraphicstext->getText()), NewText);
    // TreeItem doesn't work without a TreeView (anymore)
    //itreeItem->setText(NewText.toStdString());
    //QCOMPARE(QString::fromStdString(itreeItem->getText()), NewText);
}

void ITextUnitTest::testSetTextCase1_data()
{
    QTest::addColumn<QString>("NewText");
    QTest::newRow("SetText") << QString("SetText Case1");
}

void ITextUnitTest::testSetTextCase2()
{
    QFETCH(QString, NewText);

    button->setText(NewText.toStdString());
    QCOMPARE(button->getWidget()->text(), NewText);
    checkbox->setText(NewText.toStdString());
    QCOMPARE(checkbox->getWidget()->text(), NewText);
    groupbox->setText(NewText.toStdString());
    QCOMPARE(groupbox->getWidget()->title(), NewText);
    label->setText(NewText.toStdString());
    QCOMPARE(label->getWidget()->text(), NewText);
    lineedit->setText(NewText.toStdString());
    QCOMPARE(lineedit->getWidget()->text(), NewText);
    listview->setText(NewText.toStdString());
    QCOMPARE(QString::fromStdString(listview->getText()), NewText);
    plotwidget->setText(NewText.toStdString());
    QCOMPARE(QString::fromStdString(plotwidget->getText()), NewText);
    progressbar->setText(NewText.toStdString());
    QCOMPARE(progressbar->getWidget()->text(), QString("0%"));
//  QuestionMark doesn't show the text that is set
//    questionmark->setText(NewText.toStdString());
//    QCOMPARE(questionmark->getWidget()->text(), NewText);
    radiobutton->setText(NewText.toStdString());
    QCOMPARE(radiobutton->getWidget()->text(), NewText);
    tablewidgetitem->setText(NewText.toStdString());
    QCOMPARE(tablewidgetitem->text(), NewText);
    textarea->setText(NewText.toStdString());
    QCOMPARE(textarea->getWidget()->toPlainText(), NewText + QString("\n"));
    msgbox->setText(NewText.toStdString());
    QCOMPARE(msgbox->getWidget()->text(), NewText);
    graphicstext->setText(NewText.toStdString());
    QCOMPARE(QString::fromStdString(graphicstext->getText()), NewText);
    treeItem->setText(NewText.toStdString());
    QCOMPARE(treeItem->getWidget()->text(), NewText);

}

void ITextUnitTest::testSetTextCase2_data()
{
    QTest::addColumn<QString>("NewText");
    QTest::newRow("setText") << QString("setText Case2");
}

void ITextUnitTest::testClearTextCase1()
{
    QFETCH(QString, NewText);

    ibutton->clearText();
    QCOMPARE(QString::fromStdString(ibutton->getText()), NewText);
    icheckbox->clearText();
    QCOMPARE(QString::fromStdString(icheckbox->getText()), NewText);
    igroupbox->clearText();
    QCOMPARE(QString::fromStdString(igroupbox->getText()), NewText);
    ilabel->clearText();
    QCOMPARE(QString::fromStdString(ilabel->getText()), NewText);
    ilineedit->clearText();
    QCOMPARE(QString::fromStdString(ilineedit->getText()), NewText);
    ilistview->clearText();
    QCOMPARE(QString::fromStdString(ilistview->getText()), NewText);
    iplotwidget->clearText();
    QCOMPARE(QString::fromStdString(iplotwidget->getText()), NewText);
    iprogressbar->clearText();
    QCOMPARE(QString::fromStdString(iprogressbar->getText()), QString("0"));
    iquestionmark->clearText();
    QCOMPARE(QString::fromStdString(iquestionmark->getText()), NewText);
    iradiobutton->clearText();
    QCOMPARE(QString::fromStdString(iradiobutton->getText()), NewText);
    itablewidgetitem->clearText();
    QCOMPARE(QString::fromStdString(itablewidgetitem->getText()), NewText);
    itextarea->clearText();
    QCOMPARE(QString::fromStdString(itextarea->getText()), NewText);
//	TODO cleartext not implemented in messagebox
//    imsgbox->clearText();
//    QCOMPARE(QString::fromStdString(imsgbox->getText()), NewText);
    igraphicstext->clearText();
    QCOMPARE(QString::fromStdString(igraphicstext->getText()), NewText);
    itreeItem->clearText();
    QCOMPARE(QString::fromStdString(itreeItem->getText()), NewText);
}

void ITextUnitTest::testClearTextCase1_data()
{
    QTest::addColumn<QString>("NewText");
    QTest::newRow("clearText") << QString("");
}

void ITextUnitTest::testClearTextCase2()
{
    QFETCH(QString, NewText);

    button->clearText();
    QCOMPARE(button->getWidget()->text(), NewText);
    checkbox->clearText();
    QCOMPARE(checkbox->getWidget()->text(), NewText);
    groupbox->clearText();
    QCOMPARE(groupbox->getWidget()->title(), NewText);
    label->clearText();
    QCOMPARE(label->getWidget()->text(), NewText);
    lineedit->clearText();
    QCOMPARE(lineedit->getWidget()->text(), NewText);
//   Unable to get Items from widget
//   QCOMPARE(dynamic_cast<QListView*>(listview->widget())->text(), NewText);
//   listview->clearText();
    plotwidget->clearText();
    QCOMPARE(QString::fromStdString(plotwidget->getText()), NewText);
    progressbar->clearText();
    QCOMPARE(progressbar->getWidget()->text(), QString("0%"));
//   QuestionMark doesn't show the text that is set
//   questionmark->clearText();
//   QCOMPARE(dynamic_cast<questionmark*>(questionmark->widget())->text(), NewText);
    radiobutton->clearText();
    QCOMPARE(radiobutton->getWidget()->text(), NewText);
    tablewidgetitem->clearText();
    QCOMPARE(tablewidgetitem->text(), NewText);
    textarea->clearText();
    QCOMPARE(textarea->getWidget()->toPlainText(), NewText);
    graphicstext->clearText();
    QCOMPARE(QString::fromStdString(graphicstext->getText()), NewText);
    treeItem->clearText();
    QCOMPARE(treeItem->getWidget()->text(), NewText);
//	TODO cleartext not implemented in messagebox
//    msgbox->clearText();
//    QCOMPARE(QString::fromStdString(msgbox->getText()), NewText);
}

void ITextUnitTest::testClearTextCase2_data()
{
    QTest::addColumn<QString>("NewText");
    QTest::newRow("clearText") << QString("");
}

void ITextUnitTest::testSetBoldCase1()
{
    QFETCH(bool, NewBool);
    QFETCH(QString, NewText);

    button->setBold(NewBool);
    QCOMPARE(button->getWidget()->property("SUIFont").toString(), NewText);
    checkbox->setBold(NewBool);
    QCOMPARE(checkbox->getWidget()->property("SUIFont").toString(), NewText);
    groupbox->setBold(NewBool);
    QCOMPARE(groupbox->getWidget()->property("SUIFont").toString(), NewText);
    label->setBold(NewBool);
    QCOMPARE(label->getWidget()->property("SUIFont").toString(), NewText);
    lineedit->setBold(NewBool);
    QCOMPARE(lineedit->getWidget()->property("SUIFont").toString(), NewText);
    listview->setBold(NewBool);
    QCOMPARE(listview->getWidget()->property("SUIFont").toString(), NewText);
//    PlotWidget doesn't support setBold
//    plotwidget->setBold(NewBool);
//    QCOMPARE(plotwidget->widget()->property("SUIFont").toString(), NewText);
    progressbar->setBold(NewBool);
    QCOMPARE(progressbar->getWidget()->property("SUIFont").toString(), NewText);
//    QuestionMark doesn't support setBold
//    questionmark->setBold(NewBool);
//    QCOMPARE(questionmark->widget()->property("SUIFont").toString(), NewText);
    radiobutton->setBold(NewBool);
    QCOMPARE(radiobutton->getWidget()->property("SUIFont").toString(), NewText);
    sciencespinbox->setBold(NewBool);
    QCOMPARE(sciencespinbox->getWidget()->property("SUIFont").toString(), NewText);
    spinbox->setBold(NewBool);
    QCOMPARE(spinbox->getWidget()->property("SUIFont").toString(), NewText);
    dblspinbox->setBold(NewBool);
    QCOMPARE(dblspinbox->getWidget()->property("SUIFont").toString(), NewText);
    tablewidgetitem->setBold(NewBool);
    QCOMPARE(tablewidgetitem->getWidget()->font().bold(), bool(NewBool));
//    TextArea support setBold in a different way
//    textarea->setBold(NewBool);
//    QCOMPARE(textarea->getWidget()->font().bold(), bool(NewBool));
    msgbox->setBold(NewBool);
    QCOMPARE(msgbox->getWidget()->font().bold(), bool(NewBool));
    graphicstext->setBold(NewBool);
    QCOMPARE(graphicstext->isBold(), bool(NewBool));
    treeItem->setBold(NewBool);
    QCOMPARE(treeItem->getWidget()->font().bold(), bool(NewBool));
}

void ITextUnitTest::testSetBoldCase1_data()
{
    QTest::addColumn<bool>("NewBool");
    QTest::addColumn<QString>("NewText");
    QTest::newRow("setBold") << true << QString("bold");
    QTest::newRow("resetBold") << false << QString("");
}
