#include "SUIWidgetUnitTest.h"

#include <QTest>

#include <boost/bind.hpp>

#include <SUIWidget.h>

#include <list>

SUI::WidgetUnitTest::WidgetUnitTest(Widget *object, QObject *parent) :
    ObjectUnitTest(object,parent),
    object(object)
{
}

SUI::WidgetUnitTest::~WidgetUnitTest() {
    delete object;
}

void SUI::WidgetUnitTest::setEnabled() {
    //Note : TabPage is diabled
    if(object->getObjectType() != SUI::ObjectType::TabPage){
        object->setEnabled(true);
        QCOMPARE(object->isEnabled(),true);

        object->setEnabled(false);
        QCOMPARE(object->isEnabled(),false);
    }
}

void SUI::WidgetUnitTest::setFocus() {
//    object->setFocus();
//    QVERIFY(object->hasFocus());
    //This can not be tested without visible components
}

void SUI::WidgetUnitTest::clearFocus() {
//    object->clearFocus();
//    QVERIFY(!object->hasFocus());
    //This can not be tested without visible components
}

void SUI::WidgetUnitTest::setContextMenuItems() {
    std::list<std::string> items;
    items.push_back("a");
    items.push_back("b");
    object->setContextMenuItems(items);
    QCOMPARE(object->getContextMenuItems().front(),items.front());
    QCOMPARE(object->getContextMenuItems().back(),items.back());
}

void SUI::WidgetUnitTest::contextMenuClicked() {
    QVERIFY(object->contextMenuClicked.empty());
    object->contextMenuClicked = boost::bind(&WidgetUnitTest::onContextMenuClicked,this,_1,_2);
    QVERIFY(!object->contextMenuClicked.empty());
    object->contextMenuClicked("","");
}

void SUI::WidgetUnitTest::setStyleSheetClass() {
   object->setStyleSheetClass("Style1");
   QCOMPARE(QString::fromStdString(object->getStyleSheetClass()), QString::fromStdString("Style1"));
}

void SUI::WidgetUnitTest::onContextMenuClicked(const std::string &, const std::string &) {
    QVERIFY(true); // if this function is called, the test passed
}
