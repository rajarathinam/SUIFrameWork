#include "SUIGraphicsViewUnitTest.h"


SUI::GraphicsViewUnitTest::GraphicsViewUnitTest(SUI::GraphicsView *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::GraphicsViewUnitTest::~GraphicsViewUnitTest() {
    delete object;
}
