#include "testScrollBar.h"


#include <SUIScrollBar.h>
#include <SUICheckBox.h>
#include <SUITextArea.h>

// constructor
testScrollBar::testScrollBar(QString horizontalScrollBarWidgetId, QString verticalScrollBarWidgetId,
                             QString horizontalTextWidgetId, QString verticalTextWidgetId,
                             QString enabledCheckboxWidgetId, SUI::DialogImpl *apGui) :
                mHorizontalScrollBarWidgetId(horizontalScrollBarWidgetId),
                mVerticalScrollBarWidgetId(verticalScrollBarWidgetId),
                mHorizontalTextWidgetId(horizontalTextWidgetId),
                mVerticalTextWidgetId(verticalTextWidgetId),
                mEnabledCheckboxWidgetId(enabledCheckboxWidgetId),
                mpGui(apGui)
{}


void testScrollBar::handleClickedMinMax1()
{
    SetMinMaxValue(0, 100);
}


void testScrollBar::handleClickedMinMax2()
{
    SetMinMaxValue(-50, 150);
}


void testScrollBar::handleClickedPageStep1()
{
    SetPageStep(1, 10);
}


void testScrollBar::handleClickedPageStep2()
{
    SetPageStep(5, 50);
}


void testScrollBar::handleValueChangedHorizontal()
{
    UpdateTextArea(mHorizontalScrollBarWidgetId, mHorizontalTextWidgetId);
}


void testScrollBar::handleValueChangedVertical()
{
    UpdateTextArea(mVerticalScrollBarWidgetId, mVerticalTextWidgetId);
}

void testScrollBar::handleValueChangedEnabled()
{
    SUI::ScrollBar* horScrollBarWidget = mpGui->getObjectList()->getObject<SUI::ScrollBar>(mHorizontalScrollBarWidgetId.toStdString());
    if (mHorizontalScrollBarWidgetId == NULL)
    {
        return; // avoid crashing, do nothing
    }
    SUI::ScrollBar* vertScrollBarWidget = mpGui->getObjectList()->getObject<SUI::ScrollBar>(mVerticalScrollBarWidgetId.toStdString());
    if (mVerticalScrollBarWidgetId == NULL)
    {
        return; // avoid crashing, do nothing
    }
    SUI::CheckBox* enabledCheckboxWidget = mpGui->getObjectList()->getObject<SUI::CheckBox>(mEnabledCheckboxWidgetId.toStdString());
    if (enabledCheckboxWidget == NULL)
    {
        return; // avoid crashing, do nothing
    }
    horScrollBarWidget->setEnabled(enabledCheckboxWidget->isChecked());
    vertScrollBarWidget->setEnabled(enabledCheckboxWidget->isChecked());
}

void testScrollBar::SetMinMaxValue(int minValue, int maxValue)
{
    SUI::INumeric<int>* horScrollBarWidget = mpGui->getObjectList()->getObject<SUI::INumeric<int> >(mHorizontalScrollBarWidgetId.toStdString());
    if (horScrollBarWidget == NULL)
    {
        return; // avoid crashing, do nothing
    }
    SUI::INumeric<int>* vertScrollBarWidget = mpGui->getObjectList()->getObject<SUI::INumeric<int> >(mVerticalScrollBarWidgetId.toStdString());
    if (vertScrollBarWidget == NULL)
    {
        return; // avoid crashing, do nothing
    }

    horScrollBarWidget->setMinValue(minValue);
    horScrollBarWidget->setMaxValue(maxValue);
    vertScrollBarWidget->setMinValue(minValue);
    vertScrollBarWidget->setMaxValue(maxValue);

    UpdateTextArea(mHorizontalScrollBarWidgetId, mHorizontalTextWidgetId);
    UpdateTextArea(mVerticalScrollBarWidgetId, mVerticalTextWidgetId);
}

void testScrollBar::SetPageStep(int stepValue, int pageValue)
{
    SUI::ScrollBar* horScrollBarWidget = mpGui->getObjectList()->getObject<SUI::ScrollBar>(mHorizontalScrollBarWidgetId.toStdString());
    if (mHorizontalScrollBarWidgetId == NULL)
    {
        return; // avoid crashing, do nothing
    }
    SUI::ScrollBar* vertScrollBarWidget = mpGui->getObjectList()->getObject<SUI::ScrollBar>(mVerticalScrollBarWidgetId.toStdString());
    if (mVerticalScrollBarWidgetId == NULL)
    {
        return; // avoid crashing, do nothing
    }

    horScrollBarWidget->setPageStep(pageValue);
    vertScrollBarWidget->setPageStep(pageValue);
    horScrollBarWidget->setStepSize(stepValue);
    vertScrollBarWidget->setStepSize(stepValue);

    UpdateTextArea(mHorizontalScrollBarWidgetId, mHorizontalTextWidgetId);
    UpdateTextArea(mVerticalScrollBarWidgetId, mVerticalTextWidgetId);
}


void testScrollBar::UpdateTextArea(QString scrollBarId, QString textAreaId)
{
    SUI::ScrollBar* scrollBarWidget = mpGui->getObjectList()->getObject<SUI::ScrollBar>(scrollBarId.toStdString());
    if (scrollBarWidget == NULL)
    {
        return; // avoid crashing, do nothing
    }
    SUI::IText* textWidget = mpGui->getObjectList()->getObject<SUI::IText>(textAreaId.toStdString());
    if (textWidget == NULL)
    {
        return; // avoid crashing, do nothing
    }

    int val = scrollBarWidget->getValue();
    int min = scrollBarWidget->getMinValue();
    int max = scrollBarWidget->getMaxValue();
    int step = scrollBarWidget->getStepSize();
    int page = scrollBarWidget->getPageStep();


    QString message = QString("value:%1, Min:%2, Max:%3, Step:%4, Page:%5").arg(val).arg(min).arg(max).arg(step).arg(page);

    textWidget->setText(message.toStdString());
}
