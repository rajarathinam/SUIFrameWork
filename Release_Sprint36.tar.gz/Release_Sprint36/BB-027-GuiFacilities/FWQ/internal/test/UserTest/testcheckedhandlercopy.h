#ifndef TESTCHECKEDHANDLERCOPY_H
#define TESTCHECKEDHANDLERCOPY_H

#include <SUIDialogImpl.h>

class testCheckedHandlerCopy
{
    QString     mIDChecked;
    QString     mIDUnchecked;
    QString     mIDDestination;
    SUI::DialogImpl      *mpGui;

public:
    testCheckedHandlerCopy(QString aIDtextChecked, QString aIDtextUnchecked, QString aIDDestination, SUI::DialogImpl *apGui);
    void        handleCheckedChanged(bool checked);
};

#endif // TESTCHECKEDHANDLERCOPY_H
