#ifndef TESTSTEPSIZEDOUBLEHANDLER_H
#define TESTSTEPSIZEDOUBLEHANDLER_H


#include "SUIDialogImpl.h"

class testStepsizeDoubleValueHandler
{
public:
    testStepsizeDoubleValueHandler(QString aSourceWidgetID, QString aTargetWidgetID , SUI::DialogImpl *apGui);

    void    handleValueChanged();

private:
    QString mSourceWidgetid;
    QString mTargetWidgetid;
    SUI::DialogImpl  *mpGui;
};

#endif // TESTSTEPSIZEDOUBLEHANDLER_H
