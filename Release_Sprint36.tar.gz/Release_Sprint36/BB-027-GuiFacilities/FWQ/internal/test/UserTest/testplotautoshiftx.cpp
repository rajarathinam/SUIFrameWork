#include "testplotautoshiftx.h"

#include <SUIPlotWidget.h>

testPlotAutoShiftX::testPlotAutoShiftX(QString pltWidgetID, SUI::DialogImpl *apGui) :
    mPlotWidgetID(pltWidgetID),
    mpGui(apGui)
{
}

void testPlotAutoShiftX::handleCheckedChanged(bool checked)
{
    SUI::PlotWidget *plotWidget = mpGui->getObjectList()->getObject<SUI::PlotWidget>(mPlotWidgetID.toStdString());
    if (plotWidget)
    {
        plotWidget->setXAutoScale(checked);
        plotWidget->replot();
    }

}
