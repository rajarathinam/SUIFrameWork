#include "testSetAutoScroll.h"

#include <SUITextArea.h>
#include <SUIDialogImpl.h>

testSetAutoScroll::testSetAutoScroll(QString aTargetWidgetID , SUI::DialogImpl *apGui):
    mTargetWidgetID(aTargetWidgetID),
    mpGui(apGui)
{
}

void testSetAutoScroll::handleCheckedChanged(bool checked)
{
    SUI::TextArea *txa = mpGui->getObjectList()->getObject<SUI::TextArea>(mTargetWidgetID.toStdString());
    bool scroll = (checked ? true : false);
    if (txa)
    {
        txa->setAutoScroll(scroll);
    }
}
