#ifndef TESTSETCOLOR_H
#define TESTSETCOLOR_H

#include <SUIDialogImpl.h>



class testSetColor
{
private:
    QString mTargetWidgetid;
    QString mSourceWidgetid;
    SUI::DialogImpl  *mpGui;

public:
    void handleClicked();
    void handleValueChanged();
    testSetColor(QString aSourceWidgetID, QString aTargetWidgetID , SUI::DialogImpl *apGui);
};

#endif // TESTSETCOLOR_H
