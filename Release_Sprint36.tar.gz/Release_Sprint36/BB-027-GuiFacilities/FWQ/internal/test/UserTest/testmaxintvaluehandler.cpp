#include "testmaxintvaluehandler.h"

#include <SUIINumeric.h>

testMaxIntValueHandler::testMaxIntValueHandler(QString aSourceWidgetID, QString aTargetWidgetID, SUI::DialogImpl *apGui) :
    mSourceWidgetid(aSourceWidgetID),
    mTargetWidgetid(aTargetWidgetID),
    mpGui(apGui)
{
}

void testMaxIntValueHandler::handleValueChanged()
{
    SUI::INumeric<int> *widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<int>>(mSourceWidgetid.toStdString());
    if (widgetNum)
    {
        int val = widgetNum->getValue();
        widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<int>>(mTargetWidgetid.toStdString());
        if (widgetNum)
        {
            widgetNum->setMaxValue(val);
        }
    }
}

