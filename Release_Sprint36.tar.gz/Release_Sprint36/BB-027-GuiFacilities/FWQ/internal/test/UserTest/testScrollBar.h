#ifndef TESTSCROLLBAR_H
#define TESTSCROLLBAR_H

#include <SUIDialogImpl.h>

class testScrollBar
{
    QString mHorizontalScrollBarWidgetId;
    QString mVerticalScrollBarWidgetId;
    QString mHorizontalTextWidgetId;
    QString mVerticalTextWidgetId;
    QString mEnabledCheckboxWidgetId;

    SUI::DialogImpl  *mpGui;

public:
    // constructor
    testScrollBar(QString horizontalScrollBarWidgetId, QString verticalScrollBarWidgetId,
                  QString horizontalTextWidgetId, QString verticalTextWidgetId,
                  QString enabledCheckboxWidgetId, SUI::DialogImpl *apGui);

    void handleClickedMinMax1();
    void handleClickedMinMax2();
    void handleClickedPageStep1();
    void handleClickedPageStep2();

    void handleValueChangedHorizontal();
    void handleValueChangedVertical();
    void handleValueChangedEnabled();

private:
    void UpdateTextArea(QString scrollBarId, QString textAreaId);
    void SetMinMaxValue(int minValue, int maxValue);
    void SetPageStep(int stepValue, int pageValue);
};

#endif // TESTSCROLLBAR_H
