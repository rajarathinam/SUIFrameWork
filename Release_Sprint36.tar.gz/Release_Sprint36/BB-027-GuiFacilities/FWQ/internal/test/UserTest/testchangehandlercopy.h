#ifndef TESTCHANGEHANDLERCOPY_H
#define TESTCHANGEHANDLERCOPY_H
#include "SUIDialogImpl.h"

class testchangehandlercopy
{
    QString mWidgetID;
    RticGUI *mpGui;
public:
    testchangehandlercopy(QString aIDDestination, RticGUI *apGui);
    void handleValueChanged(QString text);
};

#endif // TESTCHANGEHANDLERCOPY_H
