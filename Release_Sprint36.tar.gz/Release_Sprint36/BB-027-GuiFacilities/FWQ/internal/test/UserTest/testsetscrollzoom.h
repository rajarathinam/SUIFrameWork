#ifndef TESTSETSCROLLZOOM_H
#define TESTSETSCROLLZOOM_H

#include <QString>

namespace SUI {
class DialogImpl;
}

class testSetScrollZoom
{
    QString mTargetWidgetid;
    SUI::DialogImpl  *mpGui;

public:
    testSetScrollZoom(QString aTargetWidgetID, SUI::DialogImpl *apGui);
    void handleCheckedChanged(bool checked);
};

#endif // TESTSETSCROLLZOOM_H
