#ifndef TESTALIGNMENT_H
#define TESTALIGNMENT_H

#include <QString>



namespace SUI {
class DialogImpl;
}

class testAlignment
{
private:
    QString mSourceWidgetid;
    QString mTargetWidgetid;
    QString mDropDownText;
    SUI::DialogImpl  *mpGui;
public:
    testAlignment(QString aTargetWidgetID, QString aDropDownText, SUI::DialogImpl *apGui);
    void handleClicked();
};

#endif // TESTALIGNMENT_H
