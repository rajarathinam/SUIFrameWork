#ifndef TESTPLOTYLEFTLABEL_H
#define TESTPLOTYLEFTLABEL_H


#include <QString>



namespace SUI {
class DialogImpl;
}

class testPlotYLeftLabel
{
public:
    testPlotYLeftLabel(QString pltWidgetID, QString YLabelWidgetID, SUI::DialogImpl *apGui);

    void    handleClicked();

private:
    QString mPlotWidgetID;
    QString mYLabelWidgetID;

    SUI::DialogImpl  *mpGui;
};

#endif // TESTPLOTYLEFTLABEL_H
