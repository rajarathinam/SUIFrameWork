#include "testaddtablewidgetrow.h"

#include <SUITableWidget.h>
#include <SUIIText.h>
#include <SUIDialogImpl.h>

testAddTableWidgetRow::testAddTableWidgetRow(QString aTargetWidgetID, QString aStatus ,SUI::DialogImpl *apGui) :
    mTargetWidgetid(aTargetWidgetID),
    mStatus(aStatus),
    mpGui(apGui)
{
}

void testAddTableWidgetRow::handleClicked()
{
    SUI::TableWidget  *tableWidget = mpGui->getObjectList()->getObject<SUI::TableWidget>(mTargetWidgetid.toStdString());
    SUI::IText *textWidget = mpGui->getObjectList()->getObject<SUI::IText>(mStatus.toStdString());
    if (tableWidget && textWidget)
    {
        textWidget->clearText();
        tableWidget->appendRow();
        textWidget->setText(QString("Append Row %1").arg(QString::number(tableWidget->rowCount())).toStdString());
    }
}




testGetItems::testGetItems(QString sourceID, QString targetID, SUI::DialogImpl *apGui) :
    mSourceID(sourceID),
    mTargetID(targetID),
    mpGui(apGui)
{
}

void testGetItems::handleClicked()
{
    QStringList itemList;
    SUI::TableWidget *widgetTable = mpGui->getObjectList()->getObject<SUI::TableWidget>(mSourceID.toStdString());
    if (widgetTable)
    {
        foreach(std::string item, widgetTable->getItems())
        {
            itemList.append(QString::fromStdString(item));
        }
        QString text = itemList.join(";");
        SUI::IText *textWidget = mpGui->getObjectList()->getObject<SUI::IText>(mTargetID.toStdString());
        if (textWidget)
        {
            textWidget->clearText();
            textWidget->setText(text.toStdString());
        }
    }
}

testShowGrid::testShowGrid(QString aWidgetID, SUI::DialogImpl *apGui) :
    mWidgetID(aWidgetID),
    mpGui(apGui)
{

}

void testShowGrid::onEnabled(bool checked) {

    SUI::TableWidget *widget = mpGui->getObjectList()->getObject<SUI::TableWidget>(mWidgetID.toStdString());
    if (widget)
    {
        widget->showGrid(checked);
    }
}
