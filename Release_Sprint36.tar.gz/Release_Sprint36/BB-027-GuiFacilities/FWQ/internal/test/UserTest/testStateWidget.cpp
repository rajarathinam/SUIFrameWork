#include "testStateWidget.h"

#include <SUIIText.h>
#include <SUIStateWidget.h>
#include <SUIDropDown.h>

testStateWidget::testStateWidget(QString aSourceWidgetID, QString aTargetWidgetID, SUI::DialogImpl *apGui, test aTest):
    mSourceWidgetid(aSourceWidgetID),
    mTargetWidgetid(aTargetWidgetID),
    mpGui(apGui),
    mTest(aTest)
{

}

void testStateWidget::handleClicked()
{
    SUI::StateWidget *sttWidget = NULL;
    SUI::IText *textWidget = NULL;
    std::string text;
    switch (mTest)
    {
    case setType:
        sttWidget = mpGui->getObjectList()->getObject<SUI::StateWidget>(mTargetWidgetid.toStdString());
        textWidget = mpGui->getObjectList()->getObject<SUI::IText>(mSourceWidgetid.toStdString());
        if (sttWidget && textWidget) {
            text = textWidget->getText();
            sttWidget->setState(text);
        }
        break;
    case getSupportedStates:
    {
        sttWidget = mpGui->getObjectList()->getObject<SUI::StateWidget>(mSourceWidgetid.toStdString());
        SUI::DropDown *dropStates = mpGui->getObjectList()->getObject<SUI::DropDown>(mTargetWidgetid.toStdString());
        if (sttWidget && dropStates) {
            dropStates->clearItems();
            dropStates->addItems(sttWidget->getSupportedStates());
        }
        break;
    }
    case getState:
        sttWidget = mpGui->getObjectList()->getObject<SUI::StateWidget>(mSourceWidgetid.toStdString());
        textWidget = mpGui->getObjectList()->getObject<SUI::IText>(mTargetWidgetid.toStdString());
        if (sttWidget && textWidget) {
            text = sttWidget->getState();
            textWidget->setText(text);
        }
        break;
    case setState:
    {
        sttWidget = mpGui->getObjectList()->getObject<SUI::StateWidget>(mTargetWidgetid.toStdString());
        SUI::DropDown *dropStates = mpGui->getObjectList()->getObject<SUI::DropDown>(mSourceWidgetid.toStdString());
        if (sttWidget && dropStates) {
            text = dropStates->getSelectedItems().front();
            sttWidget->setState(text);
        }
        break;
    }
    default:
        break;
    }
}
