#ifndef TESTTABLEWIDGETITEMTEXTCOPY_H
#define TESTTABLEWIDGETITEMTEXTCOPY_H

#include <QString>

namespace SUI {
class DialogImpl;
}

class testTableWidgetItemTextCopy 
{
public:
    testTableWidgetItemTextCopy(QString targetwidgetID, QString srcwidgetID, QString rowindwidgetID, QString colindwidgetID, SUI::DialogImpl *apGui);

    void handleClicked();
    virtual void handleSelectionChanged();
    virtual void setListViewMode(bool on);
    virtual void handleCheckedChanged(bool checked);

private:
    QString mTargetWidgetid;
    QString mSourceWidgetid;
    QString mRowSpinBoxID;
    QString mColSpinBoxID;
    SUI::DialogImpl  *mpGui;
};

class testTableWidgetTextFilter
{
public:
    testTableWidgetTextFilter(QString  targetwidgetID, QString srcwidgetID, QString caseWidgetID, QString columnNrID, SUI::DialogImpl *apGui);

    virtual void handleCheckedChanged(bool checked);

private:
    QString mTargetWidgetid;
    QString mSourceWidgetid;
    QString mCaseWidgetID;
    QString mColumnNrWidgetid;
    SUI::DialogImpl  *mpGui;

};

class testTableWidgetAddRowData
{
public:
    testTableWidgetAddRowData(QString tawID, QString lneID, QString isbID, SUI::DialogImpl *apGui);

    void handleClicked();

private:
    QString mTawID;
    QString mLneID;
    QString mIsbID;
    SUI::DialogImpl *mpGui;
};


class testTableWidgetSetWidgetItemName
{
public:
    testTableWidgetSetWidgetItemName(QString tableID, QString rowID, QString colID, QString cellName, SUI::DialogImpl *apGui);
    void handleClicked();

private:
    QString mTableID;
    QString mIsbRow;
    QString mIsbCol;
    QString mLneCellname;
    SUI::DialogImpl *mpGui;
};


class testTableWidgetGetWidgetItemByName
{
public:
    testTableWidgetGetWidgetItemByName(QString tableID, QString cellName, QString widget ,SUI::DialogImpl *apGui);
    void handleClicked();

private:
    QString mTableID;
    QString mCellname;
    QString mWidgetID;
    SUI::DialogImpl *mpGui;

};

#endif // TESTTABLEWIDGETITEMTEXTCOPY_H
