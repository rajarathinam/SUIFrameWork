#!/bin/bash
#
#-------------------------------------------------------------------------------
#   build.sh
#   
#   A script to build the trunk
#-------------------------------------------------------------------------------

#Go to the current directory
cd "${0%/*}"

DEBUG=0
RELEASE=0

while [[ $# -gt 0 ]]
do
    key="$1"
    case $key in
        debug)
        DEBUG=1
            ;;
            release)
            RELEASE=1
            ;;
            clean)
            CLEAN=1
            ;;
            help)
            HELP=1
            ;;
      esac
      shift
done


# Functions
function print_message(){
      echo "******************************"
      echo "**** $1"
      echo "******************************"
}

# script
if [ "${HELP}" == 1 ]; then
      echo "******************************"
      echo "**** HELP"
      echo "****"
      echo "**** debug: Build in debug mode."
      echo "**** release: Build in release mode."
      echo "**** help: Displays this help documentation."
      echo "**** clean: Cleans the build before the build is started."
      echo "******************************"
      exit
fi

print_message "Starting build"

if [ "${DEBUG}" == 1 ] && [ "${RELEASE}" == 0 ]; then
      print_message "Building debug"
      qmake48 $(pwd)/../../SUIFramework.pro -r -spec linux-g++-64 CONFIG+=debug
elif [ "${RELEASE}" == 1 ] && [ "${DEBUG}" == 0 ]; then
      print_message "Building release"
      qmake48 $(pwd)/../../SUIFramework.pro -r -spec linux-g++-64 CONFIG+=release
else
      print_message "Building debug & release"
      qmake48 $(pwd)/../../SUIFramework.pro -r -spec linux-g++-64 CONFIG+=debug_and_release
fi

if [ "${CLEAN}" == 1 ]; then
      print_message "Cleaning up"
      make -f QtMakefile clean
fi

make -f QtMakefile
if [ "$?" != 0 ]; then
      print_message "Build failed!"
      exit 1
fi


print_message "Build success!"
exit 0
