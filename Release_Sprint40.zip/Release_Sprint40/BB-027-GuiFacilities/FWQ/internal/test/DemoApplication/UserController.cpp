#include "UserController.h"

// needed to bind the boost function
#include <boost/bind.hpp>
#include <boost/function.hpp>

#include "UserClass.h"

// needed for used classes
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUIProgressBar.h>
#include <FWQxWidgets/SUIDialog.h>
#include <FWQxWidgets/SUILabel.h>

// needed for the timer
#include <FWQxUtils/SUITimer.h>

//needed for time
#include <FWQxUtils/SUITime.h>

// needed for output
#include <iostream>

UserController::UserController(UserClass *userClass) :
    userClass(userClass), // assign the instance of userClass
    timer(SUI::Timer::createTimer()), // instantiate the timer
    timeTimer(SUI::Timer::createTimer()),
    time(SUI::Time::createTime())
{
    // bind the Button clicked callback
    userClass->getStartButton()->clicked = boost::bind(&UserController::onStartButtonClicked,this);
    userClass->getStopButton()->clicked = boost::bind(&UserController::onStopButtonClicked,this);

    // bind the ProgressBar valueChanged callback
    userClass->getProgressBar()->progressChanged = boost::bind(&UserController::onProgressBarValueChanged,this);

    // setup the timer
    timer->setSingleShot(true);
    timer->setInterval(100);

    timeTimer->setSingleShot(false);
    timeTimer->setInterval(1);

    // bind the Timer timeout callback
    timer->timeout = boost::bind(&UserController::onTimerTimeout,this);
    timeTimer->timeout = boost::bind(&UserController::onTimeTimerTimeout,this);

    //start the time
    time->start();

    // show the dialog
    userClass->getDialog()->show();

    userClass->getStopButton()->setEnabled(false);
}

UserController::~UserController()
{
   delete userClass;
}

void UserController::onStartButtonClicked() {
    // on clicked start the timer
    std::cout << "Start clicked" << std::endl;
    timer->start();
    timeTimer->start();

    // restart the time to current time
    time->restart();

    // enable/disable the buttons
    userClass->getStopButton()->setEnabled(true);
    userClass->getStartButton()->setEnabled(false);
}

void UserController::onStopButtonClicked() {
    std::cout << "Stop clicked" << std::endl;

    // stop the timers
    timer->stop();
    timeTimer->stop();

    // enable/disable the buttons
    userClass->getStopButton()->setEnabled(false);
    userClass->getStartButton()->setEnabled(true);
}

void UserController::onProgressBarValueChanged() {
    // spam output when the ProgressBar value changed
    std::cout << "ProgressBar value changed to: " << userClass->getProgressBar()->getValue() << std::endl;
}

void UserController::onTimerTimeout() {
    // when the timer timed out increase the value of the ProgressBar with 1
    userClass->getProgressBar()->setValue(userClass->getProgressBar()->getValue() + 1);

    // if the ProgressBar value is smaller than 75 restart the timer
    if (userClass->getProgressBar()->getValue() < 75) timer->start();
}

void UserController::onTimeTimerTimeout() {
    // every interval, add 1 msec
    time->addMSecs(1);

    // set the label text
    userClass->getTimeLabel()->setText(time->toString("HH:mm:ss.zzz"));
}
