#ifndef SUIWEBVIEWUNITTEST_H
#define SUIWEBVIEWUNITTEST_H

#include "SUIWidgetUnitTest.h"
#include <FWQxWidgets/SUIWebView.h>

namespace SUI {

class WebView;

class WebViewUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    WebViewUnitTest(SUI::WebView *object, QObject *parent = 0);
    virtual ~WebViewUnitTest();

protected:
    void callInterfaceTests();

private:
    WebView *object;
};

}

#endif // SUIWEBVIEWUNITTEST_H
