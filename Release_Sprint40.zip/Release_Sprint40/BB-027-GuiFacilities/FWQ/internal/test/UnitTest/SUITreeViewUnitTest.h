#ifndef SUITREEVIEWUNITTEST_H
#define SUITREEVIEWUNITTEST_H

#include <FWQxWidgets/SUITreeView.h>
#include "SUIWidgetUnitTest.h"

namespace SUI {

class TreeView;

class TreeViewUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    TreeViewUnitTest(SUI::TreeView *object, QObject *parent = 0);
    virtual ~TreeViewUnitTest();

private slots:
    void setTitle();

protected:
    void callInterfaceTests();

private:
    TreeView *object;
};

}

#endif // SUITREEVIEWUNITTEST_H
