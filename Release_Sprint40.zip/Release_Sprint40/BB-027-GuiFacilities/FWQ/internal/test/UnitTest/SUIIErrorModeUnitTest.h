#ifndef SUIIERRORMODEUNITTEST_H
#define SUIIERRORMODEUNITTEST_H

namespace SUI {

class IErrorMode;

class IErrorModeUnitTest
{
public:
    IErrorModeUnitTest(SUI::IErrorMode *object);
    bool setErrorMode();

private:
    IErrorMode *object;
};
}
#endif // SUIIERRORMODEUNITTEST_H
