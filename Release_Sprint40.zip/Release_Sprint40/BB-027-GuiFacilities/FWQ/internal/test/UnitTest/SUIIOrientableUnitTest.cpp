#include "SUIIOrientableUnitTest.h"
#include <FWQxCore/SUIIOrientable.h>
#include <QTest>

SUI::IOrientableUnitTest::IOrientableUnitTest(SUI::IOrientable *object) :
    object(object)
{
    Q_ASSERT(object);
}

bool SUI::IOrientableUnitTest::setOrientation(OrientationEnum::Orientation orientation) {
    object->setOrientation(orientation);
    return (object->getOrientation() == orientation);
}
