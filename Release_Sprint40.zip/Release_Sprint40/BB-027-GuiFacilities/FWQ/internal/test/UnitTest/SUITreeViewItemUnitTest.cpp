#include "SUITreeViewItemUnitTest.h"
#include "SUIITextUnitTest.h"
#include <QTest>

SUI::TreeViewItemUnitTest::TreeViewItemUnitTest(SUI::TreeViewItem *object, QObject *parent) :
    WidgetUnitTest(object, parent),
    object(object)
{
}

SUI::TreeViewItemUnitTest::~TreeViewItemUnitTest()
{
    delete object;
}

void SUI::TreeViewItemUnitTest::callInterfaceTests() {
    //IText tests
    ITextUnitTest iTextUnitTest(object);
    //TODO set text interface tests fails
    //QVERIFY(iTextUnitTest.setText());
    QVERIFY(iTextUnitTest.clearText());
    QVERIFY(iTextUnitTest.setBold());
}
