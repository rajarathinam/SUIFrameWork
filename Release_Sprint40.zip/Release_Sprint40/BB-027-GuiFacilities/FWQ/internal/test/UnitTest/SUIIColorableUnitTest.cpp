#include "SUIIColorableUnitTest.h"

#include <QTest>

#include <FWQxCore/SUIIColorable.h>

SUI::IColorableUnitTest::IColorableUnitTest(SUI::IColorable *object) :
    object(object)
{
    Q_ASSERT(object);
}

bool SUI::IColorableUnitTest::setColor(SUI::ColorEnum::Color color) {
     object->setColor(color);
     return (object->getColor() == color);
}
