#include "SUIStateWidgetUnitTest.h"
#include <QTest>

SUI::StateWidgetUnitTest::StateWidgetUnitTest(SUI::StateWidget *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::StateWidgetUnitTest::~StateWidgetUnitTest() {
    delete object;
}
