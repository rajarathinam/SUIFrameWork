#ifndef IALIGNABLEUNITTEST_H
#define IALIGNABLEUNITTEST_H

#include <FWQxCore/SUIAlignmentEnum.h>

namespace SUI {

class IAlignable;

class IAlignableUnitTest
{

public:
    IAlignableUnitTest(IAlignable *object);

    bool setAlignment(SUI::AlignmentEnum::Alignment align);

private:
    IAlignable *object;
};

}
#endif // IALIGNABLEUNITTEST_H
