#ifndef SUISTATEWIDGETUNITTEST_H
#define SUISTATEWIDGETUNITTEST_H

#include "SUIWidgetUnitTest.h"
#include <FWQxWidgets/SUIStateWidget.h>

namespace SUI {

class StateWidget;

class StateWidgetUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    StateWidgetUnitTest(SUI::StateWidget *object, QObject *parent = 0);
    virtual ~StateWidgetUnitTest();

private:
    StateWidget *object;
};

}
#endif // SUISTATEWIDGETUNITTEST_H
