#ifndef SUIUSERCONTROLUNITTEST_H
#define SUIUSERCONTROLUNITTEST_H

#include <FWQxWidgets/SUIUserControl.h>
#include "SUIWidgetUnitTest.h"

namespace SUI {

class UserControl;

class UserControlUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    UserControlUnitTest(SUI::UserControl *object, QObject *parent = 0);
    virtual ~UserControlUnitTest();

protected:
    void callInterfaceTests();

private:
    UserControl *object;
};

}

#endif // SUIUSERCONTROLUNITTEST_H
