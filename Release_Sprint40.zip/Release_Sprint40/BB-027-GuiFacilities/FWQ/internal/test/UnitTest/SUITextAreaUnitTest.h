#ifndef SUITEXTAREAUNITTEST_H
#define SUITEXTAREAUNITTEST_H

#include "SUIWidgetUnitTest.h"
#include <FWQxWidgets/SUITextArea.h>

namespace SUI {

class TextArea;

class TextAreaUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    TextAreaUnitTest(SUI::TextArea *object, QObject *parent = 0);
    virtual ~TextAreaUnitTest();

private slots:
    void setText();
    void setAutoScroll();
    void setReadOnly();

protected:
    void callInterfaceTests();

private:
    TextArea *object;
};

}
#endif // SUITEXTAREAUNITTEST_H
