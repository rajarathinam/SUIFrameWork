#include "SUIWebViewUnitTest.h"
#include "SUIIWebViewUnitTest.h"
#include <QTest>

SUI::WebViewUnitTest::WebViewUnitTest(SUI::WebView *object, QObject *parent) :
    WidgetUnitTest(object, parent),
    object(object)
{
}

SUI::WebViewUnitTest::~WebViewUnitTest()
{
    delete object;
}

void SUI::WebViewUnitTest::callInterfaceTests() {
    // IWebView interface tests
    IWebViewUnitTest iWebViewUnitTest(object);
    QVERIFY(iWebViewUnitTest.setUrl());
    QVERIFY(iWebViewUnitTest.setZoomFactor());
}
