#include "SUIIWebViewUnitTest.h"
#include <FWQxCore/SUIIWebView.h>
#include <QTest>

SUI::IWebViewUnitTest::IWebViewUnitTest(SUI::IWebView *object) :
    object(object)
{
    Q_ASSERT(object);
}

bool SUI::IWebViewUnitTest::setUrl() {
    std::string url = "http://www.nu.nl/";

    object->setUrl(url);
    return (object->getUrl() == url);
}

bool SUI::IWebViewUnitTest::setZoomFactor() {
    double factor = 1.5;

    object->setZoomFactor(factor);
    return (object->getZoomFactor() == factor);
}
