#include "SUIObjectUnitTest.h"

#include <QTest>

#include <FWQxCore/SUIObject.h>

#include <string>

SUI::ObjectUnitTest::ObjectUnitTest(Object *object, QObject *parent) :
    IViewableUnitTest(object,parent),
    object(object)
{
    Q_ASSERT(object);
}

SUI::ObjectUnitTest::~ObjectUnitTest()
{
    delete object;
}

void SUI::ObjectUnitTest::getId() {
    //FIXME this needs to be tested
    //QVERIFY(object->getId().size() > 0);
    QVERIFY(true);
}

void SUI::ObjectUnitTest::getObjectType() {
    QVERIFY(object->getObjectType() != SUI::ObjectType::None);
}

void SUI::ObjectUnitTest::interfaceTests() {
    callInterfaceTests();
}
