#ifndef SUIIWEBVIEWUNITTEST_H
#define SUIIWEBVIEWUNITTEST_H

namespace SUI {

class IWebView;

class IWebViewUnitTest
{
public:
    IWebViewUnitTest(IWebView *object);

    bool setUrl();
    bool setZoomFactor();

private:
    IWebView *object;
};

}

#endif // SUIIWEBVIEWUNITTEST_H
