#ifndef TESTMAXDOUBLEVALUEHANDLER_H
#define TESTMAXDOUBLEVALUEHANDLER_H


#include "SUIDialogImpl.h"

class testMaxDoubleValueHandler
{
public:
    testMaxDoubleValueHandler(QString aSourceWidgetID, QString aTargetWidgetID , SUI::DialogImpl *apGui);

    void    handleValueChanged();

private:
    QString mSourceWidgetid;
    QString mTargetWidgetid;
    SUI::DialogImpl  *mpGui;
};

#endif // TESTMAXDOUBLEVALUEHANDLER_H
