#ifndef TESTADDTABLEWIDGETROW_H
#define TESTADDTABLEWIDGETROW_H

#include <QString>



namespace SUI {
class DialogImpl;
}

class testAddTableWidgetRow
{
private:
    QString mTargetWidgetid;
    QString mStatus;
    SUI::DialogImpl  *mpGui;

public:
    testAddTableWidgetRow(QString aTargetWidgetID , QString aStatus, SUI::DialogImpl *apGui);
    virtual ~testAddTableWidgetRow();
    void handleClicked();
};

class testGetItems
{
private:
    QString     mSourceID;
    QString     mTargetID;
    SUI::DialogImpl      *mpGui;

public:
    testGetItems(QString sourceID, QString targetID, SUI::DialogImpl *apGui);
    virtual ~testGetItems();
    void    handleClicked();
};

class testShowGrid
{
private:
    QString mWidgetID;
    SUI::DialogImpl *mpGui;

public:
    testShowGrid(QString aWidgetID, SUI::DialogImpl *apGui);
    void onEnabled(bool checked);
};

class testRowVisible
{
private:
    QString mRowId;
    QString mTableId;
    SUI::DialogImpl  *mpGui;

public:
    testRowVisible(const QString aRow, const QString aTable , SUI::DialogImpl *apGui);
    virtual ~testRowVisible();
    void onEnabled(bool checked);

};

class testColumnVisible
{
private:
    QString mColId;
    QString mTableId;
    SUI::DialogImpl  *mpGui;

public:
    testColumnVisible(const QString aCol, const QString aTable , SUI::DialogImpl *apGui);
    virtual ~testColumnVisible();
    void onEnabled(bool checked);

};

#endif // TESTADDTABLEWIDGETROW_H
