#ifndef TESTMAXINTVALUEHANDLER_H
#define TESTMAXINTVALUEHANDLER_H


#include "SUIDialogImpl.h"

class testMaxIntValueHandler
{
public:
    testMaxIntValueHandler(QString aSourceWidgetID, QString aTargetWidgetID , SUI::DialogImpl *apGui);

    void    handleValueChanged();

private:
    QString mSourceWidgetid;
    QString mTargetWidgetid;
    SUI::DialogImpl  *mpGui;
};

#endif // TESTMAXINTVALUEHANDLER_H
