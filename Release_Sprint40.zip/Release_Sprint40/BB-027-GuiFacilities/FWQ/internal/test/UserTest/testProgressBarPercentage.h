#ifndef TESTPROGRESSBARPERCENTAGE_H
#define TESTPROGRESSBARPERCENTAGE_H


#include <SUIDialogImpl.h>

class testProgressBarPercentage
{
    QString mWidgetID;
    SUI::DialogImpl  *mpGui;

public:
    void handleCheckedChanged(bool checked);
    testProgressBarPercentage(QString aWidgetID, SUI::DialogImpl *apGui);

};

class testStartTimedProgress
{
public:
    testStartTimedProgress(QString pgbID, QString timeValID, SUI::DialogImpl *apGui);

    void    handleClicked();

private:
    QString     mPgbID;
    QString     mTimeValID;
    SUI::DialogImpl      *mpGui;
};

class testStopTimedProgress
{
public:
    testStopTimedProgress(QString pgbID, QString timeValID, SUI::DialogImpl *apGui);

    void    handleClicked();

private:
    QString     mPgbID;
    QString     mTimeValID;
    SUI::DialogImpl      *mpGui;
};

#endif // TESTPROGRESSBARPERCENTAGE_H
