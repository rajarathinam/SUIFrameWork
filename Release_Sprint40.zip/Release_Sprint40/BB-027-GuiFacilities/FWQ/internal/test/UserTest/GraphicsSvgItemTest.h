#ifndef GRAPHICSSVGITEMTEST
#define GRAPHICSSVGITEMTEST

#endif // GRAPHICSSVGITEMTEST
#include <string>
namespace SUI {
class GraphicsView;
class ColorCrossDrop;
class DropDown;
class Dialog;
class DoubleSpinBox;
class SpinBox;
class CheckBox;
class Button;
class LineEdit;
class TextArea;
}

class GraphicsSvgItemTest
{
public:
    GraphicsSvgItemTest(SUI::Dialog *dialog);
    virtual ~GraphicsSvgItemTest();

private :
    void onAddSvgItemClicked();
    void onSetSvgImageClicked();
    void onSetElementIdClicked();
    void onSetColorClicked();
    void onSetBorderColorClicked();
    void onSetTextClicked();
    void onGetAllElementIdClicked();
    void onSetBorderWidthClicked();
    void onSetTextColorClicked();
    void onSetToolTipClicked();
    void onSetSubscribeDoubleClick();
    void onSubscribeDoubleClicked(const std::string &str);
    void onSubscribeDoubleClicked_shape106(const std::string &str);
    void onSubscribeDoubleClicked_shape107(const std::string &str);
    void onSubscribeDoubleClicked_shape148(const std::string &str);
    void onSetScaleFactorClicked();
    void onGetTextClicked();
    void onSetElideTextClicked();
    void onResetElideTextClicked();

    SUI::Dialog *dialog;

    SUI::GraphicsView *graphicsView;

    SUI::Button *addSvgItemButton;

    SUI::Button *setSvgImageButton;

    SUI::Button *setElementIdButton;

    SUI::Button *setColorButton;
    SUI::LineEdit *setColorLineEdit;

    SUI::Button *setBorderColorButton;
    SUI::LineEdit *setBorderColorLineEdit;

    SUI::Button *setElideTextButton;
    SUI::Button *resetElideTextButton;

    SUI::Button *getTextButton;
    SUI::Button *setTextButton;
    SUI::LineEdit *setTextLineEdit;

    SUI::Button *getAllElementIdButton;

    SUI::Button *setBorderWidthButton;
    SUI::SpinBox *borderWidth;

    SUI::Button *setTextColorButton;
    SUI::Button *setToolTipButton;
    SUI::Button *setDoubleClickButton;
    SUI::Button *setScaleFactorButton;
    SUI::DoubleSpinBox *scaleFactor;

};
