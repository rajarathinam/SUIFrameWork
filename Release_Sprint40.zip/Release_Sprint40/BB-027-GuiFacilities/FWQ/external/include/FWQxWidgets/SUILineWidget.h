//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::LineWidget.
// !\description Header file for class SUI::LineWidget.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUILINEWIDGET_H
#define SUILINEWIDGET_H

#include "FWQxWidgets/SUIWidget.h"

namespace SUI {

/*!
 * \ingroup FWQxWidgets
 *
 * \brief The LineWidget class
 */
class SUI_SHARED_EXPORT LineWidget : public Widget
{
public:
    virtual ~LineWidget();

protected:
    LineWidget();
};
}
#endif // SUILINEWIDGET_H
