//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author      Patrick van Tongeren
// !\brief       Header file for class SUI::WebView
// !\description Header file for class SUI::WebView
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUIWEBVIEW_H
#define SUIWEBVIEW_H

#include "FWQxCore/SUIIWebView.h"
#include "FWQxWidgets/SUIWidget.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 *
 * \brief The WebView class
 */
class SUI_SHARED_EXPORT WebView : public Widget, public IWebView
{
public:
    virtual ~WebView();



protected:
    WebView();
};
}
#endif // SUIWEBVIEW_H
