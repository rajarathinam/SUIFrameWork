//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for ColorDrop.
// !\description Class implementation file for ColorDrop.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "FWQxWidgets/SUIColorDrop.h"

#include "FWQxCore/SUIObjectFactory.h"

SUI::ColorDrop::ColorDrop() : 
    Widget(SUI::ObjectType::fromString(SUI::ObjectFactory::getClassName<ColorDrop>()))
{
}

SUI::ColorDrop::~ColorDrop()
{
}
