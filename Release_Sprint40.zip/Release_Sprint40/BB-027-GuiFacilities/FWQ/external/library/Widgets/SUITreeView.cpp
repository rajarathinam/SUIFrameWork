//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for TreeView.
// !\description Class implementation file for TreeView.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "FWQxWidgets/SUITreeView.h"

#include "FWQxCore/SUIObjectFactory.h"

SUI::TreeView::TreeView() : 
    Widget(SUI::ObjectType::TreeView)
{
}

SUI::TreeView::~TreeView()
{
}
