//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for RingBuffer.
// !\description Class implementation file for RingBuffer.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|



#include "FWQxUtils/SUIRingBuffer.h"
#include "SUIRingBufferImpl.h"
#include <vector>


SUI::RingBuffer::RingBuffer(const int size) : impl(new RingBufferImpl(size))
{
}

SUI::RingBuffer::~RingBuffer()
{
    delete  static_cast<RingBufferImpl*>(impl);
    impl = NULL;
}


void SUI::RingBuffer::lock() const
{
    static_cast<RingBufferImpl*>(impl)->lock();
}

void SUI::RingBuffer::unlock() const
{
    static_cast<RingBufferImpl*>(impl)->unlock();
}

void SUI::RingBuffer::setSample(const SUI::PlotDataPoint &data)
{
    static_cast<RingBufferImpl*>(impl)->insert(data);
}

void SUI::RingBuffer::setSamples(const std::vector<SUI::PlotDataPoint> &values)
{
    static_cast<RingBufferImpl*>(impl)->insert(values);
}

void SUI::RingBuffer::setRawSamples(const double *xData, const double *yData, int size)
{
    static_cast<RingBufferImpl*>(impl)->insert(xData, yData, size);
}

void SUI::RingBuffer::clearSamples()
{
    static_cast<RingBufferImpl*>(impl)->clear();
}

SUI::PlotDataPoint SUI::RingBuffer::back() const
{
   return static_cast<RingBufferImpl*>(impl)->back();
}

void *SUI::RingBuffer::getImplementation()
{
    return impl;
}
