//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for RingBuffer.
// !\description Class implementation file for RingBuffer.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "FWQxUtils/SUIFilteredRingBuffer.h"
#include "SUIFilteredRingBufferImpl.h"


SUI::FilteredRingBuffer::FilteredRingBuffer(RingBuffer& ringBuffer) 
: impl(new FilteredRingBufferImpl(ringBuffer))
{
}

SUI::FilteredRingBuffer::~FilteredRingBuffer()
{
    delete  impl;
    impl = NULL;
}

SUI::FilteredRingBuffer::FilteredRingBuffer(const SUI::FilteredRingBuffer& buffer)
{
  if (&buffer != this)  
  {
  this->impl = buffer.impl;
  }
}

SUI::FilteredRingBuffer& SUI::FilteredRingBuffer::operator =(const SUI::FilteredRingBuffer& buffer)
{
   if (&buffer != this)  
   {
   impl = buffer.impl; 
   }
   return *this;
}

void SUI::FilteredRingBuffer::lock() const
{
   impl->lock();
}

void SUI::FilteredRingBuffer::unlock() const
{
   impl->unlock();
}

void SUI::FilteredRingBuffer::setSubsampleFactor(int value)
{
   impl->setSubsampleFactor(value);
}

int SUI::FilteredRingBuffer::subsampleFactor() const
{
   return impl->subsampleFactor();
}

SUI::PlotDataPoint SUI::FilteredRingBuffer::back() const
{
   return impl->back();
}

bool SUI::FilteredRingBuffer::empty() const
{
   return impl->empty();
}

void *SUI::FilteredRingBuffer::getImplementation()
{
    return impl;
}
