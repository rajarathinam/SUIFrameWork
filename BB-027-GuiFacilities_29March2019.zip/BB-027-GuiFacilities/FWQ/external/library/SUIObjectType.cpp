//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for ObjectType.
// !\description Class implementation file for ObjectType.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "FWQxCore/SUIObjectType.h"

namespace SUI {
using std::map;
using std::string;
using std::pair;

const map<ObjectType::Type,const string> ObjectType::objectTypeStringMap = {
    {ObjectType::None, "None"},
    {ObjectType::Button, "Button"},
    {ObjectType::Label, "Label"},
    {ObjectType::LineEdit, "LineEdit"},
    {ObjectType::CheckBox, "CheckBox"},
    {ObjectType::RadioButton, "RadioButton"},
    {ObjectType::GroupBox, "GroupBox"},
    {ObjectType::CheckGroupBox, "CheckGroupBox"},
    {ObjectType::TabWidget, "TabWidget"},
    {ObjectType::TabPage, "TabPage"},
    {ObjectType::ButtonBar, "ButtonBar"},
    {ObjectType::TableWidget, "TableWidget"},
    {ObjectType::TableWidgetItem, "TableWidgetItem"},
    {ObjectType::SpinBox, "SpinBox"},
    {ObjectType::DoubleSpinBox, "DoubleSpinBox"},
    {ObjectType::DropDown, "DropDown"},
    {ObjectType::LEDWidget, "LEDWidget"},
    {ObjectType::CheckMark, "CheckMark"},
    {ObjectType::ColorDrop, "ColorDrop"},
    {ObjectType::ColorCrossDrop, "ColorCrossDrop"},
    {ObjectType::TextArea, "TextArea"},
    {ObjectType::ProgressBar, "ProgressBar"},
    {ObjectType::GraphicsView, "GraphicsView"},
    {ObjectType::MessageBox, "MessageBox"},
    {ObjectType::PlotWidget, "PlotWidget"},
    {ObjectType::Splitter, "Splitter"},
    {ObjectType::FileDialog, "FileDialog"},
    {ObjectType::UserControl, "UserControl"},
    {ObjectType::ListView, "ListView"},
    {ObjectType::ControlWidget, "ControlWidget"},
    {ObjectType::StateWidget, "StateWidget"},
    {ObjectType::ScienceSpinBox, "ScienceSpinBox"},
    {ObjectType::QuestionMark, "QuestionMark"},
    {ObjectType::BusyIndicator, "BusyIndicator"},
    {ObjectType::ImageWidget, "ImageWidget"},
    {ObjectType::TreeView, "TreeView"},
    {ObjectType::TreeViewItem, "TreeViewItem"},
    {ObjectType::LineWidget, "LineWidget"},
    {ObjectType::SvgWidget, "SvgWidget"},
    {ObjectType::FormEditor, "FormEditor"},
    {ObjectType::WidgetPage, "WidgetPage"},
    {ObjectType::Dialog, "Dialog"},
    {ObjectType::Container, "Container"},
    {ObjectType::ScrollBar, "ScrollBar"},
    {ObjectType::DateTimeEdit, "DateTimeEdit"},
    {ObjectType::GraphicsPixmapItem, "GraphicsPixmapItem"},
    {ObjectType::GraphicsTextItem, "GraphicsTextItem"},
    {ObjectType::GraphicsRectItem, "GraphicsRectItem"},
    {ObjectType::GraphicsLineItem, "GraphicsLineItem"},
    {ObjectType::GraphicsEllipseItem, "GraphicsEllipseItem"},
    {ObjectType::GraphicsCrosshairItem, "GraphicsCrosshairItem"},
    {ObjectType::GraphicsSvgItem, "GraphicsSvgItem"},
    {ObjectType::PlotCurveItem, "PlotCurveItem"},
    {ObjectType::PlotHistogramItem, "PlotHistogramItem"},
    {ObjectType::WebView, "WebView"},
    {ObjectType::TreeWidget, "TreeWidget"}
};

const map<const string,ObjectType::Type> ObjectType::objectStringTypeMap =
        ObjectType::createObjectStringTypeMap();

const map<ObjectType::Type,const string> ObjectType::objectIdPrefixes = {
    {ObjectType::None, "?"},
    {ObjectType::Button, "btn"},
    {ObjectType::Label, "lbl"},
    {ObjectType::LineEdit, "lne"},
    {ObjectType::CheckBox, "cbx"},
    {ObjectType::RadioButton, "rbn"},
    {ObjectType::GroupBox, "gbx"},
    {ObjectType::CheckGroupBox, "cgb"},
    {ObjectType::TabWidget, "tbw"},
    {ObjectType::TabPage, "tbp"},
    {ObjectType::ButtonBar, "rbb"},
    {ObjectType::TableWidget, "taw"},
    {ObjectType::TableWidgetItem, "twi"},
    {ObjectType::SpinBox, "isb"},
    {ObjectType::DoubleSpinBox, "dsb"},
    {ObjectType::DropDown, "ddb"},
    {ObjectType::LEDWidget, "led"},
    {ObjectType::CheckMark, "cmk"},
    {ObjectType::ColorDrop, "cdb"},
    {ObjectType::ColorCrossDrop, "ccd"},
    {ObjectType::TextArea, "txa"},
    {ObjectType::ProgressBar, "pgb"},
    {ObjectType::GraphicsView, "imv"},
    {ObjectType::MessageBox, "msb"},
    {ObjectType::PlotWidget, "plw"},
    {ObjectType::Splitter, "spl"},
    {ObjectType::FileDialog, "fbr"},
    {ObjectType::GraphicsPixmapItem, "gip"},
    {ObjectType::GraphicsTextItem, "git"},
    {ObjectType::GraphicsRectItem, "gir"},
    {ObjectType::GraphicsLineItem, "gil"},
    {ObjectType::GraphicsEllipseItem, "gie"},
    {ObjectType::GraphicsCrosshairItem, "gic"},
    {ObjectType::GraphicsSvgItem, "gis"},
    {ObjectType::PlotCurveItem, "pic"},
    {ObjectType::PlotHistogramItem, "pih"},
    {ObjectType::UserControl, "uct"},
    {ObjectType::ListView, "lsv"},
    {ObjectType::ControlWidget, "ctr"},
    {ObjectType::StateWidget, "stt"},
    {ObjectType::ScienceSpinBox, "ssb"},
    {ObjectType::QuestionMark, "qmk"},
    {ObjectType::BusyIndicator, "bic"},
    {ObjectType::ImageWidget, "img"},
    {ObjectType::TreeView, "trv"},
    {ObjectType::TreeViewItem, "tri"},
    {ObjectType::LineWidget, "lnw"},
    {ObjectType::SvgWidget, "svg"},
    {ObjectType::FormEditor, "frm"},
    {ObjectType::WidgetPage, "wpg"},
    {ObjectType::Dialog, "dlg"},
    {ObjectType::Container, "cnt"},
    {ObjectType::ScrollBar, "scb"},
    {ObjectType::DateTimeEdit, "dte"},
    {ObjectType::WebView, "wvw"},
    {ObjectType::TreeWidget, "trw"}
};

string ObjectType::toString(const ObjectType::Type &type) {
    map<Type,const string>::const_iterator it = objectTypeStringMap.find(type);
    return it != objectTypeStringMap.end() ? it->second : "None";
}

ObjectType::Type ObjectType::fromString(const string &type) {
    map<string,Type>::const_iterator it = objectStringTypeMap.find(type);
    return it != objectStringTypeMap.end() ? it->second : ObjectType::None;
}

string ObjectType::getIdPrefix(const ObjectType::Type &type) {
    map<Type,const string>::const_iterator it = objectIdPrefixes.find(type);
    return it != objectIdPrefixes.end() ? it->second : "?";
}


const map<const string, ObjectType::Type> ObjectType::createObjectStringTypeMap() {
    map<const string, Type> newMap;
    for (map<Type,const string>::const_iterator it = objectTypeStringMap.begin(); it != objectTypeStringMap.end(); ++it) {
        newMap.insert(pair<const string, Type>(it->second,it->first));
    }
    return newMap;
}

}
