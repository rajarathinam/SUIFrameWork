//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for PlotCurveItem.
// !\description Class implementation file for PlotCurveItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "FWQxWidgets/SUIPlotCurveItem.h"
#include "SUIPlotWidgetImpl.h"
#include "FWQxCore/SUIObjectFactory.h"
#include "SUIRingBufferImpl.h"
#include <qwt_plot_curve.h>
#include <QPointF>

namespace {
/*!
   \brief Wrapper class to avoid ownership transfer of original pointer.
*/
   class PlotSeriesDataWrapper : public QwtSeriesData<QPointF> {
   public:
      PlotSeriesDataWrapper(QwtSeriesData<QPointF>* p)
      : m_p(p)
      {   
      }
      
      virtual ~PlotSeriesDataWrapper() {
         // make sure the original pointer is not destructed.
      }
      
      virtual size_t size() const 
      {
         return m_p->size();
      }

      virtual QPointF sample( size_t i ) const
      {
         return m_p->sample(i);
      }

      virtual QRectF boundingRect() const
      {
         return m_p->boundingRect();
      }
      
   private:
      QwtSeriesData<QPointF>* m_p;
   };
}

SUI::PlotCurveItem::PlotCurveItem(const std::string &setName, SUI::PlotAxisEnum::PlotAxis side) :
    PlotItem(
        SUI::ObjectType::PlotCurveItem, new QwtPlotCurve(QString::fromStdString(setName))
        ),
  mColor(SUI::ColorEnum::Black),
  mSymbolColor(SUI::ColorEnum::Standard),
  mSymbol(SUI::MarkerSymbolEnum::NoSymbol),
  mLineStyle(SUI::LineStyleEnum::Solid),
  mCurveStyle(SUI::CurveStyleEnum::Lines)
{
    static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->setYAxis(toQwtAxis(side));
}

SUI::PlotCurveItem::~PlotCurveItem() {
    delete static_cast<QwtPlotCurve*>(PlotItem::getImplementation());
    PlotItem::setImplementation(NULL);
}

void SUI::PlotCurveItem::attach(PlotWidget *plot) {
    if(plot != NULL){
        static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->attach(dynamic_cast<SUI::PlotWidgetImpl *>(plot)->getPlot());
    }
}

void SUI::PlotCurveItem::detach() {
    dataPoints.clear();
    static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->detach();
}

void SUI::PlotCurveItem::setTitle(const std::string &title) {
    static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->setTitle(QString::fromStdString(title));
}

std::string SUI::PlotCurveItem::getTitle() const {
    return static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->title().text().toStdString();
}

void SUI::PlotCurveItem::show() {
    static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->show();
}

void SUI::PlotCurveItem::hide() {
    static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->hide();
}

void SUI::PlotCurveItem::setVisible(bool visible) {
    static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->setVisible(visible);
}

bool SUI::PlotCurveItem::isVisible() const {
    return static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->isVisible();
}

void SUI::PlotCurveItem::setAxes(SUI::PlotAxisEnum::PlotAxis xAxis, SUI::PlotAxisEnum::PlotAxis yAxis) {
    static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->setAxes(toQwtAxis(xAxis), toQwtAxis(yAxis));
}

void SUI::PlotCurveItem::setXAxis(SUI::PlotAxisEnum::PlotAxis xAxis) {
    static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->setXAxis(toQwtAxis(xAxis));
}

SUI::PlotAxisEnum::PlotAxis SUI::PlotCurveItem::getXAxis() const {
    return toSuiAxisEnum(static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->xAxis());
}

void SUI::PlotCurveItem::setYAxis(SUI::PlotAxisEnum::PlotAxis axis) {
    static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->setYAxis(toQwtAxis(axis));
}

SUI::PlotAxisEnum::PlotAxis SUI::PlotCurveItem::getYAxis() const {
    return toSuiAxisEnum(static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->yAxis());
}

double SUI::PlotCurveItem::getZ() const {
    return static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->z();
}

void SUI::PlotCurveItem::setZ(double z) {
    static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->setZ(z);
}

void SUI::PlotCurveItem::clearSamples() {
    dataPoints.clear();
    static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->setSamples(0,0,0);
}

void SUI::PlotCurveItem::setColor(const SUI::ColorEnum::Color color) {
    if(mColor == color) return;
    if (ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color)) {
        mColor = color;
        // First retrieve the pen object, so we don't loose the gridline and width settings
        QPen pen = static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->pen();
        pen.setColor(QColor(QString::fromStdString(SUI::ColorEnum::toString(mColor))));
        static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->setPen(pen);
    }
}

SUI::ColorEnum::Color SUI::PlotCurveItem::getColor() const {
    return mColor;
}

void SUI::PlotCurveItem::setWidth(const int penWidth) {
    QPen pen = static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->pen();
    pen.setWidth(penWidth);
    static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->setPen(pen);
}

int SUI::PlotCurveItem::getWidth() const {
    return static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->pen().width();
}

void SUI::PlotCurveItem::setStyle(const SUI::LineStyleEnum::LineStyle linestyle) {
    if(mLineStyle == linestyle) return;
    mLineStyle = linestyle;
    QPen pen = static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->pen();
    pen.setStyle(static_cast<Qt::PenStyle>(mLineStyle));
    static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->setPen(pen);
}

void SUI::PlotCurveItem::setCurveStyle(const SUI::CurveStyleEnum::CurveStyle curveStyle) {
    if(mCurveStyle == curveStyle) return;
    mCurveStyle = curveStyle;
    static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->setStyle(static_cast<QwtPlotCurve::CurveStyle>(mCurveStyle));
}

SUI::LineStyleEnum::LineStyle SUI::PlotCurveItem::getStyle() const {
    return mLineStyle;
}

SUI::MarkerSymbolEnum::MarkerSymbol SUI::PlotCurveItem::getSymbol() const {
  return mSymbol;
}

SUI::ColorEnum::Color  SUI::PlotCurveItem::getSymbolColor() const {
  return mSymbolColor;
}

int  SUI::PlotCurveItem::getSymbolWidth() const {
  int width = 0;
  QwtPlotCurve *plotCurvePtr = static_cast<QwtPlotCurve*> (PlotItem::getImplementation());
  const QwtSymbol *qSymbol = plotCurvePtr->symbol();
  if(qSymbol != NULL)
  {
      width = qSymbol->size().width();
  }
  return width;
}

void SUI::PlotCurveItem::setPlotMarker(SUI::MarkerSymbolEnum::MarkerSymbol markerSymbol, SUI::ColorEnum::Color color, int width) {
    mSymbol = markerSymbol;
    mSymbolColor = color;

    QwtSymbol *symbol = new QwtSymbol();
    switch (markerSymbol)
    {
    case SUI::MarkerSymbolEnum::Ellipse: symbol->setStyle(QwtSymbol::Ellipse); break;
    case SUI::MarkerSymbolEnum::Rect: symbol->setStyle(QwtSymbol::Rect);break;
    case SUI::MarkerSymbolEnum::Diamond: symbol->setStyle(QwtSymbol::Diamond); break;
    case SUI::MarkerSymbolEnum::Triangle: symbol->setStyle(QwtSymbol::Triangle); break;
    case SUI::MarkerSymbolEnum::LTriangle: symbol->setStyle(QwtSymbol::LTriangle); break;
    case SUI::MarkerSymbolEnum::RTriangle: symbol->setStyle(QwtSymbol::RTriangle); break;
    case SUI::MarkerSymbolEnum::Cross: symbol->setStyle(QwtSymbol::Cross); break;
    case SUI::MarkerSymbolEnum::XCross: symbol->setStyle(QwtSymbol::XCross); break;
    case SUI::MarkerSymbolEnum::Star: symbol->setStyle(QwtSymbol::Star1); break;
    default: symbol->setStyle(QwtSymbol::NoSymbol); break;
    }
    symbol->setSize(width);
    symbol->setColor(QColor(QString::fromStdString(SUI::ColorEnum::toString(color))));

    static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->setSymbol(symbol);
    static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->setLegendAttribute(QwtPlotCurve::LegendShowSymbol);
    static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->setLegendAttribute(QwtPlotCurve::LegendShowLine);
}

void SUI::PlotCurveItem::setSamples(const std::vector<SUI::PlotDataPoint> &values) {
    for (uint i = 0; i < values.size(); i++)
    {
        dataPoints.push_back(values.at(i));
    }
    plotCurve();
}

void SUI::PlotCurveItem::setSample(const SUI::PlotDataPoint &value) {
    dataPoints.push_back(value);
    plotCurve();
}

void SUI::PlotCurveItem::setRawSamples(const double *xData, const double *yData, int size) {
    static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->setRawSamples(xData, yData, size);
}

void SUI::PlotCurveItem::plotCurve() {
    QVector<QPointF> samples(static_cast<int>(dataPoints.size()));
    for (uint i = 0; i < dataPoints.size(); i++)
    {
        samples[i] = QPointF(static_cast<SUI::PlotDataPoint> (dataPoints.at(i)).getX(),
                             static_cast<SUI::PlotDataPoint> (dataPoints.at(i)).getY());
    }
    static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->setSamples(samples);
}

void SUI::PlotCurveItem::setSamples(SUI::PlotDataSeries& buffer) {
   QwtSeriesData<QPointF>* impl = static_cast< QwtSeriesData<QPointF>* >(buffer.getImplementation());
   if (impl != NULL)
   {
      // set samples via PlotSeriesDataWrapper to avoid ownership transfer of buffer.
      PlotSeriesDataWrapper* samples = new PlotSeriesDataWrapper(impl);
      static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->setSamples(samples);
   }
}

void SUI::PlotCurveItem::setCustomPenColor( const SUI::PlotItemCustomColor color) {
    static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->setPen(
                QPen(QColor(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha())));
}

SUI::PlotItemCustomColor SUI::PlotCurveItem::getCustomPenColor() const {
    QPen pen = static_cast<QwtPlotCurve*>(PlotItem::getImplementation())->pen();
    return SUI::PlotItemCustomColor(pen.color().red(), pen.color().green(),
                                    pen.color().blue(), pen.color().alpha());
}
