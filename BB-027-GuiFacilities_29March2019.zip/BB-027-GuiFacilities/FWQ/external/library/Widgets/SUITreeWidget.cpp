//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for TreeWidget.
// !\description Class implementation file for TreeWidget.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2018, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "FWQxWidgets/SUITreeWidget.h"
#include "FWQxCore/SUIObjectFactory.h"

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
SUI::TreeWidget::TreeWidget() :
    Widget(SUI::ObjectType::TreeWidget)
{
}

SUI::TreeWidget::~TreeWidget()
{
}
