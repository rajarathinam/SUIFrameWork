//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::TreeWidget.
// !\description Header file for class SUI::TreeWidget.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2018, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|
#ifndef SUITREEWIDGET_H
#define SUITREEWIDGET_H
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "FWQxCore/SUISharedExport.h"
#include "FWQxWidgets/SUIWidget.h"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief The TreeWidget class
 */
class SUI_SHARED_EXPORT TreeWidget : public Widget
{
 public:
    virtual ~TreeWidget();

    /*!
     * \brief setRootIsDecorated
     * This enables/disbales the root decoration  of the TreeWidget
     * \param show - Enables/Disbales the root decoration  of the TreeWidget
     */
    virtual void setRootIsDecorated(const bool show) = 0;

    /*!
     * \brief rootIsDecorated
     * This return the root decoration  of the TreeWidget is enabled /disabled
     */
    virtual bool rootIsDecorated() const = 0;

    /*!
     * \brief setHeight
     * This sets the height of the TreeWidget
     * \param height - Height to be set to TreeWidget
     */
    virtual void setHeight(const int height) = 0;

    /*!
     * \brief getHeight
     * This gets the height of the TreeWidget
     */
    virtual int getHeight() const = 0;

    /*!
     * \brief setWidth
     * This sets the width of the TreeWidget
     * \param Width - Width to be set to TreeWidget
     */
    virtual void setWidth(const int width) = 0;

    /*!
     * \brief getWidth
     * This gets the width of the TreeWidget
     */
    virtual int getWidth() const = 0;

    /*!
     * \brief setHeaderVisible
     * This makes the TreeWidget header  to visible  / hidden
     * \param visible - bool flag to make header visible / hidden
     */
    virtual void setHeaderVisible(const bool visible) = 0;

    /*!
     * \brief isHeaderVisible
     * This return the visibility of TreeWidget header
     */
    virtual bool isHeaderVisible() const = 0;

    /*!
     * \brief setColumnCount
     * This sets the number of columns of the TreeWidget
     * \param columns - Number of columns of the TreeWidget
     */
    virtual void setColumnCount(const int columns) = 0;

    /*!
     * \brief getColumnCount
     * This returns the column count of TreeWidget
     */
    virtual int getColumnCount() const = 0;

    /*!
     * \brief addTopLevelItem
     * This adds the widget as TreeWidgetItem  to the TreeWidget
     * \param widget - Widget item  to be added
     */
    virtual void addTopLevelItem(SUI::Widget *widget) = 0;

    /*!
     * \brief addChildItem
     * This adds the widget as TreeWidgetItem  to the Parent TreeWidgetItem
     * \param parent - parent widget
     * \param child - child Widget item  to be added
     */
    virtual void addChildItem(SUI::Widget *parentWidget, SUI::Widget *childWidget) = 0;

    /*!
     * \brief appendTopLevelItem
     * This appends new toplevel item, of type as same as last toplevel item of TreeWidget
     * and returns newly added widget
     */
    virtual SUI::Widget *appendTopLevelItem() = 0;

    /*!
     * \brief appendChildItem
     * This appends new child to the parentWidget passed, of same type of last child widget
     * and returns newly added widget
     * \param parentWidget - The parent widget to which the child needs to be appended
     */
    virtual SUI::Widget *appendChildItem(SUI::Widget *parentWidget) = 0;

    /*!
     * \brief setExpand
     * This expands or collapses the item (TreeWidget item)
     * \param widgetItem - item to be expanded / collapsed
     */
    virtual void setExpanded(SUI::Widget *widgetItem, bool expand) = 0;

    /*!
     * \brief hasChildren
     * This return whether the item has  children  or not
     * \param widgetItem - item to be checked for children
     */
    virtual bool hasChildren(SUI::Widget *widgetItem) const = 0;

    /*!
     * \brief getSubWidgets
     * This return whether the item has  children  or not
     * \param widget - widget for which the children to be retrieved
     */
    virtual std::vector<std::pair<SUI::Widget* , SUI::ObjectType::Type> > getSubWidgets(SUI::Widget *widget) = 0;

 protected:
    TreeWidget();

 private:
    //  To disable copy constructor and Assignment Operator
    //  Ref: http://doc.qt.io/archives/qt-4.8/qobject.html#no-copy-constructor
    TreeWidget(const TreeWidget&);
    TreeWidget& operator= (const TreeWidget&);
};
}
#endif // SUITREEWIDGET_H
