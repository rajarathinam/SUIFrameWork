
//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::DateTimeEdit.
// !\description Header file for class SUI::DateTimeEdit.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUIDATETIMEEDIT_H
#define SUIDATETIMEEDIT_H

#include "FWQxCore/SUIIClickable.h"
#include "FWQxWidgets/SUIWidget.h"
#include "FWQxCore/SUIDateTimeEnum.h"
#include <boost/shared_ptr.hpp>

namespace SUI {
class Date;
class Time;
/*!
 * \ingroup FWQxWidgets
 *
 *
 * \brief The DateTimeEdit class
 */
class SUI_SHARED_EXPORT DateTimeEdit : public Widget, public IClickable
{
public:
    virtual ~DateTimeEdit();

    /*!
     * \brief setTime
     * Sets the time part of this datetime to time.
     * \param time
     */
    virtual void setTime(const boost::shared_ptr<SUI::Time> &time) = 0;

    /*!
     * \brief getTime
     * Returns the time part of the datetime.
     * \return
     */
    virtual boost::shared_ptr<Time> getTime() const = 0;

    /*!
     * \brief setTimeSpec
     * Sets the time specification used in this datetime to spec.
     * See DateTimeEnum::TimeSpec
     * \param spec
     */
    virtual void setTimeSpec(DateTimeEnum::TimeSpec spec) = 0;

    /*!
     * \brief getTimeSpec
     * Returns the time specification of the datetime.
     * \return
     */
    virtual DateTimeEnum::TimeSpec getTimeSpec() const = 0;

    /*!
     * \brief setDate
     * Sets the date part of this datetime to date. If no time is set, it is set to midnight.
     * \param date
     */
    virtual void setDate(const boost::shared_ptr<SUI::Date> &dt) = 0;

    /*!
     * \brief getDate
     * Extracts the current year, month and day and stores it in getYear, getMonth and getDay
     * \param getYear
     * \param getMonth
     * \param getDay
     */
    virtual void getDate(int * getYear, int * getMonth, int * getDay) = 0;

    /*!
     * \brief isValid
     * Returns true if both the date and the time are valid; otherwise returns false.
     * \return
     */
    virtual bool isValid() const = 0;


protected:
    DateTimeEdit();
};
}
#endif // SUIDATETIMEEDIT_H
