//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::TableWidget.
// !\description Header file for class SUI::TableWidget.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUITABLEWIDGET_H
#define SUITABLEWIDGET_H

#include "FWQxWidgets/SUIWidget.h"

#include "FWQxCore/SUIStringList.h"
#include "FWQxCore/SUIIFilterable.h"
#include "FWQxCore/SUISortOrderEnum.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief The TableWidget class
 */
class SUI_SHARED_EXPORT TableWidget : public Widget, public StringList, public IFilterable
{
public:
    virtual ~TableWidget();

    /*!
     * \brief setListViewMode
     * Sets the selection mode. on == true means that the complete row is selected if
     * a cell in that row is clicked. on == false means that a single cell is
     * selected if clicked
     * \param on
     */
    virtual void setListViewMode(bool on) = 0;

    /*!
     * \brief getColumnItems
     * Retrieves a string list of items of the given column of the widget
     * \param int columnno - The column (zero-based) to retrieve the items from
     * \return
     */
    virtual std::list<std::string> getColumnItems(int column) const = 0;

    /*!
     * \brief getRowItems
     * Retrieves a string list of items of the given row of the widget
     * \param row - the row number (zero based) to the retrieve the items from
     * \return
     */
    virtual std::list<std::string> getRowItems(int row) const = 0;

    /*!
     * \brief addData
     * Adds data (text) to the specified row number (zero based)
     * \param row - the row number (zero based) to add the data to. If row is larger than
     * the current number of rows, rows will be added to the table widget, until row count
     * equals row
     * \param data - a list of data elements that will be added
     */
    virtual void addData(int row, const std::list<std::string> &data) = 0;

    /*!
     * \brief appendRow
     * Adds a row to the end of the TableWidget and copies the widgets of
     * the row above to the newly created row.
     * \param headertag
     */
    virtual void appendRow(const std::string &headertag = std::string("")) = 0;

    /*!
     * \brief removeRow
     * Removes the row at index 'row'. If there's only one row left, the row cannot be removed.
     * If the postion 'row' does not exist, nothing happens
     * \param row - the (zero-based) row to be removed
     */
    virtual void removeRow(int row) = 0;

    /*!
     * \brief rowCount
     * Returns the current number of rows
     * \return
     */
    virtual int rowCount() const = 0;

    /*!
     * \brief columnCount
     * Returns the current column count
     * \return
     */
    virtual int columnCount() const = 0;

    /*!
     * \brief getCellID
     * Returns the cell id of the table cell at position (row, column). Returns an
     * empty string is the position is invalid
     * \param row - row number (zero based)
     * \param column - column number (zero based)
     * \return
     */
    virtual std::string getCellID(int row, int column) const = 0;

    /*!
     * \brief getCellType
     * Returns the widget type of the table cell at position (row, column). Returns 'None'
     * if the position is invalid
     * \param row - row number (zero based)
     * \param column - column number (zero based)
     * \return
     */
    virtual SUI::ObjectType::Type getCellType(int row, int column) const = 0;

    /*!
     * \brief insertRows
     * Inserts a number of rows at a specified position
     * \param pos : start inserting rows here (0 based)
     * \param count : number of rows to add
     */
    virtual void insertRows(int pos, int count) = 0;

    /*!
     * \brief removeRows
     * Removes a number of rows at a specified position
     * \param pos : start removing rows here (0 based)
     * \param count : number of rows to remove
     * \return true if the removal was succesful. False otherwise
     */
    virtual bool removeRows(int pos, int count) = 0;

    /*!
     * \brief insertColumns
     * Inserts a number of columns at a specified position
     * \param pos : start inserting columns here (0 based)
     * \param count : number of columns to add
     */
    virtual void insertColumns(int position, int count) = 0;

    /*!
     * \brief removeColumns
     * Removes a number of columns at a specified position
     * \param pos : start removing columns here (0 based)
     * \param count : number of columns to remove
     * \return true if the removal was succesful. False otherwise
     */
    virtual bool removeColumns(int position, int count) = 0;

    /*!
     * \brief getItemText
     * Returns the text of table cell with given row and column index
     * \param row : row of the cell (0 based)
     * \param column: column of the cell (0 based)
     * \return
     */
    virtual std::string getItemText(int row, int column) const = 0;

    /*!
     * \brief getWidgetItem
     * Returns the widget of the cell
     * \param row : row number of the cell (0 based)
     * \param column : column number of the cell (0 based)
     * \return Returns SUI::Widget*
     */
    virtual Widget *getWidgetItem(int row, int column) const = 0;

    /*!
     * \brief setItemText
     * Sets the text of table cell with given row and column index
     * \param row : row number of the cell (0 based)
     * \param column: column number of the cell (0 based)
     * \param text: text to be set
     */
    virtual void setItemText(int row, int column, const std::string &text) = 0;

    /*!
     * \brief getWidgetItemByName
     * Returns the widget of the cell with cellname 'name'
     * \param name : cell name of the widget to be returned
     * \return Returns NULL if no widget can be found with the given name
     */
    virtual Widget *getWidgetItemByName(const std::string &name) const = 0;

    /*!
     * \brief setWidgetItemName
     * Sets the cell name of a table cell with given row and column number
     * \param row : row number of the cell (0 based)
     * \param column : column number of the cell (0 based)
     * \param name : cell name to be set
     */
    virtual void setWidgetItemName(int row, int column, const std::string &name) = 0;

    /*!
     * \brief swapRows
     * Swaps two rows in a table. Both rows need to be available
     * \param row1 : row number of first row to be swapped
     * \param row2 : row number of second row to be swapped
     * \NOTE: This is not implemented yet
     */
    virtual void swapRows(int row1, int row2) = 0;

    /*!
     * \brief showGrid
     * sets the Table grid to be dislayed (bShow == true) or not
     * \param bShow :True to display grid and false to hide
     */
    virtual void showGrid(const bool bShow) = 0;

    /*!
     * \brief setRowVisible
     * sets the row to be visible or not
     * \param row : row number
     * \param visible : If visible is true, row will be visible else hidden
     */
    virtual void setRowVisible(int row, bool visible) = 0;

    /*!
     * \brief isRowVisible
     * Returns whether the row is visible or not
     * \param row : row number
     * \return : bool
     */
    virtual bool isRowVisible(int row) = 0;

    /*!
     * \brief setColumnVisible
     * sets the coloumn to be visible or not
     * \param coloumn : coloumn number
     * \param visible : If visible is true, coloumn will be visible else hidden
     */
    virtual void setColumnVisible(int coloumn, bool visible) = 0;

    /*!
     * \brief isColumnVisible
     * Returns whether the column is visible or not
     * \param coloumn : coloumn number
     * \return : bool
     */
    virtual bool isColumnVisible(int coloumn) = 0;

    /*!
     * \brief getSelectedRows
     * Returns a vector of row numbers that have been selected by the user. The
     * order of the row numbers is the same as the order in which the selection was done.
     * Works for both ListView and non-ListView.
     * Remark: if the user selects cells in non-ListView and he/she requests
     * the row numbers of a column that has no (cell)selection, the result will be
     * an empty list.
     * \param column: specify the column number that needs to be inspected
     * \return
     */
    virtual std::vector<int> getSelectedRows(const int column = 0) const = 0;

    /*!
      * \brief sort
      * Sorts the rows in table.
      * Remark: Accepts column index for which sorting should be done. If column index is incorrect, or the specified sort order is Unsorted then function will return.
      * \param column: specify the column number that needs to be sorted
      * \return
      */
     virtual void sortItems(const int columnIndex, const SUI::SortOrderEnum::SortOrder order) = 0;

    /*!
     * \brief setCellWidgetType
     * Sets the given widget on the cell of TableWidget
     * \param row : row number of the cell (0 based)
     * \param column : column number of the cell (0 based)
     * \param widget : SUI::Widget to be placed on the cell
     */
     virtual void setCellWidgetType(int row, int column, Widget *widget) = 0;

    /*!
     * \brief setScrollBarEnable
     * Sets the enable state of  scrollBar of TableWidget
     * \param enable : true - Enable ScrollBar, false - Disable ScrollBar
     */
    virtual void setScrollBarEnable(bool enable) = 0;

    /*!
     * \brief isScrollBarEnabled
     * Returns the enable state of  scrollBar of TableWidget
     * \return : bool
     */
    virtual bool isScrollBarEnabled() const = 0;

    /*!
     * \brief setScrollBarVisible
     * Sets the visibility state of  scrollBar of TableWidget
     * \param enable : true - ScrollBar Visible, false - ScrollBar InVisible
     */
    virtual void setScrollBarVisible(bool visible) = 0;

    /*!
     * \brief isScrollBarVisible
     * Returns the visible state of  scrollBar of TableWidget
     * \return : bool
     */
    virtual bool isScrollBarVisible() const = 0;

    /*!
     * \brief cellClicked
     * Callback function that is called when a cell has been clicked
     * It returns the row/column number and the widget that is inside that cell
     */
    boost::function<void(int,int,Widget*)> cellClicked;

    /*!
     * \brief horizontalHeaderCellClicked
     * Callback function that is called when a horizontal header cell is clicked.
     * It returns the row/column number and the cell text
     */
    boost::function<void(int,int,std::string)> horizontalHeaderCellClicked;

    /*!
     * \brief verticalHeaderCellClicked
     * Callback function that is called when a vertical header cell is clicked.
     * It returns the row/column number and the cell text
     */
    boost::function<void(int,int,std::string)> verticalHeaderCellClicked;

    /*!
     * \brief rowClicked
     * Callback function that is called when a tablewidget cell is clicked.
     * It returns the row number
     */
    boost::function<void(int)> rowClicked;

protected:
    TableWidget();
};
}

#endif // SUITABLEWIDGET_H
