//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::MarkerSymbolEnum.
// !\description Header file for class SUI::MarkerSymbolEnum.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIMARKERSYMBOLENUM_H
#define SUIMARKERSYMBOLENUM_H

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief This enum type is used to describe marker styles
 */
class MarkerSymbolEnum
{
public:
    /*!
     * \brief MarkerSymbol
     * This enumerated type is used to specify marker symbol
     */
    typedef enum
    {
        NoSymbol,
        Ellipse,
        Rect,
        Diamond,
        Triangle,
        LTriangle,
        RTriangle,
        Cross,
        XCross,
        Star,
    } MarkerSymbol;
};
}
#endif // SUIMARKERSYMBOLENUM_H
