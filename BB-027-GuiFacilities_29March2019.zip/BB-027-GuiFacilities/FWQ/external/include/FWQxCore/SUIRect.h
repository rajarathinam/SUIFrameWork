//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::Rect.
// !\description Header file for class SUI::Rect.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUIRECT_H
#define SUIRECT_H
namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief The Rect class
 */
class Rect
{
public:
    Rect(const int x1, const int y1, const int width, const int height);

    /*!
     * \brief getX
     * Returns the X coordinate of the Rect
     * \return int
     */
    int getX() const

    /*!
     * \brief setX
     * Set the x coordinate of the Rect
     * \param int
     */;
    void setX(int value);

    /*!
     * \brief getY
     * Returns the Y coordinate of the Rect
     * \return int
     */
    int getY() const;

    /*!
     * \brief setY
     * Set the y coordinate of the Rect
     * \param int
     */
    void setY(int value);

    /*!
     * \brief getWidth
     * Returns the width of the Rect
     * \return int
     */
    int getWidth() const;

    /*!
     * \brief setWidth
     * Set the width of the Rect
     * \param int
     */
    void setWidth(int value);

    /*!
     * \brief getHeight()
     * Returns the height of the Rect
     * \return int
     */
    int getHeight() const;
    /*!
     * \brief setHeight();
     * Set the height of the Rect
     * \param int
     */
    void setHeight(int value);

    bool operator==(const Rect &rect) const;
private:
    int x;
    int y;
    int w;
    int h;
};
}
#endif // SUIRECT_H
