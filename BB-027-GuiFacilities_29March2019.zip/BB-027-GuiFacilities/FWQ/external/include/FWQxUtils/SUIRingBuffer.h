//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::RingBuffer.
// !\description Header file for class SUI::RingBuffer.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIRINGBUFFER_H
#define SUIRINGBUFFER_H

#include <FWQxCore/SUISharedExport.h>
#include <FWQxWidgets/SUIPlotDataPoint.h>
#include <FWQxCore/SUIRect.h>
#include <boost/function.hpp>
#include <boost/shared_ptr.hpp>
#include <vector>

namespace SUI {


class PlotDataSeries
{
public:  

   PlotDataSeries() {}
   virtual ~PlotDataSeries() {}
   
   virtual PlotDataPoint back() const = 0;

   virtual void *getImplementation() = 0;
};

/*!
 * \ingroup FWQxUtils
 *
 * \brief The RingBuffer class
 */
class SUI_SHARED_EXPORT RingBuffer : public PlotDataSeries
{

public:
    explicit RingBuffer(const int size);
    virtual ~RingBuffer();
    
    /*!
    * \brief lock
    * Ring buffer is reentrant data structure. Lock prevents from other thread to insert samples in RingleBuffer.
    * \note Call this method if it is multithreaded application.
    */
    virtual void lock() const;

    /*!
    * \brief unlock
    * Ring buffer is reentrant data structure. Unlock releases buffer from current thread so other thread can insert sample in RingleBuffer.
    * \note Call this method if it is multithreaded application.
    */
    virtual void unlock() const;

    /*!
    * \brief setSample
    * Set and add datapoint to the ring buffer.
    * \param values - SUI::PlotDataPoint
    * \note Call to replot on Plot widget is required to see the changes
    */
    virtual void setSample(const SUI::PlotDataPoint& data);

    /*!
    * \brief setSamples
    * Set and add data with an array of PlotDataPoint samples to the ring buffer.
    * This function sets and adds a collection of data points to the curve.
    * \param values - std::vector<SUI::PlotDataPoint>
    * \note Call to replot on Plot widget is required to see the changes
    */
    virtual void setSamples(const std::vector<SUI::PlotDataPoint> &values);

    /*!
    * \brief setRawSamples
    * This function sets a collection of data points to the curve.
    * No deep copy is created, so the plot data needs to be kept alive
    * \param xData   - The X point array.
    * \param yData   - The Y point array.
    * \param size    - size of xData and YData.
    * \note Call to replot on Plot widget is required to see the changes
    */
    virtual void setRawSamples(const double *xData, const double *yData, int size);

    /*!
    * \brief clearSamples
    *  Clear data samples plotted
    * \note Call to replot on Plot widget is required to see the changes
    */
    virtual void clearSamples();

    /*!
    * \brief back
    *  Get the last element.
    * \note buffer must not be empty
    */
    virtual PlotDataPoint back() const;

    /*!
    * \brief getImplementation
    * It returns implementation.
    */
    virtual void *getImplementation();

private:
    void *impl;

};
} // namespace SUI

#endif // SUI_SUIRINGBUFFER_H
