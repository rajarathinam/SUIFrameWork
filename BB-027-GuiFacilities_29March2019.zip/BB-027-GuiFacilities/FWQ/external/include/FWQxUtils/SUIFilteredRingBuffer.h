//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::RingBuffer.
// !\description Header file for class SUI::RingBuffer.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIFILTEREDRINGBUFFER_H
#define SUIFILTEREDRINGBUFFER_H

#include "FWQxCore/SUISharedExport.h"
#include "FWQxUtils/SUIRingBuffer.h"
namespace SUI {

/*!
 * \ingroup FWQxUtils
 *
 * \brief The RingBuffer class
 */
class RingBuffer;
class FilteredRingBufferImpl;
class SUI_SHARED_EXPORT FilteredRingBuffer : public PlotDataSeries
{

public:
    explicit FilteredRingBuffer(RingBuffer& ringBuffer);
    FilteredRingBuffer(const FilteredRingBuffer& );
    FilteredRingBuffer& operator =(const FilteredRingBuffer&);
    virtual ~FilteredRingBuffer();
    
    /*!
    * \brief lock
    * Ring buffer is reentrant data structure. Lock prevents from other thread to insert samples in RingleBuffer.
    * \note Call this method if it is multithreaded application.
    */
    virtual void lock() const;

    /*!
    * \brief unlock
    * Ring buffer is reentrant data structure. Unlock releases buffer from current thread so other thread can insert sample in RingleBuffer.
    * \note Call this method if it is multithreaded application.
    */
    virtual void unlock() const;
    
    /*!
    * \brief setSubsampleFactor
    * Set the factor for supsampling the data
    * \param value - new factor 
    */
    virtual void setSubsampleFactor(int value); 

    /*!
     * \brief subsampleFactor
     * Get the factor for supsampling the data 
     */
     virtual int subsampleFactor() const;
        
    /*!
    * \brief back
    *  Get the last element.
    * \note buffer must not be empty
    */
    virtual PlotDataPoint back() const;
    
    /*!
    * \brief empty
    *  Is the FilteredRingBuffer empty?
    * \note true if there are no elements stored in the FilteredRingBuffer; false otherwise.
    */
    virtual bool empty() const;
    
    /*!
    * \brief getImplementation
    * It returns implementation.
    */
    virtual void *getImplementation();

private:
    FilteredRingBufferImpl *impl;

};
} // namespace SUI

#endif // SUIFILTEREDRINGBUFFER_H
