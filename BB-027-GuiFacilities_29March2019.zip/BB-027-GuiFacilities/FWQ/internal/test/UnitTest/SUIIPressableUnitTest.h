#ifndef SUIIPRESSABLEUNITTEST_H
#define SUIIPRESSABLEUNITTEST_H

namespace SUI {

class IPressable;

class IPressableUnitTest
{
public:
    explicit IPressableUnitTest(IPressable *object);

    void pressable();
    void onPress();

private:
    IPressable *obj;

};

}

#endif // SUIIPRESSABLEUNITTEST_H
