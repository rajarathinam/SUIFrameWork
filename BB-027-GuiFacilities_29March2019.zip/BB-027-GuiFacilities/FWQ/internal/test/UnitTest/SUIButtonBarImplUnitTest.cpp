
#include "SUIButtonBarImplUnitTest.h"
#include "SUIButtonBarImpl.h"
#include "SUIBaseObject.h"

SUI::ButtonBarImplUnitTest::ButtonBarImplUnitTest(SUI::ButtonBarImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::ButtonBarImplUnitTest::~ButtonBarImplUnitTest()
{
   delete object;
}

void SUI::ButtonBarImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
