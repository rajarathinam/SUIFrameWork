#ifndef GRAPHICSLINEITEMUNITTEST_H
#define GRAPHICSLINEITEMUNITTEST_H

#include "SUIGraphicsItemUnitTest.h"

namespace SUI {

class GraphicsLineItem;

class GraphicsLineItemUnitTest : public GraphicsItemUnitTest
{
   Q_OBJECT
public:
    explicit GraphicsLineItemUnitTest(GraphicsLineItem *object, QObject *parent = 0);
    virtual ~GraphicsLineItemUnitTest();

private slots:
    void setColorRed();
    void setPenColorRed();
    //TODO add all colors
    void setPenWidth();
    void setP1();
    void setP2();
    void setSize();
    void penColorChanged();

    void setLineStyle();
private:
    void onPenColorChanged();

private:
    GraphicsLineItem *object;
};

}
#endif // GRAPHICSLINEITEMUNITTEST_H
