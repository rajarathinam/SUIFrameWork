
#include "SUIWidgetPageImplUnitTest.h"
#include "SUIWidgetPageImpl.h"
#include "SUIBaseObject.h"

SUI::WidgetPageImplUnitTest::WidgetPageImplUnitTest(SUI::WidgetPageImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::WidgetPageImplUnitTest::~WidgetPageImplUnitTest()
{
   delete object;
}

void SUI::WidgetPageImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
