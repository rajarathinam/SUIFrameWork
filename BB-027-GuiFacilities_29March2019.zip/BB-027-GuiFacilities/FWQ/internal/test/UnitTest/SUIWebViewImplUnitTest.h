
#ifndef SUIWEBVIEWIMPLUNITTEST_H
#define SUIWEBVIEWIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class WebViewImpl;

class WebViewImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit WebViewImplUnitTest(WebViewImpl *object, QObject *parent = 0);
    virtual ~WebViewImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    WebViewImpl *object;
};

}
#endif // SUIWEBVIEWIMPLUNITTEST_H
