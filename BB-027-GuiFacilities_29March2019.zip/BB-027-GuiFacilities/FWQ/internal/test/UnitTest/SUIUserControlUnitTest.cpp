#include "SUIUserControlUnitTest.h"
#include "SUIIClickableUnitTest.h"
#include "SUIIPressableUnitTest.h"
#include <FWQxCore/SUIObjectFactory.h>
#include <SUIBaseWidget.h>
#include <QTest>

SUI::UserControlUnitTest::UserControlUnitTest(SUI::UserControl *object, QObject *parent) :
    WidgetUnitTest(object, parent),
    object(object)
{
}

SUI::UserControlUnitTest::~UserControlUnitTest()
{
    delete object;
}

void SUI::UserControlUnitTest::callInterfaceTests() {
    BaseWidget *baseWidget = dynamic_cast<BaseWidget*>(SUI::ObjectFactory::getInstance()->toBaseObject(this->object));
    //IClickable tests
    IClickableUnitTest iClickable(object);
    iClickable.clickable();
    QTest::mouseClick(baseWidget->getWidget(),Qt::LeftButton);

    //IPressable tests
    IPressableUnitTest iPressable(object);
    iPressable.pressable();
    QTest::mousePress(baseWidget->getWidget(),Qt::LeftButton);
}
