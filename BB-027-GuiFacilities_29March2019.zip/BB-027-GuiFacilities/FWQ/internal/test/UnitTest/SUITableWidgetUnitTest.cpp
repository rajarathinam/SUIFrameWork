#include "SUITableWidgetUnitTest.h"

#include <FWQxCore/SUIObjectFactory.h>
#include <FWQxCore/SUIObjectType.h>

#include <FWQxWidgets/SUITableWidget.h>

#include <FWQxWidgets/SUIBusyIndicator.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUICheckBox.h>
#include <FWQxWidgets/SUILabel.h>
#include <FWQxWidgets/SUILineEdit.h>
#include <FWQxWidgets/SUIProgressBar.h>
#include <FWQxWidgets/SUISpinBox.h>
#include <FWQxWidgets/SUIStateWidget.h>
#include <FWQxWidgets/SUITextArea.h>
#include <FWQxWidgets/SUIScrollBar.h>
#include <FWQxWidgets/SUIWebView.h>
#include <FWQxWidgets/SUIRadioButton.h>
#include <FWQxWidgets/SUIColorDrop.h>
#include <FWQxWidgets/SUIDropDown.h>

#include <boost/bind.hpp>
#include <QTableView>
#include <QTest>
#include "SUIITextUnitTest.h"
#include "SUIBaseWidget.h"

SUI::TableWidgetUnitTest::TableWidgetUnitTest(SUI::TableWidget *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    mRow(-1),
    object(object)
{
}

SUI::TableWidgetUnitTest::~TableWidgetUnitTest() {
    delete object;
}

void SUI::TableWidgetUnitTest::callInterfaceTests() {
    // TODO test StringList
    // TODO test IFilter
    std::list<std::string> data;
    data.push_back("rowdata");
    object->insertRows(0, 1);
    object->addData(0, data);
    QCOMPARE(static_cast<int>(object->getRowItems(0).size()), 1);
    object->clearItems();
    QCOMPARE(static_cast<int>(object->getRowItems(0).size()), 0);
}

void SUI::TableWidgetUnitTest::addRow() {
    object->insertRows(0,1);
    int count = object->rowCount();
    object->appendRow();
    QCOMPARE(object->rowCount(),count+1);
}

void SUI::TableWidgetUnitTest::testSetCellWidgetTypeAndAppendRow() {
    QFETCH(QString, ObjectType);
    SUI::ObjectType::Type oType = SUI::ObjectType::fromString(ObjectType.toStdString());

    int count = object->rowCount();
    int column = 0;
    SUI::Widget *widget = NULL;
    if(oType == SUI::ObjectType::BusyIndicator) {
        widget = SUI::ObjectFactory::getInstance()->createWidget_<BusyIndicator>(NULL);
    }else if (oType == SUI::ObjectType::Button) {
        widget = SUI::ObjectFactory::getInstance()->createWidget_<Button>(NULL);
    }else if (oType == SUI::ObjectType::CheckBox) {
        widget = SUI::ObjectFactory::getInstance()->createWidget_<CheckBox>(NULL);
    }else if (oType == SUI::ObjectType::Label) {
        widget = SUI::ObjectFactory::getInstance()->createWidget_<Label>(NULL);
    }else if (oType == SUI::ObjectType::LineEdit) {
        widget = SUI::ObjectFactory::getInstance()->createWidget_<LineEdit>(NULL);
    }else if (oType == SUI::ObjectType::ProgressBar) {
        widget = SUI::ObjectFactory::getInstance()->createWidget_<ProgressBar>(NULL);
    }else if (oType == SUI::ObjectType::SpinBox) {
        widget = SUI::ObjectFactory::getInstance()->createWidget_<SpinBox>(NULL);
    }else if (oType == SUI::ObjectType::StateWidget) {
        widget = SUI::ObjectFactory::getInstance()->createWidget_<StateWidget>(NULL);
    }else if (oType == SUI::ObjectType::TextArea) {
        widget = SUI::ObjectFactory::getInstance()->createWidget_<TextArea>(NULL);
    }else if (oType == SUI::ObjectType::ScrollBar) {
        widget = SUI::ObjectFactory::getInstance()->createWidget_<ScrollBar>(NULL);
    }else if (oType == SUI::ObjectType::WebView) {
        widget = SUI::ObjectFactory::getInstance()->createWidget_<WebView>(NULL);
    }else if (oType == SUI::ObjectType::RadioButton) {
        widget = SUI::ObjectFactory::getInstance()->createWidget_<RadioButton>(NULL);
    }else if (oType == SUI::ObjectType::ColorDrop) {
        widget = SUI::ObjectFactory::getInstance()->createWidget_<ColorDrop>(NULL);
    }else if (oType == SUI::ObjectType::DropDown) {
        widget = SUI::ObjectFactory::getInstance()->createWidget_<DropDown>(NULL);
    }
    object->setCellWidgetType(count-1, column, widget);
    SUI::Widget *setWidget = object->getWidgetItem(count-1, column);
    Q_ASSERT(setWidget!= NULL);
    QCOMPARE(ObjectType, QString::fromStdString(SUI::ObjectType::toString(setWidget->getObjectType())));

    object->appendRow();
    QCOMPARE(object->rowCount(),count+1);
    setWidget = object->getWidgetItem(count, column);
    QCOMPARE(ObjectType, QString::fromStdString(SUI::ObjectType::toString(setWidget->getObjectType())));
}

void SUI::TableWidgetUnitTest::testSetCellWidgetTypeAndAppendRow_data() {
    QTest::addColumn<QString>("ObjectType");
    QTest::newRow("objectType1") << QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::BusyIndicator));
    QTest::newRow("objectType2") << QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::Button));
    QTest::newRow("objectType3") << QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::CheckBox));
    QTest::newRow("objectType4") << QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::Label));
    QTest::newRow("objectType5") << QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::DropDown));
    QTest::newRow("objectType6") << QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::LineEdit));
    QTest::newRow("objectType7") << QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::ProgressBar));
    QTest::newRow("objectType8") << QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::SpinBox));
    QTest::newRow("objectType9") << QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::StateWidget));
    QTest::newRow("objectType10") << QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::TextArea));
    QTest::newRow("objectType11") << QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::ScrollBar));
    QTest::newRow("objectType12") << QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::WebView));
    QTest::newRow("objectType13") << QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::RadioButton));
    QTest::newRow("objectType14") << QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::ColorDrop));
}

void SUI::TableWidgetUnitTest::testSpecificTest_AppendRow() {
    int count = object->rowCount();
    object->removeRows(1,count -1);

    //set Button widget
    SUI::Widget *widget = SUI::ObjectFactory::getInstance()->createWidget_<Button>(NULL);
    object->setCellWidgetType(0, 0, widget);

    SUI::Button * button = static_cast<SUI::Button*>(object->getWidgetItem(0, 0));
    ITextUnitTest iTextUnitTest(button);
    QVERIFY(iTextUnitTest.setText());

    object->appendRow();
    button = static_cast<SUI::Button*>(object->getWidgetItem(1, 0));
    //verify appendRow is accessbile
    ITextUnitTest appendRow1(button);
    QVERIFY(appendRow1.setText());

    object->appendRow();
    button = static_cast<SUI::Button*>(object->getWidgetItem(2, 0));
    //verify appendRow is accessbile
    ITextUnitTest appendRow2(button);
    QVERIFY(appendRow2.setText());

    object->appendRow();
    button = static_cast<SUI::Button*>(object->getWidgetItem(3, 0));
    //verify appendRow is accessbile
    ITextUnitTest appendRow3(button);
    QVERIFY(appendRow3.setText());

    object->appendRow();
    button = static_cast<SUI::Button*>(object->getWidgetItem(4, 0));
    //verify appendRow is accessbile
    ITextUnitTest appendRow4(button);
    QVERIFY(appendRow4.setText());

}

void SUI::TableWidgetUnitTest::insertRow() {
    int count = object->rowCount();
    object->insertRows(0,1);
    QCOMPARE(object->rowCount(),count+1);
}

void SUI::TableWidgetUnitTest::removeRow() {
    object->appendRow();
    int count = object->rowCount();
    object->removeRow(object->rowCount() -1);
    QCOMPARE(object->rowCount(),count-1);
}

void SUI::TableWidgetUnitTest::insertColumn() {
    int count = object->columnCount();
    object->insertColumns(0,1);
    QCOMPARE(object->columnCount(),count+1);
}

void SUI::TableWidgetUnitTest::removeColumn() {
    object->insertColumns(0,1);
    int count = object->columnCount();
    object->removeColumns(0,1);
    QCOMPARE(object->columnCount(),count-1);
}

void SUI::TableWidgetUnitTest::insertRows() {
    int count = object->rowCount();
    object->insertRows(0,3);
    QCOMPARE(object->rowCount(),count+3);
}

void SUI::TableWidgetUnitTest::removeRows() {
    object->insertRows(0,3);
    int count = object->rowCount();
    object->removeRows(0,3);
    QCOMPARE(object->rowCount(),count-3);
}

void SUI::TableWidgetUnitTest::insertColumns() {
    int count = object->columnCount();
    object->insertColumns(0,3);
    QCOMPARE(object->columnCount(),count+3);
}

void SUI::TableWidgetUnitTest::removeColumns() {
    object->insertColumns(0,3);
    int count = object->columnCount();
    object->removeColumns(0,3);
    QCOMPARE(object->columnCount(),count-3);
}

void SUI::TableWidgetUnitTest::setItemText() {
    std::string text1 = "text1";
    std::string text2 = "text2";
    object->insertRows(0,1);
    object->insertColumns(0,1);
    object->setItemText(0,0,text1);
    object->setItemText(0,1,text2);
    QCOMPARE(object->getItemText(0,0),text1);
    QCOMPARE(object->getItemText(0,1),text2);
}

void SUI::TableWidgetUnitTest::rowClicked() {
    QVERIFY(object->rowClicked.empty());

    object->rowClicked = boost::bind(&SUI::TableWidgetUnitTest::onRowClicked, this, _1);
    QVERIFY(!object->rowClicked.empty());
}

void SUI::TableWidgetUnitTest::setRowVisible() {
    int count = object->rowCount();
    object->setRowVisible(count -1, true);
    QCOMPARE(object->isRowVisible(count-1), true);
    object->setRowVisible(count -1, false);
    QCOMPARE(object->isRowVisible(count-1), false);

}

void SUI::TableWidgetUnitTest::setColumnVisible() {
    int count = object->columnCount();
    object->setColumnVisible(count -1, true);
    QCOMPARE(object->isColumnVisible(count-1), true);
    object->setColumnVisible(count -1, false);
    QCOMPARE(object->isColumnVisible(count-1), false);
}

void SUI::TableWidgetUnitTest::getWidgetItem() {
    for(int row =0; row < object->rowCount(); row ++){
        for(int col = 0; col < object->columnCount(); col++){
            Widget *widget = object->getWidgetItem(row,col);
            QCOMPARE(widget->getId(), object->getCellID(row,col));
            //WidgetUnitTest(widget, NULL);
        }
    }
}

void SUI::TableWidgetUnitTest::testSetListViewMode() {
   SUI::BaseWidget *widget = dynamic_cast<SUI::BaseWidget *>(object);
   if(widget != NULL) {
       QTableView *tableView = qobject_cast<QTableView *>(widget->getWidget());
       if(tableView != NULL){
           //usecase 1
           widget->setPropertyValue(SUI::ObjectPropertyTypeEnum::MultipleRowSelection, "true");
           QAbstractItemView::SelectionMode selectionMode = tableView->selectionMode();
           QAbstractItemView::SelectionBehavior selectionBehaviour = tableView->selectionBehavior();
           object->setListViewMode(true);
           QCOMPARE(QAbstractItemView::SelectRows, tableView->selectionBehavior());
           QCOMPARE(QAbstractItemView::ExtendedSelection, tableView->selectionMode());

           //usecase 2
           object->setListViewMode(false);
           QCOMPARE(selectionBehaviour, tableView->selectionBehavior());
           QCOMPARE(selectionMode, tableView->selectionMode());

           //usecase 3
           widget->setPropertyValue(SUI::ObjectPropertyTypeEnum::MultipleRowSelection, "false");
           object->setListViewMode(true);
           QCOMPARE(QAbstractItemView::SelectRows, tableView->selectionBehavior());
           QCOMPARE(QAbstractItemView::SingleSelection, tableView->selectionMode());
       }
   }
}

void SUI::TableWidgetUnitTest::testColumnFilter() {
    int count = object->columnCount();
    object->insertColumns(0,1);
    QCOMPARE(object->columnCount(),count+1);
    //TODO need to check the filter set
    object->setFilter(std::string("filter"), true);
    object->setFilter(std::string("filter"), true, 0);
}

void SUI::TableWidgetUnitTest::onRowClicked(int row) {
    mRow = row;
}
