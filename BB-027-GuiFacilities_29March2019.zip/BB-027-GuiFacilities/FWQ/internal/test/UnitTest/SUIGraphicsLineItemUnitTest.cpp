#include "SUIGraphicsLineItemUnitTest.h"

#include <QTest>

#include <boost/bind.hpp>

#include <FWQxGraphicsItems/SUIGraphicsLineItem.h>

SUI::GraphicsLineItemUnitTest::GraphicsLineItemUnitTest(SUI::GraphicsLineItem *object, QObject *parent) :
    GraphicsItemUnitTest(object,parent),
    object(object)
{
}

SUI::GraphicsLineItemUnitTest::~GraphicsLineItemUnitTest()
{
}

void SUI::GraphicsLineItemUnitTest::setColorRed() {
    object->setPenColor(SUI::ColorEnum::Red);
    QCOMPARE(object->getPenColor(),SUI::ColorEnum::Red);
}

void SUI::GraphicsLineItemUnitTest::setPenColorRed() {
    object->setPenColor(SUI::ColorEnum::Red);
    QCOMPARE(object->getPenColor(),SUI::ColorEnum::Red);
}

void SUI::GraphicsLineItemUnitTest::setPenWidth() {
    object->setPenWidth(10);
    QCOMPARE(object->getPenWidth(),5);
}

void SUI::GraphicsLineItemUnitTest::setP1() {
    object->setP1(10,10);
//    QCOMPARE(object->getP1(),10); //FIXME add 'SUI::Point getP1() const' to SUI::GraphicsLine
    QVERIFY(true);
}

void SUI::GraphicsLineItemUnitTest::setP2() {
    object->setP2(10,10);
//    QCOMPARE(object->getP2(),10); //FIXME add 'SUI::Point getP2() const' to SUI::GraphicsLine
    QVERIFY(true);
}

void SUI::GraphicsLineItemUnitTest::setSize() {

}

void SUI::GraphicsLineItemUnitTest::penColorChanged() {
    object->setPenColor(SUI::ColorEnum::Black);
    object->penColorChanged = boost::bind(&GraphicsLineItemUnitTest::onPenColorChanged,this);
    object->setPenColor(SUI::ColorEnum::Blue);
}

void SUI::GraphicsLineItemUnitTest::setLineStyle()
{
   object->setLineStyle(SUI::LineStyleEnum::NoLine);
   QCOMPARE(object->getLineStyle(), SUI::LineStyleEnum::NoLine);

   object->setLineStyle(SUI::LineStyleEnum::Solid);
   QCOMPARE(object->getLineStyle(), SUI::LineStyleEnum::Solid);

   object->setLineStyle(SUI::LineStyleEnum::Dash);
   QCOMPARE(object->getLineStyle(), SUI::LineStyleEnum::Dash);

   object->setLineStyle(SUI::LineStyleEnum::Dot);
   QCOMPARE(object->getLineStyle(), SUI::LineStyleEnum::Dot);

   object->setLineStyle(SUI::LineStyleEnum::DashDot);
   QCOMPARE(object->getLineStyle(), SUI::LineStyleEnum::DashDot);

   object->setLineStyle(SUI::LineStyleEnum::DashDotLine);
   QCOMPARE(object->getLineStyle(), SUI::LineStyleEnum::DashDotLine);
}

void SUI::GraphicsLineItemUnitTest::onPenColorChanged() {
    QVERIFY(true);
}
