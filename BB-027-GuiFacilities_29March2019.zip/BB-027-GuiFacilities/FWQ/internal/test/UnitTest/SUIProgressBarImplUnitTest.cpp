
#include "SUIProgressBarImplUnitTest.h"
#include "SUIProgressBarImpl.h"
#include "SUIBaseObject.h"

SUI::ProgressBarImplUnitTest::ProgressBarImplUnitTest(SUI::ProgressBarImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::ProgressBarImplUnitTest::~ProgressBarImplUnitTest()
{
   delete object;
}

void SUI::ProgressBarImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::EditorForm);
}
