
#include "SUIFileDialogImplUnitTest.h"
#include "SUIFileDialogImpl.h"
#include "SUIBaseObject.h"

SUI::FileDialogImplUnitTest::FileDialogImplUnitTest(SUI::FileDialogImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::FileDialogImplUnitTest::~FileDialogImplUnitTest()
{
   delete object;
}

void SUI::FileDialogImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
