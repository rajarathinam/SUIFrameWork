
#include "SUITabPageImplUnitTest.h"
#include "SUITabPageImpl.h"
#include "SUIBaseObject.h"

SUI::TabPageImplUnitTest::TabPageImplUnitTest(SUI::TabPageImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::TabPageImplUnitTest::~TabPageImplUnitTest()
{
   delete object;
}

void SUI::TabPageImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::EditorForm);
    object->setDefaultProperties(SUI::BaseObject::EditorSelector);
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
