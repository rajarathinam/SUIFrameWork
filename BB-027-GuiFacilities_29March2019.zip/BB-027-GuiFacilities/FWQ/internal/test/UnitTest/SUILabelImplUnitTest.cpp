
#include "SUILabelImplUnitTest.h"
#include "SUILabelImpl.h"
#include "SUIBaseObject.h"

SUI::LabelImplUnitTest::LabelImplUnitTest(SUI::LabelImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::LabelImplUnitTest::~LabelImplUnitTest()
{
   delete object;
}

void SUI::LabelImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::EditorForm);
    object->setDefaultProperties(SUI::BaseObject::EditorSelector);
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
