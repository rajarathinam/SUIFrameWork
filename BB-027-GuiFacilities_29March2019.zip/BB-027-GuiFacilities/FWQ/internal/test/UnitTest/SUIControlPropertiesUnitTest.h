
#ifndef SUICONTROLPROPERTIESUNITTEST_H
#define SUICONTROLPROPERTIESUNITTEST_H

#include <QTest>
namespace SUI {

class ControlProperties;

class ControlPropertiesUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit ControlPropertiesUnitTest(ControlProperties *object, QObject *parent = 0);
    virtual ~ControlPropertiesUnitTest();

public slots:
    void setDefaultProperties();

private:
    ControlProperties *object;
};

}
#endif // SUICONTROLPROPERTIESUNITTEST_H
