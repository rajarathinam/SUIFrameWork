
#ifndef SUILINEWIDGETIMPLUNITTEST_H
#define SUILINEWIDGETIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class LineWidgetImpl;

class LineWidgetImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit LineWidgetImplUnitTest(LineWidgetImpl *object, QObject *parent = 0);
    virtual ~LineWidgetImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    LineWidgetImpl *object;
};

}
#endif // SUILINEWIDGETIMPLUNITTEST_H
