
#ifndef SUICONTROLWIDGETIMPLUNITTEST_H
#define SUICONTROLWIDGETIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class ControlWidgetImpl;

class ControlWidgetImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit ControlWidgetImplUnitTest(ControlWidgetImpl *object, QObject *parent = 0);
    virtual ~ControlWidgetImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    ControlWidgetImpl *object;
};

}
#endif // SUICONTROLWIDGETIMPLUNITTEST_H
