
#include "SUIControlPropertiesUnitTest.h"
#include "SUIControlProperties.h"
#include "SUIBaseObject.h"

SUI::ControlPropertiesUnitTest::ControlPropertiesUnitTest(SUI::ControlProperties *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::ControlPropertiesUnitTest::~ControlPropertiesUnitTest()
{
   delete object;
}

void SUI::ControlPropertiesUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
