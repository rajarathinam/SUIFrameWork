#include "SUIPlotWidgetUnitTest.h"
#include  <FWQxWidgets/SUIPlotWidget.h>
#include  <FWQxWidgets/SUIPlotHistogramItem.h>
#include  <FWQxWidgets/SUIPlotCurveItem.h>
#include <QTest>
#include "SUIITextUnitTest.h"
#include "SUIIClickableUnitTest.h"
#include "SUIIBGColorableUnitTest.h"
#include "SUIIColorableUnitTest.h"
#include <array>

SUI::PlotWidgetUnitTest::PlotWidgetUnitTest(SUI::PlotWidget *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    plotwidget(object)
{

}

SUI::PlotWidgetUnitTest::~PlotWidgetUnitTest() {
    delete plotwidget;
}

void SUI::PlotWidgetUnitTest::callInterfaceTests() {
    // IText UnitTests
    ITextUnitTest iTextUnitTest(plotwidget);
    QVERIFY(iTextUnitTest.setText());
    QVERIFY(iTextUnitTest.clearText());
    QVERIFY(iTextUnitTest.setBold());

    //IClickable tests
    IClickableUnitTest iClickable(plotwidget);
    iClickable.clickable();

    //IBGColorable tests
    IBGColorableUnitTest iBGColorableUnitTest(plotwidget);
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Standard));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Black));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Green));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Red));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Gray));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Blue));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::White));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Yellow));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Orange));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Transparent));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Orange));

    //IColorable tests
    IColorableUnitTest iColorableUnitTest(plotwidget);
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Standard));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Black));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Green));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Red));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Gray));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Blue));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::White));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Yellow));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Orange));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Transparent));
}

void SUI::PlotWidgetUnitTest::axisTests() {
    // Enable & disable yLeft axis
    plotwidget->setAxisVisible(SUI::PlotAxisEnum::PlotAxis::yLeft, true);
    QVERIFY(plotwidget->getAxisVisible(SUI::PlotAxisEnum::PlotAxis::yLeft));
    plotwidget->setAxisVisible(SUI::PlotAxisEnum::PlotAxis::yLeft, false);
    QVERIFY(!plotwidget->getAxisVisible(SUI::PlotAxisEnum::PlotAxis::yLeft));

    // Enable & disable yRight axis
    plotwidget->setAxisVisible(SUI::PlotAxisEnum::PlotAxis::yRight, true);
    QVERIFY(plotwidget->getAxisVisible(SUI::PlotAxisEnum::PlotAxis::yRight));
    plotwidget->setAxisVisible(SUI::PlotAxisEnum::PlotAxis::yRight, false);
    QVERIFY(!plotwidget->getAxisVisible(SUI::PlotAxisEnum::PlotAxis::yRight));

    // Enable & disable xBottom axis
    plotwidget->setAxisVisible(SUI::PlotAxisEnum::PlotAxis::xBottom, true);
    QVERIFY(plotwidget->getAxisVisible(SUI::PlotAxisEnum::PlotAxis::xBottom));
    plotwidget->setAxisVisible(SUI::PlotAxisEnum::PlotAxis::xBottom, false);
    QVERIFY(!plotwidget->getAxisVisible(SUI::PlotAxisEnum::PlotAxis::xBottom));

    // Enable & disable xTop axis
    plotwidget->setAxisVisible(SUI::PlotAxisEnum::PlotAxis::xTop, true);
    QVERIFY(plotwidget->getAxisVisible(SUI::PlotAxisEnum::PlotAxis::xTop));
    plotwidget->setAxisVisible(SUI::PlotAxisEnum::PlotAxis::xTop, false);
    QVERIFY(!plotwidget->getAxisVisible(SUI::PlotAxisEnum::PlotAxis::xTop));

    // Axis label angles
    std::array<double, 11> angles {{ 0.0, 60.0, 120.0, 180.0, 240.0, 300.0, -60.0, -120.0, -180.0, -240.0, -300.0}};
    for(uint angleId = 0; angleId < angles.size(); angleId++) {
        for (int enumInt = SUI::PlotAxisEnum::xBottom; enumInt <= SUI::PlotAxisEnum::yRight; enumInt++) {
            plotwidget->setLabelRotation((SUI::PlotAxisEnum::PlotAxis)enumInt, angles[angleId]);
            QCOMPARE(plotwidget->getLabelRotation(static_cast<SUI::PlotAxisEnum::PlotAxis>(enumInt)), angles[angleId]);
        }
    }

    // Set Axis scales and stepsizes
    plotwidget->setAxisVisible(SUI::PlotAxisEnum::xBottom, true);
    plotwidget->setAxisVisible(SUI::PlotAxisEnum::yLeft, true);
    plotwidget->setAxisVisible(SUI::PlotAxisEnum::yRight, true);
    plotwidget->setAxisVisible(SUI::PlotAxisEnum::xTop, true);

    plotwidget->setAxisScale(SUI::PlotAxisEnum::xTop, -300.0, 3000.0, false, 50.0);
    plotwidget->setXScale(100.0, 10000.0, 800.0);
    plotwidget->setYLeftScale(-2000.0, +2000.0, 2.0);
    plotwidget->setYRightScale(-100.0, 100.0, 0.1);

    //Check if PlotWidget replots
    QCOMPARE(plotwidget->getAxisMinValue(SUI::PlotAxisEnum::xBottom), 0.0);
    QCOMPARE(plotwidget->getAxisMinValue(SUI::PlotAxisEnum::xTop), 0.0);
    QCOMPARE(plotwidget->getAxisMinValue(SUI::PlotAxisEnum::yLeft), 0.0);
    QCOMPARE(plotwidget->getAxisMinValue(SUI::PlotAxisEnum::yRight), 0.0);

    plotwidget->setAxisScale(SUI::PlotAxisEnum::xTop, -300.0, 3000.0, true, 50.0);

    // Check X-Axis bottom scale and stepsize
    QCOMPARE(plotwidget->getAxisMinValue(SUI::PlotAxisEnum::xBottom), 100.0);
    QCOMPARE(plotwidget->getAxisMaxValue(SUI::PlotAxisEnum::xBottom), 10000.0);
    QCOMPARE(plotwidget->getAxisStepSize(SUI::PlotAxisEnum::xBottom), 800.0);

    // Check X-Axis bottom scale and stepsize
    QCOMPARE(plotwidget->getAxisMinValue(SUI::PlotAxisEnum::xTop), -300.0);
    QCOMPARE(plotwidget->getAxisMaxValue(SUI::PlotAxisEnum::xTop), 3000.0);
    QCOMPARE(plotwidget->getAxisStepSize(SUI::PlotAxisEnum::xTop), 50.0);

    // Check Y-Axis left scale and stepsize
    QCOMPARE(plotwidget->getAxisMinValue(SUI::PlotAxisEnum::yLeft), -2000.0);
    QCOMPARE(plotwidget->getAxisMaxValue(SUI::PlotAxisEnum::yLeft), 2000.0);
    QCOMPARE(plotwidget->getAxisStepSize(SUI::PlotAxisEnum::yLeft), 2.0);

    // Check Y-Axis right scale and stepsize
    QCOMPARE(plotwidget->getAxisMinValue(SUI::PlotAxisEnum::yRight), -100.0);
    QCOMPARE(plotwidget->getAxisMaxValue(SUI::PlotAxisEnum::yRight), 100.0);
    QCOMPARE(plotwidget->getAxisStepSize(SUI::PlotAxisEnum::yRight), 0.1);
}

void SUI::PlotWidgetUnitTest::gridTests() {
    // Y-Axis Off, Normal, Detail
    plotwidget->setYGrid(GridStyleEnum::Off);
    QCOMPARE(plotwidget->getYGrid(), GridStyleEnum::Off);
    plotwidget->setYGrid(GridStyleEnum::Normal);
    QCOMPARE(plotwidget->getYGrid(), GridStyleEnum::Normal);
    plotwidget->setYGrid(GridStyleEnum::Detail);
    QCOMPARE(plotwidget->getYGrid(), GridStyleEnum::Detail);

    // X-Axis  Off, Normal, Detail
    plotwidget->setXGrid(GridStyleEnum::Off);
    QCOMPARE(plotwidget->getXGrid(), GridStyleEnum::Off);
    plotwidget->setXGrid(GridStyleEnum::Normal);
    QCOMPARE(plotwidget->getXGrid(), GridStyleEnum::Normal);
    plotwidget->setXGrid(GridStyleEnum::Detail);
    QCOMPARE(plotwidget->getXGrid(), GridStyleEnum::Detail);

    //grid color
    plotwidget->setGridColor(SUI::ColorEnum::Blue);
    QCOMPARE(plotwidget->getGridColor(), SUI::ColorEnum::Blue);
    plotwidget->setGridColor(SUI::ColorEnum::Red);
    QCOMPARE(plotwidget->getGridColor(), SUI::ColorEnum::Red);
    plotwidget->setGridColor(SUI::ColorEnum::Green);
    QCOMPARE(plotwidget->getGridColor(), SUI::ColorEnum::Green);
    plotwidget->setGridColor(SUI::ColorEnum::Orange);
    QCOMPARE(plotwidget->getGridColor(), SUI::ColorEnum::Orange);
    plotwidget->setGridColor(SUI::ColorEnum::Gray);
    QCOMPARE(plotwidget->getGridColor(), SUI::ColorEnum::Gray);
    plotwidget->setGridColor(SUI::ColorEnum::Yellow);
    QCOMPARE(plotwidget->getGridColor(), SUI::ColorEnum::Yellow);
    plotwidget->setGridColor(SUI::ColorEnum::Black);
    QCOMPARE(plotwidget->getGridColor(), SUI::ColorEnum::Black);
    plotwidget->setGridColor(SUI::ColorEnum::White);
    QCOMPARE(plotwidget->getGridColor(), SUI::ColorEnum::White);

    //grid major penstyle
    plotwidget->setGridMajorStyle(SUI::LineStyleEnum::Dash);
    QCOMPARE(plotwidget->getGridMajorStyle(), SUI::LineStyleEnum::Dash);
    // Verify that the style is not lost when setting another color
    plotwidget->setGridColor(SUI::ColorEnum::Blue);
    QCOMPARE(plotwidget->getGridMajorStyle(), SUI::LineStyleEnum::Dash);
    plotwidget->setGridMajorStyle(SUI::LineStyleEnum::Dot);
    QCOMPARE(plotwidget->getGridMajorStyle(), SUI::LineStyleEnum::Dot);
    //grid Minor penstyle
    plotwidget->setGridMinorStyle(SUI::LineStyleEnum::Dash);
    QCOMPARE(plotwidget->getGridMinorStyle(), SUI::LineStyleEnum::Dash);
    plotwidget->setGridColor(SUI::ColorEnum::Green);
    QCOMPARE(plotwidget->getGridMinorStyle(), SUI::LineStyleEnum::Dash);
    plotwidget->setGridMinorStyle(SUI::LineStyleEnum::Dot);
    QCOMPARE(plotwidget->getGridMinorStyle(), SUI::LineStyleEnum::Dot);
}

void SUI::PlotWidgetUnitTest::customColors() {
    SUI::PlotHistogramItem *histogram = new SUI::PlotHistogramItem("Histogram");
    histogram->attach(plotwidget);
    SUI::PlotCurveItem *curve = new SUI::PlotCurveItem("Curve", SUI::PlotAxisEnum::yLeft);
    curve->attach(plotwidget);

    curve->setStyle(SUI::LineStyleEnum::DashDotLine);
    QCOMPARE(curve->getStyle(), SUI::LineStyleEnum::DashDotLine);
    curve->setWidth(10);
    QCOMPARE(curve->getWidth(), 10);
    curve->setColor(SUI::ColorEnum::Blue);
    QCOMPARE(curve->getColor(), SUI::ColorEnum::Blue);
    // Check that linestyle and width are not changed when setting the color
    QCOMPARE(curve->getStyle(), SUI::LineStyleEnum::DashDotLine);
    QCOMPARE(curve->getWidth(), 10);
    curve->setColor(SUI::ColorEnum::Red);
    QCOMPARE(curve->getColor(), SUI::ColorEnum::Red);
    curve->setColor(SUI::ColorEnum::Green);
    QCOMPARE(curve->getColor(), SUI::ColorEnum::Green);
    curve->setColor(SUI::ColorEnum::Orange);
    QCOMPARE(curve->getColor(), SUI::ColorEnum::Orange);
    curve->setColor(SUI::ColorEnum::Gray);
    QCOMPARE(curve->getColor(), SUI::ColorEnum::Gray);
    curve->setColor(SUI::ColorEnum::Yellow);
    QCOMPARE(curve->getColor(), SUI::ColorEnum::Yellow);
    curve->setColor(SUI::ColorEnum::Black);
    QCOMPARE(curve->getColor(), SUI::ColorEnum::Black);
    curve->setColor(SUI::ColorEnum::White);
    QCOMPARE(curve->getColor(), SUI::ColorEnum::White);

    SUI::PlotItemCustomColor penColor(124,126,128,10);
    SUI::PlotItemCustomColor brushColor(224,226,228,110);
    histogram->setCustomBrushColor(brushColor);
    histogram->setCustomPenColor(penColor);
    QCOMPARE(histogram->getCustomBrushColor(), brushColor);
    QCOMPARE(histogram->getCustomPenColor(), penColor);
    penColor.setRed(0);
    penColor.setGreen(125);
    penColor.setBlue(255);
    penColor.setAlpha(0);
    curve->setCustomPenColor(penColor);
    QCOMPARE(curve->getCustomPenColor(), penColor);

    curve->detach();
    histogram->detach();
    delete curve;
    delete histogram;
}

void SUI::PlotWidgetUnitTest::mouseCursor() {
   plotwidget->setMouseCursor(SUI::CursorShapeEnum::CrossCursor);
   QCOMPARE(plotwidget->getMouseCursor(), SUI::CursorShapeEnum::CrossCursor);
   plotwidget->setMouseCursor(SUI::CursorShapeEnum::ArrowCursor);
   QCOMPARE(plotwidget->getMouseCursor(), SUI::CursorShapeEnum::ArrowCursor);
   plotwidget->setMouseCursor(SUI::CursorShapeEnum::BusyCursor);
   QCOMPARE(plotwidget->getMouseCursor(), SUI::CursorShapeEnum::BusyCursor);
}

void SUI::PlotWidgetUnitTest::setFontSize() {
    QFETCH(QString, fontSize);
    //setFontSize - xBottom
    plotwidget->setAxisFontSize(SUI::PlotAxisEnum::xBottom, SUI::FontSizeEnum::fromString(fontSize.toStdString()));
    if(SUI::FontSizeEnum::Uninitialized == SUI::FontSizeEnum::fromString(fontSize.toStdString())) {
        QCOMPARE(plotwidget->getFontSize(SUI::PlotAxisEnum::xBottom),SUI::FontSizeEnum::Small);
    } else {
        QCOMPARE(plotwidget->getFontSize(SUI::PlotAxisEnum::xBottom),SUI::FontSizeEnum::fromString(fontSize.toStdString()));
    }

    //setFontSize - xTop
    plotwidget->setAxisFontSize(SUI::PlotAxisEnum::xTop, SUI::FontSizeEnum::fromString(fontSize.toStdString()));
    if(SUI::FontSizeEnum::Uninitialized == SUI::FontSizeEnum::fromString(fontSize.toStdString())) {
        QCOMPARE(plotwidget->getFontSize(SUI::PlotAxisEnum::xTop),SUI::FontSizeEnum::Small);
    } else {
        QCOMPARE(plotwidget->getFontSize(SUI::PlotAxisEnum::xTop),SUI::FontSizeEnum::fromString(fontSize.toStdString()));
    }

    //setFontSize - yLeft
    plotwidget->setAxisFontSize(SUI::PlotAxisEnum::yLeft, SUI::FontSizeEnum::fromString(fontSize.toStdString()));
    if(SUI::FontSizeEnum::Uninitialized == SUI::FontSizeEnum::fromString(fontSize.toStdString())) {
        QCOMPARE(plotwidget->getFontSize(SUI::PlotAxisEnum::yLeft),SUI::FontSizeEnum::Small);
    } else {
        QCOMPARE(plotwidget->getFontSize(SUI::PlotAxisEnum::yLeft),SUI::FontSizeEnum::fromString(fontSize.toStdString()));
    }

    //setFontSize - yRight
    plotwidget->setAxisFontSize(SUI::PlotAxisEnum::yRight, SUI::FontSizeEnum::fromString(fontSize.toStdString()));
    if(SUI::FontSizeEnum::Uninitialized == SUI::FontSizeEnum::fromString(fontSize.toStdString())) {
        QCOMPARE(plotwidget->getFontSize(SUI::PlotAxisEnum::yRight),SUI::FontSizeEnum::Small);
    } else {
        QCOMPARE(plotwidget->getFontSize(SUI::PlotAxisEnum::yRight),SUI::FontSizeEnum::fromString(fontSize.toStdString()));
    };
}

void SUI::PlotWidgetUnitTest::setFontSize_data() {
    QTest::addColumn<QString>("fontSize");
    QTest::newRow("change1") << QString::fromStdString(SUI::FontSizeEnum::toString(FontSizeEnum::Normal));
    QTest::newRow("change2") << QString::fromStdString(SUI::FontSizeEnum::toString(FontSizeEnum::Big));
    QTest::newRow("change3") << QString::fromStdString(SUI::FontSizeEnum::toString(FontSizeEnum::Small));
    QTest::newRow("change4") << QString::fromStdString(SUI::FontSizeEnum::toString(FontSizeEnum::Uninitialized));

}

void SUI::PlotWidgetUnitTest::setAxisAutoScale() {
    QFETCH(bool, testbool);
    plotwidget->setAxisAutoScale(SUI::PlotAxisEnum::xBottom, testbool);
    QCOMPARE(plotwidget->getAxisAutoScale(SUI::PlotAxisEnum::xBottom), testbool);
    plotwidget->setAxisAutoScale(SUI::PlotAxisEnum::xTop, testbool);
    QCOMPARE(plotwidget->getAxisAutoScale(SUI::PlotAxisEnum::xTop), testbool);
    plotwidget->setAxisAutoScale(SUI::PlotAxisEnum::yLeft, testbool);
    QCOMPARE(plotwidget->getAxisAutoScale(SUI::PlotAxisEnum::yLeft), testbool);
    plotwidget->setAxisAutoScale(SUI::PlotAxisEnum::yRight, testbool);
    QCOMPARE( plotwidget->getAxisAutoScale(SUI::PlotAxisEnum::yRight), testbool);
}

void SUI::PlotWidgetUnitTest::setAxisAutoScale_data() {
    QTest::addColumn<bool>("testbool");
    QTest::newRow("change1") << true;
    QTest::newRow("change1") << false;
}

void SUI::PlotWidgetUnitTest::setLegendEnabled() {
    plotwidget->setLegendEnabled(false, PlotLegendPositionEnum::Right);
    QCOMPARE(plotwidget->getLegendEnabled(), false);
    plotwidget->setLegendEnabled(true, PlotLegendPositionEnum::Right);
    QCOMPARE(plotwidget->getLegendEnabled(), true);
}

void SUI::PlotWidgetUnitTest::setLegendPosition() {
    plotwidget->setLegendEnabled(true, PlotLegendPositionEnum::Right);
    QCOMPARE(plotwidget->getLegendPosition(), PlotLegendPositionEnum::Right);
    plotwidget->setLegendEnabled(true, PlotLegendPositionEnum::Left);
    QCOMPARE(plotwidget->getLegendPosition(), PlotLegendPositionEnum::Left);
    plotwidget->setLegendEnabled(true, PlotLegendPositionEnum::Top);
    QCOMPARE(plotwidget->getLegendPosition(), PlotLegendPositionEnum::Top);
    plotwidget->setLegendEnabled(true, PlotLegendPositionEnum::Bottom);
    QCOMPARE(plotwidget->getLegendPosition(), PlotLegendPositionEnum::Bottom);
    plotwidget->setLegendEnabled(false, PlotLegendPositionEnum::Left);
    QCOMPARE(plotwidget->getLegendPosition(), PlotLegendPositionEnum::Right);
}

void SUI::PlotWidgetUnitTest::plotItemTests() {
    QFETCH(QString, id);
    QFETCH(QString, title);
    QFETCH(bool, enable);
    QFETCH(bool, visible);

    //PlotCurve tests
    SUI::PlotCurveItem *curve = new SUI::PlotCurveItem("Curve", SUI::PlotAxisEnum::yLeft);
    curve->attach(plotwidget);
    curve->setId(id.toStdString());
    curve->setTitle(title.toStdString());
    curve->setVisible(visible);
    curve->setEnabled(enable);
    QCOMPARE(curve->getId(),id.toStdString());
    QCOMPARE(curve->getTitle(),title.toStdString());
    QCOMPARE(curve->isEnabled(),enable);
    QCOMPARE(curve->isVisible(),visible);
    curve->show();
    QCOMPARE(curve->isVisible(),true);
    curve->hide();
    QCOMPARE(curve->isVisible(),false);
    curve->setAxes(PlotAxisEnum::PlotAxis::xBottom,PlotAxisEnum::PlotAxis::yLeft);
    QCOMPARE(curve->getXAxis(), PlotAxisEnum::PlotAxis::xBottom);
    QCOMPARE(curve->getYAxis(), PlotAxisEnum::PlotAxis::yLeft);
    curve->setXAxis(PlotAxisEnum::PlotAxis::xTop);
    QCOMPARE(curve->getXAxis(), PlotAxisEnum::PlotAxis::xTop);
    curve->setYAxis(PlotAxisEnum::PlotAxis::yRight);
    QCOMPARE(curve->getYAxis(), PlotAxisEnum::PlotAxis::yRight);
    curve->detach();
    delete curve;

    //PlotHistogram tests
    SUI::PlotHistogramItem *histogram = new SUI::PlotHistogramItem("Histogram");
    histogram->attach(plotwidget);
    histogram->setId(id.toStdString());
    histogram->setTitle(title.toStdString());
    histogram->setVisible(visible);
    histogram->setEnabled(enable);
    QCOMPARE(histogram->getId(),id.toStdString());
    QCOMPARE(histogram->getTitle(),title.toStdString());
    QCOMPARE(histogram->isEnabled(),enable);
    QCOMPARE(histogram->isVisible(),visible);
    histogram->show();
    QCOMPARE(histogram->isVisible(),true);
    histogram->hide();
    QCOMPARE(histogram->isVisible(),false);
    histogram->setAxes(PlotAxisEnum::PlotAxis::xBottom,PlotAxisEnum::PlotAxis::yLeft);
    QCOMPARE(histogram->getXAxis(), PlotAxisEnum::PlotAxis::xBottom);
    QCOMPARE(histogram->getYAxis(), PlotAxisEnum::PlotAxis::yLeft);
    histogram->setXAxis(PlotAxisEnum::PlotAxis::xTop);
    QCOMPARE(histogram->getXAxis(), PlotAxisEnum::PlotAxis::xTop);
    histogram->setYAxis(PlotAxisEnum::PlotAxis::yRight);
    QCOMPARE(histogram->getYAxis(), PlotAxisEnum::PlotAxis::yRight);
    histogram->detach();
    delete histogram;
}

void SUI::PlotWidgetUnitTest::plotItemTests_data() {
    QTest::addColumn<QString>("id");
    QTest::addColumn<QString>("title");
    QTest::addColumn<bool>("enable");
    QTest::addColumn<bool>("visible");
    QTest::newRow("data1") << QString("itemID") << QString("itemTitle") << true << true;
    QTest::newRow("data2") << QString("itemID1") << QString("itemTitle1") << false << false;
}
