
#ifndef SUIPROGRESSBARIMPLUNITTEST_H
#define SUIPROGRESSBARIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class ProgressBarImpl;

class ProgressBarImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit ProgressBarImplUnitTest(ProgressBarImpl *object, QObject *parent = 0);
    virtual ~ProgressBarImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    ProgressBarImpl *object;
};

}
#endif // SUIPROGRESSBARIMPLUNITTEST_H
