#ifndef SUIPLOTWIDGETUNITTEST_H
#define SUIPLOTWIDGETUNITTEST_H

#include "SUIWidgetUnitTest.h"

namespace SUI {

class PlotWidget;

class PlotWidgetUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    explicit PlotWidgetUnitTest(PlotWidget *object, QObject *parent = 0);
    virtual ~PlotWidgetUnitTest();

protected:
    void callInterfaceTests();

private slots:
    void axisTests();
    void gridTests();
    void customColors();
    void mouseCursor();
    void setFontSize();
    void setFontSize_data();
    void setAxisAutoScale();
    void setAxisAutoScale_data();
    void setLegendEnabled();
    void setLegendPosition();

    void plotItemTests();
    void plotItemTests_data();

private:
    PlotWidget *plotwidget;
};

}

#endif // SUIPLOTWIDGETUNITTEST_H
