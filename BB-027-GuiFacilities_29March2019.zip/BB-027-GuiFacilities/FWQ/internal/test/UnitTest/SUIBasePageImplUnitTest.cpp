
#include "SUIBasePageImplUnitTest.h"
#include "SUIBasePageImpl.h"
#include "SUIBaseObject.h"

SUI::BasePageImplUnitTest::BasePageImplUnitTest(SUI::BasePageImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::BasePageImplUnitTest::~BasePageImplUnitTest()
{
   delete object;
}

void SUI::BasePageImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::Gui);
}

void SUI::BasePageImplUnitTest::checkProperties() {
    //readonly
    QCOMPARE(object->isPropertyReadonly(SUI::ObjectPropertyTypeEnum::XPos), true);
    QCOMPARE(object->isPropertyReadonly(SUI::ObjectPropertyTypeEnum::YPos), true);
    QCOMPARE(object->isPropertyReadonly(SUI::ObjectPropertyTypeEnum::Height), true);
    QCOMPARE(object->isPropertyReadonly(SUI::ObjectPropertyTypeEnum::Width), true);
    QCOMPARE(object->isPropertyReadonly(SUI::ObjectPropertyTypeEnum::Enable), true);

    //specific
    QCOMPARE(object->getPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable).toLower(), QString("false"));
    QCOMPARE(object->getPropertyValue(SUI::ObjectPropertyTypeEnum::Sizeable).toLower(), QString("false"));

}
