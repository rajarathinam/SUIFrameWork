
#include "SUICheckMarkImplUnitTest.h"
#include "SUICheckMarkImpl.h"
#include "SUIBaseObject.h"

SUI::CheckMarkImplUnitTest::CheckMarkImplUnitTest(SUI::CheckMarkImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::CheckMarkImplUnitTest::~CheckMarkImplUnitTest()
{
   delete object;
}

void SUI::CheckMarkImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
