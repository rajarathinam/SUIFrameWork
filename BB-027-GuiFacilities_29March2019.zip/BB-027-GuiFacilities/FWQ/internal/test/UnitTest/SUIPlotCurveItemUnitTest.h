#ifndef SUIPLOTCURVEITEMUNITTEST_H
#define SUIPLOTCURVEITEMUNITTEST_H
#include <FWQxWidgets/SUIPlotCurveItem.h>
#include <QTest>

namespace SUI {

class PlotCurveItem;

class PlotCurveItemUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit PlotCurveItemUnitTest(PlotCurveItem *object, QObject *parent = 0);
    virtual ~PlotCurveItemUnitTest();

private slots:
    void setDefaultProperties();

private:
    PlotCurveItem *object;
};
}

#endif // SUIPLOTCURVEITEMUNITTEST_H
