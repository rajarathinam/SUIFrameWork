#include "SUIFileDialogUnitTest.h"
#include "SUIIClickableUnitTest.h"
#include <FWQxWidgets/SUICheckBox.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxCore/SUIObjectFactory.h>
#include <QTest>

SUI::FileDialogUnitTest::FileDialogUnitTest(SUI::FileDialog *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::FileDialogUnitTest::~FileDialogUnitTest() {
    delete object;
}

void SUI::FileDialogUnitTest::fileDialogWithParent() {
    SUI::DialogRejecter filedialogRejector;
    Q_UNUSED(filedialogRejector);
    //parent CheckBox
    SUI::CheckBox *chkBox = SUI::ObjectFactory::getInstance()->createWidget_<SUI::CheckBox>(NULL);
    object->getOpenFileName(chkBox, "Checkbox parent OpenFile", "", "", "", NULL, FileDialogOptionEnum::DontUseNativeDialog);
    object->getExistingDirectory(chkBox, "Checkbox parent  open Existing directory", "", "");
    object->getOpenFileNames(chkBox, "Checkbox parent Open Filenames", "", "");
    object->getSaveFileName(chkBox, "Checkbox parent Save File", "", "");
    delete chkBox;

    //parent Button
    SUI::Button *btn = SUI::ObjectFactory::getInstance()->createWidget_<SUI::Button>(NULL);
    object->getOpenFileName(btn, "Button parent OpenFile", "", "", "", NULL, FileDialogOptionEnum::DontUseNativeDialog);
    object->getExistingDirectory(btn, "Button parent open Existing directory", "", "");
    object->getOpenFileNames(btn, "Button parent Open Filenames", "", "");
    object->getSaveFileName(btn, "Button parent Save File", "", "");
    delete btn;
}

void SUI::FileDialogUnitTest::callInterfaceTests() {
    //IClickable tests
    IClickableUnitTest iClickable(object);
    iClickable.clickable();
}
