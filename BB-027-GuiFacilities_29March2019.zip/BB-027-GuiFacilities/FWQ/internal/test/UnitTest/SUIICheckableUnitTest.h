#ifndef SUIICHECKABLEUNITTEST_H
#define SUIICHECKABLEUNITTEST_H

#include <QTest>
namespace SUI {

class ICheckable;

class ICheckableUnitTest
{
public:
     explicit ICheckableUnitTest(ICheckable *object);

     bool setChecked();

private:
    ICheckable *object;
};

}

#endif // SUIICHECKABLEUNITTEST_H
