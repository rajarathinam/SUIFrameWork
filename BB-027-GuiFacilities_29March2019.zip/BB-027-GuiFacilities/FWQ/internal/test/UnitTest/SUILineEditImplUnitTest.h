
#ifndef SUILINEEDITIMPLUNITTEST_H
#define SUILINEEDITIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class LineEditImpl;

class LineEditImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit LineEditImplUnitTest(LineEditImpl *object, QObject *parent = 0);
    virtual ~LineEditImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    LineEditImpl *object;
};

}
#endif // SUILINEEDITIMPLUNITTEST_H
