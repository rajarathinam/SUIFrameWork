#include "SUIGraphicsEllipseItemUnitTest.h"

#include <QTest>

#include <FWQxGraphicsItems/SUIGraphicsEllipseItem.h>

SUI::GraphicsEllipseItemUnitTest::GraphicsEllipseItemUnitTest(GraphicsEllipseItem *object, QObject *parent) :
    ObjectUnitTest(object,parent),
    object(object)
{
}

SUI::GraphicsEllipseItemUnitTest::~GraphicsEllipseItemUnitTest()
{
}

void SUI::GraphicsEllipseItemUnitTest::setPosition() {
    object->setPosition(20,20);
    QVERIFY(object->getX() == 20 && object->getY() == 20);
}

void SUI::GraphicsEllipseItemUnitTest::setX() {
    object->setX(20);
    QVERIFY(object->getX());
}

void SUI::GraphicsEllipseItemUnitTest::setY() {
    object->setY(20);
    QVERIFY(object->getY());
}

void SUI::GraphicsEllipseItemUnitTest::setZValue() {
    object->setZValue(20);
    QVERIFY(object->getZValue());
}

void SUI::GraphicsEllipseItemUnitTest::setRotation() {
    object->setRotation(20);
    QVERIFY(object->getRotation());
}


