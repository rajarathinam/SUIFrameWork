
#ifndef SUITABWIDGETIMPLUNITTEST_H
#define SUITABWIDGETIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class TabWidgetImpl;

class TabWidgetImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit TabWidgetImplUnitTest(TabWidgetImpl *object, QObject *parent = 0);
    virtual ~TabWidgetImplUnitTest();

private slots:
    void setDefaultProperties();

    void testVisiblityforAddNewTab();
    void testVisiblityforAddNewTab_data();
private:
    TabWidgetImpl *object;
};

}
#endif // SUITABWIDGETIMPLUNITTEST_H
