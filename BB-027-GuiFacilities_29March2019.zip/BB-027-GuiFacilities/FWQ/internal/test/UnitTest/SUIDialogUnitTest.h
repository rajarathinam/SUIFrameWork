#ifndef SUIDIALOGUNITTEST_H
#define SUIDIALOGUNITTEST_H

#include "SUIWidgetUnitTest.h"
#include <FWQxWidgets/SUIDialog.h>
#include <QObject>
namespace SUI {

class Dialog;

class DialogUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    explicit DialogUnitTest(Dialog *object, QObject *parent = 0);
    virtual ~DialogUnitTest();
    
private slots:
    void testSetWindowTitle();
    void testSetWindowTitle_data();

    void testGetFileName();
    void testGetFileName_data();
    void testQuit();
    void testSetModal();
    void testGetObjectList();

private:
    Dialog *object;
};

}
#endif // SUIDIALOGUNITTEST_H
