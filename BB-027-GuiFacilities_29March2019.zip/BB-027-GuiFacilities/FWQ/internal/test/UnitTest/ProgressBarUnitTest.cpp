#include "ProgressBarUnitTest.h"

#include <QSignalSpy>
#include <QStringList>
#include <QDebug>

ProgressBarUnitTest::ProgressBarUnitTest() :
    mProgressWidg(new SUI::ProgressBarImpl(NULL)),
    mIProgressWidg(dynamic_cast<SUI::ProgressBar *>(mProgressWidg)),
    mIProgressWidg_Status(dynamic_cast<SUI::Widget *>(mProgressWidg)),
    mIProgressWidg_Text(dynamic_cast<SUI::IText *>(mProgressWidg)),
    mIProgressWidg_Color(dynamic_cast<SUI::IColorable *>(mProgressWidg)),
    mIProgressWidg_Orientation(dynamic_cast<SUI::IOrientable *>(mProgressWidg))
{}

void ProgressBarUnitTest::initTestCase()
{
    mProgressWidg->setText("0");
}

void ProgressBarUnitTest::cleanupTestCase()
{
    delete mProgressWidg;
}

void ProgressBarUnitTest::testVisibilityCase2()
{
    QFETCH(bool, value1);

    mIProgressWidg->setVisible(value1);

    QCOMPARE(dynamic_cast<QProgressBar *>(mProgressWidg->getWidget())->isVisible(), value1);
}

void ProgressBarUnitTest::testVisibilityCase2_data()
{
    QTest::addColumn<bool>("value1");
    QTest::newRow("First change") << true;
    QTest::newRow("Second change") << false;
}

void ProgressBarUnitTest::testEnabledCase2()
{
    QFETCH(bool, value1);
    mIProgressWidg->setEnabled(value1);
    QCOMPARE(dynamic_cast<QProgressBar *>(mProgressWidg->getWidget())->isEnabled(), value1);
}

void ProgressBarUnitTest::testEnabledCase2_data()
{
    QTest::addColumn<bool>("value1");
    QTest::newRow("First change") << true;
    QTest::newRow("Second change") << false;
}

void ProgressBarUnitTest::testGetTextCase1()
{
    QFETCH(QString, value1);
    QCOMPARE(QString::fromStdString(mProgressWidg->getText()), value1);
}

void ProgressBarUnitTest::testGetTextCase1_data()
{
    QTest::addColumn<QString>("value1");
    QTest::newRow("GetText") << QString("0");
}

void ProgressBarUnitTest::testSetTextCase2()
{
    QFETCH(QString, value1);
    mProgressWidg->setText(value1.toStdString());
    QCOMPARE(QString::fromStdString(mProgressWidg->getText()), value1);
}

void ProgressBarUnitTest::testSetTextCase2_data()
{
    QTest::addColumn<QString>("value1");
    QTest::newRow("First change") << QString("10");
    QTest::newRow("SetText change 2") << QString("100");
    QTest::newRow("SetText change 3") << QString("0");
}

void ProgressBarUnitTest::testSetBoldCase1()
{
    QFETCH(bool, NewBool);
    QFETCH(QString, NewText);
    mProgressWidg->setBold(NewBool);
    QCOMPARE(mProgressWidg->getWidget()->property("SUIFont").toString(), NewText);
}

void ProgressBarUnitTest::testSetBoldCase1_data()
{
    QTest::addColumn<bool>("NewBool");
    QTest::addColumn<QString>("NewText");
    QTest::newRow("First change") << true << QString("bold");
    QTest::newRow("Second change") << false << QString("");
}

void ProgressBarUnitTest::testGetColorsCase1()
{
    QFETCH(QString, NewText);
    std::string text = SUI::ColorEnum::toString(SUI::ColorEnum::getColorEnumList(SUI::ObjectType::ProgressBar),";");
    QCOMPARE(QString::fromStdString(text), NewText);
}

void ProgressBarUnitTest::testGetColorsCase1_data() {
    QTest::addColumn<QString>("NewText");
    QTest::newRow("Colors") << QString("standard;red;green;blue;gray;yellow");
}

void ProgressBarUnitTest::testColorCase1()
{
    QFETCH(QString, NewText);
    mProgressWidg->setColor(SUI::ColorEnum::fromString(NewText.toStdString()));
    QCOMPARE(QString::fromStdString(SUI::ColorEnum::toString(mProgressWidg->getColor())), NewText) ;
}

void ProgressBarUnitTest::testColorCase1_data()
{
    QTest::addColumn<QString>("NewText");
    QTest::newRow("Set Color Green") << QString("green");
    QTest::newRow("Set Color Black") << QString("standard");
}

void ProgressBarUnitTest::testDisablePercentageCase1()
{
    QFETCH(bool, disable);
    mProgressWidg->disablePercentage(disable);
    QCOMPARE(disable, !dynamic_cast<QProgressBar *>(mProgressWidg->getWidget())->isTextVisible());
}

void ProgressBarUnitTest::testDisablePercentageCase1_data()
{
    QTest::addColumn<bool>("disable");
    QTest::newRow("Enabled percentage") << bool(false);
    QTest::newRow("Disabled percentage") << bool(true);
}

void ProgressBarUnitTest::testHandleChangeCase1()
{
    QFETCH(int, startVal);
    mProgressWidg->setValue(startVal);
    QTEST(mProgressWidg->getValue(),"endVal");
    QSignalSpy spy(mProgressWidg->getWidget(), SIGNAL(valueChanged(int)));
    QFETCH(int, newVal);
    mProgressWidg->setValue(newVal);
    QFETCH(bool, willSignal );
    if( willSignal )
    {
      QCOMPARE(spy.count(), 1);
      QTEST(spy.takeFirst()[0].toInt(), "newVal");
    }
    else
      QCOMPARE(spy.count(), 0);
}

void ProgressBarUnitTest::testHandleChangeCase1_data()
{
    QTest::addColumn<int>( "startVal" );
    QTest::addColumn<int>( "endVal" );
    QTest::addColumn<int>( "newVal" );
    QTest::addColumn<bool>( "willSignal" );
    QTest::newRow("testHandleChange") << 25 << 25 << 50 << true;
}

void ProgressBarUnitTest::testGetOrientationChangeCase1()
{
    QFETCH(QString, NewText);
    QCOMPARE(QString::fromStdString(SUI::OrientationEnum::toString(mProgressWidg->getOrientation())), NewText);
}

void ProgressBarUnitTest::testGetOrientationChangeCase1_data()
{
    QTest::addColumn<QString>("NewText");
    QTest::newRow("Orientation") << QString("Horizontal");
}

void ProgressBarUnitTest::testsetOrientationCase1()
{
    QFETCH(QString, NewText);
    QFETCH(bool, Enum);
    if (Enum)
    {
        mIProgressWidg->setOrientation(SUI::OrientationEnum::Horizontal);
    }
    else
    {
        mIProgressWidg->setOrientation(SUI::OrientationEnum::Vertical);
    }
    QCOMPARE(QString::fromStdString(SUI::OrientationEnum::toString(mProgressWidg->getOrientation())), NewText);
}

void ProgressBarUnitTest::testsetOrientationCase1_data()
{
    QTest::addColumn<QString>("NewText");
    QTest::addColumn<bool>("Enum");
    QTest::newRow("Orientation") << QString("Horizontal") << bool(true);
    QTest::newRow("Orientation") << QString("Vertical") << bool(false);
}

void ProgressBarUnitTest::testVisibilityCase1()
{
    QFETCH(bool, value1);
    mIProgressWidg_Status->setVisible(value1);
    QCOMPARE(mIProgressWidg_Status->isVisible(), value1);
}

void ProgressBarUnitTest::testVisibilityCase1_data()
{
    QTest::addColumn<bool>("value1");
    QTest::newRow("First change") << true;
    QTest::newRow("Second change") << false;
}

void ProgressBarUnitTest::testEnabledCase1()
{
    QFETCH(bool, value1);
    mIProgressWidg_Status->setEnabled(value1);
    QCOMPARE(mIProgressWidg_Status->isEnabled(), value1);
}

void ProgressBarUnitTest::testEnabledCase1_data()
{
    QTest::addColumn<bool>("value1");
    QTest::newRow("First change") << true;
    QTest::newRow("Second change") << false;
}

void ProgressBarUnitTest::testDisablePercentageCase2()
{
    QFETCH(bool, disable);
    mIProgressWidg->disablePercentage(disable);
    QCOMPARE(disable, !dynamic_cast<QProgressBar *>(mProgressWidg->getWidget())->isTextVisible());
}

void ProgressBarUnitTest::testDisablePercentageCase2_data()
{
    QTest::addColumn<bool>("disable");
    QTest::newRow("Enabled percentage") << bool(false);
    QTest::newRow("Disabled percentage") << bool(true);
}

void ProgressBarUnitTest::testGetTextCase2()
{
    QFETCH(QString, value1);
    mIProgressWidg_Text->setText(value1.toStdString());
    QTEST(QString::fromStdString(mIProgressWidg_Text->getText()), "value1");
}

void ProgressBarUnitTest::testGetTextCase2_data()
{
    QTest::addColumn<QString>("value1");
    QTest::newRow("GetText, 10") << QString("10");
    QTest::newRow("GetText, 100") << QString("100");
    QTest::newRow("GetText, 0") << QString("0");
}

void ProgressBarUnitTest::testSetTextCase1()
{
    QFETCH(QString, value1);
    mIProgressWidg_Text->setText(value1.toStdString());
    QCOMPARE(QString::fromStdString(mIProgressWidg_Text->getText()), value1);
}

void ProgressBarUnitTest::testSetTextCase1_data()
{
    QTest::addColumn<QString>("value1");
    QTest::newRow("First change") << QString("10");
    QTest::newRow("SetText change 2") << QString("100");
    QTest::newRow("SetText change 3") << QString("0");
}

void ProgressBarUnitTest::testSetBoldCase2()
{
    QFETCH(bool, NewBool);
    QFETCH(QString, NewText);
    mIProgressWidg_Text->setBold(NewBool);
    QCOMPARE(mProgressWidg->getWidget()->property("SUIFont").toString(), NewText);
}

void ProgressBarUnitTest::testSetBoldCase2_data()
{
    QTest::addColumn<bool>("NewBool");
    QTest::addColumn<QString>("NewText");
    QTest::newRow("First change") << true << QString("bold");
    QTest::newRow("Second change") << false << QString("");
}

void ProgressBarUnitTest::testGetColorsCase2()
{
    QFETCH(QString, NewText);
    std::list<SUI::ColorEnum::Color>  colorList = SUI::ColorEnum::getColorEnumList(SUI::ObjectType::ProgressBar);
    QStringList s;
    foreach(SUI::ColorEnum::Color color, colorList) 
       s.append(QString::fromStdString(SUI::ColorEnum::toString(color)));
    QCOMPARE(s.join(";"), NewText);
}

void ProgressBarUnitTest::testGetColorsCase2_data()
{
    QTest::addColumn<QString>("NewText");
    QTest::newRow("Colors") << QString("standard;red;green;blue;gray;yellow");
}

void ProgressBarUnitTest::testColorCase2()
{
    QFETCH(QString, NewText);
    mIProgressWidg_Color->setColor(SUI::ColorEnum::fromString(NewText.toStdString()));
    QCOMPARE(QString::fromStdString(SUI::ColorEnum::toString(mIProgressWidg_Color->getColor())), NewText);
}

void ProgressBarUnitTest::testColorCase2_data()
{
    QTest::addColumn<QString>("NewText");
    QTest::newRow("Set Color Green") << QString("green");
    QTest::newRow("Set Color Black") << QString("standard");
}

void ProgressBarUnitTest::testGetOrientationChangeCase2()
{
    QFETCH(QString, NewText);
    QCOMPARE(QString::fromStdString(SUI::OrientationEnum::toString(mIProgressWidg_Orientation->getOrientation())), NewText);
}

void ProgressBarUnitTest::testGetOrientationChangeCase2_data()
{
    QTest::addColumn<QString>("NewText");
    QTest::newRow("Orientation") << QString("Vertical");
}

void ProgressBarUnitTest::testsetOrientationCase2()
{
    QFETCH(QString, NewText);
    QFETCH(bool, Enum);
    if (Enum)
    {
        mIProgressWidg_Orientation->setOrientation(SUI::OrientationEnum::Horizontal);
    }
    else
    {
        mIProgressWidg_Orientation->setOrientation(SUI::OrientationEnum::Vertical);
    }
    QCOMPARE(QString::fromStdString(SUI::OrientationEnum::toString(mIProgressWidg_Orientation->getOrientation())), NewText);
}

void ProgressBarUnitTest::testsetOrientationCase2_data()
{
    QTest::addColumn<QString>("NewText");
    QTest::addColumn<bool>("Enum");
    QTest::newRow("Orientation") << QString("Horizontal") << bool(true);
    QTest::newRow("Orientation") << QString("Vertical") << bool(false);
}
