
#include "SUIContainerImplUnitTest.h"
#include "SUIContainerImpl.h"
#include "SUIBaseObject.h"

const std::string UI_FILE_NAME = "UnitTestResoursePath.xml";

SUI::ContainerImplUnitTest::ContainerImplUnitTest(SUI::ContainerImpl *object, QObject *parent) :
    QObject(parent),
    containerObject(object)
{

}

SUI::ContainerImplUnitTest::~ContainerImplUnitTest()
{
   delete containerObject;
}

void SUI::ContainerImplUnitTest::setDefaultProperties() {
    containerObject->setDefaultProperties(SUI::BaseObject::Gui);
}

void SUI::ContainerImplUnitTest::setUIFile()
{
    containerObject->setUiFilename(UI_FILE_NAME);
    QCOMPARE(static_cast<int>(containerObject->getObjectList()->getObjectList().size()), 7);
}
