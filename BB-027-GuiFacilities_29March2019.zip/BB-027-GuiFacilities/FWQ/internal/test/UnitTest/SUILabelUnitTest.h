#ifndef LABELUNITTEST_H
#define LABELUNITTEST_H

#include "SUIWidgetUnitTest.h"

namespace SUI {

class Label;

class LabelUnitTest : public WidgetUnitTest
{
    Q_OBJECT
public:
    explicit LabelUnitTest(Label *object, QObject *parent = 0);
    virtual ~LabelUnitTest();

protected:
    void callInterfaceTests();

private slots:
    void setFontSize();
    void testSetHighlightText();
    void testSetHighlightText_data();

private:
    Label *object;
};

}
#endif // LABELUNITTEST_H
