#include "SUIICheckableUnitTest.h"
#include <QTest>
#include <FWQxCore/SUIICheckable.h>

SUI::ICheckableUnitTest::ICheckableUnitTest(SUI::ICheckable *object) :
    object(object)
{
    Q_ASSERT(object);
}

bool SUI::ICheckableUnitTest::setChecked() {
    object->setChecked(true);
    bool checked = object->isChecked();
    object->setChecked(false);
    bool unchecked = object->isChecked();
    return checked && !unchecked;
}
