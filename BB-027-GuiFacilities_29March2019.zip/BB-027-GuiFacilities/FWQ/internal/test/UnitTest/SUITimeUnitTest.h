#ifndef SUITIMEUNITTEST_H
#define SUITIMEUNITTEST_H

#include <QObject>
#include <boost/shared_ptr.hpp>

namespace SUI {
class Time;
class TimeUnitTest : public QObject
{
    Q_OBJECT

public:
    TimeUnitTest();

private Q_SLOTS:
    void tesCurrentTime();
    void testSetHMS_data();
    void testSetHMS();

    void testToString_data();
    void testToString();

    void testToStringFormat();
    void testToStringFormat_data();

    void testIsValidAndNull();

private:
    boost::shared_ptr<SUI::Time> time;
};

}
#endif // SUITIMEUNITTEST_H

