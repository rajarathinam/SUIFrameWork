
#ifndef SUIUSERCONTROLIMPLUNITTEST_H
#define SUIUSERCONTROLIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class UserControlImpl;

class UserControlImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit UserControlImplUnitTest(UserControlImpl *object, QObject *parent = 0);
    virtual ~UserControlImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    UserControlImpl *object;
};

}
#endif // SUIUSERCONTROLIMPLUNITTEST_H
