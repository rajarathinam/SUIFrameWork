#include "ObjectUnitTest.h"

#include "SUITableWidgetItemImpl.h"

ObjectUnitTest::ObjectUnitTest() :
    busyindicator(new SUI::BusyIndicatorImpl(NULL)),
    button(new SUI::ButtonImpl(NULL)),
    checkbox(new SUI::CheckBoxImpl(NULL)),
    checkboxgroup(new SUI::CheckGroupBoxImpl(NULL)),
    checkmark(new SUI::CheckMarkImpl(NULL)),
    colorcrossdrop(new SUI::ColorCrossDropImpl(NULL)),
    colordrop(new SUI::ColorDropImpl(NULL)),
    controlwidget(new SUI::ControlWidgetImpl(NULL)),
    datetimewidget(new SUI::DateTimeEditImpl(NULL)),
    dblspinbox(new SUI::DoubleSpinBoxImpl(NULL)),
    filebrowser(new SUI::FileDialogImpl(NULL)),
    groupbox(new SUI::GroupBoxImpl(NULL)),
    graphicsView(SUI::ObjectFactory::getInstance()->createWidget_<SUI::GraphicsView>()),
    label(new SUI::LabelImpl(NULL)),
    led(new SUI::LEDWidgetImpl(NULL)),
    lineedit(new SUI::LineEditImpl(NULL)),
    listview(new SUI::ListViewImpl(NULL)),
    messagebox(new SUI::MessageBoxImpl(NULL)),
    plotwidget(new SUI::PlotWidgetImpl(NULL)),
    progressbar(new SUI::ProgressBarImpl(NULL)),
    questionmark(new SUI::QuestionMarkImpl(NULL)),
    radiobutton(new SUI::RadioButtonImpl(NULL)),
    sciencespinbox(new SUI::ScienceSpinBoxImpl(NULL)),
    spinbox(new SUI::SpinBoxImpl(NULL)),
    statewidget(new SUI::StateWidgetImpl(NULL)),
    svgwidget(new SUI::SvgWidgetImpl(NULL)),
    tablewidget(new SUI::TableWidgetImpl(NULL)),
    tablewidgetitem(new SUI::TableWidgetItemImpl(NULL)),
    textarea(new SUI::TextAreaImpl(NULL)),
    treeitem(new SUI::TreeViewItemImpl(NULL)),
    usercontrol(new SUI::UserControlImpl(NULL)),
    containerWidget(new SUI::ContainerImpl(NULL)),
    //SUI::GraphicsImpl
    graphicscrosshair(SUI::ObjectFactory::getInstance()->createGraphicsItem<SUI::GraphicsCrosshairItem>(NULL)),
    graphicsellipse(SUI::ObjectFactory::getInstance()->createGraphicsItem<SUI::GraphicsEllipseItem>(NULL)),
    graphicsline(SUI::ObjectFactory::getInstance()->createGraphicsItem<SUI::GraphicsLineItem>(NULL)),
    graphicspixmap(SUI::ObjectFactory::getInstance()->createGraphicsItem<SUI::GraphicsPixmapItem>(NULL)),
    graphicsrect(SUI::ObjectFactory::getInstance()->createGraphicsItem<SUI::GraphicsRectItem>(NULL)),
    graphicstext(SUI::ObjectFactory::getInstance()->createGraphicsItem<SUI::GraphicsTextItem>(NULL)),

    //SUI::Widget
    ibusyindicator(dynamic_cast<SUI::Widget *>(busyindicator)),
    ibutton(dynamic_cast<SUI::Widget *>(button)),
    icheckbox(dynamic_cast<SUI::Widget *>(checkbox)),
    icheckboxgroup(dynamic_cast<SUI::Widget *>(checkboxgroup)),
    icheckmark(dynamic_cast<SUI::Widget *>(checkmark)),
    icolorcrossDrop(dynamic_cast<SUI::Widget *>(colorcrossdrop)),
    icolorDrop(dynamic_cast<SUI::Widget *>(colordrop)),
    icontrolwidget(dynamic_cast<SUI::Widget *>(controlwidget)),
    idatetimewidget(dynamic_cast<SUI::Widget *>(datetimewidget)),
    idblspinbox(dynamic_cast<SUI::Widget *>(dblspinbox)),
    ifilebrowser(dynamic_cast<SUI::Widget *>(filebrowser)),
    igroupbox(dynamic_cast<SUI::Widget *>(groupbox)),
    igraphicsView(dynamic_cast<SUI::Widget *>(graphicsView)),
    ilabel(dynamic_cast<SUI::Widget *>(label)),
    iled(dynamic_cast<SUI::Widget *>(led)),
    ilineedit(dynamic_cast<SUI::Widget *>(lineedit)),
    ilistview(dynamic_cast<SUI::Widget *>(listview)),
    imessagebox(dynamic_cast<SUI::Widget *>(messagebox)),
    iplotwidget(dynamic_cast<SUI::Widget *>(plotwidget)),
    iprogressbar(dynamic_cast<SUI::Widget *>(progressbar)),
    iquestionmark(dynamic_cast<SUI::Widget *>(questionmark)),
    iradiobutton(dynamic_cast<SUI::Widget *>(radiobutton)),
    isciencespinbox(dynamic_cast<SUI::Widget *>(sciencespinbox)),
    ispinbox(dynamic_cast<SUI::Widget *>(spinbox)),
    istatewidget(dynamic_cast<SUI::Widget *>(statewidget)),
    isvgwidget(dynamic_cast<SUI::Widget *>(svgwidget)),
    itablewidget(dynamic_cast<SUI::Widget *>(statewidget)),
    itablewidgetitem(dynamic_cast<SUI::Widget *>(tablewidget)),
    itextarea(dynamic_cast<SUI::Widget *>(textarea)),
    itreeitem(dynamic_cast<SUI::Widget *>(treeitem)),
    iusercontrol(dynamic_cast<SUI::Widget *>(usercontrol)),
    //SUI::GraphicsItem
    igraphicscrosshair(dynamic_cast<SUI::GraphicsItem *>(graphicscrosshair)),
    igraphicsellipse(dynamic_cast<SUI::GraphicsItem *>(graphicsellipse)),
    igraphicsline(dynamic_cast<SUI::GraphicsItem *>(graphicsline)),
    igraphicspixmap(dynamic_cast<SUI::GraphicsItem *>(graphicspixmap)),
    igraphicsrect(dynamic_cast<SUI::GraphicsItem *>(graphicsrect)),
    igraphicstext(dynamic_cast<SUI::GraphicsItem *>(graphicstext))

{}

void ObjectUnitTest::cleanupTestCase()
{
    delete busyindicator;
    delete button;
    delete checkbox;
    delete checkboxgroup;
    delete checkmark;
    delete colorcrossdrop;
    delete colordrop;
    delete controlwidget;
    delete datetimewidget;
    delete dblspinbox;
    delete filebrowser;
    delete groupbox;
    delete graphicsView;
    delete label;
    delete led;
    delete lineedit;
    delete listview;
    delete messagebox;
    delete plotwidget;
    delete progressbar;
    delete questionmark;
    delete radiobutton;
    delete sciencespinbox;
    delete spinbox;
    delete statewidget;
    delete svgwidget;
    delete tablewidget;
    delete tablewidgetitem;
    delete textarea;
    delete treeitem;
    delete usercontrol;
    delete containerWidget;
//    delete graphicscrosshair;
//    delete graphicsellipse;
//    delete graphicsline;
//    delete graphicspixmap;
//    delete graphicsrect;
//    delete graphicstext;
}

void ObjectUnitTest::testVisibilityCase1()
{
    QFETCH(bool, value1);

    //SUI::Widget
    ibusyindicator->setVisible(value1);
    ibutton->setVisible(value1);
    icheckbox->setVisible(value1);
    icheckboxgroup->setVisible(value1);
    icheckmark->setVisible(value1);
    icolorcrossDrop->setVisible(value1);
    icolorDrop->setVisible(value1);
    icontrolwidget->setVisible(value1);
    idatetimewidget->setVisible(value1);
    idblspinbox->setVisible(value1);
    ifilebrowser->setVisible(value1);
    igroupbox->setVisible(value1);
    igraphicsView->setVisible(value1);
    ilabel->setVisible(value1);
    iled->setVisible(value1);
    ilineedit->setVisible(value1);
    ilistview->setVisible(value1);
    imessagebox->setVisible(value1);
    iplotwidget->setVisible(value1);
    iprogressbar->setVisible(value1);
    iquestionmark->setVisible(value1);
    iradiobutton->setVisible(value1);
    isciencespinbox->setVisible(value1);
    ispinbox->setVisible(value1);
    istatewidget->setVisible(value1);
    isvgwidget->setVisible(value1);
    itablewidget->setVisible(value1);
    itablewidgetitem->setVisible(value1);
    itextarea->setVisible(value1);
    itreeitem->setVisible(value1);
    iusercontrol->setVisible(value1);
    //SUI::GraphicsItem
    igraphicscrosshair->setVisible(value1);
    igraphicsellipse->setVisible(value1);
    igraphicsline->setVisible(value1);
    igraphicspixmap->setVisible(value1);
    igraphicsrect->setVisible(value1);
    igraphicstext->setVisible(value1);

    //SUI::Widget
    QCOMPARE(ibusyindicator->isVisible(), value1);
    QCOMPARE(ibutton->isVisible(), value1);
    QCOMPARE(icheckbox->isVisible(), value1);
    QCOMPARE(icheckmark->isVisible(), value1);
    QCOMPARE(icheckboxgroup->isVisible(), value1);
    QCOMPARE(icolorcrossDrop->isVisible(), value1);
    QCOMPARE(icolorDrop->isVisible(), value1);
    QCOMPARE(icontrolwidget->isVisible(), value1);
    QCOMPARE(idatetimewidget->isVisible(), value1);
    QCOMPARE(idblspinbox->isVisible(), value1);
    QCOMPARE(ifilebrowser->isVisible(), value1);
    QCOMPARE(igroupbox->isVisible(), value1);
    QCOMPARE(igraphicsView->isVisible(), value1);
    QCOMPARE(ilabel->isVisible(), value1);
    QCOMPARE(iled->isVisible(), value1);
    QCOMPARE(ilineedit->isVisible(), value1);
    QCOMPARE(ilistview->isVisible(), value1);
    QCOMPARE(imessagebox->isVisible(), value1);
    QCOMPARE(iplotwidget->isVisible(), value1);
    QCOMPARE(iprogressbar->isVisible(), value1);
    QCOMPARE(iquestionmark->isVisible(), value1);
    QCOMPARE(iradiobutton->isVisible(), value1);
    QCOMPARE(isciencespinbox->isVisible(), value1);
    QCOMPARE(ispinbox->isVisible(), value1);
    QCOMPARE(istatewidget->isVisible(), value1);
    QCOMPARE(isvgwidget->isVisible(), value1);
    QCOMPARE(itablewidget->isVisible(), value1);
    QCOMPARE(itablewidgetitem->isVisible(), value1);
    QCOMPARE(itextarea->isVisible(), value1);
    QCOMPARE(itreeitem->isVisible(), value1);
    QCOMPARE(iusercontrol->isVisible(), value1);
    //SUI::GraphicsItem
    QCOMPARE(igraphicscrosshair->isVisible(), value1);
    QCOMPARE(igraphicsellipse->isVisible(), value1);
    QCOMPARE(igraphicsline->isVisible(), value1);
    QCOMPARE(igraphicspixmap->isVisible(), value1);
    QCOMPARE(igraphicsrect->isVisible(), value1);
    QCOMPARE(igraphicstext->isVisible(), value1);
}

void ObjectUnitTest::testVisibilityCase1_data()
{
    QTest::addColumn<bool>("value1");
    QTest::newRow("First change") << true ;
    QTest::newRow("Second change") << false ;
}

void ObjectUnitTest::testVisibilityCase2()
{
    QFETCH(bool, value1);
    //SUI::Impl
    busyindicator->setVisible(value1);
    button->setVisible(value1);
    checkbox->setVisible(value1);
    checkboxgroup->setVisible(value1);
    checkmark->setVisible(value1);
    colorcrossdrop->setVisible(value1);
    colordrop->setVisible(value1);
    controlwidget->setVisible(value1);
    datetimewidget->setVisible(value1);
    dblspinbox->setVisible(value1);
    filebrowser->setVisible(value1);
    graphicsView->setVisible(value1);
    groupbox->setVisible(value1);
    label->setVisible(value1);
    led->setVisible(value1);
    lineedit->setVisible(value1);
    listview->setVisible(value1);
    messagebox->setVisible(value1);
    plotwidget->setVisible(value1);
    progressbar->setVisible(value1);
    questionmark->setVisible(value1);
    radiobutton->setVisible(value1);
    sciencespinbox->setVisible(value1);
    spinbox->setVisible(value1);
    statewidget->setVisible(value1);
    svgwidget->setVisible(value1);
    tablewidget->setVisible(value1);
    textarea->setVisible(value1);
    treeitem->setVisible(value1);
    usercontrol->setVisible(value1);
    containerWidget->setVisible(value1);
    //SUI::GraphicsImpl
    graphicscrosshair->setVisible(value1);
    graphicsellipse->setVisible(value1);
    graphicsline->setVisible(value1);
    graphicspixmap->setVisible(value1);
    graphicsrect->setVisible(value1);
    graphicstext->setVisible(value1);

    QCOMPARE(busyindicator->isVisible(), value1);
    QCOMPARE(button->isVisible(), value1);
    QCOMPARE(checkbox->isVisible(), value1);
    QCOMPARE(checkboxgroup->isVisible(), value1);
    QCOMPARE(checkmark->isVisible(), value1);
    QCOMPARE(colorcrossdrop->isVisible(), value1);
    QCOMPARE(colordrop->isVisible(), value1);
    QCOMPARE(controlwidget->isVisible(), value1);
    QCOMPARE(datetimewidget->isVisible(), value1);
    QCOMPARE(dblspinbox->isVisible(), value1);
    QCOMPARE(filebrowser->isVisible(), value1);
    QCOMPARE(groupbox->isVisible(), value1);
    QCOMPARE(graphicsView->isVisible(), value1);
    QCOMPARE(label->isVisible(), value1);
    QCOMPARE(led->isVisible(), value1);
    QCOMPARE(lineedit->isVisible(), value1);
    QCOMPARE(listview->isVisible(), value1);
    QCOMPARE(messagebox->isVisible(), value1);
    QCOMPARE(plotwidget->isVisible(), value1);
    QCOMPARE(progressbar->isVisible(), value1);
    QCOMPARE(questionmark->isVisible(), value1);
    QCOMPARE(radiobutton->isVisible(), value1);
    QCOMPARE(sciencespinbox->isVisible(), value1);
    QCOMPARE(spinbox->isVisible(), value1);
    QCOMPARE(statewidget->isVisible(), value1);
    QCOMPARE(svgwidget->isVisible(), value1);
    QCOMPARE(tablewidget->isVisible(), value1);
    QCOMPARE(treeitem->isVisible(), value1);
    QCOMPARE(usercontrol->isVisible(), value1);
    //SUI::GraphicsImpl
    QCOMPARE(graphicscrosshair->isVisible(), value1);
    QCOMPARE(graphicsellipse->isVisible(), value1);
    QCOMPARE(graphicsline->isVisible(), value1);
    QCOMPARE(graphicspixmap->isVisible(), value1);
    QCOMPARE(graphicsrect->isVisible(), value1);
    QCOMPARE(graphicstext->isVisible(), value1);
    QCOMPARE(containerWidget->isVisible(), value1);
}

void ObjectUnitTest::testVisibilityCase2_data()
{
    QTest::addColumn<bool>("value1");
    QTest::newRow("First change") << true ;
    QTest::newRow("Second change") << false ;
}

void ObjectUnitTest::testEnabledCase1()
{
    QFETCH(bool, value1);
    //SUI::Widget
    ibusyindicator->setEnabled(value1);
    ibutton->setEnabled(value1);
    icheckbox->setEnabled(value1);
    icheckboxgroup->setEnabled(value1);
    icheckmark->setEnabled(value1);
    icolorcrossDrop->setEnabled(value1);
    icolorDrop->setEnabled(value1);
    icontrolwidget->setEnabled(value1);
    idatetimewidget->setEnabled(value1);
    idblspinbox->setEnabled(value1);
    ifilebrowser->setEnabled(value1);
    igroupbox->setEnabled(value1);
    igraphicsView->setEnabled(value1);
    ilabel->setEnabled(value1);
    iled->setEnabled(value1);
    ilineedit->setEnabled(value1);
    ilistview->setEnabled(value1);
    imessagebox->setEnabled(value1);
    iplotwidget->setEnabled(value1);
    iprogressbar->setEnabled(value1);
    iquestionmark->setEnabled(value1);
    iradiobutton->setEnabled(value1);
    isciencespinbox->setEnabled(value1);
    ispinbox->setEnabled(value1);
    istatewidget->setEnabled(value1);
    isvgwidget->setEnabled(value1);
    itablewidget->setEnabled(value1);
    itablewidgetitem->setEnabled(value1);
    itextarea->setEnabled(value1);
    itreeitem->setEnabled(value1);
    iusercontrol->setEnabled(value1);
    //SUI::GraphicsItem
    //graphicscrosshair->setEnabled(value1);

    QCOMPARE(ibusyindicator->isEnabled(), value1);
    QCOMPARE(ibutton->isEnabled(), value1);
    QCOMPARE(icheckbox->isEnabled(), value1);
    QCOMPARE(icheckmark->isEnabled(), value1);
    QCOMPARE(icheckboxgroup->isEnabled(), value1);
    QCOMPARE(icolorcrossDrop->isEnabled(), value1);
    QCOMPARE(icolorDrop->isEnabled(), value1);
    QCOMPARE(icontrolwidget->isEnabled(), value1);
    QCOMPARE(idatetimewidget->isEnabled(), value1);
    QCOMPARE(idblspinbox->isEnabled(), value1);
    QCOMPARE(ifilebrowser->isEnabled(), value1);
    QCOMPARE(igroupbox->isEnabled(), value1);
    QCOMPARE(igraphicsView->isEnabled(), value1);
    QCOMPARE(ilabel->isEnabled(), value1);
    QCOMPARE(iled->isEnabled(), value1);
    QCOMPARE(ilineedit->isEnabled(), value1);
    QCOMPARE(ilistview->isEnabled(), value1);
    QCOMPARE(imessagebox->isEnabled(), value1);
    QCOMPARE(iplotwidget->isEnabled(), value1);
    QCOMPARE(iprogressbar->isEnabled(), value1);
    QCOMPARE(iquestionmark->isEnabled(), value1);
    QCOMPARE(iradiobutton->isEnabled(), value1);
    QCOMPARE(isciencespinbox->isEnabled(), value1);
    QCOMPARE(ispinbox->isEnabled(), value1);
    QCOMPARE(istatewidget->isEnabled(), value1);
    QCOMPARE(isvgwidget->isEnabled(), value1);
    QCOMPARE(itablewidget->isEnabled(), value1);
    QCOMPARE(itablewidgetitem->isEnabled(), value1);
    QCOMPARE(itextarea->isEnabled(), value1);
    QCOMPARE(itreeitem->isEnabled(), value1);
    QCOMPARE(iusercontrol->isEnabled(), value1);
}

void ObjectUnitTest::testEnabledCase1_data()
{
    QTest::addColumn<bool>("value1");
    QTest::newRow("First change") << true ;
    QTest::newRow("Second change") << false ;
}

void ObjectUnitTest::testEnabledCase2()
{
    QFETCH(bool, value1);

    busyindicator->setEnabled(value1);
    button->setEnabled(value1);
    checkbox->setEnabled(value1);
    checkboxgroup->setEnabled(value1);
    checkmark->setEnabled(value1);
    colorcrossdrop->setEnabled(value1);
    colordrop->setEnabled(value1);
    controlwidget->setEnabled(value1);
    datetimewidget->setEnabled(value1);
    dblspinbox->setEnabled(value1);
    filebrowser->setEnabled(value1);
    graphicsView->setEnabled(value1);
    groupbox->setEnabled(value1);
    graphicsView->setEnabled(value1);
    label->setEnabled(value1);
    led->setEnabled(value1);
    lineedit->setEnabled(value1);
    listview->setEnabled(value1);
    messagebox->setEnabled(value1);
    plotwidget->setEnabled(value1);
    progressbar->setEnabled(value1);
    questionmark->setEnabled(value1);
    radiobutton->setEnabled(value1);
    sciencespinbox->setEnabled(value1);
    spinbox->setEnabled(value1);
    statewidget->setEnabled(value1);
    svgwidget->setEnabled(value1);
    tablewidget->setEnabled(value1);
    textarea->setEnabled(value1);
    treeitem->setEnabled(value1);
    usercontrol->setEnabled(value1);
    containerWidget->setEnabled(value1);
    //SUI::GraphicsImpl
    graphicscrosshair->setEnabled(value1);
    graphicsellipse->setEnabled(value1);
    graphicsline->setEnabled(value1);
    graphicspixmap->setEnabled(value1);
    graphicsrect->setEnabled(value1);
    graphicstext->setEnabled(value1);

    QCOMPARE(busyindicator->isEnabled(), value1);
    QCOMPARE(button->isEnabled(), value1);
    QCOMPARE(checkbox->isEnabled(), value1);
    QCOMPARE(checkboxgroup->isEnabled(), value1);
    QCOMPARE(checkmark->isEnabled(), value1);
    QCOMPARE(colorcrossdrop->isEnabled(), value1);
    QCOMPARE(colordrop->isEnabled(), value1);
    QCOMPARE(controlwidget->isEnabled(), value1);
    QCOMPARE(datetimewidget->isEnabled(), value1);
    QCOMPARE(dblspinbox->isEnabled(), value1);
    QCOMPARE(filebrowser->isEnabled(), value1);
    QCOMPARE(groupbox->isEnabled(), value1);
    QCOMPARE(graphicsView->isEnabled(), value1);
    QCOMPARE(label->isEnabled(), value1);
    QCOMPARE(led->isEnabled(), value1);
    QCOMPARE(lineedit->isEnabled(), value1);
    QCOMPARE(listview->isEnabled(), value1);
    QCOMPARE(messagebox->isEnabled(), value1);
    QCOMPARE(plotwidget->isEnabled(), value1);
    QCOMPARE(progressbar->isEnabled(), value1);
    QCOMPARE(questionmark->isEnabled(), value1);
    QCOMPARE(radiobutton->isEnabled(), value1);
    QCOMPARE(sciencespinbox->isEnabled(), value1);
    QCOMPARE(spinbox->isEnabled(), value1);
    QCOMPARE(statewidget->isEnabled(), value1);
    QCOMPARE(svgwidget->isEnabled(), value1);
    QCOMPARE(tablewidget->isEnabled(), value1);
    QCOMPARE(treeitem->isEnabled(), value1);
    QCOMPARE(usercontrol->isEnabled(), value1);
    QCOMPARE(containerWidget->isEnabled(), value1);
    //SUI::GraphicsImpl
    QCOMPARE(graphicscrosshair->isEnabled(), value1);
    QCOMPARE(graphicsellipse->isEnabled(), value1);
    QCOMPARE(graphicsline->isEnabled(), value1);
    QCOMPARE(graphicspixmap->isEnabled(), value1);
    QCOMPARE(graphicsrect->isEnabled(), value1);
    QCOMPARE(graphicstext->isEnabled(), value1);
}

void ObjectUnitTest::testEnabledCase2_data()
{
    QTest::addColumn<bool>("value1");
    QTest::newRow("First change") << true ;
    QTest::newRow("Second change") << false ;
}
