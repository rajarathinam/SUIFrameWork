
#include "SUIRadioButtonImplUnitTest.h"
#include "SUIRadioButtonImpl.h"
#include "SUIBaseObject.h"

SUI::RadioButtonImplUnitTest::RadioButtonImplUnitTest(SUI::RadioButtonImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::RadioButtonImplUnitTest::~RadioButtonImplUnitTest()
{
   delete object;
}

void SUI::RadioButtonImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::EditorForm);
    object->setDefaultProperties(SUI::BaseObject::EditorSelector);
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
