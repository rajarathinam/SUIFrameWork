
#include "SUIImageWidgetImplUnitTest.h"
#include "SUIImageWidgetImpl.h"
#include "SUIBaseObject.h"

SUI::ImageWidgetImplUnitTest::ImageWidgetImplUnitTest(SUI::ImageWidgetImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::ImageWidgetImplUnitTest::~ImageWidgetImplUnitTest()
{
   delete object;
}

void SUI::ImageWidgetImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
