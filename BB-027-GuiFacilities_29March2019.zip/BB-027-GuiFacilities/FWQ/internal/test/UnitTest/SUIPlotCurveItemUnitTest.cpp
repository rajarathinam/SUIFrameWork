#include "SUIPlotCurveItemUnitTest.h"


SUI::PlotCurveItemUnitTest::PlotCurveItemUnitTest(SUI::PlotCurveItem *object, QObject *parent):
  QObject(parent),
  object(object)
{

}

SUI::PlotCurveItemUnitTest::~PlotCurveItemUnitTest()
{

}


void SUI::PlotCurveItemUnitTest::setDefaultProperties()
{
 object->setPlotMarker(MarkerSymbolEnum::XCross, ColorEnum::Green, 10);
 QCOMPARE(object->getSymbolWidth(), 10);
 QCOMPARE(object->getSymbolColor(), ColorEnum::Green);
 QCOMPARE(object->getSymbol(), MarkerSymbolEnum::XCross);

 object->setPlotMarker(MarkerSymbolEnum::Diamond, ColorEnum::Red, 1);
 QCOMPARE(object->getSymbolWidth(), 1);
 QCOMPARE(object->getSymbolColor(), ColorEnum::Red);
 QCOMPARE(object->getSymbol(), MarkerSymbolEnum::Diamond);

 object->setPlotMarker(MarkerSymbolEnum::RTriangle, ColorEnum::Blue, 15);
 QCOMPARE(object->getSymbolWidth(), 15);
 QCOMPARE(object->getSymbolColor(), ColorEnum::Blue);
 QCOMPARE(object->getSymbol(), MarkerSymbolEnum::RTriangle);

 object->setPlotMarker(MarkerSymbolEnum::NoSymbol, ColorEnum::Red, 1);
 QCOMPARE(object->getSymbolWidth(), 1);
 QCOMPARE(object->getSymbolColor(), ColorEnum::Red);
 QCOMPARE(object->getSymbol(), MarkerSymbolEnum::NoSymbol);

}
