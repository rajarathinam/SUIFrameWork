#ifndef SUIBUSYINDICATORUNITTEST_H
#define SUIBUSYINDICATORUNITTEST_H

#include "SUIWidgetUnitTest.h"
#include <FWQxWidgets/SUIBusyIndicator.h>

namespace SUI {

class BusyIndicator;

class BusyIndicatorUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    explicit BusyIndicatorUnitTest(SUI::BusyIndicator *object, QObject *parent = 0);
    virtual ~BusyIndicatorUnitTest();

private:
    BusyIndicator *object;
};

}
#endif // SUIBUSYINDICATORUNITTEST_H
