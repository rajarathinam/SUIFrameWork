#include "SUIButtonImplUnitTest.h"
#include "SUIButtonImpl.h"
#include "SUIBaseObject.h"

SUI::ButtonImplUnitTest::ButtonImplUnitTest(SUI::ButtonImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::ButtonImplUnitTest::~ButtonImplUnitTest()
{
   delete object;

}

void SUI::ButtonImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::Gui);
    object->setDefaultProperties(SUI::BaseObject::EditorForm);
    object->setDefaultProperties(SUI::BaseObject::EditorSelector);
}
