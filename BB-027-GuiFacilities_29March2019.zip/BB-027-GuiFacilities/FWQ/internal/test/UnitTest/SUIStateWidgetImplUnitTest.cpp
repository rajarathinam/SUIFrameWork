
#include "SUIStateWidgetImplUnitTest.h"
#include "SUIStateWidgetImpl.h"
#include "SUIBaseObject.h"

SUI::StateWidgetImplUnitTest::StateWidgetImplUnitTest(SUI::StateWidgetImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::StateWidgetImplUnitTest::~StateWidgetImplUnitTest()
{
   delete object;
}

void SUI::StateWidgetImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
