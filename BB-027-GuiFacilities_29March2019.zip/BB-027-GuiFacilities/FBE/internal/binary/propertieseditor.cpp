//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for PropertiesEditor.
// !\description This class provides the Property Table, which shows the
//                properties of the current widget in the Form Editor. A special
//                case is the ObjectProperty::IndexedValue property. This property
//                holds values for a different number of instances of that property.
//                E.g. the width of each column in a Table Widget. The number of
//                columns vary and changes when columns are inserted or removed.
//                The format of an IndexedValue is "index,value;". E.g. for a
//                Table Widget with 4 columns, the ColumnWidths property has an
//                initial value of "0,100;1,100;2,100;3,100;". In this example,
//                al 4 columns have a width of 100. For this property, the left
//                column has a spinbox with the key / property name, as the spinbox's
//                prefix and the spinbox's value as the index. The right column has
//                a spinbox with the value. When the index of the left spinbox changes,
//                the value of that IndexedValue has to be retrieved to fill the
//                proper value in the right spinbox. This is done with signals and slots.
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include <QVBoxLayout>
#include <QTableWidget>
#include <QHeaderView>
#include <QTableWidgetItem>
#include <QComboBox>
#include <QSpinBox>
#include <QFileDialog>
#include <QFormLayout>
#include <QVBoxLayout>
#include <QDialogButtonBox>
#include <QDebug>
#include <QBuffer>
#include <QMessageBox>
#include <QListWidget>
#include <QDoubleSpinBox>

#include <CustomScienceSpinBox.h>
#include <SUIStateWidgetImpl.h>
#include <SUIStyleSheet.h>
#include <SUIBasePageImpl.h>
#include <FWQxCore/SUIIImage.h>
#include <FWQxWidgets/SUIScienceSpinBox.h>
#include <boost/foreach.hpp>
#include "SUILogger.h"

#include "propertieseditor.h"
#include "Model.h"
#include "treewidgetdialog.h"
#include "headertreewidgetdialog.h"
#include "UndoHandler.h"




/*****************************************************************************\
 *  FUNCTION    :   PropertiesEditor
 *  PARAMETERS  :   QWidget *parent
 *  RETURN      :   n.a.
 *
 *  This is the constructor
 \****************************************************************************/
PropertiesEditor::PropertiesEditor(QWidget *parent) :
    QWidget(parent),
    mpPropertiesTable(NULL),
    mComboSignalMapper(new QSignalMapper(this)),
    mSpinboxSignalMapper(new QSignalMapper(this)),
    mPushSignalMapper(new QSignalMapper(this)),
    mSpinboxIndexedValueSignalMapper(new QSignalMapper(this)),
    mSpinboxKeyMapper(new QSignalMapper(this))
{
    QVBoxLayout *vLayout = new QVBoxLayout(this);

    mpPropertiesTable = new QTableWidget(7, 2);
    mpPropertiesTable->setColumnWidth(0, 200);
    mpPropertiesTable->setColumnWidth(1, 200);
    QStringList labels;
    labels << tr("Property") << tr("Value");
    mpPropertiesTable->setHorizontalHeaderLabels(labels);
    mpPropertiesTable->horizontalHeader()->setStretchLastSection(true);
    mpPropertiesTable->verticalHeader()->hide();

    mpPropertiesTable->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    mpPropertiesTable->setAlternatingRowColors(true);

    connect(mComboSignalMapper, SIGNAL(mapped(QString)), this, SLOT(onComboValueChanged(QString)));
    connect(mSpinboxSignalMapper, SIGNAL(mapped(QString)), this, SLOT(onSpinboxValueChanged(QString)));
    connect(mSpinboxIndexedValueSignalMapper, SIGNAL(mapped(QString)), this, SLOT(onSpinboxIndexedValueChanged(QString)));
    connect(mSpinboxKeyMapper, SIGNAL(mapped(QString)), this, SLOT(onSpinboxKeyChanged(QString)));
    connect(mPushSignalMapper, SIGNAL(mapped(QString)), this, SLOT(onButtonPushed(QString)));
    vLayout->addWidget(mpPropertiesTable);
}

/*****************************************************************************\
 *  FUNCTION    :   ~PropertiesEditor
 *  PARAMETERS  :   n.a.
 *  RETURN      :   n.a.
 *
 *  This is the destructor
\****************************************************************************/
PropertiesEditor::~PropertiesEditor()
{
}


//TODO rewrite this class and only use this function to the outside
void PropertiesEditor::setObject(SUI::BaseObject *object) {
    using namespace SUI;
    using namespace std;
    mpPropertiesTable->clear();
    if (object != NULL) {
        //TODO clear table
        vector<ObjectPropertyTypeEnum::Type> types = ObjectProperty::getObjectPropertyTypes(object->getObjectType());
        for (int n = 0, t = static_cast<int>(types.size()); n < t; n++) {
            mpPropertiesTable->insertRow(n);
            // for each type
            ObjectPropertyTypeEnum::Type type = types[n];
            // there is a property
            ObjectProperty *property = object->getProperty(type);

            switch (property->getType()) {

            case ObjectProperty::Bool: {
                QComboBox *editor = new QComboBox();
                editor->addItems(QString("true;false").split(";"));
                editor->setCurrentIndex(property->getValue() == "true" ? 0 : 1);
                mpPropertiesTable->setCellWidget(n,1,editor);
                break;
            }

            case ObjectProperty::File:
                //TODO make a button that opens a file dialog
                break;

            case ObjectProperty::Enum:
                break;

            case ObjectProperty::Number: {
                QSpinBox *editor = new QSpinBox();
                editor->setMinimum(property->getMinValue());
                editor->setMaximum(property->getMaxValue());
                editor->setValue(property->getValue().toInt());
                mpPropertiesTable->setCellWidget(n,1,editor);
            }
            case ObjectProperty::Science:

                break;

            case ObjectProperty::Double: {
                QDoubleSpinBox *editor = new QDoubleSpinBox();
                editor->setMinimum(property->getMinValue());
                editor->setMaximum(property->getMaxValue());
                editor->setValue(property->getValue().toInt());
                mpPropertiesTable->setCellWidget(n,1,editor);
                break;
            }

            case ObjectProperty::DropDown: {
                QComboBox *editor = new QComboBox();
                QStringList items = property->getValues().split(";");
                editor->addItems(property->getValues().split(";"));
                editor->setCurrentIndex(items.indexOf(property->getValue()));
                mpPropertiesTable->setCellWidget(n,1,editor);
                break;
            }
            case ObjectProperty::IndexedValue:
                break;

            case ObjectProperty::String:
                break;
            }
        }
    }

}

void PropertiesEditor::setMaxTableHeight() {
    int maxHeight = mpPropertiesTable->horizontalHeader()->height();
    if (mpPropertiesTable->rowCount() > 0) {
        for (int i = 0; i < mpPropertiesTable->rowCount(); i++) {
            maxHeight += mpPropertiesTable->rowHeight(i) + 1;
        }

        mpPropertiesTable->setVisible(true);
    }
    mpPropertiesTable->setMaximumHeight(maxHeight);
}

QTableWidget *PropertiesEditor::getTablePointer() const {
    return mpPropertiesTable;
}

/*****************************************************************************\
 *  FUNCTION    :   addTableRow
 *  PARAMETERS  :   const QString &key The key value (left column) in the Table Widget.
 *                  const QString &value The value (right column) in the Table Widget
 *                  bool bValueRO Indicates whether the value must be read only or not (default)
 *                  int maxkeyval The maximum index of the key. For IndexedValues.
 *                  int maxvalue The maximum value of the right spinbox.
 *
 *  This function adds a row to the property table widget.
\****************************************************************************/
void PropertiesEditor::addTableRow(const SUI::ObjectType::Type &objectType, SUI::ObjectProperty *property , const bool &readOnly, int maxKeyValue, int maxValue)
{
    int rowNr = mpPropertiesTable->rowCount();
    QTableWidgetItem *keyItem = new QTableWidgetItem(property->getDisplayName());
    keyItem->setToolTip(property->getDescription());
    keyItem->setFlags(Qt::NoItemFlags);
    mpPropertiesTable->insertRow(rowNr);
    mpPropertiesTable->setItem(rowNr, 0, keyItem);

    switch (property->getType()) {
    case SUI::ObjectProperty::Bool:
    {
        QComboBox *combo = new QComboBox();
        combo->addItems(QString("true;false").split(";"));
        mpPropertiesTable->setCellWidget(rowNr, 1, combo);
        combo->setCurrentIndex(property->getValue().toLower() == "false" ? 1 : 0);
        combo->setEditable(false);
        combo->setDisabled(readOnly);
        connect(combo, SIGNAL(currentIndexChanged(int)), mComboSignalMapper, SLOT(map()));
        QString signalStr = QString("%1,%2").arg(QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(property->getObjectPropertyType()))).arg(rowNr);
        mComboSignalMapper->setMapping(combo, signalStr);
        break;
    }
    case SUI::ObjectProperty::DropDown:
    {
        QComboBox *combo = new QComboBox();
        if (property->getObjectPropertyType() == SUI::ObjectPropertyTypeEnum::DefaultState) //DefaultList is a composed list of Images and States
        {
            //Number of items (States + Images) has to be even; an image for every state
            QStringList props = property->getValues().split(";");
            if (!props.at(0).isEmpty()) {
                QStringList States;
                QStringList Imgs;
                int nmbrOfStates = props.size() / 2;
                if ((props.size() % 2) == 0) {
                    for (int i = 0; i < nmbrOfStates; i++) {
                        States << props.at(i);
                        Imgs << props.at(i + nmbrOfStates);
                    }
                }
                int i = 0;
                BOOST_FOREACH(QString icon, Imgs) {
                    combo->addItem(QIcon(QString("%1").arg(QDir(":/controls/Controls/").filePath(icon))), States.at(i++), "");
                }
            }
            //in case the content of the combobox has changed and does no longer contain
            //the mValue, we assume that mCurrentIndex holds the correct index. see RticStateWidget.
            if ((combo->findText(property->getValue()) == -1)) {
                if (combo->count() > property->getCurrentIndex()) {
                    property->setValue(combo->itemText(property->getCurrentIndex()));
                }
                else {
                    combo->setCurrentIndex(0);
                    property->setValue(combo->itemText(0));
                }
            }
            else {
                combo->setCurrentIndex(combo->findText(property->getValue()));
            }
        }
        else {
            combo->addItems(property->getValues().split(";"));
            combo->setCurrentIndex(property->getValue() != "" ? combo->findText(property->getValue()) : 0);
        }
        mpPropertiesTable->setCellWidget(rowNr, 1, combo);
        combo->setEditable(false);
        combo->setDisabled(readOnly);
        connect(combo, SIGNAL(currentIndexChanged(int)), mComboSignalMapper, SLOT(map()));
        QString signalStr = QString("%1,%2").arg(QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(property->getObjectPropertyType()))).arg(rowNr);
        mComboSignalMapper->setMapping(combo, signalStr);
        break;
    }
    case SUI::ObjectProperty::File:
    {
        QPushButton *pushButton = new QPushButton();
        pushButton->setText("Select File");
        mpPropertiesTable->setCellWidget(rowNr, 1, pushButton);
        pushButton->setDisabled(readOnly);
        connect(pushButton, SIGNAL(clicked()), mPushSignalMapper, SLOT(map()));
        QString signalStr = QString("%1,%2").arg(QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(property->getObjectPropertyType()))).arg(rowNr);
        mPushSignalMapper->setMapping(pushButton, signalStr);
        break;
    }
    case SUI::ObjectProperty::Number:
    {
        if (property->getObjectPropertyType() == SUI::ObjectPropertyTypeEnum::MinValue ||
            property->getObjectPropertyType() == SUI::ObjectPropertyTypeEnum::MaxValue ||
            property->getObjectPropertyType() == SUI::ObjectPropertyTypeEnum::StepSize)
        {
            if (objectType == SUI::ObjectType::DoubleSpinBox) {
               createDoubleSpinBox(property,rowNr,readOnly);
            }
            else if (objectType == SUI::ObjectType::ScienceSpinBox) {
                createScienceSpinBox(property,rowNr,readOnly);
            }
            else {
                createSpinBox(property,rowNr,readOnly);
            }
        }
        else {
            createSpinBox(property,rowNr,readOnly);
        }
        break;
    }
    case SUI::ObjectProperty::Double:
        createDoubleSpinBox(property,rowNr,readOnly);
        break;
    case SUI::ObjectProperty::Science:
        createScienceSpinBox(property,rowNr,readOnly);
        break;

    case SUI::ObjectProperty::IndexedValue:
    {
        QSpinBox *keySP = new QSpinBox();
        keySP->setPrefix(QString("%1 ").arg(QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(property->getObjectPropertyType()))));
        keySP->setMinimum(1);
        keySP->setMaximum(maxKeyValue + 1);
        QSpinBox *valSP = new QSpinBox();
        valSP->setMaximum(maxValue ? maxValue : 99);
        mpPropertiesTable->setCellWidget(rowNr, 0, keySP);
        mpPropertiesTable->setCellWidget(rowNr, 1, valSP);
        connect(keySP, SIGNAL(valueChanged(int)), mSpinboxKeyMapper, SLOT(map()));
        connect(valSP, SIGNAL(valueChanged(int)), mSpinboxIndexedValueSignalMapper, SLOT(map()));
        QString valStr = QString("%1,%2").arg(QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(property->getObjectPropertyType()))).arg(rowNr);
        mSpinboxKeyMapper->setMapping(keySP, valStr);
        mSpinboxIndexedValueSignalMapper->setMapping(valSP, valStr);
        keySP->setValue(0);
        QStringList values = property->getValue().split(';');
        if (values.size() > 0) {
            QStringList firstValue = values.first().split(',');
            if (firstValue.size() > 1) valSP->setValue(firstValue.at(1).toInt());
        }
        break;
    }
    default:
    {
        QString text = property->getValue();
        if (SUI::ObjectPropertyTypeEnum::fromString(keyItem->text().toStdString()) == SUI::ObjectPropertyTypeEnum::ObjectType) {
            WidgetTypeText = text;
        }
        QTableWidgetItem *valItem = new QTableWidgetItem(text);
        if (readOnly) valItem->setFlags(Qt::NoItemFlags );

        mpPropertiesTable->setItem(rowNr, 1, valItem);
        break;
    }
    }
}

void PropertiesEditor::addNonPropertyToTable(QString  key, SUI::ObjectProperty::ObjectPropertyDataType property, QStringList list)
{
    int rowNr = mpPropertiesTable->rowCount();
    QTableWidgetItem *keyItem = new QTableWidgetItem(key);
    keyItem->setFlags(Qt::NoItemFlags);
    mpPropertiesTable->insertRow(rowNr);
    mpPropertiesTable->setItem(rowNr, 0, keyItem);

    if (property == SUI::ObjectProperty::File)
    {
        QPushButton *pushButton = new QPushButton();
        pushButton->setText(key);
        mpPropertiesTable->setCellWidget(rowNr, 1, pushButton);
        connect(pushButton, SIGNAL(clicked()), mPushSignalMapper, SLOT(map()));
        QString signalStr = QString("%1,%2").arg(key).arg(rowNr);
        mPushSignalMapper->setMapping(pushButton, signalStr);
    }
    else if (property == SUI::ObjectProperty::DropDown)
    {
        QComboBox *combo = new QComboBox();
        mpPropertiesTable->setCellWidget(rowNr, 1, combo);
        combo->setEditable(false);
        combo->addItems(list);
        connect(combo, SIGNAL(currentIndexChanged(int)), mComboSignalMapper, SLOT(map()));
        QString signalStr = QString("%1,%2").arg(key).arg(rowNr);
        combo->setCurrentIndex(combo->findText(WidgetTypeText));
        mComboSignalMapper->setMapping(combo, signalStr);
    }
}
/*****************************************************************************\
 *  FUNCTION    :   clearTable
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This function clears the Table Widget.
\****************************************************************************/
void PropertiesEditor::clearTable() {
    while (mpPropertiesTable->rowCount() > 0) {
        mpPropertiesTable->removeRow(0);
    }
}

/*****************************************************************************\
 *  FUNCTION    :   onComboValueChanged
 *  PARAMETERS  :   QString mapStr
 *  RETURN      :   void
 *
 *  This is a SLOT function connected with the mComboSignalMapper SIGNAL. It
 *  retrieves the current value of the combobox on row number supplied in the
 *  mapStr and emits a signal with the key and value.
\****************************************************************************/
void PropertiesEditor::onComboValueChanged(QString mapStr) {
    QStringList list = mapStr.split(",");
    QComboBox *combo = (QComboBox *)mpPropertiesTable->cellWidget(list[1].toInt(), 1);
    WidgetController *curWidget = Model::instance()->getCurrentWidget();
    if ((curWidget != NULL) && (curWidget->getParent()->getObjectType() == SUI::ObjectType::TableWidget) &&  (list[0] == "Set Item Type")) {
        curWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::ObjectType, combo->currentText());
        //get item index
        int row = curWidget->getTableWidgetItemRowNr() - 1;
        int col = curWidget->getTableWidgetItemColumnNr() - 1;

        //do update on parent
        Model::instance()->setNewSelected(curWidget->getParent());
        WidgetController *curTable = Model::instance()->getCurrentWidget();
        curTable->updateTableCell(row, col, SUI::ObjectType::fromString(combo->currentText().toStdString()), SUI::AlignmentEnum::Stretch);
        curTable->renameTableWidgetItems();
    }
    else {
        if (list[0] == "Set Item Type") {
            changeSpinBox(SUI::ObjectType::fromString(combo->currentText().toStdString()));
        }
        else {
            emit propertyValueChanged(list[0], combo->currentText());
        }
    }
}

/*****************************************************************************\
 *  FUNCTION    :   onSpinboxValueChanged
 *  PARAMETERS  :   QString mapStr
 *  RETURN      :   void
 *
 *  This is a SLOT function connected with the mSpinboxSignalMapper SIGNAL. It
 *  retrieves the current value of the spinbox on row number supplied in the
 *  mapStr and emits a signal with the key and value.
\****************************************************************************/
void PropertiesEditor::onSpinboxValueChanged(QString mapStr)
{
    QStringList list = mapStr.split(",");
    QDoubleSpinBox *spinbox = (QDoubleSpinBox *)mpPropertiesTable->cellWidget(list[1].toInt(), 1);
    emit propertyValueChanged(list[0], spinbox->text());
}

void PropertiesEditor::onButtonPushed(QString mapStr)
{
    WidgetController *curWidget = Model::instance()->getCurrentWidget();
    QStringList list = mapStr.split(",");
    if (list[0] == "Treewidget Edit")
    {
        onTreeWidgetEdit();
    }
    else if (list[0] == "Set Horizontal Header")
    {
        onAddHorizontalHeader();
    }
    else if (list[0] == "Set Vertical Header")
    {
        onAddVerticalHeader();
    }
    else if (list[0] == "Add states")
    {
        onAddStates();
    }
    else if (list[0] == "Set Item Type")
    {
        if (curWidget != NULL)
        {
            curWidget->onCustomContextItemMenu("setItemPropAct");
        }
    }
    else
    {
        if ((curWidget != NULL) && (curWidget->getObjectType() == SUI::ObjectType::TabPage))
        {
            showTabImages();
        }
        else
        {
            QString     file = QFileDialog::getOpenFileName(this, "Select File");
            if (!file.isEmpty())
            {
                if (list[0] == "ImageData" || list[0] == "ImageDataPressed")
                {
                    QImage img;
                    img.load(file);
                    QPixmap pixmap = QPixmap::fromImage(img);
                    QByteArray bytes;
                    QBuffer buffer(&bytes);
                    buffer.open(QIODevice::ReadWrite);
                    pixmap.save(&buffer, "PNG");
                    QString image = bytes.toBase64();
                    emit propertyValueChanged(list[0], image);
                }
                else if (list[0] == "HelpFile")
                {
                    QFile f(file);
                    QFileInfo fi(f);
                    if (!fi.exists())
                    {
                        QMessageBox msgBox;
                        msgBox.setText("File does not exist");
                        msgBox.exec();
                    }
                    else if (fi.suffix() != "txt")
                    {
                        QMessageBox msgBox;
                        msgBox.setText("File should have extention .txt");
                        msgBox.exec();
                    }
                    else if (!f.open(QFile::ReadOnly | QFile::Text))
                    {
                        QMessageBox msgBox;
                        msgBox.setText("Cannot open file");
                        msgBox.exec();
                    }
                    else
                    {
                        emit propertyValueChanged("Text", file);
                        WidgetController *wdgt = Model::instance()->getCurrentWidget(); //update properties
                        Model::instance()->getModelHandler()->newWidgetProperties(wdgt);
                    }
                }
                else if (list[0] == "SvgImage")
                {
                    QFile f(file);
                    QFileInfo fi(f);
                    if (!fi.exists())
                    {
                        QMessageBox msgBox;
                        msgBox.setText("File does not exist");
                        msgBox.exec();
                    }
                    else if (fi.suffix() != "svg")
                    {
                        QMessageBox msgBox;
                        msgBox.setText("File should have extention .svg");
                        msgBox.exec();
                    }
                    else if (!f.open(QFile::ReadOnly | QFile::Text))
                    {
                        QMessageBox msgBox;
                        msgBox.setText("Cannot open file");
                        msgBox.exec();
                    }
                    else
                    {
                        emit propertyValueChanged("SvgFilename", file);
                        WidgetController *wdgt = Model::instance()->getCurrentWidget(); //update properties
                        Model::instance()->getModelHandler()->newWidgetProperties(wdgt);
                    }
                }
            }
        }
    }
}

/*****************************************************************************\
 *  FUNCTION    :   onSpinboxIndexedValueChanged
 *  PARAMETERS  :   QString mapStr
 *  RETURN      :   void
 *
 *  This is a SLOT function connected with the mSpinboxIndexedValueSignalMapper
 *  SIGNAL. It retrieves the current value of the spinbox on row number
 *  supplied in the mapStr, the index of the IndexedValue key and emits a
 *  signal with the key, its index and value.
\****************************************************************************/
void PropertiesEditor::onSpinboxIndexedValueChanged(QString mapStr)
{
    QStringList keyList = mapStr.split(",");
    QSpinBox *keySP = (QSpinBox *)mpPropertiesTable->cellWidget(keyList[1].toInt(), 0);
    QSpinBox *valSP = (QSpinBox *)mpPropertiesTable->cellWidget(keyList[1].toInt(), 1);
    QString valStr = QString("%1,%2").arg(keySP->value() - 1).arg(valSP->value());
    emit propertyIndexedValueChanged(QString("%1").arg(keyList[0]), valStr);
}

/*****************************************************************************\
 *  FUNCTION    :   onSpinboxKeyChanged
 *  PARAMETERS  :   QString mapStr
 *  RETURN      :   void
 *
 *  This is a SLOT function connected with the mSpinboxKeyMapper SIGNAL. It
 *  retrieves the current index of the left spinbox on row number supplied in
 *  the mapStr and emits a signal with the key and its index
\****************************************************************************/
void PropertiesEditor::onSpinboxKeyChanged(QString mapStr)
{
    QStringList keyList = mapStr.split(",");
    int keyVal = qobject_cast<QSpinBox *>(mpPropertiesTable->cellWidget(keyList[1].toInt(), 0))->value() - 1;
    emit getNewDoubleValue(keyList.at(0), QString::number(keyVal));
}

/*****************************************************************************\
 *  FUNCTION    :   onReceiveDoubleValue
 *  PARAMETERS  :   QString key
 *                      The key
 *                  QString val
 *                      The new value for the left spinbox.
 *  RETURN      :   void
 *
 *  This is a SLOT function connected with the Mainwindow::sendDoubleValue
 *  SIGNAL. It searches the left spinbox with the given key and fills the
 *  right spinbox with value val.
\****************************************************************************/
void PropertiesEditor::onReceiveDoubleValue(QString key, QString val) {
    for (int ind = 0; ind < mpPropertiesTable->rowCount(); ind++) {
        QSpinBox *keySP = qobject_cast<QSpinBox *>(mpPropertiesTable->cellWidget(ind, 0));
        if (keySP != NULL) {
            if (keySP->prefix().trimmed() == key) {
                QSpinBox *valSP = qobject_cast<QSpinBox *>(mpPropertiesTable->cellWidget(ind, 1));
                if (valSP != NULL) {
                    valSP->setValue(val.toInt());
                    break;
                }
            }
        }
    }
}

/*****************************************************************************\
 *  FUNCTION    :   onAddStates
 *  PARAMETERS  :
 *  RETURN      :   void
 *
 *  This is a SLOT function.
\*****************************************************************************/
void PropertiesEditor::onAddStates()
{
    WidgetController *curWidget = Model::instance()->getCurrentWidget();
    WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo(curWidget, ACT_COMPLEX, "Add state");
    SUI::StateWidgetImpl *stateWidget = dynamic_cast<SUI::StateWidgetImpl *>(curWidget->getBaseWidget());

    std::list<std::string> tStateList = stateWidget->getSupportedStates();
    QStringList StateList;
    for (std::list<std::string>::const_iterator iterator = tStateList.begin(); iterator != tStateList.end(); ++iterator) {
        StateList.append(QString::fromStdString(*iterator));
    }
    QString *aStateList = new QString(StateList.join(";"));

    std::list<std::string> tImageList = stateWidget->getStatesImages();
    QStringList ImageList;
    for (std::list<std::string>::const_iterator iterator = tImageList.begin(); iterator != tImageList.end(); ++iterator) {
        ImageList.append(QString::fromStdString(*iterator));
    }
    QString *aImageList = new QString(ImageList.join(";"));

    //FIXME a separate form must be made, StateTableWidget, with a separate class to isolate the functionality.
    mStateImageTable = new QTableWidget(this);
    QList<QIcon> *IconList = new QList<QIcon>;
    QFormLayout *Layout = new QFormLayout;
    QPushButton *addState = new QPushButton("Add State");
    QPushButton *delState = new QPushButton("Delete State");
    QDialogButtonBox *buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
    QDialog *StateTableEntryDialog = new QDialog(this);

    //get all resource images
    BOOST_FOREACH(QString icon, QDir(":/controls/Controls/").entryList())
    {
        IconList->append(QIcon(QString("%1").arg(QDir(":/controls/Controls/").filePath(icon))));
    }

    //init table with current StateWidget information
    if (StateList.size() != ImageList.size())
    {
        StateList.clear();
        ImageList.clear();
    }

    mStateImageTable->setRowCount(StateList.count());
    mStateImageTable->setColumnCount(2); //State and image

    int i = 0;
    BOOST_FOREACH(QString item, StateList)
    {
        QLineEdit *state = new QLineEdit(item);
        QComboBox *combo = new QComboBox();
        //build combobox
        BOOST_FOREACH(QIcon icon, *IconList)
        {
            combo->addItem(icon, "", "");
        }
        //Find out which item to show in combo
        if (QDir(":/controls/Controls/").entryList().contains(ImageList.at(i)) == true)
        {
            combo->setCurrentIndex(QDir(":/controls/Controls/").entryList().indexOf(ImageList.at(i)));
        }

        mStateImageTable->setCellWidget(i, STATECOLUMN, state);
        mStateImageTable->setCellWidget(i, STATEIMAGECOLUMN, combo);
        i++;
    }
    buttonBox->addButton(addState, QDialogButtonBox::ActionRole);
    buttonBox->addButton(delState, QDialogButtonBox::ActionRole);
    Layout->addWidget(mStateImageTable);
    Layout->addWidget(buttonBox);
    Layout->setSizeConstraint(QLayout::SetFixedSize);
    connect(buttonBox, SIGNAL(accepted()), StateTableEntryDialog, SLOT(accept()));
    connect(buttonBox, SIGNAL(rejected()), StateTableEntryDialog, SLOT(reject()));
    connect(buttonBox, SIGNAL(clicked(QAbstractButton *)), this, SLOT(ClickedAddStateTableRow(QAbstractButton *)));
    connect(buttonBox, SIGNAL(clicked(QAbstractButton *)), this, SLOT(ClickedDelStateTableRow(QAbstractButton *)));
    StateTableEntryDialog->setLayout(Layout);
    StateTableEntryDialog->setWindowTitle("Edit States");
    StateTableEntryDialog->setStyleSheet(QString::fromStdString(SUI::StyleSheet::getInstance()->getStyleSheet()));

    if (StateTableEntryDialog->exec() > 0)
    {
        //Rebuilt State- and ImageList
        QStringList States;
        QStringList Images;
        for (int i = 0; i < mStateImageTable->rowCount(); i++)
        {
            QString state = dynamic_cast<QLineEdit *>(mStateImageTable->cellWidget(i, STATECOLUMN))->text();
            if (state.isEmpty())
            {
                //empty state will be removed
            }
            else if (state.contains(";") == true)
            {
                SUI::Logger::logError(QString("StateWidget %1 State '%2' with invalid character removed").
                                      arg(QString::fromStdString(curWidget->getBaseWidget()->getId())).arg(state));
            }
            else if (States.contains(state) == true)
            {
                // Warning: state can not be duplicated
                SUI::Logger::logWarning(QString("StateWidget %1 duplicated State '%2' removed").
                                        arg(QString::fromStdString(curWidget->getBaseWidget()->getId())).arg(state));
            }
            else
            {
                States.append(state); //collect States
                QString image = QDir(":/controls/Controls/").entryList().at(dynamic_cast<QComboBox *>(mStateImageTable->cellWidget(i, STATEIMAGECOLUMN))->currentIndex()); //get selected Image
                Images.append(image);
            }
        }

        aStateList->clear();
        *aStateList = States.join( ";" );
        tStateList.clear();
        BOOST_FOREACH(const  QString str, States) {
            tStateList.push_back(str.toStdString());
        }

        aImageList->clear();
        *aImageList = Images.join(";");
        tImageList.clear();
        BOOST_FOREACH(const  QString str, Images) {
            tImageList.push_back(str.toStdString());
        }
    }

    //cleanup
    delete mStateImageTable;
    delete IconList;
    delete Layout;
    delete addState;
    delete delState;
    delete buttonBox;
    delete StateTableEntryDialog;

    stateWidget->addStates(tStateList); //update widget StateList
    stateWidget->addImages(tImageList); //update widget ImageList
    stateWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::StateList, *aStateList); //update widget StateList property
    stateWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::ImageList, *aImageList); //update widget ImageList property
    stateWidget->setPropertyValues(SUI::ObjectPropertyTypeEnum::DefaultState, (QString("%1;%2").arg(*aStateList).arg(*aImageList)));

    Model::instance()->getModelHandler()->newWidgetProperties(curWidget);
    Model::instance()->setNewSelected(curWidget);

    //Editing StateList could have changed current State, so we set it here
    stateWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::DefaultState, stateWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::DefaultState));
    UndoHandler::instance()->finishUndoInfo(wsState, curWidget);
    UndoHandler::instance()->addToUndoGroup(wsState);
    delete aStateList;
    delete aImageList;
    curWidget->updatePixmap();
}

/*****************************************************************************\
 *  FUNCTION    :   onTreeWidgetEdit
 *  PARAMETERS  :   n.a.
 *  RETURN      :   void
 *
 *  This is a SLOT function, connected to the ui->actionTreewidget_edit SIGNAL. It shows
 *  the TreeView dialog.
\*****************************************************************************/
void PropertiesEditor::onTreeWidgetEdit()
{
    WidgetController *curWidget = Model::instance()->getCurrentWidget();
    if (curWidget != NULL)
    {
        treeWidgetDialog *Tree = new treeWidgetDialog(curWidget, this);
        Tree->setStyleSheet(QString::fromStdString(SUI::StyleSheet::getInstance()->getStyleSheet()));
        Tree->exec();
        Tree->deleteLater();
    }
}

void PropertiesEditor::onAddHorizontalHeader()
{
    WidgetController *curWidget = Model::instance()->getCurrentWidget();
    if (curWidget != NULL)
    {
        headerTreeWidgetDialog *Tree = new headerTreeWidgetDialog(curWidget, this, "HorizonHeaderTags");
        Tree->setStyleSheet(QString::fromStdString(SUI::StyleSheet::getInstance()->getStyleSheet()));
        Tree->exec();
        Tree->deleteLater();
    }
}

void PropertiesEditor::onAddVerticalHeader()
{
    WidgetController *curWidget = Model::instance()->getCurrentWidget();
    if (curWidget != NULL)
    {
        headerTreeWidgetDialog *Tree = new headerTreeWidgetDialog(curWidget, this, "VerticalHeaderTags");
        Tree->setStyleSheet(QString::fromStdString(SUI::StyleSheet::getInstance()->getStyleSheet()));
        Tree->exec();
        Tree->deleteLater();
    }
}

/*****************************************************************************\
 *  FUNCTION    :   changeSpinBox
 *  PARAMETERS  :   wSpinBox
 *                    - The kind if spinbox that the current needs to change to
 *  RETURN      :   void
 *
 *  This is a function that changes the selected spinbox to a spinbox of another
 *  kind. It copies the necessary properties.
\*****************************************************************************/
void PropertiesEditor::changeSpinBox(SUI::ObjectType::Type spinBoxType)
{
    WidgetController *wdgt = Model::instance()->getCurrentWidget();
    if (wdgt != NULL)
    {
        WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo(wdgt, ACT_COMPLEX, "Spinbox type");
        WidgetDefinition *WCInfo = new WidgetDefinition();
        WCInfo->setPropertyValue(SUI::ObjectPropertyTypeEnum::ObjectType, QString::fromStdString(SUI::ObjectType::toString(spinBoxType)));
        WCInfo->setPropertyValue(SUI::ObjectPropertyTypeEnum::Bold, wdgt->getPropertyValue(SUI::ObjectPropertyTypeEnum::Bold));;
        WCInfo->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, wdgt->getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos));
        WCInfo->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, wdgt->getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos));
        WCInfo->setPropertyValue(SUI::ObjectPropertyTypeEnum::Enable, wdgt->getPropertyValue(SUI::ObjectPropertyTypeEnum::Enable));
        WCInfo->setPropertyValue(SUI::ObjectPropertyTypeEnum::Visible, wdgt->getPropertyValue(SUI::ObjectPropertyTypeEnum::Visible));
        WCInfo->setPropertyValue(SUI::ObjectPropertyTypeEnum::StepSize, wdgt->getPropertyValue(SUI::ObjectPropertyTypeEnum::StepSize));
        WCInfo->setPropertyValue(SUI::ObjectPropertyTypeEnum::MaxValue, wdgt->getPropertyValue(SUI::ObjectPropertyTypeEnum::MaxValue));
        WCInfo->setPropertyValue(SUI::ObjectPropertyTypeEnum::MinValue, wdgt->getPropertyValue(SUI::ObjectPropertyTypeEnum::MinValue));
        WCInfo->setPropertyValue(SUI::ObjectPropertyTypeEnum::Menu, wdgt->getPropertyValue(SUI::ObjectPropertyTypeEnum::Menu));
        WCInfo->setPropertyValue(SUI::ObjectPropertyTypeEnum::TabOrder, wdgt->getPropertyValue(SUI::ObjectPropertyTypeEnum::TabOrder));
        WCInfo->setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, wdgt->getPropertyValue(SUI::ObjectPropertyTypeEnum::Text));
        WCInfo->setPropertyValue(SUI::ObjectPropertyTypeEnum::Alignment, wdgt->getPropertyValue(SUI::ObjectPropertyTypeEnum::Alignment));
        WCInfo->setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, wdgt->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width));
        WCInfo->setPropertyValue(SUI::ObjectPropertyTypeEnum::StyleSheetClass, wdgt->getPropertyValue(SUI::ObjectPropertyTypeEnum::StyleSheetClass));
        wdgt->getParent()->removeChild(wdgt);
        WidgetController *newWidgetContr = WCInfo->addToWidget(wdgt->parentWidget(), true);
        int dTabOrder = dynamic_cast<SUI::BasePageImpl *>(Model::instance()->getCurrentTopPage()->getBaseWidget())
                ->replaceTabOrderWidget(wdgt->getId(), newWidgetContr->getId());
        newWidgetContr->setPropertyValue(SUI::ObjectPropertyTypeEnum::TabOrder, QString::number(dTabOrder));
        wdgt->deleteLater();
        Model::instance()->getModelHandler()->newWidgetSelection(NULL);
        Model::instance()->getModelHandler()->newWidgetProperties(NULL);
        UndoHandler::instance()->finishUndoInfo(wsState, newWidgetContr);
        UndoHandler::instance()->addToUndoGroup(wsState);
        Model::instance()->setCurrentWidget(newWidgetContr);
        Model::instance()->setNewSelected(newWidgetContr);
    }
}

/*****************************************************************************\
 *  FUNCTION    :   showTabImages
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This function retrieves all images from the resource and executes a DialogBox
 *  from which the user can select an image. This image will be the new Icon
 *  for the (TabPage) widget.
\*****************************************************************************/
void PropertiesEditor::showTabImages()
{
    QDialog             imageDialog(this);
    QVBoxLayout *layout = new QVBoxLayout();
    QDialogButtonBox *buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
    QListWidget *listWidget = new QListWidget(this);
    QList<QIcon>        iconList;
    QStringList         nameList;
    layout->addWidget(listWidget);
    layout->addWidget(buttonBox);
    imageDialog.setLayout(layout);
    connect(buttonBox, SIGNAL(accepted()), &imageDialog, SLOT(accept()));
    connect(buttonBox, SIGNAL(rejected()), &imageDialog, SLOT(reject()));
    nameList.append(QString(""));
    iconList.append(QIcon());
    BOOST_FOREACH(QString iconName, QDir(":/controls/Controls/").entryList())
    {
        nameList.append(iconName);
        iconList.append(QIcon(QString("%1").arg(QDir(":/controls/Controls/").filePath(iconName))));
    }
    for (int ind = 0; ind < nameList.count(); ++ind)
    {
        new QListWidgetItem(iconList.at(ind), nameList.at(ind), listWidget);
    }
    if (imageDialog.exec() == QDialog::Accepted)
    {
        if(!listWidget->selectedItems().isEmpty()){
            QList<QListWidgetItem *> itemList = listWidget->selectedItems();
            QString iconName = itemList.at(0)->text();
            if (!iconName.isEmpty())
            {
                emit propertyValueChanged("ImageData", iconName);
            }
        }
    }
}

void PropertiesEditor::ClickedAddStateTableRow(QAbstractButton *but)
{
    if (but->text() == "Add State")
    {
        if (mStateImageTable != NULL)
        {
            mStateImageTable->setRowCount(mStateImageTable->rowCount() + 1);
            QLineEdit *state = new QLineEdit();
            QComboBox *combo = new QComboBox();
            //get all resource images
            QList<QIcon> *IconList = new QList<QIcon>;
            BOOST_FOREACH(QString icon, QDir(":/controls/Controls/").entryList())
            {
                QString t = QString("%1").arg(QDir(":/controls/Controls/").filePath(icon));
                QIcon img(t);
                IconList->append(img);
            }
            //build combobox
            BOOST_FOREACH(QIcon icon, *IconList)
            {
                combo->addItem(icon, "", "");
            }
            mStateImageTable->setCellWidget(mStateImageTable->rowCount() - 1, 0, state);
            mStateImageTable->setCellWidget(mStateImageTable->rowCount() - 1, 1, combo);
        }
    }
}

void PropertiesEditor::ClickedDelStateTableRow(QAbstractButton *but)
{
    if (but->text() == "Delete State")
    {
        if (mStateImageTable != NULL)
        {
            mStateImageTable->removeCellWidget(mStateImageTable->currentRow(), 0);
            mStateImageTable->removeCellWidget(mStateImageTable->currentRow(), 1);
            mStateImageTable->removeRow(mStateImageTable->currentRow());
        }
    }
}

void PropertiesEditor::createSpinBox(SUI::ObjectProperty *property, int rowNr, bool readOnly) {
    QSpinBox *spinbox = new QSpinBox();
    spinbox->setMinimum(property->getMinValue());
    spinbox->setMaximum(property->getMaxValue());
    if (property->getObjectPropertyType() == SUI::ObjectPropertyTypeEnum::Height)
    {
        spinbox->setSingleStep(10);
        spinbox->setMaximum(SUI::ObjectProperty::maxHeight);
    }
    else if (property->getObjectPropertyType() == SUI::ObjectPropertyTypeEnum::Width)
    {
        spinbox->setSingleStep(10);
        spinbox->setMaximum(SUI::ObjectProperty::maxWidth);
    }
    else if ((property->getObjectPropertyType() == SUI::ObjectPropertyTypeEnum::XPos) || (property->getObjectPropertyType() == SUI::ObjectPropertyTypeEnum::YPos))
    {
        spinbox->setSingleStep(5);
    }
    else if (property->getObjectPropertyType() == SUI::ObjectPropertyTypeEnum::MinValue ||
            property->getObjectPropertyType() == SUI::ObjectPropertyTypeEnum::MaxValue) {
        spinbox->setMinimum(INT_MIN);
        spinbox->setMaximum(INT_MAX);
    }
    else if (property->getObjectPropertyType() == SUI::ObjectPropertyTypeEnum::StepSize){
        spinbox->setMinimum(property->getDefaultValue().toInt());
    }

    mpPropertiesTable->setCellWidget(rowNr, 1, spinbox);
    spinbox->setValue(property->getValue().toInt());
    spinbox->setDisabled(readOnly);
    connect(spinbox, SIGNAL(valueChanged(int)), mSpinboxSignalMapper, SLOT(map()));
    QString signalStr = QString("%1,%2").arg(QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(property->getObjectPropertyType()))).arg(rowNr);
    mSpinboxSignalMapper->setMapping(spinbox, signalStr);
}
void PropertiesEditor::createDoubleSpinBox(SUI::ObjectProperty *property, int rowNr, bool readOnly) {
    QDoubleSpinBox *spinbox = new QDoubleSpinBox();
    spinbox->setMinimum(property->getMinValue());
    spinbox->setMaximum(property->getMaxValue());
    if (property->getObjectPropertyType() == SUI::ObjectPropertyTypeEnum::MinValue ||
            property->getObjectPropertyType() == SUI::ObjectPropertyTypeEnum::MaxValue) {
        spinbox->setMinimum(INT_MIN);
        spinbox->setMaximum(INT_MAX);
    }
    else if (property->getObjectPropertyType() == SUI::ObjectPropertyTypeEnum::StepSize) {
        spinbox->setMinimum(QString::number(0).toDouble());
    }
    mpPropertiesTable->setCellWidget(rowNr, 1, spinbox);
    spinbox->setValue(property->getValue().toDouble());
    spinbox->setDisabled(readOnly);
    connect(spinbox, SIGNAL(valueChanged(double)), mSpinboxSignalMapper, SLOT(map()));
    QString signalStr = QString("%1,%2").arg(QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(property->getObjectPropertyType()))).arg(rowNr);
    mSpinboxSignalMapper->setMapping(spinbox, signalStr);
}

void PropertiesEditor::createScienceSpinBox(SUI::ObjectProperty *property, int rowNr, bool readOnly) {
    CustomScienceSpinBox *spinbox = new CustomScienceSpinBox(NULL);
    spinbox->setMinimum(property->getMinValue());
    spinbox->setMaximum(property->getMaxValue());
    if (property->getObjectPropertyType() == SUI::ObjectPropertyTypeEnum::MinValue ||
            property->getObjectPropertyType() == SUI::ObjectPropertyTypeEnum::MaxValue) {
        spinbox->setMinimum(INT_MIN);
        spinbox->setMaximum(INT_MAX);
    }
    else if (property->getObjectPropertyType() == SUI::ObjectPropertyTypeEnum::StepSize) {
        spinbox->setMinimum(QString::number(0).toDouble());
    }
    mpPropertiesTable->setCellWidget(rowNr, 1, spinbox);
    spinbox->setValue(property->getValue().toDouble());
    spinbox->setDisabled(readOnly);
    connect(spinbox, SIGNAL(valueChanged(double)), mSpinboxSignalMapper, SLOT(map()));
    QString signalStr = QString("%1,%2").arg(QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(property->getObjectPropertyType()))).arg(rowNr);
    mSpinboxSignalMapper->setMapping(spinbox, signalStr);
}
