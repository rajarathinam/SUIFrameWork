//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for Itemwidgetdialog.
// !\description Class implementation file for Itemwidgetdialog.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "WidgetController.h"
#include "Itemwidgetdialog.h"

#include <SUITableWidgetImpl.h>
#include <boost/foreach.hpp>
#include "ui_Itemwidgetdialog.h"
#include "Model.h"

const QList<SUI::ObjectType::Type> Itemwidgetdialog::cmAllowedWidgetList = {
    SUI::ObjectType::BusyIndicator,
    SUI::ObjectType::Button,
    SUI::ObjectType::CheckBox,
    SUI::ObjectType::ColorDrop,
    SUI::ObjectType::DropDown,
    SUI::ObjectType::Label,
    SUI::ObjectType::LineEdit,
    SUI::ObjectType::ProgressBar,
    SUI::ObjectType::RadioButton,
    SUI::ObjectType::SpinBox,
    SUI::ObjectType::StateWidget,
    SUI::ObjectType::TextArea,
    SUI::ObjectType::ScrollBar,
    SUI::ObjectType::WebView,
    SUI::ObjectType::TreeWidget
    };

Itemwidgetdialog::Itemwidgetdialog(WidgetController *tablewidgcont, int choicedef, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Itemwidgetdialog),
    mTypeChanged(false),
    mBorderOnChanged(false),
    mChoiceDef(static_cast<ChoiceDefinition>(choicedef)),
    mTableWidgetContr(tablewidgcont)
{
    ui->setupUi(this);

    mWidgetTypeList.append("Default");
    BOOST_FOREACH(const SUI::ObjectType::Type &widgetType, cmAllowedWidgetList)
    {
        mWidgetTypeList.append(QString::fromStdString(SUI::ObjectType::toString(widgetType)));
    }

    BOOST_FOREACH(WidgetController *child, Model::instance()->getUserControlList())
    {
        mWidgetTypeList.append(child->getId());

        pair<QString,QString> pair;
        pair.first = child->getId();
        pair.second = child->getPropertyValue(SUI::ObjectPropertyTypeEnum::FileName);
        mUCIdFileName.insert(pair);
    }

    ui->mWidgetTypeCB->addItems(mWidgetTypeList);
    switch (mChoiceDef)
    {
    case CH_ROWS:
        ui->mRowsRB->setChecked(true);
        ui->mColumnsRB->setChecked(false);
        ui->mSingleCellRB->setChecked(false);
        onRowsToggled(true);
        break;
    case CH_COLUMNS:
        ui->mRowsRB->setChecked(false);
        ui->mColumnsRB->setChecked(true);
        ui->mSingleCellRB->setChecked(false);
        onColumnsToggled(true);
        break;
    case CH_CELL:
        ui->mRowsRB->setChecked(false);
        ui->mColumnsRB->setChecked(false);
        ui->mSingleCellRB->setChecked(true);
        onSingleCellToggled(true);
        break;
    default:
        break;
    }
    SUI::TableWidgetImpl *table = dynamic_cast<SUI::TableWidgetImpl*>(mTableWidgetContr->getBaseWidget());
    ui->mOkPB->setEnabled(table->rowCount() > 0 || table->columnCount() > 0);

    connect(ui->mRowsRB, SIGNAL(toggled(bool)), this, SLOT(onRowsToggled(bool)));
    connect(ui->mColumnsRB, SIGNAL(toggled(bool)), this, SLOT(onColumnsToggled(bool)));
    connect(ui->mSingleCellRB, SIGNAL(toggled(bool)), this, SLOT(onSingleCellToggled(bool)));
    connect(ui->mStartSB, SIGNAL(valueChanged(int)), this, SLOT(onStartSBChanged(int)));
    connect(ui->mEndSB, SIGNAL(valueChanged(int)), this , SLOT(onEndSBChanged(int)));
    connect(ui->mOkPB, SIGNAL(clicked()), this, SLOT(onOk()));
    connect(ui->mCancelPB, SIGNAL(clicked()), this, SLOT(reject()));
    connect(ui->mWidgetTypeCB, SIGNAL(currentIndexChanged(int)), this, SLOT(onTypeChanged(int)));
    connect(ui->mBorderOnCB, SIGNAL(toggled(bool)), this, SLOT(onBorderOnToggled(bool)));
}

Itemwidgetdialog::~Itemwidgetdialog()
{
    delete ui;
}

void Itemwidgetdialog::onRowsToggled(bool checked)
{
    if (checked)
    {
        mChoiceDef = CH_ROWS;
        ui->mSelectionLB->setText("Select rows");
        ui->mStartLB->setText("Start:");
        ui->mEndLB->setText("End:");
        ui->mStartSB->setMinimum(1);
        ui->mStartSB->setMaximum(dynamic_cast<SUI::TableWidgetImpl *>(mTableWidgetContr->getBaseWidget())->rowCount());
        ui->mEndSB->setMinimum(1);
        ui->mEndSB->setMaximum(dynamic_cast<SUI::TableWidgetImpl *>(mTableWidgetContr->getBaseWidget())->rowCount());
    }
}

void Itemwidgetdialog::onColumnsToggled(bool checked)
{
    if (checked)
    {
        mChoiceDef = CH_COLUMNS;
        ui->mSelectionLB->setText("Select columns");
        ui->mStartLB->setText("Start:");
        ui->mEndLB->setText("End:");
        ui->mStartSB->setMinimum(1);
        ui->mStartSB->setMaximum(dynamic_cast<SUI::TableWidgetImpl *>(mTableWidgetContr->getBaseWidget())->columnCount());
        ui->mEndSB->setMinimum(1);
        ui->mEndSB->setMaximum(dynamic_cast<SUI::TableWidgetImpl *>(mTableWidgetContr->getBaseWidget())->columnCount());
    }
}

void Itemwidgetdialog::onSingleCellToggled(bool checked)
{
    if (checked)
    {
        mChoiceDef = CH_CELL;
        ui->mSelectionLB->setText("Select single cell");
        ui->mStartLB->setText("Row:");
        ui->mEndLB->setText("Column:");
        ui->mStartSB->setMinimum(1);
        ui->mStartSB->setMaximum(dynamic_cast<SUI::TableWidgetImpl *>(mTableWidgetContr->getBaseWidget())->rowCount());
        ui->mEndSB->setMinimum(1);
        ui->mEndSB->setMaximum(dynamic_cast<SUI::TableWidgetImpl *>(mTableWidgetContr->getBaseWidget())->columnCount());
    }
}

void Itemwidgetdialog::onStartSBChanged(int val)
{
    if (mChoiceDef != CH_CELL)
    {
        if (ui->mEndSB->value() < val)
        {
            ui->mEndSB->setValue(val);
        }
    }
}

void Itemwidgetdialog::onEndSBChanged(int val)
{
    if (mChoiceDef != CH_CELL)
    {
        if (ui->mStartSB->value() > val)
        {
            ui->mStartSB->setValue(val);
        }
    }
}

void Itemwidgetdialog::onTypeChanged(int /*val*/)
{
    mTypeChanged = true;
}

void Itemwidgetdialog::onBorderOnToggled(bool /*checked*/)
{
    mBorderOnChanged = true;
}

void Itemwidgetdialog::onOk()
{
    WidgetController::ChangedItemProperties cp;
    cp.chcdef = mChoiceDef;
    cp.dStart = ui->mStartSB->value() - 1;
    cp.dEnd = ui->mEndSB->value() - 1;
    cp.bBorderOnChanged = mBorderOnChanged;
    cp.bTypeChanged = mTypeChanged;

    if(ui->mWidgetTypeCB->currentText() == "Default")
    {
        cp.sWidgetType = QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::TableWidgetItem));
    }
    else
    {
        cp.sWidgetType = ui->mWidgetTypeCB->currentText();
    }

    //check if it is a UserControl
    SUI::ObjectType::Type widgetType = SUI::ObjectType::fromString(ui->mWidgetTypeCB->currentText().toStdString());
    if ((widgetType == SUI::ObjectType::None) && (cp.sWidgetType != QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::TableWidgetItem)))) // None to indicate, User has not selected a defined control(like Button) but has selected one of the available user controls
    {
        cp.sFileName = mUCIdFileName.find(ui->mWidgetTypeCB->currentText())->second;
    }
    mTableWidgetContr->setChangedItem(cp);
    accept();
}
