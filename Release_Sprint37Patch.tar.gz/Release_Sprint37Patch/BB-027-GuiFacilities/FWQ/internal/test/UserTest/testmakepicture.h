#ifndef TESTMAKEPICTURE_H
#define TESTMAKEPICTURE_H

#include <QString>



namespace SUI {
class DialogImpl;
}

class testMakePicture
{
public:
    testMakePicture(QString aTargetWidgetID, QString aLineEdit, QString aDropDown, QString aDropDown2, SUI::DialogImpl *apGui);
private:

    QString mTargetWidgetid;
    QString mLineEdit;
    QString mDropDown;
    QString mDropDown2;
    SUI::DialogImpl  *mpGui;
public:
    void handleClicked();
};

#endif // TESTMAKEPICTURE_H
