#ifndef TESTCOPYHANDLER_H
#define TESTCOPYHANDLER_H

#include <SUIDialogImpl.h>

class testCopyHandler
{
private:
    QString mTargetWidgetid;
    QString mSourceWidgetid;
    SUI::DialogImpl  *mpGui;

public:
    void onTextChanged();
    void onTextChanged(const std::string &);
    void onPlaceHolderTextChanged();
    void handleValueChanged();
    void handleValueChanged(const std::string &value);
    testCopyHandler(QString aSourceWidgetID, QString aTargetWidgetID , SUI::DialogImpl *apGui);
    void handleEditingFinished();
};

class testTextEditedHandler
{
public:
    testTextEditedHandler(QString lblID, SUI::DialogImpl *apGui);

    void    handleTextEdited(std::string newtext);

private:
    QString     mLabelID;
    SUI::DialogImpl      *mpGui;
};

#endif // TESTCOPYHANDLER_H
