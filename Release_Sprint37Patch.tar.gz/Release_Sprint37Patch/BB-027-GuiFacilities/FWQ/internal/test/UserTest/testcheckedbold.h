#ifndef TESTCHECKEDBOLD_H
#define TESTCHECKEDBOLD_H

#include <QString>

namespace SUI {
class DialogImpl;
}

class testCheckedBold
{
    QString mWidgetID;
    SUI::DialogImpl  *mpGui;
public:

    testCheckedBold(QString aWidgetID, SUI::DialogImpl *apGui);
    void handleCheckedChanged(bool checked);
};

#endif // TESTCHECKEDBOLD_H
