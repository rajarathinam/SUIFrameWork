#ifndef TESTCOLORHANDLER_H
#define TESTCOLORHANDLER_H

#include <SUIDialogImpl.h>

class testColorHandler
{
public:
    QString mTargetWidgetid;
    QString mSourceWidgetid;
    SUI::DialogImpl  *mpGui;
public:
    void handleClicked();
    void handleValueChanged();
    testColorHandler(QString aSourceWidgetID, QString aTargetWidgetID , SUI::DialogImpl *apGui);
};

#endif // TESTCOLORHANDLER_H
