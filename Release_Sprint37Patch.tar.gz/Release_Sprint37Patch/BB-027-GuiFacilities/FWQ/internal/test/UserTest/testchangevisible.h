#ifndef TESTCHANGEVISIBLE_H
#define TESTCHANGEVISIBLE_H

#include "SUIDialogImpl.h"

class testChangeVisible
{
public:
    testChangeVisible(QString aSourcWidgetID, SUI::DialogImpl *apGui);
    void handleImageWidgetChangeVisibility(bool Widgetchanged);
private:
    QString mSourceWidgetid1;
    SUI::DialogImpl *mpGui;
};

#endif // TESTCHANGEVISIBLE_H
