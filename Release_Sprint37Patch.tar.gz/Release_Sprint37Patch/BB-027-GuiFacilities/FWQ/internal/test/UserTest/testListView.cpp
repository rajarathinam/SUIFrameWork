#include "testListView.h"

#include <SUIICheckable.h>
#include <SUIIText.h>
#include <SUIINumeric.h>

//ListView Manipulation test
testListView::testListView(QString aSourceWidgetID, QString aTargetWidgetID, SUI::DialogImpl *apGui, testListView::Act aAction):
    mTargetWidgetid(aTargetWidgetID),
    mSourceWidgetid(aSourceWidgetID),
    mpGui(apGui),
    mAction(aAction)
{
}

void testListView::handleClicked()
{
    SUI::ListView *lsvWidget;
    QString QtText;
    std::list<std::string> itemList;
    QStringList itemsLst;
    SUI::IText *textWidget = NULL;
    SUI::ICheckable *checkedWidget = NULL;
    SUI::INumeric<int> *widgetNum = NULL;

    switch (mAction)
    {
    case testListView::ADD:
        lsvWidget = mpGui->getObjectList()->getObject<SUI::ListView>(mTargetWidgetid.toStdString());
        textWidget = mpGui->getObjectList()->getObject<SUI::IText>(mSourceWidgetid.toStdString());
        if (lsvWidget && textWidget)
        {
            QtText = QString::fromStdString(textWidget->getText());
            itemsLst = QtText.split(";");
            foreach(QString item, itemsLst)
            {
                itemList.push_back(item.toStdString());
            }
            lsvWidget->addItems(itemList);
        }
        break;
    case testListView::REMOVE:
        lsvWidget = mpGui->getObjectList()->getObject<SUI::ListView>(mTargetWidgetid.toStdString());
        textWidget = mpGui->getObjectList()->getObject<SUI::IText>(mSourceWidgetid.toStdString());
        if (lsvWidget && textWidget)
        {
            QtText = QString::fromStdString(textWidget->getText());
            foreach(QString item, QtText.split(";"))
            {
                itemList.push_back(item.toStdString());
            }
            lsvWidget->removeItems(itemList);
        }
        break;
    case testListView::GET:
        textWidget = mpGui->getObjectList()->getObject<SUI::IText>(mTargetWidgetid.toStdString());
        lsvWidget = mpGui->getObjectList()->getObject<SUI::ListView>(mSourceWidgetid.toStdString());
        if (lsvWidget && textWidget)
        {
            itemList = lsvWidget->getSelectedItems();
            foreach(std::string item, itemList)
            {
                itemsLst.append(QString::fromStdString(item));
            }
            QtText = itemsLst.join(";");
            textWidget->clearText();
            textWidget->setText(QtText.toStdString());
        }
        break;
    case testListView::CLEAR:
        lsvWidget = mpGui->getObjectList()->getObject<SUI::ListView>(mSourceWidgetid.toStdString());
        if (lsvWidget)
        {
            lsvWidget->clearItems();
        }
        break;
    case testListView::SETFILTER:
        lsvWidget = mpGui->getObjectList()->getObject<SUI::ListView>(mTargetWidgetid.toStdString());
        textWidget = mpGui->getObjectList()->getObject<SUI::IText>(mSourceWidgetid.toStdString());
        if (lsvWidget && textWidget)
        {
            QtText = QString::fromStdString(textWidget->getText());
            checkedWidget = mpGui->getObjectList()->getObject<SUI::ICheckable>("cbx825");
            if (checkedWidget)
            {
                lsvWidget->setFilter(QtText.toStdString(), true, -1, checkedWidget->isChecked());
            }
        }
        break;
    case testListView::SELECT:
        lsvWidget = mpGui->getObjectList()->getObject<SUI::ListView>(mTargetWidgetid.toStdString());
        widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<int>>(mSourceWidgetid.toStdString());
        if (lsvWidget && widgetNum)
        {
            lsvWidget->selectItem(widgetNum->getValue());
        }
        break;
    default:
        break;
    }
}

void testListView::handleSelectionChanged()
{
    QStringList itemList;
    SUI::ListView *list = mpGui->getObjectList()->getObject<SUI::ListView>(mSourceWidgetid.toStdString());
    if (list)
    {
        foreach(std::string item, list->getSelectedItems())
        {
            itemList.append(QString::fromStdString(item));
        }
        QString text = itemList.join(";");
        SUI::IText *textWidget = mpGui->getObjectList()->getObject<SUI::IText>(mTargetWidgetid.toStdString());
        if (textWidget)
        {
            textWidget->setText(text.toStdString());
        }
    }
}
