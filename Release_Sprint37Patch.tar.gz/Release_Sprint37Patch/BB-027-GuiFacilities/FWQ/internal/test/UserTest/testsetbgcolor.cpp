#include "testsetbgcolor.h"

#include <SUIIText.h>
#include <SUIIBGColorable.h>
#include <SUIDropDown.h>
#include <SUIGroupBox.h>

void testSetBGColor::handleClicked()
{
    SUI::DropDown     *textWidget = mpGui->getObjectList()->getObject<SUI::DropDown>(mTargetWidgetid.toStdString());
    SUI::IBGColorable  *colorWidget = mpGui->getObjectList()->getObject<SUI::IBGColorable>(mSourceWidgetid.toStdString());
    if (textWidget && colorWidget)
    {
        std::string text = textWidget->getSelectedItems().front();
        if (text == "Blue")
        {
            colorWidget->setBGColor(SUI::ColorEnum::Blue);
        }
        else if (text == "Green")
        {
            colorWidget->setBGColor(SUI::ColorEnum::Green);
        }
        else if (text == "Red")
        {
            colorWidget->setBGColor(SUI::ColorEnum::Red);
        }
        else if (text == "Gray")
        {
            colorWidget->setBGColor(SUI::ColorEnum::Gray);
        }
        else if (text == "Yellow")
        {
            colorWidget->setBGColor(SUI::ColorEnum::Yellow);
        }
        else if (text == "Standard")
        {
            colorWidget->setBGColor(SUI::ColorEnum::Standard);
        }
        else if (text == "Orange")
        {
            colorWidget->setBGColor(SUI::ColorEnum::Orange);
        }
        else
        {
            colorWidget->setBGColor(SUI::ColorEnum::Black);
        }
    }
}

void testSetBGColor::handleValueChanged()
{

}

testSetBGColor::testSetBGColor(QString aSourceWidgetID, QString aTargetWidgetID, SUI::DialogImpl *apGui) :
    mTargetWidgetid(aTargetWidgetID),
    mSourceWidgetid(aSourceWidgetID),
    mpGui(apGui)
{
}


testCheckHover::testCheckHover(QString aWidgetID, QString aColorDropID,SUI::DialogImpl *apGui) :
    mWidgetID(aWidgetID),
    mColorDropID(aColorDropID),
    mpGui(apGui)
{
}

#include "SUIBaseObject.h"
#include "SUIObjectFactory.h"
#include "SUIGroupBoxImpl.h"
void testCheckHover::handleCheckedChanged(bool checked)
{
    SUI::GroupBox *widgetGbox = mpGui->getObjectList()->getObject<SUI::GroupBox>(mWidgetID.toStdString());
    SUI::DropDown *colorWidget = mpGui->getObjectList()->getObject<SUI::DropDown>(mColorDropID.toStdString());
    if (widgetGbox){
        std::string text = colorWidget->getSelectedItems().front();
        if (text == "Blue")
        {
            widgetGbox->setHover(checked, SUI::ColorEnum::Blue);
        }
        else if (text == "Green")
        {
            widgetGbox->setHover(checked, SUI::ColorEnum::Green);
        }
        else if (text == "Red")
        {
            widgetGbox->setHover(checked, SUI::ColorEnum::Red);
        }
        else if (text == "Gray")
        {
            widgetGbox->setHover(checked, SUI::ColorEnum::Gray);
        }
        else if (text == "Yellow")
        {
            widgetGbox->setHover(checked, SUI::ColorEnum::Yellow);
        }
        else if (text == "Standard")
        {
            widgetGbox->setHover(checked, SUI::ColorEnum::Standard);
        }
        else
        {
            widgetGbox->setHover(checked, SUI::ColorEnum::Black);
        }
    }
}
