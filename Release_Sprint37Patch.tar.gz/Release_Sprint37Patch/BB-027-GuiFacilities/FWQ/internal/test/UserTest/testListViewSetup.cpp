#include "testListViewSetup.h"

//ListView Setup test
testListViewSetup::testListViewSetup(QString aSourceWidgetID, QString aTargetWidgetID, SUI::DialogImpl *apGui, testListViewSetup::test aMode):
    mTargetWidgetid(aTargetWidgetID),
    mSourceWidgetid(aSourceWidgetID),
    mpGui(apGui),
    mMode(aMode)
{
}


void testListViewSetup::handleClicked()
{
    SUI::ListView   *lsvWidget = mpGui->getObjectList()->getObject<SUI::ListView>(mSourceWidgetid.toStdString());
    QString         text;
    QStringList     itemList;
    if (lsvWidget)
    {
        switch (mMode)
        {
        case REMOVE:
            foreach(std::string item, lsvWidget->getSelectedItems())
            {
                itemList.append(QString::fromStdString(item));
            }

            text = itemList.join(";");
            lsvWidget->removeItems(lsvWidget->getSelectedItems());
            break;
        case ALL:
            std::list<std::string>  itemList = lsvWidget->getItems();
            QStringList txtList;
            foreach(std::string item, itemList)
            {
                txtList.append(QString::fromStdString(item));
            }

            text = txtList.join(";");
            break;
        }
        SUI::IText *widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mTargetWidgetid.toStdString());
        if (widgetText)
        {
            if (mTargetWidgetid.contains("txa"))
            {
                widgetText->clearText();
            }
            widgetText->setText(text.toStdString());
        }
    }
}
