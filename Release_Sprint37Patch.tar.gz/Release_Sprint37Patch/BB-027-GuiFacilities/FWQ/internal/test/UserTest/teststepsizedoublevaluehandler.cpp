#include "teststepsizedoublevaluehandler.h"

#include <SUIINumeric.h>

testStepsizeDoubleValueHandler::testStepsizeDoubleValueHandler(QString aSourceWidgetID, QString aTargetWidgetID, SUI::DialogImpl *apGui) :
    mSourceWidgetid(aSourceWidgetID),
    mTargetWidgetid(aTargetWidgetID),
    mpGui(apGui)
{
}

void testStepsizeDoubleValueHandler::handleValueChanged()
{
    SUI::INumeric<double> *widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<double>>(mSourceWidgetid.toStdString());
    if (widgetNum)
    {
        double val = widgetNum->getValue();
        widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<double>>(mTargetWidgetid.toStdString());
        if (widgetNum)
        {
            widgetNum->setStepSize(val);
        }
    }
}
