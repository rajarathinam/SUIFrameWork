#ifndef TESTMINDOUBLEVALUEHANDLER_H
#define TESTMINDOUBLEVALUEHANDLER_H


#include "SUIDialogImpl.h"

class testMinDoubleValueHandler
{
public:
    testMinDoubleValueHandler(QString aSourceWidgetID, QString aTargetWidgetID , SUI::DialogImpl *apGui);

    void    handleValueChanged();

private:
    QString mSourceWidgetid;
    QString mTargetWidgetid;
    SUI::DialogImpl  *mpGui;
};

#endif // TESTMINDOUBLEVALUEHANDLER_H
