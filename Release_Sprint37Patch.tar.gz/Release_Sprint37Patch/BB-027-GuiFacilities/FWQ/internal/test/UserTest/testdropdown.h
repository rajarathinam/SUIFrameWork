#ifndef TESTDROPDOWN_H
#define TESTDROPDOWN_H

#include <QString>



namespace SUI {
class DialogImpl;
}

class testDropDown
{
public:
    enum Act { GET, ADD, REMOVE, GETALL, SELECT };
    testDropDown(QString aSourceWidgetID, QString aTargetWidgetID , SUI::DialogImpl *apGui, testDropDown::Act aAction);
    void handleClicked();

private:
    QString mTargetWidgetid;
    QString mSourceWidgetid;
    SUI::DialogImpl  *mpGui;
    testDropDown::Act mAction;
};

#endif // TESTDROPDOWN_H
