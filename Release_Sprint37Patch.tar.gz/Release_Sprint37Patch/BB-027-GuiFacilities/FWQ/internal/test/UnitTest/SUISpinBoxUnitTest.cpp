#include "SUISpinBoxUnitTest.h"

SUI::SpinBoxUnitTest::SpinBoxUnitTest(SUI::SpinBox *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::SpinBoxUnitTest::~SpinBoxUnitTest() {
    delete object;
}
