#include "SUIBusyIndicatorUnitTest.h"

SUI::BusyIndicatorUnitTest::BusyIndicatorUnitTest(SUI::BusyIndicator *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::BusyIndicatorUnitTest::~BusyIndicatorUnitTest() {
    delete object;
}
