#include "DialogUnitTest.h"

#include <QTest>
#include <QString>

#include <SUIUILoader.h>
#include <SUIDialogImpl.h>

DialogUnitTest::DialogUnitTest() :
    mGui(SUI::UILoader::loadUI(":/UnitTest.xml"))
{
}

void DialogUnitTest::cleanupTestCase()
{
    delete mGui;
}

void DialogUnitTest::testchangeWindowNameCase1() {
    QFETCH(QString, titleName);

    mGui->setWindowTitle(titleName.toStdString());

    QCOMPARE(titleName, dynamic_cast<SUI::DialogImpl *>(mGui)->windowTitle());
}

void DialogUnitTest::testchangeWindowNameCase1_data()
{
    QTest::addColumn<QString>("titleName");
    QTest::newRow("change the TitleName") << QString("Pietje Pukkel");
}

void DialogUnitTest::testchangeWindowNameCase2()
{
    QFETCH(QString, titleName);

    mGui->setWindowTitle(titleName.toStdString());

    QCOMPARE(titleName, dynamic_cast<SUI::DialogImpl *>(mGui)->windowTitle());
}

void DialogUnitTest::testchangeWindowNameCase2_data()
{
    QTest::addColumn<QString>("titleName");
    QTest::newRow("change the TitleName") << QString("Pietje Pukkel");
}
