#ifndef SUIDOUBLESPINBOXUNITTEST_H
#define SUIDOUBLESPINBOXUNITTEST_H

#include "SUIWidgetUnitTest.h"

namespace SUI {

class DoubleSpinBox;

class DoubleSpinBoxUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
     DoubleSpinBoxUnitTest(DoubleSpinBox *object, QObject *parent = 0);
    ~DoubleSpinBoxUnitTest();

protected:
    void callInterfaceTests();

private Q_SLOTS:
    //INumeric
    void setMinValue();
    void setMinValue_data();

    void setMaxValue();
    void setMaxValue_data();

    void setStepSize();
    void setStepSize_data();

    void setValue();
    void setValue_data();

    void setPrecision();
    void setPrecision_data();
private:
    DoubleSpinBox *object;
};

}

#endif // SUIDOUBLESPINBOXUNITTEST_H
