#include "SUIDialogUnitTest.h"
#include <QTest>

SUI::DialogUnitTest::DialogUnitTest(SUI::Dialog *object, QObject *parent) :
    ObjectUnitTest(object,parent),
    object(object)
{

}

SUI::DialogUnitTest::~DialogUnitTest()
{
    delete object;
}

