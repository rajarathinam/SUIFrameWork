#include "SUITableWidgetItemUnitTest.h"
#include <QTest>

SUI::TableWidgetItemUnitTest::TableWidgetItemUnitTest(SUI::TableWidgetItem *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::TableWidgetItemUnitTest::~TableWidgetItemUnitTest() {
    delete object;
}

void SUI::TableWidgetItemUnitTest::setFontSize() {
    //nominal
    object->setFontSize(SUI::FontSizeEnum::Big);
    QCOMPARE(object->getFontSize(), SUI::FontSizeEnum::Big);
    object->setFontSize(SUI::FontSizeEnum::Small);
    QCOMPARE(object->getFontSize(), SUI::FontSizeEnum::Small);
    object->setFontSize(SUI::FontSizeEnum::Normal);
    QCOMPARE(object->getFontSize(), SUI::FontSizeEnum::Normal);
    //robust case
    object->setFontSize(SUI::FontSizeEnum::Uninitialized);
    QCOMPARE(object->getFontSize(), SUI::FontSizeEnum::Normal);
}

