#ifndef SUIDATETIMEEDITUNITTEST_H
#define SUIDATETIMEEDITUNITTEST_H

#include "SUIWidgetUnitTest.h"
#include "SUIDateTimeEdit.h"

namespace SUI {

class DateTimeEdit;

class DateTimeEditUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    DateTimeEditUnitTest(SUI::DateTimeEdit *object, QObject *parent = 0);
    virtual ~DateTimeEditUnitTest();

private:
    DateTimeEdit *object;
};

}
#endif // SUIDATETIMEEDITUNITTEST_H
