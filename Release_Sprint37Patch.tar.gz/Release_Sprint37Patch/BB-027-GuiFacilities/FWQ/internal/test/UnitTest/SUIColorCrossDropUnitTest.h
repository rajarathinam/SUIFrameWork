#ifndef SUICOLORCROSSDROPUNITTEST_H
#define SUICOLORCROSSDROPUNITTEST_H

#include "SUIWidgetUnitTest.h"

namespace SUI {

class ColorCrossDrop;

class ColorCrossDropUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
     ColorCrossDropUnitTest(ColorCrossDrop *object, QObject *parent = 0);

protected:
    void callInterfaceTests();

private slots:

private:
    ColorCrossDrop *object;
};

}

#endif // SUICOLORCROSSDROPUNITTEST_H
