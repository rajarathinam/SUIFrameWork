#include "SUIDateTimeEditUnitTest.h"

SUI::DateTimeEditUnitTest::DateTimeEditUnitTest(SUI::DateTimeEdit *object, QObject *parent) :
    WidgetUnitTest(object, parent),
    object(object)
{
}

SUI::DateTimeEditUnitTest::~DateTimeEditUnitTest() {
    delete object;
}


