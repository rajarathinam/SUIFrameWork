#include "SUILabelUnitTest.h"

#include <QTest>

#include <SUILabel.h>
#include <SUIFontSizeEnum.h>

#include "SUIITextUnitTest.h"
#include "SUIIAlignableUnitTest.h"
#include "SUIIColorableUnitTest.h"
#include "SUIIBGColorableUnitTest.h"

SUI::LabelUnitTest::LabelUnitTest(SUI::Label *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
    Q_ASSERT(object);
}

SUI::LabelUnitTest::~LabelUnitTest() {
   delete object;
}

void SUI::LabelUnitTest::callInterfaceTests() {
    //IText unit test
    ITextUnitTest iTextUnitTest(object);
    QVERIFY(iTextUnitTest.setText());
    QVERIFY(iTextUnitTest.clearText());
    QVERIFY(iTextUnitTest.setBold());

    //IAlignable unit test
    IAlignableUnitTest iAlignableUnitTest(object);
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::HCenter));
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Left));
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Right));
    QCOMPARE(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Stretch), false );

    //IColorable tests
    IColorableUnitTest iColorableUnitTest(object);
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Transparent));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Standard));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::White));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Red));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Green));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Blue));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Gray));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Yellow));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Orange));

    //IBGColorable tests
    IBGColorableUnitTest iBGColorableUnitTest(object);
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Transparent));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Standard));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::White));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Red));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Green));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Blue));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Gray));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Yellow));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Orange));

}

void SUI::LabelUnitTest::setFontSize() {
    object->setFontSize(SUI::FontSizeEnum::Big);
    QCOMPARE(object->getFontSize(),SUI::FontSizeEnum::Big);
    object->setFontSize(SUI::FontSizeEnum::Small);
    QCOMPARE(object->getFontSize(),SUI::FontSizeEnum::Small);
    object->setFontSize(SUI::FontSizeEnum::Normal);
    QCOMPARE(object->getFontSize(),SUI::FontSizeEnum::Normal);
}

