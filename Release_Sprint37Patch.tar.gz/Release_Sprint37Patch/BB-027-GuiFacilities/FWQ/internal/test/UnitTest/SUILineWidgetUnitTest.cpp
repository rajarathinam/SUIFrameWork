#include "SUILineWidgetUnitTest.h"
#include <QTest>

SUI::LineWidgetUnitTest::LineWidgetUnitTest(SUI::LineWidget *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::LineWidgetUnitTest::~LineWidgetUnitTest() {
    delete object;
}
