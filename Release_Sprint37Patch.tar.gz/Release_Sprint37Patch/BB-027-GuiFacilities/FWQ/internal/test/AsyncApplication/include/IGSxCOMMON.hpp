/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxCOMMON.hpp
| Author       : Thijs Jacobs
| Description  : IGS common includes
|
| ! \file        IGSxCOMMON.hpp
| ! \brief       IGS common includes
|
|-----------------------------------------------------------------------------|
|                                                                             |
|                Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IGSXCOMMON_HPP
#define IGSXCOMMON_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <exception>
#include <string>

namespace IGS {

/*----------------------------------------------------------------------------|
|                                     Type Defs                               |
|----------------------------------------------------------------------------*/
// result type
typedef int Result;
const int OK = 0; // OK result

/*----------------------------------------------------------------------------|
|                                     Interface Definition                    |
|----------------------------------------------------------------------------*/
// exceptions
class Exception: public std::exception
{
public:
    explicit Exception(const std::string& message) {m_msg = message;}
    virtual ~Exception() throw () {}

    virtual const char* what() const throw () {return m_msg.c_str();}

private:
    std::string m_msg;
};

} // namespace IGS

#endif // IGSXCOMMON_HPP

