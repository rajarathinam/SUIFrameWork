/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxApplication.cpp
| Author       : Thijs Jacobs
| Description  : Impementation of class IGSxApplication
|
| ! \file        IGSxApplication.cpp
| ! \brief       Impementation of class IGSxApplication
|
|-----------------------------------------------------------------------------|
|                                                                             |
|                Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <signal.h>

//#include "IGSxER.h"
//#include "IGSxLOG.hpp"
#include "IGSxCOMMON.hpp"
//#include "IGSxEVENT.hpp"
#include "IGSxApplication.hpp"

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
// instance
IGS::Application::Application() :
    m_thread(NULL)
{
//    IGS_INFO("Start application");

    // init CN
//    int result = CNXAtaskInit(NULL);
//    ERxEXC_THROW_LOGGED_RESULT(ERxLOG::LogId(result)); // no exception thrown if (result == OK)

    // start the EH event thread
    m_thread = new boost::thread(&IGS::Application::handleEvents, this);
}

IGS::Application::~Application()
{
//    // stop the EH event thread
//    EHXA_set_exit_flag();
//    if (m_thread != NULL)
//    {
//        m_thread->interrupt();
//        m_thread->join();
//        delete m_thread;
//    }

//    // exit CN
//    CNXAtaskExit();

//    IGS_INFO("Application stopped");
}

void IGS::Application::handleEvents()
{
//    try
//    {
//        int result = EHXA_init();
//        ERxEXC_THROW_LOGGED_RESULT(ERxLOG::LogId(result)); // no exception thrown if (result == OK)
        
//        {
//            // catch the following events to gracefully terminate the application
//            EHXA_sync_to_this();
//            EHXA_sync_signal(SIGINT, EHXA_sync_signal_exit, NULL);
//            EHXA_sync_signal(SIGABRT, EHXA_sync_signal_exit, NULL);
//            EHXA_sync_signal(SIGQUIT, EHXA_sync_signal_exit, NULL);
//            EHXA_sync_signal(SIGTERM, EHXA_sync_signal_exit, NULL);
//            EHXA_sync_signal(SIGALRM, EHXA_sync_signal_exit, NULL);

//            IGS_INFO("Starting EHXA main loop");
//            EHXA_main_loop();
//            IGS_INFO("EHXA main loop stopped");
//        }

//        EHXA_clean_up();
//    }
//    catch(...)
//    {
//        const std::string err("Error while initializing EH thread");
//        IGS_ERROR(err);
//        EHXA_clean_up();
//        throw IGS::Exception(err);
//    }
}

