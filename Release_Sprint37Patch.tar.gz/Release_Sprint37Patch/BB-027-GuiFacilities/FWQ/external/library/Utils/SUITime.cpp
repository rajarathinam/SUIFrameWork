//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for Time.
// !\description Class implementation file for Time.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUITime.h"

#include "SUITimeImpl.h"

SUI::Time::~Time()
{
}

boost::shared_ptr<SUI::Time> SUI::Time::createTime() {
    return boost::shared_ptr<Time>(new TimeImpl);
}
