//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for Application.
// !\description Class implementation file for Application.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUIApplication.h"

#include "SUIApplicationImpl.h"

SUI::Application::~Application()
{
}

boost::shared_ptr<SUI::Application> SUI::Application::createApplication(int &argc, char *argv[]) {
    return boost::shared_ptr<Application>(new ApplicationImpl(argc,argv));
}
