//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for ArgumentException.
// !\description Class implementation file for ArgumentException.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIArgumentException.h"

SUI::ArgumentException::ArgumentException(const std::string &msg) :
    Exception(msg)
{
}


SUI::ArgumentException::~ArgumentException() throw()
{
}
