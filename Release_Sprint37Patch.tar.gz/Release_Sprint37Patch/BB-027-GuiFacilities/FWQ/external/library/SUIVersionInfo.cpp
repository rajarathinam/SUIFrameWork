//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for VersionInfo.
// !\description Class implementation file for VersionInfo.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIVersionInfo.h"

#include <sstream>

SUI::VersionInfo::VersionInfo(int majorVersion, int minorVersion, int revision):
    mMajor(majorVersion),
    mMinor(minorVersion),
    mRevision(revision)
{
}

int SUI::VersionInfo::majorVersion() const {
    return mMajor;
}

int SUI::VersionInfo::minorVersion() const {
    return mMinor;
}

int SUI::VersionInfo::revision() const {
    return mRevision;
}


std::string SUI::VersionInfo::toString() const {
    std::stringstream ss;
    ss << mMajor << "." << mMinor << "." << mRevision;
    return ss.str();
}

std::string SUI::VersionInfo::toStringMajorMinor() const {
    std::stringstream ss;
    ss << mMajor << "." << mMinor;
    return ss.str();
}
