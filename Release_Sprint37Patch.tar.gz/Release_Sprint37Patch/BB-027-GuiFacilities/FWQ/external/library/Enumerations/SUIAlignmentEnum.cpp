//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUIAlignmentEnum.
// !\description Header file for class SUIAlignmentEnum.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIAlignmentEnum.h"

#include <algorithm>

std::string SUI::AlignmentEnum::toString(Alignment alignment) {
    switch (alignment)
    {
    case Right: return "right";
    case Left: return "left";
    case Stretch: return "stretch";
    case HCenter: return "center";
    //default is center
    default: return "center";
    }
}

SUI::AlignmentEnum::Alignment SUI::AlignmentEnum::fromString(const std::string &alignment) {
    std::string a = alignment;
    std::transform(a.begin(), a.end(), a.begin(), ::tolower);

    if (a == "right") return Right;
    if (a == "left") return Left;
    if (a == "stretch") return Stretch;
    if (a == "center") return HCenter;
    //default is center
    return HCenter;
}
