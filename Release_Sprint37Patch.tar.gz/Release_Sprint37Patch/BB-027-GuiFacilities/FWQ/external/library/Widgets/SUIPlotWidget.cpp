//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for PlotWidget.
// !\description Class implementation file for PlotWidget.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIPlotWidget.h"

#include "SUIObjectFactory.h"

SUI::PlotWidget::PlotWidget() : 
    Widget(SUI::ObjectType::PlotWidget)
{
}

SUI::PlotWidget::~PlotWidget()
{
}
