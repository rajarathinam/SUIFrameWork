//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for ListView.
// !\description Class implementation file for ListView.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIListView.h"

#include "SUIObjectFactory.h"

SUI::ListView::ListView() : 
    Widget(SUI::ObjectType::ListView)
{
}

SUI::ListView::~ListView()
{
}
