//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for RadioButton.
// !\description Class implementation file for RadioButton.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIRadioButton.h"

#include "SUIObjectFactory.h"

SUI::RadioButton::RadioButton() : 
    Widget(SUI::ObjectType::RadioButton)
{
}

SUI::RadioButton::~RadioButton()
{
}
