//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::PlotDataPoint.
// !\description Class implementation file for SUI::PlotDataPoint.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUIPlotDataPoint.h"

SUI::PlotDataPoint::PlotDataPoint(double xVal, double yVal) :
    x(xVal),
    y(yVal)
{
}

double SUI::PlotDataPoint::getX() const {
    return x;
}

void SUI::PlotDataPoint::setX(double value) {
    x = value;
}

double SUI::PlotDataPoint::getY() const {
    return y;
}

void SUI::PlotDataPoint::setY(double value) {
    y = value;
}

