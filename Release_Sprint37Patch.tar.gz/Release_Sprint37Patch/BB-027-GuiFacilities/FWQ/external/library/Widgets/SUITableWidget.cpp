//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for TableWidget.
// !\description Class implementation file for TableWidget.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUITableWidget.h"

#include "SUIObjectFactory.h"

SUI::TableWidget::TableWidget() : 
    Widget(SUI::ObjectType::TableWidget)
{
}

SUI::TableWidget::~TableWidget()
{
}
