//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for Button.
// !\description Class implementation file for Button.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUIButton.h"

#include "SUIObjectFactory.h"

SUI::Button::Button() : 
    Widget(SUI::ObjectType::fromString(SUI::ObjectFactory::getClassName<Button>()))
{
}

SUI::Button::~Button()
{
}
