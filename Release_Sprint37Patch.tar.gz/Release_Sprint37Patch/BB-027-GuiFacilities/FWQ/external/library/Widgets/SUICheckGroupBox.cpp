//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for CheckGroupBox.
// !\description Class implementation file for CheckGroupBox.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUICheckGroupBox.h"

#include "SUIObjectFactory.h"

SUI::CheckGroupBox::CheckGroupBox() : 
    Widget(SUI::ObjectType::fromString(SUI::ObjectFactory::getClassName<CheckGroupBox>()))
{
}

SUI::CheckGroupBox::CheckGroupBox(const SUI::ObjectType::Type &type) :
    Widget(type)
{
}

SUI::CheckGroupBox::~CheckGroupBox()
{
}
