//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for DropDown.
// !\description Class implementation file for DropDown.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIDropDown.h"

#include "SUIObjectFactory.h"

SUI::DropDown::DropDown() : 
    Widget(SUI::ObjectType::DropDown) 
{       
}

SUI::DropDown::~DropDown()
{
}
