//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for BusyIndicator.
// !\description Class implementation file for BusyIndicator.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIBusyIndicator.h"

#include "SUIObjectFactory.h"

SUI::BusyIndicator::BusyIndicator() : 
    Widget(SUI::ObjectType::fromString(SUI::ObjectFactory::getClassName<BusyIndicator>()))
{
}

SUI::BusyIndicator::~BusyIndicator()
{
}
