//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for DoubleSpinBox.
// !\description Class implementation file for DoubleSpinBox.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIDoubleSpinBox.h"

#include "SUIObjectFactory.h"

SUI::DoubleSpinBox::DoubleSpinBox() : 
    Widget(SUI::ObjectType::fromString(SUI::ObjectFactory::getClassName<DoubleSpinBox>()))
{
}

SUI::DoubleSpinBox::DoubleSpinBox(const SUI::ObjectType::Type &type) : 
    Widget(type)
{
}

SUI::DoubleSpinBox::~DoubleSpinBox()
{
}
