//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for QuestionMark.
// !\description Class implementation file for QuestionMark.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIQuestionMark.h"

#include "SUIObjectFactory.h"

SUI::QuestionMark::QuestionMark() : 
    Widget(SUI::ObjectType::QuestionMark)
{
}

SUI::QuestionMark::~QuestionMark()
{
}
