//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for GraphicsCrosshairItem.
// !\description Class implementation file for GraphicsCrosshairItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIGraphicsCrosshairItem.h"

#include "SUIObjectFactory.h"
#include "CustomGraphicsCrosshairItem.h"

#include <QPen>
#include <QRectF>

SUI::GraphicsCrosshairItem::GraphicsCrosshairItem(GraphicsItem *parent) : 
    GraphicsItem(
          SUI::ObjectType::GraphicsCrosshairItem,
          new CustomGraphicsCrosshairItem(parent ? static_cast<QGraphicsItem*>(ObjectFactory::getImplementation(parent)) : NULL),
          parent),
    penColor(SUI::ColorEnum::Black)
{
}

SUI::GraphicsCrosshairItem::~GraphicsCrosshairItem()
{
    delete static_cast<CustomGraphicsCrosshairItem*>(implementation);
}

SUI::ColorEnum::Color SUI::GraphicsCrosshairItem::getPenColor() const {
    return penColor;
}

void SUI::GraphicsCrosshairItem::setPenColor(const SUI::ColorEnum::Color color) {
    if (!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color)) return;
    penColor = color;
    CustomGraphicsCrosshairItem *item = static_cast<CustomGraphicsCrosshairItem*>(implementation);
    QPen pen = item->pen();
    pen.setColor(QColor(QString::fromStdString(ColorEnum::toString(color))));
    item->setPen(pen);
}

void SUI::GraphicsCrosshairItem::setPenWidth(int width) {
    CustomGraphicsCrosshairItem *item = static_cast<CustomGraphicsCrosshairItem*>(implementation);
    QPen pen = item->pen();
    pen.setWidth(width);
    item->setPen(pen);
}

void SUI::GraphicsCrosshairItem::setCosmetic(bool enabled) {
   CustomGraphicsCrosshairItem *item = static_cast<CustomGraphicsCrosshairItem*>(implementation);
   QPen pen = item->pen();
   pen.setCosmetic(enabled);
   item->setPen(pen);
}

int SUI::GraphicsCrosshairItem::getPenWidth() const {
    return static_cast<CustomGraphicsCrosshairItem*>(implementation)->pen().width();
}

void SUI::GraphicsCrosshairItem::setSize(double width, double height) {
   CustomGraphicsCrosshairItem *item = static_cast<CustomGraphicsCrosshairItem*>(implementation);
   item->setRect(QRectF(item->rect().topLeft(),QSizeF(width,height)));
}


double SUI::GraphicsCrosshairItem::getWidth() const {
    return static_cast<CustomGraphicsCrosshairItem*>(implementation)->rect().width();
}

double SUI::GraphicsCrosshairItem::getHeight() const {
    return static_cast<CustomGraphicsCrosshairItem*>(implementation)->rect().height();
}
