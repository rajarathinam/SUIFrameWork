//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::GraphicsCrosshairItem.
// !\description Header file for class SUI::GraphicsCrosshairItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|




#ifndef SUIGRAPHICSCROSSHAIRITEM_H
#define SUIGRAPHICSCROSSHAIRITEM_H

#include "SUIGraphicsItem.h"
#include "SUIColorEnum.h"

namespace SUI {
/*!
 * \ingroup FWQxGraphicsItems
 *
 * \brief The GraphicsCrossHair class
 */
class SUI_SHARED_EXPORT GraphicsCrosshairItem : public GraphicsItem
{

public:
    virtual ~GraphicsCrosshairItem();

    /*!
     * \brief getPenColor
     * Returns the color of the cross hair item
     * \return
     */
    SUI::ColorEnum::Color getPenColor() const;

    /*!
     * \brief setPenColor
     * Sets the pen color of the cross hair item
     * \param color
     */
    void setPenColor(const SUI::ColorEnum::Color color);

    /*!
     * \brief setPenWidth
     * Sets the pen width for drawing
     * \param width
     */
    void setPenWidth(int width);

    /*!
     * \brief getPenWidth
     * Returns the current pen width
     * \return
     */
    int getPenWidth() const;

    /*!
     * \brief setCosmetic
     * Sets the drawing pen to cosmetic or non-cosmetic.
     * Cosmetic pens have a constant width, so its outline
     * will have the same thickness at different scale factors
     * \param enabled
     */
    void setCosmetic(bool enabled);

    /*!
     * \brief penColorChanged
     * Callback that is triggered when the pen color has changed
     */
    boost::function<void()> penColorChanged;

    /*!
     * \brief brushColorChanged
     * Callback that is triggered when the brush color has changed
     */
    boost::function<void()> brushColorChanged;

    /*!
     * \brief setSize
     * Sets the width and height of the bounding rectangle
     * \param width
     * \param height
     */
    void setSize(double width, double height);

    /*!
     * \brief setWidth
     * Sets the width of the bounding rectangle
     * \param width
     */
    void setWidth(double width);

    /*!
     * \brief setHeight
     * Sets the height of the bounding rectangle
     * \param height
     */
    void setHeight(double height);

    /*!
     * \brief getWidth
     * Returns the width of the bounding rectangle
     * \return
     */
    double getWidth() const;

    /*!
     * \brief getHeight
     * Returns the height of the bounding rectangle
     * \return
     */
    double getHeight() const;

private:
    friend class ObjectFactory;
    explicit GraphicsCrosshairItem(GraphicsItem *parent = NULL);
    GraphicsCrosshairItem(const GraphicsCrosshairItem &copy);
    GraphicsCrosshairItem &operator=(const GraphicsCrosshairItem &copy);
    SUI::ColorEnum::Color penColor;
};
}

#endif // SUIGRAPHICSCROSSHAIRITEM_H
