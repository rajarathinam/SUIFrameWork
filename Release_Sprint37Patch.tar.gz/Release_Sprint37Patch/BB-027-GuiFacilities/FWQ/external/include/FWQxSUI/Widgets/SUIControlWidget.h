//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ControlWidget.
// !\description Header file for class SUI::ControlWidget.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUICONTROLWIDGET_H
#define SUICONTROLWIDGET_H

#include "SUIDeprecated.h"

#include "SUIStateWidget.h"

namespace SUI {

/*!
 * \ingroup FWQxWidgets
 *
 * \brief The ControlWidget class
 */
class SUI_DEPRECATED ControlWidget : public StateWidget
{
public:
    virtual ~ControlWidget();

    /*!
     * \brief setType
     * Sets the type of the control widget
     * \Deprecated
     * \param type
     */
    SUI_DEPRECATED virtual void setType(const std::string &type) = 0;

    /*!
     * \brief getType
     * Returns the type of the control widget
     * \Deprecated
     * \return
     */
    SUI_DEPRECATED virtual std::string getType() const = 0;
    
protected:
    ControlWidget();

};
}

#endif // SUICONTROLWIDGET_H
