//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::TextArea.
// !\description Header file for class SUI::TextArea.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUITEXTAREA_H
#define SUITEXTAREA_H

#include "SUIWidget.h"
#include "SUIIErrorMode.h"
#include "SUIIText.h"
#include "SUIIColorable.h"
#include "SUIIAlignable.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief Specific Interface for the TextArea Widget
 */
class SUI_SHARED_EXPORT TextArea : public Widget, public IText, public IColorable, public IErrorMode, public IAlignable
{
public:
    virtual ~TextArea();

    /*!
     * \brief setAutoScroll
     * This function sets the scroll feature of a textarea on or off
     * \param scroll - Sets the scroll feature of a textarea on or off
     */
    virtual void setAutoScroll(bool scroll) = 0;

    /*!
     * \brief setReadonly
     * Set the widgets read-only mode
     * \param readOnly Set the read-only mode.
     */
    virtual void setReadonly(bool readOnly) = 0;
    
protected:
    TextArea();
};
}

#endif // SUITEXTAREA_H
