//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::PlotHistogramItem.
// !\description Header file for class SUI::PlotHistogramItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUIPLOTHISTOGRAMITEM_H
#define SUIPLOTHISTOGRAMITEM_H

#include "SUIPlotItem.h"
#include "SUIColorEnum.h"
#include "SUIPlotIntervalSample.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief The PlotHistogramItem class
 */
class PlotWidget;
class SUI_SHARED_EXPORT PlotHistogramItem : public PlotItem
{
public:
    explicit PlotHistogramItem(const std::string &title);
    virtual ~PlotHistogramItem();

    //Interface functions
    virtual void attach(PlotWidget *plot);
    virtual void detach();
    virtual void setTitle(const std::string &title);
    virtual std::string getTitle() const;
    virtual void show();
    virtual void hide();
    virtual void setVisible(bool visible);
    virtual bool isVisible () const;
    virtual void setAxes(PlotAxisEnum::PlotAxis xAxis, PlotAxisEnum::PlotAxis yAxis);
    virtual void setXAxis(PlotAxisEnum::PlotAxis xAxis);
    virtual PlotAxisEnum::PlotAxis getXAxis() const;
    virtual void setYAxis(PlotAxisEnum::PlotAxis axis);
    virtual PlotAxisEnum::PlotAxis getYAxis() const;
    virtual double getZ() const;
    virtual void setZ(double z);

    /*!
     * \brief getPenColor
     * Returns the color of histogram's pen
     * \return
     */
    SUI::ColorEnum::Color getPenColor() const;

    /*!
     * \brief setPenColor
     * Sets the color of histogram's pen to the given color
     * \param color
     * \note Call to replot on Plot widget is required to see the changes
     */
    void setPenColor(const SUI::ColorEnum::Color color);

    /*!
     * \brief setPenWidth
     * Sets the pen width to the given width in pixels with integer precision
     * \param width
     * \note Call to replot on Plot widget is required to see the changes
     */
    void setPenWidth(int width);

    /*!
     * \brief getPenWidth
     * Returns the pen width with integer precision
     * \return
     */
    int getPenWidth() const;

    /*!
     * \brief getBrushColor
     * Returns the color of histogram's brush
     * \return
     */
    SUI::ColorEnum::Color getBrushColor() const;

    /*!
     * \brief setBrushColor
     * Sets the color of histogram's brush to the given color
     * \param color
     * \note Call to replot on Plot widget is required to see the changes
     */
    void setBrushColor(const SUI::ColorEnum::Color color);

    /*!
     * \brief setSamples
     * Set and add data with an array of samples.
     * \param values - std::vector<SUI::PlotIntervalSample>
     * \note Call to replot on Plot widget is required to see the changes
     */
    void setSamples(const std::vector<SUI::PlotIntervalSample> &values);

    /*!
     * \brief setSamples
     * Set and add data with an interval sample.
     * \param value - SUI::PlotIntervalSample
     * \note Call to replot on Plot widget is required to see the changes
     */
    void setSample(const SUI::PlotIntervalSample &value);

    /*!
     * \brief clearSamples
     *  Clear data samples plotted
     * \note Call to replot on Plot widget is required to see the changes
     */
    void clearSamples();

 private:
    SUI::ColorEnum::Color penColor;
    SUI::ColorEnum::Color brushColor;
    std::vector<SUI::PlotIntervalSample> intervalSamples;

    void plotHistogram();

    friend class ObjectFactory;
    PlotHistogramItem(SUI::PlotItem *parent = NULL);
    PlotHistogramItem(const PlotHistogramItem &copy);
    PlotHistogramItem &operator=(const PlotHistogramItem &copy);

};
}
#endif // SUIPLOTHISTOGRAMITEM_H
