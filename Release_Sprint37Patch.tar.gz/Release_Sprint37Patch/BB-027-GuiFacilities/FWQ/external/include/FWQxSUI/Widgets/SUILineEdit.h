//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::LineEdit.
// !\description Header file for class SUI::LineEdit.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|



#ifndef SUILINEEDIT_H
#define SUILINEEDIT_H

#include "SUIWidget.h"

#include "SUIIAlignable.h"
#include "SUIIText.h"
#include "SUIIColorable.h"
#include "SUIIBGColorable.h"
#include "SUIIErrorMode.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief Specific Interface for the LineEdit Widget
 */
class SUI_SHARED_EXPORT LineEdit : public Widget, public IText, public IColorable, public IBGColorable, public IAlignable, public IErrorMode
{
public:
    virtual ~LineEdit();

    /*!
     * \brief textEdited
     * Callback function that is called if the text was edited.
     */
    boost::function<void(const std::string&)> textEdited;

    /*!
     * \brief editingFinished
     * Callback function that is called when the user has finished editing
     */
    boost::function<void()> editingFinished;

    /*!
     * \brief valueValidated
     * Callback function that is called when the value was validated.
     */
    boost::function<void()> valueValidated;

    /*!
     * \brief setPlaceHolderText
     * Sets the line edit's placeholder text
     * \param value: The new placeholder text. To disable the placeholder, supply an empty string as argument
     */
    virtual void setPlaceHolderText(const std::string &value) = 0;

    /*!
     * \brief getPlaceHolderText
     * Returns the current placeholder text
     * \return Returns the current placeholder text. Empty string if no placeholder has been set
     */
    virtual std::string getPlaceHolderText() const = 0;

protected:
    LineEdit();
};
}

#endif // SUILINEEDIT_H
