//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ArgumentException.
// !\description Header file for class SUI::ArgumentException.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIARGUMENTEXCEPTION_H
#define SUIARGUMENTEXCEPTION_H

#include "SUIException.h"

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief The ArgumentException class
 */
class SUI_SHARED_EXPORT ArgumentException : public Exception
{

public:
    /*!
     * \brief ArgumentException
     * Constructs an exception with a supplied message
     * \param msg
     */
    explicit ArgumentException(const std::string &msg);

    virtual ~ArgumentException() throw();

private:
    ArgumentException();

};
}
#endif // SUIARGUMENTEXCEPTION_H
