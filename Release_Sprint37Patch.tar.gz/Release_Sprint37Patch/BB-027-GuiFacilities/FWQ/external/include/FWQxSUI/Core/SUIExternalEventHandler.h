//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ExternalEventHandler.
// !\description Header file for class SUI::ExternalEventHandler.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUIEXTERNALEVENTHANDLER_H
#define SUIEXTERNALEVENTHANDLER_H

#include "SUIExternalEvent.h"
#include "SUISharedExport.h"

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief The ExternalEventHandler class
 */
class SUI_SHARED_EXPORT ExternalEventHandler
{
public:
    /*!
     * \brief raiseEvent
     *
     * \remark Notice that ownership is transferred, so don't delete the event
     *
     * \param event
     * \return
     */
    static bool raiseEvent(SUI::AbstractExternalEvent *event);
};
}
#endif // SUIEXTERNALEVENTHANDLER_H
