//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for SUIDeprecated
// !\description Header file for SUIDeprecated
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIDEPRECATED_H
#define SUIDEPRECATED_H

//#ifndef SUI_DEPRECATED_ENABLE_ERROR
//#  pragma GCC diagnostic warning "-Wdeprecated-declarations"
//#endif
//
//#ifdef __GNUC__
//#  define SUI_DEPRECATED __attribute__((deprecated))
//#elif defined(_MSC_VER)
//#  define SUI_DEPRECATED __declspec(deprecated)
//#else
//#  pragma message("WARNING: You need to implement DEPRECATED for this compiler")
#  define SUI_DEPRECATED
//#endif

#endif // SUIDEPRECATED_H
