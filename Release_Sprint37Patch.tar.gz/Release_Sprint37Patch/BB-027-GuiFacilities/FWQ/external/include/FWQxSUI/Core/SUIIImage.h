//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::IImage.
// !\description Header file for class SUI::IImage.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIIIMAGE_H
#define SUIIIMAGE_H

#include "SUIImageEnum.h"

#include <string>

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief Generic Interface class for interaction with the image property of a widget
 */
class IImage
{
public:
    virtual ~IImage() {}

    /*!
     * \brief setImage
     * Sets an image from file
     * \param fileName - Image filename
     */
    virtual void setImage(const std::string &fileName) = 0;

    /*!
     * \brief setImage
     * Sets an image from raw data
     * \param data - The raw byte array
     * \param width - The width of the image
     * \param height - The height of the image
     * \param format - The format of the image (\see ImageEnum::Format)
     */
    virtual void setImage(unsigned char *data, int width, int height, ImageEnum::Format format) = 0;
};
}

#endif // SUIIIMAGE_H
