//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::IHoverable.
// !\description Header file for class SUI::IHoverable.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUIIHOVERABLE_H
#define SUIIHOVERABLE_H

#include <boost/function.hpp>

namespace SUI {

/*!
 * \ingroup FWQxCore
 *
 * \brief Generic Interface class for the purpose of the chickable widgets
 */
class IHoverable
{
public:
    virtual ~IHoverable() {}

    /*!
     * \brief Callback function that is called when the widget was hovered.
     * \fn hoverEntering
     * \fn hoverLeaving
     */
    boost::function<void()> hoverEntered;
    boost::function<void()> hoverLeft;
};
}

#endif // IHOVERABLE_H
