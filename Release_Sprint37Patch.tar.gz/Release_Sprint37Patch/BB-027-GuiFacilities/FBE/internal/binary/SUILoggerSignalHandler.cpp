//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::LoggerSignalHandler.
// !\description Class implementation file for SUI::LoggerSignalHandler.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUILoggerSignalHandler.h"

SUI::LoggerSignalHandler::LoggerSignalHandler(QObject *parent) :
    QObject(parent)
{
}

void SUI::LoggerSignalHandler::sendLogEvent(QString logmsg, int level) {
    emit newLogEvent(logmsg, level);
}
