//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::Logger.
// !\description Class implementation file for SUI::Logger.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUILogger.h"
#include "SUILoggerSignalHandler.h"

#include <QMessageBox>
#include <QDateTime>
#include <QFile>

SUI::Logger *SUI::Logger::myInstance = NULL;

SUI::Logger::Logger(QString logfile):
    mLogfile(logfile), mLogSignalHandler(new LoggerSignalHandler())
{
    mLevelStrings.insert(Info, "Info");
    mLevelStrings.insert(Warning, "Warning");
    mLevelStrings.insert(Error, "Error");
}

SUI::Logger *SUI::Logger::instance() {
    if ( myInstance == NULL ) {
        myInstance = new Logger(QString("SUI_%1.log").arg(QDateTime::currentDateTime().toString("yyyyMMdd_hhmmss")));
    }
    return myInstance;
}

void SUI::Logger::logMessage(LogLevel level, QString message) {
    QFile activityLog(mLogfile);
    if (true == activityLog.open(QFile::Append | QFile::Text))
    {
        QByteArray writeData;
        QDateTime curDateTime = QDateTime::currentDateTime();

        writeData.append(curDateTime.toString("yyyyMMdd hh:mm:ss"));
        writeData.append(":");
        writeData.append(mLevelStrings[level]);
        writeData.append(":");
        writeData.append(message);
        writeData.append("\n");
        activityLog.write(writeData);
        activityLog.close();
        mLogSignalHandler->sendLogEvent(writeData, level);
    }
}

void SUI::Logger::logWarning(const QString &message) {
    Logger::instance()->logMessage(Warning, message);
}

void SUI::Logger::logError(const QString &message) {
    Logger::instance()->logMessage(Error, message);
}

