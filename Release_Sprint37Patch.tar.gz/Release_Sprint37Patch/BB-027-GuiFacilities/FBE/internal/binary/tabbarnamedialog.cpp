//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SetNameDialog.
// !\description Class implementation file for SetNameDialog.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "tabbarnamedialog.h"
#include "ui_tabbarnamedialog.h"

SetNameDialog::SetNameDialog(const QString &oldtabname, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SetNameDialog)
{
    ui->setupUi(this);
    ui->mTabNameLE->setText(oldtabname);
    ui->mTabNameLE->setFocus();
    connect(ui->mOkPB, SIGNAL(clicked()), this, SLOT(accept()));
    connect(ui->mCancelPB, SIGNAL(clicked()), this, SLOT(reject()));
}

SetNameDialog::~SetNameDialog()
{
    delete ui;
}

QString SetNameDialog::getName() const
{
    return ui->mTabNameLE->text();
}

void SetNameDialog::setEditLabelText(const QString text)
{
    ui->mEditLB->setText(text);
}

