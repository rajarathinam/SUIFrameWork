//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class GridProperties.
// !\description Header file for class GridProperties.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|



#ifndef GRIDPROPERTIES_H
#define GRIDPROPERTIES_H

#include <QDialog>

#include "Model.h"

namespace Ui {
class GridProperties;
}

class GridProperties : public QDialog
{
    Q_OBJECT

public:
    explicit GridProperties(QWidget *parent = 0);
    virtual ~GridProperties();

private:
    Ui::GridProperties *ui;

private slots:
    void    onOkClicked();
    void    onGridActiveClicked(bool checked);
};

#endif // GRIDPROPERTIES_H
