//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class Itemwidgetdialog.
// !\description Header file for class Itemwidgetdialog.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|



#ifndef ITEMWIDGETDIALOG_H
#define ITEMWIDGETDIALOG_H

#include <QDialog>
//#include "WidgetController.h"

#include <SUIObjectType.h>
#include <map>
using namespace std;

class WidgetController;

namespace Ui
{
class Itemwidgetdialog;
}

class Itemwidgetdialog : public QDialog
{
    Q_OBJECT

public:
    typedef enum SELECTIONCHOICE
    {
        CH_ROWS,
        CH_COLUMNS,
        CH_CELL
    } ChoiceDefinition;

    Itemwidgetdialog(WidgetController *tablewidgcont, int choicedef = 0, QWidget *parent = 0);
    virtual ~Itemwidgetdialog();

private:
    Ui::Itemwidgetdialog        *ui;
    bool                        mTypeChanged;
    bool                        mBorderOnChanged;
    ChoiceDefinition            mChoiceDef;
    WidgetController            *mTableWidgetContr;
    QStringList                 mWidgetTypeList;

    static const QList<SUI::ObjectType::Type> cmAllowedWidgetList;
    map<QString,QString> mUCIdFileName;

private slots:
    void    onRowsToggled(bool checked);
    void    onColumnsToggled(bool checked);
    void    onSingleCellToggled(bool checked);
    void    onStartSBChanged(int val);
    void    onEndSBChanged(int val);
    void    onTypeChanged(int val);
    void    onBorderOnToggled(bool checked);
    void    onOk();
};

#endif // ITEMWIDGETDIALOG_H
