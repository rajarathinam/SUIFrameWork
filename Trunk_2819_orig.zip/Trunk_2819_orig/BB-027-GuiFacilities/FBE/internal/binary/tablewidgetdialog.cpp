//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for TableWidgetDialog.
// !\description Class implementation file for TableWidgetDialog.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


/*===========================================================================*\
    CLASS       :   TableWidgetDialog

    This class provides a Dialog Box for editing a Table Widget. Depending on
    the mode it is started up with (enum ACTIONID), it displays different text
    and some widgets have a different function.
    The commented out code is for future purposes, where the TableWidget should
    contain other widgets as well, in stead of just TableWidgetItems.
\*===========================================================================*/

#include "tablewidgetdialog.h"
#include "ui_tablewidgetdialog.h"

#include <SUITableWidgetItemImpl.h>

#include "rticWidgetDefinition.h"

#include "Model.h"

TableWidgetDialog::TableWidgetDialog(ActionDefinition actdef, WidgetController *tablewidg, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::TableWidgetDialog),
    mPosition(1),
    mCount(1),
    mMaxPosition(1),
    mTableWidgetContr(tablewidg),
    mTable(dynamic_cast<SUI::TableWidgetImpl *>(mTableWidgetContr->getBaseWidget())),
    mActDef(actdef)
{
    Q_ASSERT(mTableWidgetContr->getObjectType() == SUI::ObjectType::TableWidget);

    int dCurrentCount = 0;
    ui->setupUi(this);
    connect(ui->mPositionSP, SIGNAL(valueChanged(int)), this, SLOT(onPositionChanged(int)));
    connect(ui->mCountSP, SIGNAL(valueChanged(int)), this, SLOT(onCountChanged(int)));
    connect(ui->mActionPB, SIGNAL(clicked()), this, SLOT(onActionTriggered()));
    connect(ui->mCancelPB, SIGNAL(clicked()), this, SLOT(onClose()));

    switch (mActDef)
    {
    case ID_ADDROWS:
        this->setWindowTitle("Add Rows");
        ui->mActionPB->setText("Add");
        dCurrentCount = mTable->rowCount();
        mMaxPosition = dCurrentCount + 1;
        ui->mCountSP->setMaximum(1000);
        break;
    case ID_ADDCOLUMNS:
        this->setWindowTitle("Add Columns");
        ui->mActionPB->setText("Add");
        dCurrentCount = mTable->columnCount();
        mMaxPosition = dCurrentCount + 1;
        ui->mCountSP->setMaximum(1000);
        break;
    case ID_REMOVEROWS:
        this->setWindowTitle("Remove Rows");
        ui->mActionPB->setText("Remove");
        dCurrentCount = mMaxPosition = mTable->rowCount();
        ui->mCountSP->setMaximum(mMaxPosition);
        break;
    case ID_REMOVECOLUMNS:
        this->setWindowTitle("Remove Columns");
        ui->mActionPB->setText("Remove");
        dCurrentCount = mMaxPosition = mTable->columnCount();
        ui->mCountSP->setMaximum(mMaxPosition);
        break;
    default:
        break;
    }
    ui->mPositionSP->setMaximum(mMaxPosition);
    ui->mPositionSP->setMinimum(1);
    ui->mPositionSP->setValue(mPosition);
    ui->mCountSP->setValue(mCount);
    ui->mCurrentCountLB->setText(QString::number(dCurrentCount));

}

TableWidgetDialog::~TableWidgetDialog()
{
    delete ui;
}

void TableWidgetDialog::onPositionChanged(int val) {
    mPosition = val;
}

void TableWidgetDialog::onCountChanged(int val) {
    mCount = val;
}

void TableWidgetDialog::onActionTriggered()
{
    int dCurrentCount = 0;
    switch (mActDef)
    {
    case ID_ADDROWS: {
        insertRows(mPosition - 1, mCount);
        dCurrentCount = mTable->rowCount();
        mMaxPosition = dCurrentCount + 1;
        break;
    }
    case ID_ADDCOLUMNS: {
        insertColumns(mPosition - 1, mCount);
        dCurrentCount = mTable->columnCount();
        mMaxPosition = dCurrentCount + 1;
        break;
    }
    case ID_REMOVEROWS:
        removeRows(mPosition - 1, mCount);
        dCurrentCount = mTable->rowCount();
        mMaxPosition = dCurrentCount;
        break;
    case ID_REMOVECOLUMNS:
        removeColumns(mPosition - 1, mCount);
        dCurrentCount = mTable->columnCount();
        mMaxPosition = dCurrentCount;
        break;
    default:
        break;
    }
    ui->mPositionSP->setMaximum(mMaxPosition);
    ui->mCurrentCountLB->setText(QString::number(dCurrentCount));
    onClose();
}

void TableWidgetDialog::onClose()
{
    this->done(QDialog::Accepted);
}

void TableWidgetDialog::insertRows(int row, int rows) {
    insert(row,rows,0,mTable->columnCount(),Row);
}

void TableWidgetDialog::insertColumns(int column, int columns) {
    insert(0,mTable->rowCount(),column,columns,Column);
}

void TableWidgetDialog::insert(int rowPos, int rowCount, int columnPos, int columnCount, ItemType rowOrColumn) {
    Q_ASSERT(rowPos >= 0);
    Q_ASSERT(columnPos >= 0);

    switch (rowOrColumn) {
    case Row:
        if (columnCount == 0) columnCount++;
        mTable->insertRows(rowPos,rowCount);
        break;
    case Column:
        if (rowCount == 0) rowCount++;
        mTable->insertColumns(columnPos,columnCount);
        break;
    }

    WidgetDefinition widgetDefinition;
    widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::ObjectType, QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::TableWidgetItem)));
    widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable, "false");
    widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::Sizeable, "false");
    widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, "0");
    widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, "0");

    int rows = rowPos + rowCount;
    int columns = columnPos + columnCount;

    int rowStart = rowPos;
    int columnStart = columnPos;

    for (int row = rowStart; row < rows; row++) {
        for (int column = columnStart; column < columns; column++) {
            WidgetController *tableItem = widgetDefinition.addToWidget(mTableWidgetContr, true);
            tableItem->setParent(mTableWidgetContr);
            mTable->assign(row,column,dynamic_cast<SUI::Widget *>(SUI::ObjectFactory::getInstance()->toObject(tableItem->getBaseWidget())));
            mTable->updateTable();
        }
    }
    mTableWidgetContr->renameTableWidgetItems();
    Model::instance()->setDataChanged();
}

void TableWidgetDialog::removeRows(int row, int rows) {
    if ( mTable->rowCount() == 0 ) return;
    remove(row,rows,0,mTable->columnCount(),Row);
}

void TableWidgetDialog::removeColumns(int column, int columns) {
    if ( mTable->columnCount() == 0 ) return;
    remove(0,mTable->rowCount(),column,columns,Column);
}

void TableWidgetDialog::remove(int rowPos, int rowCount, int columnPos, int columnCount, ItemType rowOrColumn) {
    Q_ASSERT(rowPos >= 0);
    Q_ASSERT(columnPos >= 0);

    int rows = rowPos + rowCount;
    int columns = columnPos + columnCount;
    int rowStart = rowPos;
    int columnStart = columnPos;

    for (int row = rowStart; row < rows; row++) {
        for (int column = columnStart; column < columns; column++) {
            mTableWidgetContr->removeWidgetFromTable(row, column);
        }
    }

    switch (rowOrColumn) {
    case Row:
        mTable->removeRows(rowPos, rowCount);
        break;
    case Column:
        mTable->removeColumns(columnPos, columnCount);
        break;
    }

    mTableWidgetContr->renameTableWidgetItems();
    Model::instance()->setDataChanged();
}
