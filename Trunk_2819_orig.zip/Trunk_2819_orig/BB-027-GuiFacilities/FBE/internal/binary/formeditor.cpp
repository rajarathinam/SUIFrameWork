//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for FormEditor.
// !\description Class implementation file for FormEditor.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include <QGridLayout>
#include <QLabel>
#include <QMap>

#include <SUIDialogSerializer.h>
#include <FWQxCore/SUIXmlException.h>
#include <FWQxCore/SUIIOException.h>
#include <SUIStyleSheet.h>
#include <boost/foreach.hpp>

#include "Model.h"
#include "WidgetControllerInfo.h"
#include "formeditor.h"

const SUI::VersionInfo FormEditor::suiVersion = SUI::VersionInfo(SUI_MAJOR,SUI_MINOR,0);
const SUI::VersionInfo FormEditor::suiEditorVersion = SUI::VersionInfo(SUI_EDITOR_MAJOR,SUI_EDITOR_MINOR,0);

FormEditor::FormEditor(QWidget *parent) :
    WidgetController(parent, WidgetController::RootWidgetMode, new SUI::BaseWidget(new QWidget(), SUI::ObjectType::FormEditor, true)),
    mBaseWidgetController(new WidgetController(parent, WidgetController::RootWidgetMode))
{
    using namespace SUI;
    addProperty(new ObjectProperty(ObjectProperty::getDefaultObjectProperty(ObjectPropertyTypeEnum::SUIName)));
    addProperty(new ObjectProperty(ObjectProperty::getDefaultObjectProperty(ObjectPropertyTypeEnum::SUIDescription)));
    addProperty(new ObjectProperty(ObjectProperty::getDefaultObjectProperty(ObjectPropertyTypeEnum::SUIVersion)));
    addProperty(new ObjectProperty(ObjectProperty::getDefaultObjectProperty(ObjectPropertyTypeEnum::SUICoreVersion)));
    addProperty(new ObjectProperty(ObjectProperty::getDefaultObjectProperty(ObjectPropertyTypeEnum::SUIEditorVersion)));
    addProperty(new ObjectProperty(ObjectProperty::getDefaultObjectProperty(ObjectPropertyTypeEnum::SUIObjectFactory)));
    addProperty(new ObjectProperty(ObjectProperty::getDefaultObjectProperty(ObjectPropertyTypeEnum::SUIStyleSheet)));
    addProperty(new ObjectProperty(ObjectProperty::getDefaultObjectProperty(ObjectPropertyTypeEnum::Namespace)));
    addProperty(new ObjectProperty(ObjectProperty::getDefaultObjectProperty(ObjectPropertyTypeEnum::ClassName)));

    addProperty(new ObjectProperty(ObjectProperty::getDefaultObjectProperty(ObjectPropertyTypeEnum::HasRightButtonBar)));
    addProperty(new ObjectProperty(ObjectProperty::getDefaultObjectProperty(ObjectPropertyTypeEnum::HasBottomButtonBar)));
    addProperty(new ObjectProperty(ObjectProperty::getDefaultObjectProperty(ObjectPropertyTypeEnum::HasStatusBar)));

    reset();

    getBaseWidget()->getWidget()->setStyleSheet(QString::fromStdString(StyleSheet::getInstance()->getStyleSheet()));

    getBaseWidget()->exposeHeightProperty();
    getBaseWidget()->exposeWidthProperty();
}

/*!
 *  FUNCTION    :   reset
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This function sets all its properties back to its default values. Being
 *  used by MainWindow::onNew().
 */
void FormEditor::reset() {
    setPropertyValue(SUI::ObjectPropertyTypeEnum::SUIVersion, QString::fromStdString(suiVersion.toStringMajorMinor()));
    setPropertyValue(SUI::ObjectPropertyTypeEnum::SUICoreVersion, QString::fromStdString(suiVersion.toString()));
    setPropertyValue(SUI::ObjectPropertyTypeEnum::SUIEditorVersion, QString::fromStdString(suiEditorVersion.toString()));
    setPropertyValue(SUI::ObjectPropertyTypeEnum::SUIObjectFactory, QString::fromStdString(SUI::ObjectFactory::getInstance()->getName()));
    setPropertyValue(SUI::ObjectPropertyTypeEnum::SUIName, "Example SUI");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::SUIDescription, "Example SUI");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "1024");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "768");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::SUIStyleSheet, "ADT");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::HasRightButtonBar, "false");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::HasBottomButtonBar, "false");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::HasStatusBar, "false");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::Namespace, "NMSP");
    setPropertyValue(SUI::ObjectPropertyTypeEnum::ClassName, "CLNA");
}

/*!
 *  FUNCTION    :   readInclude
 *  PARAMETERS  :   const QString &incfile
 *                      The UserControl xml file to read
 *  RETURN      :   void
 *
 *  This function reads an xml file with start element 'UserControl' and adds it
 *  to Model's UserControl List.
 */
void FormEditor::readInclude(const QString &incfile) {
    SUI::DialogSerializer mySerializer("UserControl", SUI::DialogSerializer::Read);
    WidgetDefinition userCtrlDef;
    try
    {
        mySerializer.openFile(incfile);
        mySerializer.acceptVisitor(userCtrlDef);
    }
    catch (SUI::XmlException *re)
    {
        mySerializer.closeFile();
        Model::instance()->getModelHandler()->sendMessage("XmlException", QString::fromStdString(re->getExceptionMessage()) , 1);
        return;
    }
    catch (SUI::IOException *re)
    {
        mySerializer.closeFile();
        Model::instance()->getModelHandler()->sendMessage("IOException", QString::fromStdString(re->getExceptionMessage()), 1);
        return;
    }
    WidgetController *widgetController = userCtrlDef.addToWidget(mBaseWidgetController, false);
    if (widgetController != NULL) {
        mBaseWidgetController->removeFromModel();
        widgetController->setParent(NULL);
        Model::instance()->store(widgetController);
        widgetController->removeFromModel();
        mBaseWidgetController->removeChild(widgetController);
    }
}

/*!
 *  FUNCTION    :   setPropertyValue
 *  PARAMETERS  :   QString propertyID
 *                  QString propertyValue
 *  RETURN      :   void
 *
 *  In case propertID is a 'Include" property, this function adds this
 *  propertyID with its value to mUtcProperties. Otherwise, it sets the
 *  WidgetController's property.
 */
void FormEditor::setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) {
    WidgetController::setPropertyValue(propertyID, propertyValue);
}

void FormEditor::setInclude(const QString &include, const QString &fileName) {
    mUtcProperties.insert(include, fileName);
}

/*!
 *  FUNCTION    :   getPropertyValue
 *  PARAMETERS  :   QString propertyID
 *  RETURN      :   QString
 *                      The value being retrieved.
 *
 *  In case propertID is a 'Include" property, this function return the value of
 *  propertyID. Otherwise, it returns the WidgetController's property value.
 */
QString FormEditor::getPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID) const {
    return WidgetController::getPropertyValue(propertyID);
}

/*!
 *  FUNCTION    :   acceptVisitor
 *  PARAMETERS  :   IGUIDefinitionVisitor& visitor
 *  RETURN      :   void
 *
 *  This function writes all properties to the XML Writer.
 */
void FormEditor::acceptVisitor(GUIDefinitionVisitor &visitor, bool bSkipUCtrl)
{
    Q_UNUSED(bSkipUCtrl);
    BOOST_FOREACH (SUI::ObjectPropertyTypeEnum::Type propertyID, getPropertyList()) {
        if ((propertyID == SUI::ObjectPropertyTypeEnum::SUICoreVersion) || (propertyID == SUI::ObjectPropertyTypeEnum::SUIEditorVersion) ||
                (propertyID == SUI::ObjectPropertyTypeEnum::SUIObjectFactory) || (propertyID == SUI::ObjectPropertyTypeEnum::SUIName) ||
                (propertyID == SUI::ObjectPropertyTypeEnum::SUIDescription) || (propertyID == SUI::ObjectPropertyTypeEnum::Height) || (propertyID == SUI::ObjectPropertyTypeEnum::Width) ||
                (propertyID == SUI::ObjectPropertyTypeEnum::HasRightButtonBar) || (propertyID == SUI::ObjectPropertyTypeEnum::HasBottomButtonBar) ||
                (propertyID == SUI::ObjectPropertyTypeEnum::HasStatusBar) || (propertyID == SUI::ObjectPropertyTypeEnum::SUIVersion) ||
                (propertyID == SUI::ObjectPropertyTypeEnum::SUIStyleSheet)|| (propertyID == SUI::ObjectPropertyTypeEnum::Namespace) || (propertyID == SUI::ObjectPropertyTypeEnum::ClassName))
        {
            visitor.writeWidgetProperty(propertyID, getPropertyValue(propertyID));
        }
    }

    //remove duplicates usercontrol list
    QStringList userCtrlList;
    BOOST_FOREACH (QString childID, Model::instance()->getUsedUCtrlList()) {
        WidgetController *wcUCtrl = Model::instance()->getWidgetController(childID);
        if (wcUCtrl != NULL) {
            userCtrlList.append(wcUCtrl->getPropertyValue(SUI::ObjectPropertyTypeEnum::UserControl));
        }
    }
    userCtrlList.removeDuplicates();
    BOOST_FOREACH (const QString &str, userCtrlList) {
        visitor.writeInclude(QString("Include-%1").arg(str), QString("%1.xml").arg(str));
    }

    for (int ind = 0; ind < mChildren.size(); ++ind) {
        GUIDefinitionVisitor &childVisitor = visitor.openChildWidget();
        mChildren[ind]->acceptVisitor(childVisitor, true);
        visitor.closeChildWidget();
    }
}

void FormEditor::setGridPixmap() {
    int dXSize = getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt();
    int dYSize = getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt();

    int XCoord=0, YCoord=0;
    //compute the coordinates to set grid in tabpage
    QList<WidgetController *> childrenList = FormEditor::childList();
    BOOST_FOREACH (WidgetController * child, childrenList) {
        if(child->getObjectType() == SUI::ObjectType::TabWidget) {
            XCoord = child->pos().x();
            YCoord = child->pos().y();
        }
        QList<WidgetController *> grandChildrenList = child->childList();
        BOOST_FOREACH (WidgetController * grandChild, grandChildrenList) {
            if(grandChild->getObjectType() == SUI::ObjectType::TabPage) {
                XCoord += grandChild->pos().x();
                YCoord += grandChild->pos().y();
            }
        }
    }

    QImage  image(dXSize, dYSize, QImage::Format_ARGB32);
    if ((Model::instance()->gridActive()) && (Model::instance()->XGridDistance() > 2) && (Model::instance()->YGridDistance() > 2)) {
        int dXStepsize = Model::instance()->XGridDistance();
        int dYStepsize = Model::instance()->YGridDistance();

        image.fill(qRgba(0, 0, 0, 0));
        for (int xInd = XCoord; xInd < image.width(); xInd += dXStepsize) {
            for (int yInd = YCoord; yInd < image.height(); yInd += dYStepsize)
                image.setPixel(xInd, yInd, QColor(Qt::black).rgb());
        }
        setPixmap(QPixmap::fromImage(image));
    }
    else {
        image.fill(qRgba(0, 0, 0, 0));
        setPixmap(QPixmap::fromImage(image));
    }
}

bool FormEditor::hasRightButtonBar() const {
    return (getPropertyValue(SUI::ObjectPropertyTypeEnum::HasRightButtonBar).toLower() == "true");
}

bool FormEditor::hasBottomButtonBar() const {
    return (getPropertyValue(SUI::ObjectPropertyTypeEnum::HasBottomButtonBar).toLower() == "true");
}

bool FormEditor::hasStatusBar() const {
    return (getPropertyValue(SUI::ObjectPropertyTypeEnum::HasStatusBar).toLower() == "true");
}

int FormEditor::bottomButtonBarHeight() const {
    return (hasBottomButtonBar()) ? cm_BottomButtonBarHeight : 0;
}

int FormEditor::statusBarHeight() const {
    return (hasStatusBar()) ? cm_StatusBarHeight : 0;
}

SUI::VersionInfo FormEditor::getVersion() {
    return suiVersion;
}
SUI::VersionInfo FormEditor::getEditorVersion() {
    return suiEditorVersion;
}

int FormEditor::rightButtonBarWidth() const {
    return (hasRightButtonBar()) ? cm_RightButtonBarWidth : 0;
}
