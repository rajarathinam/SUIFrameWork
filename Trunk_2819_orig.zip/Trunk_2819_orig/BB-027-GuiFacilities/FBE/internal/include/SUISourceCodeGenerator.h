//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::SourceCodeGenerator.
// !\description Header file for class SUI::SourceCodeGenerator.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUISOURCECODEGENERATOR_H
#define SUISOURCECODEGENERATOR_H

#include <QStringList>

class QFile;

namespace SUI {
class Dialog;

class SourceCodeGenerator
{
public:
    enum GenerateFiles
    {
        mocFiles,
        cppFiles
    };
    static void dialogToSource(const QString &fileName, const QString &generationPath, SUI::Dialog *dialog, const SUI::SourceCodeGenerator::GenerateFiles fileType);

private:
    // cpp
    static void writeMocHeader(QFile *file, const QStringList &objectStringList);
    static void writeMocSource(QFile *file, const QStringList &objectStringList);
    static void writeHeader(QFile *file);
    static void writeSource(QFile *file, const QString &fileName);

    static bool writeFileAllowed(QFile *file);
    static bool checkFileExists(QFile *file, GenerateFiles filetype);

    static QString generatorString();
    static QString getClassName();
    static QString getNamespace();

    static bool isFileOpen(QFile *file);

};

} // namespace SUI

#endif // SUI_SUISOURCECODEGENERATOR_H
