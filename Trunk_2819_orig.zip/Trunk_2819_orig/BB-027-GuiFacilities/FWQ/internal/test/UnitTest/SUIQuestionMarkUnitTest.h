#ifndef SUIQUESTIONMARKUNITTEST_H
#define SUIQUESTIONMARKUNITTEST_H

#include "SUIWidgetUnitTest.h"

namespace SUI {

class QuestionMark;

class QuestionMarkUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    explicit QuestionMarkUnitTest(QuestionMark *object, QObject *parent = 0);
    virtual ~QuestionMarkUnitTest();

protected:
    void callInterfaceTests();

private:
    QuestionMark *object;
};

}

#endif // SUIQUESTIONMARKUNITTEST_H
