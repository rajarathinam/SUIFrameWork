#ifndef SUIWIDGETUNITTEST_H
#define SUIWIDGETUNITTEST_H

#include "SUIObjectUnitTest.h"
#include <QTimer>
#include <QApplication>
#include <QDialog>

namespace SUI {
class DialogRejecter : public QObject
{
    Q_OBJECT
public:
    DialogRejecter() {
        mtimer = new QTimer(this);
        mtimer->setInterval(100);
        connect(mtimer, SIGNAL(timeout()), this, SLOT(rejectDialog()));
        mtimer->start();
    }
    ~DialogRejecter(){
        disconnect(mtimer, SIGNAL(timeout()), this, SLOT(rejectDialog()));
        delete mtimer;
        mtimer = NULL;
    }

private slots:
    void rejectDialog() {
        QWidget *widget = QApplication::activeModalWidget();
        if(widget != NULL){
            QDialog *dialog = qobject_cast<QDialog *>(widget);
            if(dialog !=NULL) {
                dialog->reject();
            }
        }
    }
private:
   QTimer *mtimer;
};

class Widget;

class WidgetUnitTest : public ObjectUnitTest
{
    Q_OBJECT
public:
    WidgetUnitTest(Widget *object, QObject *parent);
    virtual ~WidgetUnitTest();

private slots:
    void setEnabled();
    void setFocus();
    void clearFocus();
    void setContextMenuItems();
    void contextMenuClicked();
    void setStyleSheetClass();

    void setGeometry();
    void setGeometry_data();

    void testHoverEnter();
    void testHoverLeft();

private:
    void onHoverEnterLeft();
    void onContextMenuClicked(const std::string &s,const std::string &s2);

    Widget *object;
};

}
#endif // SUIWIDGETUNITTEST_H
