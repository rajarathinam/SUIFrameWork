
#include "SUIControlWidgetImplUnitTest.h"
#include "SUIControlWidgetImpl.h"
#include "SUIBaseObject.h"

SUI::ControlWidgetImplUnitTest::ControlWidgetImplUnitTest(SUI::ControlWidgetImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::ControlWidgetImplUnitTest::~ControlWidgetImplUnitTest()
{
   delete object;
}

void SUI::ControlWidgetImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
