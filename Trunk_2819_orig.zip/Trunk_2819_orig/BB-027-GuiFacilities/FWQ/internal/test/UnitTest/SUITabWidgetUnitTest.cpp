#include "SUITabWidgetUnitTest.h"
#include <FWQxWidgets/SUITabWidget.h>
#include <FWQxWidgets/SUITabPage.h>
#include <QTest>
#include <QDebug>

#include <FWQxWidgets/SUIDialog.h>
#include <FWQxCore/SUIUILoader.h>
#include <FWQxCore/SUIObjectList.h>
SUI::TabWidgetUnitTest::TabWidgetUnitTest(SUI::TabWidget *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::TabWidgetUnitTest::~TabWidgetUnitTest() {
    delete object;
}

void SUI::TabWidgetUnitTest::testInterfaceFunctions() {
    SUI::Dialog *dialog = SUI::UILoader::loadUI(":/UnitTestTabWidget.xml");
    SUI::TabWidget *tab = dialog->getObjectList()->getObject<SUI::TabWidget>("tbw1");

    //getCuurentIndex
    QCOMPARE(tab->getCurrentIndex(), 0);

    //getCurrentTabPage
    TabPage *tabPage = tab->getCurrentTabPage();
    QVERIFY(tabPage != NULL);

    //setTabEnabled, isTabEnabled
    tab->setTabEnabled(tabPage->getId(), true);
    QCOMPARE(tab->isTabEnabled(tabPage->getId()), true);
    //TODO - test fails
    //tab->setTabEnabled(tabPage->getId(), false);
    //QCOMPARE(tab->isTabEnabled(tabPage->getId()), false);

    //getTabPage, getTabIndexOfWidget
    TabPage *page0 = tab->getTabPage(0);
    QCOMPARE(page0->getId(), tabPage->getId());
    QCOMPARE(tab->getTabIndexOfWidget(page0->getId()), 0);
    TabPage *page1 = tab->getTabPage(1);
    QVERIFY(page1 != NULL);
    QCOMPARE(tab->getTabIndexOfWidget(page1->getId()), 1);
    TabPage *page2 = tab->getTabPage(2);
    QVERIFY(page2 != NULL);
    QCOMPARE(tab->getTabIndexOfWidget(page2->getId()), 2);
    TabPage *page3 = tab->getTabPage(3);
    QVERIFY(page3 != NULL);
    QCOMPARE(tab->getTabIndexOfWidget(page3->getId()), 3);
    TabPage *page4 = tab->getTabPage(4);
    QVERIFY(page4 == NULL);

    //focusTabPage - TODO check manually
    tab->focusTabPage(0);
    //This can not be tested without visible components

    delete dialog;
    dialog = NULL;
}
