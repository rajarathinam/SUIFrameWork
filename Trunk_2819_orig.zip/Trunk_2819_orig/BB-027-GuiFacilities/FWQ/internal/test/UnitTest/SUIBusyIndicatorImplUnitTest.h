
#ifndef SUIBUSYINDICATORIMPLUNITTEST_H
#define SUIBUSYINDICATORIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class BusyIndicatorImpl;

class BusyIndicatorImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit BusyIndicatorImplUnitTest(BusyIndicatorImpl *object, QObject *parent = 0);
    virtual ~BusyIndicatorImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    BusyIndicatorImpl *object;
};

}
#endif // SUIBUSYINDICATORIMPLUNITTEST_H
