
#ifndef SUIDROPDOWNIMPLUNITTEST_H
#define SUIDROPDOWNIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class DropDownImpl;

class DropDownImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit DropDownImplUnitTest(DropDownImpl *object, QObject *parent = 0);
    virtual ~DropDownImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    DropDownImpl *object;
};

}
#endif // SUIDROPDOWNIMPLUNITTEST_H
