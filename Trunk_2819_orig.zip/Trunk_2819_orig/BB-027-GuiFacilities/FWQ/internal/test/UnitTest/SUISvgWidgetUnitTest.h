#ifndef SUISVGWIDGETUNITTEST_H
#define SUISVGWIDGETUNITTEST_H

#include "SUIWidgetUnitTest.h"
#include <FWQxWidgets/SUISvgWidget.h>

namespace SUI {

class SvgWidget;

class SvgWidgetUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    explicit SvgWidgetUnitTest(SUI::SvgWidget *object, QObject *parent = 0);
    virtual ~SvgWidgetUnitTest();

private:
    SvgWidget *object;
};

}

#endif // SUISVGWIDGETUNITTEST_H
