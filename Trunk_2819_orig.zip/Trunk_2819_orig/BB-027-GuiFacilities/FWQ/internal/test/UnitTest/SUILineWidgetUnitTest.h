#ifndef SUILINEWIDGETUNITTEST_H
#define SUILINEWIDGETUNITTEST_H

#include "SUIWidgetUnitTest.h"
#include <FWQxWidgets/SUILineWidget.h>

namespace SUI {

class LineWidget;

class LineWidgetUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    explicit LineWidgetUnitTest(SUI::LineWidget *object, QObject *parent = 0);
    virtual ~LineWidgetUnitTest();

private:
    LineWidget *object;
};

}
#endif // SUILINEWIDGETUNITTEST_H
