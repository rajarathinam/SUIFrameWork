
#include "SUIListViewImplUnitTest.h"
#include "SUIListViewImpl.h"
#include "SUIBaseObject.h"

SUI::ListViewImplUnitTest::ListViewImplUnitTest(SUI::ListViewImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::ListViewImplUnitTest::~ListViewImplUnitTest()
{
   delete object;
}

void SUI::ListViewImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::EditorForm);
    object->setDefaultProperties(SUI::BaseObject::EditorSelector);
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
