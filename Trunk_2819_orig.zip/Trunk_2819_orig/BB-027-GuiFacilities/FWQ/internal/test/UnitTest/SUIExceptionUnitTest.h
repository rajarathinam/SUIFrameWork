#ifndef SUIEXCEPTIONUNITTEST_H
#define SUIEXCEPTIONUNITTEST_H

#include <QObject>


namespace SUI {
class Exception;
class ExceptionUnitTest : public QObject
{
    Q_OBJECT

public:
    ExceptionUnitTest();

private Q_SLOTS:

    void tesCurrentException();

};

}
#endif // SUIEXCEPTIONUNITTEST_H
