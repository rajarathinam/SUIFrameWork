
#include "SUITabWidgetImplUnitTest.h"
#include "SUITabWidgetImpl.h"
#include "SUITabPageImpl.h"
#include "SUIBaseObject.h"

SUI::TabWidgetImplUnitTest::TabWidgetImplUnitTest(SUI::TabWidgetImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::TabWidgetImplUnitTest::~TabWidgetImplUnitTest()
{
   delete object;
}

void SUI::TabWidgetImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::EditorForm);
    object->setDefaultProperties(SUI::BaseObject::EditorSelector);
    object->setDefaultProperties(SUI::BaseObject::Gui);
}

void SUI::TabWidgetImplUnitTest::testVisiblityforAddNewTab() {
    QFETCH(QString, tabTitle);
    QFETCH(QString, tabID);
    QFETCH(bool, visibility);

    SUI::TabPageImpl *mTabPage =  new SUI::TabPageImpl(NULL);
    mTabPage->setId(tabID.toStdString());
    mTabPage->setTabText(tabTitle.toStdString());
    mTabPage->setVisible(visibility);
    object->addNewTab(mTabPage);

    if(visibility){
        QCOMPARE(object->getTabName(object->getWidget()->count() - 1), tabTitle);
    } else {
        //index returns -1 for TabPage->setVisible(false)
        QCOMPARE(object->getWidget()->indexOf(mTabPage->getWidget()), -1);
    }
    object->removeTab();
    delete mTabPage;
}

void SUI::TabWidgetImplUnitTest::testVisiblityforAddNewTab_data() {
    QTest::addColumn<QString>("tabTitle");
    QTest::addColumn<QString>("tabID");
    QTest::addColumn<bool>("visibility");
    QTest::newRow("Add visible TabPage") << QString("tab title 1") << QString("tbppage1") << bool(true);
    //TODO - FIXME 
//    QTest::newRow("Add hidden TabPage") << QString("tab title 2") << QString("tbppage2") << bool(false);
}
