#include"SUIColorCrossDropUnitTest.h"

#include <FWQxWidgets/SUIColorCrossDrop.h>
#include <QTest>
#include"SUIIColorableUnitTest.h"


SUI::ColorCrossDropUnitTest::ColorCrossDropUnitTest(SUI::ColorCrossDrop *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::ColorCrossDropUnitTest::~ColorCrossDropUnitTest() {
    delete object;
}

void SUI::ColorCrossDropUnitTest::callInterfaceTests() {
    //IColorable tests
    IColorableUnitTest iColorableUnitTest(object);
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Standard));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Black));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Green));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Red));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Gray));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Blue));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::White));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Yellow));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Orange));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Transparent));
}
