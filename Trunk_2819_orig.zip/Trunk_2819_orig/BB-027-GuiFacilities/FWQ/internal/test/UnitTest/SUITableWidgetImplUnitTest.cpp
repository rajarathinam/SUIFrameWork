
#include "SUITableWidgetImplUnitTest.h"
#include "SUITableWidgetImpl.h"
#include "SUIBaseObject.h"
#include "CustomHeaderTags.h"
#include <QtTest/qtest.h>
#include <boost/bind.hpp>
#include <FWQxWidgets/SUILabel.h>

SUI::TableWidgetImplUnitTest::TableWidgetImplUnitTest(SUI::TableWidgetImpl *object, QObject *parent) :
    QObject(parent),
    object(object),
    expectedRowNumber(0)
{

    HeaderTags  tmpHeaderTags(QString("root"), QString("childtags"));
    QCOMPARE(tmpHeaderTags.getName(), QString("root"));

}

SUI::TableWidgetImplUnitTest::~TableWidgetImplUnitTest()
{
   delete object;
}

void SUI::TableWidgetImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::EditorForm);
    object->setDefaultProperties(SUI::BaseObject::EditorSelector);
    object->setDefaultProperties(SUI::BaseObject::Gui);
}

void SUI::TableWidgetImplUnitTest::testRowClickedEvent() {

    object->insertRows(0, 3);
    //row number to place the label widget
    expectedRowNumber = 2;
    object->rowClicked = boost::bind(&SUI::TableWidgetImplUnitTest::onRowClicked, this, _1);
    SUI::BaseWidget *tableWidget = dynamic_cast<SUI::BaseWidget *>(object);
    QVERIFY(tableWidget != NULL);
    SUI::Label *lbl = SUI::ObjectFactory::getInstance()->createWidget_<SUI::Label>(tableWidget->getWidget());
    QVERIFY(lbl != NULL);
    object->updateCell(expectedRowNumber,0,SUI::AlignmentEnum::Stretch, lbl );
    SUI::BaseWidget *labelWidget = dynamic_cast<SUI::BaseWidget *>(lbl);
    QVERIFY(labelWidget != NULL);
    QTest::mouseClick(labelWidget->getWidget(), Qt::LeftButton);
}

void SUI::TableWidgetImplUnitTest::onRowClicked(int row) {
    QVERIFY(row == expectedRowNumber);
}
