#include "SUIINumericUnitTest.h"
#include <FWQxCore/SUIINumeric.h>
#include <QTest>

SUI::INumericUnitTest::INumericUnitTest(SUI::INumeric<double> *dObject) :
    dObject(dObject),
    fObject(NULL),
    iObject(NULL),
    uObject(NULL)
{
    Q_ASSERT(dObject);
}

SUI::INumericUnitTest::INumericUnitTest(SUI::INumeric<float> *fObject) :
    dObject(NULL),
    fObject(fObject),
    iObject(NULL),
    uObject(NULL)
{
    Q_ASSERT(fObject);
}

SUI::INumericUnitTest::INumericUnitTest(SUI::INumeric<int> *iObject) :
    dObject(NULL),
    fObject(NULL),
    iObject(iObject),
    uObject(NULL)
{
    Q_ASSERT(iObject);
}

SUI::INumericUnitTest::INumericUnitTest(SUI::INumeric<unsigned> *uObject) :
    dObject(NULL),
    fObject(NULL),
    iObject(NULL),
    uObject(uObject)
{
    Q_ASSERT(uObject);
}

bool SUI::INumericUnitTest::testDouble() {
    bool retMin;
    bool retMax;
    bool retVal;
    bool retLow;
    bool retHigh;
    bool retPrecision;

    dObject->setMinValue(20.0);
    retMin = (dObject->getMinValue() == 20.0);

    dObject->setMaxValue(80.0);
    retMax = (dObject->getMaxValue() == 80.0);

    // Value is between min and max so OK
    dObject->setValue(60.0);
    retVal = (dObject->getValue() == 60.0);

    // Value is below min so return is min
    dObject->setValue(10.0);
    retLow = (dObject->getValue() == 20.0);

    // Value is above max so return is max
    dObject->setValue(90.0);
    retHigh = (dObject->getValue() == 80.0);

    dObject->setPrecision(2);
    retPrecision = (dObject->getPrecision() == 2);

    return (retMin && retMax && retVal && retLow && retHigh && retPrecision);
}

bool SUI::INumericUnitTest::testFloat() {
    bool retMin;
    bool retMax;
    bool retVal;
    bool retLow;
    bool retHigh;
    bool retPrecision;

    fObject->setMinValue(20);
    retMin = (fObject->getMinValue() == 20);

    fObject->setMaxValue(80);
    retMax = (fObject->getMaxValue() == 80);

    // Value is between min and max so OK
    fObject->setValue(60);
    retVal = (fObject->getValue() == 60);

    // Value is below min so return is min
    fObject->setValue(10);
    retLow = (fObject->getValue() == 20);

    // Value is above max so return is max
    fObject->setValue(90);
    retHigh = (fObject->getValue() == 80);

    fObject->setPrecision(2);
    retPrecision = (fObject->getPrecision() == 2);

    return (retMin && retMax && retVal && retLow && retHigh && retPrecision);
}

bool SUI::INumericUnitTest::testInteger() {
    bool retMin;
    bool retMax;
    bool retVal;
    bool retLow;
    bool retHigh;
    bool retPrecision;

    iObject->setMinValue(20);
    retMin = (iObject->getMinValue() == 20);

    iObject->setMaxValue(80);
    retMax = (iObject->getMaxValue() == 80);

    // Value is between min and max so OK
    iObject->setValue(60);
    retVal = (iObject->getValue() == 60);

    // Value is below min so return is min
    iObject->setValue(10);
    retLow = (iObject->getValue() == 20);

    // Value is above max so return is max
    iObject->setValue(90);
    retHigh = (iObject->getValue() == 80);

    // We use integers so precision is always 0
    iObject->setPrecision(2);
    retPrecision = (iObject->getPrecision() == 0);

    return (retMin && retMax && retVal && retLow && retHigh && retPrecision);
}

bool SUI::INumericUnitTest::testUnsigned() {
    bool retMin;
    bool retMax;
    bool retVal;
    bool retLow;
    bool retHigh;
    bool retPrecision;

    uObject->setMinValue(20);
    retMin = (uObject->getMinValue() == 20);

    uObject->setMaxValue(80);
    retMax = (uObject->getMaxValue() == 80);

    // Value is between min and max so OK
    uObject->setValue(60);
    retVal = (uObject->getValue() == 60);

    // Value is below min so return is min
    uObject->setValue(10);
    retLow = (uObject->getValue() == 20);

    // Value is above max so return is max
    uObject->setValue(90);
    retHigh = (uObject->getValue() == 80);

    uObject->setPrecision(2);
    retPrecision = (uObject->getPrecision() == 2);

    return (retMin && retMax && retVal && retLow && retHigh && retPrecision);
}
