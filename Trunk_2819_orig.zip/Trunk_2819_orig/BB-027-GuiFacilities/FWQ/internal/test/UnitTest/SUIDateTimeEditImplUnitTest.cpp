
#include "SUIDateTimeEditImplUnitTest.h"
#include "SUIDateTimeEditImpl.h"
#include "SUIBaseObject.h"

SUI::DateTimeEditImplUnitTest::DateTimeEditImplUnitTest(SUI::DateTimeEditImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::DateTimeEditImplUnitTest::~DateTimeEditImplUnitTest()
{
   delete object;
}

void SUI::DateTimeEditImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
