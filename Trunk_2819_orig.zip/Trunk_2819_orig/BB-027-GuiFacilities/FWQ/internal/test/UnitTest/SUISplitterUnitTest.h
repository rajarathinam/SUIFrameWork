#ifndef SUISPLITTERUNITTEST_H
#define SUISPLITTERUNITTEST_H

#include "SUIWidgetUnitTest.h"
#include <FWQxWidgets/SUISplitter.h>

namespace SUI {

class Splitter;

class SplitterUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    explicit SplitterUnitTest(SUI::Splitter *object, QObject *parent = 0);
    virtual ~SplitterUnitTest();

private:
    Splitter *object;
};

}
#endif // SUISPLITTERUNITTEST_H
