
#ifndef SUIPLOTWIDGETIMPLUNITTEST_H
#define SUIPLOTWIDGETIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class PlotWidgetImpl;

class PlotWidgetImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit PlotWidgetImplUnitTest(PlotWidgetImpl *object, QObject *parent = 0);
    virtual ~PlotWidgetImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    PlotWidgetImpl *object;
};

}
#endif // SUIPLOTWIDGETIMPLUNITTEST_H
