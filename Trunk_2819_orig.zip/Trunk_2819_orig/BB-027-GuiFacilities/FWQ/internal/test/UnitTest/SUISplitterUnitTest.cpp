#include "SUISplitterUnitTest.h"

SUI::SplitterUnitTest::SplitterUnitTest(SUI::Splitter *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::SplitterUnitTest::~SplitterUnitTest() {
    delete object;
}
