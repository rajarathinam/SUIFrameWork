
#include "SUIDropDownImplUnitTest.h"
#include "SUIDropDownImpl.h"
#include "SUIBaseObject.h"

SUI::DropDownImplUnitTest::DropDownImplUnitTest(SUI::DropDownImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::DropDownImplUnitTest::~DropDownImplUnitTest()
{
   delete object;
}

void SUI::DropDownImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::EditorForm);
    object->setDefaultProperties(SUI::BaseObject::EditorSelector);
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
