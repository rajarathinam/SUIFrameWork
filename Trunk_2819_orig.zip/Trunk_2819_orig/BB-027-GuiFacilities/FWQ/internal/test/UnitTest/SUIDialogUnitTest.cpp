#include "SUIDialogUnitTest.h"
#include <QTest>
#include <QDialog>
#include <FWQxCore/SUIUILoader.h>
#include <FWQxCore/SUIResourcePath.h>

#include <FWQxCore/SUIObjectList.h>
SUI::DialogUnitTest::DialogUnitTest(SUI::Dialog *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::DialogUnitTest::~DialogUnitTest() {
    delete object;
}

void SUI::DialogUnitTest::testSetWindowTitle() {
    QFETCH(QString, title);
    object->setWindowTitle(title.toStdString());
    QCOMPARE(object->getWindowTitle(), title.toStdString());
}

void SUI::DialogUnitTest::testSetWindowTitle_data() {
    QTest::addColumn<QString>("title");
    QTest::newRow("data1") << QString("t") ;
    QTest::newRow("data2") << QString("tttttttttttttttttttttttttttttttttttttttttit") ;
    QTest::newRow("data3") << QString("tttttyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyttttttttttttttttttttttttttttttttttttit") ;
}

void SUI::DialogUnitTest::testGetFileName() {
    QFETCH(QString, filename);
    SUI::Dialog *dialog = SUI::UILoader::loadUI(filename.toStdString());
    QCOMPARE(QString::fromStdString(SUI::ResourcePath::getInstance()->getResourceFile(filename.toStdString())), QString::fromStdString(dialog->getFileName()));
    delete dialog;
}

void SUI::DialogUnitTest::testGetFileName_data() {
    QTest::addColumn<QString>("filename");
    QTest::newRow("data1") << QString("UnitTestResoursePath.xml");
    QTest::newRow("data2") << QString("NMSP_UserClass.xml");
}

void SUI::DialogUnitTest::testQuit() {
    object->quit();
}

void SUI::DialogUnitTest::testSetModal(){
    object->setModal(true);
    QDialog *dialog = dynamic_cast<QDialog *>(object);
    if(dialog != NULL) {
        QCOMPARE(dialog->isModal(), true);
    }
    object->setModal(false);
    if(dialog != NULL) {
        QCOMPARE(dialog->isModal(), false);
    }
}

void SUI::DialogUnitTest::testGetObjectList() {
    SUI::ObjectList *list = object->getObjectList();
    QCOMPARE(list->idExists("wpg1"), true);
}

