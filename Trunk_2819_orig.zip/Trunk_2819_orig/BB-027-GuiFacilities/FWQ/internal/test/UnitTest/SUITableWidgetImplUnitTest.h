
#ifndef SUITABLEWIDGETIMPLUNITTEST_H
#define SUITABLEWIDGETIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class TableWidgetImpl;

class TableWidgetImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit TableWidgetImplUnitTest(TableWidgetImpl *object, QObject *parent = 0);
    virtual ~TableWidgetImplUnitTest();

private slots:
    void setDefaultProperties();
    void testRowClickedEvent();

private:
    void onRowClicked(int row);
    TableWidgetImpl *object;
    int expectedRowNumber;
};

}
#endif // SUITABLEWIDGETIMPLUNITTEST_H
