
#include"SUIControlWidgetUnitTest.h"

#include <FWQxWidgets/SUIControlWidget.h>
#include <QTest>


SUI::ControlWidgetUnitTest::ControlWidgetUnitTest(SUI::ControlWidget *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::ControlWidgetUnitTest::~ControlWidgetUnitTest() {
    delete object;
}

void SUI::ControlWidgetUnitTest::callInterfaceTests() {
}
