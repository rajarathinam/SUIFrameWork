#ifndef SUITREEVIEWITEMUNITTEST_H
#define SUITREEVIEWITEMUNITTEST_H

#include <FWQxWidgets/SUITreeViewItem.h>
#include "SUIWidgetUnitTest.h"

namespace SUI {

class TreeViewItemUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    explicit TreeViewItemUnitTest(SUI::TreeViewItem *object, QObject *parent = 0);
    virtual ~TreeViewItemUnitTest();

protected:
    void callInterfaceTests();

private:
    TreeViewItem *object;
};

}

#endif // SUITREEVIEWITEMUNITTEST_H
