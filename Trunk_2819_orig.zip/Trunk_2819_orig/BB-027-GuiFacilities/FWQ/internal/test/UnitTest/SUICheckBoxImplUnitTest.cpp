#include "SUICheckBoxImplUnitTest.h"
#include "SUICheckBoxImpl.h"
#include "SUIBaseObject.h"

SUI::CheckBoxImplUnitTest::CheckBoxImplUnitTest(SUI::CheckBoxImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::CheckBoxImplUnitTest::~CheckBoxImplUnitTest()
{
   delete object;
}

void SUI::CheckBoxImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::EditorForm);
    object->setDefaultProperties(SUI::BaseObject::EditorSelector);
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
