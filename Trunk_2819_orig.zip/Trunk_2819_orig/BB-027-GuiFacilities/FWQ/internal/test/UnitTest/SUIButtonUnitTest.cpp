#include"SUIButtonUnitTest.h"
#include <QTest>

#include <FWQxWidgets/SUIButton.h>
#include "SUIIClickableUnitTest.h"
#include "SUIITextUnitTest.h"
#include "SUIIAlignableUnitTest.h"

SUI::ButtonUnitTest::ButtonUnitTest(SUI::Button *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::ButtonUnitTest::~ButtonUnitTest() {
    delete object;
}

void SUI::ButtonUnitTest::callInterfaceTests() {
    //IText unit test
    ITextUnitTest iTextUnitTest(object);
    QVERIFY(iTextUnitTest.setText());
    QVERIFY(iTextUnitTest.clearText());
    QVERIFY(iTextUnitTest.setBold());

    //IAlignable unit test
    IAlignableUnitTest iAlignableUnitTest(object);
    // Valid alignment
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::HCenter));
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Left));
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Right));
    // Invalid alignment
    QVERIFY(!iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Stretch));

    //IClickable tests
    IClickableUnitTest iClickable(object);
    iClickable.clickable();

    //TODO IImage unit test
}
