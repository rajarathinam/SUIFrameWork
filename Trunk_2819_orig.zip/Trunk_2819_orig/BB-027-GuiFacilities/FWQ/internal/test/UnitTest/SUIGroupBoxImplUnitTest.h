
#ifndef SUIGROUPBOXIMPLUNITTEST_H
#define SUIGROUPBOXIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class GroupBoxImpl;

class GroupBoxImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit GroupBoxImplUnitTest(GroupBoxImpl *object, QObject *parent = 0);
    virtual ~GroupBoxImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    GroupBoxImpl *object;
};

}
#endif // SUIGROUPBOXIMPLUNITTEST_H
