#include "SUIResourcePathUnitTest.h"
#include <QTest>
#include <QString>
#include <QFile>
#include <QDir>
#include <FWQxWidgets/SUIDialog.h>
#include <FWQxCore/SUIUILoader.h>
SUI::ResourcePathUnitTest::ResourcePathUnitTest() :
    object(SUI::ResourcePath::getInstance())
{
}

void SUI::ResourcePathUnitTest::setResourcePath() {
    QFETCH(QString, resourcePath);
    object->setResourcePath(resourcePath.toStdString());
    QCOMPARE(QString::fromStdString(object->getResourcePath()), resourcePath);

}

void SUI::ResourcePathUnitTest::setResourcePath_data() {
    QTest::addColumn<QString>("resourcePath");
    QTest::newRow("change1") << QString("/home/adt");
}

void SUI::ResourcePathUnitTest::getResourceFile() {
    QFETCH(QString, resourcePath);
    QFETCH(QString, filename);
    QFETCH(QString, uctfilename);

    if(!QDir(resourcePath.toStdString().c_str()).exists()) QDir().mkdir(resourcePath);
    object->setResourcePath(resourcePath.toStdString());

    //test1
    QFile::copy(":/UnitTestResoursePath.xml", "/home/adt/UnitTestResoursePath.xml");
    QFile::copy(":/UCT-Button.xml", "/home/adt/UCT-Button.xml");
    //test2
    QFile::copy(":/UnitTestResoursePath.xml", "/home/adt/test/UnitTestResoursePath.xml");
    QFile::copy(":/UCT-Button.xml", "/home/adt/test/UCT-Button.xml");
    //test3
    QFile::copy(":/UnitTestResoursePath.xml", "/home/adt/test1/UnitTestResoursePath.xml");
    QFile::copy(":/UCT-Button.xml", "/home/adt/test1/UCT-Button.xml");
    //test4
    if(filename == "UnitTestResoursePath.xml"){
        QString str = QString("%1%2%3").arg(QDir::currentPath()).arg(QDir::separator()).arg(filename);
        QString ustr = QString("%1%2%3").arg(QDir::currentPath()).arg(QDir::separator()).arg(uctfilename);
        QFile::copy(":/UnitTestResoursePath.xml", str.toStdString().c_str());
        QFile::copy(":/UCT-Button.xml", ustr.toStdString().c_str());
    }
    //test8
    if(filename == "FWQ_UserTestDefinition.xml") {
        QFile::copy("FWQ_UserTestDefinition.xml", "/home/adt/test2/FWQ_UserTestDefinition.xml");
        QFile::copy("UCT-DropBoxen.xml", "/home/adt/test2/UCT-DropBoxen.xml");
        QFile::copy("UCT-UserControlInputWidgets.xml", "/home/adt/test2/UCT-UserControlInputWidgets.xml");
    }

    if(filename != "Nofilename.xml") {
        SUI::Dialog *dialog = SUI::UILoader::loadUI(filename.toStdString());
        QCOMPARE(QString::fromStdString(dialog->getFileName()), QString::fromStdString(SUI::ResourcePath::getResourceFile(filename.toStdString())));
    }else {
        QCOMPARE(QString("Nofilename.xml"), QString::fromStdString(SUI::ResourcePath::getResourceFile(filename.toStdString())));
    }
}

void SUI::ResourcePathUnitTest::getResourceFile_data() {
    QTest::addColumn<QString>("resourcePath");
    QTest::addColumn<QString>("filename");
    QTest::addColumn<QString>("uctfilename");

    QTest::newRow("change1") << QString("") << QString("/home/adt/UnitTestResoursePath.xml") << QString("");
    QTest::newRow("change2") << QString("/home/adt/test") << QString("UnitTestResoursePath.xml") << QString("");
    QTest::newRow("change3") << QString("/home/adt/test1/") << QString("UnitTestResoursePath.xml") << QString("");
    QTest::newRow("change4") << QString("") << QString("UnitTestResoursePath.xml") << QString("UCT-Button.xml");
    QTest::newRow("change5") << QString("") << QString("Nofilename.xml") << QString("");
    QTest::newRow("change6") << QString("/home/adt") << QString("Nofilename.xml") << QString("");
    QTest::newRow("change7") << QString("/home/adt/test2") <<  QString("UnitTestResoursePath.xml") << QString("UCT-Button.xml");
    QTest::newRow("change8") << QString("/home/adt/test2") <<  QString("FWQ_UserTestDefinition.xml") << QString("");
}
