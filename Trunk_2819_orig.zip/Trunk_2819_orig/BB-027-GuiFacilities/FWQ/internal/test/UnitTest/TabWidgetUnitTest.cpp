#include "TabWidgetUnitTest.h"

const QString tabPage1 = "tbp1";
const QString tabPage2 = "tbp2";

TabWidgetUnitTest::TabWidgetUnitTest() :
    mTabWidg(new SUI::TabWidgetImpl(NULL)),
    mITabWidg(dynamic_cast<SUI::TabWidget *>(mTabWidg)),
    mITabWidg_Status(dynamic_cast<SUI::Widget *>(mTabWidg)),
    mTabPage(NULL)
{}

void TabWidgetUnitTest::cleanupTestCase()
{
    QList<SUI::TabPageImpl *> allTabs = mTabWidg->findChildren<SUI::TabPageImpl *>();
    foreach(SUI::TabPageImpl * wdgt, allTabs)
    {
        delete wdgt;
    }
    delete mTabWidg;
}

void TabWidgetUnitTest::testVisibilityCase2()
{
    QFETCH(bool, value1);

    mITabWidg->setVisible(value1);

    QCOMPARE(dynamic_cast<QTabWidget *>(mTabWidg->getWidget())->isVisible(), value1);
}

void TabWidgetUnitTest::testVisibilityCase2_data()
{
    QTest::addColumn<bool>("value1");
    QTest::newRow("First change") << true ;
    QTest::newRow("Second change") << false ;
}

void TabWidgetUnitTest::testEnabledCase2()
{
    QFETCH(bool, value1);

    mITabWidg->setEnabled(value1);

    QCOMPARE(dynamic_cast<QTabWidget *>(mTabWidg->getWidget())->isEnabled(), value1);
}

void TabWidgetUnitTest::testEnabledCase2_data()
{
    QTest::addColumn<bool>("value1");
    QTest::newRow("First change") << true ;
    QTest::newRow("Second change") << false ;
}

void TabWidgetUnitTest::testAddTabPageCase1()
{
    QFETCH(QString, tabTitle);
    QFETCH(QString, tabID);

    mTabPage =  new SUI::TabPageImpl(NULL);
    mTabPage->setId(tabID.toStdString());
    mTabPage->setTabText(tabTitle.toStdString());

    mTabWidg->addNewTab(mTabPage);

    QCOMPARE(mTabWidg->getTabName(mTabWidg->getWidget()->count() - 1), tabTitle);
}

void TabWidgetUnitTest::testAddTabPageCase1_data() {
    QTest::addColumn<QString>("tabTitle");
    QTest::addColumn<QString>("tabID");
    QTest::newRow("Add TabPage") << QString("Pietje Pukkel") << QString(tabPage1);
    QTest::newRow("Add TabPage") << QString("Pietje Pukkel2") << QString(tabPage2);
}

//void TabWidgetUnitTest::testTabVisibleCase1() {
//    QFETCH(QString, tabID);
//    QFETCH(bool, visible);

//    mTabWidg->setTabEnabled(tabID.toStdString(), visible);

//    QCOMPARE(mTabWidg->isTabEnabled(tabID.toStdString()), visible);
//}

//void TabWidgetUnitTest::testTabVisibleCase1_data() {
//    QTest::addColumn<QString>("tabID");
//    QTest::addColumn<bool>("visible");

//    QTest::newRow("Test tabvisibility - False") << QString(tabPage1) << false;
//    QTest::newRow("Test tabvisibility - True") << QString(tabPage1) << true;
//}

void TabWidgetUnitTest::testTabPageTitleCase1() {
    QFETCH(QString, tabTitle);
    QFETCH(QString, tabID);

    mTabWidg->setTabText(tabID , tabTitle);

    QCOMPARE(mTabWidg->getTabName(tabID), tabTitle);
}

void TabWidgetUnitTest::testTabPageTitleCase1_data()
{
    QTest::addColumn<QString>("tabTitle");
    QTest::addColumn<QString>("tabID");
    QTest::newRow("Rename TabTitle 1") << QString("testTitle") << QString(tabPage1);
}

void TabWidgetUnitTest::testTabPageTitleCase2()
{
    QFETCH(QString, tabTitle);
    QFETCH(QString, tabID);

    mTabWidg->setTabText(mTabWidg->getTabIndexOfWidget(tabID.toStdString()),tabTitle);

    QCOMPARE(mTabWidg->getTabName(tabID), tabTitle);
}

void TabWidgetUnitTest::testTabPageTitleCase2_data()
{
    QTest::addColumn<QString>("tabTitle");
    QTest::addColumn<QString>("tabID");

    QTest::newRow("Rename TabTitle 1") << QString("testTitle") << QString(tabPage2);
}

void TabWidgetUnitTest::testVisibilityCase1()
{
    QFETCH(bool, value1);

    mITabWidg_Status->setVisible(value1);

    QCOMPARE(mITabWidg_Status->isVisible(), value1);
}

void TabWidgetUnitTest::testVisibilityCase1_data()
{
    QTest::addColumn<bool>("value1");
    QTest::newRow("First change") << true ;
    QTest::newRow("Second change") << false ;
}

void TabWidgetUnitTest::testEnabledCase1()
{
    QFETCH(bool, value1);

    mITabWidg_Status->setEnabled(value1);

    QCOMPARE(mITabWidg_Status->isEnabled(), value1);
}

void TabWidgetUnitTest::testEnabledCase1_data()
{
    QTest::addColumn<bool>("value1");
    QTest::newRow("First change") << true ;
    QTest::newRow("Second change") << false ;
}

void TabWidgetUnitTest::testgetCurrentIndexCase1()
{
    QFETCH(int, index);
    mTabWidg->setCurrentTabPage(index);

    QCOMPARE(mITabWidg->getCurrentIndex(), index);
}

void TabWidgetUnitTest::testgetCurrentIndexCase1_data()
{
    QTest::addColumn<int>("index");
    QTest::newRow("First change") << int(1) ;
    QTest::newRow("Second change") << int(0) ;
}

//void TabWidgetUnitTest::testTabVisibleCase2()
//{
//    QFETCH(QString, tabID);
//    QFETCH(bool, visible);

//    mITabWidg->setTabEnabled(tabID.toStdString(), visible);

//    QCOMPARE(mITabWidg->isTabEnabled(tabID.toStdString()), visible);
//}

//void TabWidgetUnitTest::testTabVisibleCase2_data()
//{
//    QTest::addColumn<QString>("tabID");
//    QTest::addColumn<bool>("visible");

//    QTest::newRow("Test tabvisibility - False") << QString(tabPage1) << false;
//    QTest::newRow("Test tabvisibility - True") << QString(tabPage1) << true;
//}


void TabWidgetUnitTest::testTabPageTitleCase3()
{
    QFETCH(QString, tabTitle);
    QFETCH(QString, tabID);

    SUI::TabPage *mITabPage = dynamic_cast<SUI::TabPage *>(mTabPage);
    mITabPage->setTabText(tabTitle.toStdString());

    QCOMPARE(QString::fromStdString(mITabPage->getTabText()), tabTitle);
}

void TabWidgetUnitTest::testTabPageTitleCase3_data()
{
    QTest::addColumn<QString>("tabTitle");
    QTest::addColumn<QString>("tabID");

    QTest::newRow("Rename TabTitle 1") << QString("testTitle") << QString(tabPage2);
}
