
#include "SUISvgWidgetImplUnitTest.h"
#include "SUISvgWidgetImpl.h"
#include "SUIBaseObject.h"

SUI::SvgWidgetImplUnitTest::SvgWidgetImplUnitTest(SUI::SvgWidgetImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::SvgWidgetImplUnitTest::~SvgWidgetImplUnitTest()
{
   delete object;
}

void SUI::SvgWidgetImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
