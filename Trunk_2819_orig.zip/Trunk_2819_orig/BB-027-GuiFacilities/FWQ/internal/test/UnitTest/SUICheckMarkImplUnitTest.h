
#ifndef SUICHECKMARKIMPLUNITTEST_H
#define SUICHECKMARKIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class CheckMarkImpl;

class CheckMarkImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit CheckMarkImplUnitTest(CheckMarkImpl *object, QObject *parent = 0);
    virtual ~CheckMarkImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    CheckMarkImpl *object;
};

}
#endif // SUICHECKMARKIMPLUNITTEST_H
