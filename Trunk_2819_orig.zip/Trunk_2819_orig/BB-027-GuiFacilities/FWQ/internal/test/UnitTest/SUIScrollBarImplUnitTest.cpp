
#include "SUIScrollBarImplUnitTest.h"
#include "SUIScrollBarImpl.h"
#include "SUIBaseObject.h"

SUI::ScrollBarImplUnitTest::ScrollBarImplUnitTest(SUI::ScrollBarImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::ScrollBarImplUnitTest::~ScrollBarImplUnitTest()
{
   delete object;
}

void SUI::ScrollBarImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::EditorForm);
}
