//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::TabWidget.
// !\description Header file for class SUI::TabWidget.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUITABWIDGET_H
#define SUITABWIDGET_H

#include "FWQxWidgets/SUIWidget.h"

namespace SUI {
class TabPage;
/*!
 * \ingroup FWQxWidgets
 *
 * \brief Specific Interface for the Tab Widget
 */
class SUI_SHARED_EXPORT TabWidget : public Widget
{
public:
    virtual ~TabWidget();

    /*!
     * \brief getCurrentIndex
     * Returns the index position of the current tab widget.
     * The result is -1 if there's no current widget
     * \return
     */
    virtual int getCurrentIndex() const = 0;

    /*!
     * \brief getTabIndexOfWidget
     * Returns the index of the tab page with the given id or the tab page
     * that has a child with the given id. Result is -1 if the id cannot be found.
     * \param widget - the widget id that we are looking for
     * \return
     */
    virtual int getTabIndexOfWidget(const std::string &widget) const = 0;

    /*!
     * \brief getTabPage
     * Returns the tab page with index 'index'. Returns NULL if there
     * is no tab page with index 'index'
     * \param index
     * \return
     */
    virtual TabPage *getTabPage(int index) const = 0;

    /*!
     * \brief getCurrentTabPage
     * Returns the current tab page. NULL is returned if no tab page is current
     * \return
     */
    virtual TabPage *getCurrentTabPage() const = 0;

    /*!
     * \brief setTabEnabled
     * Enables a tab page with ID 'tabID' if enabled == true, or
     * disables it (enabled == false)
     * \param tabID - ID of the tab page to be en-/disabled
     * \param enabled - enable or disable
     */
    virtual void setTabEnabled(const std::string &tabID, bool enabled) = 0;

    /*!
     * \brief isTabEnabled
     * Returns whether the tab page with ID 'tabID' is enabled or not
     * \param tabID - the tab page ID
     * \return
     */
    virtual bool isTabEnabled(const std::string &tabID) const = 0;

    /*!
     * \brief focusTabPage
     * Sets focus to the tab page with number 'tabNumber'
     * \param tabNumber - tab page index to set focus to
     */
    virtual void focusTabPage(int tabNumber) = 0;

    /*!
     * \brief currentIndexChanged
     * Callback function that is called when the selected tabpage has changed
     */
    boost::function<void(int)> currentIndexChanged;

protected:
    TabWidget();
};
}

#endif // SUITABWIDGET_H
