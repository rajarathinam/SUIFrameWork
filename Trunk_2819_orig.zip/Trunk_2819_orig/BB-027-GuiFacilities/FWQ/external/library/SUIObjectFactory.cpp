//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for ObjectFactory.
// !\description Class implementation file for ObjectFactory.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "FWQxCore/SUIObjectFactory.h"

#include <cstdlib>
#include <memory>
#include <cxxabi.h>

#include "SUIObjectFactoryImpl.h"

#include "FWQxWidgets/SUIButton.h"
#include "FWQxWidgets/SUILabel.h"
#include "FWQxWidgets/SUILineEdit.h"
#include "FWQxWidgets/SUIRadioButton.h"
#include "FWQxWidgets/SUITabWidget.h"
#include "FWQxWidgets/SUITabPage.h"
#include "FWQxWidgets/SUICheckBox.h"
#include "FWQxWidgets/SUIGroupBox.h"
#include "FWQxWidgets/SUICheckGroupBox.h"
#include "FWQxWidgets/SUIButtonBar.h"
#include "FWQxWidgets/SUITableWidget.h"
#include "FWQxWidgets/SUITableWidgetItem.h"
#include "FWQxWidgets/SUISpinBox.h"
#include "FWQxWidgets/SUIDoubleSpinBox.h"
#include "FWQxWidgets/SUIDropDown.h"
#include "FWQxWidgets/SUICheckMark.h"
#include "FWQxWidgets/SUILEDWidget.h"
#include "FWQxWidgets/SUIColorDrop.h"
#include "FWQxWidgets/SUIColorCrossDrop.h"
#include "FWQxWidgets/SUITextArea.h"
#include "FWQxWidgets/SUIProgressBar.h"
#include "FWQxWidgets/SUIGraphicsView.h"
#include "FWQxWidgets/SUIMessageBox.h"
#include "FWQxWidgets/SUISplitter.h"
#include "FWQxWidgets/SUIFileDialog.h"
#include "FWQxWidgets/SUIUserControl.h"
#include "FWQxWidgets/SUIPlotWidget.h"
#include "FWQxWidgets/SUIListView.h"
#include "FWQxWidgets/SUIControlWidget.h"
#include "FWQxWidgets/SUIStateWidget.h"
#include "FWQxWidgets/SUIScienceSpinBox.h"
#include "FWQxWidgets/SUIQuestionMark.h"
#include "FWQxWidgets/SUIBusyIndicator.h"
#include "FWQxWidgets/SUIImageWidget.h"
#include "FWQxWidgets/SUITreeView.h"
#include "FWQxWidgets/SUITreeViewItem.h"
#include "FWQxWidgets/SUILineWidget.h"
#include "FWQxWidgets/SUISvgWidget.h"
#include "FWQxWidgets/SUIScrollBar.h"
#include "FWQxWidgets/SUIDateTimeEdit.h"
#include "FWQxWidgets/SUIWebView.h"

#include "FWQxGraphicsItems/SUIGraphicsPixmapItem.h"
#include "FWQxGraphicsItems/SUIGraphicsTextItem.h"
#include "FWQxGraphicsItems/SUIGraphicsRectItem.h"
#include "FWQxGraphicsItems/SUIGraphicsLineItem.h"
#include "FWQxGraphicsItems/SUIGraphicsEllipseItem.h"
#include "FWQxGraphicsItems/SUIGraphicsCrosshairItem.h"
#include "FWQxGraphicsItems/SUIGraphicsSvgItem.h"

#include "FWQxWidgets/SUIPlotCurveItem.h"

const SUI::VersionInfo SUI::ObjectFactory::version = SUI::VersionInfo(0,0,0);
const std::string SUI::ObjectFactory::name = "SUI Object factory";
const std::string SUI::ObjectFactory::description = "Constructs Object derived classes.";

const std::map<const std::type_info*,SUI::ObjectFactory::createWidgetFunction> SUI::ObjectFactory::widgetTypeMap = {
    {&typeid(SUI::Button), &SUI::ObjectFactory::createButton},
    {&typeid(SUI::Label), &SUI::ObjectFactory::createLabel},
    {&typeid(SUI::LineEdit), &SUI::ObjectFactory::createLineEdit},
    {&typeid(SUI::RadioButton), &SUI::ObjectFactory::createRadioButton},
    {&typeid(SUI::TabWidget), &SUI::ObjectFactory::createTabWidget},
    {&typeid(SUI::TabPage), &SUI::ObjectFactory::createTabPage},
    {&typeid(SUI::CheckBox), &SUI::ObjectFactory::createCheckBox},
    {&typeid(SUI::GroupBox), &SUI::ObjectFactory::createGroupBox},
    {&typeid(SUI::CheckGroupBox), &SUI::ObjectFactory::createCheckGroupBox},
    {&typeid(SUI::ButtonBar), &SUI::ObjectFactory::createButtonBar},
    {&typeid(SUI::TableWidget), &SUI::ObjectFactory::createTableWidget},
    {&typeid(SUI::TableWidgetItem), &SUI::ObjectFactory::createTableWidgetItem},
    {&typeid(SUI::SpinBox), &SUI::ObjectFactory::createSpinBox},
    {&typeid(SUI::DoubleSpinBox), &SUI::ObjectFactory::createDoubleSpinBox},
    {&typeid(SUI::DropDown), &SUI::ObjectFactory::createDropDown},
    {&typeid(SUI::CheckMark), &SUI::ObjectFactory::createCheckMark},
    {&typeid(SUI::LEDWidget), &SUI::ObjectFactory::createLEDWidget},
    {&typeid(SUI::ColorDrop), &SUI::ObjectFactory::createColorDrop},
    {&typeid(SUI::ColorCrossDrop), &SUI::ObjectFactory::createColorCrossDrop},
    {&typeid(SUI::TextArea), &SUI::ObjectFactory::createTextArea},
    {&typeid(SUI::ProgressBar), &SUI::ObjectFactory::createProgressBar},
    {&typeid(SUI::GraphicsView), &SUI::ObjectFactory::createImageViewer},
    {&typeid(SUI::MessageBox), &SUI::ObjectFactory::createMessageBox},
    {&typeid(SUI::Splitter), &SUI::ObjectFactory::createSplitter},
    {&typeid(SUI::FileDialog), &SUI::ObjectFactory::createFileDialog},
    {&typeid(SUI::UserControl), &SUI::ObjectFactory::createUserControl},
    {&typeid(SUI::PlotWidget), &SUI::ObjectFactory::createPlotWidget},
    {&typeid(SUI::ListView), &SUI::ObjectFactory::createListView},
    {&typeid(SUI::ControlWidget), &SUI::ObjectFactory::createControlWidget},
    {&typeid(SUI::StateWidget), &SUI::ObjectFactory::createStateWidget},
    {&typeid(SUI::ScienceSpinBox), &SUI::ObjectFactory::createScienceSpinBox},
    {&typeid(SUI::QuestionMark), &SUI::ObjectFactory::createQuestionMark},
    {&typeid(SUI::BusyIndicator), &SUI::ObjectFactory::createBusyIndicator},
    {&typeid(SUI::ImageWidget), &SUI::ObjectFactory::createImageWidget},
    {&typeid(SUI::TreeView), &SUI::ObjectFactory::createTreeView},
    {&typeid(SUI::TreeViewItem), &SUI::ObjectFactory::createTreeViewItem},
    {&typeid(SUI::LineWidget), &SUI::ObjectFactory::createLineWidget},
    {&typeid(SUI::SvgWidget), &SUI::ObjectFactory::createSvgWidget},
    {&typeid(SUI::ScrollBar), &SUI::ObjectFactory::createScrollBar},
    {&typeid(SUI::DateTimeEdit), &SUI::ObjectFactory::createDateTimeEdit},
    {&typeid(SUI::WebView), &SUI::ObjectFactory::createWebView}
};


SUI::ObjectFactory::~ObjectFactory()
{
}

SUI::ObjectFactory *SUI::ObjectFactory::getInstance() {
    static ObjectFactoryImpl instance;
    return &instance;
}

std::string SUI::ObjectFactory::getName() const {
    return name;
}

std::string SUI::ObjectFactory::getDescription() const {
    return description;
}

std::string SUI::ObjectFactory::getVersion() const {
    return version.toString();
}

bool SUI::ObjectFactory::isWidget(const std::type_info &typeInfo) const
{ return widgetTypeMap.find(&typeInfo) != widgetTypeMap.end(); }

std::string SUI::ObjectFactory::Demangler::operator()(const char *name) {
   int status = -4;
   p = abi::__cxa_demangle(name,NULL,NULL,&status);
   return std::string(status == 0 ? p : name);       
}

SUI::ObjectFactory::Demangler::~Demangler() {
   std::free(p); 
}

void *SUI::ObjectFactory::getImplementation(GraphicsItem *item) {
    return item ? item->implementation : NULL;
}

void *SUI::ObjectFactory::getPlotImplementation(SUI::PlotItem *item) {
    return item ? item->implementation : NULL;
}
