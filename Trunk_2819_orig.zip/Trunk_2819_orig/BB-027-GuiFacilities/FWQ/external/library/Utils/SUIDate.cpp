//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for Date.
// !\description Class implementation file for Date.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|



#include "FWQxUtils/SUIDate.h"

#include "SUIDateImpl.h"

SUI::Date::~Date()
{
}

boost::shared_ptr<SUI::Date> SUI::Date::createDate() {
    return boost::shared_ptr<Date>(new DateImpl);
}
