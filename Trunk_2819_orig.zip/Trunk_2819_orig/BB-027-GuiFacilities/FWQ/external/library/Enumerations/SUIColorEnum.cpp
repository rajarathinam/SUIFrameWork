//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class ColorEnum.
// !\description Header file for class ColorEnum.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "FWQxCore/SUIColorEnum.h"

#include <algorithm>
#include <sstream>

std::map<SUI::ColorEnum::Color,std::string> SUI::ColorEnum::colorMap =
{
    {SUI::ColorEnum::Standard,"standard"},
    {SUI::ColorEnum::Black,"black"},
    {SUI::ColorEnum::Green,"green"},
    {SUI::ColorEnum::Red,"red"},
    {SUI::ColorEnum::Gray,"gray"},
    {SUI::ColorEnum::Blue,"blue"},
    {SUI::ColorEnum::White,"white"},
    {SUI::ColorEnum::Yellow,"yellow"},
    {SUI::ColorEnum::Orange,"orange"},
    {SUI::ColorEnum::Transparent,"transparent"}

};

std::list<std::string> SUI::ColorEnum::colorStringList =
        std::list<std::string>({
                                   SUI::ColorEnum::toString(SUI::ColorEnum::Standard),
                                   SUI::ColorEnum::toString(SUI::ColorEnum::Black),
                                   SUI::ColorEnum::toString(SUI::ColorEnum::Green),
                                   SUI::ColorEnum::toString(SUI::ColorEnum::Red),
                                   SUI::ColorEnum::toString(SUI::ColorEnum::Gray),
                                   SUI::ColorEnum::toString(SUI::ColorEnum::Blue),
                                   SUI::ColorEnum::toString(SUI::ColorEnum::White),
                                   SUI::ColorEnum::toString(SUI::ColorEnum::Yellow),
                                   SUI::ColorEnum::toString(SUI::ColorEnum::Orange),
                                   SUI::ColorEnum::toString(SUI::ColorEnum::Transparent)

                               });


std::map<SUI::ObjectType::Type,const SUI::ColorEnum::StaticColorList> SUI::ColorEnum::colorsByObjectType =
{
    {SUI::ObjectType::GraphicsCrosshairItem,SUI::ColorEnum::getColorEnumList()},
    {SUI::ObjectType::GraphicsEllipseItem,SUI::ColorEnum::getColorEnumList()},
    {SUI::ObjectType::GraphicsLineItem,SUI::ColorEnum::getColorEnumList()},
    {SUI::ObjectType::GraphicsTextItem,SUI::ColorEnum::getColorEnumList()},
    {SUI::ObjectType::GraphicsRectItem,
     SUI::ColorEnum::StaticColorList{
         SUI::ColorEnum::Black,
         SUI::ColorEnum::Red,
         SUI::ColorEnum::Green,
         SUI::ColorEnum::Blue,
         SUI::ColorEnum::Gray,
         SUI::ColorEnum::Yellow

     }},
    {SUI::ObjectType::GraphicsSvgItem,SUI::ColorEnum::getColorEnumList()},
    {SUI::ObjectType::PlotCurveItem,
     SUI::ColorEnum::StaticColorList{
         SUI::ColorEnum::Black,
         SUI::ColorEnum::Blue,
         SUI::ColorEnum::Green,
         SUI::ColorEnum::Red,
         SUI::ColorEnum::Yellow,
         SUI::ColorEnum::Gray,
         SUI::ColorEnum::White,
         SUI::ColorEnum::Orange
     }},
    {SUI::ObjectType::PlotHistogramItem,
     SUI::ColorEnum::StaticColorList{
         SUI::ColorEnum::Black,
         SUI::ColorEnum::Blue,
         SUI::ColorEnum::Green,
         SUI::ColorEnum::Red,
         SUI::ColorEnum::Yellow,
         SUI::ColorEnum::Gray,
         SUI::ColorEnum::White,
         SUI::ColorEnum::Orange
     }},
    {SUI::ObjectType::CheckMark,
     SUI::ColorEnum::StaticColorList{
         SUI::ColorEnum::Red,
         SUI::ColorEnum::Green,
     }},
    {SUI::ObjectType::ColorCrossDrop,SUI::ColorEnum::getColorEnumList()},
    {SUI::ObjectType::ColorDrop,SUI::ColorEnum::getColorEnumList()},
    {SUI::ObjectType::TableWidgetItem,
     SUI::ColorEnum::StaticColorList{
         SUI::ColorEnum::Standard,
         SUI::ColorEnum::Red,
         SUI::ColorEnum::White,
         SUI::ColorEnum::Green,
         SUI::ColorEnum::Blue,
         SUI::ColorEnum::Gray,
         SUI::ColorEnum::Yellow,
         SUI::ColorEnum::Orange
     }},
    {SUI::ObjectType::DropDown,
     SUI::ColorEnum::StaticColorList{
         SUI::ColorEnum::Standard,
         SUI::ColorEnum::Red,
         SUI::ColorEnum::Green,
         SUI::ColorEnum::Blue,
         SUI::ColorEnum::Gray,
         SUI::ColorEnum::Yellow

     }},
    {SUI::ObjectType::LEDWidget,
     SUI::ColorEnum::StaticColorList{
         SUI::ColorEnum::Red,
         SUI::ColorEnum::Green,
         SUI::ColorEnum::Blue,
         SUI::ColorEnum::Gray,
         SUI::ColorEnum::White,
         SUI::ColorEnum::Yellow
     }},
    {SUI::ObjectType::Label,
     SUI::ColorEnum::StaticColorList{
         SUI::ColorEnum::Transparent,
         SUI::ColorEnum::Standard,
         SUI::ColorEnum::White,
         SUI::ColorEnum::Red,
         SUI::ColorEnum::Green,
         SUI::ColorEnum::Blue,
         SUI::ColorEnum::Gray,
         SUI::ColorEnum::Yellow,
         SUI::ColorEnum::Orange

     }},
    {SUI::ObjectType::LineEdit,
     SUI::ColorEnum::StaticColorList{
         SUI::ColorEnum::Standard,
         SUI::ColorEnum::Red,
         SUI::ColorEnum::Green,
         SUI::ColorEnum::Blue,
         SUI::ColorEnum::Gray,
         SUI::ColorEnum::Yellow,
         SUI::ColorEnum::Orange
     }},
    {SUI::ObjectType::ProgressBar,
     SUI::ColorEnum::StaticColorList{
         SUI::ColorEnum::Standard,
         SUI::ColorEnum::Red,
         SUI::ColorEnum::Green,
         SUI::ColorEnum::Blue,
         SUI::ColorEnum::Gray,
         SUI::ColorEnum::Yellow
     }},
    {SUI::ObjectType::SvgWidget,SUI::ColorEnum::getColorEnumList()},
    {SUI::ObjectType::TextArea,
     SUI::ColorEnum::StaticColorList{
         SUI::ColorEnum::Standard,
         SUI::ColorEnum::Black,
         SUI::ColorEnum::Red,
         SUI::ColorEnum::Green,
         SUI::ColorEnum::Blue,
         SUI::ColorEnum::Gray,
         SUI::ColorEnum::Yellow
     }}

};

SUI::ColorEnum::Color SUI::ColorEnum::fromString(const std::string &colorStr) {
    std::string color;
    color.resize(colorStr.size());
    std::transform(colorStr.begin(),colorStr.end(),color.begin(),::tolower);

    if (color == toString(Standard)) return Standard;
    if (color == toString(Black)) return Black;
    if (color == toString(Green)) return Green;
    if (color == toString(Red)) return Red;
    if (color == toString(Gray)) return Gray;
    if (color == toString(Blue)) return Blue;
    if (color == toString(Yellow)) return Yellow;
    if (color == toString(White)) return White;
    if (color == toString(Transparent)) return Transparent;
    if (color == toString(Orange)) return Orange;
    return Standard;
}
std::string SUI::ColorEnum::toString(Color color) {
    std::map<Color,std::string> m = getColorMap();
    std::map<Color,std::string>::const_iterator it = m.find(color);
    return it == m.end() ? m.find(ColorEnum::Standard)->second : it->second;
}

const std::list<SUI::ColorEnum::Color> SUI::ColorEnum::getColorEnumList(const SUI::ObjectType::Type &objectType) {
    std::map<SUI::ObjectType::Type,const StaticColorList>::const_iterator it = colorsByObjectType.find(objectType);
    return it != colorsByObjectType.end() ? it->second : std::list<Color>({ Standard,Black,Green,Red,Gray,Blue,White,Yellow,Orange,Transparent });
}


std::list<std::string> SUI::ColorEnum::toStringList(const std::list<Color> &list) {
    std::list<std::string> stringList;
    for (std::list<ColorEnum::Color>::const_iterator i = list.begin(); i != list.end(); ++i) {
        stringList.push_back(toString((*i)));
    }
    return stringList;
}

std::string SUI::ColorEnum::toString(const std::list<Color> &list, const std::string &separator) {
    std::stringstream ss;
    for (std::list<ColorEnum::Color>::const_iterator i = list.begin(); i != list.end(); ++i) {
        ss << toString(*i) << separator;
    }
    std::string s = ss.str();
    return s.substr(0,s.size()-1);
}

bool SUI::ColorEnum::exists(const std::list<Color> &list, const Color &entry) {
    return std::find(list.begin(),list.end(),entry) != list.end();
}

std::list<std::string> SUI::ColorEnum::getColorStringList() {
    return colorStringList;
}

std::map<SUI::ColorEnum::Color, std::string> SUI::ColorEnum::getColorMap() {
    return colorMap;
}

std::string SUI::ColorEnum::getColorsString() {
    return colorsString;
}

std::string SUI::ColorEnum::colorsString = SUI::ColorEnum::toString(SUI::ColorEnum::getColorEnumList(),";");
