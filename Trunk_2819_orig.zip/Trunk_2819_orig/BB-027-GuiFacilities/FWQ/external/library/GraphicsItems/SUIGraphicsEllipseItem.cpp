//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for GraphicsEllipseItem.
// !\description Class implementation file for GraphicsEllipseItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "FWQxGraphicsItems/SUIGraphicsEllipseItem.h"

#include "CustomGraphicsEllipseItem.h"

#include "FWQxCore/SUIObjectFactory.h"

#include <QBrush>
#include <QPen>

SUI::GraphicsEllipseItem::GraphicsEllipseItem(SUI::GraphicsItem *parent) : 
    GraphicsItem(
          SUI::ObjectType::GraphicsEllipseItem,
          new CustomGraphicsEllipseItem(QRectF(),parent ? static_cast<QGraphicsItem*>(ObjectFactory::getImplementation(parent)) : NULL),
          parent),
    penColor(SUI::ColorEnum::Black)
{
    
    setPenColor(ColorEnum::Black);
    setBrushColor(ColorEnum::Transparent);
}

SUI::GraphicsEllipseItem::~GraphicsEllipseItem()
{
    delete static_cast<CustomGraphicsEllipseItem*>(GraphicsItem::getImplementation());
}

SUI::ColorEnum::Color SUI::GraphicsEllipseItem::getPenColor() const {
    return penColor;
}

void SUI::GraphicsEllipseItem::setPenColor(const SUI::ColorEnum::Color color) {
    if (!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color)) return;
    penColor = color;
    QGraphicsEllipseItem *item = static_cast<CustomGraphicsEllipseItem*>(GraphicsItem::getImplementation());
    QPen pen = item->pen();
    pen.setColor(QColor(QString::fromStdString(ColorEnum::toString(color))));
    item->setPen(pen);
}

SUI::ColorEnum::Color SUI::GraphicsEllipseItem::getBrushColor() const {
    return getPenColor();
}

void SUI::GraphicsEllipseItem::setBrushColor(const SUI::ColorEnum::Color color) {
    if (!ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color) && color != ColorEnum::Transparent) return;
    if (color != ColorEnum::Transparent) {
        setPenColor(color);
    }
    static_cast<QGraphicsEllipseItem*>(GraphicsItem::getImplementation())->setBrush(color == ColorEnum::Transparent ? Qt::NoBrush : QBrush(QColor(QString::fromStdString(ColorEnum::toString(color)))));
}

void SUI::GraphicsEllipseItem::setPenWidth(int width) {
    QGraphicsEllipseItem *item = static_cast<CustomGraphicsEllipseItem*>(GraphicsItem::getImplementation());
    QPen pen = item->pen();
    pen.setWidth(width < 1 ? 1 : (width < 6 ? width : 5));
    item->setPen(pen);
}

int SUI::GraphicsEllipseItem::getPenWidth() const {
    return static_cast<QGraphicsEllipseItem*>(GraphicsItem::getImplementation())->pen().width();
}

void SUI::GraphicsEllipseItem::setCosmetic(bool enabled) {
   QGraphicsEllipseItem *item = static_cast<CustomGraphicsEllipseItem*>(GraphicsItem::getImplementation());
   QPen pen = item->pen();
   pen.setCosmetic(enabled);
   item->setPen(pen);
}

void SUI::GraphicsEllipseItem::setSize(double width, double height) {
    QGraphicsEllipseItem *item = static_cast<CustomGraphicsEllipseItem*>(GraphicsItem::getImplementation());
    item->setRect(QRectF(item->rect().topLeft(),QSizeF(width,height)));
}

double SUI::GraphicsEllipseItem::getWidth() const {
    return static_cast<CustomGraphicsEllipseItem*>(GraphicsItem::getImplementation())->rect().width();
}

double SUI::GraphicsEllipseItem::getHeight() const {
    return static_cast<CustomGraphicsEllipseItem*>(GraphicsItem::getImplementation())->rect().height();
}


