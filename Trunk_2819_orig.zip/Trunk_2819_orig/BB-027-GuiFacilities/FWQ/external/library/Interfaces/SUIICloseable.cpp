//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for ICloseable.
// !\description Class implementation file for ICloseable.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "FWQxCore/SUIICloseable.h"


SUI::ICloseable::ICloseable()
{
    closeable = true ;
}

bool SUI::ICloseable::isCloseable() {
    return closeable;
}


void SUI::ICloseable::setCloseable(bool value) {
    closeable = value;
}
