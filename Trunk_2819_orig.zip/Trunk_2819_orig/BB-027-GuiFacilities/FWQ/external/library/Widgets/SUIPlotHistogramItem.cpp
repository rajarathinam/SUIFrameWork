//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for PlotHistogramItem.
// !\description Class implementation file for PlotHistogramItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "FWQxWidgets/SUIPlotHistogramItem.h"
#include "SUIPlotWidgetImpl.h"
#include "FWQxCore/SUIObjectFactory.h"

#include <qwt_plot_histogram.h>

SUI::PlotHistogramItem::PlotHistogramItem(const std::string &title) :
    PlotItem(
        SUI::ObjectType::PlotHistogramItem, new QwtPlotHistogram(QString::fromStdString(title))
        ),
    penColor(SUI::ColorEnum::Black),
    brushColor(SUI::ColorEnum::Black)
{ 
    static_cast<QwtPlotHistogram*>(PlotItem::getImplementation())->setStyle(QwtPlotHistogram::HistogramStyle::Columns);
}

SUI::PlotHistogramItem::~PlotHistogramItem() {
    delete static_cast<QwtPlotHistogram*>(PlotItem::getImplementation());
    PlotItem::setImplementation(NULL);
}

void SUI::PlotHistogramItem::attach(PlotWidget *plot) {
    if(plot != NULL){
        static_cast<QwtPlotHistogram*>(PlotItem::getImplementation())->attach(dynamic_cast<SUI::PlotWidgetImpl *>(plot)->getPlot());
    }
}

void SUI::PlotHistogramItem::detach() {
    intervalSamples.clear();
    static_cast<QwtPlotHistogram*>(PlotItem::getImplementation())->detach();
}

void SUI::PlotHistogramItem::setTitle(const std::string &title) {
    static_cast<QwtPlotHistogram*>(PlotItem::getImplementation())->setTitle(QString::fromStdString(title));
}

std::string SUI::PlotHistogramItem::getTitle() const {
    return static_cast<QwtPlotHistogram*>(PlotItem::getImplementation())->title().text().toStdString();
}

void SUI::PlotHistogramItem::show() {
    static_cast<QwtPlotHistogram*>(PlotItem::getImplementation())->show();
}

void SUI::PlotHistogramItem::hide() {
    static_cast<QwtPlotHistogram*>(PlotItem::getImplementation())->hide();
}

void SUI::PlotHistogramItem::setVisible(bool visible) {
    static_cast<QwtPlotHistogram*>(PlotItem::getImplementation())->setVisible(visible);
}

bool SUI::PlotHistogramItem::isVisible() const {
    return static_cast<QwtPlotHistogram*>(PlotItem::getImplementation())->isVisible();
}

void SUI::PlotHistogramItem::setAxes(SUI::PlotAxisEnum::PlotAxis xAxis, SUI::PlotAxisEnum::PlotAxis yAxis) {
    static_cast<QwtPlotHistogram*>(PlotItem::getImplementation())->setAxes(toQwtAxis(xAxis), toQwtAxis(yAxis));
}

void SUI::PlotHistogramItem::setXAxis(SUI::PlotAxisEnum::PlotAxis xAxis) {
    static_cast<QwtPlotHistogram*>(PlotItem::getImplementation())->setXAxis(toQwtAxis(xAxis));
}

SUI::PlotAxisEnum::PlotAxis SUI::PlotHistogramItem::getXAxis() const {
    return toSuiAxisEnum(static_cast<QwtPlotHistogram*>(PlotItem::getImplementation())->xAxis());
}

void SUI::PlotHistogramItem::setYAxis(SUI::PlotAxisEnum::PlotAxis axis) {
    static_cast<QwtPlotHistogram*>(PlotItem::getImplementation())->setYAxis(toQwtAxis(axis));
}

SUI::PlotAxisEnum::PlotAxis SUI::PlotHistogramItem::getYAxis() const {
    return toSuiAxisEnum(static_cast<QwtPlotHistogram*>(PlotItem::getImplementation())->yAxis());
}

double SUI::PlotHistogramItem::getZ() const {
    return static_cast<QwtPlotHistogram*>(PlotItem::getImplementation())->z();
}

void SUI::PlotHistogramItem::setZ(double z) {
    static_cast<QwtPlotHistogram*>(PlotItem::getImplementation())->setZ(z);
}

SUI::ColorEnum::Color SUI::PlotHistogramItem::getPenColor() const {
    return penColor;
}

void SUI::PlotHistogramItem::setPenColor(const SUI::ColorEnum::Color color) {
    if(penColor == color) return;
    if (ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color) == true) {
        penColor = color;
        static_cast<QwtPlotHistogram*>(PlotItem::getImplementation())->setPen(QColor(QString::fromStdString(SUI::ColorEnum::toString(penColor))));
    }
}

void SUI::PlotHistogramItem::setPenWidth(int width) {
    QPen pen = static_cast<QwtPlotHistogram*>(PlotItem::getImplementation())->pen();
    pen.setWidth(width);
    static_cast<QwtPlotHistogram*>(PlotItem::getImplementation())->setPen(pen);

}

int SUI::PlotHistogramItem::getPenWidth() const {
    return static_cast<QwtPlotHistogram*>(PlotItem::getImplementation())->pen().width();
}

SUI::ColorEnum::Color SUI::PlotHistogramItem::getBrushColor() const {
    return brushColor;
}

void SUI::PlotHistogramItem::setBrushColor(const SUI::ColorEnum::Color color) {
    if(brushColor == color) return ;
    if (ColorEnum::exists(ColorEnum::getColorEnumList(Object::getObjectType()),color) == true) {
        brushColor = color;
        static_cast<QwtPlotHistogram*>(PlotItem::getImplementation())->setBrush(QColor(QString::fromStdString(SUI::ColorEnum::toString(brushColor))));
    }
}

void SUI::PlotHistogramItem::setSamples(const std::vector<SUI::PlotIntervalSample> &values) {
    for (uint i = 0; i < values.size(); i++)
    {
        intervalSamples.push_back(values.at(i));
    }
    plotHistogram();
}

void SUI::PlotHistogramItem::setSample(const SUI::PlotIntervalSample &value) {
    intervalSamples.push_back(value);
    plotHistogram();
}

void SUI::PlotHistogramItem::clearSamples() {
    intervalSamples.clear();
    //draw an empty histogram
    SUI::PlotIntervalSample sample(0.0,0.0,0.0);
    setSample(sample);
    intervalSamples.clear();
}

void SUI::PlotHistogramItem::plotHistogram() {
    QVector<QwtIntervalSample> samples(intervalSamples.size());
    for (uint i = 0; i < intervalSamples.size(); i++)
    {
        samples[i] = QwtIntervalSample(static_cast<SUI::PlotIntervalSample>(intervalSamples.at(i)).getValue(),
                                       static_cast<SUI::PlotIntervalSample>(intervalSamples.at(i)).getMinValue(),
                                       static_cast<SUI::PlotIntervalSample>(intervalSamples.at(i)).getMaxValue() );
    }
    static_cast<QwtPlotHistogram*>(PlotItem::getImplementation())->setData(new QwtIntervalSeriesData( samples));
}

void SUI::PlotHistogramItem::setCustomPenColor( const SUI::PlotItemCustomColor color) {
    static_cast<QwtPlotHistogram*>(PlotItem::getImplementation())->setPen(
                QPen(QColor(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha())));
}

SUI::PlotItemCustomColor SUI::PlotHistogramItem::getCustomPenColor() const {
    QPen pen = static_cast<QwtPlotHistogram*>(PlotItem::getImplementation())->pen();
    return SUI::PlotItemCustomColor(pen.color().red(), pen.color().green(),
                                    pen.color().blue(), pen.color().alpha());
}

void SUI::PlotHistogramItem::setCustomBrushColor( const SUI::PlotItemCustomColor color) {
    static_cast<QwtPlotHistogram*>(PlotItem::getImplementation())->setBrush(
                QBrush(QColor(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha())));
}

SUI::PlotItemCustomColor SUI::PlotHistogramItem::getCustomBrushColor() const {
    QBrush brush = static_cast<QwtPlotHistogram*>(PlotItem::getImplementation())->brush();
    return SUI::PlotItemCustomColor(brush.color().red(), brush.color().green(),
                                    brush.color().blue(), brush.color().alpha());
}

