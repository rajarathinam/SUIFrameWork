//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for LEDWidget.
// !\description Class implementation file for LEDWidget.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "FWQxWidgets/SUILEDWidget.h"

#include "FWQxCore/SUIObjectFactory.h"

SUI::LEDWidget::LEDWidget() : 
    Widget(SUI::ObjectType::LEDWidget)
{
}

SUI::LEDWidget::~LEDWidget()
{
}
