#ifndef DATETIMEEDITTEST_H
#define DATETIMEEDITTEST_H

namespace SUI {
class Dialog;
class Button;
class DateTimeEdit;
}

class DateTimeEditTest
{
public:
    DateTimeEditTest(SUI::Dialog *dialog);
    virtual ~DateTimeEditTest();

private:
    void onGetDateClicked();
    void onGetTimeClicked();
    void onSetDateClicked();
    void onSetTimeClicked();
    void onSetTimeSpecClicked();
    void onGetTimeSpecClicked();

    SUI::Dialog *dialog;
    SUI::DateTimeEdit *dateTime;

    SUI::Button *getDate;
    SUI::Button *getTime;
    SUI::Button *getTimeSpec;
    SUI::Button *setDate;
    SUI::Button *setTime;
    SUI::Button *setTimeSpec;


};

#endif // DATETIMEEDITTEST_H
