#include "PlotCurveItemTest.h"

#include <map>
#include <sstream>
#include <SUIPlotWidget.h>
#include <SUIPlotAxisEnum.h>
#include <SUIPlotCurveItem.h>
#include <SUIDropDown.h>
#include <SUIButton.h>
#include <SUICheckBox.h>
#include <SUILineEdit.h>
#include <SUIINumeric.h>
#include <SUIPlotDataPoint.h>
#include <boost/bind.hpp>

#include <SUIObjectFactory.h>
#include <SUIDialog.h>
#include <SUIObjectList.h>

#include <QStringList>
#include <QString>
#include <QDebug>
#include <SUITimer.h>

PlotCurveTest::PlotCurveTest(SUI::Dialog *dialog) :
    dialog(dialog),
    plotWidget(dialog->getObjectList()->getObject<SUI::PlotWidget>("plw299")),
    addCurve(dialog->getObjectList()->getObject<SUI::Button>("btn300")),
    deleteCurve(dialog->getObjectList()->getObject<SUI::Button>("btn877")),
    hideCurve(dialog->getObjectList()->getObject<SUI::Button>("btn461")),
    addSamples(dialog->getObjectList()->getObject<SUI::Button>("btn805")),
    addRawSamples(dialog->getObjectList()->getObject<SUI::Button>("btn972")),
    clearCurve(dialog->getObjectList()->getObject<SUI::Button>("btn302")),
    setCurve(dialog->getObjectList()->getObject<SUI::Button>("btn325")),
    showCurve(dialog->getObjectList()->getObject<SUI::Button>("btn468")),
    addSample(dialog->getObjectList()->getObject<SUI::Button>("btn303")),
    addScientificSample(dialog->getObjectList()->getObject<SUI::Button>("btn1042")),
    testScenario1(dialog->getObjectList()->getObject<SUI::Button>("btn1186")),
    plotMarker(dialog->getObjectList()->getObject<SUI::CheckBox>("cbx1053")),
    yAxisLeft(dialog->getObjectList()->getObject<SUI::CheckBox>("cbx1158")),
    yAxisRight(dialog->getObjectList()->getObject<SUI::CheckBox>("cbx1160")),
    xAxisBottom(dialog->getObjectList()->getObject<SUI::CheckBox>("cbx1159")),
    xAxisTop(dialog->getObjectList()->getObject<SUI::CheckBox>("cbx1161")),
    le_curveName(dialog->getObjectList()->getObject<SUI::LineEdit>("lne301")),
    le_addSamples(dialog->getObjectList()->getObject<SUI::LineEdit>("lne806")),
    le_addRawSamples(dialog->getObjectList()->getObject<SUI::LineEdit>("lne973")),
    dd_yaxis(dialog->getObjectList()->getObject<SUI::DropDown>("ddb308"))
{
    assert(dialog);
    assert(plotWidget);
    assert(addCurve);
    assert(deleteCurve);
    assert(hideCurve);
    assert(addSamples);
    assert(addRawSamples);
    assert(clearCurve);
    assert(setCurve);
    assert(showCurve);
    assert(addSample);
    assert(addScientificSample);
    assert(testScenario1);
    assert(plotMarker);
    assert(yAxisLeft);
    assert(yAxisRight);
    assert(xAxisBottom);
    assert(xAxisTop);
    assert(le_curveName);
    assert(le_addSamples);
    assert(le_addRawSamples);
    assert(dd_yaxis);

    count = 0;
    addCurve->clicked = boost::bind(&PlotCurveTest::onAddCurveClicked, this);
    deleteCurve->clicked = boost::bind(&PlotCurveTest::onDeleteCurveClicked, this);
    hideCurve->clicked = boost::bind(&PlotCurveTest::onHideCurveClicked, this);
    clearCurve->clicked = boost::bind(&PlotCurveTest::onClearCurveClicked, this);
    setCurve->clicked = boost::bind(&PlotCurveTest::onSetCurveClicked, this);
    plotMarker->checkStateChanged = boost::bind(&PlotCurveTest::onPlotMarkerChecked , this, _1);
    addRawSamples->clicked = boost::bind(&PlotCurveTest::onAddRawSamplesClicked, this);
    addSamples->clicked = boost::bind(&PlotCurveTest::onAddSamplesClicked, this);
    showCurve->clicked = boost::bind(&PlotCurveTest::onShowCurveClicked, this);
    addSample->clicked = boost::bind(&PlotCurveTest::onAddSampleClicked,this);
    addScientificSample->clicked = boost::bind(&PlotCurveTest::onAddScientificSampleClicked, this);
    testScenario1->clicked = boost::bind(&PlotCurveTest::onTestScenario1Clicked, this);
    plotWidget->clicked = boost::bind(&PlotCurveTest::onPlotWidgetClicked, this);
    yAxisLeft->checkStateChanged = boost::bind(&PlotCurveTest::onAxisVisibleChecked , this);
    yAxisRight->checkStateChanged = boost::bind(&PlotCurveTest::onAxisVisibleChecked , this);
    xAxisBottom->checkStateChanged = boost::bind(&PlotCurveTest::onAxisVisibleChecked , this);
    xAxisTop->checkStateChanged = boost::bind(&PlotCurveTest::onAxisVisibleChecked , this);
}

PlotCurveTest::~PlotCurveTest() {
    mapPlotCurves.clear();
    delete plotWidget;
    delete addCurve;
    delete deleteCurve;
    delete hideCurve;
    delete addSamples;
    delete addRawSamples;
    delete clearCurve;
    delete plotMarker;
    delete le_addRawSamples;
    delete le_addSamples;
    delete le_curveName;
    delete dd_yaxis;
    delete showCurve;
    delete addSample;
    delete yAxisLeft;
    delete yAxisRight;
    delete xAxisBottom;
    delete xAxisTop;
}

void PlotCurveTest::onAddCurveClicked() {
    auto it = mapPlotCurves.find(le_curveName->getText());
    if(it != mapPlotCurves.end()) return;

    SUI::PlotAxisEnum::PlotAxis yAxis = SUI::PlotAxisEnum::yLeft;
    if(dd_yaxis->getSelectedItems().front() == "Right") yAxis = SUI::PlotAxisEnum::yRight;
    SUI::PlotCurveItem *curve = new SUI::PlotCurveItem(le_curveName->getText(), yAxis);
    curve->attach(plotWidget);

    mapPlotCurves.insert(std::pair<std::string, SUI::PlotCurveItem*>(le_curveName->getText(), curve));
    plotWidget->replot();
}

void PlotCurveTest::onDeleteCurveClicked() {
    auto it = mapPlotCurves.find(le_curveName->getText());
    if(it == mapPlotCurves.end()) return;

    SUI::PlotCurveItem *curve = mapPlotCurves.at(le_curveName->getText());
    curve->detach();
    mapPlotCurves.erase(it);
    plotWidget->replot();
}

void PlotCurveTest::onHideCurveClicked() {
    auto it = mapPlotCurves.find(le_curveName->getText());
    if(it == mapPlotCurves.end()) return;

    SUI::PlotCurveItem *curve = mapPlotCurves.at(le_curveName->getText());
    curve->hide();
    plotWidget->replot();
}

void PlotCurveTest::onClearCurveClicked() {
    auto it = mapPlotCurves.find(le_curveName->getText());
    if(it == mapPlotCurves.end()) return;

    SUI::PlotCurveItem *curve = mapPlotCurves.at(le_curveName->getText());
    curve->clearSamples();
    plotWidget->replot();
}

void PlotCurveTest::onAddRawSamplesClicked() {
    auto it = mapPlotCurves.find(le_curveName->getText());
    if(it == mapPlotCurves.end()) return;

    SUI::PlotCurveItem *curve = mapPlotCurves.at(le_curveName->getText());
    std::stringstream ss(le_addRawSamples->getText());
    std::string split;
    int count = 0;
    while (std::getline(ss, split, ';'))
    {
        QString qStrCoordinates = QString::fromUtf8(split.c_str());
        QStringList qStrXandY = qStrCoordinates.split(",", QString::SkipEmptyParts);
        if ((qStrXandY.size() == 2) && !qStrXandY.at(0).isEmpty() && !qStrXandY.at(1).isEmpty())
        {
            xRawData[count] = qStrXandY.at(0).toDouble();
            yRawData[count] = qStrXandY.at(1).toDouble();
            ++count;
        }
    }
    curve->setRawSamples(xRawData, yRawData, count);
    plotWidget->replot();
}

void PlotCurveTest::onAddSamplesClicked() {
    auto it = mapPlotCurves.find(le_curveName->getText());
    if(it == mapPlotCurves.end()) return;
    SUI::PlotCurveItem *curve = mapPlotCurves.at(le_curveName->getText());
    std::stringstream ss(le_addSamples->getText());
    std::string split;
    std::vector<SUI::PlotDataPoint> dataPoints;
    while (std::getline(ss, split, ';'))
    {
        QString qStrCoordinates = QString::fromUtf8(split.c_str());
        QStringList qStrXandY = qStrCoordinates.split(",", QString::SkipEmptyParts);
        if ((qStrXandY.size() == 2) && !qStrXandY.at(0).isEmpty() && !qStrXandY.at(1).isEmpty())
        {
            SUI::PlotDataPoint point(qStrXandY.at(0).toDouble(),qStrXandY.at(1).toDouble());
            dataPoints.push_back(point);
        }
    }
    curve->setSamples(dataPoints);
    plotWidget->replot();
}

void PlotCurveTest::onPlotMarkerChecked(bool check) {

    auto it = mapPlotCurves.find(le_curveName->getText());
    if(it == mapPlotCurves.end()) return;
    SUI::PlotCurveItem *curve = mapPlotCurves.at(le_curveName->getText());

    SUI::DropDown *dropColWidget = dialog->getObjectList()->getObject<SUI::DropDown>("ddb1056");
    if (dropColWidget)
    {
        QString color = QString::fromStdString(dropColWidget->getSelectedItems().front());
        SUI::DropDown *dropLineType = dialog->getObjectList()->getObject<SUI::DropDown>("ddb1055");
        if (dropLineType)
        {
            SUI::INumeric<int> *widgetNum = dialog->getObjectList()->getObject<SUI::INumeric<int>>("isb1057");
            if (widgetNum)
            {
                int penwidth = widgetNum->getValue();
                SUI::ColorEnum::Color Color;
                if (color == "Blue")
                {
                    Color = SUI::ColorEnum::Blue;
                }
                else if (color == "Green")
                {
                    Color = SUI::ColorEnum::Green;
                }
                else if (color == "Red")
                {
                    Color = SUI::ColorEnum::Red;
                }
                else if (color == "Yellow")
                {
                    Color = SUI::ColorEnum::Yellow;
                }
                else
                {
                    Color = SUI::ColorEnum::Black;
                }

                QString marker = QString::fromStdString(dropLineType->getSelectedItems().front());
                SUI::MarkerSymbolEnum::MarkerSymbol markerSymbol;
                if (marker == "NoSymbol")
                {
                    markerSymbol = SUI::MarkerSymbolEnum::NoSymbol;
                }
                else if (marker == "Ellipse")
                {
                    markerSymbol = SUI::MarkerSymbolEnum::Ellipse;
                }
                else if (marker == "Rect")
                {
                    markerSymbol = SUI::MarkerSymbolEnum::Rect;
                }
                else if (marker == "Diamond")
                {
                    markerSymbol = SUI::MarkerSymbolEnum::Diamond;
                }
                else if (marker == "Traingle")
                {
                    markerSymbol = SUI::MarkerSymbolEnum::Triangle;
                }
                else if (marker == "Cross")
                {
                    markerSymbol = SUI::MarkerSymbolEnum::Cross;
                }
                else
                {
                    markerSymbol = SUI::MarkerSymbolEnum::Star;
                }

                if(check) { curve->setPlotMarker(markerSymbol, Color, penwidth);}
                else { curve->setPlotMarker(SUI::MarkerSymbolEnum::NoSymbol, Color, penwidth);}
                plotWidget->replot();
            }
        }
    }
}

void PlotCurveTest::onSetCurveClicked() {
    auto it = mapPlotCurves.find(le_curveName->getText());
    if(it == mapPlotCurves.end()) return;
    SUI::PlotCurveItem *curve = mapPlotCurves.at(le_curveName->getText());

    SUI::DropDown *dropColWidget = dialog->getObjectList()->getObject<SUI::DropDown>("ddb322");
    if (curve && dropColWidget)
    {
        QString color = QString::fromStdString(dropColWidget->getSelectedItems().front());
        SUI::ColorEnum::Color Color;
        if (color == "Blue")
        {
            Color = SUI::ColorEnum::Blue;
        }
        else if (color == "Green")
        {
            Color = SUI::ColorEnum::Green;
        }
        else if (color == "Red")
        {
            Color = SUI::ColorEnum::Red;
        }
        else if (color == "Yellow")
        {
            Color = SUI::ColorEnum::Yellow;
        }
        else
        {
            Color = SUI::ColorEnum::Black;
        }
        //setColor
        curve->setColor(Color);
    }

    SUI::DropDown *dropLineType = dialog->getObjectList()->getObject<SUI::DropDown>("ddb323");
    if (curve && dropLineType)
    {
        QString linetype = QString::fromStdString(dropLineType->getSelectedItems().front());
        SUI::LineStyleEnum::LineStyle linestyle;
        if (linetype == "Dash")
        {
            linestyle = SUI::LineStyleEnum::Dash;
        }
        else if (linetype == "Dot")
        {
            linestyle = SUI::LineStyleEnum::Dot;
        }
        else if (linetype == "DashDot")
        {
            linestyle = SUI::LineStyleEnum::DashDot;
        }
        else if (linetype == "DashDotDotLine")
        {
            linestyle = SUI::LineStyleEnum::DashDotLine;
        }
        else
        {
            linestyle = SUI::LineStyleEnum::Solid;
        }
        //setStyle
        curve->setStyle(linestyle);
    }
    SUI::INumeric<int> *widgetNum = dialog->getObjectList()->getObject<SUI::INumeric<int>>("isb324");
    if (curve && widgetNum)
    {
        int penwidth = widgetNum->getValue();
        //setWidth
        curve->setWidth(penwidth);
    }
    plotWidget->replot();
}

void PlotCurveTest::onShowCurveClicked() {
    auto it = mapPlotCurves.find(le_curveName->getText());
    if(it == mapPlotCurves.end()) return;
    SUI::PlotCurveItem *curve = mapPlotCurves.at(le_curveName->getText());

    curve->show();
    plotWidget->replot();
}

void PlotCurveTest::onAddSampleClicked() {
    auto it = mapPlotCurves.find(le_curveName->getText());
    if(it == mapPlotCurves.end()) return;
    SUI::PlotCurveItem *curve = mapPlotCurves.at(le_curveName->getText());

    SUI::INumeric<double> *x = dialog->getObjectList()->getObject<SUI::INumeric<double>>("dsb1105");
    SUI::INumeric<double> *y = dialog->getObjectList()->getObject<SUI::INumeric<double>>("dsb1106");
    if(x && y) {
        SUI::PlotDataPoint point(x->getValue(), y->getValue());
        curve->setSample(point);
        plotWidget->replot();
    }
}

void PlotCurveTest::onAddScientificSampleClicked() {
    auto it = mapPlotCurves.find(le_curveName->getText());
    if(it == mapPlotCurves.end()) return;
    SUI::PlotCurveItem *curve = mapPlotCurves.at(le_curveName->getText());

    SUI::INumeric<double> *x = dialog->getObjectList()->getObject<SUI::INumeric<double>>("ssb1049");
    SUI::INumeric<double> *y = dialog->getObjectList()->getObject<SUI::INumeric<double>>("ssb1050");
    if(x && y) {
        SUI::PlotDataPoint point(x->getValue(), y->getValue());
        curve->setSample(point);
        plotWidget->replot();
    }
}

void PlotCurveTest::onPlotWidgetClicked() {
    count ++;
    SUI::IText *statusBar = dialog->getObjectList()->getObject<SUI::IText>("txaStatus");
    statusBar->setText(QString("Plot Widget Clicked : %1 ").arg(QString::number(count)).toStdString());
}

void PlotCurveTest::onAxisVisibleChecked() {
        plotWidget->setAxisVisible(SUI::PlotAxisEnum::yLeft, yAxisLeft->isChecked());
        plotWidget->setAxisVisible(SUI::PlotAxisEnum::yRight, yAxisRight->isChecked());
        plotWidget->setAxisVisible(SUI::PlotAxisEnum::xBottom, xAxisBottom->isChecked());
        plotWidget->setAxisVisible(SUI::PlotAxisEnum::xTop, xAxisTop->isChecked());
}

void PlotCurveTest::onTestScenario1Clicked() {
    plotWidget->setAxisVisible(SUI::PlotAxisEnum::PlotAxis::yLeft, true);
    plotWidget->setAxisVisible(SUI::PlotAxisEnum::PlotAxis::xBottom, true);
    plotWidget->setAxisVisible(SUI::PlotAxisEnum::PlotAxis::yRight, true);

    plotWidget->setXScale(0, 10000);
    plotWidget->setXAutoScale(false);
    SUI::PlotCurveItem *curveLeft = new SUI::PlotCurveItem("Red", SUI::PlotAxisEnum::PlotAxis::yLeft);
    curveLeft->setColor(SUI::ColorEnum::Red);
    curveLeft->attach(plotWidget);

    SUI::PlotCurveItem *curveRight = new SUI::PlotCurveItem("Green", SUI::PlotAxisEnum::PlotAxis::yLeft);
    curveRight->setColor(SUI::ColorEnum::Green);
    curveRight->attach(plotWidget);

    mapPlotCurves.insert(std::pair<std::string, SUI::PlotCurveItem*>("Red", curveLeft));
    mapPlotCurves.insert(std::pair<std::string, SUI::PlotCurveItem*>("Green", curveRight));

    timer = SUI::Timer::createTimer();
    timer->setSingleShot(false);
    timer->setInterval(1);
    timer->timeout = boost::bind(&PlotCurveTest::onTimerTimeout, this);
    timer->start();
}

void PlotCurveTest::onTimerTimeout() {
    auto it = mapPlotCurves.find("Red");
    if(it == mapPlotCurves.end()) return;
    auto it1 = mapPlotCurves.find("Green");
    if(it1 == mapPlotCurves.end()) return;
    SUI::PlotCurveItem *curveLeft = mapPlotCurves.at("Red");
    SUI::PlotCurveItem *curveRight = mapPlotCurves.at("Green");
    static int xCoord = 0;
    int yCoord1 = rand() % 100;
    int yCoord2 = 100-yCoord1;
    curveLeft->setSample(SUI::PlotDataPoint(xCoord, yCoord1));
    curveRight->setSample(SUI::PlotDataPoint(xCoord, yCoord2));
    ++xCoord;
    plotWidget->replot();
    if(xCoord < 10000) timer->start();
}
