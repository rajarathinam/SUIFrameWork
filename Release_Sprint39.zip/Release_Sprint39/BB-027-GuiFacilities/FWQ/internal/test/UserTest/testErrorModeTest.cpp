#include "testErrorModeTest.h"

#include <SUIIErrorMode.h>
#include <SUIDialogImpl.h>
#include <SUIDropDown.h>

testErrorMode::testErrorMode(QString aDropdown, QString aWidget, SUI::DialogImpl *apGui) :
    mDropdown(aDropdown),
    mWidgetid(aWidget),
    mpGui(apGui)
{
    std::list<std::string> errorModeList = SUI::ErrorModeEnum::getErrorModeStringList();

    SUI::DropDown *dropdown = mpGui->getObjectList()->getObject<SUI::DropDown>(mDropdown.toStdString());
    dropdown->clearItems();

    dropdown->addItems(errorModeList);
}

void testErrorMode::onSelectionChanged()
{
    SUI::IErrorMode *errorWidget = mpGui->getObjectList()->getObject<SUI::IErrorMode>(mWidgetid.toStdString());
    SUI::DropDown *dropdown = mpGui->getObjectList()->getObject<SUI::DropDown>(mDropdown.toStdString());
    if (errorWidget)
    {
        std::string errorModeText = dropdown->getCurrentText();
        SUI::ErrorModeEnum::ErrorMode errorMode = SUI::ErrorModeEnum::fromString(errorModeText);
        errorWidget->setMode(errorMode);
    }
}


