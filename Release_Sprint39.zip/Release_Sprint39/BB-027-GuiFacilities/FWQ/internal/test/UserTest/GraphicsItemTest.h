#ifndef GRAPHICSITEMTEST_H
#define GRAPHICSITEMTEST_H

namespace SUI {
class GraphicsView;
class ColorCrossDrop;
class DropDown;
class Dialog;
class SpinBox;
class CheckBox;
class Button;
class LineEdit;
}
class GraphicsItemTest
{

public:
    GraphicsItemTest(SUI::Dialog *dialog);
    virtual ~GraphicsItemTest();

private:
    void onCurrentItemChanged(int index);

    void onFillItemChanged(bool checked);
    void onItemSizeChanged();
    void onItemPositionChanged();
    void onItemPenWidthChanged();
    void onItemVisibilityChanged(bool checked);
    void onSetPixmapClicked();

    void onAddItemClicked();
    void onRemoveItemClicked();

    void onGeoRequested();

    SUI::Dialog *dialog;

    SUI::GraphicsView *graphicsView;

    SUI::DropDown *itemSelector;

    SUI::ColorCrossDrop *colorSelector;

    SUI::SpinBox *penWidthSpinBox;

    SUI::CheckBox *fillItemCheckBox;

    SUI::CheckBox *visibilityCheckBox;

    SUI::SpinBox *xSpinBox;
    SUI::SpinBox *ySpinBox;
    SUI::SpinBox *widthSpinBox;
    SUI::SpinBox *heightSpinBox;

    SUI::Button *setPixmapButton;

    SUI::Button *addItemButton;
    SUI::Button *removeItemButton;

    SUI::LineEdit *xLineEdit;
    SUI::LineEdit *yLineEdit;
    SUI::LineEdit *widthLineEdit;
    SUI::LineEdit *heightLineEdit;

    SUI::LineEdit *textLineEdit;
};

#endif // GRAPHICSITEMTEST_H

