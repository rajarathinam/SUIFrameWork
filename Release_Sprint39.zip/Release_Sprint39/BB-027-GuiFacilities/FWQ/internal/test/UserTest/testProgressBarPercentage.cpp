#include "testProgressBarPercentage.h"

#include <SUIProgressBar.h>
#include <SUISpinBox.h>

void testProgressBarPercentage::handleCheckedChanged(bool checked)
{
    SUI::ProgressBar *widget = mpGui->getObjectList()->getObject<SUI::ProgressBar>(mWidgetID.toStdString());
    if (widget)
    {
        widget->disablePercentage(checked);
    }
}

testProgressBarPercentage::testProgressBarPercentage(QString aWidgetID, SUI::DialogImpl *apGui) :
    mWidgetID(aWidgetID),
    mpGui(apGui)
{
}


testStartTimedProgress::testStartTimedProgress(QString pgbID, QString timeValID, SUI::DialogImpl *apGui) :
    mPgbID(pgbID),
    mTimeValID(timeValID),
    mpGui(apGui)
{
}

void testStartTimedProgress::handleClicked()
{
    SUI::ProgressBar    *prgBar = mpGui->getObjectList()->getObject<SUI::ProgressBar>(mPgbID.toStdString());
    SUI::SpinBox         *txtWidget = mpGui->getObjectList()->getObject<SUI::SpinBox>(mTimeValID.toStdString());
    if (prgBar && txtWidget)
    {
        prgBar->startTimedProgress(txtWidget->getValue());
    }
}


testStopTimedProgress::testStopTimedProgress(QString pgbID, QString timeValID, SUI::DialogImpl *apGui) :
    mPgbID(pgbID),
    mTimeValID(timeValID),
    mpGui(apGui)
{
}

void testStopTimedProgress::handleClicked()
{
    SUI::ProgressBar    *prgBar = mpGui->getObjectList()->getObject<SUI::ProgressBar>(mPgbID.toStdString());
    SUI::SpinBox         *txtWidget = mpGui->getObjectList()->getObject<SUI::SpinBox>(mTimeValID.toStdString());
    if (prgBar && txtWidget)
    {
        prgBar->stopTimedProgress(txtWidget->getValue());
    }
}
