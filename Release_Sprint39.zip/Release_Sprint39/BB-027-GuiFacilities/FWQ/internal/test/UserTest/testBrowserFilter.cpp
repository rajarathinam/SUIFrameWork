#include "testBrowserFilter.h"

#include <SUIIText.h>
#include <SUIFileDialog.h>
#include <SUIDialogImpl.h>

testBrowserFilter::testBrowserFilter(QString aSourceWidgetID, QString aTargetWidgetID, SUI::DialogImpl *apGui):
    mTargetWidgetid(aTargetWidgetID),
    mSourceWidgetid(aSourceWidgetID),
    mpGui(apGui)
{
}

void testBrowserFilter::handleClicked()
{
    SUI::IText *widget = mpGui->getObjectList()->getObject<SUI::IText>(mSourceWidgetid.toStdString());
    if (widget)
    {
        SUI::FileDialog *fbrdialog = mpGui->getObjectList()->getObject<SUI::FileDialog>(mTargetWidgetid.toStdString());
        if (fbrdialog)
        {
            QStringList text = QString::fromStdString(widget->getText()).split(";");
            std::list<std::string> list;
            foreach (QString str, text)
            {
                list.push_back(str.toStdString());
            }

            fbrdialog->setFilter(list);
        }
    }
}
