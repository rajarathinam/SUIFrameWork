#include "testTablegetselected.h"

#include <SUITableWidget.h>
#include <SUIIText.h>
#include <SUIINumeric.h>
#include <SUIDialogImpl.h>
#include <boost/lexical_cast.hpp>

TestTableGetSelected::TestTableGetSelected(QString aTargetWidgetID, QString aSourceWidgetID,
                                           SUI::DialogImpl *apGui, TestTableGetSelected::Act aAction,
                                           QString spinBoxID):
    mTargetWidgetID(aTargetWidgetID),
    mSourceWidgetID(aSourceWidgetID),
    mpGui(apGui),
    mAction(aAction),
    mSpinBoxID(spinBoxID)
{
}

void TestTableGetSelected::handleClicked() {
    SUI::TableWidget *tableWidget = mpGui->getObjectList()->getObject<SUI::TableWidget>(mSourceWidgetID.toStdString());
    if (tableWidget)
    {
        std::list<std::string> textList = tableWidget->getSelectedItems();
        std::string text;
        SUI::IText *textWidget = NULL;
        SUI::INumeric<int> *widgetNum = NULL;
        SUI::StringList *itemWidget = NULL;

        foreach (std::string item, textList) text += item + ";";

        switch (mAction)
        {
        case TestTableGetSelected::GET:
            textWidget = mpGui->getObjectList()->getObject<SUI::IText>(mTargetWidgetID.toStdString());
            if (textWidget != NULL) textWidget->setText(text);
            break;
        case TestTableGetSelected::SELECT:
            itemWidget = mpGui->getObjectList()->getObject<SUI::StringList>(mSourceWidgetID.toStdString());
            widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<int>>(mTargetWidgetID.toStdString());
            if (itemWidget != NULL && widgetNum != NULL) itemWidget->selectItem( widgetNum->getValue());
            break;
        case TestTableGetSelected::SELECTEDROWS:
            widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<int>>(mSpinBoxID.toStdString());
            if(widgetNum != NULL) {
                std::vector<int> selectedRows = tableWidget->getSelectedRows(widgetNum->getValue());
                text.clear();
                if(selectedRows.size() > 0) {
                    for(std::vector<int>::iterator it = selectedRows.begin(); it != selectedRows.end(); ++it) {
                        text += boost::lexical_cast<std::string>(*it) + ";";
                    }
                }
            }
            textWidget = mpGui->getObjectList()->getObject<SUI::IText>(mTargetWidgetID.toStdString());
            if (textWidget != NULL) textWidget->setText(text);
        }
    }
}

void TestTableGetSelected::handleSelectionChanged() {
    SUI::TableWidget *table = mpGui->getObjectList()->getObject<SUI::TableWidget>(mSourceWidgetID.toStdString());
    if (table == NULL) return;
    QStringList itemList;
    foreach(std::string item, table->getSelectedItems()) itemList.append(QString::fromStdString(item));

    SUI::IText *textWidget = mpGui->getObjectList()->getObject<SUI::IText>(mTargetWidgetID.toStdString());
    if (textWidget != NULL) textWidget->setText(itemList.join(":").toStdString());
}
