#include "testbusyhandler.h"

#include <SUIBusyIndicator.h>

testStartBusyHandler::testStartBusyHandler(QString bicWidgetID, SUI::DialogImpl *apGui) :
    mBicWidgetID(bicWidgetID),
    mpGui(apGui)
{
}

void testStartBusyHandler::handleClicked()
{
    SUI::BusyIndicator  *bicWidget = mpGui->getObjectList()->getObject<SUI::BusyIndicator>(mBicWidgetID.toStdString());
    if (bicWidget)
    {
        bicWidget->startAnimation();
    }
}


testStopBusyHandler::testStopBusyHandler(QString bicWidgetID, SUI::DialogImpl *apGui) :
    mBicWidgetID(bicWidgetID),
    mpGui(apGui)
{

}

void testStopBusyHandler::handleClicked()
{
    SUI::BusyIndicator  *bicWidget = mpGui->getObjectList()->getObject<SUI::BusyIndicator>(mBicWidgetID.toStdString());
    if (bicWidget)
    {
        bicWidget->stopAnimation();
    }
}
