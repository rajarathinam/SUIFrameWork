#ifndef GETHELPFILE_H
#define GETHELPFILE_H

#include <QString>



namespace SUI {
class DialogImpl;
}

class getHelpFile
{
    QString mTargetWidgetid;
    QString mSourceWidgetid;
    SUI::DialogImpl  *mpGui;
public:
    getHelpFile(QString aSourceWidgetID, QString aTargetWidgetID , SUI::DialogImpl *apGui);
    void handleClicked();
};
#endif
