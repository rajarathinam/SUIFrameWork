#include "testsetprecision.h"

#include <SUIINumeric.h>
#include <SUIDoubleSpinBox.h>
#include <SUIScienceSpinBox.h>

testSetPrecision::testSetPrecision(QString aSourceWidgetID, QString aTargetWidgetID, SUI::DialogImpl *apGui) :
    mSourceWidgetid(aSourceWidgetID),
    mTargetWidgetid(aTargetWidgetID),
    mpGui(apGui)
{
}

void testSetPrecision::handleValueChanged()
{
    SUI::INumeric<int> *widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<int>>(mSourceWidgetid.toStdString());
    if (widgetNum)
    {
        int val = widgetNum->getValue();
        if (mTargetWidgetid.left(3) == "dsb")
        {
            SUI::DoubleSpinBox *dsbWidget = mpGui->getObjectList()->getObject<SUI::DoubleSpinBox>(mTargetWidgetid.toStdString());
            if (dsbWidget)
            {
                dsbWidget->setPrecision(val);
            }
        }
        else if (mTargetWidgetid.left(3) == "ssb")
        {
            SUI::ScienceSpinBox  *dsbWidget = mpGui->getObjectList()->getObject<SUI::ScienceSpinBox>(mTargetWidgetid.toStdString());
            if (dsbWidget)
            {
                dsbWidget->setPrecision(val);
            }
        }
    }
}
