#ifndef TESTEXTERNALEVENT_H
#define TESTEXTERNALEVENT_H

#include <QString>
#include <boost/thread.hpp>

namespace SUI {
class DialogImpl;
}

class testexternalevent
{
public:
    testexternalevent(QString aTargetWidgetID, SUI::DialogImpl *apGui);
    ~testexternalevent();
    void handleClicked();
    void fireEvents();


private:
    QString mTargetWidgetid;
    SUI::DialogImpl  *mpGui;
    boost::thread *m_thread;
};

#endif // TESTEXTERNALEVENT_H
