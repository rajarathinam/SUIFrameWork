#ifndef PLOTCURVEITEMTEST_H
#define PLOTCURVEITEMTEST_H
#include <vector>
#include <map>
#include <string>
#include <boost/shared_ptr.hpp>

namespace SUI {
class PlotCurveItem;
class PlotWidget;
class DropDown;
class Dialog;
class SpinBox;
class CheckBox;
class Button;
class LineEdit;
class Timer;
}

class PlotCurveTest
{
public:
    PlotCurveTest(SUI::Dialog *dialog);
    virtual ~PlotCurveTest();
private:
    void onAddCurveClicked();
    void onDeleteCurveClicked();
    void onHideCurveClicked();
    void onClearCurveClicked();
    void onAddRawSamplesClicked();
    void onAddSamplesClicked();
    void onPlotMarkerChecked(bool check);
    void onSetCurveClicked();
    void onShowCurveClicked();
    void onAddSampleClicked();
    void onAddScientificSampleClicked();
    void onPlotWidgetClicked();
    void onAxisVisibleChecked();
    void onTestScenario1Clicked();
    void onTimerTimeout();

    std::map<std::string, SUI::PlotCurveItem *> mapPlotCurves;
    SUI::Dialog *dialog;
    SUI::PlotWidget *plotWidget;

    SUI::Button *addCurve;
    SUI::Button *deleteCurve;
    SUI::Button *hideCurve;
    SUI::Button *addSamples;
    SUI::Button *addRawSamples;
    SUI::Button *clearCurve;
    SUI::Button *setCurve;

    SUI::Button *showCurve;
    SUI::Button *addSample;
    SUI::Button *addScientificSample;
    SUI::Button *testScenario1;

    SUI::CheckBox *plotMarker;

    SUI::CheckBox *yAxisLeft;
    SUI::CheckBox *yAxisRight;
    SUI::CheckBox *xAxisBottom;
    SUI::CheckBox *xAxisTop;

    SUI::LineEdit *le_curveName;
    SUI::LineEdit *le_addSamples;
    SUI::LineEdit *le_addRawSamples;

    boost::shared_ptr<SUI::Timer> timer;
    uint count;

    SUI::DropDown *dd_yaxis;
    double xRawData[100];
    double yRawData[100];
};

#endif // PLOTCURVETEST_H
