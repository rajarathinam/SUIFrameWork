#include "testTableGetAll.h"

#include <SUIIText.h>
#include <SUIINumeric.h>
#include <SUITableWidget.h>
#include <SUISpinBox.h>
#include <SUILineEdit.h>
#include <SUITabWidget.h>
#include <SUITabPage.h>
#include <SUIDialogImpl.h>

#include <sstream>
#include <algorithm>


testTableGetAll::testTableGetAll(QString aTargetWidgetID, QString aSourceWidgetID, QString aSpinWidgetID, SUI::DialogImpl *apGui) :
    mTargetWidgetID(aTargetWidgetID),
    mSourceWidgetID(aSourceWidgetID),
    mSpinWidgetID(aSpinWidgetID),
    mpGui(apGui)
{
}

void testTableGetAll::handleClicked() {
    SUI::INumeric<int> *widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<int>>(mSpinWidgetID.toStdString());
    if (widgetNum)
    {
        int                 column = widgetNum->getValue();
        SUI::TableWidget    *widgetTable = mpGui->getObjectList()->getObject<SUI::TableWidget>(mSourceWidgetID.toStdString());
        if (widgetTable)
        {
            std::list<std::string>         text = widgetTable->getColumnItems(column);
            SUI::IText         *textWidget = mpGui->getObjectList()->getObject<SUI::IText>(mTargetWidgetID.toStdString());
            if (textWidget)
            {
                std::ostringstream displayText;
                std::copy(text.begin(), text.end(), std::ostream_iterator<std::string>(displayText, ";"));
                textWidget->setText(displayText.str());
            }
        }
    }
}


testTableCount::testTableCount(QString tableID, QString lineeditID, QString row_column, SUI::DialogImpl *apGui) :
    mTableID(tableID),
    mLineEditID(lineeditID),
    mRowOrColumn(row_column),
    mpGui(apGui)
{
}

void testTableCount::handleClicked() {
    int count = 0;
    SUI::TableWidget    *table = mpGui->getObjectList()->getObject<SUI::TableWidget>(mTableID.toStdString());
    if (table)
    {
        if (mRowOrColumn.toLower() == "row")
        {
            count = table->rowCount();
        }
        else if (mRowOrColumn.toLower() == "column")
        {
            count = table->columnCount();
        }
        SUI::LineEdit   *lineedit = mpGui->getObjectList()->getObject<SUI::LineEdit>(mLineEditID.toStdString());
        if (lineedit)
        {
            lineedit->setText(QString::number(count).toStdString());
        }
    }
}


testTableCellInfo::testTableCellInfo(QString tableID, QString lineeditID, QString xIsbID, QString yIsbID, QString IdOrType, SUI::DialogImpl *apGui) :
    mTableID(tableID),
    mLineEditID(lineeditID),
    mX_IsbID(xIsbID),
    mY_IsbID(yIsbID),
    mIdOrType(IdOrType),
    mpGui(apGui)
{
}

void testTableCellInfo::handleClicked()
{
    SUI::TableWidget    *table = mpGui->getObjectList()->getObject<SUI::TableWidget>(mTableID.toStdString());
    SUI::LineEdit       *lineedit = mpGui->getObjectList()->getObject<SUI::LineEdit>(mLineEditID.toStdString());
    SUI::SpinBox        *XSpinbox = mpGui->getObjectList()->getObject<SUI::SpinBox>(mX_IsbID.toStdString());
    SUI::SpinBox        *YSpinbox = mpGui->getObjectList()->getObject<SUI::SpinBox>(mY_IsbID.toStdString());
    if (table && lineedit && XSpinbox && YSpinbox)
    {
        int     RowNr = XSpinbox->getValue();
        int     ColNr = YSpinbox->getValue();
        QString propStr;
        if (mIdOrType.toLower() == "id")
        {
            propStr = QString::fromStdString(table->getCellID(RowNr, ColNr));
        }
        else if (mIdOrType.toLower() == "type")
        {
            propStr = QString::fromStdString(SUI::ObjectType::toString(table->getCellType(RowNr, ColNr)));
        }
        lineedit->setText(propStr.toStdString());
    }
}


testTableSetItemText::testTableSetItemText(QString tableID, QString lineeditID, QString xIsbID, QString yIsbID, SUI::DialogImpl *apGui) :
    mTableID(tableID),
    mLineEditID(lineeditID),
    mX_IsbID(xIsbID),
    mY_IsbID(yIsbID),
    mpGui(apGui)
{
}

void testTableSetItemText::handleClicked() {
    SUI::TableWidget    *table = mpGui->getObjectList()->getObject<SUI::TableWidget>(mTableID.toStdString());
    SUI::LineEdit       *lineedit = mpGui->getObjectList()->getObject<SUI::LineEdit>(mLineEditID.toStdString());
    SUI::SpinBox        *XSpinbox = mpGui->getObjectList()->getObject<SUI::SpinBox>(mX_IsbID.toStdString());
    SUI::SpinBox        *YSpinbox = mpGui->getObjectList()->getObject<SUI::SpinBox>(mY_IsbID.toStdString());
    if (table && lineedit && XSpinbox && YSpinbox)
    {
        int                 RowNr = XSpinbox->getValue();
        int                 ColNr = YSpinbox->getValue();
        std::string         textStr = lineedit->getText();
        std::string         id = table->getCellID(RowNr, ColNr);
        SUI::IText         *textWidget = mpGui->getObjectList()->getObject<SUI::IText>(id);
        if (textWidget)
        {
            textWidget->setText(textStr);
        }
    }
}

testTableGetItemText::testTableGetItemText(QString tableID, QString lineeditID, QString xIsbID, QString yIsbID, SUI::DialogImpl *apGui) :
    mTableID(tableID),
    mLineEditID(lineeditID),
    mX_IsbID(xIsbID),
    mY_IsbID(yIsbID),
    mpGui(apGui)
{
}

void testTableGetItemText::handleClicked() {
    SUI::TableWidget    *table = mpGui->getObjectList()->getObject<SUI::TableWidget>(mTableID.toStdString());
    SUI::LineEdit       *lineedit = mpGui->getObjectList()->getObject<SUI::LineEdit>(mLineEditID.toStdString());
    SUI::SpinBox        *XSpinbox = mpGui->getObjectList()->getObject<SUI::SpinBox>(mX_IsbID.toStdString());
    SUI::SpinBox        *YSpinbox = mpGui->getObjectList()->getObject<SUI::SpinBox>(mY_IsbID.toStdString());
    if (table && lineedit && XSpinbox && YSpinbox)
    {
        int                 RowNr = XSpinbox->getValue();
        int                 ColNr = YSpinbox->getValue();

        QString             id = QString::fromStdString(table->getCellID(RowNr, ColNr));
        SUI::IText         *widgetText = mpGui->getObjectList()->getObject<SUI::IText>(id.toStdString());
        if (widgetText)
        {
            QString             textStr = QString::fromStdString(widgetText->getText());
            lineedit->setText(textStr.toStdString());
        }
    }
}
