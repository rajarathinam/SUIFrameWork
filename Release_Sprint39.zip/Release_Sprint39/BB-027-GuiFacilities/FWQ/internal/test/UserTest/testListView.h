#ifndef TESTLISTVIEW_H
#define TESTLISTVIEW_H

#include "SUIListViewImpl.h"
#include "SUIDialogImpl.h"

class testListView
{
public:
    enum Act { GET, ADD, REMOVE, SETFILTER, SELECT, CLEAR };
    testListView(QString aSourceWidgetID, QString aTargetWidgetID , SUI::DialogImpl *apGui, testListView::Act aAction);
    void handleClicked();
    void handleSelectionChanged();

private:
    QString mTargetWidgetid;
    QString mSourceWidgetid;
    SUI::DialogImpl  *mpGui;
    testListView::Act mAction;
};

#endif // TESTLISTVIEW_H
