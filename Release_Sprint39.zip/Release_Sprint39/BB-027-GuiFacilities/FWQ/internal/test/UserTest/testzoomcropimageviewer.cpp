#include "testzoomcropimageviewer.h"

#include <SUIIText.h>
#include <SUIGraphicsView.h>
#include <SUIDialogImpl.h>

testZoomCropImageViewer::testZoomCropImageViewer(QString X, QString Y, QString W, QString H, QString aTargetWidgetid, SUI::DialogImpl *apGui):
    mX(X),
    mY(Y),
    mW(W),
    mH(H),
    mTargetWidgetid(aTargetWidgetid),
    mpGui(apGui)
{
}

void testZoomCropImageViewer::handleClicked()
{
    SUI::GraphicsView *img = mpGui->getObjectList()->getObject<SUI::GraphicsView>(mTargetWidgetid.toStdString());
    SUI::IText *widgetTextmX = mpGui->getObjectList()->getObject<SUI::IText>(mX.toStdString());
    SUI::IText *widgetTextmY = mpGui->getObjectList()->getObject<SUI::IText>(mY.toStdString());
    SUI::IText *widgetTextmW = mpGui->getObjectList()->getObject<SUI::IText>(mW.toStdString());
    SUI::IText *widgetTextmH = mpGui->getObjectList()->getObject<SUI::IText>(mH.toStdString());
    if (img && widgetTextmX && widgetTextmY && widgetTextmW && widgetTextmH)
    {
        img->fitInView( QString::fromStdString(widgetTextmX->getText()).toInt(), QString::fromStdString(widgetTextmY->getText()).toInt(),
                       QString::fromStdString(widgetTextmW->getText()).toInt(), QString::fromStdString(widgetTextmH->getText()).toInt());
        SUI::IText *textWidget = mpGui->getObjectList()->getObject<SUI::IText>( "txaStatus" );
        if ( textWidget )
        {
            textWidget->setText( QString( QString( "Zoom factor: ") + QString::number( img->getScale(), 'g', 2 ) ).toStdString() );
        }
    }
}

