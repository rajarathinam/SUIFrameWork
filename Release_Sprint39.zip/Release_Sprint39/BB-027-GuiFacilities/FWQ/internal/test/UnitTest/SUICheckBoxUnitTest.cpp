#include"SUICheckBoxUnitTest.h"

#include <QTest>
#include"SUICheckBox.h"

#include"SUIITextUnitTest.h"
#include"SUIICheckableUnitTest.h"

SUI::CheckBoxUnitTest::CheckBoxUnitTest(SUI::CheckBox *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::CheckBoxUnitTest::~CheckBoxUnitTest() {
    delete object;
}

void SUI::CheckBoxUnitTest::callInterfaceTests() {
    //IText unit test
    ITextUnitTest iTextUnitTest(object);
    QVERIFY(iTextUnitTest.setText());
    QVERIFY(iTextUnitTest.clearText());
    QVERIFY(iTextUnitTest.setBold());

    //ICheckable unit test
    ICheckableUnitTest icheckable(object);
    QVERIFY(icheckable.setChecked());

}

