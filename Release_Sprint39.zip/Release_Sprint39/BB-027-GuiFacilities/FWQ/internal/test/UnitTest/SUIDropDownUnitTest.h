#ifndef SUIDROPDOWNUNITTEST_H
#define SUIDROPDOWNUNITTEST_H

#include "SUIWidgetUnitTest.h"

namespace SUI {

class DropDown;

class DropDownUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
     DropDownUnitTest(DropDown *object, QObject *parent = 0);
    ~DropDownUnitTest();

protected:
    void callInterfaceTests();

private slots:

private:
    DropDown *object;
};

}


#endif // SUIDROPDOWNUNITTEST_H
