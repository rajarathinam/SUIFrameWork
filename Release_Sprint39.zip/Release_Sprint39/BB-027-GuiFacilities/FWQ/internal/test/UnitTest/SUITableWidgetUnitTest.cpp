#include "SUITableWidgetUnitTest.h"

#include "SUITableWidget.h"

#include <QTest>

#include <boost/bind.hpp>

SUI::TableWidgetUnitTest::TableWidgetUnitTest(SUI::TableWidget *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::TableWidgetUnitTest::~TableWidgetUnitTest() {
    delete object;
}

void SUI::TableWidgetUnitTest::callInterfaceTests() {
    // TODO test StringList
    // TODO test IFilter
}

void SUI::TableWidgetUnitTest::addRow() {
    object->insertRows(0,1);
    int count = object->rowCount();
    object->appendRow();
    QCOMPARE(object->rowCount(),count+1);
}

void SUI::TableWidgetUnitTest::insertRow() {
    int count = object->rowCount();
    object->insertRows(0,1);
    QCOMPARE(object->rowCount(),count+1);
}

void SUI::TableWidgetUnitTest::removeRow() {
    object->appendRow();
    int count = object->rowCount();
    object->removeRow(object->rowCount() -1);
    QCOMPARE(object->rowCount(),count-1);
}

void SUI::TableWidgetUnitTest::insertColumn() {
    int count = object->columnCount();
    object->insertColumns(0,1);
    QCOMPARE(object->columnCount(),count+1);
}

void SUI::TableWidgetUnitTest::removeColumn() {
    object->insertColumns(0,1);
    int count = object->columnCount();
    object->removeColumns(0,1);
    QCOMPARE(object->columnCount(),count-1);
}

void SUI::TableWidgetUnitTest::insertRows() {
    int count = object->rowCount();
    object->insertRows(0,3);
    QCOMPARE(object->rowCount(),count+3);
}

void SUI::TableWidgetUnitTest::removeRows() {
    object->insertRows(0,3);
    int count = object->rowCount();
    object->removeRows(0,3);
    QCOMPARE(object->rowCount(),count-3);
}

void SUI::TableWidgetUnitTest::insertColumns() {
    int count = object->columnCount();
    object->insertColumns(0,3);
    QCOMPARE(object->columnCount(),count+3);
}

void SUI::TableWidgetUnitTest::removeColumns() {
    object->insertColumns(0,3);
    int count = object->columnCount();
    object->removeColumns(0,3);
    QCOMPARE(object->columnCount(),count-3);
}

void SUI::TableWidgetUnitTest::setItemText() {
    std::string text1 = "text1";
    std::string text2 = "text2";
    object->insertRows(0,1);
    object->insertColumns(0,1);
    object->setItemText(0,0,text1);
    object->setItemText(0,1,text2);
    QCOMPARE(object->getItemText(0,0),text1);
    QCOMPARE(object->getItemText(0,1),text2);
}

void SUI::TableWidgetUnitTest::rowClicked() {
    QVERIFY(object->rowClicked.empty());

    object->rowClicked = boost::bind(&SUI::TableWidgetUnitTest::onRowClicked, this, _1);
    QVERIFY(!object->rowClicked.empty());
}

void SUI::TableWidgetUnitTest::setRowVisible() {
    int count = object->rowCount();
    object->setRowVisible(count -1, true);
    QCOMPARE(object->isRowVisible(count-1), true);
    object->setRowVisible(count -1, false);
    QCOMPARE(object->isRowVisible(count-1), false);

}

void SUI::TableWidgetUnitTest::setColumnVisible() {
    int count = object->columnCount();
    object->setColumnVisible(count -1, true);
    QCOMPARE(object->isColumnVisible(count-1), true);
    object->setColumnVisible(count -1, false);
    QCOMPARE(object->isColumnVisible(count-1), false);
}

void SUI::TableWidgetUnitTest::getWidgetItem() {
    for(int row =0; row < object->rowCount(); row ++){
        for(int col = 0; col < object->columnCount(); col++){
            Widget *widget = object->getWidgetItem(row,col);
            QCOMPARE(widget->getId(), object->getCellID(row,col));
            //WidgetUnitTest(widget, NULL);
        }
    }
}

void SUI::TableWidgetUnitTest::onRowClicked(int row) {
    mRow = row;
}
