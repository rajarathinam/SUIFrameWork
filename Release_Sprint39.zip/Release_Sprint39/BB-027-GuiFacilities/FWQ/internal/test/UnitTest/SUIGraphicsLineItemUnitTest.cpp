#include "SUIGraphicsLineItemUnitTest.h"

#include <QTest>

#include <boost/bind.hpp>

#include <SUIGraphicsLineItem.h>

SUI::GraphicsLineItemUnitTest::GraphicsLineItemUnitTest(SUI::GraphicsLineItem *object, QObject *parent) :
    GraphicsItemUnitTest(object,parent),
    object(object)
{
}

SUI::GraphicsLineItemUnitTest::~GraphicsLineItemUnitTest()
{
}

void SUI::GraphicsLineItemUnitTest::setColorRed() {
    object->setPenColor(SUI::ColorEnum::Red);
    QCOMPARE(object->getPenColor(),SUI::ColorEnum::Red);
}

void SUI::GraphicsLineItemUnitTest::setPenColorRed() {
    object->setPenColor(SUI::ColorEnum::Red);
    QCOMPARE(object->getPenColor(),SUI::ColorEnum::Red);
}

void SUI::GraphicsLineItemUnitTest::setPenWidth() {
    object->setPenWidth(10);
    QCOMPARE(object->getPenWidth(),10);
}

void SUI::GraphicsLineItemUnitTest::setP1() {
    object->setP1(10,10);
//    QCOMPARE(object->getP1(),10); //FIXME add 'SUI::Point getP1() const' to SUI::GraphicsLine
    QVERIFY(false);
}

void SUI::GraphicsLineItemUnitTest::setP2() {
    object->setP2(10,10);
//    QCOMPARE(object->getP2(),10); //FIXME add 'SUI::Point getP2() const' to SUI::GraphicsLine
    QVERIFY(false);
}

void SUI::GraphicsLineItemUnitTest::setSize() {

}

void SUI::GraphicsLineItemUnitTest::penColorChanged() {
    object->setPenColor(SUI::ColorEnum::Black);
    object->penColorChanged = boost::bind(&GraphicsLineItemUnitTest::onPenColorChanged,this);
    object->setPenColor(SUI::ColorEnum::Blue);
}

void SUI::GraphicsLineItemUnitTest::onPenColorChanged() {
    QVERIFY(true);
}
