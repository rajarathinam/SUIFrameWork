#include "SUIPlotWidgetUnitTest.h"
#include "SUIPlotWidget.h"
#include "SUIPlotHistogramItem.h"
#include "SUIPlotCurveItem.h"
#include <QTest>
#include "SUIITextUnitTest.h"
#include "SUIClickableUnitTest.h"
#include "SUIIBGColorableUnitTest.h"
#include <array>

SUI::PlotWidgetUnitTest::PlotWidgetUnitTest(SUI::PlotWidget *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    plotwidget(object)
{

}

SUI::PlotWidgetUnitTest::~PlotWidgetUnitTest() {
    delete plotwidget;
}

void SUI::PlotWidgetUnitTest::callInterfaceTests() {
    // IText UnitTests
    ITextUnitTest iTextUnitTest(plotwidget);
    QVERIFY(iTextUnitTest.setText());
    QVERIFY(iTextUnitTest.clearText());
    QVERIFY(iTextUnitTest.setBold());

    //IClickable tests
    IClickableUnitTest iClickable(plotwidget);
    iClickable.clickable();

    //IBGColorable tests
    IBGColorableUnitTest iBGColorableUnitTest(plotwidget);
    //valid colors
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Transparent));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Standard));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::White));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Red));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Green));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Blue));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Gray));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Yellow));
}

void SUI::PlotWidgetUnitTest::axisTests() {
    // Enable & disable yLeft axis
    plotwidget->setAxisVisible(SUI::PlotAxisEnum::PlotAxis::yLeft, true);
    QVERIFY(plotwidget->getAxisVisible(SUI::PlotAxisEnum::PlotAxis::yLeft));
    plotwidget->setAxisVisible(SUI::PlotAxisEnum::PlotAxis::yLeft, false);
    QVERIFY(!plotwidget->getAxisVisible(SUI::PlotAxisEnum::PlotAxis::yLeft));

    // Enable & disable yRight axis
    plotwidget->setAxisVisible(SUI::PlotAxisEnum::PlotAxis::yRight, true);
    QVERIFY(plotwidget->getAxisVisible(SUI::PlotAxisEnum::PlotAxis::yRight));
    plotwidget->setAxisVisible(SUI::PlotAxisEnum::PlotAxis::yRight, false);
    QVERIFY(!plotwidget->getAxisVisible(SUI::PlotAxisEnum::PlotAxis::yRight));

    // Enable & disable xBottom axis
    plotwidget->setAxisVisible(SUI::PlotAxisEnum::PlotAxis::xBottom, true);
    QVERIFY(plotwidget->getAxisVisible(SUI::PlotAxisEnum::PlotAxis::xBottom));
    plotwidget->setAxisVisible(SUI::PlotAxisEnum::PlotAxis::xBottom, false);
    QVERIFY(!plotwidget->getAxisVisible(SUI::PlotAxisEnum::PlotAxis::xBottom));

    // Enable & disable xTop axis
    plotwidget->setAxisVisible(SUI::PlotAxisEnum::PlotAxis::xTop, true);
    QVERIFY(plotwidget->getAxisVisible(SUI::PlotAxisEnum::PlotAxis::xTop));
    plotwidget->setAxisVisible(SUI::PlotAxisEnum::PlotAxis::xTop, false);
    QVERIFY(!plotwidget->getAxisVisible(SUI::PlotAxisEnum::PlotAxis::xTop));

    // Axis label angles
    std::array<double, 11> angles {{ 0.0, 60.0, 120.0, 180.0, 240.0, 300.0, -60.0, -120.0, -180.0, -240.0, -300.0}};
    for(uint angleId = 0; angleId < angles.size(); angleId++) {
        for (int enumInt = SUI::PlotAxisEnum::xBottom; enumInt <= SUI::PlotAxisEnum::yRight; enumInt++) {
            plotwidget->setLabelRotation((SUI::PlotAxisEnum::PlotAxis)enumInt, angles[angleId]);
            QCOMPARE(plotwidget->getLabelRotation(static_cast<SUI::PlotAxisEnum::PlotAxis>(enumInt)), angles[angleId]);
        }
    }

    // Set Axis scales and stepsizes
    plotwidget->setAxisVisible(SUI::PlotAxisEnum::xBottom, true);
    plotwidget->setAxisVisible(SUI::PlotAxisEnum::yLeft, true);
    plotwidget->setAxisVisible(SUI::PlotAxisEnum::yRight, true);
    plotwidget->setAxisVisible(SUI::PlotAxisEnum::xTop, true);
    plotwidget->setXScale(100.0, 10000.0, 800.0);
    plotwidget->setAxisScale(SUI::PlotAxisEnum::xTop, -300.0, 3000.0, 50.0);
    plotwidget->setYLeftScale(-2000.0, +2000.0, 2.0);
    plotwidget->setYRightScale(-100.0, 100.0, 0.1);

    // Check X-Axis bottom scale and stepsize
    QCOMPARE(plotwidget->getAxisMinValue(SUI::PlotAxisEnum::xBottom), 100.0);
    QCOMPARE(plotwidget->getAxisMaxValue(SUI::PlotAxisEnum::xBottom), 10000.0);
    QCOMPARE(plotwidget->getAxisStepSize(SUI::PlotAxisEnum::xBottom), 800.0);

    // Check X-Axis bottom scale and stepsize
    QCOMPARE(plotwidget->getAxisMinValue(SUI::PlotAxisEnum::xTop), -300.0);
    QCOMPARE(plotwidget->getAxisMaxValue(SUI::PlotAxisEnum::xTop), 3000.0);
    QCOMPARE(plotwidget->getAxisStepSize(SUI::PlotAxisEnum::xTop), 50.0);

    // Check Y-Axis left scale and stepsize
    QCOMPARE(plotwidget->getAxisMinValue(SUI::PlotAxisEnum::yLeft), -2000.0);
    QCOMPARE(plotwidget->getAxisMaxValue(SUI::PlotAxisEnum::yLeft), 2000.0);
    QCOMPARE(plotwidget->getAxisStepSize(SUI::PlotAxisEnum::yLeft), 2.0);

    // Check Y-Axis right scale and stepsize
    QCOMPARE(plotwidget->getAxisMinValue(SUI::PlotAxisEnum::yRight), -100.0);
    QCOMPARE(plotwidget->getAxisMaxValue(SUI::PlotAxisEnum::yRight), 100.0);
    QCOMPARE(plotwidget->getAxisStepSize(SUI::PlotAxisEnum::yRight), 0.1);
}

void SUI::PlotWidgetUnitTest::gridTests() {
    // Y-Axis Off, Normal, Detail
    plotwidget->setYGrid(GridStyleEnum::Off);
    QCOMPARE(plotwidget->getYGrid(), GridStyleEnum::Off);
    plotwidget->setYGrid(GridStyleEnum::Normal);
    QCOMPARE(plotwidget->getYGrid(), GridStyleEnum::Normal);
    plotwidget->setYGrid(GridStyleEnum::Detail);
    QCOMPARE(plotwidget->getYGrid(), GridStyleEnum::Detail);

    // X-Axis  Off, Normal, Detail
    plotwidget->setXGrid(GridStyleEnum::Off);
    QCOMPARE(plotwidget->getXGrid(), GridStyleEnum::Off);
    plotwidget->setXGrid(GridStyleEnum::Normal);
    QCOMPARE(plotwidget->getXGrid(), GridStyleEnum::Normal);
    plotwidget->setXGrid(GridStyleEnum::Detail);
    QCOMPARE(plotwidget->getXGrid(), GridStyleEnum::Detail);

    //grid color
    plotwidget->setGridColor(SUI::ColorEnum::Blue);
    QCOMPARE(plotwidget->getGridColor(), SUI::ColorEnum::Blue);
    plotwidget->setGridColor(SUI::ColorEnum::Red);
    QCOMPARE(plotwidget->getGridColor(), SUI::ColorEnum::Red);

    //grid major penstyle
    plotwidget->setGridMajorStyle(SUI::LineStyleEnum::Dash);
    QCOMPARE(plotwidget->getGridMajorStyle(), SUI::LineStyleEnum::Dash);
    plotwidget->setGridMajorStyle(SUI::LineStyleEnum::Dot);
    QCOMPARE(plotwidget->getGridMajorStyle(), SUI::LineStyleEnum::Dot);
    //grid Minor penstyle
    plotwidget->setGridMinorStyle(SUI::LineStyleEnum::Dash);
    QCOMPARE(plotwidget->getGridMinorStyle(), SUI::LineStyleEnum::Dash);
    plotwidget->setGridMinorStyle(SUI::LineStyleEnum::Dot);
    QCOMPARE(plotwidget->getGridMinorStyle(), SUI::LineStyleEnum::Dot);
}

void SUI::PlotWidgetUnitTest::customColors() {
    SUI::PlotHistogramItem *histogram = new SUI::PlotHistogramItem("Histogram");
    histogram->attach(plotwidget);
    SUI::PlotCurveItem *curve = new SUI::PlotCurveItem("Curve", SUI::PlotAxisEnum::yLeft);
    curve->attach(plotwidget);

    SUI::PlotItemCustomColor penColor(124,126,128,10);
    SUI::PlotItemCustomColor brushColor(224,226,228,110);
    histogram->setCustomBrushColor(brushColor);
    histogram->setCustomPenColor(penColor);
    QCOMPARE(histogram->getCustomBrushColor(), brushColor);
    QCOMPARE(histogram->getCustomPenColor(), penColor);
    penColor.setRed(0);
    penColor.setGreen(125);
    penColor.setBlue(255);
    penColor.setAlpha(0);
    curve->setCustomPenColor(penColor);
    QCOMPARE(curve->getCustomPenColor(), penColor);
}

void SUI::PlotWidgetUnitTest::mouseCursor() {
   plotwidget->setMouseCursor(SUI::CursorShapeEnum::CrossCursor);
   QCOMPARE(plotwidget->getMouseCursor(), SUI::CursorShapeEnum::CrossCursor);
   plotwidget->setMouseCursor(SUI::CursorShapeEnum::ArrowCursor);
   QCOMPARE(plotwidget->getMouseCursor(), SUI::CursorShapeEnum::ArrowCursor);
   plotwidget->setMouseCursor(SUI::CursorShapeEnum::BusyCursor);
   QCOMPARE(plotwidget->getMouseCursor(), SUI::CursorShapeEnum::BusyCursor);
}
