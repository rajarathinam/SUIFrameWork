#ifndef ICOLORABLEUNITTEST_H
#define ICOLORABLEUNITTEST_H

#include <SUIColorEnum.h>

namespace SUI {

class IColorable;

class IColorableUnitTest
{
public:
    IColorableUnitTest(IColorable *object);

    bool setColor(SUI::ColorEnum::Color color);

private:
    IColorable *object;
};
}
#endif // ICOLORABLEUNITTEST_H
