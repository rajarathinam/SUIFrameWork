#ifndef SUIBUTTONBARUNITTEST_H
#define SUIBUTTONBARUNITTEST_H

#include "SUIWidgetUnitTest.h"
#include "SUIButtonBar.h"

namespace SUI {

class ButtonBar;

class ButtonBarUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
     ButtonBarUnitTest(ButtonBar *object, QObject *parent = 0);
    ~ButtonBarUnitTest();

private:
     ButtonBar *object;
};

}


#endif // SUIBUTTONBARUNITTEST_H
