#include"SUICheckGroupBoxUnitTest.h"

#include"SUICheckGroupBox.h"
#include <QTest>

#include "SUIITextUnitTest.h"
#include "SUIIBGColorableUnitTest.h"
#include "SUIICheckableUnitTest.h"

SUI::CheckGroupBoxUnitTest::CheckGroupBoxUnitTest(SUI::CheckGroupBox *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::CheckGroupBoxUnitTest::~CheckGroupBoxUnitTest() {
    delete object;
}

void SUI::CheckGroupBoxUnitTest::callInterfaceTests() {
    //IText unit test
    ITextUnitTest iTextUnitTest(object);
    QVERIFY(iTextUnitTest.setText());
    QVERIFY(iTextUnitTest.clearText());
    QVERIFY(iTextUnitTest.setBold());

    //IBGColorable tests
    IBGColorableUnitTest iBGColorableUnitTest(object);
    //valid colors
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Transparent));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Standard));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::White));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Red));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Green));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Blue));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Gray));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Yellow));

    //ICheckable unit test
    ICheckableUnitTest icheckable(object);
    QVERIFY(icheckable.setChecked());
}


