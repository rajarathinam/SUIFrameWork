#include "SUITabWidgetUnitTest.h"

SUI::TabWidgetUnitTest::TabWidgetUnitTest(SUI::TabWidget *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::TabWidgetUnitTest::~TabWidgetUnitTest() {
    delete object;
}
