#include "ICheckableUnitTest.h"

#include <SUIICheckable.h>
#include <SUIBaseWidget.h>

#include <SUIObjectFactory.h>

ICheckableUnitTest::ICheckableUnitTest()
{
}

void ICheckableUnitTest::cleanupTestCase()
{
}

void ICheckableUnitTest::testCheckboxCase()
{
    SUI::BaseWidget* widget = SUI::ObjectFactory::getInstance()->createWidget(SUI::ObjectType::CheckBox);

    SUI::ICheckable* checkedWidget = dynamic_cast<SUI::ICheckable *>(widget);

    checkedWidget->setChecked(true);
    QCOMPARE(checkedWidget->isChecked(), true);

    checkedWidget->setChecked(false);
    QCOMPARE(checkedWidget->isChecked(), false);
}

void ICheckableUnitTest::testCheckGroupBoxCase()
{
    SUI::BaseWidget* widget = SUI::ObjectFactory::getInstance()->createWidget(SUI::ObjectType::CheckGroupBox);

    SUI::ICheckable* checkedWidget = dynamic_cast<SUI::ICheckable *>(widget);

    checkedWidget->setChecked(true);
    QCOMPARE(checkedWidget->isChecked(), true);

    checkedWidget->setChecked(false);
    QCOMPARE(checkedWidget->isChecked(), false);
}

void ICheckableUnitTest::testRadioButtonCase()
{
    SUI::BaseWidget* widget = SUI::ObjectFactory::getInstance()->createWidget(SUI::ObjectType::RadioButton);

    SUI::ICheckable* checkedWidget = dynamic_cast<SUI::ICheckable *>(widget);

    checkedWidget->setChecked(true);
    QCOMPARE(checkedWidget->isChecked(), true);

    checkedWidget->setChecked(false);
    QCOMPARE(checkedWidget->isChecked(), false);
}
