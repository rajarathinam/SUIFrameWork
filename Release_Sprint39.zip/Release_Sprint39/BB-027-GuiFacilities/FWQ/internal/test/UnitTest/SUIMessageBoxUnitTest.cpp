#include "SUIMessageBoxUnitTest.h"
#include "SUIMessageBox.h"
#include <QTest>
#include "SUIITextUnitTest.h"

SUI::MessageBoxUnitTest::MessageBoxUnitTest(SUI::MessageBox *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::MessageBoxUnitTest::~MessageBoxUnitTest() {
    delete object;
}

void SUI::MessageBoxUnitTest::callInterfaceTests() {
    // IText UnitTests
    ITextUnitTest iTextUnitTest(object);
    QVERIFY(iTextUnitTest.setText());
    QVERIFY(iTextUnitTest.clearText());
    QVERIFY(iTextUnitTest.setBold());

    //TO DO IClickable tests

}
