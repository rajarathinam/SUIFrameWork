#ifndef SUIMESSAGEBOXUNITTEST_H
#define SUIMESSAGEBOXUNITTEST_H

#include "SUIWidgetUnitTest.h"


namespace SUI {

class MessageBox;

class MessageBoxUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
     MessageBoxUnitTest(MessageBox *object, QObject *parent = 0);
    ~MessageBoxUnitTest();

protected:
    void callInterfaceTests();

private slots:

private:
    MessageBox *object;
};

}

#endif // SUIMESSAGEBOXUNITTEST_H
