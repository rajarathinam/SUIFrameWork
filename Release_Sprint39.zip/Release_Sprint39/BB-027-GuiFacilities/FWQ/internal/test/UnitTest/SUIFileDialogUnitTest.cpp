#include "SUIFileDialogUnitTest.h"

SUI::FileDialogUnitTest::FileDialogUnitTest(SUI::FileDialog *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::FileDialogUnitTest::~FileDialogUnitTest() {
    delete object;
}

