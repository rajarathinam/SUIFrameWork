#ifndef SUITABPAGEUNITTEST_H
#define SUITABPAGEUNITTEST_H

#include "SUIWidgetUnitTest.h"
#include "SUITabPage.h"

namespace SUI {

class TabPage;

class TabPageUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    TabPageUnitTest(SUI::TabPage *object, QObject *parent = 0);
    virtual ~TabPageUnitTest();

private:
    TabPage *object;
};

}

#endif // SUITABPAGEUNITTEST_H
