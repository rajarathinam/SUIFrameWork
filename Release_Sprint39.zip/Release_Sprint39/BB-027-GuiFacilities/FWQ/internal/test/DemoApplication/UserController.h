#ifndef USERCONTROLLER_H
#define USERCONTROLLER_H

#include <boost/shared_ptr.hpp>

class UserClass;

namespace SUI {
class Timer;
class Time;
}
class UserController
{
public:
    UserController(UserClass *userClass);
    ~UserController();

private:
    // private callback functions
    void onStartButtonClicked();
    void onStopButtonClicked();
    void onProgressBarValueChanged();
    void onTimerTimeout();
    void onTimeTimerTimeout();

    // pointer to the UserClass
    UserClass *userClass;

    // shared pointer to the timer and time instances
    boost::shared_ptr<SUI::Timer> timer;

    boost::shared_ptr<SUI::Timer> timeTimer;
    boost::shared_ptr<SUI::Time> time;
};

#endif // USERCONTROLLER_H
