#include "UserClass.h"
#include "moc_UserClass.h"

UserClass::UserClass() :
    sui(new SUI::UserClass)
{
    sui->setupSUI("UserClass.xml");
}
UserClass::~UserClass()
{
    delete sui;
}

SUI::Button *UserClass::getStartButton() {
    return sui->startButton;
}

SUI::Button *UserClass::getStopButton() {
    return sui->stopButton;
}

SUI::Label *UserClass::getTimeLabel() {
    return sui->timeLabel;
}

SUI::ProgressBar *UserClass::getProgressBar() {
    return sui->progressBar;
}

SUI::Dialog *UserClass::getDialog() {
    return sui->dialog;
}
