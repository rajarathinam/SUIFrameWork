//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::GraphicsSvgItem.
// !\description Header file for class SUI::GraphicsSvgItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIGRAPHICSSVGITEM_H
#define SUIGRAPHICSSVGITEM_H

#include "SUIGraphicsItem.h"
#include "SUIIImage.h"
#include "SUIColorEnum.h"

namespace SUI {
/*!
 * \ingroup FWQxGraphicsItems
 *
 * \brief The GraphicsSvg class
 */
class SUI_SHARED_EXPORT GraphicsSvgItem : public GraphicsItem, public IImage
{
public:
    virtual ~GraphicsSvgItem();
	
    /*!
     * \brief setImage
     * Loads the SVG file specified by filename
     * \param image
     */
    virtual void setImage(const std::string &image);

    /*!
     * \brief setImage
     * DEPRECATED. DO NOT USE
     * \param data
     * \param width
     * \param height
     * \param format
     */
    virtual void setImage(unsigned char *data, int width, int height, ImageEnum::Format format);

    /*!
     * \brief setElementId
     * Sets the element ID of the SVG item
     * \param id
     */
    void setElementId(const std::string &id);

    /*!
     * \brief elementId
     * Returns the element ID of the SVG item
     * \return
     */
    std::string elementId();

    /*!
     * \brief scale
     * Sets the scale of the svg item to the given width and height
     * \param width
     * \param height
     */
    void scale(int width, int height);

    /*!
     * \brief getElementIdList
     * Returns a string list of all "id" attribute values
     */
    std::list<std::string> getElementIdList(void);

    /*!
     * \brief setElementColor
     * Sets the color of an element (identified by idvalue)
     * \param idvalue
     * \param color
     */
    void setElementColor(const std::string idvalue, const SUI::ColorEnum::Color color);

    /*!
     * \brief setElementBorderColor
     * Sets the border color of an element (identified by idvalue)
     * \param idvalue
     * \param borderColor
     */
    void setElementBorderColor(const std::string idvalue, const SUI::ColorEnum::Color borderColor);

    /*!
     * \brief setElementText
     * Sets the text of an element (identified by idvalue)
     * \param idvalue
     * \param text
     */
    void setElementText(const std::string idvalue, const std::string text);

    /*!
     * \brief getElementText
     * Gets the text of an element (identified by idvalue)
     * \param idvalue
     * \return
     */
    std::string getElementText(const std::string idvalue);

    /*!
     * \brief elideText
     * Elide(...) text to a maximum width for all text elements in the SVG image
     * \param maxwidth
     */
    void elideText(int maxwidth);

    /*!
     * \brief resetElideText
     * Removes the previous elide setting, if any
     */
    void resetElideText(void);

    /*!
     * \brief setElementBorderWidth
     * Sets the border width of an element, corresponding to id attribute value
     * \param idvalue
     * \param borderWidth
     */
    void setElementBorderWidth(const std::string idvalue, const int borderWidth);

    /*!
     * \brief setElementTextColor
     * Sets the textcolor of an element, corresponding to id attribute value
     * \param idvalue
     * \param color
     */
    void setElementTextColor(const std::string idvalue, const SUI::ColorEnum::Color color );

    /*!
     * \brief setElementToolTip
     * Sets the tooltip of an element, corresponding to id attribute value
     * \param idvalue
     * \param tipText
     */
    void setElementToolTip(const std::string idvalue, const std::string tipText);

    /*!
     * \brief setElementToDoublClickEvent
     * Registers for a double click event on an element with given id value
     * \param idvalue
     * \param func - CALLBACK handler
     */
    typedef boost::function<void(const std::string &)> function_type;
    void setElementToDoublClickEvent(const std::string idvalue, function_type func);

private:

    void onSubscribeDoubleClick();
    friend class ObjectFactory;
    explicit GraphicsSvgItem(SUI::GraphicsItem *parent = NULL);
    GraphicsSvgItem(const GraphicsSvgItem &copy);
    GraphicsSvgItem &operator=(const GraphicsSvgItem &copy);
};
}

#endif // SUIGRAPHICSSVGITEM_H
