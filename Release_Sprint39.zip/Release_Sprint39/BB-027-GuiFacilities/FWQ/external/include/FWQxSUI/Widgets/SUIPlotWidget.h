//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::PlotWidget.
// !\description Header file for class SUI::PlotWidget.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUIPLOTWIDGET_H
#define SUIPLOTWIDGET_H

#include "SUICurveColorEnum.h"
#include "SUIPlotAxisEnum.h"
#include "SUILineStyleEnum.h"
#include "SUIScaleTypeEnum.h"
#include "SUIGridStyleEnum.h"
#include "SUIMarkerSymbolEnum.h"
#include "SUIMouseButtonEnum.h"

#include "SUIWidget.h"
#include "SUIIText.h"
#include "SUIIClickable.h"
#include "SUIIBGColorable.h"

#include <list>

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 *
 * \brief Specific Interface for the plot widget Widget
 */
class SUI_SHARED_EXPORT PlotWidget : public Widget, public IText, public IClickable, public IBGColorable
{
public:
    virtual ~PlotWidget();

    /*!
     * \brief setLegend
     * Enables (on == true) or disables the plot's legend
     * \param on
     */
    virtual void setLegend(bool on) = 0;

    /*!
     * \brief setRectangle
     * This function adds a new rectangle to the PlotWidget.
     * If it doesn't already exist and set is true.\n
     * If set is true and the rectangle does not exist yet, it makes a new rectangle at the given position, with the given color and
     * the given label. If set is false and the rectangle exists, it will hide that rectangle.
     * If the rectangle does not exist and set is false, nothing happens.
     * If the rectangle exists and set is true, it is being redrawn with the
     * appropriate parameters, so one can change the start, end, color and label
     * of an existing rectangle.
     * \param id - The ID for the Rectangle
     * \param xstart - The X coordinate where the rectangle should begin.
     * \param xend - The X coordinate where the rectangle should end.
     * \param color - The color of the rectangle.
     * \param set - Defines whether the rectangle must be turned on or off.
     * \param label - The name / label of the rectangle.
     * \param axis    -   Which axis to use
     * \param orientation - Valid values are 'Vertical' (= default) or 'Horizontal'.
     * \param yside - Valid values are 'Left' (= default) or 'Right'. Is not used when orientation is 'Vertical'
     */
    virtual void setRectangle(int id, double xstart, double xend, CurveColorEnum::CurveColor color, bool set, const std::string &label, const PlotAxisEnum::PlotAxis axis) = 0;

    /*!
     * \brief setROI
     * This function sets or hides a Region Of Interest in the PlotWidget
     * \param    id  	    -   The ID of the ROI
     * \param    set         -   Turns the region on or off
     * \param    label 		-   The name / label of the rectangle.
     * \param    color       -   The color of the ROI
     * \param    xstart      -   The start point x value, related to the bottom x scale
     * \param    ystart      -   The start point y value, related to the left y scale
     * \param    xend        -   The end point x value, related to the bottom x scale
     * \param    yend        -   The end point y value, related to the left y scale
     * \param    axis        -   Indicates which Y axis to relate to.
     * \remark   If setting the ROI off, the geometry, the color and the axis of the ROI is of no interest. Hence
     *           the default values, so you don't have to supply them.
     */
    virtual void setROI(int id, bool set, const std::string &label, int xstart = INT_MAX, int xend = INT_MAX, int ystart = INT_MAX, int yend = INT_MAX,
                            CurveColorEnum::CurveColor color = CurveColorEnum::Black, const PlotAxisEnum::PlotAxis axis = PlotAxisEnum::yLeft) = 0;

    /*!
     * \brief setAutoReplot
     * This function indicates whether autoreplot should occur or not
     * \param autoreplot - Defines autoplot is to be enabled or not.
     */
    virtual void setAutoReplot(bool autoreplot) = 0;

    /*!
     * \brief getAutoReplot
     * This function returns whether autoReplot is set or not.
     */
    virtual bool getAutoReplot() const = 0;

    /*!
     * \brief replot
     * This function redraws the plot. If the autoReplot option is not set
     * (which is the default) or if any curves are attached to raw data, the plot has to be
     * refreshed explicitly in order to make changes visible.
     */
    virtual void replot() const = 0;

    /*!
     * \brief setScaleType
     * sets the type of scale used at a side of the plotwidget
     * \param side - The side of the plotwidget. side can only be
     * - EnumYSide::Y_LEFT - The left side of the plot widget
     * - EnumYSide::Y_RIGHT - The right side of the plot widget
     * If something else is given the value EnumYSide::Y_RIGHT will be applied.
     * \param type - The type of scale used. type can only be:
     * - EnumScaleType::LINEAR_SCALE - a linear Scale
     * - EnumScaleType::LOG_SCALE - a logarimic Scale
     */
    virtual void setScaleType(PlotAxisEnum::PlotAxis side, ScaleTypeEnum::ScaleType type) = 0;

    /*!
     * \brief setXAutoScale
     * Sets X-axis auto scale to on (set == true) or off (set == false).
     * \param set
     */
    virtual void setXAutoScale(bool set) = 0;

    /*!
     * \brief setXGrid
     * Enables or disables the X Grid for the Max lines and the Min lines.
     * \param style - Valid values: Off = No Grid, Normal = Main grid lines, Detail = Main and sub grid lines.
     */
    virtual void setXGrid(GridStyleEnum::GridStyle style) = 0;

    /*!
     * \brief getXGrid
     * Returns the current vertical grid style.
     */
    virtual GridStyleEnum::GridStyle getXGrid() = 0;

    /*!
     * \brief setYGrid
     * Enables or disables the Y Grid for the Max lines and the Min lines.
     * \param style - Valid values: EnumGridStyle::GRID_OFF = No Grid, EnumGridStyle::GRID_NORMAL = Main grid lines,
     * EnumGridStyle::GRID_Detail = Main and sub grid lines.
     */
    virtual void setYGrid(GridStyleEnum::GridStyle style) = 0;

    /*!
     * \brief getYGrid
     * Returns the current horizontal grid style.
     */
    virtual GridStyleEnum::GridStyle getYGrid() = 0;

    /*!
     * \brief setXLabel
     * sets the label of the X Axis
     * \param label - The label for the X Axis
     */
    virtual void setXLabel(const std::string &label) = 0;

    /*!
     * \brief setYLeftLabel
     * Sets the label of the left Y Axis
     * \param label - The label for the left Y Axis
     */
    virtual void setYLeftLabel(const std::string &label) = 0;

    /*!
     * \brief setYRightLabel
     * Sets the label of the right Y Axis
     * \param label - The label for the right Y Axis
     */
    virtual void setYRightLabel(const std::string &label) = 0;

    /*!
     * \brief setXScale
     * REMARK: use setAxisScale() instead of this method
     * Sets the X Scale from xMin to xMax. This overrides the methods setAxisMaxMajor() and setAxisMaxMinor().
     * If xMin is between -0.01 and 0.01 and xMax is between -0.01 and 0.01, the X Scale is set to AutoScale. If
     * AutoScale is true, xMin, xMax and stepsize are overruled.
     * \param xMin - The minimum X value for the X Scale
     * \param xMax - The maximum X value for the X Scale
     * \param stepSize - Defines the stepsize between two major tickmarks
     */
    virtual void setXScale(double xMin, double xMax, double stepsize = 0) = 0;

    /*!
     * \brief setYLeftScale
     * REMARK: use setAxisScale() instead of this method
     * Sets the Left Y Scale from yMin to yMax. This overrides the methods setAxisMaxMajor() and setAxisMaxMinor().
     * If yMin is between -0.01 and 0.01 and yMax is between -0.01 and 0.01, the Y Scale is set to AutoScale
     * Because the Text label y position of the rectangle's is calculated from the Canvas,
     * these positions have to be recalculated, when the Y Scale changes
     * \param yMin - The minimum Y value for the Left Y Scale
     * \param yMax - The maximum Y value for the Left Y Scale
     * \param stepsize - Defines the stepsize between two major tickmarks
     */
    virtual void setYLeftScale(double yMin, double yMax, double stepsize = 0) = 0;

    /*!
     * \brief setYRightScale
     * REMARK: use setAxisScale() instead of this method
     * Sets the Right Y Scale from yMin to yMax. This overrides the methods setAxisMaxMajor() and setAxisMaxMinor().
     * When yMin is between -0.01 and 0.01 and yMax is between -0.01 and 0.01, the Y Scale is set to AutoScale
     * \param yMin - The minimum Y value for the Right Y Scale
     * \param yMax - The maximum Y value for the Right Y Scale
     * \param stepsize - Defines the stepsize between two major tickmarks
     */
    virtual void setYRightScale(double yMin, double yMax, double stepsize = 0) = 0;

    /*!
     * \brief setAxisScale
     * Sets the scale and stepsize for the given axis. Setting the stepsize by using this method,
     * setAxisMaxMajor() and setAxisMaxMinor() are overriden.
     * When min is between -0.01 and 0.01 and max is between -0.01 and 0.01, the scale is set to AutoScale
     * \param axis - Axis for which the values are changed
     * \param min - The axis min value
     * \param max - The axis max value
     * \param stepsize - The axis stepsize
     */
    virtual void setAxisScale(SUI::PlotAxisEnum::PlotAxis axis, double min, double max, double stepsize = 0) = 0;

    /*!
     * \brief getAxisMaxValue
     * Returns the axis maximum value
     * \param axis - Axis from which the maximum value is requested
     * \return
     */
    virtual double getAxisMaxValue(SUI::PlotAxisEnum::PlotAxis axis) const = 0;

    /*!
     * \brief getAxisMinValue
     * Returns the axis minimum value
     * \param axis - Axis from which the minimum value is requested
     * \return
     */
    virtual double getAxisMinValue(SUI::PlotAxisEnum::PlotAxis axis) const = 0;

    /*!
     * \brief getAxisStepSize
     * Returns the axis stepsize
     * \param axis - Axis from which the stepsize is requested
     * \return
     */
    virtual double getAxisStepSize(SUI::PlotAxisEnum::PlotAxis axis) const = 0;

    /*!
     * \brief setTitle
     * Sets the title of the plot
     * \param title - The text to set
     */
    virtual void setTitle(const std::string &title) = 0;

    /*!
     * \brief setAxisVisible
     * Makes the specified axis visible (visible = true) or hides it (visible = false)
     * \param axis
     * \param visible
     */
    virtual void setAxisVisible(SUI::PlotAxisEnum::PlotAxis axis, bool visible) = 0;

    /*!
     * \brief getAxisVisible
     * Returns whether thee specified axis is visible (true) or not (false)
     * \param axis
     */
    virtual bool getAxisVisible(SUI::PlotAxisEnum::PlotAxis axis) const = 0;

    /*!
     * \brief getTitle
     * Returns the plot's title
     * \return - the title text
     */
    virtual std::string getTitle() const = 0;

    /*!
     * \brief setAxisMaxMajor
     * Set the maximum number of major scale intervals for a specified axis
     * \param axis
     * \param max
     */
    virtual void setAxisMaxMajor(SUI::PlotAxisEnum::PlotAxis axis, int max) = 0;

    /*!
     * \brief getAxisMaxMajor
     * Returns the maximum number of major ticks for a specified axis
     * \param axis
     * \return
     */
    virtual int getAxisMaxMajor(SUI::PlotAxisEnum::PlotAxis axis) const = 0;

    /*!
     * \brief setAxisMaxMinor
     * Set the maximum number of minor scale intervals for a specified axis
     * \param axis
     * \param max
     */
    virtual void setAxisMaxMinor(SUI::PlotAxisEnum::PlotAxis axis, int max) = 0;

    /*!
     * \brief getAxisMaxMinor
     * Returns the maximum number of minor ticks for a specified axis
     * \param axis
     * \return
     */
    virtual int getAxisMaxMinor(SUI::PlotAxisEnum::PlotAxis axis) const = 0;

    /*!
     * \brief setGridColor
     * Sets the color of the Grid
     * \param color - The color to set(SUI::ColorEnum::Color)
     */
    virtual void setGridColor(const SUI::ColorEnum::Color color) = 0;

    /*!
     * \brief getGridColor
     * Returns the color of the grid
     * \return SUI::ColorEnum::Color - color
     */
    virtual SUI::ColorEnum::Color getGridColor() const = 0;

    /*!
     * \brief setGridMajorStyle
     * Sets the linestyle of the major grid
     * \param linestyle - Line Style(SUI::LineStyleEnum::LineStyle)
     */
    virtual void setGridMajorStyle(const LineStyleEnum::LineStyle linestyle) = 0;

    /*!
     * \brief getGridMajorStyle
     * Returns the line style of the major grid
     * \return SUI::LineStyleEnum::LineStyle
     */
    virtual SUI::LineStyleEnum::LineStyle getGridMajorStyle() const = 0;

    /*!
     * \brief setGridMinorStyle
     * Sets the linestyle of the minor grid
     * \param linestyle - Line Style(SUI::LineStyleEnum::LineStyle)
     */
    virtual void setGridMinorStyle(const LineStyleEnum::LineStyle linestyle) = 0;

    /*!
     * \brief getGridMinorStyle
     * Returns the line style of the minor grid
     * \return SUI::LineStyleEnum::LineStyle
     */
    virtual SUI::LineStyleEnum::LineStyle getGridMinorStyle() const = 0;

    /*!
     * \brief setMouseCursor
     * Sets the mouse curshor shape
     * \param cursor - Cursor shape(SUI::CursorShapeEnum::CursorShape)
     */
    virtual void setMouseCursor(SUI::CursorShapeEnum::CursorShape cursor) = 0;

    /*!
     * \brief getMouseCursor
     * Returns the Mouse cursor shape
     * \return SUI::CursorShapeEnum::CursorShape
     */
    virtual SUI::CursorShapeEnum::CursorShape getMouseCursor() const = 0;

    /*!
     * \brief setLabelRotation
     * Sets the rotation (angle) of the labels on an axis.
     * Usable values are 0.0 (horizontal, which is default) to -90.0 (vertical), but other values are also accepted
     * \param axis  The axis on which the label rotation must be applied
     * \param rotation  The rotation value. Normally between 0.0 (horizontal) and -90.0 (vertical)
     * \note Call to replot on Plot widget is required to see the changes
     */
    virtual void setLabelRotation(const SUI::PlotAxisEnum::PlotAxis axis, const double rotation = 0) = 0;

    /*!
     * \brief getLabelRotation
     * Returns the label rotation value of the requested axis.
     * \param axis  The axis of which the label rotation must be retrieved
     * \return The actual rotation. Normally between 0.0 (horizontal) and -90.0 (vertical)
     */
    virtual double getLabelRotation(const SUI::PlotAxisEnum::PlotAxis axis) const = 0;

    /*!
     * \brief setCustomXAxisScale
     * Sets the X axis scale with custom time values for the major ticks.
     * \param items is a list of major time tick values,
     * \note first value represents the axis min value
     * \note last value represents the axis max value
     */
    virtual void setCustomXAxisScale(const std::list<double> &items) = 0;
protected:
    PlotWidget();
};
}

#endif // SUIPLOTWIDGET_H
