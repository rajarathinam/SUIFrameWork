//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::TabPage.
// !\description Header file for class SUI::TabPage.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUITABPAGE_H
#define SUITABPAGE_H

#include "SUIWidget.h"

#include <list>

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief The TabPage class
 */
class SUI_SHARED_EXPORT TabPage : public Widget
{
public:
    TabPage();
    virtual ~TabPage();

    /*!
     * \brief setTabText
     * Sets the title of a tabpage widget
     * \param title - the text to be set
     */
    virtual void setTabText(const std::string &title) = 0;

    /*!
     * \brief getTabText
     * Returns the title's text
     * \return - the title text
     */
    virtual std::string getTabText() const = 0;

    /*!
     * \brief setIconName
     * Loads an icon resource, specified by the name 'icon'
     * \param icon - name of the icon file to load
     */
    virtual void setIconName(const std::string &icon) = 0;

    /*!
     * \brief getIconName
     * Returns the name of the current icon
     * \return
     */
    virtual std::string getIconName() const = 0;

    /*!
     * \brief removeIcon
     * Removes the current icon from the widget.
     */
    virtual void removeIcon() = 0;

    /*!
     * \brief getAvailableIconNames
     * Returns a list of available icon names
     * \return
     */
    virtual const std::list<std::string> getAvailableIconNames() const = 0;
};
}

#endif // SUITABPAGE_H
