//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::Splitter.
// !\description Header file for class SUI::Splitter.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUISPLITTER_H
#define SUISPLITTER_H

#include "SUIWidget.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief The Splitter class
 */
class SUI_SHARED_EXPORT Splitter : public Widget
{
public:
    virtual ~Splitter();
    
protected:
    Splitter();

};
}

#endif // SUISPLITTER_H
