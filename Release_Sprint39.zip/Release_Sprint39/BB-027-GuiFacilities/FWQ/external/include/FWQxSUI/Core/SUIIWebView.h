//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author      Jan-Pieter Diender
// !\brief       Header file for class SUI::IWebView.
// !\description Header file for class SUI::IWebView.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUIIWEBVIEW_H
#define SUIIWEBVIEW_H

#include <string>

#include <boost/function.hpp>

namespace SUI {

class IWebView
{
public:
    virtual ~IWebView() {}

    /*!
     * \brief setUrl
     * This sets the url to be displayed in the view. If any content was already available in the view,
     * it will be cleared.
     * \param url
     */
    virtual void setUrl(const std::string &url) = 0;

    /*!
     * \brief getUrl
     * Returns the human-diaplayable string representation of the URL of the webview currently viewed
     * \return
     */
    virtual std::string getUrl() const = 0;

    /*!
     * \brief setHtml
     * This sets the content of the webview to the specified HTML. External objects such as stylesheets or
     * images referenced in the HTML document are located relative to baseUrl. The html is loaded
     * immediately; external objects are loaded asynchronously
     * \param html Specifies the HTML content as a string
     * \param baseUrl Specifies the relative location for external object to be loaded. Use an empty string
     * if not needed
     */
    virtual void setHtml(const std::string &html, const std::string &baseUrl) = 0;

    /*!
     * \brief setZoomFactor
     * This sets the zoom factor for the web view
     * \param factor The zoomfactor for the View. 1.0 is the default zoom factor
     */
    virtual void setZoomFactor(const double factor) = 0;

    /*!
     * \brief getZoomFactor
     * Returns the current zoom factor of the view
     * \return
     */
    virtual double getZoomFactor() const = 0;

    /*!
     * \brief loadFinished
     * Callback function that is called when the loading of the url or the HTML content finished.
     * \fn valueChanged
     * \param succeeded : boolean value indicating whether the loading succeeded
     */
    boost::function<void(bool)> loadFinished;
};
}
#endif // SUIIWEBVIEW_H
