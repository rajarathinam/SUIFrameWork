//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for WidgetPage.
// !\description Class implementation file for WidgetPage.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIWidgetPage.h"

#include "SUIObjectFactory.h"

SUI::WidgetPage::WidgetPage() : 
    Widget(SUI::ObjectType::WidgetPage)
{
}

SUI::WidgetPage::~WidgetPage()
{
}
