//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::PlotRenderer.
// !\description Class implementation file for SUI::PlotRenderer.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUIPlotRenderer.h"
#include "SUIPlotWidgetImpl.h"

#include <qwt_plot_renderer.h>

SUI::PlotRenderer::PlotRenderer() {
    implementation = new QwtPlotRenderer();
}

SUI::PlotRenderer::~PlotRenderer() {
    delete static_cast<QwtPlotRenderer*>(implementation);
}

void SUI::PlotRenderer::renderDocument(SUI::PlotWidget *plotWidget, const std::string &fileName, const std::string &format, const double widthMM, const double heightMM, int resolution) {
    if(plotWidget != NULL) {
        static_cast<QwtPlotRenderer*>(implementation)->renderDocument(dynamic_cast<SUI::PlotWidgetImpl*>(plotWidget)->getPlot(), QString::fromStdString(fileName), QString::fromStdString(format), QSizeF(widthMM, heightMM), resolution);
    }
}

