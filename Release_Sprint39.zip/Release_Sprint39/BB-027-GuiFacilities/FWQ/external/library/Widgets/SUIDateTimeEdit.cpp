//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for DateTimeEdit.
// !\description Class implementation file for DateTimeEdit.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUIDateTimeEdit.h"

#include "SUIObjectFactory.h"

SUI::DateTimeEdit::DateTimeEdit() :
    Widget(SUI::ObjectType::fromString(SUI::ObjectFactory::getClassName<DateTimeEdit>()))
{
}

SUI::DateTimeEdit::~DateTimeEdit()
{
}

