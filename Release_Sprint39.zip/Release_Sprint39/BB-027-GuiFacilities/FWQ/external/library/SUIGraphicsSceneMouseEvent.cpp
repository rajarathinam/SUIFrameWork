//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for GraphicsSceneMouseEvent.
// !\description Class implementation file for GraphicsSceneMouseEvent.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIGraphicsSceneMouseEvent.h"

#include <QGraphicsSceneMouseEvent>
#include <QGraphicsSceneWheelEvent>

SUI::GraphicsSceneMouseEvent::GraphicsSceneMouseEvent(
   double posX_t,
   double posY_t,
   double scenePosX_t,
   double scenePosY_t,
   double screenPosX_t,
   double screenPosY_t,
   double lastPosX_t,
   double lastPosY_t,
   double lastScenePosX_t,
   double lastScenePosY_t,
   double lastScreenPosX_t,
   double lastScreenPosY_t,
   SUI::MouseButton button_t,
   SUI::WheelDirection wheelDirection_t) :
   
   posX(posX_t),
   posY(posY_t),
   scenePosX(scenePosX_t),
   scenePosY(scenePosY_t),
   screenPosX(screenPosX_t),
   screenPosY(screenPosY_t),
   lastPosX(lastPosX_t),
   lastPosY(lastPosY_t),
   lastScenePosX(lastScenePosX_t),
   lastScenePosY(lastScenePosY_t),
   lastScreenPosX(lastScreenPosX_t),
   lastScreenPosY(lastScreenPosY_t),
   button(button_t),
   wheelDirection(wheelDirection_t)

{   
}

SUI::GraphicsSceneMouseEvent::GraphicsSceneMouseEvent(const GraphicsSceneMouseEvent &copy) :
   posX(copy.posX),
   posY(copy.posY),
   scenePosX(copy.scenePosX),
   scenePosY(copy.scenePosY),
   screenPosX(copy.screenPosX),
   screenPosY(copy.screenPosY),
   lastPosX(copy.lastPosX),
   lastPosY(copy.lastPosY),
   lastScenePosX(copy.lastScenePosX),
   lastScenePosY(copy.lastScenePosY),
   lastScreenPosX(copy.lastScreenPosX),
   lastScreenPosY(copy.lastScreenPosY),
   button(copy.button),
   wheelDirection(copy.wheelDirection)
{   
}

SUI::GraphicsSceneMouseEvent &SUI::GraphicsSceneMouseEvent::operator=(const GraphicsSceneMouseEvent &copy) {
   posX = copy.posX;
   posY = copy.posY;
   scenePosX = copy.scenePosX;
   scenePosY = copy.scenePosY;
   screenPosX = copy.screenPosX;
   screenPosY = copy.screenPosY;
   button = copy.button;
   wheelDirection = copy.wheelDirection;
   lastPosX = copy.lastPosX;
   lastPosY = copy.lastPosY;
   lastScenePosX = copy.lastScenePosX;
   lastScenePosY = copy.lastScenePosY;
   lastScreenPosX = copy.lastScreenPosX;
   lastScreenPosY = copy.lastScreenPosY;
   return *this;
}

double SUI::GraphicsSceneMouseEvent::getPosX() const { return posX; }
double SUI::GraphicsSceneMouseEvent::getPosY() const { return posY; }
double SUI::GraphicsSceneMouseEvent::getScenePosX() const { return scenePosX; }
double SUI::GraphicsSceneMouseEvent::getScenePosY() const { return scenePosY; }
double SUI::GraphicsSceneMouseEvent::getScreenPosX() const { return screenPosX; }
double SUI::GraphicsSceneMouseEvent::getScreenPosY() const { return screenPosY; }
double SUI::GraphicsSceneMouseEvent::getLastPosX() const { return lastPosX; }
double SUI::GraphicsSceneMouseEvent::getLastPosY() const { return lastPosY; }
double SUI::GraphicsSceneMouseEvent::getLastScenePosX() const { return lastScenePosX; }
double SUI::GraphicsSceneMouseEvent::getLastScenePosY() const { return lastScenePosY; }
double SUI::GraphicsSceneMouseEvent::getLastScreenPosX() const { return lastScreenPosX; }
double SUI::GraphicsSceneMouseEvent::getLastScreenPosY() const { return lastScreenPosY; }
SUI::WheelDirection SUI::GraphicsSceneMouseEvent::getWheelDirection() const { return wheelDirection; }
SUI::MouseButton SUI::GraphicsSceneMouseEvent::getButton() const { return button; }

boost::shared_ptr<SUI::GraphicsSceneMouseEvent> SUI::GraphicsSceneMouseEvent::create(void *qEv) {
    
    boost::shared_ptr<SUI::GraphicsSceneMouseEvent> suiEvent;
    
    QGraphicsSceneEvent *qEvent = static_cast<QGraphicsSceneEvent*>(qEv);
     
    QGraphicsSceneMouseEvent *mouseEvent = dynamic_cast<QGraphicsSceneMouseEvent*>(qEvent);
    QGraphicsSceneWheelEvent *wheelEvent = dynamic_cast<QGraphicsSceneWheelEvent*>(qEvent);
    
    SUI::MouseButton button = SUI::MouseButton::NoButton;
    SUI::WheelDirection wheelDirection = SUI::WheelDirection::Up;
    if (mouseEvent != NULL) {
         if (mouseEvent->buttons() & Qt::LeftButton) {
             button = SUI::MouseButton::Left;
         }
         else if (mouseEvent->buttons() & Qt::MiddleButton) {
             button = SUI::MouseButton::Middle;
         }
         else if (mouseEvent->buttons() & Qt::RightButton) {
             button = SUI::MouseButton::Right;
         }
         else if (mouseEvent->buttons() & Qt::NoButton) {
             button = SUI::MouseButton::NoButton;
         }
         else {
             button = (SUI::MouseButton)mouseEvent->button();
         }
         suiEvent = boost::shared_ptr<SUI::GraphicsSceneMouseEvent>(new SUI::GraphicsSceneMouseEvent(
               mouseEvent->pos().x(),
               mouseEvent->pos().y(),
               mouseEvent->scenePos().x(),
               mouseEvent->scenePos().y(),
               mouseEvent->screenPos().x(),
               mouseEvent->screenPos().y(),
               mouseEvent->lastPos().x(),
               mouseEvent->lastPos().y(),
               mouseEvent->lastScenePos().x(),
               mouseEvent->lastScenePos().y(),
               mouseEvent->lastScreenPos().x(),
               mouseEvent->lastScreenPos().y(),
               button,
               wheelDirection));
    }
    else if (wheelEvent != NULL) {
       wheelDirection = wheelEvent->delta() < 0 ? SUI::WheelDirection::Up : SUI::WheelDirection::Down;       
       suiEvent = boost::shared_ptr<SUI::GraphicsSceneMouseEvent>(new SUI::GraphicsSceneMouseEvent(
             wheelEvent->pos().x(),
             wheelEvent->pos().y(),
             wheelEvent->scenePos().x(),
             wheelEvent->scenePos().y(),
             wheelEvent->screenPos().x(),
             wheelEvent->screenPos().y(),
             0,
             0,
             0,
             0,
             0,
             0,
             button,
             wheelDirection));
    }
    return suiEvent;
}
