//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class ErrorModeEnum.
// !\description Header file for class ErrorModeEnum.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIErrorModeEnum.h"

#include <algorithm>

std::map<SUI::ErrorModeEnum::ErrorMode,std::string> SUI::ErrorModeEnum::errorMap =
{
    {SUI::ErrorModeEnum::None,"none"},
    {SUI::ErrorModeEnum::Ok,"ok"},
    {SUI::ErrorModeEnum::Warning,"warning"},
    {SUI::ErrorModeEnum::Error,"error"}
};

std::list<std::string> SUI::ErrorModeEnum::errorModeStringList =
    std::list<std::string>({
       SUI::ErrorModeEnum::toString(SUI::ErrorModeEnum::None),
       SUI::ErrorModeEnum::toString(SUI::ErrorModeEnum::Ok),
       SUI::ErrorModeEnum::toString(SUI::ErrorModeEnum::Warning),
       SUI::ErrorModeEnum::toString(SUI::ErrorModeEnum::Error)
    });

SUI::ErrorModeEnum::ErrorMode SUI::ErrorModeEnum::fromString(const std::string &errorStr) {
    std::string error;
    error.resize(errorStr.size());
    std::transform(errorStr.begin(),errorStr.end(),error.begin(),::tolower);

    if (error == toString(None)) return None;
    if (error == toString(Ok)) return Ok;
    if (error == toString(Warning)) return Warning;
    if (error == toString(Error)) return Error;
    return None;
}
std::string SUI::ErrorModeEnum::toString(ErrorMode error) {
    std::map<ErrorMode,std::string> m = errorMap;
    std::map<ErrorMode,std::string>::const_iterator it = m.find(error);
    return it == m.end() ? m.find(ErrorModeEnum::None)->second : it->second;
}

std::list<std::string> SUI::ErrorModeEnum::getErrorModeStringList()
{
    return errorModeStringList;
}
