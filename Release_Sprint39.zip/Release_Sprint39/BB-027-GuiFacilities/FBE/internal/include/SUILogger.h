//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::Logger.
// !\description Header file for class SUI::Logger.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUILOGGER_H
#define SUILOGGER_H

#include "SUISharedExport.h"

#include <QString>
#include <QMap>

namespace SUI {
class LoggerSignalHandler;

class SUI_SHARED_EXPORT Logger
{
public:
    typedef enum
    {
        Info,
        Warning,
        Error
    } LogLevel;

    static Logger *instance();

    void logMessage(LogLevel level, QString message);

    static void logWarning(const QString &message);
    static void logError(const QString &message);

private:
    explicit Logger(QString logfile);

private:
    static Logger       *myInstance;
    QString                 mLogfile;
    QMap<LogLevel, QString> mLevelStrings;
    LoggerSignalHandler *mLogSignalHandler;
};
}

#endif // SUILOGGER_H
