//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::SourceCodeGenerator.
// !\description Header file for class SUI::SourceCodeGenerator.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUISOURCECODEGENERATOR_H
#define SUISOURCECODEGENERATOR_H

#include <QStringList>

class QFile;

namespace SUI {
class Dialog;

class SourceCodeGenerator
{
public:
    static void dialogToSource(const QString &fileName, SUI::Dialog *dialog);

private:
    // cpp
    static void writeMocHeader(QFile *file, const QString &className, const QStringList &objectStringList);
    static void writeMocSource(QFile *file, const QString &className, const QStringList &objectStringList);
    static void writeHeader(QFile *file, const QString &className);
    static void writeSource(QFile *file, const QString &fileName);

    //python
    static void writePythonFile(QFile *file, const QString &className);

    static bool writeFileAllowed(QFile *file);

    static QString generatorString();

    static bool isFileOpen(QFile *file);

};

} // namespace SUI

#endif // SUI_SUISOURCECODEGENERATOR_H
