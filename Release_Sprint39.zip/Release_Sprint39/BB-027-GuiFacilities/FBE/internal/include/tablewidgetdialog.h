//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class TableWidgetDialog.
// !\description Header file for class TableWidgetDialog.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef TABLEWIDGETDIALOG_H
#define TABLEWIDGETDIALOG_H

#include <QDialog>

#include <SUITableWidgetImpl.h>

#include "WidgetController.h"

namespace Ui
{
class TableWidgetDialog;
}

class TableWidgetDialog : public QDialog
{
    Q_OBJECT

public:
    typedef enum ACTIONID
    {
        ID_ADDROWS,
        ID_ADDCOLUMNS,
        ID_REMOVEROWS,
        ID_REMOVECOLUMNS
    } ActionDefinition;

    explicit TableWidgetDialog(ActionDefinition actdef, WidgetController *tablewidgcont, QWidget *parent = 0);
    virtual ~TableWidgetDialog();

private slots:
    void onPositionChanged(int val);
    void onCountChanged(int val);
    void onActionTriggered();
    void onClose();

private:
    void insertRows(int row, int rows);
    void insertColumns(int column, int columns);
    void removeRows(int row, int rows);
    void removeColumns(int column, int columns);

    enum ItemType{ Row, Column };

    void insert(int row, int rowCount, int column, int columnCount, ItemType rowOrColumn);
    void remove(int rowPos, int rowCount, int columnPos, int columnCount, ItemType rowOrColumn);

private:
    Ui::TableWidgetDialog   *ui;
    int mPosition;      //  one based
    int mCount;         //  one based
    int mMaxPosition;   //  one based

    WidgetController *mTableWidgetContr;
    SUI::TableWidgetImpl *mTable;
    ActionDefinition mActDef;

};

#endif // TABLEWIDGETDIALOG_H
