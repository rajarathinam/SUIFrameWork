//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for mainwindow.
// !\description Class implementation file for mainwindow.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


/*===========================================================================*\
    CLASS       :   MainWindow

    This class provides the mainwindow implemetation. The GUI and a number of
    actions are defined in mainwindow.ui.

    N.B.: Make sure that the windows title always contains '[*]'. This is used
    by the function setWindowModified. If this function can not find this '[*]'
    in the window title, it will write an error to stderr (the terminal),
    which looks ugly.
\*===========================================================================*/
#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QFileDialog>
#include <QSettings>
#include <QStandardItemModel>
#include <QDesktopWidget>
#include <QTimer>
#include <QProgressBar>
#include <QCloseEvent>
#include <QMessageBox>
#include <QTextStream>
#include <QVariant>

#include <SUIStyleSheet.h>
#include <SUITreeViewImpl.h>
#include <SUITabWidgetImpl.h>
#include <SUITableWidgetImpl.h>
#include <SUITabPageImpl.h>
#include <SUISplitterImpl.h>
#include <SUIDialogSerializer.h>
#include <SUIXmlException.h>
#include <SUIIOException.h>
#include <SUIMessageBox.h>
#include <SUIUILoader.h>
#include <SUIDialog.h>

#include <CustomTableItemModel.h>

#include "UndoHandler.h"
#include "Model.h"
#include "FileController.h"
#include "formpropertiesdialog.h"
#include "usercontroldialog.h"
#include "GridProperties.h"
#include "tabbarnamedialog.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    mStandardModel(new QStandardItemModel),
    mSettings(new QSettings(QSettings::UserScope, "ASML", "SUI")),
    mWidgetCount(0),
    mWidgetCountProgressBar(NULL)
{
    UndoHandler::instance()->block(true);
    ui->setupUi(this);
    ui->scrollArea->setWidgetResizable(true);

    mWidgetCountProgressBar = new QProgressBar(this->statusBar());
    mWidgetCountProgressBar->hide();

    setWindowTitle(QString("%1 - SUIObject version: %2 - SUIEditor version:%3 [*]").arg(qApp->applicationName()).arg(QString::fromStdString(ui->frmFormEditor->getVersion().toString())).arg(QString::fromStdString(ui->frmFormEditor->getEditorVersion().toString())));

    QRect desktopRect = qApp->desktop()->availableGeometry();
    desktopRect.setWidth(desktopRect.width() - 100);
    desktopRect.setHeight(desktopRect.height() - 100);
    setGeometry(desktopRect);

    ui->frmFormEditor->setStyleSheet("background-color: white;");
    QRect frmRect = ui->frmFormEditor->geometry();
    ui->frmFormEditor->setGeometry(frmRect.x(), frmRect.y(), ui->frmFormEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt(),
                                   ui->frmFormEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt());
    ui->frmFormEditor->setFixedSize(ui->frmFormEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt(),
                                    ui->frmFormEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt());
    ui->frmFormEditor->setGridPixmap();

    addStatusbarSplitter();
    addMainTabWidget();
    rightButtonBar();
    bottomButtonBar();
    addStatusBar();
    handleFormLayout();

    Model::instance()->setMainWindow(this);
    Model::instance()->setFormEditor(ui->frmFormEditor);

    connect(Model::instance()->getModelHandler(), SIGNAL(newWidget()), this, SLOT(fillObjectTree()));
    connect(Model::instance()->getModelHandler(), SIGNAL(sendNewWidgetSelection(WidgetController *)),this, SLOT(setSelection(WidgetController *)));
    connect(Model::instance()->getModelHandler(), SIGNAL(sigNewWidgetProperties(WidgetController *)), this, SLOT(loadProperties(WidgetController *)));
    connect(ui->m_PropertyTW->getTablePointer(), SIGNAL(itemChanged(QTableWidgetItem *)), this, SLOT(onPropertyItemChanged(QTableWidgetItem *)));
    connect(ui->m_PropertyTW, SIGNAL(propertyValueChanged(QString, QString)), this, SLOT(onPropertyChanged(QString, QString)));
    connect(ui->m_PropertyTW, SIGNAL(propertyIndexedValueChanged(QString, QString)), this, SLOT(onPropertyIndexedValueChanged(QString, QString)));
    connect(ui->m_PropertyTW, SIGNAL(getNewDoubleValue(QString, QString)), this, SLOT(onGetNewDoubleValue(QString, QString)));
    connect(this, SIGNAL(sendDoubleValue(QString, QString)), ui->m_PropertyTW, SLOT(onReceiveDoubleValue(QString, QString)));
    connect(Model::instance()->getModelHandler(), SIGNAL(disablePasteAction(bool)), this, SLOT(onDisablePasteAction(bool)));
    connect(Model::instance()->getModelHandler(), SIGNAL(disableShowProperties(const QString &)), this, SLOT(onDisableShowProperties(const QString &)));
    connect(Model::instance()->getModelHandler(), SIGNAL(enableShowProperties(const QString &)), this, SLOT(onEnableShowProperties(const QString &)));
    connect(Model::instance()->getModelHandler(), SIGNAL(sigSendMessage(QString, QString, int)), this, SLOT(onNewLogMessage(QString, QString, int)));
    connect(Model::instance()->getModelHandler(), SIGNAL(enableForwardBackward(bool)), this, SLOT(onEnableForwardbackward(bool)));
    connect(Model::instance(), SIGNAL(sendDataChanged(bool)), this, SLOT(onDataChanged(bool)));

    ui->action_New->setShortcuts(QKeySequence::New);
    ui->action_New->setStatusTip(tr("Start a new layout"));
    ui->action_Open->setShortcuts(QKeySequence::Open);
    ui->action_Open->setStatusTip(tr("Open an existing xml file"));
    ui->action_Save->setShortcuts(QKeySequence::Save);
    ui->action_Save->setStatusTip(tr("Save current file"));
    ui->actionSave_As->setShortcuts(QKeySequence::SaveAs);
    ui->actionSave_As->setStatusTip(tr("Save as XML file"));
    ui->actionForm_Properties->setShortcut(tr("Ctrl+F"));
    ui->actionForm_Properties->setStatusTip(tr("Change the Form editor properties"));
    ui->action_Copy->setShortcut(QKeySequence::Copy);
    ui->action_Copy->setStatusTip(tr("Copy seletcted widget"));
    ui->action_Paste->setShortcut(QKeySequence::Paste);
    ui->action_Paste->setStatusTip(tr("Paste widget"));
    ui->action_Paste->setDisabled(true);
    ui->actionImport_UserControl->setShortcut(tr("Ctrl+I"));
    ui->actionImport_UserControl->setStatusTip(tr("Import new UserControl"));
    ui->action_Quit->setShortcuts(QKeySequence::Quit);
    ui->action_Quit->setStatusTip(tr("Quit the application"));
    ui->actionAdd_Standard_Button_area->setStatusTip(tr("Add the Standard Button Area"));
    ui->actionAdd_Standard_Button_area->setDisabled(true);
    ui->actionTo_Forground->setEnabled(false);
    ui->actionTo_Background->setEnabled(false);
    ui->actionForward->setEnabled(false);
    ui->actionBackward->setEnabled(false);
    ui->action_Undo->setShortcut(QKeySequence::Undo);
    QList<QKeySequence> redoKeyList;
    redoKeyList.append(QKeySequence::Redo);
    redoKeyList.append(QKeySequence(Qt::CTRL + Qt::Key_Y));
    ui->action_Redo->setShortcuts(redoKeyList);
    ui->action_Undo->setEnabled(false);
    ui->action_Redo->setEnabled(false);

    connect(ui->action_New, SIGNAL(triggered()), this, SLOT(onNew()));
    connect(ui->action_Open, SIGNAL(triggered()), this, SLOT(onOpen()));
    connect(ui->action_Save, SIGNAL(triggered()), this, SLOT(onSaveClicked()));
    connect(ui->actionSave_As, SIGNAL(triggered()), this, SLOT(onSaveAs()));
    connect(ui->actionForm_Properties, SIGNAL(triggered()), this, SLOT(onPropertiesDialog()));
    connect(ui->action_Quit, SIGNAL(triggered()), this, SLOT(onQuit()));
    connect(ui->action_Copy, SIGNAL(triggered()), this, SLOT(onCopyWidget()));
    connect(ui->action_Paste, SIGNAL(triggered()), this, SLOT(onPasteWidget()));
    connect(ui->actionImport_UserControl, SIGNAL(triggered()), this, SLOT(onImportUserControl()));
    connect(ui->actionAdd_Standard_Button_area, SIGNAL(triggered()), this, SLOT(onAddStandardButtonArea()));
    connect(ui->actionTo_Forground, SIGNAL(triggered()), this, SLOT(onToForground()));
    connect(ui->actionTo_Background, SIGNAL(triggered()), this, SLOT(onBackground()));
    connect(ui->actionForward, SIGNAL(triggered()), this, SLOT(onForward()));
    connect(ui->actionBackward, SIGNAL(triggered()), this, SLOT(onBackward()));
    connect(ui->actionAddTabPage, SIGNAL(triggered()), this, SLOT(onAddTabPageAct()));
    connect(ui->actionMoveNextAct, SIGNAL(triggered()), this, SLOT(onMoveNextAct()));
    connect(ui->actionMovePrevAct, SIGNAL(triggered()), this, SLOT(onMovePrevAct()));
    connect(ui->actionDeleteAct, SIGNAL(triggered()), this, SLOT(onDeleteAct()));
    connect(ui->actionPreview, SIGNAL(triggered()), this, SLOT(onPreview()));
    connect(ui->actionCollapseAll, SIGNAL(triggered()), this, SLOT(onCollapseAll()));
    connect(ui->actionExpandAll, SIGNAL(triggered()), this, SLOT(onExpandAll()));
    connect(ui->action_Undo, SIGNAL(triggered()), this, SLOT(onUndo()));
    connect(ui->action_Redo, SIGNAL(triggered()), this, SLOT(onRedo()));
    connect(ui->actionGrid_Enabled, SIGNAL(toggled(bool)), this, SLOT(onGridChanged(bool)));
    connect(ui->actionGrid_Options, SIGNAL(triggered()), this, SLOT(onGridOptions()));

    connect(UndoHandler::instance(), SIGNAL(doEnableUndo(bool)), this, SLOT(onEnableUndo(bool)));
    connect(UndoHandler::instance(), SIGNAL(doEnableRedo(bool)), this, SLOT(onEnableRedo(bool)));
    connect(UndoHandler::instance(), SIGNAL(doSendUndoRedoText(const QString &, const QString &)), this, SLOT(onUndoRedoText(const QString &, const QString &)));
    connect(this, SIGNAL(customContextMenuRequested(QPoint)), this, SLOT(onCustomContextMenuRequest(QPoint)));

    Model::instance()->useGrid(mSettings->value("GridActive", false).toBool());
    Model::instance()->setXSnap(mSettings->value("X-Snap", true).toBool());
    Model::instance()->setYSnap(mSettings->value("Y-Snap", true).toBool());
    Model::instance()->setXGridDistance(mSettings->value("X-Distance", 10).toInt());
    Model::instance()->setYGridDistance(mSettings->value("Y-Distance", 10).toInt());

    ui->actionGrid_Enabled->setChecked(Model::instance()->gridActive());
    ui->widgetSelector->initWidgets();
    ui->frmFormEditor->setStyleSheet("background-color: white;");
    ui->m_ObjectTV->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->m_ObjectTV->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->m_PropertyTW->getTablePointer()->setColumnWidth(0, (ui->m_PropertyTW->getTablePointer()->width()) / 4);

    /*
    *  In case the UndoBuffer must be investigated, comment out the next two lines and uncomment the third line beneath.
    *  This will show a menu item under Edit where you can print out the contents of the Undo Buffer (in the Application Output)
    */
    ui->actionShow_Undo_Buffer->setVisible(false);
    ui->actionShow_Undo_Buffer->setEnabled(false);

    QList<int>  sizelist;
    sizelist << 30 << 680 << 230;
    ui->splitter_3->setSizes(sizelist);
    setContextMenuPolicy(Qt::CustomContextMenu);  // Catch right mouse button

    Model::instance()->setNewSelected(Model::instance()->getTopWidget());
    Model::instance()->setDataChanged(false);
    Model::instance()->getCurrentTopPage()->addToTaborder();


    connect(FileController::instance(),SIGNAL(enableShowProperties(QString)),this,SLOT(onEnableShowProperties(QString)));
    connect(FileController::instance(),SIGNAL(disableShowProperties(QString)),this,SLOT(onDisableShowProperties(QString)));
    connect(FileController::instance(),SIGNAL(startWidgetProcess(int)),this,SLOT(onWidgetProcessStart(int)));
    connect(FileController::instance(),SIGNAL(finishWidgetProcess()),this,SLOT(onFinishWidgetProcess()));
    connect(FileController::instance(),SIGNAL(loadProperties(WidgetController*)),this,SLOT(loadProperties(WidgetController*)));
    connect(FileController::instance(),SIGNAL(fillObjectTree()),this,SLOT(fillObjectTree()));
    connect(FileController::instance(),SIGNAL(statusMessage(QString,int)),statusBar(),SLOT(showMessage(QString,int)));
    connect(FileController::instance(),SIGNAL(enableStandardButtonArea(bool)),this,SLOT(onEnableStandardButtonArea(bool)));
    connect(FileController::instance(),SIGNAL(changeWindowTitle(QString)),this,SLOT(setWindowTitle(QString)));

    FileController::instance()->initialize(ui->frmFormEditor,ui->usercontrolSelector, ui->menu_File, mSettings);
    FileController::instance()->resetRecentFilesMenu();

    ui->frmFormEditor->setGridPixmap();
    QTimer::singleShot(10, this, SLOT(onLoadFinished()));
    UndoHandler::instance()->block(false);

    ui->m_ObjectTV->model()->setHeaderData(0,Qt::Horizontal,"Widget treeview",Qt::DisplayRole);

}

/*!
 *  FUNCTION    :   ~MainWindow
 *  PARAMETERS  :   n.a.
 *  RETURN      :   n.a.
 *
 *  This is the destructor
 */
MainWindow::~MainWindow()
{
    mSettings->deleteLater();
    FileController::instance()->deleteLater();
    mWidgetCountProgressBar->deleteLater();

    delete ui;

    UndoHandler::instance()->deleteInstance();
    Model::instance()->deleteInstance();
}

/*!
 *  FUNCTION    :   onSaveClicked
 *  PARAMETERS  :   QString filename
 *                      The name of the file to save to
 *  RETURN      :   void
 *
 *  This is a SLOT function, connected to the ui->action_Save triggered SIGNAL.
 *  Because Save() is used by onSaveTimeout() as well, in which case no export
 *  code files should be generated, there is a separate slot function to
 *  differentiate between a save started by a user and a backup save.
 */
void MainWindow::onSaveClicked() {
    FileController::instance()->save(FileController::instance()->getFileName());
}

/*!
 *  FUNCTION    :   onSaveAs
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This is a SLOT function, connected to the ui->actionSave_As triggered SIGNAL.
 *  Or it is called by onSave, if the file name (mFileName) is not known.
 *  It will display a file dialogbox, asking for a filename. The '.xml' extension
 *  is added if it is not supplied by the user. It then calls onSave, which
 *  actually saves the Form.
 */
void MainWindow::onSaveAs() {
    FileController::instance()->saveAs();
}

/*!
 *  FUNCTION    :   onOpen
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This is a SLOT function, connected to the ui->action_Open triggered SIGNAL.
 *  It will display a file dialogbox, asking for a filename. It then uses the
 *  serializer to read the created gui to file.
 *
 *  Release 10:
 *  Since this version, the Main TabWidget is not mandatory anymore.
 *  So the (newly introduced) TopWidget is either the Main TabWidget or a
 *  RticWidgetPage.
 */
void MainWindow::onOpen() {
    UndoHandler::instance()->block(true);
    if (FileController::instance()->saveDialog()) {
        QString fileName = QFileDialog::getOpenFileName(this, tr("Open XML file"), "", tr("XML Files (*.xml)"));
        if ( !fileName.isNull() ) FileController::instance()->openFile(fileName);
    }
    UndoHandler::instance()->block(false);
}

/*!
 *  FUNCTION    :   onNew
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This is a SLOT function, connected to the ui->action_New triggered SIGNAL.
 *  It cleans the current Form, it displays the PropertiesDialog and sets up a
 *  new Form with the properties selected in the PropertiesDialog.
 */
void MainWindow::onNew() {
    UndoHandler::instance()->block(true);
    if (FileController::instance()->saveDialog()) {
        onDisableShowProperties(__FUNCTION__);
        // Remove all current widgets
        QList<WidgetController *> children = ui->frmFormEditor->childList();
        ui->frmFormEditor->clearChildList();
        foreach(WidgetController * child, children)
        {
            child->close();
            child->deleteLater();
        }
        Model::instance()->reset();
        ui->frmFormEditor->reset();
        ui->usercontrolSelector->clear();
        ui->usercontrolSelector->init();

        FileController::instance()->clearFileName();

        this->setWindowTitle(QString("%1 - [*]").arg(qApp->applicationName()));
        FormPropertiesDialog *formDialog = new FormPropertiesDialog(ui->frmFormEditor, this);
        formDialog->setStyleSheet(QString::fromStdString(SUI::StyleSheet::getInstance()->getStyleSheet()));
        formDialog->exec();
        QRect frmRect = ui->frmFormEditor->geometry();
        ui->frmFormEditor->setGeometry(frmRect.x(), frmRect.y(), ui->frmFormEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt(),
                                       ui->frmFormEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt());
        ui->frmFormEditor->setFixedSize(ui->frmFormEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt(),
                                        ui->frmFormEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt());

        formDialog->deleteLater();
        statusbarSplitter();
        addMainTabWidget();
        rightButtonBar();
        bottomButtonBar();
        addStatusBar();
        handleFormLayout();
        onEnableShowProperties(__FUNCTION__);
        fillObjectTree();
        WidgetController *tabWidg = Model::instance()->getMainTabWidget();
        Model::instance()->setNewSelected(tabWidg);
        Model::instance()->setDataChanged(false);
        UndoHandler::instance()->clearBuffer();
    }
    QTimer::singleShot(10, this, SLOT(onLoadFinished()));
    UndoHandler::instance()->block(false);
}

void MainWindow::onLoadFinished() {
    Model::instance()->setDataChanged(false);
}

/*!
 *  FUNCTION    :   onPropertiesDialog
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This is a SLOT function, connected to the ui->actionForm_Properties
 *  triggered SIGNAL. It shows a dialogbox with the properties of the FormEditor.
 *  If the dialogbox is closed with the 'Ok' button, the properties will be
 *  saved and the size of the FormEditor and the main TabWidget will be changed.
 *
 *  Release 10:
 *  Since this version, the Main TabWidget is not mandatory anymore.
 *  So the (newly introduced) TopWidget is either the Main TabWidget or a
 *  RticWidgetPage.
 */
void MainWindow::onPropertiesDialog() {
    this->loadProperties(NULL);
    Model::instance()->deselectAll();
    FormPropertiesDialog *formDialog = new FormPropertiesDialog(ui->frmFormEditor, this);
    formDialog->setStyleSheet(QString::fromStdString(SUI::StyleSheet::getInstance()->getStyleSheet()));
    if ( formDialog->exec() != 0 ) {
        ui->m_PropertyTW->getTablePointer()->blockSignals(true);

        ui->frmFormEditor->setGeometry(ui->frmFormEditor->pos().x(), ui->frmFormEditor->pos().y(),
                                       ui->frmFormEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt(),
                                       ui->frmFormEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt());
        ui->frmFormEditor->setFixedSize(ui->frmFormEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt(),
                                        ui->frmFormEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt());
        addStatusbarSplitter();
        checkMaintabwidgetParent();
        removeStatusbarSplitter();
        rightButtonBar();
        addStatusBar();
        handleFormLayout();
        fillObjectTree();

        QApplication::processEvents();

        ui->frmFormEditor->setGridPixmap();
        WidgetController *wcTopPage = Model::instance()->getCurrentTopPage();
        Model::instance()->selectNewWidget(wcTopPage->getId());
        Model::instance()->setNewSelected(wcTopPage);
        loadProperties(wcTopPage);
        ui->m_PropertyTW->getTablePointer()->blockSignals(false);
    }
    formDialog->deleteLater();
}

/*!
 *  FUNCTION    :   onDisablePasteAction
 *  PARAMETERS  :   bool setDisabled
 *  RETURN      :   void
 *
 *  This is a SLOT function, connected to the disablePasteAction SIGNAL. It is
 *  emitted by Model::removeWidget() and disables the ui->action_Paste QAction.
 *  This will prefend users from pasting an object which has been deleted.
 */
void MainWindow::onDisablePasteAction(bool setDisabled) {
    ui->action_Paste->setDisabled(setDisabled);
}

/*!
 *  FUNCTION    :   closeEvent
 *  PARAMETERS  :   QCloseEvent *event
 *  RETURN      :   void
 *
 *  This function is being called, whenever a user clicks on the top right 'X'
 *  icon to close the application. This function calls onQuit(), which will check
 *  if anything has changed. And if so, will ask the user to save these changes.
 */
void MainWindow::closeEvent(QCloseEvent *event) {
    onQuit();
    event->ignore();
}

/*!
 *  FUNCTION    :   loadProperties
 *  PARAMETERS  :   DragAndDropInfo *ddinfo
 *                      The DragAndDropInfo object to be displayed in the Object
 *                      property Table widget.
 *  RETURN      :   void
 *
 *  Fills the ui->m_PropertyTW Table widget with the properties of the
 *  DragAndDropInfo object
 *
 *  We wanted the properties of the TabWidget and the TabPages to be invisible.
 *  But for some reason, that introduces a strange bug. The problem is that when
 *  resizing the Form Editor format, the active TabPage becomes very small and
 *  therefor the widgets on it, become invisible. Showing the TabWidget and
 *  TabPage properties in the Table Widget somehow solves that problem. To be
 *  investigated.
 *
 *  Release 10:
 *  Since this version, the Main TabWidget is not mandatory anymore.
 *  So the (newly introduced) TopWidget is either the Main TabWidget or a
 *  RticWidgetPage.
 */
void MainWindow::loadProperties(WidgetController *ddwidg) {
    QList<PropertyStruct>   propStructList;
    SUI::ObjectType::Type objectType;

    ui->m_PropertyTW->getTablePointer()->blockSignals(true);
    ui->m_PropertyTW->clearTable();
    if ( ddwidg != NULL ) {
        UndoHandler::instance()->block(true);
        QSet<SUI::ObjectPropertyTypeEnum::Type> keyList = ddwidg->getPropertyList();
        objectType = ddwidg->getObjectType();
        bool bTopWidgCheck = (ddwidg == Model::instance()->getTopWidget());
        bool bRightButtonCheck = false;
        if ( ddwidg->getParent() != NULL ) bRightButtonCheck = (ddwidg->getParent()->getId() == "rbbRight");

        bool bUCtrlCheck = (!(ddwidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::UserControl).isEmpty()) && (objectType != SUI::ObjectType::UserControl));

        foreach(SUI::ObjectPropertyTypeEnum::Type type, keyList) {
            SUI::ObjectProperty *prop = ddwidg->getBaseWidget()->getProperty(type);
            if ( prop == NULL ) continue;
            if (prop->isVisible()) {
                PropertyStruct  propStruct;
                propStruct.key = type;
                propStruct.readOnly = (bTopWidgCheck ||
                                       (bRightButtonCheck && (propStruct.key == SUI::ObjectPropertyTypeEnum::XPos)) ||
                                       bUCtrlCheck ||
                                       (type == SUI::ObjectPropertyTypeEnum::ObjectType) ||
                                       (ddwidg->getBaseWidget()->getProperty(type)->isReadOnly())) ? true : false;
                propStructList.append(propStruct);
            }
        }

        if (Model::instance()->getSelectionList().size() > 1) {
            objectType = Model::instance()->getSelectionList().at(0)->getObjectType();
            for (int selInd = 0; selInd < Model::instance()->getSelectionList().size(); ++selInd) {
                WidgetController *wcCurrent = Model::instance()->getSelectionList()[selInd];
                if (wcCurrent == ddwidg) continue;

                if (objectType != wcCurrent->getObjectType()) objectType = SUI::ObjectType::None;

                bool bTopWidgCheck = (wcCurrent == Model::instance()->getTopWidget()) || (objectType == SUI::ObjectType::TabPage);
                bool bRightButtonCheck = (wcCurrent->getParent()->getId() == "rbbRight");
                bool bUCtrlCheck = (!(wcCurrent->getPropertyValue(SUI::ObjectPropertyTypeEnum::UserControl).isEmpty()) && (objectType != SUI::ObjectType::UserControl));
                for (int cplInd = 0; cplInd < propStructList.size(); ++cplInd) {
                    SUI::ObjectPropertyTypeEnum::Type key = propStructList.at(cplInd).key;
                    if (!wcCurrent->getPropertyList().contains(key) || !wcCurrent->getBaseWidget()->getProperty(key)->isVisible() ||
                            (key == SUI::ObjectPropertyTypeEnum::ObjectType) || (key == SUI::ObjectPropertyTypeEnum::ID))
                    {                        
                        propStructList.removeAt(cplInd--);
                    }
                    else
                    {
                        if (bTopWidgCheck || bUCtrlCheck || ((key == SUI::ObjectPropertyTypeEnum::XPos) && bRightButtonCheck) ||
                                (wcCurrent->getBaseWidget()->getProperty(key)->isReadOnly()))
                        {
                            propStructList[cplInd].readOnly = true;
                        }
                    }
                }
            }
        }
        for (int ind = 0; ind < propStructList.size(); ++ind) {
            SUI::ObjectPropertyTypeEnum::Type propertyType = propStructList.at(ind).key;
            if (objectType == SUI::ObjectType::TableWidget && propertyType == SUI::ObjectPropertyTypeEnum::ColumnWidths) {
                int min = ddwidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::ColumnCount).toInt() - 1;
                int max = 1024;
                ui->m_PropertyTW->addTableRow(objectType,ddwidg->getBaseWidget()->getProperty(propertyType),propStructList.at(ind).readOnly,min,max);
            }
            else if (objectType == SUI::ObjectType::TableWidget && propertyType == SUI::ObjectPropertyTypeEnum::RowHeights) {
                int min = ddwidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::RowCount).toInt() - 1;
                int max = 1024;
                ui->m_PropertyTW->addTableRow(objectType,ddwidg->getBaseWidget()->getProperty(propertyType),propStructList.at(ind).readOnly,min,max);
            }
            else {
                if (objectType == SUI::ObjectType::TabPage && propertyType == SUI::ObjectPropertyTypeEnum::StateList) {
                    //Dont add states, to the tabpage. Why do they come in the list?
                }
                else {
                    ui->m_PropertyTW->addTableRow(objectType, ddwidg->getBaseWidget()->getProperty(propertyType),propStructList.at(ind).readOnly);
                }
            }
        }
        if (objectType == SUI::ObjectType::StateWidget){
            QStringList dummylist;
            ui->m_PropertyTW->addNonPropertyToTable("Add states", SUI::ObjectProperty::File, dummylist);
        }

        if (Model::instance()->getSelectionList().size() == 1) {
            QStringList list;
            if (objectType == SUI::ObjectType::TreeView) {
                ui->m_PropertyTW->addNonPropertyToTable("Treewidget Edit", SUI::ObjectProperty::File, list);
            }
            else if (objectType == SUI::ObjectType::TabPage) {
                ui->m_PropertyTW->addNonPropertyToTable("Add states", SUI::ObjectProperty::File, list);
            }
            else if (objectType == SUI::ObjectType::TableWidget) {
                ui->m_PropertyTW->addNonPropertyToTable("Set Item Type", SUI::ObjectProperty::File, list);
                ui->m_PropertyTW->addNonPropertyToTable("Set Horizontal Header", SUI::ObjectProperty::File, list);
                ui->m_PropertyTW->addNonPropertyToTable("Set Vertical Header", SUI::ObjectProperty::File, list);
            }
            else if (objectType == SUI::ObjectType::SpinBox ||
                     objectType == SUI::ObjectType::DoubleSpinBox ||
                     objectType == SUI::ObjectType::ScienceSpinBox) {
                list.append(QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::SpinBox)));
                list.append(QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::DoubleSpinBox)));
                list.append(QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::ScienceSpinBox)));
                ui->m_PropertyTW->addNonPropertyToTable("Set Item Type", SUI::ObjectProperty::DropDown, list);
            }
        }
        UndoHandler::instance()->block(false);
    }
    ui->m_PropertyTW->getTablePointer()->blockSignals(false);
}

/*!
 *  FUNCTION    :   onPropertyItemChanged
 *  PARAMETERS  :   QTableWidgetItem *valueItem
 *  RETURN      :   void
 *
 *  This is a SLOT function, connected to the ui->m_PropertyTW itemChanged SIGNAL.
 *  This SIGNAL is emitted whenever the data of the valueItem in the Property
 *  TableWidget is changed.
 *  If the Visible property is changed, it changes the visibility of the object
 *  accordingly. If the ID is changed, it checks if this is a valid change. If
 *  so, the Object TreeView needs to be updated with this new ID. And, of course,
 *  the new value needs to be saved in the object.
 */
void MainWindow::onPropertyItemChanged(QTableWidgetItem *valueItem) {
    QString strValue = valueItem->text();
    QTableWidgetItem *keyItem = ui->m_PropertyTW->getTablePointer()->item(valueItem->row(), 0);
    WidgetController *curWidg = Model::instance()->getCurrentWidget();

    QString tempStr = QString::fromStdString(SUI::ObjectPropertyTypeEnum::toString(SUI::ObjectPropertyTypeEnum::ID));
    //  In case multiple Widgets are selected, curWidg will be NULL
    if ((curWidg != NULL) && (keyItem->text() == tempStr)) {
        WidgetState  *wsState = UndoHandler::instance()->getNewUndoInfo(curWidg, ACT_PROPERTY, "Change property");
        QString curID = curWidg->getId();
        bool    bIdChanged = false;
        if (curID != strValue) {
            QString editPrefix = strValue.left(3);
            QString widgetPrefix = QString::fromStdString(SUI::ObjectType::getIdPrefix(curWidg->getObjectType()));
            if (editPrefix == widgetPrefix) {
                if (Model::instance()->IDExists(strValue)) {
                    QMessageBox::critical(this, qApp->applicationName(),
                                          tr("A widget with this ID '%1' already exists").arg(strValue));
                    strValue = curID;
                }
                else {
                    bIdChanged = true;
                }
            }
            else if (SUI::ObjectType::getIdPrefix(curWidg->getObjectType()) == editPrefix.toStdString()) {
                strValue.replace(0, 3, widgetPrefix);
                if (Model::instance()->IDExists(strValue) && curID != strValue) {
                    QMessageBox::critical(this, qApp->applicationName(),
                                          tr("Replaced invalid widget prefix '%1'' with '%2'', but a widget with that ID '%3' already exists.")
                                          .arg(editPrefix).arg(widgetPrefix).arg(strValue));
                    strValue = curID;
                }
                else {
                    QMessageBox::warning(this, qApp->applicationName(), tr("Replaced invalid widget prefix '%1'' with '%2'.")
                                         .arg(editPrefix).arg(widgetPrefix));
                    bIdChanged = true;
                }
            }
            else {
                strValue.prepend(widgetPrefix);
                if ((Model::instance()->IDExists(strValue)) && (curID != strValue))
                {
                    QMessageBox::critical(this, qApp->applicationName(),
                                          tr("A valid prefix '%1'' was added to the ID, but a widget with that ID '%2' already exists.")
                                          .arg(widgetPrefix).arg(strValue));
                    strValue = curID;
                }
                else
                {
                    QMessageBox::warning(this, qApp->applicationName(),
                                         tr("A valid prefix '%1'' was added to the ID.").arg(widgetPrefix));
                    bIdChanged = true;
                }
            }
        }
        valueItem->setText(strValue);
        curWidg->setPropertyValue(SUI::ObjectPropertyTypeEnum::fromString(keyItem->text().toStdString()), valueItem->text());
        if (curWidg->getObjectType() == SUI::ObjectType::ListView)
        {
            Model::instance()->getModelHandler()->newWidgetProperties(curWidg); //force update property table
        }
        else if (curWidg->getObjectType() == SUI::ObjectType::TableWidget)
        {
            curWidg->renameTableWidgetItems();
        }
        else if (curWidg->getObjectType() == SUI::ObjectType::TreeView)
        {
            WidgetController *parentWidg = curWidg;
            while (parentWidg->getObjectType() != SUI::ObjectType::TreeView)
            {
                parentWidg = parentWidg->getParent();
            }
            dynamic_cast<SUI::TreeViewImpl *>(parentWidg->getBaseWidget())->renameItem(curID, strValue);
        }
        else if (curWidg->getObjectType() == SUI::ObjectType::UserControl)
        {
            curWidg->renameChildren(QString(""));
            curWidg->renameChildren(curWidg->getId());
            Model::instance()->renameUsedUserControl(curID, strValue);
        }
        curWidg->updatePixmap();
        if (curWidg->getParent()->getObjectType() == SUI::ObjectType::TableWidget)
        {
            curWidg->getParent()->updatePixmap();
        }
        if (bIdChanged)
        {
            fillObjectTree();
            UndoHandler::instance()->finishUndoInfo(wsState, curWidg);
            UndoHandler::instance()->addToUndoGroup(wsState);
        }
        else
        {
            UndoHandler::instance()->deleteWidgetState(wsState);
        }
    }
    else
    {
        if (keyItem->text() == QString(SUI::ObjectPropertyTypeEnum::ID))
        {
            QMessageBox::warning(this, qApp->applicationName(),
                                 tr("You can not change the ID of multiple widgets at the same time."));
            return;
        }
        if (( curWidg != NULL ) && (keyItem->text() == QString("Text")) && (curWidg->getObjectType() == SUI::ObjectType::TreeViewItem))
        {
            WidgetController *parentWidg = curWidg;
            while (parentWidg->getObjectType() != SUI::ObjectType::TreeView)
            {
                parentWidg = parentWidg->getParent();
            }
            dynamic_cast<SUI::TreeViewImpl *>(parentWidg->getBaseWidget())->updateText(curWidg->getId(), strValue);
            parentWidg->updatePixmap();
        }
        bool    bClearSelection = false;
        if (!Model::instance()->hasSelectedItems())
        {
            Model::instance()->addToSelectionList(curWidg);
            bClearSelection = true;
        }
        QList<WidgetState *> wcStateList;
        for (int ind = 0; ind < Model::instance()->getSelectionList().size(); ++ind)
        {
            curWidg = Model::instance()->getSelectionList()[ind];
            if ( (keyItem != NULL) && (keyItem != valueItem) && (curWidg != NULL) )
            {
                WidgetState  *wcState = UndoHandler::instance()->getNewUndoInfo(curWidg, ACT_PROPERTY, "Change property");
                if (keyItem->text() == "Visible")
                {
                    if (valueItem->text().compare("false", Qt::CaseInsensitive) == 0)
                    {
                        curWidg->setVisible(false);
                    }
                    else
                    {
                        curWidg->setVisible(true);
                    }
                }
                valueItem->setText(strValue);
                curWidg->setPropertyValue(SUI::ObjectPropertyTypeEnum::fromString(keyItem->text().toStdString()), valueItem->text());
                curWidg->updatePixmap();
                if (curWidg->getParent()->getObjectType() == SUI::ObjectType::TableWidget)
                {
                    curWidg->getParent()->updatePixmap();
                }
                UndoHandler::instance()->finishUndoInfo(wcState, curWidg);
                wcStateList.append(wcState);
            }
        }
        UndoHandler::instance()->addToUndoGroup(wcStateList);
        if (bClearSelection)
        {
            Model::instance()->removeFromSelectionList(curWidg);
        }
    }
    Model::instance()->setDataChanged(true);

}

/*!
 *  FUNCTION    :   onPropertyChanged
 *  PARAMETERS  :   QString key
 *                  QString value
 *  RETURN      :   void
 *
 *  This is a SLOT function, connected to the ui->m_PropertyTW
 *  propertyValueChanged SIGNAL. This SIGNAL is emitted whenever the value of a
 *  SpinBox or ComboBox in the Property Table Widget changes. This function
 *  sets the new property value of the object and updates that object. This way,
 *  the object shows the changes immediately.
 */
void MainWindow::onPropertyChanged(QString key, QString value)
{
    QList<WidgetState *> wcStateList;
    SUI::ObjectPropertyTypeEnum::Type type = SUI::ObjectPropertyTypeEnum::fromString(key.toStdString());
    for (int ind = 0; ind < Model::instance()->getSelectionList().size(); ++ind) {
        WidgetController *currentWidget = Model::instance()->getSelectionList()[ind];
        if ( currentWidget != NULL ) {
            if (currentWidget->getPropertyList().contains(type)) {
                WidgetState  *wcState = UndoHandler::instance()->getNewUndoInfo(currentWidget, ACT_PROPERTY, "Change property");
                currentWidget->setPropertyValue(type, value);
                if (currentWidget->getParent()->getObjectType() == SUI::ObjectType::TableWidget) {
                    if (type == SUI::ObjectPropertyTypeEnum::CellAlignment) {
                        //get item index
                        int row = currentWidget->getTableWidgetItemRowNr() - 1;
                        int col = currentWidget->getTableWidgetItemColumnNr() - 1;

                        //do update on parent; Note: curWidg wil be destroyed in updateTableCell
                        Model::instance()->setNewSelected(currentWidget->getParent());
                        WidgetController *curTable = Model::instance()->getCurrentWidget();
                        
                        curTable->updateTableCell(row, col, currentWidget->getObjectType(), SUI::AlignmentEnum::fromString(!value.size() ? "stretch" : value.toLower().toStdString()));
                        curTable->updatePixmap();

                        //set focus to new tableCell item
                        SUI::TableWidgetImpl *table = dynamic_cast<SUI::TableWidgetImpl*>(curTable->getBaseWidget());
                        QString newCellId = table->getWidget()->model()->data(table->getWidget()->model()->index(row,col),SUI::CustomTableItemModel::IDRole).toString();
                        Model::instance()->setNewSelected(Model::instance()->getWidgetController(newCellId));
                    }
                    else if (type == SUI::ObjectPropertyTypeEnum::CellName){

                        //get item index
                        int row = currentWidget->getTableWidgetItemRowNr() - 1;
                        int col = currentWidget->getTableWidgetItemColumnNr() - 1;
                        //do update on parent; Note: curWidg wil be destroyed in updateTableCell
                        Model::instance()->setNewSelected(currentWidget->getParent());
                        WidgetController *curTable = Model::instance()->getCurrentWidget();
                        SUI::TableWidgetImpl *table = dynamic_cast<SUI::TableWidgetImpl*>(curTable->getBaseWidget());
                        table->setWidgetItemName(row, col, value.toLower().toStdString());
                    }
                    else {
                        currentWidget->getParent()->updatePixmap();
                    }
                }
                else if (currentWidget->getObjectType() == SUI::ObjectType::StateWidget) {
                    currentWidget->getParent()->updatePixmap();
                }
                else if (currentWidget->getObjectType() == SUI::ObjectType::TreeViewItem) {
                    WidgetController *parentWidget = currentWidget;
                    while (parentWidget->getObjectType() != SUI::ObjectType::TreeView) {
                        parentWidget = parentWidget->getParent();
                    }
                }

                else if (type == SUI::ObjectPropertyTypeEnum::Checked && currentWidget->getObjectType() == SUI::ObjectType::RadioButton) {
                    if (value == "true") {
                        WidgetController *wcParent = currentWidget->getParent();
                        if ( wcParent != NULL ) {
                            QList<WidgetState *> wcChildStateList;
                            foreach(WidgetController * wcChild, wcParent->childList()) {
                                if ( wcChild == NULL ) continue;
                                if (wcChild == currentWidget) continue;
                                if (wcChild->getObjectType() != SUI::ObjectType::RadioButton) continue;

                                WidgetState  *wcChildState = UndoHandler::instance()->getNewUndoInfo(wcChild, ACT_PROPERTY, "Change property");
                                wcChild->setPropertyValue(SUI::ObjectPropertyTypeEnum::Checked, "false");
                                UndoHandler::instance()->finishUndoInfo(wcChildState, wcChild);
                                wcChildStateList.append(wcChildState);
                            }
                            if ( wcChildStateList.count() != 0 ) {
                                wcStateList.append(wcChildStateList);
                            }
                            wcParent->updatePixmap();
                        }
                    }
                }
                UndoHandler::instance()->finishUndoInfo(wcState, currentWidget);
                wcStateList.append(wcState);
            }
        }
    }
    UndoHandler::instance()->addToUndoGroup(wcStateList);
    Model::instance()->setDataChanged(true);

}

/*!
 *  FUNCTION    :   onPropertyIndexedValueChanged
 *  PARAMETERS  :   QString typeString The property type.
 *                  QString indexedValue The combined index, value of the IndexedValue.
 *
 *  This is a SLOT function, connected to the ui->m_PropertyTW
 *  propertyIndexedValueChanged SIGNAL. This SIGNAL is emitted whenever the value
 *  of a SpinBox in the Property Table Widget, which holds an IndexedValue,
 *  changes.
 */
void MainWindow::onPropertyIndexedValueChanged(QString typeString, QString indexedValue) {

    WidgetController *widgetController = Model::instance()->getCurrentWidget();

    // if the widgetController exists and the indexedValue is valid
    if (( widgetController != NULL ) && ( !indexedValue.isEmpty() ) && ( indexedValue.split(",").size() == 2 )) {
        // get the property type and undo handler WidgetState
        SUI::ObjectPropertyTypeEnum::Type propertyType = SUI::ObjectPropertyTypeEnum::fromString(typeString.toStdString());
        WidgetState  *widgetState = UndoHandler::instance()->getNewUndoInfo(widgetController, ACT_PROPERTY, "Change property");

        // get the existing values
        QStringList existingValues = widgetController->getPropertyValue(propertyType).split(';');

        // make a map to sort existing values and add new value
        QMap<int,QString> indexedValues; // key is int to have the map correctly sorted, i.e. 1,2,...,10,11,... and not 1,10,2,... By default, QMap is ordered by key.
        foreach (const QString &existingValue, existingValues) {
            if (existingValue.split(',').size() == 2) {
                indexedValues.insert(existingValue.split(',')[0].toInt(),existingValue.split(',')[1]);
            }
        }

        // add new value
        indexedValues.insert(indexedValue.split(',')[0].toInt(),indexedValue.split(',')[1]);

        // convert the map to string
        QStringList newList;
        foreach (int index, indexedValues.keys())
            newList.append(QString("%1,%2").arg(index).arg(indexedValues.value(index)));

        // set the property
        widgetController->setPropertyValue(propertyType, newList.join(";"));

        UndoHandler::instance()->finishUndoInfo(widgetState, widgetController);
        UndoHandler::instance()->addToUndoGroup(widgetState);
    }
    Model::instance()->setDataChanged(true);

}

/*!
 *  FUNCTION    :   onGetNewDoubleValue
 *  PARAMETERS  :   QString key
 *                      The property name.
 *                  QString value
 *                      The combined index, value of the IndexedValue.
 *  RETURN      :   void
 *
 *  This is a SLOT function, connected to the ui->m_PropertyTW
 *  getNewDoubleValue SIGNAL. This SIGNAL is emitted whenever the value
 *  of a SpinBox in the Property Table Widget, which holds the index of the key,
 *  changes. This function calls the getIndexedValue function to retrieve the
 *  value of the given index. Then the PropertyEditor is notified, so it can
 *  update the appropriate value box.
 */
void MainWindow::onGetNewDoubleValue(QString key, QString value)
{
    WidgetController *curWidg = Model::instance()->getCurrentWidget();
    if ( curWidg != NULL ) {
        QString retStr = curWidg->getIndexedValue(key, value);
        if (!retStr.isEmpty()) {
            emit sendDoubleValue(key, retStr);
        }
    }
}

/*!
 *  FUNCTION    :   fillObjectTree
 *  PARAMETERS  :   const QString &id
 *                      If not empty, this is the id of the newly added widget.
 *  RETURN      :   void
 *
 *  This is a SLOT function, connected to the newWidget() SIGNAL. This function
 *  builds the object tree view with all objects in the Form Editor.
 */
void MainWindow::fillObjectTree()
{
    mStandardModel->clear();
    QStandardItem *rootNode = mStandardModel->invisibleRootItem();
    StdItemList rootList;
    for (int ind = 0; ind < ui->frmFormEditor->childList().size(); ++ind)
    {
        WidgetController *controller = ui->frmFormEditor->childList()[ind];
        QStandardItem *item = new QStandardItem(controller->getId());
        rootList.append(item);
        addItemToObjectTree(item, controller);
    }

    for (StdItemList::iterator it = rootList.begin(); it != rootList.end(); ++it)
    {
        rootNode->appendRow((*it));
    }
    ui->m_ObjectTV->setModel(mStandardModel);
    ui->m_ObjectTV->expandAll();

    connect(ui->m_ObjectTV->selectionModel(), SIGNAL(selectionChanged(const QItemSelection &, const QItemSelection &)),
            this, SLOT(selectionChangedSlot(const QItemSelection &, const QItemSelection &)));
}

/*!
 *  FUNCTION    :   addItemToObjectTree
 *  PARAMETERS  :   QStandardItem *parentItem
 *                  WidgetController *pWidget
 *  RETURN      :   void
 *
 *  This function is being called by fillObjectTree().
 */
void MainWindow::addItemToObjectTree(QStandardItem *parentItem, WidgetController *pWidget) {
    StdItemList childList;
    for (int ind = 0; ind < pWidget->childList().size(); ++ind) {
        WidgetController *childController = pWidget->childList()[ind];
        QStandardItem *item = new QStandardItem(childController->getId());
        childList.append(item);
        parentItem->appendRow(item);
        addItemToObjectTree(item, childController);
    }
}

/*!
 *  FUNCTION    :   selectionChangedSlot
 *  PARAMETERS  :   const QItemSelection &newSelection
 *                      Not being used.
 *                  const QItemSelection &oldSelection
 *                      Not being used.
 *  RETURN      :   void
 *
 *  This is a SLOT function, connected to the QItemSelectionModel selectionChanged
 *  SIGNAL and is emitted whenever the user clicks on an item in the Object Tree
 *  View. This will show the newly selected object with its selection rectangles.
 */
void MainWindow::selectionChangedSlot(const QItemSelection &newSelection, const QItemSelection &oldSelection)
{
    Q_UNUSED(newSelection);
    Q_UNUSED(oldSelection);
    QString idStr = ui->m_ObjectTV->selectionModel()->currentIndex().data(Qt::DisplayRole).toString();
    Model::instance()->getWidgetController(idStr)->showProperTabPages();
    Model::instance()->selectNewWidget(idStr);
    Model::instance()->setNewSelected(Model::instance()->getWidgetController(idStr));
    Model::instance()->getWidgetController(idStr)->tabReorder();
}

/*!
 *  FUNCTION    :   SetSelection
 *  PARAMETERS  :   const QString &id
 *  RETURN      :   void
 *
 *  This is a SLOT function, connected to the setNewObjectTreeSelection SIGNAL,
 *  which is being called by ModelHandler::sendNewObjectTreeSelection(). This
 *  function should be called whenever the user or the code, selects a different
 *  object. SetSelection() will select the appropriate item in the Object Tree
 *  View.
 */
void MainWindow::setSelection(WidgetController *ddwidg)
{
    onDisableShowProperties(__FUNCTION__);

    QString id = ddwidg ? ddwidg->getId() : QString();
    QStandardItem   *rootNode = mStandardModel->invisibleRootItem();
    QStandardItem   *foundItem = searchItem(rootNode, id);
    if ( foundItem != NULL )
    {
        ui->m_ObjectTV->setCurrentIndex(foundItem->index());
        QItemSelection  selection(foundItem->index(), foundItem->index());
        ui->m_ObjectTV->selectionModel()->select(selection, QItemSelectionModel::Select);
        ui->m_ObjectTV->scrollTo(ui->m_ObjectTV->selectionModel()->currentIndex(), QAbstractItemView::PositionAtCenter);
    }
    else
    {
        ui->m_ObjectTV->clearSelection();
    }
    onEnableShowProperties(__FUNCTION__);
}

/*!
 *  FUNCTION    :   searchItem
 *  PARAMETERS  :   QStandardItem *parentItem
 *                  const QString &id
 *  RETURN      :   QStandardItem*
 *
 *  This function is being called by SetSelection() and searches the Object Tree
 *  View for the Item with the given id.
 */
QStandardItem *MainWindow::searchItem(QStandardItem *parentItem, const QString &id)
{
    QStandardItem   *returnItem = NULL;
    QStandardItem   *childItem = parentItem->child(0);

    for (int i = 0; childItem; ++i)
    {
        if (id == childItem->data(Qt::DisplayRole).toString())
        {
            return childItem;
        }
        if ((returnItem = searchItem(childItem, id)) != NULL)
        {
            return returnItem;
        }
        childItem = parentItem->child(i);
    }
    return returnItem;
}

/*!
 *  FUNCTION    :   onCustomContextMenuRequest
 *  PARAMETERS  :   QPoint point
 *  RETURN      :   void
 *
 *  This is a SLOT function, connected to the customContextMenuRequested SIGNAL,
 *  which is emitted whenever the user clicks the right mouse button. This
 *  function displays a popup menu with a Copy and Paste QAction.
 *  The algorithm which decides which menu items are to be displayed, is not
 *  very neat. Could do with some rework.
 *  Because when right-clicking on a User Control, the underlying User Controls
 *  child gets selected, we have to undo that and make the User Control the
 *  selected widget again.
 */

//FIXME this is completely wrong, QAction should not be instantiated on every contextmenurequest, instead they should be instantiated in the constructor and be unique.
void MainWindow::onCustomContextMenuRequest(QPoint point)
{
    QMenu   widgetMenu;
    WidgetController *curWidget = Model::instance()->getCurrentWidget();
    QPoint globalPos = mapToGlobal(point);

    WidgetController *RticWidget = dynamic_cast<WidgetController *>(childAt(point));
    if (RticWidget != NULL)
    {
        while (!RticWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::UserControl).isEmpty() && (RticWidget->getObjectType() != SUI::ObjectType::UserControl))
        {
            Model::instance()->swapInSelectionList(RticWidget, RticWidget->getParent());
            RticWidget = RticWidget->getParent();
        }
        if ( ( !RticWidget->isWidgetSelector() ) && ( ((RticWidget->getParent() != NULL) && (!RticWidget->getParent()->isWidgetSelector())) ) )
        {
            if (Model::instance()->getSelectionList().count() == 1)
            {
                Model::instance()->setNewSelected(RticWidget);
            }
            else
            {
                bool found = false;
                foreach(WidgetController * wcChild, Model::instance()->getSelectionList())
                {
                    if (wcChild == RticWidget)
                    {
                        found = true;
                        break;
                    }
                }
                if (!found)
                {
                    Model::instance()->setNewSelected(RticWidget);
                }
            }
            QAction *alignLeft = new QAction("Align Left", this);
            QAction *alignRight = new QAction("Align Right", this);
            QAction *alignTop = new QAction("Align Top", this);
            QAction *alignBottom = new QAction("Align Bottom", this);
            QAction *layoutHorizontal = new QAction("Layout Horizontally", this);
            QAction *layoutVertical = new QAction("Layout Vertically", this);
            QAction *spaceHorizontally = new QAction("Space evenly Horizontally", this);
            QAction *spaceVertically = new QAction("Space evenly Vertically", this);
            QAction *centerHorizontal = new QAction("Center Horizontally", this);
            QAction *centerVertical = new QAction("Center Vertically", this);
            QAction *joinUCtrlAct = new QAction("Make User Control", this);
            QAction *splitUCtrlAct = new QAction("Split User Control", this);
            QAction *insertRowsAct = new QAction("Insert Rows", this);
            QAction *insertColumnsAct = new QAction("Insert Columns", this);
            QAction *removeRowsAct = new QAction("Remove Rows", this);
            QAction *removeColumnsAct = new QAction("Remove Columns", this);
            QAction *fillTableAct = new QAction("Fill Table", this);
            QAction *clearTableAct = new QAction("Clear Table", this);
            Q_UNUSED(fillTableAct);

            widgetMenu.setStyleSheet(QString::fromStdString(SUI::StyleSheet::getInstance()->getStyleSheet()));

            if (( curWidget != NULL ) && ( curWidget->getObjectType() == SUI::ObjectType::TabWidget ))
            {
                widgetMenu.addSeparator();
                widgetMenu.addAction(ui->actionAddTabPage);
                widgetMenu.addSeparator();
                widgetMenu.addAction(ui->actionMoveNextAct);
                widgetMenu.addAction(ui->actionMovePrevAct);
                widgetMenu.addAction(ui->actionDeleteAct);
                widgetMenu.addSeparator();

                int dTabCount = dynamic_cast<SUI::TabWidgetImpl *>(curWidget->getBaseWidget())->getWidget()->count();
                int dCurInd = dynamic_cast<SUI::TabWidgetImpl *>(curWidget->getBaseWidget())->getCurrentIndex();
                if (dCurInd == (dTabCount - 1))
                {
                    ui->actionMoveNextAct->setEnabled(false);
                }
                else
                {
                    ui->actionMoveNextAct->setEnabled(true);
                }
                if (dCurInd == 0)
                {
                    ui->actionMovePrevAct->setEnabled(false);
                }
                else
                {
                    ui->actionMovePrevAct->setEnabled(true);
                }
                if (dTabCount == 1)
                {
                    ui->actionDeleteAct->setEnabled(false);
                }
                else
                {
                    ui->actionDeleteAct->setEnabled(true);
                }
            }

            if ((RticWidget != Model::instance()->getMainTabWidget()) && (Model::instance()->hasSelectedItems() || Model::instance()->hasCopiedWidgetList()))
            {
                widgetMenu.addSeparator();
                widgetMenu.addAction(ui->action_Copy);
                widgetMenu.addAction(ui->action_Paste);
                widgetMenu.addSeparator();
                if (Model::instance()->hasSelectionList())
                {
                    if (Model::instance()->selectionHasSameParent("rbbRight"))
                    {
                        widgetMenu.addAction(layoutVertical);
                    }
                    else if ((!Model::instance()->selectionHasSameParent("rbbBottom")) && (!Model::instance()->selectionHasSameParent("rbbStatus")))
                    {
                        widgetMenu.addAction(alignLeft);
                        widgetMenu.addAction(alignRight);
                        widgetMenu.addAction(alignTop);
                        widgetMenu.addAction(alignBottom);
                        widgetMenu.addAction(layoutHorizontal);
                        widgetMenu.addAction(layoutVertical);
                        widgetMenu.addAction(spaceHorizontally);
                        widgetMenu.addAction(spaceVertically);
                        widgetMenu.addSeparator();
                        widgetMenu.addAction(joinUCtrlAct);
                    }
                }
                else if (( curWidget != NULL ) && (curWidget->getId() != "rbbBottom") && (curWidget->getId() != "rbbStatus"))
                {
                    if (curWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable).toLower() != "false")
                    {
                        if (curWidget->getObjectType() == SUI::ObjectType::UserControl || curWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::UserControl) != "")
                        {
                            widgetMenu.addAction(splitUCtrlAct);
                        }
                        else
                        {
                            widgetMenu.addAction(joinUCtrlAct);
                        }
                        widgetMenu.addSeparator();
                        widgetMenu.addAction(ui->actionTo_Forground);
                        widgetMenu.addAction(ui->actionTo_Background);
                        widgetMenu.addAction(ui->actionForward);
                        widgetMenu.addAction(ui->actionBackward);
                        widgetMenu.addSeparator();
                        if (curWidget->getObjectType() == SUI::ObjectType::TableWidget)
                        {
                            widgetMenu.addSeparator();
                            widgetMenu.addAction(insertRowsAct);
                            widgetMenu.addAction(insertColumnsAct);
                            widgetMenu.addAction(removeRowsAct);
                            widgetMenu.addAction(removeColumnsAct);
                            widgetMenu.addSeparator();
#ifdef QT_DEBUG
                            widgetMenu.addAction(fillTableAct);
#endif
                            widgetMenu.addAction(clearTableAct);
                            widgetMenu.addSeparator();
                        }
                    }
                    if (curWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable).toLower() != "false")
                    {
                        widgetMenu.addAction(centerHorizontal);
                    }
                    if ((curWidget->getParent()->getId() != "rbbBottom") &&
                            (curWidget->getParent()->getId() != "rbbStatus") &&
                            (curWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable).toLower() != "false"))
                    {
                        widgetMenu.addAction(centerVertical);
                    }
                }
                QAction *selectedAct = widgetMenu.exec(globalPos);
                if (selectedAct ==  alignLeft)
                {
                    Model::instance()->alignLeft();
                }
                else if (selectedAct ==  alignRight)
                {
                    Model::instance()->alignRight();
                }
                else if (selectedAct ==  alignTop)
                {
                    Model::instance()->alignTop();
                }
                else if (selectedAct ==  alignBottom)
                {
                    Model::instance()->alignBottom();
                }
                else if (selectedAct ==  layoutHorizontal)
                {
                    Model::instance()->layoutHorizontally();
                }
                else if (selectedAct ==  layoutVertical)
                {
                    Model::instance()->layoutVerically();
                }
                else if (selectedAct == spaceHorizontally)
                {
                    Model::instance()->spaceHorizontally();
                }
                else if (selectedAct == spaceVertically)
                {
                    Model::instance()->spaceVerically();
                }
                else if (selectedAct ==  centerHorizontal)
                {
                    Model::instance()->centerHorizontally();
                }
                else if (selectedAct ==  centerVertical)
                {
                    Model::instance()->centerVerically();
                }
                else if (selectedAct == insertRowsAct)
                {
                    onDisableShowProperties(__FUNCTION__);
                    curWidget->onCustomContextItemMenu("insertRowsAct");
                    onEnableShowProperties(__FUNCTION__);
                }
                else if (selectedAct ==  clearTableAct)
                {
                    onDisableShowProperties(__FUNCTION__);
                    curWidget->onCustomContextItemMenu("clearTableAct");
                    onEnableShowProperties(__FUNCTION__);
                }
                else if (selectedAct ==  fillTableAct)
                {
                    onDisableShowProperties(__FUNCTION__);
                    curWidget->onCustomContextItemMenu("fillTableAct");
                    onEnableShowProperties(__FUNCTION__);
                }
                else if (selectedAct ==  insertColumnsAct)
                {
                    onDisableShowProperties(__FUNCTION__);
                    curWidget->onCustomContextItemMenu("insertColumnsAct");
                    onEnableShowProperties(__FUNCTION__);
                }
                else if (selectedAct ==  removeRowsAct)
                {
                    onDisableShowProperties(__FUNCTION__);
                    curWidget->onCustomContextItemMenu("removeRowsAct");
                    onEnableShowProperties(__FUNCTION__);
                }
                else if (selectedAct ==  removeColumnsAct)
                {
                    onDisableShowProperties(__FUNCTION__);
                    curWidget->onCustomContextItemMenu("removeColumnsAct");
                    onEnableShowProperties(__FUNCTION__);
                }
                else if (selectedAct ==  joinUCtrlAct)
                {
                    QString nwID = Model::instance()->createNewId("uct");
                    UserControlDialog   *UCtrlDia = new UserControlDialog(nwID);
                    UCtrlDia->setStyleSheet(QString::fromStdString(SUI::StyleSheet::getInstance()->getStyleSheet()));
                    if (UCtrlDia->exec() == QDialog::Accepted)
                    {
                        QString name = UCtrlDia->getUserCtrlName();
                        if (UCtrlDia->idChecked())
                        {
                            nwID = UCtrlDia->getId();
                        }
                        else
                        {
                            nwID.clear();
                        }
                        newUserControl(name, nwID);
                    }
                    UCtrlDia->deleteLater();
                }
                else if (selectedAct ==  splitUCtrlAct)
                {
                    splitUserControl(curWidget);
                }
                alignLeft->deleteLater();
                alignRight->deleteLater();
                alignTop->deleteLater();
                alignBottom->deleteLater();
                layoutHorizontal->deleteLater();
                layoutVertical->deleteLater();
                centerHorizontal->deleteLater();
                centerVertical->deleteLater();
                joinUCtrlAct->deleteLater();
                splitUCtrlAct->deleteLater();
            }
            else if (( curWidget != NULL ) && ( curWidget->getObjectType() == SUI::ObjectType::TabWidget ))
            {
                widgetMenu.exec(globalPos);
            }

            delete alignLeft;
            delete alignRight;
            delete alignTop;
            delete alignBottom;
            delete layoutHorizontal;
            delete layoutVertical;
            delete spaceHorizontally;
            delete spaceVertically;
            delete centerHorizontal;
            delete centerVertical;
            delete joinUCtrlAct;
            delete splitUCtrlAct;
            delete insertRowsAct;
            delete insertColumnsAct;
            delete removeRowsAct;
            delete removeColumnsAct;
            delete fillTableAct;
            delete clearTableAct;
        }
        else if (( RticWidget->getParent() != NULL ) && ( RticWidget->getParent()->isWidgetSelector() ))
        {
            QAction *removeUCtrlAction = new QAction("Remove from UserControl Selector", this);
            widgetMenu.setStyleSheet(QString::fromStdString(SUI::StyleSheet::getInstance()->getStyleSheet()));
            widgetMenu.addAction(removeUCtrlAction);
            QAction *selectedAction = widgetMenu.exec(globalPos);
            if (selectedAction == removeUCtrlAction)
            {
                removeUCtrlFromSelector(RticWidget);
            }
            delete removeUCtrlAction;
        }
    }
    else if (( curWidget != NULL ) && ( this->childAt(point)->parentWidget() == ui->m_ObjectTV )
             && ( curWidget->supportsChildren() )
             && ( curWidget->getChildren()->count() > 0 ))
    {
        widgetMenu.addAction(ui->actionCollapseAll);
        widgetMenu.addAction(ui->actionExpandAll);
        widgetMenu.exec(globalPos);
    }
}

/*!
 *  FUNCTION    :   addMainTabWidget
 *  PARAMETERS  :
 *  RETURN      :   void
 *
 *  This function is being called by the constructor, because the FormEditor
 *  should always have the Main Tab Widget. The size of the Main Tab Widget
 *  depends on the size of the FormEditor.
 */
void MainWindow::addMainTabWidget() {
    WidgetDefinition widgetDefinition;
    widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::ObjectType, QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::TabWidget)));
    widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable, "false");
    widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::Sizeable, "false");
    widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, "0");
    widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, "0");
    widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, "1024");
    widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, "768");

    WidgetController *tabWidgetController = NULL;
    WidgetController *splitter = Model::instance()->getWidgetController("splFormStatus");

    widgetDefinition.setSelected(true);
    if ( splitter != NULL ) {
        tabWidgetController = widgetDefinition.addToWidget(splitter, true);
        splitter->addSplitterWidget(tabWidgetController);
    }
    else {
        tabWidgetController = widgetDefinition.addToWidget(ui->frmFormEditor, true);
        tabWidgetController->setWidgetMode(WidgetController::RootWidgetMode);
    }
    Model::instance()->setTopWidget(tabWidgetController);
    tabWidgetController->addTabPage("Default");
    tabWidgetController->updatePixmap();

    Model::instance()->setDataChanged(true);

}

/*!
 *  FUNCTION    :   rightButtonBar
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This function is being called by the constructor, because if the FormEditor
 *  has a Right Button Bar, it should be constructed immediately.
 */
void MainWindow::rightButtonBar()
{
    WidgetController   *rbbWCWidg = Model::instance()->getRightButtonBar();
    if (!ui->frmFormEditor->hasRightButtonBar())
    {
        if ( rbbWCWidg != NULL )
        {
            Model::instance()->removeWidget(rbbWCWidg->widgetGUID());
            ui->frmFormEditor->removeChild(rbbWCWidg);
            rbbWCWidg->deleteLater();
            rbbWCWidg = NULL;
        }
    }
    else
    {
        if ( rbbWCWidg == NULL )
        {
            WidgetDefinition widgetDefinition;
            widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::ObjectType, QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::ButtonBar)));
            widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable, "false");
            widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::Sizeable, "false");
            widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, "0");
            widgetDefinition.setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, "0");
            widgetDefinition.setSelected(true);
            rbbWCWidg = widgetDefinition.addToWidget(ui->frmFormEditor, true);
            rbbWCWidg->setWidgetMode(WidgetController::RootWidgetMode);
            rbbWCWidg->setId("rbbRight");
            rbbWCWidg->updatePixmap();
            Model::instance()->setRightButtonBar(rbbWCWidg);
        }
    }
}

/*!
 *  FUNCTION    :   bottomButtonBar
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This function is being called by the constructor, because if the FormEditor
 *  has a Bottom Button Bar, it should be constructed immediately. This Button
 *  should always exist.
 */
void MainWindow::bottomButtonBar()
{
    if (ui->frmFormEditor->hasBottomButtonBar())
    {
        WidgetDefinition    WCInfo;
        WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::ObjectType, QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::ButtonBar)));
        WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable, "false");
        WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::Sizeable, "false");
        WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, "0");
        WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, "0");
        WCInfo.setSelected(true);
        WidgetController   *bbbWCWidg = WCInfo.addToWidget(ui->frmFormEditor, true);
        bbbWCWidg->setWidgetMode(WidgetController::RootWidgetMode);
        bbbWCWidg->setId("rbbBottom");
        Model::instance()->setBottomButtonBar(bbbWCWidg);

        WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, QString::number(30));
        WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, QString::number(200));
        WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::ObjectType, QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::Button)));
        WidgetController    *closeButton = WCInfo.addToWidget(bbbWCWidg, true);
        closeButton->setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, "Close");
        closeButton->setId("btnClose");
        Model::instance()->setCloseButton(closeButton);

        WidgetController    *helpButton = WCInfo.addToWidget(bbbWCWidg, true);
        helpButton->setPropertyValue(SUI::ObjectPropertyTypeEnum::Text, "Help");
        helpButton->setId("btnHelp");
        Model::instance()->setHelpButton(helpButton);

        bbbWCWidg->updatePixmap();
    }
    Model::instance()->setDataChanged(true);

}

/*!
 *  FUNCTION    :   statusBar
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This function is being called by the constructor, because if the FormEditor
 *  has a Status Button Bar, it should be constructed immediately.
 *
 *  Release 5:
 *  The statusbar has been removed and now there is a Status Text Area. For old
 *  xml files, a check for statusBar is done.
 */
void MainWindow::addStatusBar()
{
    WidgetController    *staWCWidg = Model::instance()->getStatusTextArea();

    if (!ui->frmFormEditor->hasStatusBar())
    {
        if ( staWCWidg != NULL )
        {
            Model::instance()->removeWidget(staWCWidg->widgetGUID());
            ui->frmFormEditor->removeChild(staWCWidg);
            staWCWidg->deleteLater();
            staWCWidg = NULL;
        }
    }
    else
    {
        WidgetController    *SplWidget = Model::instance()->getWidgetController("splFormStatus");
        if ( SplWidget != NULL )
        {
            if ( staWCWidg == NULL )
            {
                WidgetDefinition    WCInfo;
                WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::ObjectType, QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::TextArea)));
                WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, QString::number(30));
                WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, QString::number(200));
                WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, "10");
                WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, "10");
                WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::AutoScroll, "true");
                WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::ReadOnly, "true");
                WidgetController    *stlWCWidg = WCInfo.addToWidget(SplWidget, true);
                SplWidget->addSplitterWidget(stlWCWidg);
                stlWCWidg->setId("txaStatus");
                Model::instance()->setStatusTextArea(stlWCWidg);
            }
            else
            {
                WidgetController    *wcOldparent = staWCWidg->getParent();
                if (( SplWidget != NULL ) && (wcOldparent != SplWidget))
                {
                    WidgetDefinition    newDef;
                    staWCWidg->acceptVisitor(newDef);
                    WidgetController    *newTextArea = newDef.addToWidget(SplWidget, false);
                    Model::instance()->setStatusTextArea(newTextArea);
                    wcOldparent->removeChild(staWCWidg);
                    Model::instance()->removeWidget(staWCWidg->widgetGUID());
                    staWCWidg->deleteLater();
                    SplWidget->addSplitterWidget(newTextArea);
                }
            }
        }
    }
    Model::instance()->setDataChanged(true);

}

/*!
 *  FUNCTION    :   statusbarSplitter
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This function is being called by onNew(). It wrappes calls to
 *  addStatusbarSplitter() and removeStatusbarSplitter().
 */
void MainWindow::statusbarSplitter()
{
    addStatusbarSplitter();
    removeStatusbarSplitter();
    Model::instance()->setDataChanged(true);

}

/*!
 *  FUNCTION    :   addStatusbarSplitter
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This function creates the Splitter widget, if appropriate, which contains
 *  the Main Tab Widget and Statusbar Widget.
 */
void MainWindow::addStatusbarSplitter()
{
    if ( Model::instance()->getStatusBar() == NULL )
    {
        if (( ui->frmFormEditor->hasStatusBar() ) && ( Model::instance()->getWidgetController("splFormStatus") == NULL ))
        {
            WidgetDefinition    WCInfo;
            WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::ObjectType, QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::Splitter)));
            WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable, "false");
            WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::Sizeable, "false");
            WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, "0");
            WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, "0");
            WidgetController    *splWCWidg = WCInfo.addToWidget(ui->frmFormEditor, true);
            splWCWidg->setWidgetMode(WidgetController::RootWidgetMode);
            splWCWidg->setId("splFormStatus");
            splWCWidg->getBaseWidget()->setPropertyReadonly(SUI::ObjectPropertyTypeEnum::XPos);
            splWCWidg->getBaseWidget()->setPropertyReadonly(SUI::ObjectPropertyTypeEnum::YPos);
        }
    }
}

/*!
 *  FUNCTION    :   onAddStandardButtonArea
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This is a SLOT function which is connected to the
 *  ui->actionAdd_Standard_Button_area SIGNAL. It adds the Standard Button area
 *  to the Form Editor.
 */
void MainWindow::onAddStandardButtonArea()
{
    int dHeight = ui->frmFormEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt() + ui->frmFormEditor->bottomButtonBarHeight() + (2 * Model::cmInnerMargin) + (2 * Model::cmOuterMargin);
    ui->frmFormEditor->setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, QString::number(dHeight));
    ui->frmFormEditor->setPropertyValue(SUI::ObjectPropertyTypeEnum::HasBottomButtonBar, "true");
    ui->frmFormEditor->setGeometry(ui->frmFormEditor->pos().x(), ui->frmFormEditor->pos().y(),
                                   ui->frmFormEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt(),
                                   ui->frmFormEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt());
    ui->frmFormEditor->setFixedSize(ui->frmFormEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt(),
                                    ui->frmFormEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt());
    bottomButtonBar();
    handleFormLayout();
    ui->actionAdd_Standard_Button_area->setDisabled(true);

    Model::instance()->setDataChanged(true);

}

/*!
 *  FUNCTION    :   removeStatusbarSplitter
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This function removes the Splitter widget, if appropriate, which contains
 *  the Main Tab Widget and Statusbar Widget.
 *
 *  Release 5:
 *  Because old XML files should still be handled correctly, a check for the
 *  old statusBar is implemented.
 */
void MainWindow::removeStatusbarSplitter()
{
    if (!ui->frmFormEditor->hasStatusBar())
    {
        WidgetController    *splWidgContr = Model::instance()->getWidgetController("splFormStatus");
        if ( splWidgContr != NULL )
        {
            Model::instance()->removeWidget(splWidgContr->widgetGUID());
            ui->frmFormEditor->removeChild(splWidgContr);
            splWidgContr->deleteLater();
        }

        //  For old times sake
        WidgetController    *stbWCWidg = Model::instance()->getStatusBar();
        if ( stbWCWidg != NULL )
        {
            Model::instance()->removeWidget(stbWCWidg->widgetGUID());
            ui->frmFormEditor->removeChild(stbWCWidg);
            stbWCWidg->deleteLater();
            stbWCWidg = NULL;

        }
    }
    Model::instance()->setDataChanged(true);

}

/*!
 *  FUNCTION    :   handleFormLayout
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This function handles the size and position of the Main Tab Widget, the
 *  Button Bars and the mandatory buttons/labels on it.
 *
 *  Release 10:
 *  Since this version, the Main TabWidget is not mandatory anymore.
 *  So the (newly introduced) TopWidget is either the Main TabWidget or a
 *  RticWidgetPage.
 */
void MainWindow::handleFormLayout()
{
    int dFormHeight = ui->frmFormEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt();
    int dFormWidth = ui->frmFormEditor->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt();

    //  TopWidget. Either the MainTabWidget or the WidgetPage
    int dX = Model::cmOuterMargin;
    int dY = Model::cmOuterMargin;
    int dHeight = dFormHeight - Model::cmInnerMargin - ui->frmFormEditor->statusBarHeight() -
            ((ui->frmFormEditor->statusBarHeight()) ? Model::cmInnerMargin : 0) - ui->frmFormEditor->bottomButtonBarHeight() - (Model::cmOuterMargin * 2);
    int tabHeight = dHeight;
    int dWidth = dFormWidth - ui->frmFormEditor->rightButtonBarWidth() - (Model::cmInnerMargin * 2) - (Model::cmOuterMargin * 2);
    WidgetController    *WCWidget = Model::instance()->getTopWidget();
    if ( WCWidget != NULL )
    {
        WCWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, QString::number(dX));
        WCWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, QString::number(dY));
        WCWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, QString::number(dHeight));
        WCWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, QString::number(dWidth));
    }
    WCWidget->updatePixmap();

    //  Right Button Bar
    if (ui->frmFormEditor->hasRightButtonBar())
    {
        dX = dFormWidth - ui->frmFormEditor->rightButtonBarWidth() - Model::cmOuterMargin;
        dY = Model::cmOuterMargin;
        dHeight = dFormHeight - ui->frmFormEditor->bottomButtonBarHeight() - Model::cmInnerMargin - (Model::cmOuterMargin * 2);
        dWidth = ui->frmFormEditor->rightButtonBarWidth();
        WCWidget = Model::instance()->getRightButtonBar();
        if ( WCWidget != NULL )
        {
            WCWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, QString::number(dX));
            WCWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, QString::number(dY));
            WCWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, QString::number(dHeight));
            WCWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, QString::number(dWidth));
            WCWidget->updatePixmap();
        }
    }

    // Bottom Button Bar
    dX = Model::cmOuterMargin;
    dY = dFormHeight - ui->frmFormEditor->bottomButtonBarHeight() - Model::cmOuterMargin;
    dHeight = ui->frmFormEditor->bottomButtonBarHeight();
    dWidth = dFormWidth - (Model::cmOuterMargin * 2);
    WCWidget = Model::instance()->getBottomButtonBar();
    if ( WCWidget != NULL )
    {
        WCWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, QString::number(dX));
        WCWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, QString::number(dY));
        WCWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, QString::number(dHeight));
        WCWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, QString::number(dWidth));
        WCWidget->updatePixmap();
    }

    //  Close Button
    dX = Model::cmInnerMargin;
    dY = Model::cmInnerMargin;
    WCWidget = Model::instance()->getCloseButton();
    if ( WCWidget != NULL )
    {
        WCWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, QString::number(dX));
        WCWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, QString::number(dY));
        WCWidget->updatePixmap();
    }

    //  Help Button;
    dX = dWidth - 200 - 10;
    dY = Model::cmInnerMargin;
    WCWidget = Model::instance()->getHelpButton();
    if ( WCWidget != NULL )
    {
        WCWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, QString::number(dX));
        WCWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, QString::number(dY));
        WCWidget->updatePixmap();
    }

    // Status Bar
    if (ui->frmFormEditor->hasStatusBar())
    {
        dX = Model::cmOuterMargin;
        dY = dFormHeight - Model::cmOuterMargin - ui->frmFormEditor->bottomButtonBarHeight() - Model::cmInnerMargin - ui->frmFormEditor->statusBarHeight();
        dHeight = ui->frmFormEditor->statusBarHeight();
        dWidth = dFormWidth - ui->frmFormEditor->rightButtonBarWidth() - Model::cmInnerMargin - (Model::cmOuterMargin * 2);

        //  Status TextArea
        dWidth -= (Model::cmInnerMargin * 2);
        WCWidget = Model::instance()->getStatusTextArea();
        if ( WCWidget != NULL )
        {
            WCWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, QString::number(dX));
            WCWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, QString::number(dY));
            WCWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, QString::number(dHeight));
            WCWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, QString::number(dWidth));
            WCWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable, "false");
            WCWidget->updatePixmap();
        }
    }

    //  Splitter between Form Editor and Status Bar
    WCWidget = Model::instance()->getWidgetController("splFormStatus");
    if ( WCWidget != NULL )
    {
        dHeight = dFormHeight - ui->frmFormEditor->bottomButtonBarHeight();
        dWidth = dFormWidth - (ui->frmFormEditor->hasRightButtonBar() ? ui->frmFormEditor->rightButtonBarWidth() : 0);
        WCWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, QString::number(0));
        WCWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, QString::number(0));
        WCWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, QString::number(dHeight));
        WCWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, QString::number(dWidth));

        QList<int>  sizeList;
        sizeList << tabHeight << 50;
        dynamic_cast<SUI::SplitterImpl *>(WCWidget->getBaseWidget())->setSizes(sizeList);
        WCWidget->updatePixmap();
    }
    ui->frmFormEditor->updatePixmap();
//    Model::instance()->setDataChanged(true);
}

/*!
 *  FUNCTION    :   checkMaintabwidgetParent
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This function checks whether a splitter widget should be added or removed.
 *  It then calls changeMaintabwidgetParent() with the new parent for the
 *  Main Tabwidget, if neccessary.
 *
 *  Release 10:
 *  Since this version, the Main TabWidget is not mandatory anymore.
 *  So the (newly introduced) TopWidget is either the Main TabWidget or a
 *  RticWidgetPage.
 */
void MainWindow::checkMaintabwidgetParent()
{
    WidgetController    *wcSplitter = Model::instance()->getWidgetController("splFormStatus");
    WidgetController    *wcOldTopWidget = Model::instance()->getTopWidget();
    WidgetController    *wcOldParent = wcOldTopWidget->getParent();

    if (ui->frmFormEditor->hasStatusBar())
    {
        if (wcOldParent != wcSplitter)
        {
            if ( wcSplitter != NULL )
            {
                changeMaintabwidgetParent(wcSplitter);
                wcSplitter->addSplitterWidget(Model::instance()->getTopWidget());
                Model::instance()->getTopWidget()->setWidgetMode(WidgetController::ParentWidgetMode);
            }
        }
    }
    else
    {
        if (wcOldParent != ui->frmFormEditor)
        {
            changeMaintabwidgetParent(ui->frmFormEditor);
            if ( Model::instance()->getMainTabWidget() != NULL )
            {
                Model::instance()->getMainTabWidget()->setWidgetMode(WidgetController::RootWidgetMode);
            }
        }
    }
    Model::instance()->setDataChanged(true);

}

/*!
 *  FUNCTION    :   changeMaintabwidgetParent
 *  PARAMETERS  :   WidgetController *newParent
 *                      The new parent for the Main TabWidget.
 *  RETURN      :   void
 *
 *  This function adds the Main TabWidget to the new parent, being either the
 *  Splitter Widget or the frmFormEditor. It removes the Main TabWidget from
 *  the old parents children list.
 *
 *  Release 10:
 *  Since this version, the Main TabWidget is not mandatory anymore.
 *  So the (newly introduced) TopWidget is either the Main TabWidget or a
 *  RticWidgetPage.
 */
void MainWindow::changeMaintabwidgetParent(WidgetController *newParent)
{
    WidgetController *wcOldTopWidget = Model::instance()->getTopWidget();
    WidgetController *wcOldParent = wcOldTopWidget->getParent();
    WidgetDefinition newDef;

    wcOldTopWidget->acceptVisitor(newDef);
    WidgetController *wcNewTopWidget = newDef.addToWidget(newParent, false);
    Model::instance()->setTopWidget(wcNewTopWidget);
    wcOldParent->removeChild(wcOldTopWidget);
    wcOldTopWidget->deleteLater();

    Model::instance()->setDataChanged(true);
}

/*!
 *  FUNCTION    :   newUserControl
 *  PARAMETERS  :   WidgetController *TopWidget
 *                      The widget to be included in the new User Control
 *                  QString &name
 *                      The name of the new User Control
 *  RETURN      :   void
 *
 *  This function creates a new User Control, with TopWidget as its child.
 *  For some obscure reason, Model::Instance()->addUserControl(wcUCtrl) does
 *  not work. Initialy, this function adds the newly created UserControl to the
 *  Model's list of UserControls. When after that, one imports another
 *  UserControl, the Model's list of UserControls seems to be corrupted for the
 *  newly made UserControl. The address of that newly made UserControl looks
 *  valid, but the address of mRticWidget is not anymore. This issue has been
 *  dealed with by replacing the addUserControl() call, with
 *  ui->frmFormEditor->ReadInclude(fileName). This seems to work Ok.
 *  Release 10:
 *  Since this release, User Controls are not only made by GroupBoxes, but any
 *  Widget combination. Therefor a check is made to check if a widget is not a
 *  child of another selected widget. If so, that child is removed from the
 *  selection list, because it will be added as a child. After that, the lowest
 *  common parent is searched, because that will become te parent of the new
 *  User Control. Then the dimensions of the new User Control are calculated.
 */
void MainWindow::newUserControl(QString &uctrlname , QString &id) {
    QString uctName = QString("UCT-%1").arg(uctrlname);
    QString fileName = QString("%1.xml").arg(uctName);
    WidgetDefinition wcInfo;
    WidgetController *wcBase = new WidgetController(NULL, WidgetController::RootWidgetMode);

    if (FileController::instance()->getFileName().isEmpty()) {
        QMessageBox::warning(this, tr("First save the ui definition file"),
                             tr("Before creating a UserControl, the ui definition file must be saved.\nThe UserControl will be saved in the same directory."),
                             QMessageBox::Ok);
        onSaveAs();
        if (FileController::instance()->getFileName().isEmpty()) {
            QMessageBox::warning(this, tr("First save the ui definition file"),
                                 tr("No ui definition file defined. So no User Control is created"), QMessageBox::Ok);
            return;
        }
    }

    //  Check if this UserControl ID already exists
    QString filepath = QFileInfo(FileController::instance()->getFileName()).absolutePath();
    filepath.append(QDir::separator());
    fileName.prepend(filepath);
    QFileInfo   chkFileInf(fileName);
    if (chkFileInf.exists()) {
        int ret = QMessageBox::warning(this, tr("User Control %1").arg(uctName),
                                       tr("User Control %1 already exists. Do you want to replace it?").arg(uctName),
                                       QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
        if (ret != QMessageBox::Yes) return;
        Model::instance()->removeUserControl(Model::instance()->retrieveFromStore(uctName));
    }

    //  Clear widgets from list that are children of other widgets that are also selected. Because
    //  they are children of selected widgets, they will be added to the UserControl anyway.
    QList<WidgetController *>    uctrlTopWidgetList = Model::instance()->getSelectionList();
    for (int ind1 = 0; ind1 < uctrlTopWidgetList.size(); ++ind1) {
        for (int ind2 = 0; ind2 < uctrlTopWidgetList.size(); ++ind2) {
            if (ind1 == ind2) continue;
            if (!uctrlTopWidgetList.at(ind1)->isChildOfThis(uctrlTopWidgetList.at(ind2))) continue;
            Model::instance()->removeFromSelectionList(uctrlTopWidgetList.at(ind2));
        }
    }

    //  Split child widget's if they are of widgetType RticUserControl
    bool bFound;
    do
    {
        bFound = false;
        uctrlTopWidgetList = Model::instance()->getSelectionList();
        foreach(WidgetController * wcTopWidget, uctrlTopWidgetList) {            
            WidgetController    *wcTest = wcTopWidget->searchForUserControl();
            if ( wcTest != NULL ) {
                splitUserControl(wcTest);
                bFound = true;
            }
        }
    }
    while (bFound);

    // Search for the common parent WidgetController
    QList<WidgetController *> parentList;
    QList<QList<WidgetController *>> allParentsList;

    foreach(WidgetController * wcChild, Model::instance()->getSelectionList())
        allParentsList.append(wcChild->getParentList());

    WidgetController *wcTopWidgetParent = NULL;
    parentList = allParentsList.at(0);
    int fndInd = -1;
    for (int ind1 = 0; (fndInd == -1) && (ind1 < parentList.size()); ++ind1) {
        WidgetController *wcTest = parentList.at(ind1);
        fndInd = 0;
        for (int ind2 = 1; (fndInd != -1) && (ind2 < allParentsList.size()); ++ind2) {
            QList<WidgetController *> pList = allParentsList.at(ind2);
            fndInd = allParentsList.at(ind2).indexOf(wcTest);
            if (fndInd > -1) wcTopWidgetParent = wcTest;
        }
    }
    if ( wcTopWidgetParent == NULL ) wcTopWidgetParent = parentList.at(0);

    //  Calculate dimensions
    int xTop = -1;
    int yTop = -1;
    int xBottom = -1;
    int yBottom = -1;
    uctrlTopWidgetList = Model::instance()->getSelectionList();
    foreach(WidgetController * wcTopWidget, uctrlTopWidgetList) {
        QPoint  Pos = QPoint(wcTopWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt(), wcTopWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt());
        Pos = wcTopWidget->getParent()->mapTo(wcTopWidgetParent, Pos);
        if ((Pos.x() < xTop) || (xTop == -1)) xTop = Pos.x();

        if ((Pos.y() < yTop) || (yTop == -1)) yTop = Pos.y();

        if (((Pos.x() + wcTopWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt()) > xBottom) || (xBottom == -1)) {
            xBottom = Pos.x() + wcTopWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width).toInt();
        }

        if (((Pos.y() + wcTopWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt()) > yBottom) || (yBottom == -1)) {
            yBottom = Pos.y() + wcTopWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height).toInt();
        }

    }

    int X = xTop - (Model::cmInnerMargin / 2);
    int Y = yTop - (Model::cmInnerMargin / 2);
    QPoint  uctrlPosition = QPoint(X, Y);

    //  Make an (empty) UserControl
    wcInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::ObjectType, QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::UserControl)));
    wcInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, QString::number(yBottom - yTop + (Model::cmInnerMargin)));
    wcInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, QString::number(xBottom - xTop + (Model::cmInnerMargin)));
    wcInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, QString::number(0));
    wcInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, QString::number(0));
    wcInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::ID, uctName);
    wcInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::UserControl, uctName);
    wcInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::FileName, fileName);
    wcInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::Sizeable, "false");
    WidgetController *wcUCtrl = wcInfo.addToWidget(wcBase, false);

    //  Add the TopWidgets to the UserControl
    QList<WidgetState *> wsStateList;
    foreach(WidgetController * wcTopWidget, uctrlTopWidgetList) {
        WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo(wcTopWidget, ACT_UCTRL, "New UserControl");
        QPoint  position = QPoint(wcTopWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::XPos).toInt(), wcTopWidget->getPropertyValue(SUI::ObjectPropertyTypeEnum::YPos).toInt());
        position = wcTopWidget->getParent()->mapTo(wcTopWidgetParent, position);
        position -= uctrlPosition;
        wcTopWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, QString::number(position.x()));
        wcTopWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, QString::number(position.y()));

        WidgetDefinition newDef;
        wcTopWidget->acceptVisitor(newDef);
        WidgetController *wcChild = newDef.addToWidget(wcUCtrl, false);

        wcChild->move(position);
        wcChild->setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, QString::number(position.x()));
        wcChild->setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, QString::number(position.y()));
        UndoHandler::instance()->finishUndoInfo(wsState, wcChild);
        wsStateList.append(wsState);
        if ( wcTopWidget->getParent() != NULL ) wcTopWidget->getParent()->removeChild(wcTopWidget);

        wcTopWidget->deleteLater();
    }
    wcUCtrl->setChildrenPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable, "false");
    wcUCtrl->setPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable, "true");
    wcUCtrl->setChildrenPropertyReadOnly();
    wcUCtrl->setParent(NULL);
    wcUCtrl->removeFromModel();

    wcBase->removeChild(wcUCtrl);
    wcBase->deleteLater();

    QApplication::processEvents();

    SUI::DialogSerializer mySerializer("UserControl", SUI::DialogSerializer::Write);
    try
    {
        mySerializer.openFile(fileName);
        wcUCtrl->acceptVisitor(mySerializer);
    }
    catch (SUI::XmlException *re)
    {
        SUI::MessageBox::warning(NULL,"XmlException", re->getExceptionMessage());
        return;
    }
    catch (SUI::IOException *re)
    {
        SUI::MessageBox::warning(NULL,"IOException", re->getExceptionMessage());
        return;
    }
    mySerializer.closeFile();

    ui->frmFormEditor->readInclude(fileName);

    if (!id.isEmpty()) {
        WidgetDefinition uCtrlDef;
        wcUCtrl->acceptVisitor(uCtrlDef);
        uCtrlDef.setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, QString::number(X));
        uCtrlDef.setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, QString::number(Y));
        uCtrlDef.setPropertyValue(SUI::ObjectPropertyTypeEnum::ID, id);
        WidgetController    *wcUTC = uCtrlDef.addToWidget(wcTopWidgetParent, false);
        wcUTC->renameChildren(wcUTC->getId());
        wcUTC->setChildrenPropertyReadOnly();
        Model::instance()->addUsedUserControl(wcUTC->getId());
        Model::instance()->getModelHandler()->sendNewWidget();
        Model::instance()->setNewSelected(wcUTC);
        UndoHandler::instance()->addNewUCtrlToWSList(wsStateList, wcUTC);
        if ( wsStateList.count() != 0 ) UndoHandler::instance()->addToUndoGroup(wsStateList);
        ui->frmFormEditor->setInclude(id, fileName);
    }
    else {
        Model::instance()->getModelHandler()->sendNewWidget();
        Model::instance()->setNewSelected(wcTopWidgetParent);
        foreach(WidgetState * wsState, wsStateList)
            UndoHandler::instance()->deleteWidgetState(wsState);
    }
    ui->usercontrolSelector->clear();
    ui->usercontrolSelector->initUserControls();

    Model::instance()->setDataChanged(true);

}

/*!
 *  FUNCTION    :   SplitUserControl
 *  PARAMETERS  :   WidgetController *UctWidget
 *                      The User Control to be removed
 *  RETURN      :   void
 *
 *  This function moves the child(ren) of the User Control to its parent Widget
 *  and removes the User Control.
 *  Sometimes, when clicking a User Contrtol, the selection shifts down a widget,
 *  from User Control to e.g. a GroupBox. In that case we have to move up again,
 *  until we've got the User Control again.
 */
void MainWindow::splitUserControl(WidgetController *UctWidget) {
    while (( UctWidget != NULL ) && ( UctWidget->getObjectType() != SUI::ObjectType::UserControl ) && ( UctWidget != Model::instance()->getCurrentTopPage() )) {
        UctWidget = UctWidget->getParent();
    }

    if (( UctWidget != NULL ) && (UctWidget->getObjectType() == SUI::ObjectType::UserControl)) {
        if (UctWidget->splitUserControl()) {
            UctWidget->deleteLater();
            QApplication::processEvents();
            Model::instance()->getModelHandler()->sendNewWidget();
        }
    }
    Model::instance()->setDataChanged(true);


}

/*!
 *  FUNCTION    :   onImportUserControl
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This is a SLOT function. It shows a File Dialog to open UserControl xml
 *  files. It then reads the chosen files and initializes the
 *  UserControlSelector with all UserControls.
 */
void MainWindow::onImportUserControl() {
    QStringList uCtrlFilenameList = QFileDialog::getOpenFileNames(this, tr("Open UserControl XML file"), "", tr("XML File (UCT*.xml)"));
    if (uCtrlFilenameList.isEmpty()) return;

    foreach(QString fileName, uCtrlFilenameList)
        FileController::instance()->importUserControl(fileName);

    ui->usercontrolSelector->clear();
    ui->usercontrolSelector->initUserControls();

    Model::instance()->setDataChanged(true);

}

/*!
 *  FUNCTION    :   onToForground
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This is a SLOT function. It moves the current widget to the top within its
 *  parent.
 */
void MainWindow::onToForground() {
    WidgetController *wcCurrent = Model::instance()->getCurrentWidget();
    if ( wcCurrent != NULL ) {
        WidgetController *wcCurParent = wcCurrent->getParent();
        if ( wcCurParent != NULL )
        {
            WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo(wcCurParent, ACT_MOVE, "Move to forground");
            QString idStr = wcCurrent->getId();
            wcCurParent->toForground(wcCurrent);
            wcCurParent->redraw();
            fillObjectTree();
            UndoHandler::instance()->finishUndoInfo(wsState, wcCurParent);
            UndoHandler::instance()->addToUndoGroup(wsState);
            Model::instance()->setNewSelected(Model::instance()->getWidgetController(idStr));
        }
    }
}

/*!
 *  FUNCTION    :   onBackground
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This is a SLOT function. It moves the current widget to the bottom within its
 *  parent.
 */
void MainWindow::onBackground() {
    WidgetController *wcCurrent = Model::instance()->getCurrentWidget();
    if ( wcCurrent != NULL ) {
        WidgetController *wcCurParent = wcCurrent->getParent();
        if ( wcCurParent != NULL ) {
            WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo(wcCurParent, ACT_MOVE, "Move to background");
            QString idStr = wcCurrent->getId();
            wcCurParent->toBackground(wcCurrent);
            wcCurParent->redraw();
            fillObjectTree();
            UndoHandler::instance()->finishUndoInfo(wsState, wcCurParent);
            UndoHandler::instance()->addToUndoGroup(wsState);
            Model::instance()->setNewSelected(Model::instance()->getWidgetController(idStr));
        }
    }
}

/*!
 *  FUNCTION    :   onForward
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This is a SLOT function. It moves the current widget one step to the top of
 *  its parent.
 */
void MainWindow::onForward() {
    WidgetController *wcCurrent = Model::instance()->getCurrentWidget();
    if ( wcCurrent != NULL ) {
        WidgetController *wcCurParent = wcCurrent->getParent();
        if ( wcCurParent != NULL ) {
            WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo(wcCurParent, ACT_MOVE, "Move forwards");
            QString idStr = wcCurrent->getId();
            wcCurParent->forward(wcCurrent);
            wcCurParent->redraw();
            fillObjectTree();
            UndoHandler::instance()->finishUndoInfo(wsState, wcCurParent);
            UndoHandler::instance()->addToUndoGroup(wsState);
            Model::instance()->setNewSelected(Model::instance()->getWidgetController(idStr));
        }
    }
    Model::instance()->setDataChanged(true);


}

/*!
 *  FUNCTION    :   onBackward
 *  PARAMETERS  :   void
 *  RETURN      :   void
 *
 *  This is a SLOT function. It moves the current widget one step to the bottom
 *  of its parent.
 */
void MainWindow::onBackward() {
    WidgetController *wcCurrent = Model::instance()->getCurrentWidget();
    if ( wcCurrent != NULL ) {
        WidgetController *wcCurParent = wcCurrent->getParent();
        if ( wcCurParent != NULL ) {
            WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo(wcCurParent, ACT_MOVE, "Move backwards");
            QString idStr = wcCurrent->getId();
            wcCurParent->backward(wcCurrent);
            wcCurParent->redraw();
            fillObjectTree();
            UndoHandler::instance()->finishUndoInfo(wsState, wcCurParent);
            UndoHandler::instance()->addToUndoGroup(wsState);
            Model::instance()->setNewSelected(Model::instance()->getWidgetController(idStr));
        }
    }
    Model::instance()->setDataChanged(true);

}

/*!
 *  FUNCTION    :   onEnableForwardbackward
 *  PARAMETERS  :   bool on
 *                      Enables or disables
 *  RETURN      :   void
 *
 *  This is a SLOT function. It enables or disables the Front/Back QActions.
 */
void MainWindow::onEnableForwardbackward(bool on) {
    ui->actionTo_Forground->setEnabled(on);
    ui->actionTo_Background->setEnabled(on);
    ui->actionForward->setEnabled(on);
    ui->actionBackward->setEnabled(on);
}

/*!
 *  FUNCTION    :   onAddTabPageAct
 *  PARAMETERS  :
 *  RETURN      :   void
 *
 *  This is a SLOT function.
 */
void MainWindow::onAddTabPageAct() {
    QString tabNameStr;
    SetNameDialog    *tabnameDia = new SetNameDialog(QString(""));
    tabnameDia->setStyleSheet(QString::fromStdString(SUI::StyleSheet::getInstance()->getStyleSheet()));
    tabnameDia->setWindowTitle("Type the new tab name");
    tabnameDia->setEditLabelText("Tab name:");
    if (tabnameDia->exec() == QDialog::Accepted)
    {
        tabNameStr = tabnameDia->getName();
        WidgetController *curWidget = Model::instance()->getCurrentWidget();
        curWidget->addTabPage(tabNameStr);
    }
    tabnameDia->deleteLater();
}

/*!
 *  FUNCTION    :   onMoveNextAct
 *  PARAMETERS  :
 *  RETURN      :   void
 *
 *  This is a SLOT function.
 */
void MainWindow::onMoveNextAct() {
    moveTabPage(true);
}

/*!
 *  FUNCTION    :   onMoveNextAct
 *  PARAMETERS  :
 *  RETURN      :   void
 *
 *  This is a SLOT function.
 */
void MainWindow::onMovePrevAct() {
    moveTabPage(false);
}

/*!
 *  FUNCTION    :   moveTabPage
 *  PARAMETERS  :   bool direction
 *                      - If true move to Next else previous
 *  RETURN      :   void
 *
 *  This function moves the tabpages to the next or previous position.
 */
void MainWindow::moveTabPage(bool direction) {
    WidgetController *curWidget = Model::instance()->getCurrentWidget();
    if ( curWidget != NULL ) {
        WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo(curWidget, ACT_COMPLEX, "Tabpage move");
        int dNewTabNr = -1;
        int dPrevTabNr = dynamic_cast<SUI::TabWidgetImpl *>(curWidget->getBaseWidget())->getCurrentIndex();
        QString strTabPageID = QString::fromStdString(dynamic_cast<SUI::TabWidgetImpl *>(curWidget->getBaseWidget())->getCurrentTabPage()->getId());

        if ( direction ) dNewTabNr = dynamic_cast<SUI::TabWidgetImpl *>(curWidget->getBaseWidget())->moveNext();
        else dNewTabNr = dynamic_cast<SUI::TabWidgetImpl *>(curWidget->getBaseWidget())->movePrevious();

        curWidget->updatePixmap();
        if ((dNewTabNr != -1) && (dPrevTabNr != dNewTabNr)) {
            curWidget->removeChildat(dPrevTabNr);
            curWidget->insertChild(dNewTabNr, Model::instance()->getWidgetController(strTabPageID));
        }
        Model::instance()->getModelHandler()->sendNewWidget();
        Model::instance()->selectNewWidget(strTabPageID);
        Model::instance()->setNewSelected(Model::instance()->getWidgetController(curWidget->getId()));
        UndoHandler::instance()->finishUndoInfo(wsState, curWidget);
        UndoHandler::instance()->addToUndoGroup(wsState);
    }
    Model::instance()->setDataChanged(true);

}


/*!
 *  FUNCTION    :   onDeleteAct
 *  PARAMETERS  :
 *  RETURN      :   void
 *
 *  This is a SLOT function. It is being called when a user selects remove
 *  tabpage in the popup menu.
 */
void MainWindow::onDeleteAct()
{
    WidgetController *curWidg = NULL;
    WidgetController *curWidget = Model::instance()->getCurrentWidget();
    SUI::TabPage *curTabPage = dynamic_cast<SUI::TabWidgetImpl *>(curWidget->getBaseWidget())->getCurrentTabPage();
    if (dynamic_cast<SUI::TabWidgetImpl *>(curWidget->getBaseWidget())->removeTab()) {
        WidgetState *wsState = UndoHandler::instance()->getNewUndoInfo(curWidget, ACT_COMPLEX, "Remove Tabpage");
        for (int ind = 0; ind <  curWidget->getChildren()->size(); ++ind) {
            if (dynamic_cast<SUI::TabPageImpl *>(curWidget->getChildren()->at(ind)->getBaseWidget()) == curTabPage) {
                curWidg = curWidget->getChildren()->at(ind);
                break;
            }
        }
        if ( curWidg != NULL ) {
            curWidget->removeChild(curWidg);
            curWidg->deleteLater();
            curWidget->updatePixmap();
            Model::instance()->getModelHandler()->sendNewWidget();
        }
        UndoHandler::instance()->finishUndoInfo(wsState, curWidget);
        UndoHandler::instance()->addToUndoGroup(wsState);
    }
    curWidget->setPropertyValue(SUI::ObjectPropertyTypeEnum::CurrentTabPage, QString::number(dynamic_cast<SUI::TabWidgetImpl *>(curWidget->getBaseWidget())->getCurrentIndex()));
    curTabPage = dynamic_cast<SUI::TabWidgetImpl *>(curWidget->getBaseWidget())->getCurrentTabPage();
    Model::instance()->getWidgetController(QString::fromStdString(curTabPage->getId()))->showProperTabPages();

    Model::instance()->setDataChanged(true);

}


/*!
 *  FUNCTION    :   onCopyWidget
 *  PARAMETERS  :
 *  RETURN      :   void
 *
 *  This is a SLOT function, connected to the ui->action_Copy triggered SIGNAL,
 *  which is emitted whenever the user selects the ui->action_Copy action in the
 *  popup menu or Presses 'Ctrl-C'. It forwards the action to the
 *  HandleCopyAction() function of the currently selected object. It will not
 *  allow to copy the Main Tab Widget or a Tab Page.
 */
void MainWindow::onCopyWidget()
{
    bool    bWidgetTypeCopyError = false;
    foreach(WidgetController * wcChild, Model::instance()->getSelectionList())
    {
        if (wcChild->getObjectType() == SUI::ObjectType::TabPage)
        {
            bWidgetTypeCopyError = true;
            break;
        }
    }

    if ((Model::instance()->getSelectionList().contains(Model::instance()->getMainTabWidget())) ||
            (Model::instance()->getSelectionList().contains(Model::instance()->getTopWidget())))
    {
        bWidgetTypeCopyError = true;
    }

    if (bWidgetTypeCopyError)
    {
        QMessageBox::critical(this, qApp->applicationName(),
                              tr("It is not allowed to copy the Main TabWidget, the TopWidget or a TabPage"));
        return;
    }
    if (!Model::instance()->setCopiedDragAndDropInfo())
    {
        QMessageBox::critical(this, qApp->applicationName(),
                              tr("Not all widgets have the same parent. You can not copy these widgets simultaniously"));
    }
    Model::instance()->setDataChanged(true);

}

/*!
 *  FUNCTION    :   onPasteWidget
 *  PARAMETERS  :
 *  RETURN      :   void
 *
 *  This is a SLOT function, connected to the ui->action_Paste triggered SIGNAL,
 *  which is emitted whenever the user selects the ui->action_Paste action in the
 *  popup menu or Presses 'Ctrl-P'. It retrieves the currently selected widget.
 *  If that is a Tab Widget, it retrieves that Tab Widget's current Tab Page and
 *  that will become the Parent Widget. Otherwise, it searches upwards until it
 *  finds a widget that supports children. Then that will become the Parent Widget.
 *  Since this action can be triggered by a 'Ctrl-P' key sequence, a point can
 *  not be used as the place to copy to. It forwards the action to the
 *  HandlePasteAction() function of the parent Widget.
 *
 *  Release 10:
 *  Since this version, the Main TabWidget is not mandatory anymore.
 *  So the (newly introduced) TopWidget is either the Main TabWidget or a
 *  RticWidgetPage.
 */
void MainWindow::onPasteWidget()
{
    WidgetController *parWidg = Model::instance()->getCurrentWidget();
    if ( parWidg != NULL )
    {
        if (parWidg->getObjectType() == SUI::ObjectType::TabWidget)
        {
            parWidg = parWidg->getCurrentDaDTabpage();
        }
        else
        {
            while (( parWidg != NULL ) && !(parWidg->supportsChildren()))
            {
                parWidg = parWidg->getParent();
            }
        }
    }
    else
    {
        parWidg = Model::instance()->getCurrentTopPage();
    }
    parWidg->handlePasteAction();

    Model::instance()->setDataChanged(true);

}

/*!
 *  FUNCTION    :   onQuit
 *  PARAMETERS  :
 *  RETURN      :   void
 *
 *  This is a SLOT function, connected to the ui->action_Quit triggered SIGNAL.
 *  It is also being called by closeEvent(). It checks if anything has changed
 *  and if so, it asks if the user wants to save these changes. It then closes
 *  the application.
 */
void MainWindow::onQuit()
{
    mSettings->setValue("GridActive", Model::instance()->gridActive());
    mSettings->setValue("X-Snap", Model::instance()->xSnap());
    mSettings->setValue("Y-Snap", Model::instance()->ySnap());
    mSettings->setValue("X-Distance", Model::instance()->XGridDistance());
    mSettings->setValue("Y-Distance", Model::instance()->YGridDistance());
    mSettings->sync();
    if (FileController::instance()->saveDialog()) {
        qApp->quit();
    }
}

void MainWindow::onEnableStandardButtonArea(bool enabled) {
    ui->actionAdd_Standard_Button_area->setDisabled(enabled);
}

/*!
 *  FUNCTION    :   onDisableShowProperties
 *  PARAMETERS  :
 *  RETURN      :   void
 *
 *  This is a SLOT function, connected to the ModeHandler disableShowProperties
 *  SIGNAL. It is intended to temporarely disable SLOTS which update the Property
 *  Table Widget and Object Tree View.
 *  Since disabling these slots can happen in different nested functions, the
 *  upper most function can reserve the enabling for itself, without nested
 *  functions being able the enable it again.
 */
void MainWindow::onDisableShowProperties(const QString &funcname)
{
    if (mSendDisableShowFunction.isEmpty())
    {
        ui->m_PropertyTW->getTablePointer()->blockSignals(true);
        ui->m_PropertyTW->blockSignals(true);
        ui->m_ObjectTV->selectionModel()->blockSignals(true);
        mSendDisableShowFunction = funcname;
    }
}

/*!
 *  FUNCTION    :   onEnableShowProperties
 *  PARAMETERS  :
 *  RETURN      :   void
 *
 *  This is a SLOT function, connected to the ModeHandler enableShowProperties
 *  SIGNAL. It is intended to enable SLOTS which update the Property
 *  Table Widget and Object Tree View again.
 *  Since disabling these slots can happen in different nested functions, the
 *  upper most function can reserve the enabling for itself, without nested
 *  functions being able the enable it again.
 */
void MainWindow::onEnableShowProperties(const QString &funcname)
{
    if (mSendDisableShowFunction == funcname)
    {
        ui->m_PropertyTW->getTablePointer()->blockSignals(false);
        ui->m_PropertyTW->blockSignals(false);
        ui->m_ObjectTV->selectionModel()->blockSignals(false);
        mSendDisableShowFunction.clear();
    }
}

/*!
 *  FUNCTION    :   keyPressEvent
 *  PARAMETERS  :   QKeyEvent *ke
 *  RETURN      :   void
 *
 *  This is a virtual function to handle the key events. Here we want to handle
 *  the Delete and Ctrl key,
 *
 *  Release 10:
 *  Since this version, the Main TabWidget is not mandatory anymore.
 *  So the (newly introduced) TopWidget is either the Main TabWidget or a
 *  RticWidgetPage. If the Main TabWidget is deleted, a RticWidgetPage is
 *  created to be the TopWidget.
 */
void MainWindow::keyPressEvent(QKeyEvent *ke)
{
    QList<WidgetState *> wsStateList;
    switch (ke->key())
    {
    case Qt::Key_Delete:
        Model::instance()->removeChildrenFromSelectionList();
        foreach(WidgetController * curWidg, Model::instance()->getSelectionList())
        {
            bool    bMainTabWidgetDeleted = (curWidg == Model::instance()->getMainTabWidget());

            if (( curWidg != NULL ) && (((curWidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable).toLower() != "false") &&
                             (curWidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::UserControl).isEmpty() || (curWidg->getObjectType() == SUI::ObjectType::UserControl))) ||
                            bMainTabWidgetDeleted))
            {
                WidgetState         *wsState = NULL;
                WidgetController    *wcTopWidget = NULL;
                WidgetController    *wcParent = curWidg->getParent();
                wcParent->removeChild(curWidg);
                Model::instance()->removeWidget(curWidg->widgetGUID());
                if (bMainTabWidgetDeleted) {
                    wsState = UndoHandler::instance()->getNewUndoInfo(curWidg, ACT_COMPLEX, "Delete Main Tabwidget");
                    WidgetDefinition WCInfo;
                    WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::ObjectType, QString::fromStdString(SUI::ObjectType::toString(SUI::ObjectType::WidgetPage)));
                    WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::Moveable, "false");
                    WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::Sizeable, "false");
                    WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::XPos, "0");
                    WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::YPos, "0");
                    WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::ID, "wpg1");
                    WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::Height, curWidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::Height));
                    WCInfo.setPropertyValue(SUI::ObjectPropertyTypeEnum::Width, curWidg->getPropertyValue(SUI::ObjectPropertyTypeEnum::Width));
                    wcTopWidget = WCInfo.addToWidget(wcParent, false);

                    Model::instance()->addWidget(wcTopWidget);
                    Model::instance()->setTopWidget(wcTopWidget);
                    if (wcParent->getObjectType() == SUI::ObjectType::Splitter) {
                        dynamic_cast<SUI::SplitterImpl *>(wcParent->getBaseWidget())->switchSplitterWidgets(curWidg->getBaseWidget(), wcTopWidget->getBaseWidget());
                    }
                    handleFormLayout();
                    Model::instance()->getModelHandler()->sendNewWidget();
                    Model::instance()->getModelHandler()->newWidgetProperties(wcTopWidget);
                    Model::instance()->getModelHandler()->newWidgetSelection(wcTopWidget);
                }
                else {
                    wsState = UndoHandler::instance()->getNewUndoInfo(curWidg, ACT_DELETE, "Delete widget");
                    Model::instance()->getModelHandler()->sendNewWidget();
                    Model::instance()->getModelHandler()->newWidgetSelection(wcParent);
                    Model::instance()->getModelHandler()->newWidgetProperties(wcParent);
                }
                UndoHandler::instance()->finishUndoInfo(wsState, wcTopWidget);
                if (!bMainTabWidgetDeleted)
                {
                    wsStateList.append(wsState);
                }
                else
                {
                    wsStateList.prepend(wsState);
                }
                curWidg->deleteLater();
            }
        }
        UndoHandler::instance()->addToUndoGroup(wsStateList);
        Model::instance()->setDataChanged(true);

        break;
    case Qt::Key_Control:
        Model::instance()->setCtrlPressed(true);
        break;
    default:
        QWidget::keyPressEvent(ke);
        Model::instance()->setDataChanged(true);

        break;
    }
}

/*!
 *  FUNCTION    :   keyReleaseEvent
 *  PARAMETERS  :   QKeyEvent *ke
 *  RETURN      :   void
 *
 *  This is a virtual function to handle the key events. Here we want to handle
 *  the Ctrl key,
 */
void MainWindow::keyReleaseEvent(QKeyEvent *ke)
{
    if (ke->key() == Qt::Key_Control)
    {
        Model::instance()->setCtrlReleased();
    }
    else
    {
        QWidget::keyReleaseEvent(ke);
    }
    Model::instance()->setDataChanged(true);

}

/*!
 *  FUNCTION    :   onNewLogMessage
 *  PARAMETERS  :   QString title
 *                      The title (caption bar) of the message box.
 *                  QString msg
 *                      The message to be displayed in the message box.
 *                  int level
 *                      Tndicates the message type.
 *  RETURN      :   void
 *
 *  This is a SLOT function, triggered by ModelHandler::sigSendMessage(). It
 *  displayes a message box with the given title, message and error type.
 */
void MainWindow::onNewLogMessage(QString title, QString msg, int level)
{
    switch (level)
    {
    case 0:
        QMessageBox::information(this, title, msg);
        break;
    case 1:
        QMessageBox::warning(this, title, msg);
        break;
    case 2:
        QMessageBox::critical(this, title, msg);
        break;
    default:
        QMessageBox::critical(this, title, tr("Unknown loglevel detected %1. Message is:\n%2").arg(level).arg(msg));
        break;
    }
}

/*!
 *  FUNCTION    :   onPreview
 *  PARAMETERS  :   n.a.
 *  RETURN      :   void
 *
 *  This is a SLOT function, connected to the ui->actionPreview SIGNAL. It shows
 *  the preview dialog.
 */
void MainWindow::onPreview() {
    // if the backup file is empty
    if (FileController::instance()->getBackupTempFileName() == "") {
        //then tell the FileController data changed, that way a backup file will be created
        FileController::instance()->setDataChanged(true);
        //and wait some time before we call this function again
        QTimer::singleShot(500,this,SLOT(onPreview()));
    }
    // if the backup file exists
    else {
        // copy the usercontrol files if any
        QFile file(FileController::instance()->getBackupTempFileName());
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
            throw new SUI::IOException(std::string(" Unable to open file ").append(file.fileName().toStdString()).append(" for reading. Error: ").append(file.errorString().toStdString()));

        QTextStream fileStream(&file);
        QString fileContent = fileStream.readAll();
        file.close();

        QSet<QString> userControlFiles;
        QStringList fileContentList = fileContent.split("\n");
        foreach (QString line, fileContentList) {
            if (!line.contains("<property Include-")) continue;

            QString includeFileName = line.split("=").at(1).split("\"").at(1);

            QFileInfo backupTempFileInfo(FileController::instance()->getBackupTempFileName());
            QString tempPath = backupTempFileInfo.absolutePath().append(QDir::separator()).append(includeFileName);

            QString path = includeFileName;
            if (FileController::instance()->getFileName() != "") {
                QFileInfo fileInfo(FileController::instance()->getFileName());
                path.prepend(QDir::separator()).prepend(fileInfo.absolutePath());
            }
            if (!userControlFiles.contains(tempPath)) {
                userControlFiles.insert(tempPath);
                QFile::copy(path,tempPath);
            }
        }

        // load it in a dialog
        SUI::Dialog *dialog = SUI::UILoader::loadUI(FileController::instance()->getBackupTempFileName().toStdString());
        dialog->setModal(true);
        dialog->show();

        // delete the temp files
        foreach (QString tempFile, userControlFiles)
            QFile::remove(tempFile);
    }
}

/*!
 *  FUNCTION    :   onCollapseAll
 *  PARAMETERS  :   n.a.
 *  RETURN      :   void
 *
 *  This is a SLOT function, connected to the ui->actionCollapseAll SIGNAL. It shows
 *  child Widgets. In the treeview
 */
void MainWindow::onCollapseAll()
{
    expandNode(ui->m_ObjectTV->currentIndex(), false);
}

/*!
 *  FUNCTION    :   onExpandAll
 *  PARAMETERS  :   n.a.
 *  RETURN      :   void
 *
 *  This is a SLOT function, connected to the ui->actionExpandAll SIGNAL. It Hides
 *  child Widgets in the treeview
 */
void MainWindow::onExpandAll()
{
    expandNode(ui->m_ObjectTV->currentIndex(), true);
}

/*!
 *  FUNCTION    :   expandNode
 *  PARAMETERS  :   QModelIndex &parentIndex
 *                      - The index of parent item
 *              :   bool expand
 *                      - false will collapse the child item, true will expand
 *  RETURN      :   void
 *
 *  This function hides/shows the child items of the treeview. This will effect
 *  all the child item below the parent index
 */
void MainWindow::expandNode(const QModelIndex &parentIndex, bool expand)
{
    if (expand)
    {
        ui->m_ObjectTV->setExpanded(parentIndex, expand);
    }
    for (int rowNum = 0; rowNum < ui->m_ObjectTV->model()->rowCount(parentIndex); ++rowNum)
    {
        QModelIndex childIndex = ui->m_ObjectTV->model()->index(rowNum, 0, parentIndex);
        ui->m_ObjectTV->setExpanded(childIndex, expand);
        expandNode(childIndex, expand);
    }
}

/*!
 *  FUNCTION    :   onUndo
 *  PARAMETERS  :   NA
 *  RETURN      :   void
 *
 *  This is a SLOT function. It executes an undo action.
 */
void MainWindow::onUndo()
{
    onDisableShowProperties(__FUNCTION__);
    Model::instance()->setCtrlReleased();
    UndoHandler::instance()->undo();
    onEnableShowProperties(__FUNCTION__);

    Model::instance()->setDataChanged(true);

}

/*!
 *  FUNCTION    :   onRedo
 *  PARAMETERS  :   NA
 *  RETURN      :   void
 *
 *  This is a SLOT function. It executes a redo action.
 */
void MainWindow::onRedo()
{
    onDisableShowProperties(__FUNCTION__);
    Model::instance()->setCtrlReleased();
    UndoHandler::instance()->redo();
    onEnableShowProperties(__FUNCTION__);

    Model::instance()->setDataChanged(true);

}

/*!
 *  FUNCTION    :   onEnableUndo
 *  PARAMETERS  :   bool enable
 *  RETURN      :   void
 *
 *  This is a SLOT function. It executes the enabling or disabling of the undo
 *  action. If undo is enabled it shows the next undo action in the menu.
 *  Therefor, if undo is disabled, the menu text should be simply 'undo', without
 *  the next undo action, because there is no next undo action.
 */
void MainWindow::onEnableUndo(bool enable)
{
    if (!enable)
    {
        ui->action_Undo->setText("Undo");
    }
    ui->action_Undo->setEnabled(enable);
}

/*!
 *  FUNCTION    :   onEnableRedo
 *  PARAMETERS  :   bool enable
 *  RETURN      :   void
 *
 *  This is a SLOT function. It executes the enabling or disabling of the redo
 *  action.
 */
void MainWindow::onEnableRedo(bool enable)
{
    ui->action_Redo->setEnabled(enable);
}

/*!
 *  FUNCTION    :   onUndoRedoText
 *  PARAMETERS  :   const QString &undotxt
 *                      The string with the next undo action.
 *                  const QString &redotxt
 *                      The string with the next redo action.
 *  RETURN      :   void
 *
 *  This is a SLOT function. It appends the next undo and redo actions to their
 *  menu items.
 */
void MainWindow::onUndoRedoText(const QString &undotxt, const QString &redotxt)
{
    QString strUndo = undotxt;
    QString strRedo = redotxt;
    if (!strUndo.isEmpty())
    {
        strUndo.prepend(" ");
    }
    ui->action_Undo->setText(QString("Undo%1").arg(strUndo));

    if (!strRedo.isEmpty())
    {
        strRedo.prepend(" ");
    }
    ui->action_Redo->setText(QString("Redo%1").arg(strRedo));
}

/*!
 *  FUNCTION    :   onPrintUndoBuffer
 *  PARAMETERS  :   n.a.
 *  RETURN      :   void
 *
 *  This is a SLOT function. It is meant for debugging purposes and not activated
 *  in general.
 */
void MainWindow::onPrintUndoBuffer()
{
    UndoHandler::instance()->printUndoBuffer();
}


/*!
 *  FUNCTION    :   removeUCtrlFromSelector
 *  PARAMETERS  :   WidgetController *widget
 *  RETURN      :   void
 *
 *  This function removes the User Control from the user control selector and
 *  from the Model's UserControl List. Furthermore it splits all instances of
 *  this UserControl on the form.
 */
void MainWindow::removeUCtrlFromSelector(WidgetController *widget)
{
    QString uctrlID = widget->getId();
    Model::instance()->removeUserControl(Model::instance()->retrieveFromStore(widget->getId()));
    ui->usercontrolSelector->clear();
    ui->usercontrolSelector->initUserControls();
    foreach (QString testID, Model::instance()->getUsedUCtrlList())
    {
        WidgetController *wcTest = Model::instance()->getWidgetController(testID);
        if (( wcTest != NULL ) && (wcTest->getPropertyValue(SUI::ObjectPropertyTypeEnum::UserControl) == uctrlID))
        {
            splitUserControl(wcTest);
        }
    }
}

/*!
 *  FUNCTION    :   onWidgetProcessed
 *  PARAMETERS  :   n.a.
 *  RETURN      :   void
 *
 *  This is a SLOT function and is activated by Model's widgetProcessed signal.
 *  It add's one to the current value of the progress bar in the Status Bar .
 */
void MainWindow::onWidgetProcessed()
{
    ++mWidgetCount;
    mWidgetCountProgressBar->setValue(mWidgetCount);
}

/*!
 *  FUNCTION    :   onWidgetProcessMessage
 *  PARAMETERS  :   QString &msg
 *                      The new message
 *  RETURN      :   void
 *
 *  This is a SLOT function and is activated by Model's newMessage signal.
 *  It sets the new message in the Status Bar.
 */
void MainWindow::onWidgetProcessMessage(QString msg) {
    statusBar()->showMessage(msg);
}

/*!
 *  FUNCTION    :   onWidgetProcessStart
 *  PARAMETERS  :   int count
 *                      The maximum value of the progress bar.
 *  RETURN      :   void
 *
 *  This is a SLOT function and is activated by Model's setWidgetCount signal.
 *  It initializes the progress bar in the Status Bar.
 */
void MainWindow::onWidgetProcessStart(int count) {
    ui->frmFormEditor->setVisible(false);
    mWidgetCount = 0;
    mWidgetCountProgressBar->setMinimum(0);
    mWidgetCountProgressBar->setMaximum(count);
    mWidgetCountProgressBar->setValue(0);
    statusBar()->addPermanentWidget(mWidgetCountProgressBar);
    mWidgetCountProgressBar->show();
    Model::instance()->onLoadingFile();
    connect(Model::instance(), SIGNAL(setWidgetCount(int)), this, SLOT(onWidgetProcessStart(int)),Qt::UniqueConnection);
    connect(Model::instance(), SIGNAL(widgetProcessed()), this, SLOT(onWidgetProcessed()),Qt::UniqueConnection);
    connect(Model::instance(), SIGNAL(newMessage(QString)), this, SLOT(onWidgetProcessMessage(QString)),Qt::UniqueConnection);
}

/*!
 *  FUNCTION    :   finishWidgetProcess
 *  PARAMETERS  :   n.a.
 *  RETURN      :   void
 *
 *  This function hides the progress bar in the Status Bar.
 */
void MainWindow::onFinishWidgetProcess() {
    statusBar()->removeWidget(mWidgetCountProgressBar);
    mWidgetCountProgressBar->hide();
    Model::instance()->callNewMessage("");
    Model::instance()->onFileLoaded();
    disconnect(Model::instance(), SIGNAL(setWidgetCount(int)), this, SLOT(onWidgetProcessStart(int)));
    disconnect(Model::instance(), SIGNAL(widgetProcessed()), this, SLOT(onWidgetProcessed()));
    disconnect(Model::instance(), SIGNAL(newMessage(QString)), this, SLOT(onWidgetProcessMessage(QString)));
    ui->frmFormEditor->setVisible(true);
}

/*!
 *  FUNCTION    :   onDataChanged
 *  FUNCTION    :   onDataChanged
 *  PARAMETERS  :   bool changed
 *  RETURN      :   void
 *
 *  This is a SLOT function and is activated by Model's sendDataChanged signal.
 *  This signal is emitted whenever the data changes. This function will set an
 *  asterix in the caption bar if the current definition has not been saved.
 */
void MainWindow::onDataChanged(bool changed) {
    if ( Model::instance()->getCurrentWidget() != NULL ) {
        FileController::instance()->setDataChanged(changed);
    }
    setWindowModified(changed);
    if ( Model::instance()->getCurrentWidget() != NULL ) {
        Model::instance()->getCurrentWidget()->updatePixmap();
    }
}

/*!
 *  FUNCTION    :   onGridChanged
 *  PARAMETERS  :   bool set
 *  RETURN      :   void
 *
 *  This SLOT function sets the grid on or off, depending on the set parameter.
 */
void MainWindow::onGridChanged(bool set)
{
    Model::instance()->useGrid(set);
    ui->frmFormEditor->setGridPixmap();
}

/*!
 *  FUNCTION    :   onGridOptions
 *  PARAMETERS  :   n.a.
 *  RETURN      :   void
 *
 *  This SLOT function shows a grid property dialogbox. Because the grid
 *  distance may have been changed in this dialog, the FormEditor needs to be
 *  updated again with the new grid distance (if applicable).
 */
void MainWindow::onGridOptions()
{
    GridProperties  *gridDialog = new GridProperties();
    gridDialog->setStyleSheet(QString::fromStdString(SUI::StyleSheet::getInstance()->getStyleSheet()));
    if (gridDialog->exec() == QDialog::Accepted)
    {
        ui->actionGrid_Enabled->setChecked(Model::instance()->gridActive());
        bool    bGrid = Model::instance()->gridActive();
        Model::instance()->useGrid(bGrid);
        ui->frmFormEditor->setGridPixmap();
    }
    gridDialog->deleteLater();
}

FormEditor *MainWindow::getFormEditor() const {
    return ui->frmFormEditor;
}

