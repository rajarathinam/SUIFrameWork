//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for ExternalEventHandler.
// !\description Class implementation file for ExternalEventHandler.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|



#include "SUIExternalEventHandler.h"
#include "SUIExternalEventHandlerImpl.h"

#include <QApplication>

bool SUI::ExternalEventHandler::raiseEvent(SUI::AbstractExternalEvent *event) {
    ExternalEventHandlerImpl *t = new ExternalEventHandlerImpl(event);
    t->moveToThread(QApplication::instance()->thread());
    return QMetaObject::invokeMethod(t, "emitEvent", Qt::QueuedConnection);
}
