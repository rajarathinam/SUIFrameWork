//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for ColorCrossDrop.
// !\description Class implementation file for ColorCrossDrop.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUIColorCrossDrop.h"

#include "SUIObjectFactory.h"

SUI::ColorCrossDrop::ColorCrossDrop() : 
    Widget(SUI::ObjectType::fromString(SUI::ObjectFactory::getClassName<ColorCrossDrop>()))
{
}

SUI::ColorCrossDrop::~ColorCrossDrop()
{
}
