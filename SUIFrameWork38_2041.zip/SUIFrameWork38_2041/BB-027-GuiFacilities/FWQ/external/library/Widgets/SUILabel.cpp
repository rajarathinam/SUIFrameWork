//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for Label.
// !\description Class implementation file for Label.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|



#include "SUILabel.h"

#include "SUIObjectFactory.h"

SUI::Label::Label() : 
    Widget(SUI::ObjectType::Label) 
{       
}

SUI::Label::~Label()
{
}
