//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author      Patrick van Tongeren
// !\brief       Class implementation file for WebView.
// !\description Class implementation file for WebView.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUIWebView.h"
#include "SUIObjectFactory.h"

SUI::WebView::WebView() : Widget(SUI::ObjectType::WebView)
{
}

SUI::WebView::~WebView()
{
}
