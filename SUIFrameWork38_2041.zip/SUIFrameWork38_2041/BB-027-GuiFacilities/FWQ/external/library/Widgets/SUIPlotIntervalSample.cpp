//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for SUI::PlotIntervalSample.
// !\description Class implementation file for SUI::PlotIntervalSample.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUIPlotIntervalSample.h"

SUI::PlotIntervalSample::PlotIntervalSample(double val, double min, double max) :
    value(val),
    minValue(min),
    maxValue(max)
{
}
double SUI::PlotIntervalSample::getMaxValue() const {
    return maxValue;
}

void SUI::PlotIntervalSample::setMaxValue(double value) {
    maxValue = value;
}

double SUI::PlotIntervalSample::getMinValue() const {
    return minValue;
}

void SUI::PlotIntervalSample::setMinValue(double value) {
    minValue = value;
}

double SUI::PlotIntervalSample::getValue() const {
    return value;
}

void SUI::PlotIntervalSample::setValue(double val) {
    value = val;
}
