//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for GroupBox.
// !\description Class implementation file for GroupBox.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIGroupBox.h"

#include "SUIObjectFactory.h"

SUI::GroupBox::GroupBox() : 
    Widget(SUI::ObjectType::GroupBox)
{
}

SUI::GroupBox::GroupBox(const SUI::ObjectType::Type &type) : 
    Widget(type)
{
}

SUI::GroupBox::~GroupBox()
{
}
