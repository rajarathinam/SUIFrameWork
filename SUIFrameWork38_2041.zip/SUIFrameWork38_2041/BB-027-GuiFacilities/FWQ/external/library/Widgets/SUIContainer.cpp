//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for Container.
// !\description Class implementation file for Container.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "SUIContainer.h"

#include "SUIObjectFactory.h"

SUI::Container::Container() : 
    Widget(SUI::ObjectType::fromString(SUI::ObjectFactory::getClassName<Container>()))
{
}

SUI::Container::~Container()
{
}
