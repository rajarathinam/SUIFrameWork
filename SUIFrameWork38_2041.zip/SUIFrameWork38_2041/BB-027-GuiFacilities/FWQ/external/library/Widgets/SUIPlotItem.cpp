//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for PlotItem.
// !\description Class implementation file for PlotItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "SUIPlotItem.h"
#include "SUIPlotWidgetImpl.h"

SUI::PlotItem::PlotItem(const SUI::ObjectType::Type &type, void *implementation) :
    SUI::Object(type),
    implementation(implementation)
{
}

std::string SUI::PlotItem::getId() const {
    return id;
}

void SUI::PlotItem::setId(const std::string &value) {
    id = value;
}

SUI::PlotItem::~PlotItem() {
}

void SUI::PlotItem::setEnabled(bool value) {
    enabled = value;
}

bool SUI::PlotItem::isEnabled() const {
    return enabled;
}

void* SUI::PlotItem::getImplementation() const {
    return implementation;
}

void SUI::PlotItem::setImplementation(void* impl) {
    implementation = impl;
}

SUI::PlotItemCustomColor::PlotItemCustomColor(const int red, const int green, const int blue, const int alpha) :
    mRed(red), mGreen(green), mBlue(blue), mAlpha(alpha)
{
}

int SUI::PlotItemCustomColor::getRed() const {
    return mRed;
}

int SUI::PlotItemCustomColor::getGreen() const {
    return mGreen;
}

int SUI::PlotItemCustomColor::getBlue() const {
    return mBlue;
}

int SUI::PlotItemCustomColor::getAlpha() const {
    return mAlpha;
}

void SUI::PlotItemCustomColor::setRed(const int value) {
    mRed = value;
}

void SUI::PlotItemCustomColor::setGreen(const int value) {
    mGreen = value;
}

void SUI::PlotItemCustomColor::setBlue(const int value) {
    mBlue = value;
}

void SUI::PlotItemCustomColor::setAlpha(const int value) {
    mAlpha = value;
}

bool SUI::PlotItemCustomColor::operator == (const PlotItemCustomColor &color) const {
    return (this->getRed() == color.getRed() &&
            this->getBlue() == color.getBlue() &&
            this->getGreen() == color.getGreen() &&
            this->getAlpha() == color.getAlpha());
}
