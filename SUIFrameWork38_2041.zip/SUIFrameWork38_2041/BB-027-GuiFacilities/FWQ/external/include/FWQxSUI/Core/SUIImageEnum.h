//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ImageEnum.
// !\description Header file for class SUI::ImageEnum.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIIMAGEENUM_H
#define SUIIMAGEENUM_H

#include <string>

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief This enum type is used as a container for image related enums.
 */
class ImageEnum
{
public:
    /*!
     * \brief   This enum is an exact copy of the QImage::Format (Qt 4.8) enum.
     *          The conversion is done by a simple C cast so it is imperative
     *          that the order remains the same.
     */
    enum Format {
        Format_Invalid = 0,                  //	0	The image is invalid.
        Format_Mono = 1,                     //	1	The image is stored using 1-bit per pixel. Bytes are packed with the most significant bit (MSB) first.
        Format_MonoLSB = 2,                  //	2	The image is stored using 1-bit per pixel. Bytes are packed with the less significant bit (LSB) first.
        Format_Indexed8 = 3,                 //	3	The image is stored using 8-bit indexes into a colormap.
        Format_RGB32 = 4,                    //	4	The image is stored using a 32-bit RGB format (0xffRRGGBB).
        Format_ARGB32 = 5,                   //	5	The image is stored using a 32-bit ARGB format (0xAARRGGBB).
        Format_ARGB32_Premultiplied = 6,     //	6	The image is stored using a premultiplied 32-bit ARGB format (0xAARRGGBB), i.e. the red, green, and blue channels are multiplied by the alpha component divided by 255. (If RR, GG, or BB has a higher value than the alpha channel, the results are undefined.) Certain operations (such as image composition using alpha blending) are faster using premultiplied ARGB32 than with plain ARGB32.
        Format_RGB16 = 7,                    //	7	The image is stored using a 16-bit RGB format (5-6-5).
        Format_ARGB8565_Premultiplied = 8,   //	8	The image is stored using a premultiplied 24-bit ARGB format (8-5-6-5).
        Format_RGB666 = 9,                   //	9	The image is stored using a 24-bit RGB format (6-6-6). The unused most significant bits is always zero.
        Format_ARGB6666_Premultiplied = 10,  //	10	The image is stored using a premultiplied 24-bit ARGB format (6-6-6-6).
        Format_RGB555 = 11,                  //	11	The image is stored using a 16-bit RGB format (5-5-5). The unused most significant bit is always zero.
        Format_ARGB8555_Premultiplied = 12,  //	12	The image is stored using a premultiplied 24-bit ARGB format (8-5-5-5).
        Format_RGB888 = 13,                  //	13	The image is stored using a 24-bit RGB format (8-8-8).
        Format_RGB444 = 14,                  //	14	The image is stored using a 16-bit RGB format (4-4-4). The unused bits are always zero.
        Format_ARGB4444_Premultiplied = 15   //	15	The image is stored using a premultiplied 16-bit ARGB format (4-4-4-4).
    };

    /*!
     * \brief FileType
     * The (allowed) type of image files
     */
    enum FileType {
        JPG,
        TIFF,
        BMP,
        PNG
    };

    /*!
     * \brief getFileExtension
     * Converts a FileType enumeration to a string like '.jpg' or '.png'
     * \param fileType
     * \return
     */
    static std::string getFileExtension(ImageEnum::FileType fileType);

    /*!
     * \brief AspectRatioMode
     * The aspect ratio mode enumeration
     */
    enum AspectRatioMode {
        IgnoreAspectRatio,
        KeepAspectRatio,
        KeepAspectRatioByExpanding
    };

    /*!
     * \brief TransformationMode
     * The transformation mode enumeration
     */
    enum TransformationMode {
        FastTransformation,
        SmoothTransformation
    };

};
}
#endif // SUIIMAGEENUM_H
