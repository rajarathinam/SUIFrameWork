//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::IOException.
// !\description Header file for class SUI::IOException.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIIOEXCEPTION_H
#define SUIIOEXCEPTION_H

#include "SUIException.h"

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief The IOException class
 */
class SUI_SHARED_EXPORT IOException : public Exception
{

public:
    /*!
     * \brief IOException
     * constructs an IOException with a message
     * \param msg
     */
    explicit IOException(const std::string &msg);

private:
    IOException();
};
}
#endif // SUIIOEXCEPTION_H
