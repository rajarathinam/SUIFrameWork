//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::DoubleSpinBox.
// !\description Header file for class SUI::DoubleSpinBox.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIDOUBLESPINBOX_H
#define SUIDOUBLESPINBOX_H

#include "SUIWidget.h"
#include "SUIIText.h"
#include "SUIIErrorMode.h"
#include "SUIIAlignable.h"
#include "SUIINumeric.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief Specific Interface for the DoubleSpinBox Widget
 */
class SUI_SHARED_EXPORT DoubleSpinBox : public Widget, public IErrorMode, public INumeric<double>, public IAlignable
{
public:
    virtual ~DoubleSpinBox();
    
protected:
    DoubleSpinBox();
    explicit DoubleSpinBox(const SUI::ObjectType::Type &type);

};
}

#endif // SUIDOUBLESPINBOX_H
