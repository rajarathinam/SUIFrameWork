//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::PlotDataPoint.
// !\description Header file for class SUI::PlotDataPoint.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUIPLOTDATAPOINT_H
#define SUIPLOTDATAPOINT_H

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief This PlotDataPoint type is used to describe data points for plotting curve */
class PlotDataPoint {
public:

    PlotDataPoint(double xVal, double yVal);
    /*!
     * \brief getX
     * Returns the X coordinate of the datapoint
     * \return int
     */
    double getX() const;
    /*!
     * \brief setX
     * Set the x coordinate of the datapoint
     * \param double x
     */
    void setX(double value);

    /*!
     * \brief getY
     * Returns the Y coordinate of the datapoint
     * \return int
     */
    double getY() const;

    /*!
     * \brief setY
     * Set the y coordinate of the datapoint
     * \param double y
     */
    void setY(double value);

private:
    double x;
    double y;
};
}

#endif // SUIPLOTDATAPOINT_H
