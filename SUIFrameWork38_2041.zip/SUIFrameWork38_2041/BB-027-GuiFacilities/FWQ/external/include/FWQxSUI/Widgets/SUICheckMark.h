//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::CheckMark.
// !\description Header file for class SUI::CheckMark.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUICHECKMARK_H
#define SUICHECKMARK_H

#include "SUIDeprecated.h"

#include "SUIWidget.h"
#include "SUIIColorable.h"

namespace SUI {

/*!
 * \ingroup FWQxWidgets
 *
 * \brief The CheckMark class
 */
class SUI_DEPRECATED CheckMark : public Widget, public IColorable
{
public:
    virtual ~CheckMark();
    
protected:
    CheckMark();

};
}

#endif // SUICHECKMARK_H
