//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::CheckGroupBox.
// !\description Header file for class SUI::CheckGroupBox.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUICHECKGROUPBOX_H
#define SUICHECKGROUPBOX_H

#include "SUIICheckable.h"
#include "SUIWidget.h"
#include "SUIIText.h"
#include "SUIIBGColorable.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 *
 * \brief The CheckGroupBox class
 */
class SUI_SHARED_EXPORT CheckGroupBox : public Widget, public IText, public IBGColorable, public ICheckable
{
public:
    virtual ~CheckGroupBox();

protected:
    CheckGroupBox();
    explicit CheckGroupBox(const SUI::ObjectType::Type &type);
};
}

#endif // SUICHECKGROUPBOX_H
