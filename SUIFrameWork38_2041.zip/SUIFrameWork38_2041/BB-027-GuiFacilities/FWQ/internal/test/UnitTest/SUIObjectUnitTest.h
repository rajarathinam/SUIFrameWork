#ifndef OBJECTUNITTEST_H
#define OBJECTUNITTEST_H

#include "SUIIViewableUnitTest.h"

namespace SUI {

class Object;

class ObjectUnitTest : public IViewableUnitTest
{
    Q_OBJECT
public:
     ObjectUnitTest(Object *object, QObject *parent = 0);
    virtual ~ObjectUnitTest();

private slots:
    void getId();
    void getObjectType();
    void interfaceTests();

protected:
    virtual void callInterfaceTests() {} // empty implementation

private:
    Object *object;
};

}
#endif // OBJECTUNITTEST_H
