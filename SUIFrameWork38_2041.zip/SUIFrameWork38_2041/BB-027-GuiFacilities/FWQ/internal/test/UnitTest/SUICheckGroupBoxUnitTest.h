#ifndef SUICHECKGROUPBOXUNITTEST_H
#define SUICHECKGROUPBOXUNITTEST_H

#include "SUIWidgetUnitTest.h"

namespace SUI {

class CheckGroupBox;

class CheckGroupBoxUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
     CheckGroupBoxUnitTest(CheckGroupBox *object, QObject *parent = 0);
    ~CheckGroupBoxUnitTest();

protected:
    void callInterfaceTests();

private slots:

private:
    CheckGroupBox *object;
};

}
#endif // SUICHECKGROUPBOXUNITTEST_H
