#include "SUIWebViewUnitTest.h"

SUI::WebViewUnitTest::WebViewUnitTest(SUI::WebView *object, QObject *parent) :
    WidgetUnitTest(object, parent),
    object(object)
{
}

SUI::WebViewUnitTest::~WebViewUnitTest()
{
    delete object;
}
