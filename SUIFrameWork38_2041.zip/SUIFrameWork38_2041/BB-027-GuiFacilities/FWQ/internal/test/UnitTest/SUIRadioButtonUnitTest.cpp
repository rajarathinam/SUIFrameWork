#include "SUIRadioButtonUnitTest.h"

SUI::RadioButtonUnitTest::RadioButtonUnitTest(SUI::RadioButton *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::RadioButtonUnitTest::~RadioButtonUnitTest() {
    delete object;
}
