#ifndef TABWIDGETUNITTEST_H
#define TABWIDGETUNITTEST_H


#include <QTest>
#include <QString>
#include <SUITabWidgetImpl.h>
#include <SUITabPageImpl.h>
#include <SUIObjectList.h>
#include <SUIBaseWidget.h>

class TabWidgetUnitTest : public QObject
{
    Q_OBJECT

public:
    TabWidgetUnitTest();

private Q_SLOTS:
    void    cleanupTestCase();

/// Unit testen
    // IWidgetStatus setVisible
    void    testVisibilityCase2();
    void    testVisibilityCase2_data();

    // IWidgetStatus Enabled
    void    testEnabledCase2();
    void    testEnabledCase2_data();

    // Add tabPage to tabwidget
    void    testAddTabPageCase1();
    void    testAddTabPageCase1_data();

    // setTabVisible & isTabVisible
    //FIXME
//    void    testTabVisibleCase1();
//    void    testTabVisibleCase1_data();

    // Rename TabPageTitle
    void    testTabPageTitleCase1();
    void    testTabPageTitleCase1_data();

    void    testTabPageTitleCase2();
    void    testTabPageTitleCase2_data();



/// Interface Unit Testen
    // IWidgetStatus Visibility
    void    testVisibilityCase1();
    void    testVisibilityCase1_data();

    // IWidgetStatus Enabled
    void    testEnabledCase1();
    void    testEnabledCase1_data();

    // getCurrentIndex
    void    testgetCurrentIndexCase1();
    void    testgetCurrentIndexCase1_data();


    // setTabVisible & isTabVisible
    //FIXME
//    void    testTabVisibleCase2();
//    void    testTabVisibleCase2_data();

    // Rename TabPageTitle
    void    testTabPageTitleCase3();
    void    testTabPageTitleCase3_data();

private:
    SUI::TabWidgetImpl       *mTabWidg;
    SUI::TabWidget      *mITabWidg;
    SUI::Widget       *mITabWidg_Status;
    SUI::TabPageImpl         *mTabPage;
};

#endif // TABWIDGETUNITTEST_H
