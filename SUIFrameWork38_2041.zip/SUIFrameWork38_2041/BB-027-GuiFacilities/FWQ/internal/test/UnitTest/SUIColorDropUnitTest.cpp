#include "SUIColorDropUnitTest.h"
#include "SUIColorDrop.h"
#include <QTest>
#include"SUIIColorableUnitTest.h"


SUI::ColorDropUnitTest::ColorDropUnitTest(SUI::ColorDrop *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::ColorDropUnitTest::~ColorDropUnitTest() {
    delete object;
}

void SUI::ColorDropUnitTest::callInterfaceTests() {
    //IColorable tests
    IColorableUnitTest iColorableUnitTest(object);
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Transparent));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Standard));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::White));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Red));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Green));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Blue));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Gray));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Yellow));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Orange));
}

