#ifndef SUIWEBVIEWUNITTEST_H
#define SUIWEBVIEWUNITTEST_H

#include "SUIWidgetUnitTest.h"
#include "SUIWebView.h"

namespace SUI {

class WebViewUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    WebViewUnitTest(SUI::WebView *object, QObject *parent = 0);
    virtual ~WebViewUnitTest();

private:
    WebView *object;
};

}

#endif // SUIWEBVIEWUNITTEST_H

