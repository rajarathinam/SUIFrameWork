#ifndef PROGRESSBARUNITTEST_H
#define PROGRESSBARUNITTEST_H

#include <QTest>
#include <QString>

#include <SUIBaseWidget.h>
#include <SUIProgressBarImpl.h>

#include <SUIObjectList.h>

class ProgressBarUnitTest : public QObject
{
    Q_OBJECT
public:
    ProgressBarUnitTest();

public slots:

private Q_SLOTS:
    void  initTestCase();
    void  cleanupTestCase();

    /// Unit testen
    // Visibility
    void  testVisibilityCase2();
    void  testVisibilityCase2_data();

    // Enabled
    void  testEnabledCase2();
    void  testEnabledCase2_data();

    // GetText
    void  testGetTextCase1();
    void  testGetTextCase1_data();

    // SetText
    void  testSetTextCase2();
    void  testSetTextCase2_data();

    // Set Bold
    void  testSetBoldCase1();
    void  testSetBoldCase1_data();

    // Get colors
    void  testGetColorsCase1();
    void  testGetColorsCase1_data();

    // Color set & get color
    void  testColorCase1();
    void  testColorCase1_data();

    // Disable percentage
    void  testDisablePercentageCase1();
    void  testDisablePercentageCase1_data();

    // HandleChange
    void  testHandleChangeCase1();
    void  testHandleChangeCase1_data();

    // GetOrientation
    void  testGetOrientationChangeCase1();
    void  testGetOrientationChangeCase1_data();

    // setOrientation
    void  testsetOrientationCase1();
    void  testsetOrientationCase1_data();

    /// Interface Unit Testen
    // Visibility
    void  testVisibilityCase1();
    void  testVisibilityCase1_data();

    // IWidgetStatus Enabled
    void  testEnabledCase1();
    void  testEnabledCase1_data();

    // GetText
    void  testGetTextCase2();
    void  testGetTextCase2_data();

    // SetText
    void  testSetTextCase1();
    void  testSetTextCase1_data();

    // Set Bold
    void  testSetBoldCase2();
    void  testSetBoldCase2_data();

    // Get colors
    void  testGetColorsCase2();
    void  testGetColorsCase2_data();

    // Color set & get color
    void  testColorCase2();
    void  testColorCase2_data();

    // Disable percentage
    void  testDisablePercentageCase2();
    void  testDisablePercentageCase2_data();

    // GetOrientation
    void  testGetOrientationChangeCase2();
    void  testGetOrientationChangeCase2_data();

    // setOrientation
    void  testsetOrientationCase2();
    void  testsetOrientationCase2_data();

private:
    SUI::ProgressBarImpl *mProgressWidg;
    SUI::ProgressBar *mIProgressWidg;
    SUI::Widget *mIProgressWidg_Status;
    SUI::IText *mIProgressWidg_Text;
    SUI::IColorable *mIProgressWidg_Color;
    SUI::IOrientable *mIProgressWidg_Orientation;
    QString handle;

};

#endif // PROGRESSBARUNITTEST_H
