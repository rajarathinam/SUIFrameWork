#ifndef SUITABWIDGETUNITTEST_H
#define SUITABWIDGETUNITTEST_H

#include "SUIWidgetUnitTest.h"
#include "SUITabWidget.h"

namespace SUI {

class TabWidget;

class TabWidgetUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    TabWidgetUnitTest(SUI::TabWidget *object, QObject *parent = 0);
    virtual ~TabWidgetUnitTest();

private:
    TabWidget *object;
};

}
#endif // SUITABWIDGETUNITTEST_H
