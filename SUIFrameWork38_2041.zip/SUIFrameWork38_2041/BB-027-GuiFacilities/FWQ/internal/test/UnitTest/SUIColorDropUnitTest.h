#ifndef SUICOLORDROPUNITTEST_H
#define SUICOLORDROPUNITTEST_H

#include "SUIWidgetUnitTest.h"


namespace SUI {

class ColorDrop;

class ColorDropUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
     ColorDropUnitTest(ColorDrop *object, QObject *parent = 0);
    ~ColorDropUnitTest();

protected:
    void callInterfaceTests();

private slots:

private:
    ColorDrop *object;
};

}


#endif // SUICOLORDROPUNITTEST_H
