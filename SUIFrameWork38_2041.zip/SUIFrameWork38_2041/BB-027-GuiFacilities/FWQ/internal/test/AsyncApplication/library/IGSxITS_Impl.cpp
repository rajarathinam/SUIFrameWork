/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxITS_Impl.cpp
| Author       : Thijs Jacobs
| Description  : Impementation of IGSxITS library
|
| ! \file        IGSxITS_Impl.cpp
| ! \brief       Impementation of IGSxITS library
|
|-----------------------------------------------------------------------------|
|                                                                             |
|                Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <iostream>
#include <boost/bind.hpp>

//#include "ERxEXC/ERxEXC.hpp"
//#include "FSDxCOM/FSDxCOMtyp.hpp"

//#include "IGSxER.h"
//#include "IGSxLOG.hpp"
//#include "IGSxEVENT.hpp"
#include "IGSxITS_Impl.hpp"

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/

const int MS_IN_SEC = 1000;
const int NO_ERROR = 0x0000;
const int ERROR_CODE = 0x1234;
const int OK = 0;

typedef struct
{
    std::string name;
    std::string desc;
    int initDur;
    int termDur;
} gMetaType;

typedef struct
{
    std::string sysfun;
    gMetaType driver;
} gDriverType;

gMetaType gSystem = {"EUV Source","EUV Source",40,20};

gMetaType gSysfun[] = {
    {"SF-04","Environmental Mgt",30,15},
    {"SF-15","Laser Mgt",40,20},
    {"SF-16","Tin Mgt",20,10},
    {"SF-17","Plasma & Energy Mgt",20,10},
    {"SF-18","Spectrally Pure EUV Collection Mgt",30,15},
    {"SF-19","Tin Mitigation Mgt",40,20}
};

gDriverType gDriver[] = {
    {"SF-04",{"Environmental Mgt","Environmental Mgt",10,5}},
    {"SF-04",{"Gas and Vacuum","Gas and Vacuum",10,5}},
    {"SF-04",{"HPRGA","HPRGA",20,10}},
    {"SF-04",{"Vessel Cooling","Vessel Cooling",20,10}},
    {"SF-04",{"Collector Cooling","Collector Cooling",30,15}},
    {"SF-15",{"Laser Mgt","Laser Mgt",10,5}},
    {"SF-15",{"FFA/FFM","FFA/FFM",10,5}},
    {"SF-15",{"HPAC","HPAC",20,10}},
    {"SF-15",{"HPSM","HPSM",20,10}},
    {"SF-15",{"ST","ST",30,15}},
    {"SF-15",{"BFSR","BFSR",30,15}},
    {"SF-15",{"VBE","VBE",40,20}},
    {"SF-16",{"Tin Mgt","Tin Mgt",20,10}},
    {"SF-17",{"Plasma & Energy Mgt","Plasma & Energy Mgt",10,5}},
    {"SF-17",{"PD","PD",10,5}},
    {"SF-17",{"TEC","TEC",20,10}},
    {"SF-17",{"TFM","TFM",20,10}},
    {"SF-18",{"Plasma Power Limiter","Plasma Power Limiter",30,15}},
    {"SF-19",{"Tin Debris Mgt","Tin Debris Mgt",10,5}},
    {"SF-19",{"HTVB","HTVB",10,5}},
    {"SF-19",{"Vanes","Vanes",20,10}},
    {"SF-19",{"Heated Shroud","Heated Shroud",20,10}},
    {"SF-19",{"Optics Lifetime Mgt","Optics Lifetime Mgt",30,15}},
    {"SF-19",{"Metrology Cleaning","Metrology Cleaning",30,15}},
    {"SF-19",{"Collector Cleaning","Collector Cleaning",40,20}}
};

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
// instance
IGSxITS::InitTerminate* IGSxITS::InitTerminate::instance = IGSxITS::InitTerminate_Impl::getInstance();

IGSxITS::InitTerminate_Impl::InitTerminate_Impl() :
    m_initializeSystemCompletedCb(NULL),
    m_initializeDriversCompletedCb(NULL),
    m_terminateSystemCompletedCb(NULL),
    m_terminateDriversCompletedCb(NULL),
    m_driverStatusChangedCb(NULL),
    m_driver(NULL),
    m_timer(SUI::Timer::createTimer()),
    m_elapsedTime(0)
{
    srand(time(NULL)); // init random seed
    m_timer->setInterval(MS_IN_SEC);
    m_timer->setSingleShot(false);

    for (size_t i = 0; i < sizeof(gDriver) / sizeof(*gDriver); i++)
    {
        gMetaType* driver = &gDriver[i].driver;
        m_drivers.push_back(Driver(driver->name, driver->desc, driver->initDur, driver->termDur));
    }
}


IGSxITS::InitTerminate_Impl::~InitTerminate_Impl()
{
}

IGSxITS::Driver &IGSxITS::InitTerminate_Impl::driver(const std::string &driverName)
{
    for (unsigned i = 0; i < m_drivers.size(); i++)
    {
        if (driverName == m_drivers[i].name())
        {
            return m_drivers[i];
        }
    }
    assert(false);
}

IGSxITS::InitTerminate* IGSxITS::InitTerminate_Impl::getInstance()
{
    static InitTerminate_Impl _instance;
    return &_instance;
}

// meta data requests
IGSxITS::MetaDescriptions IGSxITS::InitTerminate_Impl::getSysfuns()
{
    std::cout << "getSysfuns" << std::endl;
    MetaDescriptions sysfuns;
    for (size_t i = 0; i < sizeof(gSysfun) / sizeof(*gSysfun); i++)
    {
        gMetaType* sysfun = &gSysfun[i];
        sysfuns.push_back(MetaDescription(sysfun->name, sysfun->desc));
    }
    return sysfuns;
}

IGSxITS::MetaDescriptions IGSxITS::InitTerminate_Impl::getDrivers(const std::string& sysfunName)
{
    std::cout << "getDrivers" << std::endl;
    MetaDescriptions drivers;
    for (size_t i = 0; i < sizeof(gDriver) / sizeof(*gDriver); i++)
    {
        if (sysfunName == gDriver[i].sysfun)
        {
            gMetaType* driver = &gDriver[i].driver;
            drivers.push_back(MetaDescription(driver->name, driver->desc));
        }
    }
    return drivers;
}
    
// init-terminate
void IGSxITS::InitTerminate_Impl::initializeSystem(const InitializeCompletedCallback& cb)
{
    std::cout << "initializeSystem++" << std::endl;
    m_initializeSystemCompletedCb = cb;

    bool hasError = false;
    for (unsigned i = 0; i < m_drivers.size(); i++)
    {
        Driver& driver = m_drivers[i];
        if (DriverState::DS_INITIALIZED != driver.driverState())
        {
            if (NO_ERROR != driver.error())
            {
                hasError = true;
            }
            driver.setDriverState(DriverState::DS_INITIALIZING);
            driver.setError(NO_ERROR);
        }
    }

    if (!hasError) {
        // inject an error to a random driver
        m_drivers[rand() % m_drivers.size()].setError(ERROR_CODE);
    }

    on_initializeSystemCompleted();
//    m_timer->timeout = boost::bind(&InitTerminate_Impl::on_initializeSystemCompleted, this);
//    m_elapsedTime = 0;
//    m_timer->start(1);
    std::cout << "initializeSystem--" << std::endl;
}

void IGSxITS::InitTerminate_Impl::initializeDrivers(const DriverNames& /*driverNames*/, const InitializeCompletedCallback& /*cb*/)
{
    std::cout << "initializeDrivers" << std::endl;
}

void IGSxITS::InitTerminate_Impl::terminateSystem(const TerminateCompletedCallback& cb)
{
    std::cout << "terminateSystem" << std::endl;
    m_terminateSystemCompletedCb = cb;

    for (unsigned i = 0; i < m_drivers.size(); i++)
    {
        m_drivers[i].setDriverState(DriverState::DS_TERMINATING);
    }
    on_terminateSystemCompleted();

//    m_timer->timeout = boost::bind(&IGSxITS::InitTerminate_Impl::on_terminateSystemCompleted, this);
//    m_elapsedTime = 0;
//    m_timer->start(1);
    std::cout << "terminateSystem--" << std::endl;
}

void IGSxITS::InitTerminate_Impl::terminateDrivers(const DriverNames& /*driverNames*/, const TerminateCompletedCallback& /*cb*/)
{
    std::cout << "terminateDrivers" << std::endl;
}

IGSxITS::DriverStatus IGSxITS::InitTerminate_Impl::getDriverStatus(const std::string& driverName)
{
    std::cout << "getDriverStatus" << std::endl;
    return driver(driverName).driverStatus();
}

void IGSxITS::InitTerminate_Impl::subscribeToDriverStatusChanged(const DriverStatusChangedCallback& cb)
{
    std::cout << "subscribeToDriverStatusChanged" << std::endl;
    m_driverStatusChangedCb = cb;
}

void IGSxITS::InitTerminate_Impl::unsubscribeToDriverStatusChanged()
{
    std::cout << "unsubscribeToDriverStatusChanged" << std::endl;
    m_driverStatusChangedCb = NULL;
}

void IGSxITS::InitTerminate_Impl::on_driverStatusChanged(int result, const std::string& driverName)
{
    std::cout << "on_driverStatusChanged" << std::endl;
    try
    {
        if (result == OK)
        {
            DriverStatus status(DriverState::DS_TERMINATED);
            std::cout << "Status of driver" << driverName << "changed to " << std::endl;
            SUI::ExternalEventHandler::raiseEvent(new SUI::ExternalEvent<const std::string&, const DriverStatus&>(m_driverStatusChangedCb, driverName, status));
        }
        else
        {
            std::cout << "Error while receiving driver status changed event"<< std::endl;
        }
    }
    catch (...)
    {
        // don't throw exception in callback function
    }
}

// function completion notifications
void IGSxITS::InitTerminate_Impl::on_initializeSystemCompleted()
{
    std::cout << "on_initializeSystemCompleted" << std::endl;
    int result = OK;
    SUI::ExternalEventHandler::raiseEvent(new SUI::ExternalEvent<int>(m_initializeSystemCompletedCb, result));
}

void IGSxITS::InitTerminate_Impl::on_initializeDriversCompleted()
{
    std::cout << "on_initializeDriversCompleted" << std::endl;
    int result = OK;
    SUI::ExternalEventHandler::raiseEvent(new SUI::ExternalEvent<int>(m_initializeDriversCompletedCb, result));
}

void IGSxITS::InitTerminate_Impl::on_terminateSystemCompleted()
{
    std::cout << "on_terminateSystemCompleted" << std::endl;
    int result = OK;
    SUI::ExternalEventHandler::raiseEvent(new SUI::ExternalEvent<int>(m_terminateSystemCompletedCb, result));
}

void IGSxITS::InitTerminate_Impl::on_terminateDriversCompleted()
{
    std::cout << "on_terminateDriversCompleted" << std::endl;
    int result = OK;
    SUI::ExternalEventHandler::raiseEvent(new SUI::ExternalEvent<int>(m_terminateDriversCompletedCb, result));
}

// exception handling
void IGSxITS::InitTerminate_Impl::handleException(const std::string& err)
{
    std::cout << "handleException" << std::endl;
    throw IGS::Exception(err);
}

