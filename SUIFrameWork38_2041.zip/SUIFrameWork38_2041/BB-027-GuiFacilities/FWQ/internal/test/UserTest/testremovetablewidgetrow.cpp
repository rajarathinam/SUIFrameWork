#include "testremovetablewidgetrow.h"

#include <SUIINumeric.h>
#include <SUITableWidget.h>
#include <SUIDialogImpl.h>

testRemoveTableWidgetRow::testRemoveTableWidgetRow(const QString aSourceWidgetID, const QString aTargetWidgetID , SUI::DialogImpl *apGui) :
    mTargetWidgetid(aTargetWidgetID),
    mSourceWidgetid(aSourceWidgetID),
    mpGui(apGui)
{
}

void testRemoveTableWidgetRow::handleClicked()
{
    SUI::INumeric<int> *widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<int>>(mSourceWidgetid.toStdString());
    SUI::TableWidget  *tableWidget = mpGui->getObjectList()->getObject<SUI::TableWidget>(mTargetWidgetid.toStdString());
    if (widgetNum && tableWidget)
    {
        int val = widgetNum->getValue();
        tableWidget->removeRow(val);
    }
}
