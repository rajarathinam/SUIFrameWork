#ifndef TESTFIRLEBROWSECALLBACK_H
#define TESTFIRLEBROWSECALLBACK_H

#include <QString>



namespace SUI {
class DialogImpl;
}

class testFileBrowserCallback
{
    QString mTargetWidgetid;
    QString mSourceWidgetid;
    SUI::DialogImpl  *mpGui;
public:
    testFileBrowserCallback(QString aSourceWidgetID, QString aTargetWidgetID , SUI::DialogImpl *apGui);
    void handleClicked();
};
#endif // TESTFIRLEBROWSECALLBACK_H
