#ifndef GRAPHICSVIEWTEST_H
#define GRAPHICSVIEWTEST_H

#include <QString>

namespace SUI {
class DialogImpl;
class GraphicsView;
class DoubleSpinBox;
}

class GraphicsSceneMouseEventTest;

class GraphicsViewTest
{
public:

    GraphicsViewTest(SUI::DialogImpl *dialog);
    ~GraphicsViewTest();

private:
    SUI::DialogImpl *dialog;
    SUI::GraphicsView *graphicsView;
    GraphicsSceneMouseEventTest *graphicsSceneMouseEventTest;

    void onScrollBarsEnable(bool checked);
    void onEnableChecked(bool checked);
    void onVisibleChecked(bool checked);
    void onZoomButtonClicked();
    void onCropZoomButtonClicked();
};

#endif // GRAPHICSVIEWTEST_H
