#ifndef testListViewSetup_H
#define testListViewSetup_H

#include <SUIListViewImpl.h>


#include "SUIDialogImpl.h"


class testListViewSetup
{
public:
    enum test { REMOVE, ALL };
    testListViewSetup(QString aSourceWidgetID, QString aTargetWidgetID , SUI::DialogImpl *apGui, test aMode);
    void handleClicked();

private:
    QString mTargetWidgetid;
    QString mSourceWidgetid;
    SUI::DialogImpl  *mpGui;
    test    mMode;
};

#endif // testListViewSetup_H
