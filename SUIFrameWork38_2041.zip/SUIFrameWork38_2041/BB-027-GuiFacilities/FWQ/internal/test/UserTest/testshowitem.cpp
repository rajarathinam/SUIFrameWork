#include "testshowitem.h"

#include <SUIIViewable.h>
#include <SUIIText.h>
#include <SUIDialogImpl.h>

testShowItem::testShowItem(QString aDropDownText, SUI::DialogImpl *apGui):
    mDropDownText(aDropDownText),
    mpGui(apGui)
{
}

void testShowItem::handleClicked() {
    SUI::IText *widgetText = mpGui->getObjectList()->getObject<SUI::IText>(mDropDownText.toStdString());
    if (widgetText) {
        QString text3 = QString::fromStdString(widgetText->getText());
        SUI::IViewable *widgetShow = mpGui->getObjectList()->getObject<SUI::IViewable>(text3.toStdString());
        if (widgetShow) widgetShow->show();
    }
}
