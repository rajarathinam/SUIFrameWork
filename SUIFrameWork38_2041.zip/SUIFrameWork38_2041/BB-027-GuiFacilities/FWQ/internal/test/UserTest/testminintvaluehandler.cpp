#include "testminintvaluehandler.h"
#include "SUISpinBox.h"

testMinIntValueHandler::testMinIntValueHandler(QString aSourceWidgetID, QString aTargetWidgetID, SUI::DialogImpl *apGui) :
    mSourceWidgetid(aSourceWidgetID),
    mTargetWidgetid(aTargetWidgetID),
    mpGui(apGui)
{
}

void testMinIntValueHandler::handleValueChanged()
{
    SUI::INumeric<int> *widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<int>>(mSourceWidgetid.toStdString());
    if (widgetNum)
    {
        int val = widgetNum->getValue();
        widgetNum = mpGui->getObjectList()->getObject<SUI::INumeric<int>>(mTargetWidgetid.toStdString());
        if (widgetNum)
        {
            widgetNum->setMinValue(val);
        }
    }
}

