#include "GraphicsSvgItemTest.h"
#include <SUIDialog.h>
#include <SUIObjectFactory.h>
#include <SUIObjectList.h>

#include <SUIColorCrossDrop.h>
#include <SUIDropDown.h>
#include <SUISpinBox.h>
#include <SUIDoubleSpinBox.h>
#include <SUICheckBox.h>
#include <SUIButton.h>
#include <SUILineEdit.h>
#include <SUIGraphicsSvgItem.h>
#include <SUIGraphicsScene.h>
#include <SUIGraphicsView.h>

#include <boost/bind.hpp>

#include <assert.h>

#include <QDebug>
#include <QStringList>

GraphicsSvgItemTest::GraphicsSvgItemTest(SUI::Dialog *dialog) :
    dialog(dialog),
    graphicsView(dialog->getObjectList()->getObject<SUI::GraphicsView>("imv939")),
    addSvgItemButton(dialog->getObjectList()->getObject<SUI::Button>("btn940")),
    setSvgImageButton(dialog->getObjectList()->getObject<SUI::Button>("btn941")),
    setElementIdButton(dialog->getObjectList()->getObject<SUI::Button>("btn966")),
    setColorButton(dialog->getObjectList()->getObject<SUI::Button>("btn946")),
    setColorLineEdit(dialog->getObjectList()->getObject<SUI::LineEdit>("lne948")),
    setBorderColorButton(dialog->getObjectList()->getObject<SUI::Button>("btn950")),
    setBorderColorLineEdit(dialog->getObjectList()->getObject<SUI::LineEdit>("lne952")),
    setElideTextButton(dialog->getObjectList()->getObject<SUI::Button>("btn1028")),
    resetElideTextButton(dialog->getObjectList()->getObject<SUI::Button>("btn1023")),
    getTextButton(dialog->getObjectList()->getObject<SUI::Button>("btn1026")),
    setTextButton(dialog->getObjectList()->getObject<SUI::Button>("btn958")),
    setTextLineEdit(dialog->getObjectList()->getObject<SUI::LineEdit>("lne960")),
    getAllElementIdButton(dialog->getObjectList()->getObject<SUI::Button>("btn943")),
    setBorderWidthButton(dialog->getObjectList()->getObject<SUI::Button>("btn969")),
    borderWidth(dialog->getObjectList()->getObject<SUI::SpinBox>("isb971")),
    setTextColorButton(dialog->getObjectList()->getObject<SUI::Button>("btn954")),
    setToolTipButton(dialog->getObjectList()->getObject<SUI::Button>("btn962")),
    setDoubleClickButton(dialog->getObjectList()->getObject<SUI::Button>("btn974")),
    setScaleFactorButton(dialog->getObjectList()->getObject<SUI::Button>("btn1020")),
    scaleFactor(dialog->getObjectList()->getObject<SUI::DoubleSpinBox>("dsb1022"))
{
    assert(dialog);
    assert(graphicsView);
    assert(addSvgItemButton);
    assert(setSvgImageButton);
    assert(setElementIdButton);
    assert(setColorButton);
    assert(setColorLineEdit);
    assert(setBorderColorButton);
    assert(setBorderColorLineEdit);
    assert(setElideTextButton);
    assert(resetElideTextButton);
    assert(getTextButton);
    assert(getTextButton);
    assert(setTextButton);
    assert(setTextLineEdit);
    assert(getAllElementIdButton);
    assert(setBorderWidthButton);
    assert(borderWidth);
    assert(setTextColorButton);
    assert(setToolTipButton);
    assert(setDoubleClickButton);
    assert(setScaleFactorButton);
    assert(scaleFactor);

    addSvgItemButton->clicked = boost::bind(&GraphicsSvgItemTest::onAddSvgItemClicked, this);
    setSvgImageButton->clicked = boost::bind(&GraphicsSvgItemTest::onSetSvgImageClicked, this);
    setElementIdButton->clicked = boost::bind(&GraphicsSvgItemTest::onSetElementIdClicked, this);

    setColorButton->clicked = boost::bind(&GraphicsSvgItemTest::onSetColorClicked,this);
    setBorderColorButton->clicked = boost::bind(&GraphicsSvgItemTest::onSetBorderColorClicked,this);
    setElideTextButton->clicked = boost::bind(&GraphicsSvgItemTest::onSetElideTextClicked,this);
    resetElideTextButton->clicked = boost::bind(&GraphicsSvgItemTest::onResetElideTextClicked,this);
    setTextButton->clicked = boost::bind(&GraphicsSvgItemTest::onSetTextClicked,this);
    getTextButton->clicked = boost::bind(&GraphicsSvgItemTest::onGetTextClicked,this);
    getAllElementIdButton->clicked = boost::bind(&GraphicsSvgItemTest::onGetAllElementIdClicked, this);
    borderWidth->valueChanged = boost::bind(&GraphicsSvgItemTest::onSetBorderWidthClicked, this);
    setBorderWidthButton->clicked = boost::bind(&GraphicsSvgItemTest::onSetBorderWidthClicked, this);
    setTextColorButton->clicked = boost::bind(&GraphicsSvgItemTest::onSetTextColorClicked, this);
    setToolTipButton->clicked = boost::bind(&GraphicsSvgItemTest::onSetToolTipClicked, this);
    setDoubleClickButton->clicked = boost::bind(&GraphicsSvgItemTest::onSetSubscribeDoubleClick, this);
    setScaleFactorButton->clicked = boost::bind(&GraphicsSvgItemTest::onSetScaleFactorClicked , this);

    borderWidth->setStepSize(1);
    borderWidth->setMaxValue(10);
    borderWidth->setMinValue(1);
}

void GraphicsSvgItemTest::onAddSvgItemClicked()
{
    SUI::GraphicsItem *graphicsItem = NULL;
    graphicsItem = dialog->getObjectList()->getObject<SUI::GraphicsItem>("GraphicsSvgItem");
    if (graphicsItem) return;

    SUI::GraphicsSvgItem *graphicsSvgItem = SUI::ObjectFactory::getInstance()->createGraphicsItem<SUI::GraphicsSvgItem>();
    graphicsItem = graphicsSvgItem;

    graphicsItem->setId("GraphicsSvgItem");
    graphicsItem->setVisible(true);
    dialog->getObjectList()->addObject(graphicsItem->getId(), graphicsItem);
    graphicsView->getGraphicsScene()->addItem(graphicsItem);
}

void GraphicsSvgItemTest::onSetSvgImageClicked()
{
    SUI::GraphicsItem  *graphicsItem = dialog->getObjectList()->getObject<SUI::GraphicsItem>("GraphicsSvgItem");
    if (!graphicsItem) return;
    SUI::GraphicsSvgItem *graphicsSvgItem = dynamic_cast<SUI::GraphicsSvgItem*>(graphicsItem);
    if (!graphicsSvgItem) return;

    graphicsSvgItem->setImage(":/testimages/testSvgImage.svg");
}

void GraphicsSvgItemTest::onSetElementIdClicked()
{

    SUI::GraphicsItem  *graphicsItem = dialog->getObjectList()->getObject<SUI::GraphicsItem>("GraphicsSvgItem");
    if (!graphicsItem) return;
    SUI::GraphicsSvgItem *graphicsSvgItem = dynamic_cast<SUI::GraphicsSvgItem*>(graphicsItem);
    if (!graphicsSvgItem) return;

    SUI::IText *widgetidText = dialog->getObjectList()->getObject<SUI::IText>("lne1032");
    if(widgetidText)graphicsSvgItem->setElementId(widgetidText->getText());
}

void GraphicsSvgItemTest::onSetColorClicked()
{
    SUI::GraphicsItem  *graphicsItem = dialog->getObjectList()->getObject<SUI::GraphicsItem>("GraphicsSvgItem");
    if (!graphicsItem) return;
    SUI::GraphicsSvgItem *graphicsSvgItem = dynamic_cast<SUI::GraphicsSvgItem*>(graphicsItem);
    if (!graphicsSvgItem) return;

    SUI::IColorable *setColorSelector = dialog->getObjectList()->getObject<SUI::IColorable>("cdb947");
    if(setColorSelector){
    graphicsSvgItem->setElementColor(setColorLineEdit->getText(), setColorSelector->getColor());
    }
}

void GraphicsSvgItemTest::onSetBorderColorClicked()
{
    SUI::GraphicsItem  *graphicsItem = dialog->getObjectList()->getObject<SUI::GraphicsItem>("GraphicsSvgItem");
    if (!graphicsItem) return;
    SUI::GraphicsSvgItem *graphicsSvgItem = dynamic_cast<SUI::GraphicsSvgItem*>(graphicsItem);
    if (!graphicsSvgItem) return;

    SUI::IColorable *setBorderColorSelector = dialog->getObjectList()->getObject<SUI::IColorable>("cdb951");
    if(setBorderColorSelector){
        graphicsSvgItem->setElementBorderColor(setBorderColorLineEdit->getText(), setBorderColorSelector->getColor());
    }
}

void GraphicsSvgItemTest::onSetTextClicked()
{
    SUI::GraphicsItem  *graphicsItem = dialog->getObjectList()->getObject<SUI::GraphicsItem>("GraphicsSvgItem");
    if (!graphicsItem) return;
    SUI::GraphicsSvgItem *graphicsSvgItem = dynamic_cast<SUI::GraphicsSvgItem*>(graphicsItem);
    if (!graphicsSvgItem) return;

    SUI::IText *widgetidText = dialog->getObjectList()->getObject<SUI::IText>("lne1029");
    if(widgetidText)graphicsSvgItem->setElementText(setTextLineEdit->getText(), widgetidText->getText());
}

void GraphicsSvgItemTest::onGetAllElementIdClicked()
{
    SUI::GraphicsItem  *graphicsItem = dialog->getObjectList()->getObject<SUI::GraphicsItem>("GraphicsSvgItem");
    if (!graphicsItem) return;
    SUI::GraphicsSvgItem *graphicsSvgItem = dynamic_cast<SUI::GraphicsSvgItem*>(graphicsItem);
    if (!graphicsSvgItem) return;

    QStringList tagList;
    foreach(std::string item, graphicsSvgItem->getElementIdList())
    {
        tagList.append(QString::fromStdString(item));
    }

    SUI::IText *widgetidText = dialog->getObjectList()->getObject<SUI::IText>("txa944");
    QString tagValues;
    if(widgetidText){
        tagValues = tagList.join(";");
        widgetidText->clearText();
        widgetidText->setText(tagValues.toStdString());
    }
}

void GraphicsSvgItemTest::onSetBorderWidthClicked()
{
    SUI::GraphicsItem  *graphicsItem = dialog->getObjectList()->getObject<SUI::GraphicsItem>("GraphicsSvgItem");
    if (!graphicsItem) return;
    SUI::GraphicsSvgItem *graphicsSvgItem = dynamic_cast<SUI::GraphicsSvgItem*>(graphicsItem);
    if (!graphicsSvgItem) return;

    SUI::IText *widgetidText = dialog->getObjectList()->getObject<SUI::IText>("lne970");
    int value = borderWidth->getValue();
    if(widgetidText ) graphicsSvgItem->setElementBorderWidth(widgetidText->getText(), value);
}

void GraphicsSvgItemTest::onSetTextColorClicked()
{
    SUI::GraphicsItem  *graphicsItem = dialog->getObjectList()->getObject<SUI::GraphicsItem>("GraphicsSvgItem");
    if (!graphicsItem) return;
    SUI::GraphicsSvgItem *graphicsSvgItem = dynamic_cast<SUI::GraphicsSvgItem*>(graphicsItem);
    if (!graphicsSvgItem) return;

    SUI::IText *widgetidText = dialog->getObjectList()->getObject<SUI::IText>("lne956");
    SUI::IColorable *widgetColor = dialog->getObjectList()->getObject<SUI::IColorable>("cdb955");
    if(widgetidText && widgetColor) {
        graphicsSvgItem->setElementTextColor(widgetidText->getText(), widgetColor->getColor());
    }
}

void GraphicsSvgItemTest::onSetToolTipClicked()
{
    SUI::GraphicsItem  *graphicsItem = dialog->getObjectList()->getObject<SUI::GraphicsItem>("GraphicsSvgItem");
    if (!graphicsItem) return;
    SUI::GraphicsSvgItem *graphicsSvgItem = dynamic_cast<SUI::GraphicsSvgItem*>(graphicsItem);
    if (!graphicsSvgItem) return;

    SUI::IText *widgetidText = dialog->getObjectList()->getObject<SUI::IText>("lne963");
    SUI::IText *widgetidTextarea = dialog->getObjectList()->getObject<SUI::IText>("lne1031");
    if(widgetidText && widgetidTextarea) {
        graphicsSvgItem->setElementToolTip(widgetidText->getText(), widgetidTextarea->getText());
    }
}

void GraphicsSvgItemTest::onSubscribeDoubleClicked(const std::string &str) {
    QString Str = QString("Clicked %1 element").arg(QString::fromStdString(str));
    SUI::IText *widgetidText = dialog->getObjectList()->getObject<SUI::IText>("lbl974");
    if(widgetidText != NULL) widgetidText->setText(Str.toStdString());
}

void GraphicsSvgItemTest::onSubscribeDoubleClicked_shape106(const std::string &str) {
    QString Str = QString("shape106-1 element clicked!!! %1").arg(QString::fromStdString(str));
    SUI::IText *widgetidText = dialog->getObjectList()->getObject<SUI::IText>("lbl974");
    if(widgetidText != NULL) {
        widgetidText->clearText();
        widgetidText->setText(Str.toStdString());
    }
}

void GraphicsSvgItemTest::onSubscribeDoubleClicked_shape107(const std::string &str) {
    QString Str = QString("shape107-4 element clicked!!! %1").arg(QString::fromStdString(str));
    SUI::IText *widgetidText = dialog->getObjectList()->getObject<SUI::IText>("lbl974");
    if(widgetidText != NULL) {
        widgetidText->clearText();
        widgetidText->setText(Str.toStdString());
    }
}

void GraphicsSvgItemTest::onSubscribeDoubleClicked_shape148( const std::string &str) {
    QString Str = QString("shape148-91 element clicked!!! %1").arg(QString::fromStdString(str));
    SUI::IText *widgetidText = dialog->getObjectList()->getObject<SUI::IText>("lbl974");
    if(widgetidText != NULL) {
        widgetidText->clearText();
        widgetidText->setText(Str.toStdString());
    }
}
void GraphicsSvgItemTest::onSetSubscribeDoubleClick() {
    SUI::GraphicsItem  *graphicsItem = dialog->getObjectList()->getObject<SUI::GraphicsItem>("GraphicsSvgItem");
    if (!graphicsItem) return;
    SUI::GraphicsSvgItem *graphicsSvgItem = dynamic_cast<SUI::GraphicsSvgItem*>(graphicsItem);
    if (!graphicsSvgItem) return;

    boost::function<void (const std::string &)> f1( boost::bind( &GraphicsSvgItemTest::onSubscribeDoubleClicked, this, _1 ) );
    boost::function<void (const std::string &)> f2( boost::bind( &GraphicsSvgItemTest::onSubscribeDoubleClicked_shape106, this, _1 ) );
    boost::function<void (const std::string &)> f3( boost::bind( &GraphicsSvgItemTest::onSubscribeDoubleClicked_shape107, this, _1 ) );
    boost::function<void (const std::string &)> f4( boost::bind( &GraphicsSvgItemTest::onSubscribeDoubleClicked_shape148, this, _1 ) );
    foreach(std::string item, graphicsSvgItem->getElementIdList())
    {
        if(item == "shape106-1") {
            graphicsSvgItem->setElementToDoublClickEvent(item, f2);
        }
        else if(item == "shape107-4") {
            graphicsSvgItem->setElementToDoublClickEvent(item, f3);
        }
        else if(item == "shape148-91") {
            graphicsSvgItem->setElementToDoublClickEvent(item, f4);
        }
        else{
            graphicsSvgItem->setElementToDoublClickEvent(item, f1);
        }
    }
}


void GraphicsSvgItemTest::onSetScaleFactorClicked()
{
    graphicsView->setScaleFactor(scaleFactor->getValue());

    // Verify if the scale factor has been set
    SUI::IText *statusBar = dialog->getObjectList()->getObject<SUI::IText>( "txaStatus" );
    statusBar->setText(QString("Scale factor: %1").arg(QString::number(graphicsView->getScaleFactor(), 'g', 5 )).toStdString());
}

void GraphicsSvgItemTest::onGetTextClicked()
{
    SUI::GraphicsItem  *graphicsItem = dialog->getObjectList()->getObject<SUI::GraphicsItem>("GraphicsSvgItem");
    if (!graphicsItem) return;
    SUI::GraphicsSvgItem *graphicsSvgItem = dynamic_cast<SUI::GraphicsSvgItem*>(graphicsItem);
    if (!graphicsSvgItem) return;

    SUI::IText *dispWidget = dialog->getObjectList()->getObject<SUI::IText>("lbl1029");
    SUI::IText *idWidget = dialog->getObjectList()->getObject<SUI::IText>("lne1027");
    if(dispWidget && idWidget) {
        dispWidget->clearText();
        dispWidget->setText(graphicsSvgItem->getElementText(idWidget->getText()));
    }
}

void GraphicsSvgItemTest::onSetElideTextClicked()
{
    SUI::GraphicsItem  *graphicsItem = dialog->getObjectList()->getObject<SUI::GraphicsItem>("GraphicsSvgItem");
    if (!graphicsItem) return;
    SUI::GraphicsSvgItem *graphicsSvgItem = dynamic_cast<SUI::GraphicsSvgItem*>(graphicsItem);
    if (!graphicsSvgItem) return;

    SUI::INumeric<int> *maxwidth = dialog->getObjectList()->getObject<SUI::INumeric<int>>("isb1029");
    graphicsSvgItem->elideText(maxwidth->getValue());
}

void GraphicsSvgItemTest::onResetElideTextClicked()
{
    SUI::GraphicsItem  *graphicsItem = dialog->getObjectList()->getObject<SUI::GraphicsItem>("GraphicsSvgItem");
    if (!graphicsItem) return;
    SUI::GraphicsSvgItem *graphicsSvgItem = dynamic_cast<SUI::GraphicsSvgItem*>(graphicsItem);
    if (!graphicsSvgItem) return;

    graphicsSvgItem->resetElideText();
}

