#include "testFont.h"

#include <SUILabel.h>
#include <SUIDialogImpl.h>
#include <SUIDropDown.h>

testFontSize::testFontSize(QString aTargetWidgetID, QString aDropDownText, SUI::DialogImpl *apGui) :
    mTargetWidgetid(aTargetWidgetID),
    mDropDownText(aDropDownText),
    mpGui(apGui)
{
}

void testFontSize::handleClicked() {
    SUI::DropDown *widgetText = mpGui->getObjectList()->getObject<SUI::DropDown>(mDropDownText.toStdString());
    if (widgetText) {
        std::string text3 = widgetText->getSelectedItems().front();
        SUI::Label *lbl = mpGui->getObjectList()->getObject<SUI::Label>(mTargetWidgetid.toStdString());
        if (lbl) lbl->setFontSize(SUI::FontSizeEnum::fromString(text3));
    }
}
