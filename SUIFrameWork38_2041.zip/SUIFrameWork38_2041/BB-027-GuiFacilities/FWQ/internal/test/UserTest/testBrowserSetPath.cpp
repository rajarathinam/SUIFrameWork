#include "testBrowserSetPath.h"

#include <SUIIText.h>
#include <SUIFileDialog.h>
#include <SUIDialogImpl.h>

testBrowserSetPath::testBrowserSetPath(QString aSourceWidgetID, QString aTargetWidgetID, SUI::DialogImpl *apGui):
    mTargetWidgetid(aTargetWidgetID),
    mSourceWidgetid(aSourceWidgetID),
    mpGui(apGui)
{
}

void testBrowserSetPath::handleClicked()
{
    SUI::IText *textWidget = mpGui->getObjectList()->getObject<SUI::IText>(mSourceWidgetid.toStdString());
    if (textWidget)
    {
        std::string text = textWidget->getText();
        SUI::FileDialog *fbrdialog = mpGui->getObjectList()->getObject<SUI::FileDialog>(mTargetWidgetid.toStdString());
        if (fbrdialog)
        {
            fbrdialog->setDirectory(text);
        }
    }
}


testBrowserSetRootPath::testBrowserSetRootPath(QString aSourceWidgetID, QString aTargetWidgetID , SUI::DialogImpl *apGui) :
    mTargetWidgetid(aTargetWidgetID),
    mSourceWidgetid(aSourceWidgetID),
    mpGui(apGui)
{
}

void testBrowserSetRootPath::handleClicked()
{
    SUI::IText *textWidget = mpGui->getObjectList()->getObject<SUI::IText>(mSourceWidgetid.toStdString());
    if (textWidget)
    {
        QString text = QString::fromStdString(textWidget->getText());
        SUI::FileDialog *fbrdialog = mpGui->getObjectList()->getObject<SUI::FileDialog>(mTargetWidgetid.toStdString());
        if (fbrdialog)
        {
            fbrdialog->setRootDirectory(text.toStdString());
        }
    }
}

