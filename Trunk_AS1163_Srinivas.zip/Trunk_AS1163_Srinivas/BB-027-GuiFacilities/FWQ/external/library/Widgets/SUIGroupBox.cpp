//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for GroupBox.
// !\description Class implementation file for GroupBox.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "FWQxWidgets/SUIGroupBox.h"

#include "FWQxCore/SUIObjectFactory.h"

SUI::GroupBox::GroupBox() : 
    Widget(SUI::ObjectType::GroupBox)
{
}

SUI::GroupBox::GroupBox(const SUI::ObjectType::Type &type) : 
    Widget(type)
{
}

SUI::GroupBox::~GroupBox()
{
}
