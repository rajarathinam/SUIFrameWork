//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for MessageBox.
// !\description Class implementation file for MessageBox.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#include "FWQxWidgets/SUIMessageBox.h"

#include <QWidget>
#include <QMessageBox>
#include <QPushButton>
#include <boost/foreach.hpp>

#include "SUIBaseWidget.h"
#include "FWQxCore/SUIObjectFactory.h"
#include "SUIStyleSheet.h"

SUI::MessageBox::MessageBox() : 
    Widget(SUI::ObjectType::MessageBox) 
{       
}

SUI::MessageBox::~MessageBox()
{
}

void SUI::MessageBox::about(SUI::Widget *parent, const std::string &title, const std::string &text) {
    QMessageBox::about(static_cast<QWidget*>(getParent(parent)),QString::fromStdString(title),QString::fromStdString(text));
}

SUI::StandardButtonEnum::Button SUI::MessageBox::critical(
        SUI::Widget *parent, const std::string &title, const std::string &text,
        StandardButtonEnum::Buttons buttons, StandardButtonEnum::Button defaultButton) {

    return static_cast<StandardButtonEnum::Button>(QMessageBox::critical(static_cast<QWidget*>(getParent(parent)),QString::fromStdString(title),QString::fromStdString(text),(QMessageBox::StandardButtons)buttons,(QMessageBox::StandardButton)defaultButton));
}

SUI::StandardButtonEnum::Button SUI::MessageBox::information(
        SUI::Widget *parent, const std::string &title, const std::string &text,
        StandardButtonEnum::Buttons buttons, StandardButtonEnum::Button defaultButton) {

    return static_cast<StandardButtonEnum::Button>(QMessageBox::information(static_cast<QWidget*>(getParent(parent)),QString::fromStdString(title),QString::fromStdString(text),(QMessageBox::StandardButtons)buttons,(QMessageBox::StandardButton)defaultButton));
}

SUI::StandardButtonEnum::Button SUI::MessageBox::message(
        SUI::Widget *parent, const std::string &title, const std::string &text,
        SUI::StandardButtonEnum::Buttons buttons, SUI::StandardButtonEnum::Button defaultButton) {

    QMessageBox messageBox(static_cast<QWidget*>(getParent(parent)));
    messageBox.setWindowTitle(QString::fromStdString(title));
    messageBox.setText(QString::fromStdString(text));
    messageBox.setStandardButtons((QMessageBox::StandardButtons)buttons);
    messageBox.setDefaultButton((QMessageBox::StandardButton)defaultButton);
    messageBox.setIcon(QMessageBox::NoIcon);
    messageBox.exec();
    return (StandardButtonEnum::Button)messageBox.result();
}

SUI::StandardButtonEnum::Button SUI::MessageBox::question(
        SUI::Widget *parent, const std::string &title, const std::string &text,
        StandardButtonEnum::Buttons buttons, StandardButtonEnum::Button defaultButton) {
    return (StandardButtonEnum::Button)QMessageBox::question(static_cast<QWidget*>(getParent(parent)),QString::fromStdString(title),QString::fromStdString(text),(QMessageBox::StandardButtons)buttons,(QMessageBox::StandardButton)defaultButton);
}

SUI::StandardButtonEnum::Button SUI::MessageBox::warning(
        Widget *parent, const std::string &title, const std::string &text,
        StandardButtonEnum::Buttons buttons, StandardButtonEnum::Button defaultButton) {
    QWidget *qParent = NULL;
    if (parent != NULL) qParent = dynamic_cast<SUI::BaseWidget*>(SUI::ObjectFactory::getInstance()->toBaseObject(parent))->getWidget();
    else {
        qParent = new QWidget;
        qParent->setStyleSheet(QString::fromStdString(SUI::StyleSheet::getInstance()->getStyleSheet()));
    }
    return (StandardButtonEnum::Button)QMessageBox::warning(qParent,QString::fromStdString(title),QString::fromStdString(text),(QMessageBox::StandardButtons)buttons,(QMessageBox::StandardButton)defaultButton);
}

std::string SUI::MessageBox::custom(SUI::Widget *parent, const std::string &title, const std::string &text,
        MessageBoxIconEnum::MessageBoxIconType icon, const std::string &buttons, const std::string &defaultButton)
{
    QMessageBox messageBox(static_cast<QWidget*>(getParent(parent)));
    messageBox.setWindowTitle(QString::fromStdString(title));
    messageBox.setText(QString::fromStdString(text));
    messageBox.resize(280,80); //FIXME Doesnt work
    QStringList buttonList = QString::fromStdString(buttons).split("|");
    BOOST_FOREACH (const QString &button, buttonList) {
        QPushButton *b = messageBox.addButton(button,QMessageBox::NoRole);
        if (b->text().toStdString() == defaultButton) messageBox.setDefaultButton(b);
    }

    messageBox.setIcon((QMessageBox::Icon)icon);
    int result = messageBox.exec();
    return messageBox.buttons().at(result)->text().toStdString();
}

void *SUI::MessageBox::getParent(Widget *parent) {
   QWidget *qParent = NULL;
   if (parent != NULL) qParent = dynamic_cast<SUI::BaseWidget*>(SUI::ObjectFactory::getInstance()->toBaseObject(parent))->getWidget();
   else {
       qParent = new QWidget;
       qParent->setStyleSheet(QString::fromStdString(SUI::StyleSheet::getInstance()->getStyleSheet()));
   }
   return qParent;
}

