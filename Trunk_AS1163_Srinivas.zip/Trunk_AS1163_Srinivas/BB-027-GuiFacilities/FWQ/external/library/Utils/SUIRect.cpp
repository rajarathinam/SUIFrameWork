
//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Class implementation file for Rect.
// !\description Class implementation file for Rect.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#include "FWQxCore/SUIRect.h"

SUI::Rect::Rect(const int x1, const int y1, const int width, const int height):
    x(x1),
    y(y1),
    w(width),
    h(height)
{
}

int SUI::Rect::getHeight() const {
    return h;
}

void SUI::Rect::setHeight(int value) {
    h = value;
}

int SUI::Rect::getWidth() const {
    return w;
}

void SUI::Rect::setWidth(int value) {
    w = value;
}

int SUI::Rect::getY() const {
    return y;
}

void SUI::Rect::setY(int value) {
    y = value;
}

int SUI::Rect::getX() const {
    return x;
}

void SUI::Rect::setX(int value) {
    x = value;
}

bool SUI::Rect::operator==(const SUI::Rect &rect) const {
    return (this->getX() == rect.getX() &&
            this->getY() == rect.getY() &&
            this->getWidth() == rect.getWidth() &&
            this->getHeight() == rect.getHeight());
}
