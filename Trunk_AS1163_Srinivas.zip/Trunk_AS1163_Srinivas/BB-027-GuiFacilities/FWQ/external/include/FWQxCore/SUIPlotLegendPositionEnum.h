//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::PlotLegendPositionEnum.
// !\description Header file for class SUI::PlotLegendPositionEnum.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUIPLOTLEGENDPOSITIONENUM_H
#define SUIPLOTLEGENDPOSITIONENUM_H

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief This enum type is used to describe plot legend positions
 */
class PlotLegendPositionEnum {
public:
    /*!
     * \brief PlotLegendPosition
     * This enum type is used to describe legend position options
     */
    enum PlotLegendPosition{
        Left,
        Right,
        Bottom,
        Top
    };
};

}
#endif // SUIPLOTLEGENDPOSITIONENUM_H
