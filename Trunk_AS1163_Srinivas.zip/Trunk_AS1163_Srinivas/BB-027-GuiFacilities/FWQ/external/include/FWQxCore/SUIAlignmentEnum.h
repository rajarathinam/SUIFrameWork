//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::AlignmentEnum.
// !\description Header file for class SUI::AlignmentEnum.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|



#ifndef SUIALIGNMENTENUM_H
#define SUIALIGNMENTENUM_H

#include <string>

namespace SUI {

/*!
 * \ingroup FWQxCore
 *
 * \brief This enum type is used to describe alignment. It contains horizontal flags that can be combined to produce the required effect.
 */
class AlignmentEnum
{
public:
    /*!
     * \brief Alignment
     * The alignment enumeration
     */
    typedef enum
    {
        Right,
        HCenter,
        Left,
        Stretch
    } Alignment;

    /*!
     * \brief toString
     * \Convert an Alignment to a string object
     * \param alignment: to be converted alignment
     * \return
     */
    static std::string toString(AlignmentEnum::Alignment alignment);

    /*!
     * \brief fromString
     * Convert a string to an Alignment object
     * \param alignment: to be converted string
     * \return
     */
    static AlignmentEnum::Alignment fromString(const std::string &alignment);

};
}
#endif // SUIALIGNMENTENUM_H
