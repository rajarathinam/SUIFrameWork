//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::PlotRenderer.
// !\description Header file for class SUI::PlotRenderer.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUIPLOTRENDERER_H
#define SUIPLOTRENDERER_H

#include "FWQxCore/SUISharedExport.h"
#include <string>
namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief The PlotRenderer class
 */
class PlotWidget;
class SUI_SHARED_EXPORT PlotRenderer {
public:
    PlotRenderer();
    virtual ~PlotRenderer();

    /*!
     * \brief renderDocument
     * Render a plot to a file.
     * \param plotWidget - Plot Widget
     * \param fileName - Path of the file, where the document will be stored
     * \param format - format for the document
     * \param widthMM - width of document in millimeters
     * \param heightMM - height  of document in millimeters
     * \param resolution - Resolution in dots per Inch (dpi)
     */
    void renderDocument( PlotWidget *plotWidget, const std::string &fileName, const std::string &format, const double widthMM, const double heightMM, int resolution = 85);

private:
    void *implementation;
};
}
#endif // SUIPLOTRENDERER_H
