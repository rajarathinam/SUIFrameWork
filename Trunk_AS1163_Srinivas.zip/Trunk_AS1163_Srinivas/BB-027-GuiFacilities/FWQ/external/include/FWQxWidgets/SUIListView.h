//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ListView.
// !\description Header file for class SUI::ListView.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUILISTVIEW_H
#define SUILISTVIEW_H

#include "FWQxWidgets/SUIWidget.h"
#include "FWQxCore/SUIStringList.h"

#include "FWQxCore/SUIIText.h"
#include "FWQxCore/SUIIClickable.h"
#include "FWQxCore/SUIIFilterable.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief Specific Interface for the ListView Widget
 */
class SUI_SHARED_EXPORT ListView : public Widget, public IText, public IClickable, public StringList, public IFilterable
{
public:
    virtual ~ListView();
  /*!
   * \brief getSize
   * Returns the number of items in the ListView
   */
  virtual int getSize() const = 0;

protected:
    ListView();
};
}

#endif // SUILISTVIEW_H
