
#include "SUIUserControlImplUnitTest.h"
#include "SUIUserControlImpl.h"
#include "SUIBaseObject.h"

SUI::UserControlImplUnitTest::UserControlImplUnitTest(SUI::UserControlImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::UserControlImplUnitTest::~UserControlImplUnitTest()
{
   delete object;
}

void SUI::UserControlImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
