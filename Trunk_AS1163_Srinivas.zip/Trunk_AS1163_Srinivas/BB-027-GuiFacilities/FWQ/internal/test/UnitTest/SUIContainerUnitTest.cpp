#include"SUIContainerUnitTest.h"

#include <FWQxWidgets/SUIContainer.h>
#include <QTest>

SUI::ContainerUnitTest::ContainerUnitTest(SUI::Container *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::ContainerUnitTest::~ContainerUnitTest() {
    delete object;
}

void SUI::ContainerUnitTest::callInterfaceTests() {
}


