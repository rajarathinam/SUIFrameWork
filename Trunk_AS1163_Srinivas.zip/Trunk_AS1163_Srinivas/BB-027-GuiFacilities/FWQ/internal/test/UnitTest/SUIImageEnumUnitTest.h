#ifndef SUIIMAGEENUMUNITTEST_H
#define SUIIMAGEENUMUNITTEST_H
#include <QObject>

#include "FWQxCore/SUIImageEnum.h"

namespace SUI {

class ImageEnumUnitTest : public QObject
{
    Q_OBJECT

public:
    ImageEnumUnitTest();
    ~ImageEnumUnitTest();

private slots:
    void testgetFileExtension();

};

}
#endif // SUIIMAGEENUMUNITTEST_H
