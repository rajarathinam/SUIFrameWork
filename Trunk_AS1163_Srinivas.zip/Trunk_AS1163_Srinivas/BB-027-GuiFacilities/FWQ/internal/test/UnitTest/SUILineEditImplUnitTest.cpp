
#include "SUILineEditImplUnitTest.h"
#include "SUILineEditImpl.h"
#include "SUIBaseObject.h"

SUI::LineEditImplUnitTest::LineEditImplUnitTest(SUI::LineEditImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::LineEditImplUnitTest::~LineEditImplUnitTest()
{
   delete object;
}

void SUI::LineEditImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::EditorForm);
    object->setDefaultProperties(SUI::BaseObject::EditorSelector);
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
