
#ifndef SUILISTVIEWIMPLUNITTEST_H
#define SUILISTVIEWIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class ListViewImpl;

class ListViewImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit ListViewImplUnitTest(ListViewImpl *object, QObject *parent = 0);
    virtual ~ListViewImplUnitTest();

private slots:
    void setDefaultProperties();
    void testAddItems();

    void testGetSize();
    void testClearItems();
    void testClearText();
    void testFormatStdString();
    void testGetAllColumnItems();
    void testGetItems();
    void testSetBold();
private:
    ListViewImpl *object;
};

}
#endif // SUILISTVIEWIMPLUNITTEST_H
