#include "SUITimeUnitTest.h"
#include <FWQxUtils/SUITime.h>

#include <QTest>

SUI::TimeUnitTest::TimeUnitTest() :
    time(SUI::Time::createTime())
{
}

void SUI::TimeUnitTest::tesCurrentTime(){
    //time set to current time, but not started
    QCOMPARE(QString::fromStdString( time->toString( "hh:mm" )), QTime::currentTime().toString("hh:mm"));
}

void SUI::TimeUnitTest::testSetHMS_data() {
    QTest::addColumn<int>("hour");
    QTest::addColumn<int>("minute");
    QTest::addColumn<int>("sec");

    QTest::newRow(  "data0" ) << 0 << 0 << 0;
    QTest::newRow(  "data1" ) << 1 << 2 << 3;
    QTest::newRow(  "data2" ) << 0 << 59 << 0;
    QTest::newRow(  "data3" ) << 0 << 59 << 59;
    QTest::newRow(  "data4" ) << 23 << 0 << 0;
    QTest::newRow(  "data5" ) << 23 << 59 << 0;
    QTest::newRow(  "data6" ) << 23 << 59 << 59;
    //invalid data
    QTest::newRow(  "data7" ) << -1 << -1 << -1;
}

void SUI::TimeUnitTest::testSetHMS() {
    QFETCH( int, hour );
    QFETCH( int, minute );
    QFETCH( int, sec );

    bool ret = time->setHMS( hour, minute, sec );
    if(hour == -1 && minute == -1 && sec == -1) {
        QCOMPARE( ret, false );
    } else {
        QCOMPARE( time->getHour(), hour );
        QCOMPARE( time->getMinute(),minute );
        QCOMPARE( time->getSecond(), sec );
        QCOMPARE( ret, true);
    }
}

void SUI::TimeUnitTest::testToString_data() {
    QTest::addColumn<int>("hour");
    QTest::addColumn<int>("minute");
    QTest::addColumn<int>("sec");
    QTest::addColumn<int>("msec");
    QTest::addColumn<QString>("format");
    QTest::addColumn<QString>("str");

    QTest::newRow( "data0" ) << 0 << 0 << 0<< 0 << QString("h:m:s:z") << QString("0:0:0:0");
    QTest::newRow( "data1" ) << 10 << 12 << 34 << 53 << QString("hh:mm:ss:zzz") << QString("10:12:34:053");
    QTest::newRow( "data2" ) << 10 << 12 << 34 << 45 << QString("hh:m:ss:z") << QString("10:12:34:45");
    QTest::newRow( "data3" ) << 10 << 12 << 34 << 45 << QString("hh:ss ap") << QString("10:34 am");
    QTest::newRow( "data4" ) << 22 << 12 << 34 << 45 << QString("hh:zzz AP") << QString("10:045 PM");
    QTest::newRow( "data5" ) << 230 << 230 << 230 << 230 << QString("hh:mm:ss") << QString();
}

void SUI::TimeUnitTest::testToString() {
    QFETCH( int, hour );
    QFETCH( int, minute );
    QFETCH( int, sec );
    QFETCH( int, msec );
    QFETCH( QString, format );
    QFETCH( QString, str );

    time->setHMS( hour, minute, sec, msec );
    QCOMPARE( time->toString( format.toStdString() ), str.toStdString());
}

void SUI::TimeUnitTest::testToStringFormat() {
    QFETCH( int, hour );
    QFETCH( int, minute );
    QFETCH( int, sec );
    QFETCH( int, msec );

    time->setHMS( hour, minute, sec, msec );
    QCOMPARE(QString::fromStdString( time->toString(SUI::DateTimeEnum::TextDate)), QTime(hour,minute,sec,msec).toString( Qt::TextDate));
    QCOMPARE(QString::fromStdString( time->toString(SUI::DateTimeEnum::ISODate)), QTime(hour,minute,sec,msec).toString( Qt::ISODate));
}

void SUI::TimeUnitTest::testToStringFormat_data() {
    QTest::addColumn<int>("hour");
    QTest::addColumn<int>("minute");
    QTest::addColumn<int>("sec");
    QTest::addColumn<int>("msec");
    QTest::addColumn<QString>("expected");

    QTest::newRow("00:00:00.000") << 0 << 0 << 0 << 0;
    QTest::newRow("ISO 10:12:34.000") << 10 << 12 << 34 << 0 ;
}

void SUI::TimeUnitTest::testIsValidAndNull() {
     time->restart();
     time->start();
     QCOMPARE(false, time->isNull() );
     QCOMPARE(true, time->isValid());
}
