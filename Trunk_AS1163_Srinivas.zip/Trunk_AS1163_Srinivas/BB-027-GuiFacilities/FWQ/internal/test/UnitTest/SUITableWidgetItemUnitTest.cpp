#include "SUITableWidgetItemUnitTest.h"
#include "SUIIAlignableUnitTest.h"
#include "SUIITextUnitTest.h"
#include <QTest>

SUI::TableWidgetItemUnitTest::TableWidgetItemUnitTest(SUI::TableWidgetItem *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::TableWidgetItemUnitTest::~TableWidgetItemUnitTest() {
    delete object;
}

void SUI::TableWidgetItemUnitTest::callInterfaceTests() {
    //IText unit test
    ITextUnitTest iTextUnitTest(object);
    QVERIFY(iTextUnitTest.setText());
    QVERIFY(iTextUnitTest.clearText());
    //TODO set bold interface test fails
    //QVERIFY(iTextUnitTest.setBold());

    //IAlignable tests
    IAlignableUnitTest iAlignableUnitTest(object);
    // Valid alignment
    // TODO Because of the V alignment mask for the table items the return
    // value is never the same as the input alignment. The default
    // interface tests will always fail because of this
    //QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::HCenter));
    //QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Left));
    //QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Right));
    // Invalid alignment
    QVERIFY(!iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Stretch));
}

void SUI::TableWidgetItemUnitTest::setFontSize() {
    //nominal
    object->setFontSize(SUI::FontSizeEnum::Big);
    QCOMPARE(object->getFontSize(), SUI::FontSizeEnum::Big);
    object->setFontSize(SUI::FontSizeEnum::Small);
    QCOMPARE(object->getFontSize(), SUI::FontSizeEnum::Small);
    object->setFontSize(SUI::FontSizeEnum::Normal);
    QCOMPARE(object->getFontSize(), SUI::FontSizeEnum::Normal);
    //robust case
    object->setFontSize(SUI::FontSizeEnum::Uninitialized);
    QCOMPARE(object->getFontSize(), SUI::FontSizeEnum::Normal);
}
