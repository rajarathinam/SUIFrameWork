
#include "SUIExceptionUnitTest.h"
#include <FWQxCore/SUIIOException.h>
#include <FWQxCore/SUIXmlException.h>
#include <QTest>

SUI::ExceptionUnitTest::ExceptionUnitTest()
{
}

void SUI::ExceptionUnitTest::tesCurrentException() {
SUI::IOException* exception = new SUI::IOException(std::string(""));
SUI::XmlException* xmlException = new SUI::XmlException(std::string(""));
delete xmlException;
delete exception;
}
