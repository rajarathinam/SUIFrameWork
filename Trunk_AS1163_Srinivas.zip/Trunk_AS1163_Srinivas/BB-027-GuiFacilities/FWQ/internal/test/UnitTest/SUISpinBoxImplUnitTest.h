
#ifndef SUISPINBOXIMPLUNITTEST_H
#define SUISPINBOXIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class SpinBoxImpl;

class SpinBoxImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit SpinBoxImplUnitTest(SpinBoxImpl *object, QObject *parent = 0);
    virtual ~SpinBoxImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    SpinBoxImpl *object;
};

}
#endif // SUISPINBOXIMPLUNITTEST_H
