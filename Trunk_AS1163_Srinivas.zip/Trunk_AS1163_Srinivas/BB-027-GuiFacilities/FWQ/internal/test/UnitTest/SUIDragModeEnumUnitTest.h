#ifndef SUIDRAGMODEENUMUNITTEST_H
#define SUIDRAGMODEENUMUNITTEST_H
#include <QObject>

#include "FWQxCore/SUIDragModeEnum.h"

namespace SUI {

class DragModeEnumUnitTest : public QObject
{
    Q_OBJECT

public:
    DragModeEnumUnitTest();
    ~DragModeEnumUnitTest();

private slots:
    void testToString();
    void testFromString();

};

}
#endif // SUIDRAGMODEENUMUNITTEST_H
