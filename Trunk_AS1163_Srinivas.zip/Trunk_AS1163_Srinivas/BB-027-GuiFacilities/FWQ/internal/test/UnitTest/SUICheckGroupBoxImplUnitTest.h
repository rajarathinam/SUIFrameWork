
#ifndef SUICHECKGROUPBOXIMPLUNITTEST_H
#define SUICHECKGROUPBOXIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class CheckGroupBoxImpl;

class CheckGroupBoxImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit CheckGroupBoxImplUnitTest(CheckGroupBoxImpl *object, QObject *parent = 0);
    virtual ~CheckGroupBoxImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    CheckGroupBoxImpl *object;
};

}
#endif // SUICHECKGROUPBOXIMPLUNITTEST_H
