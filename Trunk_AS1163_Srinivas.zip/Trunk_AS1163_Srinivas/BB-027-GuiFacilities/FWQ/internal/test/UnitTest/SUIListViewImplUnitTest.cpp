
#include "SUIListViewImplUnitTest.h"
#include "SUIListViewImpl.h"
#include "SUIBaseObject.h"

SUI::ListViewImplUnitTest::ListViewImplUnitTest(SUI::ListViewImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::ListViewImplUnitTest::~ListViewImplUnitTest()
{
   delete object;
}

void SUI::ListViewImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::EditorForm);
    object->setDefaultProperties(SUI::BaseObject::EditorSelector);
    object->setDefaultProperties(SUI::BaseObject::Gui);

}

void SUI::ListViewImplUnitTest::testGetSize()
{
  object->clearItems();
  QCOMPARE(0, object->getSize());

  std::list<std::string> datalist;
  datalist.push_back("Data1");
  datalist.push_back("Data2");
  datalist.push_back("Data3");
  datalist.push_back("Data4");
  object->addItems(datalist);
  QCOMPARE(4, object->getSize());
}

void SUI::ListViewImplUnitTest::testAddItems()
{
  object->clearItems();
  QCOMPARE(0, object->getSize());

  std::list<std::string> datalist;
  datalist.push_back("Data1");
  datalist.push_back("Data2");
  datalist.push_back("Data3");
  datalist.push_back("Data4");
  object->addItems(datalist);
  QCOMPARE(4, object->getSize());
}
void SUI::ListViewImplUnitTest::testClearItems()
{
  std::list<std::string> datalist;
  datalist.push_back("Data1");
  datalist.push_back("Data2");
  datalist.push_back("Data3");
  datalist.push_back("Data4");
  object->addItems(datalist);
  QCOMPARE(4, object->getSize());

  object->clearItems();
  QCOMPARE(0, object->getSize());
}

void SUI::ListViewImplUnitTest::testClearText()
{
  std::list<std::string> datalist1;
  datalist1.push_back("Data1");
  datalist1.push_back("Data2");
  datalist1.push_back("Data3");

  object->addItems(datalist1);
  QCOMPARE(3, object->getSize());
  object->clearText();
  QCOMPARE(0, object->getSize());
}

void SUI::ListViewImplUnitTest::testFormatStdString()
{
  // setText and getText also covered here

  std::string input = "ASML;Framework\nSUI";
  object->setText(input);
  std::string actual = object->getText();
  std::string expected = "ASML;Framework;SUI";
  QCOMPARE(actual, expected);

  object->clearItems();
  std::string input1 = "";
  object->setText(input1);
  std::string actual1 = object->getText();
  std::string expected1 = "";
  std::cout << actual1 << std::endl;
  QCOMPARE(actual1, expected1);

  object->clearItems();
  std::string input2 = " ";
  object->setText(input2);
  std::string actual2 = object->getText();
  std::string expected2 = " ";
  QCOMPARE(actual2, expected2);

  object->clearItems();
  std::string input3 = "ASMLSUIFramework";
  object->setText(input3);
  std::string actual3 = object->getText();
  std::string expected3 = "ASMLSUIFramework";
  QCOMPARE(actual3, expected3);

}
void SUI::ListViewImplUnitTest::testGetAllColumnItems()
{
  object->clearItems();
  std::list<std::string> datalist;
  datalist.push_back("Data1");
  datalist.push_back("Data2");
  datalist.push_back("Data3");

  object->addItems(datalist);

  std::string expected = "Data1;Data2;Data3";
  std::string actual = object->getAllColumnItems().toStdString();
  QCOMPARE(actual, expected);

  object->clearItems();

  std::string expected1 = "";
  std::string actual1 = object->getAllColumnItems().toStdString();
  QCOMPARE(actual1, expected1);

}

void SUI::ListViewImplUnitTest::testGetItems()
{
  object->clearItems();
  std::list<std::string> datalist;
  datalist.push_back("Data1");
  datalist.push_back("Data2");
  datalist.push_back("Data3");

  object->addItems(datalist);

  std::list<std::string> actualList = object->getItems();
  int size = actualList.size();
  QCOMPARE(size, 3);

  std::string str1 = "Data1";
  QCOMPARE(actualList.front(), str1);
  actualList.pop_front();

  std::string str2 = "Data2";
  QCOMPARE(actualList.front(), str2);
  actualList.pop_front();

  std::string str3 = "Data3";
  QCOMPARE(actualList.front(), str3);
  actualList.pop_front();

  size = actualList.size();
  QCOMPARE(size, 0);

}
void SUI::ListViewImplUnitTest::testSetBold()
{
  object->setBold(false);
  QVERIFY(!object->isBold());

  object->setBold(true);
  QVERIFY(object->isBold());
}
