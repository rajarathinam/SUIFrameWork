#include "SUILabelUnitTest.h"

#include <QTest>

#include <FWQxWidgets/SUILabel.h>
#include <FWQxCore/SUIFontSizeEnum.h>

#include "SUIITextUnitTest.h"
#include "SUIIAlignableUnitTest.h"
#include "SUIIColorableUnitTest.h"
#include "SUIIBGColorableUnitTest.h"
#include "SUIIClickableUnitTest.h"

SUI::LabelUnitTest::LabelUnitTest(SUI::Label *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
    Q_ASSERT(object);
}

SUI::LabelUnitTest::~LabelUnitTest() {
   delete object;
}

void SUI::LabelUnitTest::callInterfaceTests() {
    //IText unit test
    ITextUnitTest iTextUnitTest(object);
    QVERIFY(iTextUnitTest.setText());
    QVERIFY(iTextUnitTest.clearText());
    QVERIFY(iTextUnitTest.setBold());

    //IAlignable unit test
    IAlignableUnitTest iAlignableUnitTest(object);
    // Valid alignment
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::HCenter));
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Left));
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Right));
    // Invalid alignment
    QVERIFY(!iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Stretch));

    //IColorable tests
    IColorableUnitTest iColorableUnitTest(object);
    // Valid colors
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Standard));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Green));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Red));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Gray));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Blue));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::White));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Yellow));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Orange));
    QVERIFY(iColorableUnitTest.setColor(SUI::ColorEnum::Transparent));
    // Invalid colors
    object->setColor(SUI::ColorEnum::Black);
    QCOMPARE(object->getColor(), SUI::ColorEnum::Transparent);

    //IBGColorable tests
    IBGColorableUnitTest iBGColorableUnitTest(object);
    //TODO the interface should accept all colors but doesn't
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Standard));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Green));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Red));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Gray));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Blue));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::White));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Yellow));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Orange));
    QVERIFY(iBGColorableUnitTest.setBackgroundColor(SUI::ColorEnum::Transparent));

    //IClickable tests
    IClickableUnitTest iClickable(object);
    iClickable.clickable();
}

void SUI::LabelUnitTest::setFontSize() {
    object->setFontSize(SUI::FontSizeEnum::Big);
    QCOMPARE(object->getFontSize(),SUI::FontSizeEnum::Big);
    object->setFontSize(SUI::FontSizeEnum::Small);
    QCOMPARE(object->getFontSize(),SUI::FontSizeEnum::Small);
    object->setFontSize(SUI::FontSizeEnum::Normal);
    QCOMPARE(object->getFontSize(),SUI::FontSizeEnum::Normal);
}

void SUI::LabelUnitTest::testSetHighlightText() {
    QFETCH(QString, data);
    QFETCH(QString, text);
    QFETCH(QString, searchText);
    QFETCH(QString, Color);

    object->setText(text.toStdString());
    QCOMPARE(object->getText(),text.toStdString());

    object->setHighlightText(searchText.toStdString(), Color.toStdString());
    if(data == "data1" || data == "data2"){
        QCOMPARE(object->getHighlightText(), searchText.toStdString());
    }else {
        QCOMPARE(object->getHighlightText(), QString("").toStdString());
    }
}

void SUI::LabelUnitTest::testSetHighlightText_data() {
    QTest::addColumn<QString>("data");
    QTest::addColumn<QString>("text");
    QTest::addColumn<QString>("searchText");
    QTest::addColumn<QString>("Color");
    //valid data
    QTest::newRow("test1") << QString("data1") << QString("settext") << QString("se") << QString("blue");
    //valid data
    QTest::newRow("test2") << QString("data2") << QString("set text") << QString("text") << QString("#0000ff");
    //invalid color
    QTest::newRow("test3") << QString("data3") << QString("settext") << QString("se") << QString("invalid color");
    //invalid search text
    QTest::newRow("test4") << QString("data4") << QString("gui framework") << QString("adt") << QString("red");
    //search string empty
    QTest::newRow("test5") << QString("data5") << QString("set text") << QString("") << QString("#0000ff");
}

