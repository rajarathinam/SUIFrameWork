
#include "SUIBusyIndicatorImplUnitTest.h"
#include "SUIBusyIndicatorImpl.h"
#include "SUIBaseObject.h"

SUI::BusyIndicatorImplUnitTest::BusyIndicatorImplUnitTest(SUI::BusyIndicatorImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::BusyIndicatorImplUnitTest::~BusyIndicatorImplUnitTest()
{
   delete object;
}

void SUI::BusyIndicatorImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
