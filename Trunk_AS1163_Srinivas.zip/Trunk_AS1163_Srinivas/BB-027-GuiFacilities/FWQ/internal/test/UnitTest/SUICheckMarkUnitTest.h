#ifndef SUICHECKMARKUNITTEST_H
#define SUICHECKMARKUNITTEST_H

#include "SUIWidgetUnitTest.h"

namespace SUI {

class CheckMark;

class CheckMarkUnitTest : public WidgetUnitTest
{
    Q_OBJECT

public:
    explicit CheckMarkUnitTest(CheckMark *object, QObject *parent = 0);
    virtual ~CheckMarkUnitTest();

protected:
    void callInterfaceTests();

private:
    CheckMark *object;
};

}
#endif // SUICHECKMARKUNITTEST_H
