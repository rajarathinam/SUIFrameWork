
#ifndef SUISCROLLBARIMPLUNITTEST_H
#define SUISCROLLBARIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class ScrollBarImpl;

class ScrollBarImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit ScrollBarImplUnitTest(ScrollBarImpl *object, QObject *parent = 0);
    virtual ~ScrollBarImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    ScrollBarImpl *object;
};

}
#endif // SUISCROLLBARIMPLUNITTEST_H
