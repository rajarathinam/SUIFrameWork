#include "SUISpinBoxUnitTest.h"
#include "SUIIAlignableUnitTest.h"
#include "SUIINumericUnitTest.h"
#include "SUIIErrorModeUnitTest.h"
#include <QTest>

SUI::SpinBoxUnitTest::SpinBoxUnitTest(SUI::SpinBox *object, QObject *parent) :
    WidgetUnitTest(object,parent),
    object(object)
{
}

SUI::SpinBoxUnitTest::~SpinBoxUnitTest() {
    delete object;
}

void SUI::SpinBoxUnitTest::callInterfaceTests() {
    //IAlignable unit test
    IAlignableUnitTest iAlignableUnitTest(object);
    // Valid alignment
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::HCenter));
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Left));
    QVERIFY(iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Right));
    // Invalid alignment
    QVERIFY(!iAlignableUnitTest.setAlignment(SUI::AlignmentEnum::Stretch));

    //INumeric unit test
    INumericUnitTest iNumericUnitTest(object);
    QVERIFY(iNumericUnitTest.testInteger());

    //IErrorMode unit test
    IErrorModeUnitTest iErrorModeUnitTest(object);
    QVERIFY(iErrorModeUnitTest.setErrorMode());
}
