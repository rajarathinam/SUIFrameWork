
#include "SUITreeViewImplUnitTest.h"
#include "SUITreeViewImpl.h"
#include "SUIBaseObject.h"

SUI::TreeViewImplUnitTest::TreeViewImplUnitTest(SUI::TreeViewImpl *object, QObject *parent) :
    QObject(parent),
    object(object)
{

}

SUI::TreeViewImplUnitTest::~TreeViewImplUnitTest()
{
   delete object;
}

void SUI::TreeViewImplUnitTest::setDefaultProperties() {
    object->setDefaultProperties(SUI::BaseObject::Gui);
}
