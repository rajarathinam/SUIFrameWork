#include "SUITreeViewUnitTest.h"
#include "SUIITextUnitTest.h"
#include <QTest>
#include <QTreeView>
#include "SUIBaseWidget.h"
#include <FWQxCore/SUIUILoader.h>
#include <FWQxWidgets/SUIDialog.h>
#include <FWQxCore/SUIObjectList.h>

SUI::TreeViewUnitTest::TreeViewUnitTest(SUI::TreeView *object, QObject *parent) :
    WidgetUnitTest(object, parent),
    object(object)
{
}

SUI::TreeViewUnitTest::~TreeViewUnitTest()
{
    delete object;
}

void SUI::TreeViewUnitTest::callInterfaceTests() {
    // IText UnitTests
    ITextUnitTest iTextUnitTest(object);
    QVERIFY(iTextUnitTest.setText());
    QVERIFY(iTextUnitTest.clearText());
    QVERIFY(iTextUnitTest.setBold());
}

void SUI::TreeViewUnitTest::setTitle() {
    const std::string title = "Unit test";

    object->setTitle(title);
    QCOMPARE(object->getTitle(), title);
}

void SUI::TreeViewUnitTest::testDisableHeader() {
    SUI::BaseWidget *widget = dynamic_cast<SUI::BaseWidget *>(object);
    if(widget != NULL) {
        QTreeView *treeView = qobject_cast<QTreeView *>(widget->getWidget());
        if(treeView != NULL) {
            object->disableHeader(true);
            QCOMPARE(treeView->isHeaderHidden(), true);
            object->disableHeader(false);
            QCOMPARE(treeView->isHeaderHidden(), false);
        }
    }
}

/* -- UnitTestTreeView.xml
 *  |-tbw1
 *    |-tbp2
 *     |-trv29 //Tree View
 *         |-tri30(a)
 *           |-tri31(aa)
 *           |-tri32(ab)
 *         |-tri33(b)
 *           |-tri34(ba)
 *           |-tri35(bb)
 *           |-tri36(bc)
 *         |-tri37(c)
 *           |-tri38(ca)
 *             |-tri39(caa)
 *             |-tri40(cab)
 *           |-tri41(cb)
 */
void SUI::TreeViewUnitTest::testIsLeafNode()  {
    SUI::Dialog *dialog = SUI::UILoader::loadUI(":UnitTestTreeView.xml");
    SUI::TreeView *treeView = dialog->getObjectList()->getObject<SUI::TreeView>("trv29");

    QCOMPARE(treeView->isLeafNode("tri30"), false);
    QCOMPARE(treeView->isLeafNode("tri38"), false);
    QCOMPARE(treeView->isLeafNode("tri41"), true);
    QCOMPARE(treeView->isLeafNode("tri34"), true);

    delete dialog;
    dialog = NULL;
}

/* -- UnitTestTreeView.xml
 *  |-tbw1
 *    |-tbp2
 *     |-trv29 //Tree View
 *         |-tri30(a)
 *           |-tri31(aa)
 *           |-tri32(ab)
 *         |-tri33(b)
 *           |-tri34(ba)
 *           |-tri35(bb)
 *           |-tri36(bc)
 *         |-tri37(c)
 *           |-tri38(ca)
 *             |-tri39(caa)
 *             |-tri40(cab)
 *           |-tri41(cb)
 */
void SUI::TreeViewUnitTest::testAddTreeItem() {
    QFETCH(QString, text);
    QFETCH(QString, newID);
    QFETCH(QString, parentID);
    SUI::Dialog *dialog = SUI::UILoader::loadUI(":UnitTestTreeView.xml");
    SUI::TreeView *treeView = dialog->getObjectList()->getObject<SUI::TreeView>("trv29");

    std::string newIDstr = newID.startsWith("tri") ? newID.prepend("tri").toStdString() : newID.toStdString();

    treeView->addTreeItem(text.toStdString(), newIDstr, parentID.toStdString());
    QCOMPARE(true, dialog->getObjectList()->idExists(newIDstr));
    QCOMPARE(treeView->isLeafNode(parentID.toStdString()), false);

    delete dialog;
    dialog = NULL;
}

void SUI::TreeViewUnitTest::testAddTreeItem_data() {
    QTest::addColumn<QString>("text");
    QTest::addColumn<QString>("newID");
    QTest::addColumn<QString>("parentID");
    //nominal item with ID = newId
    QTest::newRow("data1") << QString("ac") << QString("newId") << QString("tri30");
    //nominal item with ID = tri1111
    QTest::newRow("data2") << QString("aca") << QString("tri111") << QString("trinewId");
    //
    QTest::newRow("data2") << QString("aca") << QString("trinewId") << QString("trinewId");

}


