
#ifndef SUIMESSAGEBOXIMPLUNITTEST_H
#define SUIMESSAGEBOXIMPLUNITTEST_H

#include <QTest>
namespace SUI {

class MessageBoxImpl;

class MessageBoxImplUnitTest : public QObject
{
    Q_OBJECT
public:
    explicit MessageBoxImplUnitTest(MessageBoxImpl *object, QObject *parent = 0);
    virtual ~MessageBoxImplUnitTest();

private slots:
    void setDefaultProperties();

private:
    MessageBoxImpl *object;
};

}
#endif // SUIMESSAGEBOXIMPLUNITTEST_H
